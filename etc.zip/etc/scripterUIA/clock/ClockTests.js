#import "./Clock.js"
#import "../libs/PHTesting.js"
#import "../settings/Settings.js"

// --------------------------------------------------------------------------------
//	Function: clockTest_addWorldClock 
//		Adds a world clock to the Clock App.
//
//	Parameters: 
//		city (string) - City name to search for
//		identifier (string) - The whole string that shows up when you do the search
//			for the city.  For example, if you type in Paris, "Paris, France" should
//			be entered for the identifier. 
//
//	Returns: 
//		1 if test passes, 0 or 64 if test fails. 
// --------------------------------------------------------------------------------
function clockTest_addWorldClock() {
	
	if (this.argv.length < 2) {
		UIALogger.logError(arguments.callee.name + ": Wrong search parameters specified.");
		return 64;		
	}
	
	var city = this.argv[0];
	var identifier = this.argv[1];
	
	clock.getToClockView();
	
	clock.addWorldClock(city);
	
	UIATarget.localTarget().delay(1); //animation delays
	if (!clock.mainWindow().images()[0].tableViews()[0].cells().firstWithPredicate("name contains '" + city + "'").isValid()) {
		this.testError = "Failed to verify added clock.";
		UIALogger.logError(this.testError);
		return this.testResult = 0;
	}
	
	UIALogger.logMessage("New clock added.");
	return this.testResult = 1;
}

// --------------------------------------------------------------------------------
//	Function: clockTest_removeWorldClock 
//		Removes a world clock
//
//	Parameters: 
//		label (string) - the label of the clock that needs to be removed.  
//
//	Returns: 
//		1 if test passes, 0 or 64 if test fails. 
// --------------------------------------------------------------------------------
function clockTest_removeWorldClock() {	
	var label = null;
	
	if (this.argv.length > 0) {
		var label = this.argv[0];
	}
	
	clock.getToClockView();
	
	var dupCount = clock.mainWindow().images()[0].tableViews()[0].cells().withPredicate("name contains '" + label + "'").length;
	UIALogger.logMessage(dupCount + " clocks found with '" + label + "'");
	
	clock.deleteWorldClock(label);
	
	//verify
	var updatedDupCount = clock.mainWindow().images()[0].tableViews()[0].cells().withPredicate("name contains '" + label + "'").length;
	if (updatedDupCount != (dupCount-1)) {
		this.testError = "Unexpected number of clocks found after deleting: " + updatedDupCount;
		UIALogger.logError(this.testError);
		return this.testResult = 0;
	}
	
	return this.testResult = 1;
}

// --------------------------------------------------------------------------------
//	Function: clockTest_addAlarm 
//		Adds an alarm
//
//	Optional Parameters: 
//		Optional arguments passed in as: "repeat:Every Tuesday" "snooze:0"
//			time	(string)	a string in the format hh:mm
//			repeat	(string)	the repeat string as shown in UI (i.e. "Every Monday", "Every Tuesday" ...)
//								(can specify multiple repeat strings)
//			sound	(string)	name of the sound as shown in UI (i.e. "Marimba", "Alarm"....)
//			snooze	(string)	value for the snooze option (i.e. "1" or "0")
//			label	(string)	label for the new alarm
//
//	Returns: 
//		1 if test passes, 0 or 64 if test fails. 
// --------------------------------------------------------------------------------
function clockTest_addAlarm(){
	var time, repeat, sound, snooze, label;
	
	time = UIAUtility.valuesForKey("time", this.argv, 1);
	repeat = UIAUtility.valuesForKey("repeat", this.argv, this.argv.length);
	sound = UIAUtility.valuesForKey("sound", this.argv, 1);
	snooze = UIAUtility.valuesForKey("snooze", this.argv, 1);
	label = UIAUtility.valuesForKey("label", this.argv, 1);
	
	clock.getToClockView();
	clock.tabBar().buttons()["Alarm"].tap();
	UIATarget.localTarget().delay(1);
	
	if (!label) label = time;
	var alarmCells = clock.mainWindow().images()[0].tableViews()[0].cells().withPredicate("name contains '" + label + "'");
	var originalAlarmsNumber = alarmCells.length;
	UIALogger.logMessage("Found " + originalAlarmsNumber + " alarms with label " + label);
		
	clock.navigationBar().buttons()["Add"].tap();
	if (!clock.navigationBar().withName("Add Alarm").isValid()) {
		this.testError = "Tapped 'Add' button but the 'Add Alarm' nav bar did not show up";
		UIALogger.logError(this.testError);
		return this.testResult = 0;
	}
	UIATarget.localTarget().delay(1);
	
	clock.setAlarm(time, null, repeat, sound, snooze, label);
	UIATarget.localTarget().delay(1);
	
	//verify we added the alarm
	if (label) {
		alarmCells = clock.mainWindow().images()[0].tableViews()[0].cells().withPredicate("name contains '" + label + "'");
		if (alarmCells.length != originalAlarmsNumber+1) { 
			this.testError = "Could not find the added alarm in the list";
			UIALogger.logError(this.testError);
			return this.testResult = 0;
		}
	}
	
	return this.testResult = 1;
}

// --------------------------------------------------------------------------------
//	Function: clockTest_addAndWaitForAlarm 
//		Adds an alarm, and waits for the alarm to fire off. 
//
//	Optional Parameters: 
//		Optional arguments passed in as: "repeat:Every Tuesday" "snooze:0"
//			systemDate		(string) -	a string in the format yyyy:mm:dd:hh:mm to specify the date/time the 
//										system should be set to, before adding the alarm
//			timezone		(string) - the timezone the system should be set to, before adding the alarm
//			time			(string) - the time the alarm should be set for (in the format hh:mm)
//			delay			(string) - number of minutes after the current time that the alarm will be set for. 
//										Note that this parameter is used only if the time parameter is not 
//										specified. 
//			waitInterval	(string) - the number of minutes to wait for the alarm alert to come up. If the time 
//										paramter is specified, but the waitInterval parameter is not specified, 
//										the test function only uses the date(s) specified by validationDate for 
//										verification i.e. it does not wait for the alarm to get activated after 
//										setting the alarm. If time parameter is not specified, the default value 
//										of waitInterval is the same as the delay value.
//			repeat			(string) - the repeat string as shown in UI (i.e. "Every Monday", "Every Tuesday" ...)
//			sound			(string) - name of the sound as shown in UI (i.e. "Marimba", "Alarm"....)
//			snooze			(string) - value for the snooze option (i.e. "1" or "0")
//			label			(string) - label for the new alarm
//			validationDate	(string) - a string in the format yyyy:mm:dd[:hh:mm] to specify the date(s) on which the 
//										alarm should be verified. 
//
//	Returns: 
//		1 if test passes, 0 or 64 if test fails. 
// --------------------------------------------------------------------------------
function clockTest_addAndWaitForAlarm()
{	
	var systemDate, timezone, time, delay, waitInterval, repeat, sound, snooze, label, validationDates;
	var alarmDate; //stores the time in a dictionary object of when the alarm should fire off (will not change over the course of the test)
	var useOriginalTimeForVerification = true;
	
	systemDate = UIAUtility.valuesForKey("systemDate", this.argv, 1);
	timezone = UIAUtility.valuesForKey("timezone", this.argv, 1);
	time = UIAUtility.valuesForKey("time", this.argv, 1);
	waitInterval = UIAUtility.valuesForKey("waitInterval", this.argv, 1);
	delay = parseInt(UIAUtility.valuesForKey("delay", this.argv, 1));
	repeat = UIAUtility.valuesForKey("repeat", this.argv, this.argv.length);
	sound = UIAUtility.valuesForKey("sound", this.argv, 1);
	snooze = UIAUtility.valuesForKey("snooze", this.argv, 1);
	label = UIAUtility.valuesForKey("label", this.argv, 1);
	validationDates = UIAUtility.valuesForKey("validationDate", this.argv, this.argv.length);
	
	if (isNaN(delay)) delay = 3;
	if (waitInterval == undefined || isNaN(waitInterval)) {
		if (time) useOriginalTimeForVerification = false;
		waitInterval = delay;
	}

	if (timezone) {
		UIALogger.logMessage("Setting time zone to: " + timezone);
		settings.launchIfNotActive();
		settings.setTimeZone(timezone);
	}

	if (systemDate) {
		UIALogger.logMessage("Setting system date to: " + systemDate);
		settings.setDateAndTime(UIADate.dateWithDateString(systemDate));
	}
		
	clock.getToClockView();
	clock.tabBar().buttons()["Alarm"].tap();
	UIATarget.localTarget().delay(1);

	var hours, minutes;
	if (time) {
		var timeArray = time.split(':');
		hours = timeArray[0];
		minutes = timeArray[1];
		alarmDate = {hours:parseInt(timeArray[0],10), minutes:parseInt(timeArray[1],10)};
	} else {
		// calulate the hour and minutes to set the alarm for in order to get it to go off in <delay> minutes
		var now = new UIADate();
		now.setWithOptions({minutes:"+"+delay});
		minutes = now.getMinutes();
		hours = now.getHours();
		alarmDate = {hours:hours, minutes:minutes};
	}
	if (minutes < 10) minutes = "0" + parseInt(minutes, 10);
	time = hours + ":" + minutes;
	UIALogger.logDebug("alarm time: hours " + alarmDate.hours + " and minutes " + alarmDate.minutes);
	
	if (!label) label = time;
	var alarmCells = clock.mainWindow().images()[0].tableViews()[0].cells().withPredicate("name contains '" + label.replace("'", "\\'") + "'");
	var maxRemovals = alarmCells.length;
	UIALogger.logMessage("Found " + maxRemovals + " alarms with label " + label);
	
	//remove all the dup alarms
	for (var i=0; i<maxRemovals; i++) {
		UIALogger.logMessage("Removing alarm " + (i+1));
		clock.deleteAlarm(label);
	}
	
	clock.navigationBar().buttons()["Add"].tap();
	if (!clock.navigationBar().withName("Add Alarm").isValid()) {
		this.testError = "Tapped 'Add' button but the 'Add Alarm' nav bar did not show up";
		UIALogger.logError(this.testError);
		return this.testResult = 0;
	}
	UIATarget.localTarget().delay(1);
	clock.setAlarm(time, null, repeat, sound, snooze, label);
	UIATarget.localTarget().delay(1);
	
	//verify we added the alarm
	if (label) {
		var alarmCell = clock.mainWindow().images()[0].tableViews()[0].cells().firstWithPredicate("name contains '" + label.replace("'", "\\'") + "'");
		if (!alarmCell.isValid()) { 
			this.testError = "Could not find the added alarm in the list";
			UIALogger.logError(this.testError);
			return this.testResult = 0;
		}
	}
	
	//do the alarm handling stuff...
	if (useOriginalTimeForVerification) {
		UIALogger.logDebug("Validating the original time");
	} else {
		UIALogger.logDebug("Not validating the original time");
	}
	
	var dateToValidate;
	var validated = false;
	this.testResult = 1;
	do {
		var expectedAlarmDate = new Object();
		expectedAlarmDate.hours = alarmDate.hours;
		expectedAlarmDate.minutes = alarmDate.minutes;
		
		if (dateToValidate) {
			waitInterval = 2 //bring down the wait interval
			timeArray = dateToValidate.split(':');
			systemDateOptions = {year:timeArray[0], month:timeArray[1], date:timeArray[2]};
			if (timeArray.length > 3) {
				systemDateOptions.hours = timeArray[3];
				systemDateOptions.minutes = timeArray[4];
				expectedAlarmDate.hours = timeArray[3];
				expectedAlarmDate.minutes = timeArray[4];
			} else {
				systemDateOptions.hours = alarmDate.hours;
				systemDateOptions.minutes = alarmDate.minutes;
			}
			systemDate = (new UIADate());
			systemDate.setWithOptions(systemDateOptions);
			systemDate.setWithOptions({minutes:"-"+waitInterval});
			UIALogger.logDebug("System date being set to " + systemDate.toString());
			settings.setDateAndTime(systemDate);
		}
		
		if (dateToValidate || useOriginalTimeForVerification) {
			validated = true;
			var alarmActivated = false;
			UIATarget.localTarget().clickMenu();
			var date = new UIADate();
			UIALogger.logMessage("Waiting for " + waitInterval*60 + " seconds for the alarm...");
			for (var i=0; i<waitInterval*60; i=i+5) {
				var lastAlert = springboard.alertSinceDate(date);
				if (lastAlert && lastAlert.alertMessageArray[0] == label) {
					lastAlert.uiaDate = new UIADate();
					lastAlert.uiaDate.setTime(lastAlert.date.getTime());
					
					//check the alert fired off at the correct time
					UIALogger.logMessage("Alarm got activated as expected. Checking if it activated at the correct time...");
					if (lastAlert.uiaDate.getHours() == parseInt(expectedAlarmDate.hours, 10) &&
						lastAlert.uiaDate.getMinutes() == parseInt(expectedAlarmDate.minutes, 10)) {
						alarmActivated = true;
						springboard.lastAlert = null; //reseting the lastAlert. Should really do something better...
						break;
					} else {
						UIALogger.logError("Alarm did not activate at the correct time");
						UIALogger.logDebug("Alarm fire off time: " + lastAlert.uiaDate);
						UIALogger.logDebug("Alarm expected time: hours:" +  expectedAlarmDate.hours + " minutes: " + expectedAlarmDate.minutes);
					}
				}
				UIATarget.localTarget().delay(5);
			}
			if (!alarmActivated) {
				var expectedAlarmDateString = "hours:" +  expectedAlarmDate.hours + " minutes: " + expectedAlarmDate.minutes;
				var errorString = "Alarm did not get activated for " + expectedAlarmDateString;
				this.testError = (!this.testError) ? errorString : this.testError + ", " + expectedAlarmDateString;
				UIALogger.logError(errorString);
				this.testResult = 0;
			}
		}
		if (validationDates) dateToValidate = validationDates.shift();
	} while (dateToValidate);
	
	if (this.testResult && !validated) {
		this.testResult = 0;
		this.testError = "Did not validate that the alarm got activated";
	}
	clock.getToClockView();
	if (label) clock.deleteAlarm(label);
	return this.testResult;
}

// --------------------------------------------------------------------------------
//	Function: clockTest_removeAlarm 
//		Removes an alarm
//
//	Parameters: 
//		label (string) - the label of the alarm that needs to be removed.  
//
//	Returns: 
//		1 if test passes, 0 or 64 if test fails. 
// --------------------------------------------------------------------------------
function clockTest_removeAlarm() {
	var label;
	
	if (this.argv.length > 0) label = this.argv[0];

	clock.getToClockView();
	clock.tabBar().buttons()["Alarm"].tap();
	var dupCount = clock.mainWindow().images()[0].tableViews()[0].cells().withPredicate("name contains '" + label + "'").length;
	UIALogger.logMessage(dupCount + " alarm with '" + label + "'");
	
	clock.deleteAlarm(label);
	
	//verify
	var updatedDupCount = clock.mainWindow().images()[0].tableViews()[0].cells().withPredicate("name contains '" + label + "'").length;
	if (updatedDupCount != (dupCount-1)) {
		this.testError = "Unexpected number of alarms found after deleting: " + updatedDupCount;
		UIALogger.logError(this.testError);
		return this.testResult = 0;
	}
	
	return this.testResult = 1;
}

// --------------------------------------------------------------------------------
//	Function: clockTest_removeAllAlarms
//		Removes all the alarms
//
//	Parameters: 
//		None
//
//	Returns: 
//		1 if test passes, 0 or 64 if test fails. 
// --------------------------------------------------------------------------------
function clockTest_removeAllAlarms() {

	clock.getToClockView();
	clock.tabBar().buttons()["Alarm"].tap();
	clock.deleteAllAlarms();
	
	//verify
	var clockTable = clock.mainWindow().images()[0].tableViews()[0];
	if (!clockTable.withName("No Alarms").isValid()) UIALogger.logWarning("'No Alarms' did not come up");
	
	var alarmCount = clock.mainWindow().images()[0].tableViews()[0].cells().length;
	if (alarmCount != 0) {
		this.testError = "Unexpected number of alarms found after deleting: " + alarmCount;
		UIALogger.logError(this.testError);
		return this.testResult = 0;
	}
	
	return this.testResult = 1;
}

// --------------------------------------------------------------------------------
//	Function: clockTest_addMultipleAlarms
//		Deletes all existing alarms and creates new randomly-configured alarms
//
//	Parameters: 
//		count (string) - optional - number of alarms to create
//
//	Returns: 
//		1 if test passes, 0 or 64 if test fails. 
// --------------------------------------------------------------------------------
function clockTest_addMultipleAlarms() {
    var count = 4;
    if (this.argv != null) {
        if (this.argv.length > 0) count = parseInt(this.argv[0]);
    }
    UIALogger.logMessage("count: " + count);
	
	clock.getToClockView();
	clock.tabBar().buttons()["Alarm"].tap();

    if (clock.invalidAlarmsDetected()) {
        this.testError = "Invalid Alarms Detected";
        UIALogger.logError(this.testError);

        var log = clock.invalidAlarmsLog();
        for (var key in log) {
            UIALogger.logError(log[key]);
        }
            
        UIALogger.logError(this.testError);
        return this.testResult = 0;
    }
    
    clock.deleteAllAlarms();

    UIALogger.logMessage("Creating " + count + " new alarms.");
    var timestamp = new Date();
    for (var ctr = 0; ctr < count; ctr++) {
		var alarmSettings = clock.getRandomAlarmSettings();
		var label = "Alarm " + timestamp.getTime() + " + " + (ctr + 1);
		var argArray = ["time:"+alarmSettings.time, "snooze:"+alarmSettings.snooze, "sound:"+alarmSettings.sound, "label:"+label];
		for (var i=0; i<alarmSettings.repeat.length;i++)
			argArray.push("repeat:"+alarmSettings.repeat[i]);
		var subTest = phtCreateTest("AddAlarm", argArray, clockTest_addAlarm, "Add random alarm.");
		var result = subTest.execute();
		if (subTest.testError) {
			this.testError = subTest.testError;
			return this.testResult = 0;
		}
    }
	return this.testResult = 1;
}

// --------------------------------------------------------------------------------
//	Function: clockTest_editAllAlarms
//		Reconfigures all alarms randomly
//
//	Parameters: 
//		None
//
//	Returns: 
//		1 if test passes, 0 or 64 if test fails. 
// --------------------------------------------------------------------------------
function clockTest_editAllAlarms() {
	
	clock.getToClockView();
	clock.tabBar().buttons()["Alarm"].tap();
	
    if (clock.invalidAlarmsDetected()) {
        this.testError = "Invalid Alarms Detected";
        UIALogger.logError(this.testError);
        
        var log = clock.invalidAlarmsLog();
        for (var key in log) {
            UIALogger.logError(log[key]);
        }
        
        UIALogger.logError(this.testError);
        return this.testResult = 0;
    }
    
    var alarmTable = clock.mainWindow().images()[0].tableViews()[0];
    var numOfAlarms = alarmTable.cells().length;
    
    UIALogger.logMessage("There are " + numOfAlarms + " alarms");
 

	if (numOfAlarms > 0) {
		var cellNames = new Array();
		for (var ctr = 0; ctr < numOfAlarms; ctr++) {
			cellNames.push(alarmTable.cells()[ctr].name());
		}
		
		for (var key in cellNames) {
			clock.navigationBar().buttons()["Edit"].tap();
			UIATarget.localTarget().delay(1);
			
			UIALogger.logMessage("Editing alarm: " + cellNames[key]);
			var labelElement = alarmTable.cells().firstWithPredicate("name contains '" + cellNames[key] + "'");
			if (!labelElement.isValid()) {
				throw new Error("Did not find an alarm label");
			}
			labelElement.tap();
			UIATarget.localTarget().delay(1); //account for the animation delay
			var alarmSettings = clock.getRandomAlarmSettings();
            clock.setAlarm(alarmSettings.time, clock.repeatChoices, alarmSettings.repeat, alarmSettings.sound, alarmSettings.snooze, null);
			if (!clock.navigationBar().withName("Alarm").isValid()) UIALogger.logWarning("Tapped 'Save' but the Alarms view did not come up");
			UIATarget.localTarget().delay(1);
		}
    }
	
	return this.testResult = 1;
}

// --------------------------------------------------------------------------------
//	Function: clockTest_createAndEditAlarms 
//		Creates and edits alarms with random configurations
//
//	Parameters: 
//		alarmsCount (string) - optional - number of alarms to create
//		iterationsCount (string) - optional - number of times to edit each alarm
//
//	Returns: 
//		1 if test passes, 0 or 64 if test fails. 
// --------------------------------------------------------------------------------
function clockTest_createAndEditAlarms() {
 
    var alarmsCount = 3;
    var iterationsCount = 2;
    if (this.argv != null) {
        if (this.argv.length > 0) alarmsCount = parseInt(this.argv[0]);
        if (this.argv.length > 1) iterationsCount = parseInt(this.argv[1]);
    }
    UIALogger.logMessage("alarmsCount: " + alarmsCount);
    UIALogger.logMessage("iterationsCount: " + iterationsCount);
    
	var subTest = phtCreateTest("AddMultipleAlarms", [alarmsCount], clockTest_addMultipleAlarms, "Add multiple alarms.");
	var result = subTest.execute();
	if (subTest.testError) {
		this.testError = subTest.testError;
		return this.testResult = 0;
	}
	
    for (var ctr = 0; ctr < iterationsCount; ctr++) {
        // bring springboard up
        springboard.getToSpringBoard();
        
		subTest = phtCreateTest("EditAllAlarms", null, clockTest_editAllAlarms, "Edit all alarms.");
		result = subTest.execute();
		if (subTest.testError) {
			this.testError = subTest.testError;
			return this.testResult = 0;
		}
    }
    
	return this.testResult = 1;
}

// --------------------------------------------------------------------------------
//	Function: clockTest_startStopwatch
//		Starts the stopwatch and checks if the time is increasing
//		(If stopwatch is already running, it stops the stopwatch and then a start)
//
//	Parameters:
//		None
//
//	Returns: 
//		1 if test passes, 0 or 64 if test fails. 
// --------------------------------------------------------------------------------
function clockTest_startStopwatch() {
	
	clock.getToClockView();
	clock.tabBar().buttons()["Stopwatch"].tap();
	
	// Checking if the Stopwatch is at 00:00.0/paused or running		
	if(clock.isStopwatchRunning()){ 
		UIALogger.logMessage("The stopwatch is already running so STOP it");			   
		clock.stopStopwatch();	// Stopping the Stopwatch
	}
	
	UIALogger.logMessage("The Stopwatch is PAUSED/00:00.0 so START it");
	clock.mainWindow().buttons()["Start"].tap();  
	
	UIALogger.logMessage("The Stopwatch is running");   
	if (clock.isStopwatchRunning()){
		UIALogger.logMessage("Validated that Stopwatch is running since Time2 > Time1");
		return this.testResult = 1;
	} else {
		this.testError = "Unable to validate that Stopwatch is running";
		UIALogger.logError(this.testError);
		return this.testResult = 0;
	}
}


// --------------------------------------------------------------------------------
//	Function: clockTest_stopStopwatch 
//		STOPS the stopwatch.  It starts the stopwatch if it isn't already running and then STOPS it
//
//	Parameters:
//		None
//
//	Returns: 
//		1 if test passes, 0 or 64 if test fails. 
// --------------------------------------------------------------------------------
function clockTest_stopStopwatch() {
	clock.getToClockView();
	clock.tabBar().buttons()["Stopwatch"].tap();
	
	// Checking if the Stopwatch is at 00:00.0/paused or running		
	if (!clock.isStopwatchRunning()) { 
		UIALogger.logMessage("The Stopwatch is PAUSED/00:00.0 so first START and then STOP");
		clock.mainWindow().buttons()["Start"].tap();  
		UIATarget.localTarget().delay(1);
		if (!clock.isStopwatchRunning()){  //Validating if the stopwatch is running
			this.testError = "Failed to start the Stopwatch";
			UIALogger.logError(this.testError);
			return this.testResult = 0;
		}		
	}
	
	UIALogger.logMessage("The stopwatch is now running so STOP it");			   
	clock.stopStopwatch();	// Stopping the Stopwatch
	if (!clock.isStopwatchRunning()){  //Validating if the stopwatch is not running
		UIALogger.logMessage("Validated that Stopwatch is STOPPED since Time2 = Time1");
		return this.testResult = 1;
	} else {
		this.testError = "Unable to validate that Stopwatch has stopped";
		UIALogger.logError(this.testError);
		return this.testResult = 0;
	}		
}


// --------------------------------------------------------------------------------
//	Function: clockTest_resetStopwatch
//		RESET the stopwatch.  Starts the stopwatch if it is already at 00:00.0/running and RESETs it
//	
//	Parameters:
//		None
//
//  Returns: 
//		1 if test passes, 0 or 64 if test fails. 
// --------------------------------------------------------------------------------

function clockTest_resetStopwatch() {

	clock.getToClockView();
	clock.tabBar().buttons()["Stopwatch"].tap();
	
	// Checking if the Stopwatch is at 00:00.0/paused or running
	if (!clock.isStopwatchRunning()) {
		UIALogger.logMessage("The Stopwatch is at 00:00.0/PAUSED so first START it");
		clock.mainWindow().buttons()["Start"].tap();
	}
	
	UIALogger.logMessage("The stopwatch is already running so STOP and RESET it");			   
	clock.stopStopwatch();	// Stopping the Stopwatch 
	UIATarget.localTarget().delay(1);
	clock.mainWindow().buttons()["Reset"].tap();
	
	if (clock.isclockReset()){  //Validating if the stopwatch is RESET
		UIALogger.logMessage("Validated that the Stopwatch is RESET");
		return this.testResult = 1;
	} else {
		this.testError = "Unable to validate that Stopwatch has been RESET";
		UIALogger.logError(this.testError);
		return this.testResult = 0;
	}
}


// --------------------------------------------------------------------------------
//	Function: clockTest_getStopwatchLaptime 
//		Get all lap times on stopwatch.  Gets each laptime and verifies the total time
//  
//	Parameters:
//		None
//
//  Returns: 
//		1 if test passes, 0 or 64 if test fails. 
// --------------------------------------------------------------------------------

function clockTest_getStopwatchLaptime(){

	var sum = 0;
	var lapTime = 0;
	var numberOfLaps = 3;
	
	clock.getToClockView();
	clock.tabBar().buttons()["Stopwatch"].tap();
	
	if (clock.isStopwatchRunning()) clock.mainWindow().buttons()["Stop"].tap();
	if (!clock.isclockReset()) clock.mainWindow().buttons()["Reset"].tap();
	
	// Checking if the Stopwatch is at 00:00.0/paused or running		
	if(!clock.isStopwatchRunning()){
		sum = clock.getLapTime();
		UIALogger.logMessage("The Stopwatch is at 00:00.0/PAUSED so first START it");
		clock.mainWindow().buttons()["Start"].tap();
	}
	
	var error = 0.2; //some precision error
	for (var i=0; i < numberOfLaps; i++) { 
		UIATarget.localTarget().delay(2);
		var start = new Date().getTime();
		lapTime = clock.getLapTime();
		clock.mainWindow().buttons()["Lap"].tap();
		UIATarget.localTarget().delay(0.5); //minimize error for how long the app takes to respond to the tap, etc.
		var stop = new Date().getTime();
		error += (stop - start)/1000.0;
		sum = sum + lapTime;
	} 
	
	clock.mainWindow().buttons()["Stop"].tap();
	
	UIALogger.logMessage("Sum of the lap times in seconds is " + sum);
	var strcurrentTime = clock.getStopwatchTime();
	var currentTime = strcurrentTime;
	UIALogger.logMessage("Current Stopwatch time in seconds is " + currentTime);
	UIALogger.logMessage("Margin of error allowed is " + error);
	// error is the maximum amount of time that the uiElement and tapUIElement functions could be contributing
	if (currentTime - sum < error){
		UIALogger.logMessage("Validated Stopwatch Lap Function");
		return this.testResult = 1;
	} else {
		this.testError = "Unable to validate that Stopwatch Lap Function";
		UIALogger.logError(this.testError);
		return this.testResult = 0;
	}		
}

// Create self tests -- this is an unnamed function, just to make sure any local variables stay in the correct context
(function() {	
	if (typeof clock.selfTests == 'undefined') {
		clock.selfTests = new Array();
	}
	if ((typeof clock != 'undefined') && springboard.displaysApp(clock)) {
		var alarm = "Robot";
	
		// world clock
		clock.selfTests.push(phtCreateTest("AddWorldClock", ["Indianapolis", "Indianapolis"], clockTest_addWorldClock, "Add world clock for Indianapolis"));
		clock.selfTests.push(phtCreateTest("RemoveWorldClock", ["Indianapolis"], clockTest_removeWorldClock, "Remove world clock for Indianapolis"));
	
		// alarm
		clock.selfTests.push(phtCreateTest("AddAlarm", ["repeat:Every Friday", "sound:"+alarm, "snooze:1", "label:Self Test Alarm"], clockTest_addAlarm, "Add a new alarm"));
		clock.selfTests.push(phtCreateTest("RemoveAlarm", ["Self Test Alarm"], clockTest_removeAlarm, "Remove an existing alarm"));
		clock.selfTests.push(phtCreateTest("AddAndWaitForAlarm", ["delay:"+3, "sound:"+alarm, "snooze:0", "label:Self Test Alarm 2"], clockTest_addAndWaitForAlarm, "Add a new alarm and wait for it to go off"));
		clock.selfTests.push(phtCreateTest("CreateAndEditAlarms", [], clockTest_createAndEditAlarms, "Create random alarms and edit them"));
		clock.selfTests.push(phtCreateTest("RemoveAllAlarms", null, clockTest_removeAllAlarms, "Removes all existing alarms"));
	
		// stopwatch
		clock.selfTests.push(phtCreateTest("StartStopwatch", [], clockTest_startStopwatch, "Start the stopwatch."));
		clock.selfTests.push(phtCreateTest("StopStopwatch", [], clockTest_stopStopwatch, "Stop the stopwatch."));
		clock.selfTests.push(phtCreateTest("ResetStopwatch", [], clockTest_resetStopwatch, "Reset the stopwatch."));
		clock.selfTests.push(phtCreateTest("GetStopwatchLaptime", [], clockTest_getStopwatchLaptime, "Check the stopwatch laptime."));
	}
	
	// timer
}())