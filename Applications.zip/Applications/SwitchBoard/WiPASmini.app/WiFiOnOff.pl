#!/usr/bin/perl

if ((0 <= $#ARGV) && ($ARGV[0] eq "ON"))
{
	$onoffflag = "1";
	$state = "ON";
}
else
{
	$onoffflag = "0";
	$state = "OFF";
}

$cmd = "/usr/local/bin/mobilewifitool -- device power -i en0 " . $onoffflag . " |";
printf ("$cmd\n");
system ("/bin/launchctl load /System/Library/LaunchDaemons/com.apple.wifid.plist");
$success = 0;
for ($n = 0; ($n < 100) && !$success; $n++)
{
	system ("/bin/sleep 0.5");
	open (PS, $cmd);
	while (<PS>)
	{
		$line = $_;
		printf ("> %s", $line);
		if ($line =~ /$state/)
		{
			$success = 1;
			last;
		}
	}
	close (PS);
}
if ($success)
{
	exit (0);
}
else
{
	exit (-1);
}
