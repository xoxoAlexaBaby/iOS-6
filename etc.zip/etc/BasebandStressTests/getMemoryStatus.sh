#!/bin/sh

count=0
mysleep=18000
myDate=`perl -e '($s,$m,$H,$d,$M) = localtime(); $Y += 1900; $M++; printf ("%02d%02d",$M,$d); ' `
myDir="/var/root/MemoryDumps_$myDate/"
mkdir $myDir

while(true);
do
	((count++))
	sleep $mysleep

	echo "***** Iteration $count -- Dumping Virtual Memory Status"
	#echo "vmmap -resident SpringBoard > $myDir/vmmap_$count.txt"
	#vmmap -resident SpringBoard > $myDir/vmmap_$count.txt
	#sleep 2
	
	#echo "heap -guessNonObjects SpringBoard > $myDir/heapSpringBoard_$count.txt"
	#heap SpringBoard > $myDir/heapSpringBoard_$count.txt
	#sleep 2
	
	echo "\n\nheap -showSizes CommCenter" > $myDir/heapCommCenter_$count.txt
	heap -showSizes CommCenter > $myDir/heapCommCenter_$count.txt
	sleep 2

	echo "\n\n\nleaks CommCenter" > $myDir/leaksCommCenter_$count.txt
	leaks CommCenter > $myDir/leaksCommCenter_$count.txt
	sleep 2

	echo "\n\n\vmmap -resident -dirty CommCenter" > $myDir/vmmapCommCenter_$count.txt
	vmmap -resident -dirty CommCenter > $myDir/vmmapCommCenter_$count.txt
	sleep 2

	#echo "heap MobilePhone  > $myDir/heapMobilePhone_$count.txt"
	#heap MobilePhone  > $myDir/heapMobilePhone_$count.txt
	#echo "Done Collecting... Waiting for $mysleep seconds.\n"
	
	if [ $(($count % 10)) -eq 0 ]; then  break; fi
	
done

echo "*************  DONE COLLECTING MEMORY DUMPS - $count ******************\n"