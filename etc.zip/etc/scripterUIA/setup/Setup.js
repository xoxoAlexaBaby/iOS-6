#import "../libs/SpringBoard.js"
//#import "../libs/UIAApp.js"

setup = UIAApp.application("Setup", "com.apple.purplebuddy");

if (typeof setup != 'undefined') { 
	
	setup.alertHandler = function alertHandler(alert) {
		if (alert.name() == "Disable Location Services?") {
			UIALogger.logMessage("Got the 'Disable Location Services' alert -- tapping 'Disable' button");
			try {
			    alert.buttons()["Disable"].tap();
			}
			catch (e) {
			    UIALogger.logMessage("'Disable' button doesn't exist.  Tapping 'OK'.");
			    alert.buttons()["OK"].tap();
			}
			return 1;
		}
		if (alert.name() == "Continue without Wi-Fi?") {
    		UIALogger.logMessage("Got the 'Continue without Wi-Fi' alert -- tapping 'Continue' button");
    		alert.buttons()["Continue"].tap();
    		return 1;
    	}
    	if (alert.name() == "Terms and Conditions") {
    		UIALogger.logMessage("Got the 'Terms and Conditions' alert -- tapping 'Agree' button");
    		alert.buttons()["Agree"].tap();
    		return 1;
    	}
    	if (alert.name() == "Are you sure?") {
    		UIALogger.logMessage("Got the 'Are you sure you want to skip setting up an Apple ID' alert -- tapping 'Skip' button");
    		alert.buttons()["Skip"].tap();
    		return 1;
    	}
    	if (alert.name() == "Restore from iPad Backup") {
    		UIALogger.logMessage("Got the 'Restore from iPad Backup' alert -- tapping 'OK' button");
    		alert.buttons()["OK"].tap();
    		return 1;
    	}
	}
	
	//	----------------------------------------------------------------------------------------------------------------------
	//	Function: unlockScreenForSetup 
	//		Tries to run unlockScreenIfNecessary several times before giving up.  This is a workaround for 
	//          <rdar://problem/9671446> Automation Stuck with "Could not go to spring board"
	//      This bug hits setup pretty hard, because 'AutoLock' cannot be set to 'Never' via the UI until we're out of the buddy.
	//
	//	Parameters:
	//      none
	//
	//	Returns: 
	//		If the next button can't be tapped, this throws an error.
	//	----------------------------------------------------------------------------------------------------------------------
	setup.unlockScreenForSetup = function unlockScreenForSetup() {
	    try {
	        UIATarget.localTarget().unlockScreenIfNecessary();
	    }
	    catch (e) {
	        UIALogger.logMessage("Caught Error: " + e.message);
	        UIALogger.logMessage("Will wait a few seconds and then try to unlock screen again.");
	        UIATarget.localTarget().delay(2);
	        UIATarget.localTarget().unlockScreenIfNecessary();
	    }
	}
	
	//	----------------------------------------------------------------------------------------------------------------------
	//	Function: tapRightButton 
	//		Taps the 'Next' button, but checks to make sure it's valid first.
	//
	//	Parameters:
	//      name (string) = expected name that that button should have.
	//
	//	Returns: 
	//		If the next button can't be tapped, this throws an error.
	//	----------------------------------------------------------------------------------------------------------------------
	setup.tapRightButton = function tapRightButton(timeout) {
	    if (!timeout) timeout = 30;
	    UIATarget.localTarget().pushTimeout(timeout);
	    var rightButton = this.mainWindow().navigationBar().rightButton().withValueForKey(1, "isEnabled");
	    UIATarget.localTarget().popTimeout();
		if (rightButton.isValid() && rightButton.isVisible()) {
		    UIALogger.logMessage("Tapping right button with name '" + rightButton.name() + "'");
		    rightButton.tap();
		}
		else {
		    throw new Error("Could not tap right button");
		}
		
	}
	
	//	----------------------------------------------------------------------------------------------------------------------
	//	Function: getBuddyTableView
	//		returns the 'buddyContainView' tableView
	//
	//	Parameters:
	//      none
	//
	//	Returns: 
	//		If the next button can't be tapped, this throws an error.
	//	----------------------------------------------------------------------------------------------------------------------
	setup.getBuddyTableView = function getBuddyTableView() {
	    return this.mainWindow().elements()["BuddyContainerView"].tableViews()[0];
		
	}
	
	//	----------------------------------------------------------------------------------------------------------------------
	//	Function: waitForNextPage 
	//		Waits to be on a page besides the current page that we're on.
	//
	//	Parameters:
	//      currentPage (string) = current page that we're on.  
	//      timeout (int) = max number of seconds to wait--default is 30.
	//
	//	Returns: 
	//		Returns 1 if we are on a new page, 0 if not.
	//	----------------------------------------------------------------------------------------------------------------------
	setup.waitForNextPage = function waitForNextPage(currentPage, timeout) {
	    if (!currentPage) {
	        UIALogger.logError("No current page given.  Returning.");
	        return 0;
	    }
	    
	    if (!timeout) timeout = 30;
	    
	    for (var i=0; i<timeout; i++) {
	        var nextPage = setup.getCurrentPage();
	        if (nextPage != currentPage) {
	            UIALogger.logDebug("New page found: " + nextPage);
	            return 1;
	        }
	        UIATarget.localTarget().delay(1);
	    }
	    UIALogger.logMessage("Still on page: " + currentPage);
	    return 0;
	}
	
	//	----------------------------------------------------------------------------------------------------------------------
	//	Function: waitForPage 
	//		Waits to be on the page specified.
	//
	//	Parameters:
	//      page (string) = page we're waiting for.
	//      timeout (int) = max number of seconds to wait--default is 5.
	//
	//	Returns: 
	//		Returns 1 if the page we're waiting for comes up, 0 if not.
	//	----------------------------------------------------------------------------------------------------------------------
	setup.waitForPage = function waitForPage(page, timeout) {
	    if (!page) {
	        UIALogger.logError("No page to wait for given.  Returning.");
	        return 0;
	    }
	    
	    if (!timeout) timeout = 5;
	    
	    for (var i=0; i<timeout; i++) {
	        var currentPage = setup.getCurrentPage();
	        if (currentPage == page) {
	            UIALogger.logDebug("Page successfully found: " + page);
	            return 1;
	        }
	        UIATarget.localTarget().delay(1);
	    }
	    return 0;
	}
	
	//	----------------------------------------------------------------------------------------------------------------------
	//	Function: getCurrentPage 
	//		Returns a string indicating which Buddy page we're currently on.
	//
	//	Parameters:
	//      none
	//
	//	Returns: 
	//		Throws an error if we're not in buddy--otherwise, returns a string.
	//	----------------------------------------------------------------------------------------------------------------------
	setup.getCurrentPage = function getCurrentPage() {
	    this.unlockScreenForSetup();

        // try several times to get the current page--there could be timing issues with alerts still being on screen before they're dismissed.
	    for (var i=0; i<3; i++) {
	        UIATarget.localTarget().pushTimeout(0);
	        var currentPage = "";
	        var navBar = this.mainWindow().navigationBar();
    	    if (this.mainWindow().elements()["A panning display of the word 'Welcome' in many languages."].isValid()) {
    	        currentPage = "language";
    	    }
    	    else if (this.mainWindow().elements()["BuddyContainerView"].elements()["A panning display of the word 'Welcome' in many languages."].isValid()) {
    	        currentPage = "language";
    	    }
    	    else if (navBar.staticTexts()["Country or Region"].isValid()) {
    	        currentPage = "country";
    	    }
    	    else if (navBar.staticTexts()["Location Services"].isValid()) {
    	        currentPage = "locationservices";
    	    }
    	    else if (navBar.staticTexts()["Wi-Fi Networks"].isValid()) {
    	        currentPage = "wifi";
    	    }
    	    else if (navBar.staticTexts().firstWithPredicate("name beginswith 'Set Up i'").isValid())  {
    	        currentPage = "setupdevice";
    	    }
    	    else if (navBar.staticTexts().firstWithPredicate("name beginswith 'Diagnostics'").isValid())  {
    	        currentPage = "diagnostics";
    	    }
    	    else if (navBar.staticTexts().firstWithPredicate("name beginswith 'Could Not Activate'").isValid()) {
    	        currentPage = "noactivate";
    	    }
    	    else if (navBar.staticTexts().firstWithPredicate("name beginswith 'Activating your'").isValid()) {
        	    currentPage = "activating";
        	}
        	else if (navBar.staticTexts()["iCloud Sign In"].isValid()) {
    	        currentPage = "icloudsignin";
    	    }
        	else if (navBar.staticTexts()["Apple ID"].isValid()) {
    	        currentPage = "appleid";
    	    }
    	    else if (navBar.staticTexts()["Signing In…"].isValid()) {
    	        currentPage = "appleidsignin";
    	    }
    	    else if (navBar.staticTexts()["Terms and Conditions"].isValid()) {
    	        currentPage = "termsandconditions";
    	    }
    	    else if (navBar.staticTexts()["Choose Backup"].isValid()) {
    	        currentPage = "choosebackup";
    	    }
    	    else if (navBar.staticTexts()["Restoring from Backup"].isValid()) {
    	        currentPage = "restoringfrombackup";
    	    }
    	    else if (navBar.staticTexts()["Set Up MobileMe"].isValid()) {
    	        currentPage = "setupmobileme";
    	    }
    	    else if (navBar.staticTexts().firstWithPredicate("name beginswith 'Find My'").isValid()) {
    	        currentPage = "findmydevice";
    	    }
    	    else if (navBar.staticTexts()["Siri"].isValid()) {
    	        currentPage = "siri";
    	    }
    	    else if (navBar.staticTexts()["Thank You"].isValid()) {
    	        currentPage = "thankyou";
    	    }
    	    else if (navBar.staticTexts()["Connect to iTunes"].isValid()) {
    	        currentPage = "itunes";
    	    }
    	    else if (navBar.staticTexts().firstWithPredicate("name beginswith 'Enter Password'").isValid()) {
        	    currentPage = "enterpassword";
        	}
    	    UIATarget.localTarget().popTimeout();
 
    	    if (currentPage != "") {
    	        //UIALogger.logDebug("Current Page is '" + currentPage + "'");
        	    return currentPage;
    	    }
    	    UIATarget.localTarget().delay(1);  
    	}
    	
        UIATarget.localTarget().logElementTree();
        throw new Error("Could not determine current page!");
	}
    
    //	----------------------------------------------------------------------------------------------------------------------
	//	Function: chooseLanguage 
	//		Returns the UIAElement for the number field in the keypad view
	//
	//	Parameters:
	//		language (string) - language to choose.  If not specified, it chooses English.
	//
	//	Returns: 
	//		Throws an error if there's a problem.
	//	----------------------------------------------------------------------------------------------------------------------
	setup.chooseLanguage = function chooseLanguage(language) {
	    
	    this.unlockScreenForSetup()
	    
	    if (this.getCurrentPage() != "language") {
	        throw new Error("Not on choose language page.");
	    }
	    
	    if (!language) language = "English";
	    
	    var theLanguageCell = this.mainWindow().tableViews()[0].cells()[language];
	    if (theLanguageCell.isValid()) {
	        UIALogger.logMessage("Tapping '" + theLanguageCell.name() + "'");
	        theLanguageCell.tap();
	    }
	    else {
	        // Chosen language isn't one of the main ones to display--have to hit the "more languages button"
	        UIALogger.logMessage("Tapping the 'More languages' button.");
	        
	        try {
	            this.mainWindow().tableViews()[0].cells()['More languages'].tap();
	        }
	        catch(e) {
	            throw new Error("Could not tap the 'More languages' button");
	        }
	        theLanguageCell = this.mainWindow().tableViews()[0].cells()[language];
    	    if (theLanguageCell.isValid()) {
    	        UIALogger.logMessage("Tapping '" + theLanguageCell.name() + "'");
    	        theLanguageCell.tap();
    	    }
    	    else {
    	        throw new Error("Could not find language '" + language + "'");
    	    }      
	    }
	    
	    // tap the 'Next' button to go to the next page.
	    this.tapRightButton();  
	    this.waitForNextPage("language");
	    
    }
    
    //	----------------------------------------------------------------------------------------------------------------------
	//	Function: chooseCountry 
	//		Returns the UIAElement for the number field in the keypad view
	//
	//	Parameters:
	//		country (string) - country to choose.  If not specified, it chooses United States.
	//
	//	Returns: 
	//		Throws an error if there's a problem.
	//	----------------------------------------------------------------------------------------------------------------------
	setup.chooseCountry = function chooseCountry(country) {
	    
	    this.unlockScreenForSetup()
	    
	    if (this.getCurrentPage() != "country") {
	        throw new Error("Not on Choose Country or Region page.");
	    }
	    
	    if (!country) country = "United States";
	    
	    var theCountryCell = this.getBuddyTableView().cells()[country];
	    if (theCountryCell.isValid()) {
	        UIALogger.logMessage("Tapping '" + theCountryCell.name() + "'");
	        theCountryCell.tap();
	    }
	    else {
	        // Chosen country isn't one of the main ones to display--have to hit the "more languages button"
	        UIALogger.logMessage("Tapping the 'Show More' button.");
	        
	        try {
	            this.getBuddyTableView().cells()["Show More…"].tap();
	        }
	        catch(e) {
	            throw new Error("Could not tap the 'Show More' button");
	        }
	        theCountryCell = this.getBuddyTableView().cells()[country];
    	    if (theCountryCell.isValid()) {
    	        UIALogger.logMessage("Tapping '" + theCountryCell.name() + "'");
    	        theCountryCell.tap();
    	    }
    	    else {
    	        throw new Error("Could not find country '" + country + "'");
    	    }      
	    }
	    
	    // tap the 'Next' button to go to the next page.
	    this.tapRightButton(); 
	    this.waitForNextPage("country");
	    
	}
	
	//	----------------------------------------------------------------------------------------------------------------------
	//	Function: chooseLocationServices 
	//		Returns the UIAElement for the number field in the keypad view
	//
	//	Parameters:
	//      shouldDisableLocationServices (bool) - set to 1 if you want to disable location services.
	//
	//	Returns: 
	//		Throws an error if there's a problem.
	//	----------------------------------------------------------------------------------------------------------------------
	setup.chooseLocationServices = function chooseLocationServices(shouldDisableLocationServices) {
	    this.unlockScreenForSetup()
	    
	    if (this.getCurrentPage() != "locationservices") {
	        throw new Error("Not on choose 'Disable/Enable Location Services' page.");
	    }
	    
	    var allCells = this.getBuddyTableView().cells();
	    var locationCell;
	    if (shouldDisableLocationServices == 1) {
	        locationCell = allCells.firstWithPredicate("name beginswith 'Disable Location'");
	        UIALogger.logMessage("Choosing 'Disable Location Services'");
	    }
	    else {
	        locationCell = allCells.firstWithPredicate("name beginswith 'Enable Location'");
	        UIALogger.logMessage("Choosing 'Enable Location Services'");
	    }
	    
	    if (!locationCell.isValid()) {
	        throw new Error("Could not find the Enable or Disable Location Cell");
	    }
	    locationCell.tap();
	    UIATarget.localTarget().delay(1); // give some time for selection to take place
	    
	    locationCell.checkIsValid();  // get the locationCell again so we can check the value
	    if (locationCell.value() != 1) {
	        throw new Error("Location Services was not Selected as desired.");
	    }
	    
	    this.tapRightButton(); 
	    
	    this.waitForNextPage("locationservices"); // alert may appear -- wait for it to come up so it can be dismissed.
	    
    }
    
    //	----------------------------------------------------------------------------------------------------------------------
	//	Function: setWiFi 
	//		Returns the UIAElement for the number field in the keypad view
	//
	//	Parameters:
	//      network (string) - the network to choose.  If left blank, just tap 'Next' button.
	//      password (string) - the password to use
	//      useCellularNetwork (bool) - choose to use the cellular network instead of wifi.  
	//
	//	Returns: 
	//		Throws an error if there's a problem.
	//	----------------------------------------------------------------------------------------------------------------------
	setup.setWiFi = function setWiFi(network, password, useCellularNetwork) {
	    this.unlockScreenForSetup()
	    var waitForNetworkTimeout = 60;
	    var maxAttempts = 3; 
		    
	    if (this.getCurrentPage() != "wifi") {
	        throw new Error("Not on choose wifi page.");
	    }
	    
	    if ((useCellularNetwork == true) || (useCellularNetwork == "true"))    {
	        var cellConnectionButton = this.mainWindow().tableViews()[0].cells()['Use Cellular Connection'];
	        if (cellConnectionButton.isValid()) {
	            UIALogger.logMessage("Tapping 'Use Cellular Connection' button");
	            cellConnectionButton.tap();
	        }
	        else {
	            throw new Error("Cannot tap Cellular Connection button.");
	        }
	    }
	    else if (network) {
	        for ( var currentAttempt = 0; currentAttempt < maxAttempts; currentAttempt++) {
    			UIALogger.logMessage("Attempting to find '" + network + "', attempt #" + currentAttempt);
    			// Increase Wait for network timeout for each attempt
    			if (currentAttempt > 0) {
    				waitForNetworkTimeout = waitForNetworkTimeout + 5
    			}
    			UIALogger.logMessage("Waiting up to " + waitForNetworkTimeout + " seconds for WiFi to load the networks")	
    			UIATarget.localTarget().pushTimeout(waitForNetworkTimeout);

    			UIALogger.logMessage("Scrolling to network: " + network);
    			var networkCell = setup.mainWindow().tableViews()[0].cells().firstWithPredicate("name contains '" + network + "'");
    			var foundNetwork = 0;
    			UIATarget.localTarget().popTimeout();
    			if (networkCell.isValid()) {
    				UIALogger.logMessage("Choosing wifi network: " + network);
    				networkCell.tap();
    				foundNetwork = 1;
    				
    				// Deal with the password if it's there.
    				if (this.navigationBar().staticTexts().firstWithName("Enter Password").isValid()) {
    				    
    				    // Enter password
    				    if (!password) {
    				        throw new Error("No password was given, 'Enter Password' dialog is up.");
    				    }
    				    this.enterTextInTextField(this.mainWindow().tableViews()[0].cells()["Password"].secureTextFields()["Password"], password);
    				    
    				    // Tap the Join button
    				    UIATarget.localTarget().pushTimeout(15);
    				    var joinButton = this.navigationBar().buttons()["Join"];
    				    UIATarget.localTarget().popTimeout();
                        if (joinButton.isValid() && joinButton.isVisible() && joinButton.isEnabled()) {
                            UIALogger.logMessage("Tapping 'join' button");
                            joinButton.tap();
                        }
                        else {
                            throw new Error("Could not tap join button");
                        }
                        
                        // Check to make sure the password field went away.  May want to check for an alert here, too...
                        UIATarget.localTarget().pushTimeout(10);
                        var passwordFieldInvalid = this.navigationBar().staticTexts().firstWithName('Enter Password').waitForInvalid();
                        UIATarget.localTarget().popTimeout();
                        if (!passwordFieldInvalid) {
                            throw new Error("Entered password, but 'Password' field never went away");
                        }
                        
    				}
    				break;
    				
    			} else {
    				UIALogger.logError("Did not find network '" + network + "' on attempt #" + currentAttempt);
    			}

    			//Add three seconds delay to allow WiFi to scan/update with more networks
    			UIATarget.localTarget().delay(3);

    		}  // end for		

    		if (!foundNetwork) {
    			var networkError = "Could not find the network " + network;
    			this.logElementTree();
    			throw new Error(networkError);
    		}
    		this.waitForNetworkLoadingToFinish();
    	    this.tapRightButton();
    	    this.waitForNetworkLoadingToFinish();
	    }
	    else {
	        UIALogger.logMessage("No wifi network was given, skipping wifi..");
	        try  {this.tapRightButton();}
	        catch (e) {
	            UIALogger.logMessage("Could not tap the right button--will try to hit the 'Connect to iTunes' button instead.");
	            try {
	                this.mainWindow().tableViews()[0].cells()['Connect to iTunes'].tap();
	            }
	            catch (e) {
	                throw new Error("Could not tap 'Next' button and could not find 'Connect to iTunes' button.");
	            }
	        }
	        UIATarget.localTarget().delay(2); // give time for the alert to pop up.	  
	    }	    
	    this.waitForNextPage("wifi");
    }
    
    //	----------------------------------------------------------------------------------------------------------------------
	//	Function: setUpDeviceRestoreRoute 
	//		Chooses between "Set up as new iDevice", "Restore from iCloud Backup", or "Restore from iTunes"
	// 
	//	Parameters:
	//      restoreRoute (string) = "new", "icloud" or "itunes".  If nothing is entered, we set it up as a new device.
	//
	//	Returns: 
	//		Throws an error if there's a problem.
	//	----------------------------------------------------------------------------------------------------------------------
	setup.setUpDeviceRestoreRoute = function setUpDeviceRestoreRoute(restoreRoute) {
	    this.unlockScreenForSetup();
	    if (!restoreRoute) restoreRoute = "new";
	    var elementName = "";
	    
	    if (this.getCurrentPage() != "setupdevice") {
	        throw new Error("Not on 'Setup Device' page.");
	    }
	    
	    if (restoreRoute.toLowerCase() == "icloud") {
	        UIALogger.logMessage("Using an iCloud backup.");
	        elementName = "Restore from iCloud Backup";
	    }
	    else if (restoreRoute.toLowerCase() == "itunes") {
	        UIALogger.logMessage("Using an iTunes backup.");
	        elementName = "Restore from iTunes";
        }
        else {
            UIALogger.logMessage("Not using a backup--setting up as a new device.");
            elementName = "Set Up as New"
        }
        
        var theElement = this.getBuddyTableView().cells().firstWithPredicate("name beginswith '" + elementName + "'");
        if (!theElement.isValid()) {
            throw new Error("Can not find the element beginning with " + elementName);
        }
        UIALogger.logMessage("Tapping '" + theElement.name() + "'");
        theElement.tap();
	    
        this.tapRightButton(10);
	    this.waitForNextPage("setupdevice");
    }
    
    //	----------------------------------------------------------------------------------------------------------------------
	//	Function: activate 
	//		Attempts to activate the phone.
	// 
	//	Parameters:
	//      tries (integer) - Number of times to try to activate the phone before giving up an throwing an error.  Default is 3.
	//
	//	Returns: 
	//		Throws an error if there's a problem.
	//	----------------------------------------------------------------------------------------------------------------------
	setup.activate = function activate(tries) {
	    this.unlockScreenForSetup()
	    if (!tries) tries = 3;
	    
	    var currentPage = this.getCurrentPage();
	    if ((currentPage != "activating") && (currentPage != "noactivate")) {
	        throw new Error("Not on one of the activation pages.");
	    }
	    for (var i=0; i<tries; i++) {
	        if (currentPage == "activating") {
	            UIALogger.logDebug("Attempting to activate phone");
	            this.waitForNextPage("activating", 60);
	        }
	        
	        var currentPage = this.getCurrentPage();
	        if (currentPage == "noactivate") {
	            UIALogger.logDebug("Phone could not activate on try # " + (i+1));
	            var tryAgainButton = this.getBuddyTableView().cells()["Try Again"];
	            if (!tryAgainButton.isValid()) {
	                throw new Error("Could not tap 'Try Again' Button.");
	            }
	            tryAgainButton.tap();
	            this.waitForNetworkLoadingToFinish();
	            this.waitForNextPage("noactivate", 60);
	        }
	        
	        if ((currentPage != "activating") && (currentPage != "noactivate")) {
	            UIALogger.logMessage("No longer on activation pages -- activation must have been successful.");
	            break;
	        }
	    }
	    
	    if ((currentPage == "activating") || (currentPage == "noactivate")) {
	        throw new Error("Could not activate the device after "+ tries + " tries.");
	    }
	    
    }
    
    //	----------------------------------------------------------------------------------------------------------------------
	//	Function: setupiCloud 
	//		Attempts to setup iCloud
	// 
	//	Parameters:
	//      appleID (string) = Apple ID string to use.  If appleID is not given, we use "Skip this step"
	//      password (string) = Apple ID password to use.  Must submit a password, if an apple ID is given.
	//
	//	Returns: 
	//		Throws an error if there's a problem.
	//	----------------------------------------------------------------------------------------------------------------------
	setup.setupiCloud = function setupiCloud(appleID, password) {
	    this.unlockScreenForSetup()
	    
	    var currentPage = this.getCurrentPage();
	    if (currentPage != "icloudsignin")  {
	        throw new Error("Not on the 'Apple ID' page.");
	    }
	    
	    // Enter apple ID.
	    if (appleID) {
	        
	        var textField = this.getBuddyTableView().cells()['Apple ID'].textFields()[0];
	        if (!textField.isValid()) {
	            throw new Error("Could not find text field in which to enter the Apple ID.");
	        }
	        this.enterTextInTextField(textField, appleID);
	        
	        if (!password) { 
	            throw new Error("An appleID was given, but a password was not."); 
	        }
            var passwordField = this.getBuddyTableView().cells()['Password'].secureTextFields()[0];
            if (!passwordField.isValid()) {
	            throw new Error("Could not find text field in which to enter the password for the Apple ID.");
	        }
	        this.enterTextInTextField(passwordField, password);
	        
	        this.tapRightButton(); 
	        this.waitForNetworkLoadingToFinish();
	        if (this.mainWindow().navigationBar().staticTexts()["Terms and Conditions"].isValid()) {
	            UIALogger.logMessage("Terms and Conditations text is on screen--pressing the 'Agree' button.");
	            var agreeButton =  this.mainWindow().toolbars()[0].buttons()["Agree"];
	            if (!agreeButton.isValid()) {
	                throw new Error ("Could not find the 'Agree' button on current page.");
	            }
	            agreeButton.tap();
	            UIATarget.localTarget().delay(2); // give us a bit of time for the 'Terms and Conditions' alert to come up.
	        }
	        else {
	            throw new Error("Terms and Conditions window never came up after entering Apple ID information.");
	        }
	        
	        UIALogger.logMessage("Waiting for Apple ID to be set up.");	        
	        if (!this.waitForNextPage("appleid", 120)) {
	            throw new Error("Never got out of the 'Apple ID' setup page.")
	        }	        
	        
	    }
	    else {
	        throw new Error("iCloud was chosen, but no Apple ID was given to enter.");
	    }
	    	    
    }
    
    //	----------------------------------------------------------------------------------------------------------------------
	//	Function: icloudBackup 
	//		Chooses between "Set up as new iDevice", "Restore from iCloud Backup", or "Restore from iTunes"
	// 
	//	Parameters:
	//      restoreRoute (string) = "new", "latest", "itunes".  If nothing is entered, we set it up as a new device.
	//
	//	Returns: 
	//		Throws an error if there's a problem.
	//	----------------------------------------------------------------------------------------------------------------------
	setup.icloudBackup = function icloudBackup(restoreRoute) {
	    this.unlockScreenForSetup();
	    if (!restoreRoute) restoreRoute = "new";
	    var elementName = "";
	    var theElement = "";
	    
	    if (this.getCurrentPage() != "choosebackup") {
	        throw new Error("Not on iCloud 'Choose Backup' page.");
	    }
	    this.waitForNetworkLoadingToFinish();
	    
	    // Wait for the 'In Progress" spinner to go away
	    var inProgressSpinner = this.getBuddyTableView().cells()["In Progess"];
	    if (inProgressSpinner.isValid()) {
	        UIALogger.logMessage("Waiting for the 'In Progress' Spinner to go away");
	        UIATarget.localTarget().pushTimeout(30);
	        inProgressSpinner.waitForInvalid();
	        UIATarget.localTarget().popTimeout();
	    }
	    
	    if (restoreRoute.toLowerCase() == "itunes") {
	        UIALogger.logMessage("Using an iTunes backup.");
	        elementName = "Restore from iTunes";
	        theElement = this.getBuddyTableView().cells().firstWithPredicate("name beginswith '" + elementName + "'");
        }
        if (restoreRoute.toLowerCase() == "latest") {
	        UIALogger.logMessage("Using the most recent backup");
	        elementName = "first cell";
	        theElement = this.getBuddyTableView().cells()[0];
	        if (!theElement.isValid()) {
	            UIALogger.logMessage("Could not find Buddy Container Cell, looking for cell without it being in the buddy container cell.");
	            theElement = this.mainWindow().tableViews()[0].cells()[0];
	        }
        }
        else {
            UIALogger.logMessage("Not using a backup--setting up as a new device.");
            elementName = "Set up as a new"
            theElement = this.getBuddyTableView().cells().firstWithPredicate("name beginswith '" + elementName + "'");
        }
        
        if (!theElement.isValid()) {
            throw new Error("Can not find the element for restore route '" + restoreRoute + "'");
        }
        UIALogger.logMessage("Tapping '" + theElement.name() + "'");
        theElement.tap();
        UIATarget.localTarget().delay(1);
	    
        try {
            this.tapRightButton(5);
        }
        catch (e) {
            UIALogger.logMessage("Caught error '" + e.message + "'.  This was probably expected, because sometimes choosing the 'Restore from iTunes' button skips the 'Next' button.");
        }
	    this.waitForNextPage("choosebackup");
    }
    
    //	----------------------------------------------------------------------------------------------------------------------
	//	Function: setAppleID 
	//		Attempts to activate the phone.
	// 
	//	Parameters:
	//      appleID (string) = Apple ID string to use.  If appleID is not given, we use "Skip this step"
	//      password (string) = Apple ID password to use.  Must submit a password, if an apple ID is given.
	//
	//	Returns: 
	//		Throws an error if there's a problem.
	//	----------------------------------------------------------------------------------------------------------------------
	setup.setAppleID = function setAppleID(appleID, password) {
	    this.unlockScreenForSetup()
	    
	    var currentPage = this.getCurrentPage();
	    if (currentPage != "appleid")  {
	        throw new Error("Not on the 'Apple ID' page.");
	    }
	    
	    // Enter apple ID.
	    if (appleID) {
	        
	        var signInCell = this.getBuddyTableView().cells()['Sign In with an Apple ID'];
	        if (!signInCell.isValid()) {
	            throw new Error ("Could not tap the 'Sign In with an Apple ID' button.");
	        }
	        UIALogger.logDebug("Tapping the 'Sign In with an Apple ID' button.");
	        signInCell.tap();
	        
	        var textField = this.getBuddyTableView().cells()['Apple ID'].textFields()[0];
	        if (!textField.isValid()) {
	            throw new Error("Could not find text field in which to enter the Apple ID.");
	        }
	        this.enterTextInTextField(textField, appleID);
	        
	        if (!password) { 
	            throw new Error("An appleID was given, but a password was not."); 
	        }
            var passwordField = this.getBuddyTableView().cells()['Password'].secureTextFields()[0];
            if (!passwordField.isValid()) {
	            throw new Error("Could not find text field in which to enter the password for the Apple ID.");
	        }
	        this.enterTextInTextField(passwordField, password);
	        
	        this.tapRightButton(); 
	        this.waitForNetworkLoadingToFinish();
	        if (this.mainWindow().navigationBar().staticTexts()["Terms and Conditions"].isValid()) {
	            UIALogger.logMessage("Terms and Conditations text is on screen--pressing the 'Agree' button.");
	            var agreeButton =  this.mainWindow().toolbars()[0].buttons()["Agree"];
	            if (!agreeButton.isValid()) {
	                throw new Error ("Could not find the 'Agree' button on current page.");
	            }
	            agreeButton.tap();
	            UIATarget.localTarget().delay(2); // give us a bit of time for the 'Terms and Conditions' alert to come up.
	        }
	        else {
	            throw new Error("Terms and Conditions window never came up after entering Apple ID information.");
	        }
	        
	        UIALogger.logMessage("Waiting for Apple ID to be set up.");	        
            if (!this.waitForNextPage("appleid", 120)) {
	            throw new Error("Never got out of the 'Apple ID' setup page.")
	        }	        
	        
	        var mobileMeFinished = this.mainWindow().navigationBar().staticTexts()["Set Up MobileMe"].isValid();	        
	        if (mobileMeFinished) {
	            UIALogger.logMessage("Set Up Mobile Me is on screen--tapping the right button.");
	            this.tapRightButton(); 
	        }
	        
	        if (this.mainWindow().navigationBar().staticTexts().firstWithPredicate("name beginswith 'Find My'").isValid()) {
	            UIALogger.logMessage("'Find My <device>' is on screen--tapping the right button.");
	            this.tapRightButton(); 
	        }
	        
	    }
	    else {
	        UIALogger.logMessage("Skipping Apple ID setup--not entering an Apple ID.");
	        var skipButton = this.mainWindow().elements()["BuddyContainerView"].buttons()["Skip This Step"];
	        if (!skipButton.isValid()) {
	            throw new Error("Could not hit the 'Skip This Step' button.");
	        }
	        skipButton.tap();
	        UIATarget.localTarget().delay(2); // wait a bit for alert to pop up.
	    }
	    	    
    }
    
    //	----------------------------------------------------------------------------------------------------------------------
	//	Function: setSiri
	//		Turns Siri (aka Assistant) on or off.
	// 
	//	Parameters:
	//      dontUseSiri (bool) = if set to 1, turns off Siri.  Otherwise, Siri is turned on.
	//
	//	Returns: 
	//		Throws an error if there's a problem.
	//	----------------------------------------------------------------------------------------------------------------------
	setup.setSiri = function setSiri(dontUseSiri) {
	    this.unlockScreenForSetup()
	    
	    if (this.getCurrentPage() != "siri") {
	        throw new Error("Not on the 'Siri' page.");
	    }
	    
	    UIALogger.logMessage("On the Siri Page");
	    
	    var siriChoice;
	    if ((dontUseSiri == 1) || (dontUseSiri == "true")) {
	        UIALogger.logMessage("Turning off Siri.");
	        siriChoice = this.getBuddyTableView().cells()["Don’t Use Siri"];
	    }
	    else {
	        UIALogger.logMessage("Turning on Siri.");
	        siriChoice = this.getBuddyTableView().cells().firstWithPredicate("name endswith 't Use Siri'");
	    }
	    if (!siriChoice.isValid()) {
	        throw new Error("Could not find the proper choice for Siri");
	    }
	    siriChoice.tap();  
	    this.tapRightButton(); 
	    this.waitForNextPage("siri");
    }
    
    //	----------------------------------------------------------------------------------------------------------------------
	//	Function: setDiagnostics 
	//		Leaves the diagnostics parameters the way they are and hits "Next"
	// 
	//	Parameters:
	//      dontSendDiagnostics (bool) = if set to 1, does not send Diagnostics to Apple.  Otherwise, Diagnostics are sent.
	//
	//	Returns: 
	//		Throws an error if there's a problem.
	//	----------------------------------------------------------------------------------------------------------------------
	setup.setDiagnostics = function setDiagnostics(dontSendDiagnostics) {
	    this.unlockScreenForSetup()
	    
	    if (this.getCurrentPage() != "diagnostics") {
	        throw new Error("Not on the 'Disgnostics' page.");
	    }
	    UIALogger.logMessage("On the 'Diagnostics' page -- hitting the 'Next' button.");
	    
	    var diagnosticsChoice;
	    if ((dontSendDiagnostics == 1) || (dontSendDiagnostics == "true")) {
	        UIALogger.logMessage("Turning off Diagnostics.");
	        diagnosticsChoice = this.getBuddyTableView().cells()["Donʼt Send"];
	    }
	    else {
	        UIALogger.logMessage("Turning on Diagnostics.");
	        diagnosticsChoice = this.getBuddyTableView().cells()["Automatically Send"];
	    }
	    if (!diagnosticsChoice.isValid()) {
	        throw new Error("Could not find the proper choice for the Diagnostics page");
	    }
	    diagnosticsChoice.tap();
	    
	    this.tapRightButton(); 
    }
    
    //	----------------------------------------------------------------------------------------------------------------------
	//	Function: thankYouPage 
	//		Attempts to activate the phone.
	// 
	//	Parameters:
	//      none
	//
	//	Returns: 
	//		Throws an error if there's a problem.
	//	----------------------------------------------------------------------------------------------------------------------
	setup.thankYouPage = function thankYouPage() {
	    this.unlockScreenForSetup();
	    
	    if (this.getCurrentPage() != "thankyou") {
	        throw new Error("Not on the 'Thank You' page.");
	    }
	    
	    var startUsingButton = this.getBuddyTableView().cells().firstWithPredicate("name beginswith 'Start Using'");
	    if (!startUsingButton.isValid()) {
	        throw new Error("'Start Using <Device>' button is not on screen.");
	    }
	    UIALogger.logMessage("Tapping 'Start Using <Device>' button.");
	    startUsingButton.tap();
	    
	    if (!springboard.waitForActive(60)) {
	        throw new Error("SpringBoard never became the frontmost app. Could not navigate through buddy.");
	    }
	    
    }
    
    //	----------------------------------------------------------------------------------------------------------------------
	//	Function: navigateSetupBuddy 
	//		Navigates the entire setup buddy and sets the desired options.
	//
	//	Parameters:
	//		None required.
	//
	//  Optional Parameters:
	//      language (string) - language to choose.  If not specified, chooses English
	//      country (string) - country to choose.  If not specified, chooses United States.
	//      shouldDisableLocationServices (bool) - set to 1 if you want to disable location services.
	//      wifiNetwork (string) - wifi network to choose.  If not specified, no network is chosen.
	//      wifiPassword (string) - password for the wifi network
    //      restoreRoute (string) = "new", "icloud" or "itunes".  If nothing is entered, we set it up as a new device.     
	//      appleID (string) = apple ID to setup.
	//      appleIDPassword (password) = password for the apple id account.
	//      dontUseSiri (string) = set to 1 if you don't want to use Siri.  Otherwise, Siri will be turned on.
	//
	//	Returns: 
	//		Throws an error if there's a problem.
	//	----------------------------------------------------------------------------------------------------------------------
	setup.navigateSetupBuddy = function navigateSetupBuddy(options) {
	    if (!options) options = new Object();
	    
	    this.unlockScreenForSetup()
	    if (!this.isActive()) {
	        throw new Error("Setup is not active.");
	    }
	    
	    // Language
	    if (this.waitForPage("language", 3)) {
	        this.chooseLanguage(options.language);
	    }
	    else {
	        UIALogger.logMessage("Skipping 'Language' page");
	    }
	
	    // Country or Region
	    if (this.waitForPage("country", 3)) {
	        this.chooseCountry(options.country);
	    }
	    else {
	        UIALogger.logMessage("Skipping 'Country' page");
	    }
	    
	    // Location Services
	    if (this.waitForPage("locationservices", 3)) {
            this.chooseLocationServices(options.shouldDisableLocationServices);
        }    
        else {
	        UIALogger.logMessage("Skipping 'Location Services' page");
	    }
	    
	    // Wi-Fi
	    if (this.waitForPage("wifi", 5)) {
            this.setWiFi(options.wifiNetwork, options.wifiPassword, options.useCellularNetwork);
        }    
        else {
	        UIALogger.logMessage("Skipping 'WiFi' page");
	    }
	    	    
	    // Activate
        if ((this.getCurrentPage() == "activating") || (this.getCurrentPage() == "noactivate")) {
            this.activate(options.activationtries);
        }    
        else {
	        UIALogger.logMessage("Skipping 'Activation' page");
	    }
	    
	    // Setup Device (restore routes)
	    if (this.waitForPage("setupdevice", 5)) {
            this.setUpDeviceRestoreRoute(options.restoreRoute);
        }    
        else {
	        UIALogger.logMessage("Skipping 'Setup Device' page");
	    }
	    
	    // iCloud Sign In
    	if (this.waitForPage("icloudsignin", 5)) {
            this.setupiCloud(options.appleID, options.appleIDPassword);
        }    
        else {
    	    UIALogger.logMessage("Skipping 'iCloud Sign In' page");
    	}
    	
    	// Choose Backup for iCloud
        if (this.waitForPage("choosebackup", 2)) {
            this.icloudBackup(options.icloudBackup);
        }
        else {
            UIALogger.logMessage("Skipping 'Choose Backup' page");
        }
        
        // Restoring from backup
        if (this.waitForPage("restoringfrombackup", 2)) {
            UIALogger.logMessage("Currently Restoring from an iCloud Backup.  Phone should reboot soon.");
            return 1;
        }
        else {
            UIALogger.logMessage("Skipping 'Choose Backup' page");
        }
        
	    
        // Apple ID
        if (this.waitForPage("appleid", 2)) {
            this.setAppleID(options.appleID, options.appleIDPassword);
        }
        else {
            UIALogger.logMessage("Skipping 'Apple ID' page");
        }   
        
        // Siri
        if (this.waitForPage("siri", 2)) {
            this.setSiri(options.dontUseSiri);
            
        }
        else {
            UIALogger.logMessage("Skipping 'Siri' page");
        }
        
        // Diagnostics
        if (this.waitForPage("diagnostics", 2)) {
            this.setDiagnostics(options.dontSendDiagnostics);
        }
        else {
            UIALogger.logMessage("Skipping 'Diagnostics' page");
        }
        
        // Thank You Page
        if (this.waitForPage("thankyou", 5)) {
            this.thankYouPage();
        }
        else {
            if (this.getCurrentPage() == 'itunes') {
                throw new Error("Failed to finish Setup -- on the 'Connect to iTunes' page.");
            }
            else {
                UIATarget.localTarget().logElementTree();
                throw new Error("Could not get to 'Thank You' page.");
            }
        }
        
        if (springboard.waitForActive(60)) {
	        UIALogger.logMessage("Springboard is frontmost app.  Setup buddy is complete.")
	    }
	    else {
	        UIATarget.localTarget().logElementTree();
	        throw new Error("SpringBoard never became the frontmost app. Could not navigate through buddy.");
	    }
	    
	}
    
}