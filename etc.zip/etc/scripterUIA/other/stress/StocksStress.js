#import "UIAAppStressLibrary.js"

var stocksList = new Array("Ebay", "Amazon", "Netflix", "Google", "Yahoo", "Apple");

if (typeof stocks != 'undefined') {
	stocksStress = AppStressBase.stressTest("Stocks");
	
	if (typeof stocksStress != 'undefined') {
		
		stocksStress.setup = function setup () {
			stocksStress.addTest(stocksStress._addStock);
			stocksStress.addTest(stocksStress._removeAndAddStock);
			stocksStress.addTest(stocksStress._getToYahooPage);
			
			return true;
		}
		
		stocksStress.run = function run () {
			stocksStress.executeRandomTests(3);
		}
		
		// add stock
		stocksStress._addStock = function _addStock() {
			var stock = UIAUtility.randomFromArray(stocksList);
			
			stocksStress.executeTest("AddStock", [ stock ], stocksTest_addStock, "Adding stock " + stock);
		}
		
		// remove and add stock
		stocksStress._removeAndAddStock = function _removeAndAddStock() {
			stocksStress.executeTest( "RemoveAndAddStock", [], stocksTest_removeAndAddStock, "Removing and re-adding random stock." );
		}
		
		// go to Yahoo page
		stocksStress._getToYahooPage = function _getToYahooPage() {
			stocksStress.executeTest("GetToYahooPage", [], stocksTest_getToYahooPage, "Navigating to Yahoo Stocks page.");
			system.sleep(2);
		}
	}
}



