/*
 Class: UIApp (clock)
 Clock object
 */
#import "../libs/SpringBoard.js"


clock = UIAApp.application("Clock", "com.apple.mobiletimer");

if (typeof clock != 'undefined') {
	
	clock.soundChoices = new Array("None", "Marimba", "Alarm", "Ascending", "Bark", "Bell Tower", "Blues", "Boing", "Crickets", 
								   "Digital", "Doorbell", "Duck", "Harp", "Motorcycle", "Old Car Horn", "Old Phone", "Piano Riff", 
								   "Pinball", "Robot", "Sci-Fi", "Sonar", "Strum", "Timba", "Time Passing", "Trill", "Xylophone");
	clock.repeatChoices = new Array("Every Monday", "Every Tuesday", "Every Wednesday", "Every Thursday", "Every Friday", "Every Saturday", "Every Sunday");

	clock.resetInvalidAlarmsLogging = function resetInvalidAlarmsLogging() {
		this.asApplication().resetInvalidAlarmsLogging();
	}
    
	clock.invalidAlarmsDetected = function invalidAlarmsDetected() {
		return this.asApplication().invalidAlarmsDetected();
	}
    
	clock.invalidAlarmsLog = function invalidAlarmsLog() {
		return this.asApplication().invalidAlarmsLogCopy();
	}
	
	
	// --------------------------------------------------------------------------------
	//	Function: getToClockView 
	//		Goes to the World Clock view
	//
	//	Parameters:	
	//		None
	//
	//	Returns: 
	//		None
	//
	//	Throws: 
	//		Error
	// --------------------------------------------------------------------------------
	clock.getToClockView = function getToClockView() {
		this.launchIfNotActive();
		
		var navBar = this.navigationBar();
		if (navBar.isValid()) {
			if (navBar.searchBars()[0].isValid()) {
				UIALogger.logMessage("In 'SearchView'");
				navBar.buttons()["Cancel"].tap();
			}
			
			for (var i=0; i<3; i++) {
				var navBarName = navBar.name();
				UIALogger.logMessage("In '" + navBarName + "'");
				var leftButton = navBar.leftButton().withPredicate("name != 'Edit'");
				if (leftButton.isValid()) {
					leftButton.tap();
					UIATarget.localTarget().delay(1); //some time for animation
				}
				else 
					break;
				navBar = this.navigationBar();
				if (!navBar.isValid()) break;
				if (navBar.name() == navBarName) UIALogger.logWarning("Nav bar did not change name");
			}
		}
		
		this.tabBar().buttons()["World Clock"].tap();
		if (!this.navigationBar().withName("World Clock").isValid())
			throw new Error("Could not verify if 'World Clock' is being displayed");
		UIALogger.logMessage("In 'ClockView'");
	}

	// --------------------------------------------------------------------------------
	//	Function: addWorldClock 
	//		Adds a world clock for the specified city
	//
	//	Parameters: 
	//		city (string) - City name to search for
	//
	//	Returns: 
	//		None
	// --------------------------------------------------------------------------------
	clock.addWorldClock = function addWorldClock(city, identifier) {	
		var date = new Date(); //for checking for "Too many world clock alert"
		UIALogger.logMessage("Selecting button 'Add'");
		this.navigationBar().buttons()["Add"].tap();
		UIATarget.localTarget().delay(2); //couple of seconds for the alert to pop up
		var alert = this.alertSinceDate(date);
		if (alert && alert.alertMessageArray[0] == "Too many world clocks") {
			throw new Error("Too many world clocks - cannot add any more. ");
		}
		
		this.search(city, {searchBarEvalString:"this.mainWindow().navigationBar().searchBars()[0]"});
		if (!this.waitForNetworkLoadingToFinish()) 
			UIALogger.logWarning("Network loading did not finish");
		UIALogger.logMessage("Selecting clock for location '" + city + "'.");
		
		var cityCell = this.mainWindow().tableViews()[0].scrollToElementWithPredicate("name contains '" + city + "'");
		if (!cityCell.isValid()) {
			throw new Error("'" + city + "' did not appear in the search results");
		}
		cityCell.tap();
	}
	
	// --------------------------------------------------------------------------------
	//	Function: deleteWorldClock 
	//		Removes a world clock
	//
	//	Parameters:	
	//		label (string) - optional - deletes the clock with the specified label. If 
	//			no label is specified, the first clock is deleted.  
	//
	//	Throws: 
	//		Error
	//
	//	Returns: 
	//		None
	// --------------------------------------------------------------------------------
	clock.deleteWorldClock = function deleteWorldClock(label) {	
		var worldClockCell;

		if (label) {
			UIALogger.logMessage("Selecting clock with label '" + label + "'");
			worldClockCell = this.mainWindow().images()[0].tableViews()[0].cells().firstWithPredicate("name contains '" + label + "'");
		} else {
			worldClockCell = this.mainWindow().images()[0].tableViews()[0].cells()[0];
			UIALogger.logMessage("No label specified.  Removing the first World Clock found.");		
		}
		
		if (!worldClockCell.isValid()) throw new Error("Did not find the table cell");
		worldClockCell.scrollToVisible();
		
		this.navigationBar().buttons()["Edit"].tap();
		this.deleteTableCell(worldClockCell);
		
		var doneButton = this.navigationBar().buttons()["Done"];
		if (doneButton.isValid()) doneButton.tap();
	}
	
	// --------------------------------------------------------------------------------
	//	Function: setAlarmTime
	//		Sets the time for a new alarm
	//
	//	Parameters:	
	//		time	(string)	a string in the format hh:mm
	//
	//	Returns: 
	//		None
	//
	//	Throws: 
	//		Error
	// --------------------------------------------------------------------------------
	clock.setAlarmTime = function setAlarmTime(time) {
		var hours, minutes;
		
		if (typeof time != "string") return false;
		
		var timeArray = time.split(":");
		if (timeArray.length < 2) {
			throw new Error("time should be a string in the form of hh:mm");
		}
		
		// update the hours for a 12 hour clock and set the 
		hours = timeArray[0]%12;
		if (hours == 0) hours = 12;
		minutes = timeArray[1];
		
		var hoursValue = hours + " o'clock"; //need to add o'clock to match the picker value
		var minutesValue = (minutes == "01") ? minutes + " minute" : minutes + " minutes"; //need to add minutes to match the picker value
		
		var pickerTable = this.mainWindow().pickers()[0];
		if (!pickerTable.isValid()) throw new Error("Did not find a picker table");
		
		//Setting value for hours
		UIALogger.logMessage("Attempting to adjust picker to '" + hoursValue + "'.");
		var scrollDirection = ((12 + (parseInt(pickerTable.wheels()[0].value(), 10) - parseInt(hours, 10))) % 12) >= 6 ? 1 : 0;
		UIALogger.logMessage("Scrolling (dragging) the wheel " + (scrollDirection ? "up" : "down"));
		UIAUtility.scrollWheelToValueWithOptions(pickerTable.wheels()[0], hoursValue, {direction:scrollDirection, maxDrags:27});

		//Setting value for minutes
		UIALogger.logMessage("Attempting to adjust picker to '" + minutesValue + "'.");
		scrollDirection = ((60 + (parseInt(pickerTable.wheels()[1].value(), 10) - parseInt(minutes, 10))) % 60) >= 30 ? 1 : 0;
		UIALogger.logMessage("Scrolling (dragging) the wheel " + (scrollDirection ? "up" : "down"));
		UIAUtility.scrollWheelToValueWithOptions(pickerTable.wheels()[1], minutesValue, {direction:scrollDirection, maxDrags:65});
		
		//Setting AM/PM if needed. This needs to come last, otherwise the AM/PM might get changed when you change hours.
		var value = (timeArray[0] < 12) ? "AM " : "PM "; //need to add space at the end to match the picker value
		scrollDirection = (value == "AM ") ? 0 : 1;
		UIALogger.logMessage("Attempting to adjust picker to '" + value + "'.");
		UIALogger.logMessage("Scrolling (dragging) the wheel " + (scrollDirection ? "up" : "down"));
		UIAUtility.scrollWheelToValueWithOptions(pickerTable.wheels()[2], value, {direction:scrollDirection, maxDrags:3});

	}
	
	// --------------------------------------------------------------------------------
	//	Function: setAlarmRepeat 
	//		Sets the repeat for a new alarm
	//
	//	Parameters:	
	//		repeatList	(array of strings)	an array of repeat strings as shown in UI (i.e. "Every Monday", "Every Tuesday" ...)
	//
	//	Returns: 
	//		None
	//
	//	Throws: 
	//		Error
	// --------------------------------------------------------------------------------
	clock.setAlarmRepeat = function setAlarmRepeat(repeatList) {
		if (!(repeatList instanceof Array)) throw new Error("Unexpected repeat array format '" + repeatList + "'");
		
		//Going into the Repeat Window
		this.mainWindow().tableViews()[0].cells().firstWithPredicate("name contains 'Repeat'").tap();
		if (!this.navigationBar().withName("Repeat").isValid()) 
			UIALogger.logWarning("'Repeat' nav bar did not show up");
		UIATarget.localTarget().delay(1);
		
		//Selecting frequency
		for (var key in repeatList) {
			UIALogger.logMessage("Setting alarm repeat to '" + repeatList[key] + "'");

			//Selecting frequency
			var repeatElement = this.mainWindow().tableViews()[0].scrollToElementWithPredicate("name contains '" + repeatList[key] + "'");
			if (repeatElement.value() != "1") repeatElement.tap();
			if (!repeatElement.withValueForKey(1, "value").isValid()) 
				throw new Error("Selected the repeat element, but the value did not change to 1");
		}
		
		this.navigationBar().leftButton().tap();
		UIATarget.localTarget().delay(1);
	}
	
	// --------------------------------------------------------------------------------
	//	Function: unsetAlarmRepeat 
	//		Clears one or more repeat days for the opened alarm
	//
	//	Parameters:	
	//		repeatList	(array of strings)	an array of repeat strings as shown in UI (i.e. "Every Monday", "Every Tuesday" ...)
	//
	//	Returns: 
	//		None
	//
	//	Throws: 
	//		Error
	// --------------------------------------------------------------------------------
	clock.unsetAlarmRepeat = function unsetAlarmRepeat(repeatList) {
		if (!(repeatList instanceof Array)) throw new Error("Unexpected repeat array format '" + repeatList + "'");
				
		//Going into the Repeat Window
		this.mainWindow().tableViews()[0].cells().firstWithPredicate("name contains 'Repeat'").tap();
		if (!this.navigationBar().withName("Repeat").isValid()) 
			UIALogger.logWarning("'Repeat' nav bar did not show up");
		UIATarget.localTarget().delay(1);
	
		for (var key in repeatList) {
			UIALogger.logMessage("Unsetting alarm repeat to '" + repeatList[key] + "'");
   
			//Selecting frequency
			var repeatElement = this.mainWindow().tableViews()[0].scrollToElementWithPredicate("name contains '" + repeatList[key] + "'");
			if (repeatElement.value() == "1") repeatElement.tap();
			if (!repeatElement.withPredicate("value != 1").isValid()) 
				throw new Error("Unselected the repeat element, but the value did not change to 0");
		}
	
		this.navigationBar().leftButton().tap();
		UIATarget.localTarget().delay(1);
	}
	
	// --------------------------------------------------------------------------------
	//	Function: setAlarmSound 
	//		Sets the sound for a new alarm
	//
	//	Parameters:	
	//		sound	(string)	the sound string as shown in UI (i.e. "Marimba", "Alarm" ...)
	//
	//	Returns: 
	//		None
	//
	//	Throws: 
	//		Error
	// --------------------------------------------------------------------------------
	clock.setAlarmSound = function setAlarmSound(sound) {
		if(typeof sound != "string") throw new Error("Unexpected argument type: " + sound);
		
		var pageName = this.navigationBar().name();
		
		UIALogger.logMessage("Setting alarm sound to '" + sound + "'");
		
		//Going into the Sound Window
		this.mainWindow().tableViews()[0].cells().firstWithPredicate("name contains 'Sound'").tap();
		if (!this.navigationBar().withName("Sound").isValid()) 
			UIALogger.logWarning("'Sound' nav bar did not show up");
		UIATarget.localTarget().delay(1);
		
		//Selecting sound
		var soundElement = this.mainWindow().tableViews()[0].elements()[sound];
		soundElement.scrollToVisible();
		soundElement.tap();
		UIATarget.localTarget().delay(1);
		
		this.navigationBar().leftButton().tap();
		if (!this.navigationBar().withName(pageName).isValid()) throw new Error("Tapped the back button, but the '" + pageName + "' view did not come up");
		UIATarget.localTarget().delay(1);
		
		var soundElement = this.mainWindow().tableViews()[0].cells()["Sound, " + sound];
		if (!soundElement.isValid()) throw new Error("Failed to set the sound for the alarm to '" + sound + "'.");
	}
	
	// --------------------------------------------------------------------------------
	//	Function: setAlarmSnooze 
	//		Sets the snooze setting for an alarm
	//
	//	Parameters:	
	//		snooze	(string)	the snooze value as shown in UI (i.e. "0" or "1")
	//
	//	Returns: 
	//		None
	//
	//	Throws: 
	//		Error
	// --------------------------------------------------------------------------------
	clock.setAlarmSnooze = function setAlarmSnooze(snooze) {

		UIALogger.logMessage("Setting Snooze to " + snooze);
		
		var snoozeElement = this.mainWindow().tableViews()[0].cells().firstWithPredicate("name contains 'Snooze'");
		snoozeElement.switches()[0].setValue(snooze);
	}

	// --------------------------------------------------------------------------------
	//	Function: setAlarmLabel 
	//		Sets the label for a new alarm
	//
	//	Parameters:	
	//		label	(string)	a label to use for the alarm
	//
	//	Returns: 
	//		None
	//
	//	Throws: 
	//		Error
	// --------------------------------------------------------------------------------
	clock.setAlarmLabel = function setAlarmLabel(label) {
		if(typeof label != "string") throw new Error("Unexpected label type: " + label);
		
		var pageName = this.navigationBar().name();
		UIALogger.logMessage("Setting alarm label to '" + label + "'");
		
		//Going into the Label Window
		this.mainWindow().tableViews()[0].cells().firstWithPredicate("name contains 'Label'").tap();
		if (!this.navigationBar().withName("Label").isValid()) 
			UIALogger.logWarning("'Label' nav bar did not show up");
		UIATarget.localTarget().delay(1);
		
		//Selecting sound
		this.mainWindow().tableViews()[0].cells()[0].textFields()[0].setValue(label);
		
		this.navigationBar().leftButton().tap();
		if (!this.navigationBar().withName(pageName).isValid()) throw new Error("Tapped the back button, but the '" + pageName + "' view did not come up");
		UIATarget.localTarget().delay(1);
		
		var labelElement = this.mainWindow().tableViews()[0].cells()["Label, " + label];
		if (!labelElement.isValid()) throw new Error("Failed to set the label for the alarm to '" + label + "'.");
	}
	
	// --------------------------------------------------------------------------------
	//	Function: setAlarm
	//		Sets the currently displayed alarm using the specified settings
	//
	//	Parameters:	
	//		time	(string)	a string in the format hh:mm
	//		unsetRepeatList	(array of strings)	an array of repeat strings to unset as shown in UI (i.e. "Every Monday", "Every Tuesday" ...)
	//		setRepeatList	(array of strings)	an array of repeat strings to set as shown in UI (i.e. "Every Monday", "Every Tuesday" ...)
	//		sound	(string)	name of the sound as shown in UI (i.e. "Marimba", "Alarm"....)
	//		snooze	(string)	value for the snooze option (i.e. "1" or "0")
	//		label	(string)	label for the new alarm
	//
	//	Returns: 
	//		None
	//
	//	Throws: 
	//		Error
	// --------------------------------------------------------------------------------
	clock.setAlarm = function setAlarm(time, unsetRepeatList, setRepeatList, sound, snooze, label) {	
		
		var navBar = this.navigationBar();
		if (!navBar.withName("Add Alarm").isValid() && 
			!navBar.withName("Edit Alarm").isValid()) {
            throw new Error("There is no alarm open to configure.");
        }
		
		var hours, minutes;
		if (typeof time == "string") {
			this.setAlarmTime(time);
		} else {
			UIALogger.logError("No time specified.  Using the default.");
		}
		
		if (unsetRepeatList instanceof Array && unsetRepeatList.length > 0) {
			this.unsetAlarmRepeat(unsetRepeatList);
		} else {
			UIALogger.logError("No unset repeat list specified.  Using the default.");
		}
		
		if (setRepeatList instanceof Array && setRepeatList.length > 0) {
			this.setAlarmRepeat(setRepeatList);
		} else {
			UIALogger.logError("No set repeat list specified.  Using the default.");
		}
		
		if (typeof sound == "string") {
			this.setAlarmSound(sound);
		} else {
			UIALogger.logError("No sound specified.  Using the default.");
		}
		
		if (typeof snooze == "string") {
			this.setAlarmSnooze(snooze);
		} else {
			UIALogger.logError("No snooze specified.  Using the default.");
		}
		
		if (typeof label == "string") {
			this.setAlarmLabel(label);
		} else {
			UIALogger.logError("No label specified.  Using the default.");
		}
		
		//Saving the info
		this.navigationBar().buttons()["Save"].tap();
	}
	
	//----------------------------------------------------------------------------------------
	//  Function: setAlarmSwitch
	//		Sets the alarm to be off or on
	//
	//	Parameters: 
	//		alarmCellLabel (string) - the label of the alarm whose switch needs to be toggled
	//		setting (string) - "1" or "0"
	//
	//	Throws: 
	///		Error
	//	
	//	Returns: 
	//		None
	//----------------------------------------------------------------------------------------
	clock.setAlarmSwitch = function setAlarmSwitch(alarmCellLabel, setting) {
		
		UIALogger.logMessage("Setting the element with " + alarmCellLabel + " to " + setting);
		var alarmCell = this.mainWindow().images()[0].tableViews()[0].scrollToElementWithPredicate("name contains '" + alarmCellLabel + "'");
		if (!alarmCell.isValid()) throw new Error("Did not find alarm table cell with '" + alarmCellLabel + "'");
		
		alarmCell.switches()[0].setValue(setting);
	}

	//----------------------------------------------------------------------------------------
	//  Function: deleteAlarm
	//		Removes the alarm with the specified label
	//
	//	Parameters: 
	//		label (string) - the label of the alarm that needs to be removed
	//
	//	Throws: 
	//		Error
	//	
	//	Returns: 
	//		None
	//----------------------------------------------------------------------------------------
	clock.deleteAlarm = function deleteAlarm(label) {	
		
		this.tabBar().buttons()["Alarm"].tap();
		
		UIALogger.logMessage("Removing alarm with label '" + label + "'");
		var alarmCell = this.mainWindow().images()[0].tableViews()[0].scrollToElementWithPredicate("name contains '" + label.replace("'", "\\'") + "'");
		if (!alarmCell.isValid()) throw new Error("Alarm not found with label '" + label + "'.");
		
		this.navigationBar().buttons()["Edit"].tap();
		this.deleteTableCell(alarmCell);
		var doneButton = this.navigationBar().buttons()["Done"];
		if (doneButton.isValid()) doneButton.tap(); //might not be there is the deleted alarm was the last alarm
	}
	
	//----------------------------------------------------------------------------------------
	//  Function: deleteAllAlarms
	//		Removes all the alarms
	//
	//	Parameters: 
	//		None
	//
	//	Throws: 
	//		Error
	//	
	//	Returns: 
	//		None
	//----------------------------------------------------------------------------------------
	clock.deleteAllAlarms = function deleteAllAlarms() {
		
		UIALogger.logMessage("Removing all alarms");
		this.tabBar().buttons()["Alarm"].tap();
		
		var alarmTable = this.mainWindow().images()[0].tableViews()[0];
		var numOfAlarms = alarmTable.cells().length;
		
		UIALogger.logMessage("There are " + numOfAlarms + " alarms");
		
		if (numOfAlarms > 0) {
			this.navigationBar().buttons()["Edit"].tap();
			
			for (var i=0; i<numOfAlarms; i++) {
				var labelElement = alarmTable.cells()[0];
				if (!labelElement.isValid()) {
					throw new Error("Did not find an alarm label after deleting " + (i+1) + " alarms");
				}
				UIATarget.localTarget().delay(1);
				
				UIALogger.logMessage("Deleting an alarm with label " + labelElement.name());
				this.deleteTableCell(labelElement);
			}
		}
	}
	
	//----------------------------------------------------------------------------------------
	//  Function: getRandomAlarmSettings
	//		Returns a dictionary containing random alarm settings
	//
	//	Parameters: 
	//		None
	//
	//	Returns: 
	//		A dictionary containing the following keys: time, repeat, sound, snooze
	//----------------------------------------------------------------------------------------
	clock.getRandomAlarmSettings = function getRandomAlarmSettings() {
		var settings = new Object();
		
		var now = new Date();
        var hour = system.randomInteger(0,23);
        var minute = system.randomInteger(0,59);
        // no alarms within the next 30 minutes to avoid dealing with them going off
        var timeDifference = (hour * 60 + minute) - (now.getHours() * 60 + now.getMinutes());
        if ((timeDifference > 0 && timeDifference <= 30) || (timeDifference <= -((24 * 60) - 30))) {
            hour = (hour + 1) % 24;
        }
        settings.time = (hour < 10 ? "0" : "") + hour + ":" + (minute < 10 ? "0" : "") + minute;
        settings.repeat = new Array();
        if (system.randomReal(0,1) < 0.7) {
            if (system.randomReal(0,1) < 0.4) {
                // all days
                settings.repeat = this.repeatChoices;
            } else if (system.randomReal(0,1) < 0.4) {
                // one day
                settings.repeat.push(UIAUtility.randomFromArray(this.repeatChoices));
            } else {
                // zero to all days, mostly likely several
                for (var key in this.repeatChoices) {
                    if (system.randomReal(0,1) < 0.4) {
                        settings.repeat.push(this.repeatChoices[key]);
                    }
                }
            }
        }
        settings.sound = UIAUtility.randomFromArray(this.soundChoices);
		settings.snooze = system.randomReal(0,1) < 0.3 ? "0" : "1";
		
		UIALogger.logMessage("Time : " + settings.time);
        UIALogger.logMessage("Repeat : " + settings.repeat.join(", "));
        UIALogger.logMessage("Sound : " + settings.sound);
        UIALogger.logMessage("Snooze : " + settings.snooze);
		
		return settings;
	}
	

	
	// --------------------------------------------------------------------------------
	//	Function: getStopwatchTime 
	//		Gets the current time from the Stopwatch
	//
	//	Parameters: 
	//		None
	//
	//	Returns: 
	//		Current time from Stopwatch
	//
	//	Throws: 
	//		Error
	// --------------------------------------------------------------------------------
	clock.getStopwatchTime = function getStopwatchTime(stopwatchTimeElement) { 
		var elapsedTimeElement = this.mainWindow().staticTexts().firstWithPredicate("name contains ', elapsed'");
		if (!elapsedTimeElement.isValid()) throw new Error("Elapsed time element not found");
		
		var elapsedTimeString = elapsedTimeElement.name().split(", elapsed")[0];
		
		var timeArr = elapsedTimeString.split(' ');
		var time = parseFloat(timeArr[timeArr.length-2]);
		if (timeArr.length>2) time += 60*parseFloat(timeArr[timeArr.length-4]);
		
		return time;
	}
	
	//----------------------------------------------------------------------------------------
	//  Function: isStopwatchRunning
	//		Compares two different times recorded by Stopwatch and 
	//		checks if the Stopwatch is running
	//
	//	Parameters: 
	//		None
	//
	//	Returns: 
	//		True - if the stopwatch is running, false otherwise. 
	//----------------------------------------------------------------------------------------
	clock.isStopwatchRunning = function isStopwatchRunning() {
		var firstTime = this.getStopwatchTime();
		UIALogger.logMessage("Time 1: " + firstTime);	
		UIATarget.localTarget().delay(1); //getting time difference
		var secondTime = this.getStopwatchTime();
		UIALogger.logMessage("Time 2: " + secondTime);	
		
		if (secondTime > firstTime){
			// there is time difference - Stopwatch is already running
			return true;
		} else {
			// there is no time difference - Stopwatch is paused or at 00:00.0
			return false;
		}
	}
	
	//----------------------------------------------------------------------------------------
	//  Function: stopStopwatch
	//		Stop the Stopwatch and gets the latest time
	//
	//	Parameters: 
	//		None
	//
	//	Returns: 
	//		The current time
	//
	//	Throws: 
	//		Error
	//----------------------------------------------------------------------------------------	
	clock.stopStopwatch = function stopStopwatch() {
		this.mainWindow().buttons()["Stop"].tap();
		var currentTime = this.getStopwatchTime();
		UIALogger.logMessage("The Stopwatch is STOPPED at time " + currentTime);
		return currentTime;
	}
	
	//----------------------------------------------------------------------------------------
	//  Function: isclockReset
	//		To check that the Stopwatch is at 00:00.0
	//
	//	Parameters: 
	//		None
	//
	//	Returns: 
	//		True - if the clock is reset. False, otherwise. 
	//
	//	Throws: 
	//		Error
	//----------------------------------------------------------------------------------------
	clock.isclockReset = function isclockReset() {
		var currentTime = this.getStopwatchTime();
		if(currentTime != 0){
			UIALogger.logMessage("The Stopwatch time is " + currentTime);
			return false;
		} else {
			return true;
		}	
	}
	
	//----------------------------------------------------------------------------------------
	//  Function: getLapTime
	//		Gets current lap time of the Stopwatch
	//
	//	Parameters: 
	//		None
	//
	//	Returns: 
	//		Current lap time
	//
	//	Throws: 
	//		Error
	//----------------------------------------------------------------------------------------
	clock.getLapTime = function getLapTime() { 	

		var lapTimeElement = this.mainWindow().staticTexts().firstWithPredicate("name contains 'lap time'");
		if (!lapTimeElement.isValid()) throw new Error("Elapsed time element not found");
		
		var lapTimeString = lapTimeElement.name().split(", lap time")[0];
		
		var timeArr = lapTimeString.split(' ');
		var time = parseFloat(timeArr[timeArr.length-2]);
		if (timeArr.length>2) time += 60*parseFloat(timeArr[timeArr.length-4]);
		
		return time;  
	}
}
