#!/usr/bin/perl

open (PS, "| /usr/local/bin/h4isp -x");
printf ("$ARGV[1]\n");
printf ("$ARGV[0]\n");
if (1 <= $#ARGV && ($ARGV[1] eq "OFF"))
{
	printf (PS "off\n");
}
elsif (0 <= $#ARGV && ($ARGV[0] eq "FRONT"))
{
	printf (PS "v off\n");
	printf (PS "on\n");
	printf (PS "start 1 8 0\n");
	printf (PS "maxframerate 1 30\n");
	printf (PS "minframerate 1 30\n");
}
elsif (0 <= $#ARGV && ($ARGV[0] eq "REAR"))
{
	printf (PS "v off\n");
	printf (PS "on\n");
	printf (PS "start 0 11 0\n");
	printf (PS "maxframerate 0 20\n");
	printf (PS "minframerate 0 20\n");
}
close (PS);
