/*
 Class: UIApp (photos)
 Photos object
 */

#import "../libs/SpringBoard.js"
#import "../libs/UIAAppPhotoAdditions.js"
#import "../libs/UIAAppMailAdditions.js"
#import "../libs/UIAAppContactsAdditions.js"
#import "../libs/UIAAppPrintingAdditions.js"

photos = UIAApp.application("Photos", "com.apple.mobileslideshow");

if (typeof photos != 'undefined') {
	
	// Minumum # of photos required to scroll the photo table view
	if (UIATarget.localTarget().model() != 'iPad') {
		photos.MIN_PHOTO_COUNT = 21;
	} else {
		photos.MIN_PHOTO_COUNT = 40;	
	}
	 
	// Helper function to get the element to change between albums, events, photos, etc on iPad vs. non-iPad
	photos._getViewControllerElement = function _getViewControllerElement() {
		
		if (UIATarget.localTarget().model() != 'iPad') {
			return this.mainWindow().tabBar();
		} else {
			return this.mainWindow().navigationBar().segmentedControls()[0];
			
		}
	} // end _getViewControlElement	
	

	// Helper function to start the slideshow on iPad vs. non-iPad
	photos._startSlideshow = function _startSlideshow() {
		var maxAttempts = 10;
		
		// Start the slideshow
		if (UIATarget.localTarget().model() != 'iPad') {
			this.photoToolbarButtonWithName("Play").tap();
			
			// Let the modal slidehow options view appar
			UIATarget.localTarget().delay(1);
			
			this.mainWindow().tableViews()[0].buttons().firstWithName("Start Slideshow").tap();
			
		} else {
			
			for (var attempt = 0; attempt < maxAttempts && !this.navigationBar().isVisible(); attempt++) {
				UIALogger.logMessage("Attempting to bring up controls.");
				try {
					this.bringUpControls();
				} catch (e) {
					UIALogger.logMessage(e.message + ". Attempt # " + (attempt + 1));
				}
				//give the animation a chance to finish
				UIATarget.localTarget().delay(0.7);
			}
			
			this.navigationBar().buttons()["Slideshow"].tap();
			UIATarget.localTarget().delay(1);
			this.mainWindow().popover().tableViews()[0].buttons().firstWithName("Start Slideshow").tap();
		}
		return;
		
	} // end _startSlideshow
	
	//----------------------------------------------------------------------------------------
	//	Function: getToViewNamed
	//		Returns to the top-most view in the Photos view hierarchy and selects a tab in 
	//		the tab bar with the specified name.  By default, this will navigate to the 
	//		Albums tab
	//
	//	Parameters: 
	//		viewName (string) - name of the view to select (if available)
	//					Photos (iPad only)
	//					Albums
	//					Events
	//					Faces
	//					Places
	//
	//	Returns: 
	//		None
	//	
	//	Throws:
	//		Throws an error if the tab could not be selected for any reason
	//----------------------------------------------------------------------------------------
	photos.getToViewNamed = function getToViewNamed(viewName) {

		// First check for photos or videos on the device (since we wouldn't be in a photo if there weren't)
		if (!this.checkForPhotosOrVideos())
			throw new Error("No photos or videos on device.");

		// Default to "Albums" tab
		if (!viewName) 
			viewName = "Albums";

		// viewControllerElement is the parent element of either the tabBar (non-ipads) or 
		// the segmentedControls (ipad) where the buttons to change the view to "Albums", "Events", etc.
		var viewControllerElement = this._getViewControllerElement();
		var navBar = this.navigationBar();
		// Are we already in the specified tab view?
		if (viewControllerElement.isVisible()) {
			viewControllerElement.buttons().firstWithPredicate("name beginswith '" + viewName + "'").tap();
			return;
		}
		
		// Dismiss any Action Sheets
		if (this.actionSheet().isValid()) this.actionSheet().buttons()["Cancel"].tap();
		
		// Is there a cancel button in the navigation bar? (For non-iPads, we could be in the contacts list.
		// For iPads, this could mean we're setting the wallpaper.)
		var cancelButton = this.mainWindow().navigationBar().buttons().firstWithName("Cancel");
		if (cancelButton.isValid()) cancelButton.tap();
		
		// Let the contacts table disappear
		UIATarget.localTarget().delay(1);

		// Now, are we currently viewing a photo?
		UIALogger.logMessage("Exiting Photo View");
		this.exitPhotoView();

		navBar = this.mainWindow().navigationBar();
		var tabBar = this.mainWindow().tabBar();
		
		if (!tabBar.isVisible() && navBar.isVisible()) {
			this.returnToTopLevel();
		}
		// Let any animations settle
		UIATarget.localTarget().delay(1);
		
		this.returnToTopLevel();
		// Let any animations settle
		UIATarget.localTarget().delay(1);

		navBar = this.mainWindow().navigationBar();
		viewControllerElement = this._getViewControllerElement();
		
		if (UIATarget.localTarget().model() != 'iPad') {

			if (!navBar.staticTexts().firstWithName(viewName).isValid() && !viewControllerElement.isValid()) {
				UIATarget.localTarget().frontMostApp().logElementTree();
				throw new Error("Not in the " + viewName + " view and the tab bar is not valid to select the " + viewName + " view.");
			} 
			
			if (!navBar.staticTexts().firstWithName(viewName).isValid() && viewControllerElement.isValid()) {
				if (tabBar.buttons().firstWithName(viewName).isValid()) {
					UIALogger.logMessage("Tapping the '" + viewName + "' tab");
					viewControllerElement.buttons().firstWithName(viewName).tap();
				} else {
					UIATarget.localTarget().frontMostApp().logElementTree();
					throw new Error("Coud not find the '" + viewName + "' button in the tab bar.");
				}
			}
			
			return;	
		} else {
			var isViewControllerElementValid = viewControllerElement.isValid();
			var viewControllerElementButtonValue = viewControllerElement.buttons().firstWithPredicate("name beginswith '" + viewName + "'").value();
			
			if (!isViewControllerElementValid) {
				throw new Error("Cannot find the segmented controls");
			} else if (isViewControllerElementValid && !viewControllerElementButtonValue) {
				UIALogger.logMessage("Tapping the '" + viewName + "' button");
                var viewControllerElementButton = viewControllerElement.buttons().firstWithPredicate("name beginswith '" + viewName + "'");
				viewControllerElementButton.tap();

                // Patiently wait for the view to switch
                viewControllerElementButton.withValueForKey(1, "value");

				return;
			} else {
				return;
			}
			
		}
		
		
	} // end photos.getToViewNamed
	
	
	//----------------------------------------------------------------------------------------
	//	Function: getToCollectionInView
	//		Selects an album/event/Faces with the name specified from a specified view.  Due to
	//		<rdar://problem/8299121> In Photos, table cells that are offscreen do not appear in logElementTree
	//		this test is not guaranteed to work if there are 18+ collections in a table.
	//
	//	Parameters: 
	//		collectionName (string) - name of the collection to select
	//		viewName (string) - name of the tab to look for collectionName
	//
	//	Returns: 
	//		none
	//	
	//	Throws:
	//		An exception if the collection could not be selected for any reason
	//----------------------------------------------------------------------------------------
	photos.getToCollectionInView = function getToCollectionInView(collectionName, viewName) {
		
		var navBar = this.navigationBar();
		UIALogger.logMessage("Searching for collection: '" + collectionName + "' in '" + viewName + "' view.");

		UIATarget.localTarget().delay(1);
		// Are we already in the album specified?
		if (navBar.staticTexts().firstWithPredicate("name beginswith '" + collectionName + "'").isValid()) {
			UIALogger.logMessage("Already in the '" + collectionName + "' album");
			return;
		}
		this.getToViewNamed(viewName);
				
        
        UIATarget.localTarget().delay(2);
		if (!this.mainWindow().tableViews()[0].isValid())
			throw new Error("Did not find list of photo albums");
		
		var collection;
		if (UIATarget.localTarget().model() != 'iPad') {
			collection = this.mainWindow().tableViews()[0].cells().firstWithPredicate("name beginswith '" + collectionName + "'");
		} else {
			var collectionRow = this.mainWindow().tableViews()[0].cells().firstWithPredicate("ANY elements.name beginswith '" + collectionName + "'");	
			collection = collectionRow.elements().firstWithName(collectionName);
		}
		
		if (!collection.isValid()) throw new Error("Could not find a cell beginning with: " + collectionName);
		
		collection.scrollToVisible();
		UIATarget.localTarget().delay(1);

		UIALogger.logMessage("Selecting collection '" + collectionName + "' from " + viewName);
		//workaround for <rdar://problem/8503147>
		if (collection.isVisible()) {
			collection.tap();
		} else {
			UIATarget.localTarget().tap(collection.rect());
		}
		return;
		
	} // end photos.getToCollectionInView
	
	//----------------------------------------------------------------------------------------
	//	Function: getCurrentPhotoIndex
	//		Gets the index of the current photo in the currently-viewed collection
	//		
	//	Parameters: 
	//		None
	//		
	//	Returns: 
	//		index of the photo being viewed
	//	
	//----------------------------------------------------------------------------------------
	photos.getCurrentPhotoIndex = function getCurrentPhotoIndex() {
		var maxAttempts = 10;
		for (var attempt = 0; attempt < maxAttempts && !this.navigationBar().isVisible(); attempt++) {
			UIALogger.logMessage("Attempting to bring up controls.");
			try {
				this.bringUpControls();
			} catch (e) {
				UIALogger.logMessage(e.message + ". Attempt # " + (attempt + 1));
			}
			//give the animation a chance to finish
			UIATarget.localTarget().delay(1);
		}
		
			return parseInt(this.navigationBar().name().split("of")[0]);
	}
	
	//----------------------------------------------------------------------------------------
	//	Function: getCurrentCollectionPhotoCount
	//		Gets the number of photos of the "collection" (album/event/etc) that is currently
	//		being viewed
	//		
	//	Parameters: 
	//		None
	//		
	//	Returns: 
	//		An integer value for the total number of photos in the collection being 
	//				viewed
	//----------------------------------------------------------------------------------------
	photos.getPhotoCountForCollection = function getPhotoCountForCollection() {
		var maxAttempts = 10;
		for (var attempt = 0; attempt < maxAttempts && !this.navigationBar().isVisible(); attempt++) {
			UIALogger.logMessage("Attempting to bring up controls.");
			try {
				this.bringUpControls();
			} catch (e) {
				UIALogger.logMessage(e.message + ". Attempt # " + (attempt + 1));
			}
			//give the animation a chance to finish
			UIATarget.localTarget().delay(0.7);
		}
		
        return parseInt(this.navigationBar().name().split("of")[1]);
	}
	
	
	//----------------------------------------------------------------------------------------
	//	Function: playSlideshowForDuration
	//		Play a slideshow for duration.  
	//
	//	Parameters: 
	//		duration (int) - Optional.  Length of time to play the slideshow. If no duration is
	//			specified, the slideshow will play for 20 seconds.  
	//		
	//	Returns: 
	//		None
	//	
	//	Throws:
	//		An exception if the slideshow could not be played
	//
	//	Notes:
	//		A minimum playback duration	of 6 seconds is enforced to ensure that the 
	//		slideshow will progress at least 1 slide to try and minimize false negatives.
	//----------------------------------------------------------------------------------------
	photos.playSlideshowForDuration = function playSlideshowForDuration(duration) {
		var duration;
		var minPlaybackTime = 6;
		if (!duration) duration = 20;
		if (this.getPhotoCountForCollection() < 2)
			throw new Error("Not enough photos in collection to test slideshow");

		var startPhotoIndex	= photos.getCurrentPhotoIndex();
		UIALogger.logMessage("Starting photo index: " + startPhotoIndex);

		this._startSlideshow();
		UIALogger.logMessage("'Ere");		
		// Wait 6 seconds and check to see if the slideshow is playing
		UIATarget.localTarget().delay(minPlaybackTime);

		UIALogger.logMessage("Checking to see if playback has progressed.  Current index: " + photos.getCurrentPhotoIndex() + ".");		
        //<rdar://problem/9946976> Add workaround for slideshow navigation bar label bug <rdar://problem/9861997>
        // Let the controls disappear
        this.bringUpControls();
        UIATarget.localTarget().delay(5);
		if (startPhotoIndex == photos.getCurrentPhotoIndex())
			throw new Error("Slideshow playback has not progressed");

		this._startSlideshow();

		UIALogger.logMessage("Continuing slideshow for remaining duration: " + (duration - minPlaybackTime));
		UIATarget.localTarget().delay(duration - minPlaybackTime);        
		UIALogger.logMessage("Ending photo index: " + photos.getCurrentPhotoIndex());
		
		this.exitPhotoView();
	
		return;
			
	} // end photos.playSlideshowForDuration
	
	
	//----------------------------------------------------------------------------------------
	//	Function: randomCollectionFromTable
	//		This method will choose a random "collection" of photos(i.e., an album, event, etc) 
	//		from a table specified by the tab name.  For example, this method will
	//		randomly choose an event (the "collection") from the table specified by the 
	//		argument tabBarName
	//		
	//	Parameters: 
	//		tabBarName (string) - name of the tab to select from the tab bar (if available)
	//					Albums
	//					Events
	//					Faces
	//					Places
	//
	//	Optional Parameters:
	//		enforceMinimumPhotoCount (int) - require a selected album to have at least the
	//					MIN_PHOTO_COUNT number of photos
	//
	//	Returns: 
	//		Name of the random photo collection 
	// 
	//	Throws:
	//		An error if a video could not be chosen from the table
	//----------------------------------------------------------------------------------------
	photos.randomCollectionFromTable = function randomCollectionFromTable(viewName, options) {

		this.getToViewNamed(viewName);
		// Let any animations cease
		UIATarget.localTarget().delay(1);

		var count = this.mainWindow().tableViews()[0].cells().length;
		
		// Set the max number of attempts to find a random album
		var maxAttempts = count;
		var randomInt;
		var name;
		var albumPhotoCount = 0;

		// Look for a random photo album.  If the enforceMinimumPhotoCount option is set, keep trying for maxAttempts 
		// or until an album is found with enough photos
		for (var i = 0; i < maxAttempts; i++) {
			randomInt = system.randomInteger(0,count - 1);
			UIALogger.logMessage("Scrolling to row: " + randomInt + ". Total rows: " + count);
			this.mainWindow().tableViews()[0].cells()[randomInt].scrollToVisible();
			UIATarget.localTarget().delay(1);
			name = this.mainWindow().tableViews()[0].cells()[randomInt].name();
			var firstIndex = name.lastIndexOf("(");
			var lastIndex = name.lastIndexOf(")");
			albumPhotoCount = parseInt(name.substring(firstIndex + 1, lastIndex));
			if (!albumPhotoCount) albumPhotoCount = 0;
			if (!options || (options.enforceMinimumPhotoCount == 0)) {
				return name;
			} else if (options.enforceMinimumPhotoCount && (this.MIN_PHOTO_COUNT < albumPhotoCount)) {
				return name;
			}
			UIALogger.logMessage("Album " + name + " did not have enough photos to satisfy the minimum requirements. Number of photos in album: " + albumPhotoCount);
		}

		// This is a last-ditch effort to find an album with photos greater than the min photo count.
		// Iterate through all of the cells, looking for the first album with enough photos to 
		// satisfy the minimum photo count
		if (options && options.enforceMinimumPhotoCount) {
			for (var i = 0; i < count; i++) {
				this.mainWindow().tableViews()[0].cells()[i].scrollToVisible();
				UIATarget.localTarget().delay(1);
				name = this.mainWindow().tableViews()[0].cells()[i].name();
				var firstIndex = name.lastIndexOf("(");
				var lastIndex = name.lastIndexOf(")");
				albumPhotoCount = parseInt(name.substring(firstIndex + 1, lastIndex));
				if (!albumPhotoCount) albumPhotoCount = 0;
				if (albumPhotoCount > this.MIN_PHOTO_COUNT) return name;
				UIALogger.logMessage("Album " + name + " did not have enough photos to satisfy the minimum requirements. Number of photos in album: " + albumPhotoCount);
			}
		}
		
		throw new Error("Could not find an album to choose.");		
	}
	
	//----------------------------------------------------------------------------------------
	//	Function: randomPhotoFromCollection
	//		This method will choose a random photo from a table full of thumbnails
	//		
	//	Parameters: 
	//		None
	//		
	//	Returns: 
	//		Hash containing the index of the random row and column
	//----------------------------------------------------------------------------------------	
	photos.randomPhotoFromCollection = function randomPhotoFromCollection() {

		// Allow animations to cease
		var rowCount = this.mainWindow().tableViews()[0].cells().length;
		var randomRow = system.randomInteger(0, rowCount - 1);
		UIALogger.logMessage("Scrolling to row: " + randomRow);
        UIATarget.localTarget().delay(2);
		this.mainWindow().tableViews()[0].cells()[randomRow].scrollToVisible();

		
		var columnCount = this.mainWindow().tableViews()[0].cells()[randomRow].elements().length;
		var randomColumn = system.randomInteger(0, columnCount - 1);
		UIALogger.logMessage("Choosing column: " + randomColumn);
		return ({row:randomRow, column:randomColumn});
		
	}

	//----------------------------------------------------------------------------------------
	//	Function: randomTabBar
	//		This method will choose a random tab bar button to choose a photo collection from
	//		
	//	Parameters: 
	//		None
	//		
	//	Returns: 
	//		None
	//----------------------------------------------------------------------------------------	
	photos.randomTabBar = function randomTabBar() {
		var tabBar = this.mainWindow().tabBar();
		if (!tabBar.isValid() && !this.currentlyViewingPhoto()) {
			return;
		}
		var tabBarButtonCount = tabBar.buttons().length;
		var randomTabBarButtonIndex = system.randomInteger(0, tabBarButtonCount - 1);

		UIALogger.logMessage("Choosing : " + tabBar.buttons()[randomTabBarButtonIndex].name());
		tabBar.buttons()[randomTabBarButtonIndex].tap();		
	}
	
} // end photos
