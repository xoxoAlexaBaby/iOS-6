/*
 Class: UIApp (apstester)
 Settings object
 */
#import "../libs/SpringBoard.js"

apstester = UIAApp.application("APSTester", "com.apple.wumpus");

if (typeof apstester != 'undefined') {
	
	//----------------------------------------------------------------------------------------
	//	Private Function: waitForAlertWithTitle
	//		Disables auto alert handling, arms a timer, and calls a function.  After the
	//      function returns, the first alert is captured, and it's title is compared with the provided
	//      string.
	//
	//	Parameters: 
	//		timeout        (number)   The max time to wait for an alert to occur
	//      title          (string)   The title to match with the first alert presented
	//      actionFunction (function) The function to invoke immediately before expecting an alert
	//
	//	Returns: 
	//		None
	//	
	//	Throws:
	//		An exception if no alert is encountered or if the alert name does not match
	//----------------------------------------------------------------------------------------
	apstester.waitForAlertWithTitle = function waitForAlertWithTitle(timeout, title, actionFunction) {
		// disable auto alert handling and arm a time out
		UIATarget.disableOnAlert = 1;
		UIATarget.localTarget().pushTimeout(timeout);
		
		var actualAlertElement;
		
		// call our action
		try {
			actionFunction();
			
			actualAlertElement = apstester.alert();
		}
		finally {
			// pop our timeout and re-enable auto alert handling
			UIATarget.localTarget().popTimeout();
			UIATarget.disableOnAlert = 0;
		}
		
		if (!actualAlertElement.isValid())
			throw new Error("Did not get an alert result");
		
		var actualTitle = actualAlertElement.staticTexts()[0].name();
		
		// always dismiss the alert, even if titles end up mismatching
		actualAlertElement.buttons()[0].tap();
		
		if (actualTitle != title)
			throw new Error("Alert title did not match:" + actualTitle + " != " + title);
		
		UIALogger.logMessage("Titles match");
	} // end apstester.waitForAlertWithTitle
	
	//----------------------------------------------------------------------------------------
	//	Function: setDeviceName
	//		Enters a device name in the registration text field
	//
	//	Parameters: 
	//		name (string) - The name to use
	//
	//	Returns: 
	//		None
	//	
	//	Throws:
	//		None
	//----------------------------------------------------------------------------------------
	apstester.setDeviceName = function setDeviceName(name) {
		UIALogger.logMessage("Setting device name to: " + name);
		apstester.mainWindow().textFields()[0].setValue(name);
	} // end apstester.setDeviceName
	
	//----------------------------------------------------------------------------------------
	//	Function: deregister
	//		Enters a device name, and then presses the delete button
	//
	//	Parameters: 
	//		name (string) - The name to use for device de-registration
	//
	//	Returns: 
	//		None
	//	
	//	Throws:
	//		An exception if de-registration could not be completed
	//----------------------------------------------------------------------------------------
	apstester.deregister = function deregister(name) {
		this.launchIfNotActive();
		
		apstester.setDeviceName(name);
		
		apstester.waitForAlertWithTitle(30, "Request succeeded (HTTP/200)", function() {
			UIALogger.logMessage("Pressing Delete");
			apstester.mainWindow().buttons().firstWithName("Delete").tap();
		});
				
		UIALogger.logMessage("Reregistration completed");
	} // end apstester.deleteRegistration
		
	//----------------------------------------------------------------------------------------
	//	Function: register
	//		Enters a device name, deletes itself to be certain the registration will
	//		succeed, and then presses the registration button
	//
	//	Parameters: 
	//		name (string) - The name to use for device registration
	//
	//	Returns: 
	//		None
	//	
	//	Throws:
	//		An exception if registration could not be completed
	//----------------------------------------------------------------------------------------
	apstester.register = function register(name) {
		this.launchIfNotActive();
		
		try {
			apstester.deregister(name);
		} catch (e) {
			// silent catch, because deregister will throw an exception if the device is not registered in the
			// first place
		}
		
		apstester.waitForAlertWithTitle(30, "Registration Successful", function() {
			UIALogger.logMessage("Pressing Register");
			apstester.mainWindow().buttons().firstWithName("Register").tap();
		});
				
		UIALogger.logMessage("Reregistration completed");
	} // end apstester.deleteRegistration
	
	//----------------------------------------------------------------------------------------
	//	Function: publicToken
	//		Retrieve the APSTester public token
	//
	//	Parameters: 
	//		None
	//
	//	Returns: 
	//		The token as a string, or an empty string if it was unable to determine the token
	//	
	//	Throws:
	//		None
	//----------------------------------------------------------------------------------------
	apstester.publicToken = function publicToken() {
		var token = "";
		var staticText;
		
		this.launchIfNotActive();
		
		apstester.navigationBar().rightButton().tap();
		UIATarget.localTarget().delay(3);
		
		// we are looking for the public token, which is 64 characters long.
		// the positioning of this element is not predictible, but since there are
		// so few things on screen, this should be good enough
		
		staticText = apstester.mainWindow().staticTexts().firstWithPredicate("name.length == 64");
		if (staticText.isValid()) {
			token = staticText.name();
		}
		
		apstester.navigationBar().rightButton().tap();
		UIATarget.localTarget().delay(3);
		
		return token;
	}
	
	//----------------------------------------------------------------------------------------
	//	Function: EnablePushNotifications
	//		Launch APSTester and enable Push Notifications
	//
	//	Parameters: 
	//		None
	//
	//	Returns: 
	//		None
	//	
	//	Throws:
	//		None
	//----------------------------------------------------------------------------------------
	apstester.EnablePushNotifications = function EnablePushNotifications() {
		
		var pushNotificationAlertHandler = function(alert) { 
			if (alert.staticTexts().firstWithPredicate("name contains 'Would Like to Send You Push Notifications'").isValid()) { 
				UIALogger.logDebug("Selecting OK on the push notification alert");
				alert.buttons()["OK"].tap(); 
			} 
		};
		UIATarget.pushAlertHandler(pushNotificationAlertHandler);
		this.launchIfNotActive();
		UIATarget.popAlertHandler()
		
		var remoteNotificationSwitch = apstester.mainWindow().switches()[0];
		if (remoteNotificationSwitch.value() != "1") {
			UIALogger.logMessage("Setting Remote Notification Switch to 1...");
			//workaround for <rdar://problem/9385120> apster switches setValue("1"): 
			//unxpected error in -[UIASwitch_0x1f242500 setValue:], /SourceCache/UIAutomation/UIAutomation-143/Framework/UIAItemElements.m line 42
			//RemoteNotificationSwitch.setValue("1");
			remoteNotificationSwitch.tap();
			UIALogger.logMessage("Remote Notification Switch set to 1");
			
		} else {
			UIALogger.logMessage("Remote Notification switch already set to 1");
		}
		return;
	}
		
} // if (typeof apstester != 'undefined')
