#import "./Photos.js"
#import "../libs/PHTesting.js"



// --------------------------------------------------------------------------------
//	Function: photosTest_scrollThroughAPhotoAlbum
//		Scrolls randomly through a photo album.  Does not select any pictures, 
//		just scrolls up and down through list of photos.
//
//	Optional Parameters: 
//		viewName (string) - Name of the view to choose a photo collection from. 
//							If none is specified, non-iPad devices will select 
//							a collection from "Albums".
//			For example, 
//				Non-iPad: "Albums", "Events", "Faces", "Places"
//				iPad: "Photos", "Albums", "Events", "Faces"
//		photoCollectionName (string) - Name of photo album to scroll through.
//			If no name is given, it selects a random photo album.
//
//	Returns: 
//		1 if test passes, 0 if test fails. 
// --------------------------------------------------------------------------------
function photosTest_scrollThroughAPhotoAlbum() {
	var viewName = "Albums";
	var photoCollectionName = "";	

	if (this.argv.length > 0 && (this.argv[0] != null && this.argv[0] != "null")) viewName = this.argv[0];
	if (this.argv.length > 1 && (this.argv[1] != null && this.argv[1] != "null")) photoCollectionName = this.argv[1];

	photos.launchIfNotActive();
	
	// Check to see if there are indeed photos on the device
	if (!photos.checkForPhotosOrVideos()) {
		photos.mainWindow().logElementTree();
		this.testError = "No photos or videos on the device";
		return this.testResult = 0;
	}
	
	// Choose a random album if none was specified
	if (UIATarget.localTarget().model() != 'iPad') {
		if (!photoCollectionName) {
			photoCollectionName = photos.randomCollectionFromTable(viewName, {enforceMinimumPhotoCount:1});
		}

		photos.getToCollectionInView(photoCollectionName, viewName);
	} else {
		// Hacky way to deal with the fact that there's no easy way to determine
		// how many photos are in an album on iPad like there is on non-iPads
		// Go to the 'Photos' segmented control and scroll through that
		photos.getToViewNamed("Photos");
	}
	// Delay for animations
	UIATarget.localTarget().delay(2);
	
	photos.scrollPhotoCollection();
	
	return this.testResult = 1;
	
} // end photosTest_scrollThroughAPhotoAlbum

// --------------------------------------------------------------------------------
//	Function: photosTest_viewSomePicturesFromAPhotoAlbum 
//		View some pictures in a photo album
//
//	Optional Parameters: 
//		tabBarName (string) - Name of the tab to choose a photo collection from.  
//			For example, 
//				Non-iPad: "Albums", "Events", "Faces", "Places"
//				iPad: "Photos", "Albums", "Events", "Faces"
//		photoCollectionName (string) - Name of photo album to view. If no name
//			is given, it selects a random photo album.
//		numberOfPhotosToView (int) - Number of photos to view.  If no number
//			is specified, 5 photos will be selected
//
//	Returns: 
//		1 if test passes, 0 if test fails. 
// --------------------------------------------------------------------------------
function photosTest_viewSomePicturesFromAPhotoAlbum() {
	var viewName = "Albums";
	var photoCollectionName = "";
	var numberOfPhotosToView = 5;

	if (this.argv.length > 0 && (this.argv[0] != null && this.argv[0] != "null")) viewName = this.argv[0];
	if (this.argv.length > 1 && (this.argv[1] != null && this.argv[1] != "null")) photoCollectionName = this.argv[1];
	if (this.argv.length > 2 && (this.argv[2] != null && this.argv[2] != "null")) numberOfPhotosToView = this.argv[2];	
	
	photos.launchIfNotActive();

	// If no album name was specified, get a random album.  
	if (!photoCollectionName) {
		if (UIATarget.localTarget().model() != 'iPad') {
			photoCollectionName = photos.randomCollectionFromTable(viewName, {enforceMinimumPhotoCount:1});
		} else {
			photoCollectionName = photos.randomCollectionFromTable(viewName, {enforceMinimumPhotoCount:0});
		}
	}

	photos.getToCollectionInView(photoCollectionName, viewName);

	for (var i = 0; i < numberOfPhotosToView; i++ ) {
		photos.exitPhotoView();

		var randomPhotoRowColumn = photos.randomPhotoFromCollection();

		photos.selectPhoto({row:randomPhotoRowColumn.row, column:randomPhotoRowColumn.column});
		
	}

	return this.testResult = 1;
	
} // end photosTest_viewSomePicturesFromAPhotoAlbum



// --------------------------------------------------------------------------------
//	Function: photosTest_playPhotoAlbumSlideshow 
//		Play a photo album slideshow for a given amount of time.  
//
//	Optional Parameters: 
//		photoCollectionName (string) - Name of photo album to view (optional).
//			If no name is given, it selects a random photo album.
//		duration (int) - Number of seconds to play the slideshow for. If no 
//			duration is specified, a duration between 15 and 60 seconds will 
//			be selected.
//
//	Returns: 
//		1 if test passes, 0 if test fails. 
//	
// --------------------------------------------------------------------------------
function photosTest_playPhotoAlbumSlideshow() {
	var viewName = "Albums";
	var photoCollectionName = "";
	var duration;
	
	if (this.argv.length > 0 && (this.argv[0] != null && this.argv[0] != "null")) photoCollectionName = this.argv[0];	
	if (this.argv.length > 1 && (this.argv[1] != null && this.argv[1] != "null")) duration = parseInt(this.argv[1]);	
	
	// Pick a random duration if none is specified
	if (!duration) duration = system.randomInteger(15, 60);
	
	photos.launchIfNotActive();
	
	// Choose a random album if none is specified
	if (!photoCollectionName) {
		if (UIATarget.localTarget().model() != 'iPad') {
			photoCollectionName = photos.randomCollectionFromTable(viewName, {enforceMinimumPhotoCount:1});
		} else {
			photoCollectionName = photos.randomCollectionFromTable(viewName, {enforceMinimumPhotoCount:0});
		}
		
	}
	
	photos.getToCollectionInView(photoCollectionName, viewName);

	var randomPhotoRowColumn = photos.randomPhotoFromCollection();
	
	photos.selectPhoto({row:randomPhotoRowColumn.row, column:randomPhotoRowColumn.column});
	
	photos.playSlideshowForDuration(duration);

	return this.testResult = 1;
		
} // end photosTest_playPhotoAlbumSlideshow


//----------------------------------------------------------------------------------------
//	Function: photosTest_emailPhoto 
//		This is a test that emails a photo.
//
//	Optional Parameters
//		to (string)			- the email address for the reciever - defaults to: weliketesting@me.com
//				
//		subject (string)	- the subject line to use for the email - defaults to: "Where's Chuck?"
//
//		photoCollectionName (string) - the name of the photo collection to send from - a random 
//			collection will be chosen if none is specified
//
//	Returns: 
//		1 if test passes, 0 if it fails
//
//----------------------------------------------------------------------------------------
function photosTest_emailPhoto() {
	var viewName = "Albums";
	var photoCollectionName = "";
	
	var email = new Object();
	
	email.to = (this.argv.length > 0) ? this.argv[0] : "weliketesting@me.com";
	email.subject = (this.argv.length > 1) ? this.argv[1] : "Where's Chuck?";
	
	if (this.argv.length > 2) { photoCollectionName = this.argv[0]; }
	
	photos.launchIfNotActive();
	
	if (!photoCollectionName) {
		if (UIATarget.localTarget().model() != 'iPad') {
			photoCollectionName = photos.randomCollectionFromTable(viewName, {enforceMinimumPhotoCount:1});
		} else {
			photoCollectionName = photos.randomCollectionFromTable(viewName, {enforceMinimumPhotoCount:0});
		}
	}
	
	photos.getToCollectionInView(photoCollectionName, viewName);

	var randomPhotoRowColumn = photos.randomPhotoFromCollection();

	photos.selectPhoto({row:randomPhotoRowColumn.row, column:randomPhotoRowColumn.column});

	UIATarget.localTarget().delay(1);
	try {
		photos.selectPhotoAction("Email Photo");
	} catch (e) {
		photos.logElementTree();
		this.testError = "Could not find the 'Email Photo' button in the action sheet.  Are there email accounts set up on the device?";
		return this.testResult = 0;
	}
		
	UIALogger.logMessage("Sending email with subject '" + email.subject + "'.");

	UIATarget.localTarget().delay(1);	
    UIATarget.localTarget().pushTimeout(15);
    var sendButton = photos.mainWindow().navigationBar().buttons().firstWithName("Send");
    if (!sendButton.isVisible()) throw new Error("'Send' button is not visible onscreen");
    UIATarget.localTarget().popTimeout();
	photos.composeEmail({to:email.to, subject:email.subject});
	sendButton.tap();
	
	UIALogger.logMessage("No verification performed -- email may or may not have been sent");
	
	return this.testResult = 1;

} // end photosTest_emailPhoto

//----------------------------------------------------------------------------------------
//	Function: photosTest_printPhoto 
//		This is a test that prints a photo.
//
//	Optional Parameters
//		printerName (string) - optional - the name of the printer. If no value is specified, 
//			a random printer is selected.
//				
//		numberOfCopies (number)	- optional - the number of copies to print
//
//		photoCollectionName (string) - the name of the photo collection to print from - a random 
//			collection will be chosen if none is specified
//
//	Returns: 
//		1 if test passes, 0 if it fails
//
//----------------------------------------------------------------------------------------
function photosTest_printPhoto() {
	
	var viewName = "Albums";
	var photoCollectionName = "";
	
	var options = new Object();
	if (this.argv.length > 0 && this.argv[0] != "null") options.printerName = this.argv[0];
	if (this.argv.length > 1 && this.argv[1] != "null") options.numberOfCopies = this.argv[1];
	if (this.argv.length > 2 && this.argv[2] != "null") { photoCollectionName = this.argv[2]; }
	
	photos.launchIfNotActive();
	
	if (!photoCollectionName) {
		if (UIATarget.localTarget().model() != 'iPad') {
			photoCollectionName = photos.randomCollectionFromTable(viewName, {enforceMinimumPhotoCount:1});
		} else {
			photoCollectionName = photos.randomCollectionFromTable(viewName, {enforceMinimumPhotoCount:0});
		}
	}
	
	photos.getToCollectionInView(photoCollectionName, viewName);
	if (!photos.navigationBar().withName(photoCollectionName).isValid()) 
		UIALogger.logWarning("Nav bar label did not change to " + photoCollectionName);
	
	var randomPhotoRowColumn = photos.randomPhotoFromCollection();
	
	photos.selectPhoto({row:randomPhotoRowColumn.row, column:randomPhotoRowColumn.column});
	
	UIATarget.localTarget().delay(1);
	try {
		photos.selectPhotoAction("Print");
	} catch (e) {
		UIALogger.logError(e);
		photos.logElementTree();
		this.testError = "Could not find the 'Print' button in the action sheet.";
		return this.testResult = 0;
	}
	
	photos.printWithOptions(options);
	
	return this.testResult = 1;
	
} // end photosTest_printPhoto


//----------------------------------------------------------------------------------------
//	Function: photosTest_assignPhotoToContact
//		This is a test that emails a photo.
//
//	Optional Parameters:	
//		tabBarName (string)	- the name of the tab to choose a collection from - defaults to 'Albums'
//		photoCollectionName (string) - the name of the photo collection to send from - a random 
//			collection will be chosen if none is specified
//		contactName (string) - the name of the contact to assign photo - a random contact
//			will be selected if none is specified
//		shouldValidate (bool) - the test will not validate the 
//
//	Returns: 
//		1 if test passes, 0 if it fails
//
//----------------------------------------------------------------------------------------
function photosTest_assignPhotoToContact() {
	var viewName = "Albums";
	var photoCollectionName = "";
	var contactName = "";
	var shouldValidate = false;
	
	if (this.argv.length > 0 && (this.argv[0] != null && this.argv[0] != "null")) { viewName = this.argv[0]; }
	if (this.argv.length > 1 && (this.argv[1] != null && this.argv[1] != "null")) { photoCollectionName = this.argv[1]; }
	if (this.argv.length > 2 && (this.argv[2] != null && this.argv[2] != "null")) { contactName = this.argv[2]; }	
	if (this.argv.length > 3 && (this.argv[3] != null && this.argv[3] != "null")) { shouldValidate = this.argv[3]; }	
	
	photos.launchIfNotActive();
	
	if (!photoCollectionName) {
		if (UIATarget.localTarget().model() != 'iPad') {
			photoCollectionName = photos.randomCollectionFromTable(viewName, {enforceMinimumPhotoCount:1});
		} else {
			photoCollectionName = photos.randomCollectionFromTable(viewName, {enforceMinimumPhotoCount:0});
		}
	}

	photos.getToCollectionInView(photoCollectionName, viewName);
	
	// Choose a random photo
	var randomPhotoRowColumn = photos.randomPhotoFromCollection();
	
	photos.selectPhoto({row:randomPhotoRowColumn.row, column:randomPhotoRowColumn.column});
	
	UIATarget.localTarget().delay(1);	
	try {
		photos.selectPhotoAction("Assign to Contact");
	} catch(e) {
		photos.mainWindow().logElementTree();
		this.testError = "'Assign to Contact' not found - are there any contacts on the device?";
		return this.testResult = 0;
	}
	
	var contactsTable;

	if (UIATarget.localTarget().model() != 'iPad') {
		contactsTable = photos.mainWindow().tableViews()[0];
	} else {
		contactsTable = photos.mainWindow().popover().tableViews()[0];
	}
	
	if (!contactsTable.isValid()) throw new Error ("Could not find contacts table");
	
	// Select a random contact if needed
	if (!contactName) {
		var contactsTableLength = contactsTable.cells().length;
		var randomIndex = system.randomInteger(0,contactsTableLength - 1);
		contactName = contactsTable.cells()[randomIndex].name();
	}
	
	UIALogger.logMessage("Assigning photo to contact: '" + contactName + "'.");	
	
	var contactCell;
	if (UIATarget.localTarget().model() != 'iPad') {
		contactCell = photos.mainWindow().tableViews()[0].scrollToElementWithName(contactName);
	} else {
		contactCell = photos.mainWindow().popover().tableViews()[0].scrollToElementWithName(contactName);
	}
	contactCell.tap();

	//Allow animation to finish
	UIATarget.localTarget().delay(1);
	if (contactCell.isVisible()) {
		this.testError = "Contact list did not disappear";
		return this.testResult = 0;
	}
	if (UIATarget.localTarget().model() != 'iPad') {
		photos.mainWindow().buttons().firstWithName("Set Photo").tap();
	} else {
		photos.mainWindow().popover().navigationBar().buttons().firstWithName("Use").tap();
	}
	
	if (shouldValidate) {
		addressbook.launchIfNotActive();

		addressbook.getToContactsList();
		addressbook.selectContact(contactName);
		
		var contactPhoto;
		if (UIATarget.localTarget().model() != 'iPad') {
			contactPhoto = addressbook.mainWindow().tableViews().firstWithPredicate("isVisible == 1").images().firstWithName("Photo of " + contactName);
		} else {
			contactPhoto = addressbook.mainWindow().images().firstWithName("Photo of " + contactName);
		}
		if (!contactPhoto.isValid()) {
			this.testError = "Could not verify that the photo was added to the contact";
			return this.testResult = 0;
		} else {
			UIALogger.logMessage("Found a photo associated with contact " + contactName);
		}
	}
	
	return this.testResult = 1;

} // end photosTest_assignPhotoToContact


// Create self tests -- this is an unnamed function, just to make sure any local variables stay in the correct context
(function() {	
	
	if (typeof photos.selfTests == 'undefined') {
		photos.selfTests = new Array();
	}
	// Need to put pictures on the device for these tests to pass
	photos.selfTests.push(phtCreateTest("ScrollThroughAPhotoAlbum", null, photosTest_scrollThroughAPhotoAlbum, "Scroll Through Random Photo Album"));
	photos.selfTests.push(phtCreateTest("ViewSomePicturesFromAPhotoAlbum", [null, null, 10], photosTest_viewSomePicturesFromAPhotoAlbum, "Scroll Through Pictures in a Photo Album"));
	photos.selfTests.push(phtCreateTest("PlayPhotoAlbumSlideshow", [null, 30], photosTest_playPhotoAlbumSlideshow, "Play Slideshow for 30 Seconds")); 
	photos.selfTests.push(phtCreateTest("EmailPhoto", ["weliketesting@me.com", "Self Test Camera Email"], photosTest_emailPhoto, "Send an image from Photos through mail")); 
	if (system.hasCapability("multitasking")) {
		photos.selfTests.push(phtCreateTest("PrintPhoto", ["dailyQLAutomation"], photosTest_printPhoto, "Print a photo from Photos")); 
	}
	photos.selfTests.push(phtCreateTest("AddPhotoToContact", [null, null, null, true], photosTest_assignPhotoToContact, "Assign a photo to a contact")); 
}())
