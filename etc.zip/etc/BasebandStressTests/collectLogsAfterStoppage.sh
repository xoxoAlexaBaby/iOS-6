#!/bin/sh

StressTestDir=$1
DEVICENAME=`hostname`
APBuild=`/usr/local/bin/lockdown_query get NULL BuildVersion 2>&1`
if [ $APBuild == "5H11" ]; then 
	PowerLogsPath="/var/mobile/Library/Logs/CrashReporter/"; 
else
	PowerLogsPath="/Library/Logs/CrashReporter/"; 	
fi

BB_Build=`/usr/local/bin/lockdown_query get NULL BasebandVersion 2>&1`
dir="/var/root"
myDate=`perl -e '($s,$m,$H,$d,$M) = localtime(); $Y += 1900; $M++; printf ("%02d%02d-%02d%02d",$M,$d,$H,$m); ' `

File="/$dir/alloutputs-$BB_Build-$DEVICENAME-$myDate.txt"
date >> $File

echo "***************************************************************** " >> $File
echo " Tailed output of nohup.out -> 500 lines.\n\n" >> $File
tail -500 $StressTestDir/nohup.out >> $File
echo "***************************************************************** " >> $File
echo "*****************************************************************\n" >> $File


echo "***************************************************************** " >> $File
history | tail -50 >> $File
echo  >> $File
ps -A >> $File
echo "*****************************************************************\n" >> $File

echo "\n\n#################################################################### " >> $File
echo " Output of POWER Logs from Starting..." >> $File
head -100 $PowerLogsPath/Power* >> $File
echo " Output of POWER Logs from End (last 100 lines)..." >> $File
tail -100 $PowerLogsPath/Power* >> $File
echo "####################################################################\n" >> $File


echo "***************************************************************** " >> $File
echo  >> $File
date >> $File
tail -1 /var/root/ipc*Stats* >> $File
echo "***************************************************************** " >> $File


echo "#################################################################### " >> $File
echo " Output of Panic Logs...." >> $File
cat /Library/Logs/CrashReporter/Panics/* >> $File
ls -rlt /Library/Logs/CrashReporter/Panics/* >> $File
echo "\n ls of CrashReporter/" >> $File
ls -rlt /Library/Logs/CrashReporter/ >> $File
echo "\n Is there any Low Battery Logs ??????? " >> $File
ls -rlt /var/mobile/Library/Logs/CrashReporter/Low* >> $File
echo "####################################################################\n" >> $File


echo "***************************************************************** " >> $File
ls -rlt /Library/Logs/CrashReporter/Baseband/*csi*  >> $File
head -1 /Library/Logs/CrashReporter/Baseband/*csi*  >> $File
head -1 /Library/Logs/CrashReporter/Baseband/*csi* | grep Reason:  >> $File
echo "***************************************************************** " >> $File


echo " OUTPUT FILE GENERATED for $DEVICENAME."
echo  " Check $DEVICENAME - $File for all the required outputs.\n"