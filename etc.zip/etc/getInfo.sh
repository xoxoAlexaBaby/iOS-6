#!/bin/sh

#################################################################################################
#                                                                                               #
#   ScriptName: getInfo.sh                                                                      #
#                                                                                               #
#   Purpose:    Script to get the Ph numbers and version strings                                #
#   Author:     Jerome Jesu                                                                     #
#   Contact:    jesu@apple.com                                                                  #
#   Version:    v20                                                                             #
#                                                                                               #
#   Copyright   2010 Apple. All rights reserved.                                                #
#################################################################################################


### GET THE DEVICE Phone Number for SMS  if not Provided
sNumber=`echo $smsNumber | perl -lne ' s/[+]//g; if (/\D/g || $_ !~ /^\s+$/) { print "0";} else { print "1";}' `
PhoneNumber=`/usr/local/bin/lockdown_query get NULL PhoneNumber 2>&1 | perl -lne 's/[(]|[)]|\s+|[-]//g; s/^([1])(.*)$/+$1$2/; print;' `
flag=`echo $PhoneNumber | perl -lne ' s/[+]//g; if (/^\d{6,12}$/ && $_ !~ /[0]{6,}/ && $_ !~ /^\s+$/) { print "1";} else { print "0";}' `

if [ $flag -eq 1 ];  then  
	SMS_NUMBER=$PhoneNumber; 
elif [ $flag -eq 0 ] && [ $sNumber -eq 1 ];  then  
	SMS_NUMBER=$smsNumber; 
else 
	dontSendSMS=1;
	SMS_NUMBER=1111111111;
fi


### Enabling Upload
if [ "$UPLOAD" ] ;  then   		
		echo "Uploading option -u is specified.";
		
		if [ "$isSSID" ] && [ "$key" ]; then  
			echo "Logs will be uploaded to $SSID - $WEPKEY. Security chosen - $SECURITY.";
		else
			# change the Defaults if needed.
			SSID=$DEFAULT_SSID ; 	
			WEPKEY=$DEFAULT_WEP_KEY;
			SECURITY=$DEFAULT_SECURITY;
			echo "Logs will be uploaded to $SSID - $WEPKEY.";
		fi
		echo "DEFAULT_SSID=\"$SSID\"" >  $SCRIPTS_DIR/WiFiSettings.sh
		echo "DEFAULT_WEP_KEY=\"$WEPKEY\"" >> $SCRIPTS_DIR/WiFiSettings.sh
		echo "DEFAULT_SECURITY=\"$SECURITY\"" >> $SCRIPTS_DIR/WiFiSettings.sh
		echo "SERVER_ADDR=\"$SERVER_ADDR\"" >> $SCRIPTS_DIR/WiFiSettings.sh
fi


###########################################################################
# Function to get the Version Numbers of AP and Baseband Firmware
###########################################################################
getBuildVersions()
{
	# GET ALL REQUIRED DEVICE INFOS
	Hardware=`/usr/local/bin/lockdown_query get NULL HardwareModel 2>&1 | cut -c1-3`
	
	if [ $Hardware == "N92" ] || [ $Hardware == "K95" ]; then
		MEID=`grep IMEI BBVersion.txt | head -1 | awk '{print $2}' | perl -lne 's/\[|\]//g; print;'`
	else
		MEID=`grep MEID BBVersion.txt | head -1 | awk '{print $2}' | perl -lne 's/\[|\]//g; print;'`
	fi
	
	#Baseband=`perl -lne 'if (/\QFirmware Version\E/ ) { $vers = (split /\s+/)[-1]; $vers =~ s/\[|\]//g;  print "$vers" }' BBVersion.txt`
	SNUM=`grep BasebandSerialNumber BBVersion.txt | perl -lne '$chip = (split /\s+/)[-1]; $chip =~ s/;|<|>//g; print $chip;'`
	APBuild=`sw_vers -buildVersion`	
	echo "2. Baseband -- $BB\n"
	
	UDID=`/usr/local/bin/lockdown_query get NULL UniqueDeviceID 2>&1`
	SERIAL=`/usr/local/bin/lockdown_query get NULL SerialNumber 2>&1`
	isSERIAL=`echo $SERIAL | perl -lne ' if (/^$/) {print 0} else {print 1};'`
	
	if [ $DEVICENAME == "iPhone" ] || [ $DEVICENAME == "iPad" ]; then  DEVICENAME=$SMS_NUMBER; fi

	if [ $round -eq 1 ]; then
		BB_Build="$BB-${RAT}_$ROUNDINFO"
	else
		BB_Build="$BB-${RAT}"; 
	fi

	serverDir=`echo "${Hardware}-${BB_Build}" | perl -lne '($d,$M,$Y) = (localtime())[3,4,5]; $Y = $Y + 1900; $M++; s/[.]//g; printf ("IPC_%s_%04d%02d%02d",$_,$Y,$M,$d)'`
	echo "*** ServerDir = $serverDir";
}

