#import "UIAAppStressLibrary.js"

var locations = new Array("Infinite Loop California", "George, WA", "Washington DC", "Sears Tower", "Paris", "Rome", "Osaka, Japan");
var repeatList = new Array("None", "Every Day", "Every Week", "Every 2 Weeks", "Every Month", "Every Year");

if (typeof calendar != 'undefined') {
	calendarStress = AppStressBase.stressTest('Calendar');
	
	if (typeof calendarStress != 'undefined') {
		calendarStress.eventList = new Array();
		
		calendarStress.setup = function setup() {
			calendarStress.addTest(calendarStress._addEvent);
			calendarStress.addTest(calendarStress._deleteEvent);
			calendarStress.addTest(calendarStress._navigateBetweenViews);
		}
		
		
		calendarStress.run = function run() {
			calendarStress.executeRandomTests(4);
		}
		
		
		// add event
		calendarStress._addEvent = function _addEvent() {
			var title = getRandomMessage(1, 3, 1, 10, true);
			var loc = UIAUtility.randomFromArray(locations);
			var notes = getRandomMessage(0, 50, 1, 32);
			var date = new Date();
			var result;
			
			date.setDate(date.getDate() + system.randomInteger(1, 10));
			
			result = calendarStress.executeTest( "AddEvent", [ title, loc, null, UIAUtility.randomFromArray(repeatList), notes ],
												 calTest_addEvent, "Add a new event to the calendar." );
			
			if (result) { calendarStress.eventList[title] = loc };
			
			return result;
		}
			
		// delete event
		calendarStress._deleteEvent = function _deleteEvent() {
			var title;
			var result;
			
			if (calendarStress.eventList.length == 0) {
				if (!calendarStress._addEvent()) {
					UIALogger.logError("No events to delete and unable to add one -- skipping test.");
					return false;
				}				
			}
			
			title = UIAUtility.randomFromArray(keys(calendarStress.eventList));
			
			result = calendarStress.executeTest( "DeleteEvent", [ title ], 
												 calTest_deleteCalendarEvent, "Delete event with title " + title + " event from the calendar." );
			
			if (result) { delete calendarStress.eventList[title] }
			
			return result;
		}

		// navigate between views
		calendarStress._navigateBetweenViews = function _navigateBetweenViews() {
			var view = UIAUtility.randomFromArray(["Month", "Day", "List"]);
			
			calendarStress.executeTest( "NavigateBetweenViews", [ view ], 
										calTest_navigateBetweenViews, "Navigate between calendar views." );
		}
	}
}