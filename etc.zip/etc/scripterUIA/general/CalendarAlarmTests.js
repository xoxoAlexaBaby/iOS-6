#!/usr/local/bin/scripter -uiautomation YES -f

#import "../libs/PHTesting.js"
#import "../libs/HarnessUtility.js"
#import "../calendar/CalendarTests.js"
#import "../settings/SettingsTests.js"

var kReportPath = "/var/mobile/Library/Logs/Testing/";
var start = new Date();
var timeString = start.getTime() + "";  // turn this into a string
var runID = "AlarmTests " + start.toDateString() + " - " + timeString.substr(-6);

var kSameDayAlertOptions = ["5 minutes before", "15 minutes before", "30 minutes before", "1 hour before", "2 hours before"];
var kDayOfEventAlarmOption = "On date of event";
var k1DayBeforeAlarmOptions = "1 day before";
var k2DaysBeforeAlarmOptions = "2 days before";

var kBasicAlarmStartDate = "2011:01:01";
var kBasicAlarmEndDate = "2011:01:02";
var kBasicAlarmSystemTime = "00:00";
var kBasicAlarmEventStartTime = "08:00";
var currentPosition = 0;

var kTimeZones = new Array();
var kDSTTranstionDates = ["2011:03:13:03:00", "2011:11:06:01:00", "2012:03:11:03:00", "2012:11:04:01:00", "2013:03:10:03:00", "2013:11:03:01:00", 
						  "2014:03:09:03:00", "2014:11:02:01:00", "2015:03:08:03:00", "2015:11:01:01:00", "2016:03:13:03:00", "2016:11:06:01:00"];
kTimeZones[0] = {name:"Cupertino", id:"America/Los_Angeles", transitionDates:kDSTTranstionDates};
kTimeZones[1] = {name:"Phoenix", id:"America/Phoenix", transitionDates:kDSTTranstionDates};

var kDefaultTimeZone = kTimeZones[0];
var kDSTSystemTimeOffset = ":::-5";
var kDSTAlarmTimeOffset = ":::+5";

var kLeapYears = ["2012", "2016", "2020", "2024", "2028", "2032", "2036"];
var kLeapYearAlarmEventStartTime = "08:00";
var kLeapYearAlarmSystemTime = "00:00";
var kLeapYearAlarmSystemDayAndMonth = "01:01";

function getNextAlertOption() {
	return kSameDayAlertOptions[currentPosition++ % kSameDayAlertOptions.length];
}

function _createCalendarTest(testType, alarmOption, systemTime, alarmTime, timezone, baseTime) {
	var alarmOptionString;
	var eventStartTimeDateString;
	if (!baseTime) baseTime = systemTime;
	
	if (kSameDayAlertOptions.indexOf(alarmOption) >= 0) {
		alarmOptionString = "SameDay";
		eventStartTimeDateString = baseTime.getFullYear() + ":" + (baseTime.getMonth() + 1) + ":" + baseTime.getDate() + ":" + alarmTime;
	} else if (alarmOption == kDayOfEventAlarmOption) {
		alarmOptionString = "DayOfEvent";
		eventStartTimeDateString = baseTime.getFullYear() + ":" + (baseTime.getMonth() + 1) + ":" + baseTime.getDate() + ":" + alarmTime;
	} else if (alarmOption == k1DayBeforeAlarmOptions) {
		alarmOptionString = "1DayBefore";
		var eventStartDateObject = UIADate.dateWithDateStringInTimeZone(baseTime.getDateString(), baseTime.timeZone);
		eventStartDateObject.setDate("+1");
		eventStartTimeDateString = eventStartDateObject.getFullYear() + ":" + (eventStartDateObject.getMonth() + 1) + ":" + eventStartDateObject.getDate() + ":" + alarmTime;
	} else if (alarmOption == k2DaysBeforeAlarmOptions) {
		alarmOptionString = "2DaysBefore";
		var eventStartDateObject = UIADate.dateWithDateStringInTimeZone(baseTime.getDateString(), baseTime.timeZone);
		eventStartDateObject.setDate("+2");
		eventStartTimeDateString = eventStartDateObject.getFullYear() + ":" + (eventStartDateObject.getMonth() + 1) + ":" + eventStartDateObject.getDate() + ":" + alarmTime;
	} else
		throw new Error("Unexpected alarmOption:" + alarmOptionString + " for test type " + testType);
	
	var testName, testDescription, title, testArgs;
	testDescription = "Add a new event on " + systemTime.toString() + " with alert option set to " + alarmOption;
	testArgs = ["systemDate:"+systemTime.getDateString(), "startTime:"+eventStartTimeDateString, "alertReminder:"+alarmOption];
	if (testType == "Basic") {
		testName = testType + alarmOptionString + "AlarmTest";
		title = testName + " for " + systemTime.toString();
		testArgs.push("title:"+title);
	} else if (testType == "DST") {
		testName = testType + alarmOptionString + systemTime.getFullYear() + "For" + timezone;
		title = testName;	
		testArgs.push("timezone:" + timezone);
		testArgs.push("title:"+title);
	} else if (testType == "LeapYear") {
		testName = testType + alarmOptionString + systemTime.getFullYear();
		title = testName;
		testArgs.push("title:"+title);
	} else { 
		throw new Error("Unexpected test type:" + testType);
	}
	
	return (phtCreateTest(testName, testArgs, calTest_addEventAndValidateAlert, testDescription));
}
		
		
			
function addTestsToArray(tests) {
	if ((typeof calendar != 'undefined') && springboard.displaysApp(calendar)) {
	
		
		//Basic Alarm Testing
		
		//Same day
		var currentDate = UIADate.dateWithDateString(kBasicAlarmStartDate + ":" + kBasicAlarmSystemTime);
		var endDate = UIADate.dateWithDateString(kBasicAlarmEndDate + ":" + kBasicAlarmSystemTime);
		do {
			var alertOption = getNextAlertOption();
			tests.push(_createCalendarTest("Basic", alertOption, currentDate, kBasicAlarmEventStartTime));
			currentDate.setWithOptions({date:"+1"});
		} while (currentDate.getTime() < endDate.getTime());
		
		//Day of event
		currentDate = UIADate.dateWithDateString(kBasicAlarmStartDate + ":" + kBasicAlarmSystemTime);
		endDate = UIADate.dateWithDateString(kBasicAlarmEndDate + ":" + kBasicAlarmSystemTime);
		do {
			var alertOption = kDayOfEventAlarmOption;
			tests.push(_createCalendarTest("Basic", alertOption, currentDate, kBasicAlarmEventStartTime));
			currentDate.setWithOptions({date:"+1"});
		} while (currentDate.getTime() < endDate.getTime());
		
		//1 day before
		currentDate = UIADate.dateWithDateString(kBasicAlarmStartDate + ":" + kBasicAlarmSystemTime);
		endDate = UIADate.dateWithDateString(kBasicAlarmEndDate + ":" + kBasicAlarmSystemTime);
		do {
			var alertOption = k1DayBeforeAlarmOptions;
			tests.push(_createCalendarTest("Basic", alertOption, currentDate, kBasicAlarmEventStartTime));
			currentDate.setWithOptions({date:"+1"});
		} while (currentDate.getTime() < endDate.getTime());
		
		//2 days before
		currentDate = UIADate.dateWithDateString(kBasicAlarmStartDate + ":" + kBasicAlarmSystemTime);
		endDate = UIADate.dateWithDateString(kBasicAlarmEndDate + ":" + kBasicAlarmSystemTime);
		do {
			var alertOption = k2DaysBeforeAlarmOptions;
			tests.push(_createCalendarTest("Basic", alertOption, currentDate, kBasicAlarmEventStartTime));
			currentDate.setWithOptions({date:"+1"});
		} while (currentDate.getTime() < endDate.getTime());
		
		//DST Testing
		tests.push("DST Testing");
		for (var j=0; j<kTimeZones.length; j++) {
			//Same day
			for (var i=0; i<kTimeZones[j].transitionDates.length; i++) {
				var alertOption = getNextAlertOption();
				
				var dstDate = UIADate.dateWithDateStringInTimeZone(kTimeZones[j].transitionDates[i], kTimeZones[j].id);
				var systemDate = UIADate.dateWithDateStringInTimeZone(kTimeZones[j].transitionDates[i], kTimeZones[j].id);
				systemDate.setWithOptions({dateString:kDSTSystemTimeOffset});
				var alarmDate = UIADate.dateWithDateStringInTimeZone(kTimeZones[j].transitionDates[i], kTimeZones[j].id); 
				alarmDate.setWithOptions({dateString:kDSTAlarmTimeOffset});
				var alarmTime = alarmDate.getHours() + ":" + alarmDate.getMinutes();
				
				tests.push(_createCalendarTest("DST", alertOption, systemDate, alarmTime, kTimeZones[j].name, alarmDate));
			}

			//Day of event
			for (var i=0; i<kTimeZones[j].transitionDates.length; i++) {
				var alertOption = kDayOfEventAlarmOption;
				
				var dstDate = UIADate.dateWithDateStringInTimeZone(kTimeZones[j].transitionDates[i], kTimeZones[j].id);
				var systemDate = UIADate.dateWithDateStringInTimeZone(kTimeZones[j].transitionDates[i], kTimeZones[j].id);
				systemDate.setWithOptions({dateString:kDSTSystemTimeOffset});
				var alarmDate = UIADate.dateWithDateStringInTimeZone(kTimeZones[j].transitionDates[i], kTimeZones[j].id); 
				alarmDate.setWithOptions({dateString:kDSTAlarmTimeOffset});
				var alarmTime = alarmDate.getHours() + ":" + alarmDate.getMinutes();
				
				tests.push(_createCalendarTest("DST", alertOption, systemDate, alarmTime, kTimeZones[j].name, alarmDate));
			}
			
			//1 day before
			for (var i=0; i<kTimeZones[j].transitionDates.length; i++) {
				var alertOption = k1DayBeforeAlarmOptions;
				
				var dstDate = UIADate.dateWithDateStringInTimeZone(kTimeZones[j].transitionDates[i], kTimeZones[j].id);
				var systemDate = UIADate.dateWithDateStringInTimeZone(kTimeZones[j].transitionDates[i], kTimeZones[j].id);
				systemDate.setWithOptions({dateString:kDSTSystemTimeOffset});
				var alarmDate = UIADate.dateWithDateStringInTimeZone(kTimeZones[j].transitionDates[i], kTimeZones[j].id); 
				alarmDate.setWithOptions({dateString:kDSTAlarmTimeOffset});
				var alarmTime = alarmDate.getHours() + ":" + alarmDate.getMinutes();
				
				tests.push(_createCalendarTest("DST", alertOption, systemDate, alarmTime, kTimeZones[j].name, alarmDate));
			}
			
			//2 days before
			for (var i=0; i<kTimeZones[j].transitionDates.length; i++) {
				var alertOption = k2DaysBeforeAlarmOptions;
				
				var dstDate = UIADate.dateWithDateStringInTimeZone(kTimeZones[j].transitionDates[i], kTimeZones[j].id);
				var systemDate = UIADate.dateWithDateStringInTimeZone(kTimeZones[j].transitionDates[i], kTimeZones[j].id);
				systemDate.setWithOptions({dateString:kDSTSystemTimeOffset});
				var alarmDate = UIADate.dateWithDateStringInTimeZone(kTimeZones[j].transitionDates[i], kTimeZones[j].id); 
				alarmDate.setWithOptions({dateString:kDSTAlarmTimeOffset});
				var alarmTime = alarmDate.getHours() + ":" + alarmDate.getMinutes();
				
				tests.push(_createCalendarTest("DST", alertOption, systemDate, alarmTime, kTimeZones[j].name, alarmDate));
			}
		}
		
		tests.push("Leap Year");
		for (var i=0; i<kLeapYears.length; i++) {
			var leapYearDate = UIADate.dateWithDateString(kLeapYears[i] + ":02:29");
			var systemDate = UIADate.dateWithDateString(kLeapYears[i] + ":" + kLeapYearAlarmSystemDayAndMonth + ":" + kLeapYearAlarmSystemTime);
			var alertOption = getNextAlertOption();
			tests.push(_createCalendarTest("LeapYear", alertOption, systemDate, kLeapYearAlarmEventStartTime, null, leapYearDate));
		}
		for (var i=0; i<kLeapYears.length; i++) {
			var leapYearDate = UIADate.dateWithDateString(kLeapYears[i] + ":02:29");
			var systemDate = UIADate.dateWithDateString(kLeapYears[i] + ":" + kLeapYearAlarmSystemDayAndMonth + ":" + kLeapYearAlarmSystemTime);
			var alertOption = kDayOfEventAlarmOption;
			tests.push(_createCalendarTest("LeapYear", alertOption, systemDate, kLeapYearAlarmEventStartTime, null, leapYearDate));
		}
		for (var i=0; i<kLeapYears.length; i++) {
			var leapYearDate = UIADate.dateWithDateString(kLeapYears[i] + ":02:29");
			var systemDate = UIADate.dateWithDateString(kLeapYears[i] + ":" + kLeapYearAlarmSystemDayAndMonth + ":" + kLeapYearAlarmSystemTime);
			var alertOption = k1DayBeforeAlarmOptions;
			tests.push(_createCalendarTest("LeapYear", alertOption, systemDate, kLeapYearAlarmEventStartTime, null, leapYearDate));
		}
		for (var i=0; i<kLeapYears.length; i++) {
			var leapYearDate = UIADate.dateWithDateString(kLeapYears[i] + ":02:29");
			var systemDate = UIADate.dateWithDateString(kLeapYears[i] + ":" + kLeapYearAlarmSystemDayAndMonth + ":" + kLeapYearAlarmSystemTime);
			var alertOption = k2DaysBeforeAlarmOptions;
			tests.push(_createCalendarTest("LeapYear", alertOption, systemDate, kLeapYearAlarmEventStartTime, null, leapYearDate));
		}
	}
			
}

function usage() {
	system.println("usage: AlarmTests.js [--enable <string>] [--disable <string>] [-o <path> | -filepath <path> | --filename <string>] [-l | --list]");
	system.println("	--basicAlarmStartDate	a string in the format YYYY:MM:DD to specify the start date for basic alarm tests");
	system.println("	--basicAlarmEndDate	a string in the format YYYY:MM:DD to specify the end date for basic alarm tests");
	system.println("    --timezone <name> <tz id> <number of transition dates> <transition date> timezones to run the DST tests for"); 
	system.println("	--disable	tests to skip (may use regex to describe tests)");
	system.println("	--enable	tests to run (may use regex to describe tests)");
	system.println("	--filepath	full path for the results file");
	system.println("	--filename	name to use for the results file");
	system.println("	--wifiname	name to use for the wifi basestation");
	system.println("	--wifipassword	password to use for the wifi basestation");
	system.println("	--nosetup	skip the setup phase of the AlarmTests")
	system.println("	--list		list the available tests");
	system.println("	--writecrashes	write out crashes to the results file")
	system.println("	--help | -h	usage description");
}

function main() {
	var tests = new Array();
	var version = harness_getBuildVersion();
	var filename = "AlarmTests_" + version + ".txt";
	var filepath;
	var wifiname;
	var wifipassword;
	var writeCrashes = false;
	var enableSetup = true;
	
	// seed the generator, so that any random events are the same for every run
	system.setRandomSeed(1);
	UIATarget.localTarget().unlockScreenIfNecessary();	// screen must be unlocked to check for springboard app icons
	
	// process command line arguments
	var options = new Options();
	if (options.help || options.h) {
		usage();
		return;
	}
	if (options.list || options.l) {
		addTestsToArray(tests);
		harness_listTests(tests);
		return;
	}
	if (options.filename) filename = options.filename;
	if (options.nosetup) enableSetup = false;
	if (options.writecrashes) writeCrashes = true;
	if (options.o) filepath = options.o;
	else if (options.filepath) filepath = options.filepath;
	else {
		harness_makeDirectory(kReportPath);
		filepath = kReportPath + filename;
	}
	if (options.basicAlarmStartDate && options.basicAlarmEndDate) {
		kBasicAlarmStartDate = options.basicAlarmStartDate;
		kBasicAlarmEndDate = options.basicAlarmEndDate;
	}

	if (options.timezone) { 
		kTimeZones = new Array(); 
		while (options.timezone.length > 0) { 
			var timezone = {name:options.timezone.shift(), id:options.timezone.shift()}; 
			var dstDatesCount = options.timezone.shift(); 
			timezone.transitionDates = new Array(); 
			for (var i=0; i<parseInt(dstDatesCount,10); i++) { 
				timezone.transitionDates.push(options.timezone.shift()); 
			} 
			kTimeZones.push(timezone); 
		} 
	}
	
	addTestsToArray(tests); // add all of the normal tests to the array
	
	// uncomment this line if you want top data added to the output
	system.setDefault("com.apple.harness", "utilities", ["/usr/bin/top -o -cpu -l 1"]);
	
	harness_removeFile(filepath);

	//Test setup
	if (system.hasCapability('telephony')) {
		tests.push(phtCreateTest("TurnSetTimeAndDateAutomaticallyOff", ["General", "Date & Time", "Set Automatically", 0], settingsTest_changeSingleSwitch, "Set the 'Set Automatically' Date & Time switch to off"));		
	}
	tests.push(phtCreateTest("SetAutoLockToNever", ["General", "Auto-Lock", "Never"], settingsTest_chooseCheckmarkedItem, "Set Auto-Lock to Never"));
	tests.push(phtCreateTest("DisableTimeZoneSupport", ["General", "Mail, Contacts, Calendars", "Time Zone Support", "Time Zone Support", "0"], settingsTest_changeSingleSwitch, "Turn Time Zone Support Off"));
	
	system.run("/usr/local/bin/thermtune --disable", 5);
	harness_runTestsFromArray(tests, filepath, options.disable, options.enable, false, writeCrashes);
	system.run("/usr/local/bin/thermtune --enable", 5)
	
	system.println("Done Running Alarm tests.");
}

main();
