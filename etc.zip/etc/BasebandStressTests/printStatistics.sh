#################################################################################################
#                                                                                               #
#   ScriptName: printStatistics.sh                                                              #
#                                                                                               #
#   Usage:      <path_to_Script>/printStatistics.sh                                             #
#                                                                                               #
#   Purpose:    This Scripts helps in printing the Statistics for Stress Tests                  #
#                                                                                               #
#   Author:     Jerome Jesu                                                                     #
#   Contact:    jesu@apple.com                                                                  #
#                                                                                               #
#################################################################################################


###########################################################################
# Function to get the S/w Version Numbers of AP and Baseband Firmware
###########################################################################
getBuildVersions()
{

	# GET THE BASEBAND VERSION LOADED ON THE DEVICE
	${CT_MONITOR} -q 2> BBVersion.txt &
	sleep 1;
	#killall -9 CoreTelephonyMonitor; sleep 1;
	CHECK=`grep -c "Firmware Baseline Version" BBVersion.txt`
	
	if [ $CHECK -ne 0 ]; then 
		Baseband=`perl -lne 'if (/\QFirmware Baseline Version\E/ ) { $vers = (split /\s+/)[-1]; $vers =~ s/\[|\]//g;  print "$vers" }' BBVersion.txt`
		#Baseline=`perl -lne 'if (/\QFirmware Version\E/ ) { $vers = (split /\s+/)[-1]; $vers =~ s/\[|\]//g;  print "$vers" }' BBVersion.txt`
		#if [ $BLVers == $Baseline ]; then Baseband=$Baseline; 
		#else Baseband=$BLVers;; fi
	else
		Baseband=`perl -lne 'if (/\QFirmware Version\E/ ) { $vers = (split /\s+/)[-1]; $vers =~ s/\[|\]//g;  print "$vers" }' BBVersion.txt`
		#Baseband=`${LOCKDOWN_QUERY} get NULL BasebandVersion 2>&1`
	fi
	#SNUM=`grep Chip BBVersion.txt | perl -lne 's/^(.*)(bytes = )(.*)$/$1$2$3/; $chip = $3; $chip =~ s/\}|\]//g; print $chip;'`

	
	# GET ALL REQUIRED DEVICE INFOS
	isSERIAL=`echo $SERIAL | perl -lne ' if (/^$/) {print 0} else {print 1};'`

	# SET DEVICE NAME
	if [ $isSERIAL -eq 0 ]; then NAME="${HARDWARE}_${PHONE_NUMBER}";
	else  NAME="${HARDWARE}_${SERIAL}"; fi
	if [ $DEVICENAME == "iPhone" ] || [ $DEVICENAME == "iPad" ]; then  DEVICENAME=${NAME}; fi
	

	# SETTING THE ROUND VERSION FOR THE SERVER DIRS FOR LOGS/STATS
	if [ $round -eq 1 ]; then  
		BB_Build="$Baseband-${RAT}_$ROUNDINFO"
	else 
		BB_Build="$Baseband-${RAT}"; 
	fi
	serverDir=`echo "$HARDWARE-${BB_Build}" | perl -lne '($d,$M,$Y) = (localtime())[3,4,5]; $Y = $Y + 1900; $M++; s/[.]//g; printf ("IPC_%s_%04d%02d%02d",$_,$Y,$M,$d)'`
	echo "ServerDir = $serverDir";
	echo "DLCI PORT -> $DLCI_DEV_NODE"
}

###########################################################################
#Function to Convert given run time in seconds to HH:MM:SS
# USAGE: calculateTime RUN_TIME (in seconds) [1 to output to Stats file, 0 otherwise] 
###########################################################################
calculateTime()
{
	runTime=$1;
	hours=$(($runTime / 3600)); hours2=$(($hours * 3600));
	mins2=$(($runTime - $hours2)); mins=$(($mins2 / 60));
	abSecs=$(($hours * 3600 + $mins * 60)); secs=$(($runTime - $abSecs));
	if [ $hours -lt 10 ]; then  hours=`echo "0$hours"`;  fi
	if [ $mins -lt 10 ];  then  mins=`echo "0$mins"`;    fi
	if [ $secs -lt 10 ];  then  secs=`echo "0$secs"`;    fi
	totalTime="$hours:$mins:$secs"
	if [ $2 -eq 1 ]; then echo " Total RunTime : $totalTime, RunTime (in secs): $runTime." >> Stats.txt;	fi
	echo $totalTime
}

###########################################################################
# Function to calculate Percentages
# USAGE: calculatePercent <total Fails/Pass> <Total>
###########################################################################
calculatePercent()
{
	Percent=`echo "$1 $2" |  perl -lne '($n,$d) = split; $percent = ($n*100)/$d if ($d > 0); printf ("%.2f",$percent);'`
	echo $Percent
}

calculateUploadStatsiPerf()
{
	uploadDataRate=`perl -lne ' 
		END { if (defined $count) {  printf ("%0.03f", $sum/$count); 
			} else { print "0";} } 
		$rate = (split/\s+/)[-2]; 
		if ($rate =~ /^\d+$|^\d+[.]/ && $rate != 0) { $count++; $sum += $rate;} ' DataUploadStress.txt `
		
	DataUploadPass=`perl -lne ' 
			BEGIN {$passcount = 0; }
			END { print $passcount; } 
			$rate = (split/\s+/)[-2]; 
			$passcount++ if ($rate != 0 && $rate =~ /^\d+|^\d+[.]/);' DataUploadStress.txt`
	
	DataUploadFail=$(($uploadAttempts - $DataUploadPass))	
}


calculateUploadStatsStreamPerf()
{
	uploadDataRate=`perl -lne ' 
			END { printf ("%0.03f", $sum/$count); }
			if (/^\QINFO: \E\(\d{1,}\)/) { 	@w = split; 
			if ($w[4] =~ /^\d{1,2}[.]\d{3,}$/ & $w[4] !~ /^[0]{1,3}[.][0]{3,}/ ) { 
				$count++; $sum += $w[4] } 
		}' UploadStressTest.txt`

	DataUploadFail=`perl -lne ' 
			END { $count=0 if (! defined $count); print "$count" }  
			if (/Mean Throughput|Average Throughput/) { 
			@w = split; 
			$count++ if ( $w[4] =~ /^[0][.][0]{3,}/ | $w[4] =~ /\d{3,}[.]\d{3,}/  | $w[4] =~ /inf/ ); 
		} ' UploadStressTest.txt`
}


calculateDownloadRates()
{
	dataFailCount2=`perl -lne ' 
			END { $count=0 if (! defined $count); print "$count" }  
			if (/Mean Throughput|Average Throughput/) { 
			@w = split; 
			$count++ if ( $w[4] =~ /^[0][.][0]{3,}/ | $w[4] =~ /\d{3,}[.]\d{3,}/  | $w[4] =~ /inf/ ); 
		} ' DownloadStressTest.txt` 
			
	downloadDataRate=`perl -lne ' 
			END { printf ("%0.03f", $sum/$count); }
			if (/^\QINFO: \E\(\d{1,}\)/) { 	@w = split; 
			if ($w[4] =~ /^\d{1,2}[.]\d{3,}$/ & $w[4] !~ /^[0]{1,3}[.][0]{3,}/ ) { 
				$count++; $sum += $w[4] } 
		}' DownloadStressTest.txt`

	if [ $dataFailCount -ge $DataAttempts ]; then dataFailCount=$DataAttempts; fi
	MinDataRate=`grep Average DownloadStressTest.txt | awk '{print $5}' | perl -lne ' print if (! /inf|nan/); ' | sort | head -1`
	MaxDataRate=`grep Average DownloadStressTest.txt | awk '{print $5}' | perl -lne ' print if (! /inf|nan/); ' | sort | tail -1`
	echo " Data Fail Counters - 0=$dataFailCount, 1=$dataFailCount1, 2=$dataFailCount2---$isDataFAIL"
	echo " Data Pass Count - $dataPassCount --- $isDataPASS."

}


###########################################################################
# FUNCTION to process the CSI logs and report the number of crashes and Call Drops
###########################################################################
processCsiLogs()
{
	echo `date` ": _____PROCESSING CSI LOGS - $dcount _____"  >> $LOGSFILE
	totalCsiLogs=`ls $csiLogsDir/*csi* | wc -l | awk '{print $1}'`
	totalModemResets=`cat /tmp/crashReasons | grep "modem reset" | wc -l | awk '{print $1}'`
	totalAtTimeouts=`cat /tmp/crashReasons | grep -i "timeout" | grep "AT" | grep -v "modem reset" | wc -l | awk '{print $1}'`
	totalASM=`cat /tmp/crashReasons | grep -i "Fatal Error"| wc -l | awk '{print $1}'`
	totalLocationdError=`cat /tmp/crashReasons | grep -i "locationd qmux"| wc -l | awk '{print $1}'`
	totalTempTimeouts=`cat /tmp/crashReasons | grep "temperature update" | grep -v "modem reset" | wc -l | awk '{print $1}'`
	totalBasebandCrashes=`cat /tmp/crashReasons | grep "baseband crash"| wc -l | awk '{print $1}'`
	totalTraceDiag=`cat /tmp/crashReasons | grep "Trace DIAG"| grep -i config | wc -l | awk '{print $1}'`
	totalCallFailures=`cat /tmp/crashReasons | grep -i "call fail" | wc -l | awk '{print $1}'`
	totalCallDrops=`cat /tmp/crashReasons | grep -i "call drop"| wc -l | awk '{print $1}'`
	totalDumps=`cat /tmp/crashReasons | grep "Dump" | wc -l | awk '{print $1}'`
	totalUserDumps=`cat /tmp/crashReasons | grep "User" | wc -l | awk '{print $1}'`
	totalFTO=`cat /tmp/crashReasons | grep "FTO" | wc -l | awk '{print $1}' `
	totalBBResets=$(($totalModemResets + $totalBasebandCrashes + $totalAtTimeouts + $totalTempTimeouts + $totalASM + $totalTraceDiag + $totalLocationdError))
	totalLogs=$(($totalBBResets + $totalCallFailures + $totalCallDrops + $totalDumps + $totalUserDumps + $totalFTO))
	totalOthers=$(($totalCsiLogs - $totalLogs))
	
	echo "\n ****************  LOG DETAILS:  *********************"
	echo "RESETS-$totalModemResets  CRASHES-$totalBasebandCrashes"
	echo "FAIL-$totalCallFailures,  DROPS-$totalCallDrops, DUMPS-$totalDumps, USERDUMPS-$totalUserDumps"
	echo "FTO-$totalFTO,  OTHERS-$totalOthers"
	
	if [ $minUpTime -eq 0 ] && [ $totalBBResets -gt 0 ]; then
		ls $logFiles | perl -lne '@C = stat($_); $f = $_; open (F, $f); 
			while (<F>) {
				chomp; if (/\QReason: \E/) { 
				$m = (split /:/)[1];  
				if ($m !~ /call/i && $m !~ /dump/i && $m !~ /FTO/ && $m !~ /user/i && $m !~ /location/i) { 
					$t = @C[9]; print "$f:$m:$t"}; 
					last;
			} }' > /tmp/firstCrash
			
		firstResetTime=`perl -e '
			END{ $file = (sort {$H{$a} <=> $H{$b}} keys %H)[0]; print "$H{$file}";} 
			open (F, "/tmp/firstCrash") || print "$!.\n"; 
			foreach (<F>) {
				$f = (split /:/)[0]; $H{$f} = (split /:/)[2];}'`
				
		echo "First Reset Time - $firstResetTime"
		if [ $firstResetTime -lt 0 ]; then firstResetTime=0; fi
	fi
} 


###########################################################################
# Function to print the IPC Stress Test statistics to a CSV File.
###########################################################################
printIPCStatistics()
{
	# Process all the CSI Logs to find the number of crahses/call drops/call failures.
	cp  $logFiles  $csiLogsDir/
	ls $csiLogsDir/*csi.txt | perl -lne '
			$f = $_; open (F, $f); $f =~ s/(.*\Qlog-bb-\E)(.*)(\Q-csi.\E(.*))/$2/; 
			while (<F>) { 
				chomp; if (/\QReason: \E/) {
				s/^(.*Reason: )//; s/--/_/g; s/,/_/g; 
				if ( /ATCS_TIMEOUT/ ) { s/(txid=\d+\s+)(msgid)/$2/; s/on message for svc=\d+\s+client=\d+\s+//;  }
				 s/(times)(\s[-]\s\d+\s:\s.*)$/$1/ if ( /DataDownloadFailed|LowThroughput/ );
				$i=$_; print "$i,$f" if (! /Dump State/ig); last; } 
			}  close F; 
		'  > /tmp/crashReasons
	
	processCsiLogs

	ls $crashDir/*plist $wirelessDir/*plist $mobileDir/*plist $mobileDir/Retired/*plist | 
		perl -lne '
			$f = (split /\//)[-1]; 
			if (! /LatestCrash/g &&  ! /SystemLog/  && ! /aggregated/g) { 
				$f =~ s/^(.+)[_-](\d{4}-\d{2}-\d{2}-\d{6})(.*)(.plist)$/$1$2$3/; 
				print "$1,$2"; }
		'  >> /tmp/crashReasons
	cp /tmp/crashReasons crashReasons
	
	
	# Find out the Crashes/call failure statistics with Time stamp based on the CSI/Crash Logs.	
	echo "\nDEVICE:, $DEVICENAME\n" > $CsiLogsFile
	echo `date` ", Crash Reasons Summary." >> $CsiLogsFile
				
	perl -e 'open (F, "/tmp/crashReasons"); 
		while (<F>) { chomp; 
			($r,$t) = split/,/; $C{$r}++; 
			push (@{$H{$r}},$t); } 
		close F; 
		foreach $k (keys %H) {
		print ("$k,$C{$k}, ",join(", ", @{$H{$k}},"\n") )} 
	' >> $CsiLogsFile
	
	crash=`perl -e '
		open (F, "/tmp/crashReasons"); 
		while (<F>) { 
			chomp; 
			($r,$t) = split/,/; 
			$C{$r}++; 
			push (@{$H{$r}},$t); } 
		close F; 
		foreach $k (keys %H) {
			print ("$k,$C{$k},",join(",", @{$H{$k}},"::::") ) if ($k !~ /call drop|call fail|fto|corelocation|aggregated/i && $k !~ /^\s*$/);
		} '`
	
	testCurrentTime=$2
	testStartTime=$1	
	tcurTime="0"
	tcurTime=`date -r $testCurrentTime | cut -c5-19`
	tStartTime=`date -r $testStartTime | cut -c5-19`
	runTime=$(($testCurrentTime - $testStartTime))
	tRunTime=`calculateTime $runTime 255`
	if [ $totalBBResets -ne 0 ]; then	avgUpTime=$(($runTime / $totalBBResets)); 
	else	avgUpTime=$runTime;  fi
		
	tavgUpTime=`calculateTime $avgUpTime 255`
	echo "Average UpTime....  $tavgUpTime. Last Log Time - $checkTimeForUploadingStats, $lastLogTime seconds.\n"

	callFailPercent=`calculatePercent $fail $callCount`
	smsFailPercent=`calculatePercent $sfail $smsCount`

	lastLogTime=$tcurTime
	if [ $minUpTime -le 0 ]; then  minUpTime=$(($firstResetTime - $startTime)); fi

	echo "Calculating Download Data Rate/Failures..."		
	calculateDownloadRates
	
	echo "Calculating Upload Data Rate/Failures..."
	#calculateUploadStatsiPerf
	calculateUploadStatsStreamPerf


	echo "Calculating Failure %s..."
	downloadFailPercent=`calculatePercent $dataFailCount $DataAttempts`
	uploadFailPercent=`calculatePercent $uploadFailCount $uploadAttempts`
	dataFailPercent="$downloadFailPercent %--$uploadFailPercent %"
	echo "DataUploadFail - $DataUploadFail"

	echo `date` ": _____PRINTING STATS - $dcount _____"  >> $LOGSFILE
	
	echo "START_TIME, CURRENT_TIME, IMEI, DEVICE_NAME, AP_BUILD, BB_BUILD, ITERATIONS, Total BB RESETS, Total_CALLS, Total_SMS, CALL_DROPS, CALL_FAILURES, FTOs, Download_Attempts, Download Pass, Download Fails, DataFailPercent, DownloadDataRate, Upload_Attempts, AvgUploadDataRate, CallFails_CT, SMSFails_CT, START_TIME(s), CURRENT_TIME(s), RUN_TIME(s), FirstResetTime(s), D3, PDPActAttempts, PDPActFAIL, UDID, RUN_TIME (Hours), ScriptName, HARDWARE, SERIAL, CRASHES, TARGET, PHONE_NUMBER, SNUM, MMS_COUNT, MMS_FAIL, "
	
	echo "$tStartTime, $tcurTime, $IMEI, $DEVICENAME, $APBUILD, $BB_Build, $dcount, $totalBBResets, $callCount, $smsCount, $totalCallDrops, $totalCallFailures, $totalFTO, $DataAttempts, $dataPassCount , $dataFailCount, $dataFailPercent, $downloadDataRate, $uploadAttempts, $uploadDataRate, $fail, $sfail, $testStartTime, $testCurrentTime, $runTime, $minUpTime, $dataFailCount1 -- $dataFailCount2, $pdpAttempts, $pdpFails, $UDID, $tRunTime, $scriptname, $HARDWARE, $SERIAL, $crash, $LOOPS, ${PHONE_NUMBER}, $SNUM, $mmsCount, $mfail, "
	
	echo "$tStartTime, $tcurTime, $IMEI, $DEVICENAME, $APBUILD, $BB_Build, $dcount, $totalBBResets, $callCount, $smsCount, $totalCallDrops, $totalCallFailures, $totalFTO, $DataAttempts, $dataPassCount , $dataFailCount, $dataFailPercent, $downloadDataRate, $uploadAttempts, $uploadDataRate, $fail, $sfail, $testStartTime, $testCurrentTime, $runTime, $minUpTime, $dataFailCount1 -- $dataFailCount2, $pdpAttempts, $pdpFails, $UDID, $tRunTime, $scriptname, $HARDWARE, $SERIAL, $crash, $LOOPS, ${PHONE_NUMBER}, $SNUM, $mmsCount, $mfail, " >> $ResultsFile
		
	#cp top_output* /Library/Logs/CrashReporter/
}


