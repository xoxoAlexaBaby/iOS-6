#import "Calendar.js"
#import "../libs/PHTesting.js"


// --------------------------------------------------------------------------------
//	Function: calTest_addEvent 
//		Adds an event and verifies the event has been added
//											
//	Optional Parameters:
//		title ( String ) argv[0] - title of the event.  By default, an event will be created
//									with the title "Event " + a number, e.g.,  "Event 982"
//		loc ( String ) argv[1] - Location of the event. By default, no location is specified
//		date ( String ) argv[2] - Start date of event to add.  By default, an event date 
//									3 days in the future is specified. Be aware that creating 
//									a date too far in the future or in the past with numerous 
//									existing events may fail verification.  This is due to a 
//									maximum number of drags when scrolling to search for an event.
//		repetition (string) argv[3]- how often to repeat the event
//		notes (String) argv[4] - Notes to add to the event
//		deleteNewEvent ( boolean ) argv[5] - If true, delete the newly created event
//											NOTE: By default, this is false. 
//		deleteAllNewEvents (boolean) - Used in conjunction with deleteNewEvents, this will
//									delete all new events.  By default, this is false
//
//	Returns:
//		1 if the test passes, 0 otherwise
// --------------------------------------------------------------------------------
function calTest_addEvent() {
	
	var date;
	var today = new Date();
	var scrollDownwards;
	var notes;
	var loc;
	var title;
	var deleteNewEvent;
	var repetition;
	var deleteAllNewEvents;
	
	if (!this.argv[0] || this.argv[0] == "null") {
		//Create a unique event name based on the Unix Epoch
		var uniqueNum = new Date().getTime() % 2000;
		title = "Event " + uniqueNum;
	} else {
		title = this.argv[0];
	}


	this.testResult = 0;
	this.testError = "";
	
	// Create and assign the specified location.
	if (this.argv[1] && this.argv[1] != "null") {
		loc = this.argv[1];
	}
	
	//Create a date object with the date string from the arguments
	if ( this.argv[2] && this.argv[2] != "null" ) {
		date = new Date( this.argv[2] );
	} else {
	//Create a default date object 3 days in the future.
		date = new Date();
		date.setDate(date.getDate() + 3);
	}

	//Set Repetition
	if (this.argv[3] && this.argv[3] != "null") {
		repetition = this.argv[3];
	} 
	
	//Set notes
	if (this.argv[4] && this.argv[4] != "null") {
		notes = this.argv[4];
	} 
	
	//Set deleteNewEvent
	if (this.argv[5] && this.argv[5] != "null") {
		deleteNewEvent = this.argv[5];
	} else {
		deleteNewEvent = false;
	}

	//Set deleteNewEvent
	if (this.argv[6] && this.argv[6] != "null") {
		deleteAllNewEvents = this.argv[6];
	} else {
		deleteAllNewEvents = false;
	}
	
	
	// launches, dismisses dialogs and makes sure we're on the main screen
	calendar.getToMainCalendarView();

	try {
		calendar.addNewEvent(title, {notes:notes,location:loc, startEndOptions:{starts:date}, repeat:repetition});
	} catch (e) {
		UIALogger.logError(e.message);
		this.testError = "Could not add a new event.";
		UIALogger.logError(this.testError);
		return this.testResult = 0;
	} 

	calendar.getToCalendarView("List");
	if (!calendar.mainWindow().tableViews()[0].scrollToElementWithPredicate("name CONTAINS '" + title + "'").isValid()) {	
		this.testError = "Added event, but could not verify that it was added.";
		UIALogger.logError(this.testError);
		return this.testResult = 0;
	} 
	
	//if the option to delete the newly created event is true, then do some cleanup and delete the new event. 
	//Note, no validation is performed
	if (deleteNewEvent) {
		try {
			UIALogger.logMessage("Performing cleanup - deleting newly added event");
			calendar.deleteCalendarEvent({eventTitle:title, deleteRecurringEvents:deleteAllNewEvents});
		} catch (e) {
			UIALogger.logError("Exception thrown: " + e.message);
			UIALogger.logError("Could not delete event. Passing, but no cleanup performed");
		}
	}
	
	return this.testResult = 1;
	
		
} //end calTest_addEvent
					
					
					
// --------------------------------------------------------------------------------
//	Function: calTest_navigateBetweenViews 
//		Attempts to navigate between the three different calendar views: Month, Day, List
//	
//	Parameters:
//		( String ) - a particular view to navigate to
//
//	Returns:
//		1 if the test passes
// --------------------------------------------------------------------------------
function calTest_navigateBetweenViews(){
	var views;
	if (this.argv.length < 1) {
		if (UIATarget.localTarget().model() == 'iPad') views = ["Month", "Day", "List", "Week"];
		else views = ["Month", "Day", "List"];
	} else {
		views = this.argv;
	}
	calendar.getToMainCalendarView();

	for(i = 0; i<views.length; i++) {
		try {
			calendar.getToCalendarView(views[i]);
		} catch (e) {
			UIALogger.logError(e.message);
			this.testError = "Failed to switch to '" + views[i] + "' view.";
			UIALogger.logError(this.testError);
			return this.testResult = 0;			
		}
		
		try {
			calendar.validateCurrentCalendarView(views[i]);
		} catch (e) {
			UIALogger.logError(e.message);
			this.testError = "Unable to confirm switch to '" + views[i] + "' view.";
			UIALogger.logError(this.testError);
			return this.testResult = 0;
		}
		
		UIALogger.logMessage( "Switch to view: "+views[i]+" - Confirmed");
	}

	return this.testResult = 1;
}

// --------------------------------------------------------------------------------
//	Function: calTest_searchForEventUsingSearchBar 
//		Attempts to search for an event using the event list search bar.  If a title
//      is not specified, a new event will be created
//	
//	Parameters:
//		title ( String ) - title of event.  If none is specified, "Event" + a random number based on today's date and time will
//							be used to create a unique event name
//
//		location ( String ) - location of event. If none is specified, "IL" + a random number 1-7 will
//							be used to create a unique event location
//	Returns:
//		1 if the list view was scrolled
// --------------------------------------------------------------------------------
function calTest_searchForEventUsingSearchBar() {
	
	this.testResult = 0;
	this.testError = "";

	var title;
	var loc;
    var createNewEvent = true;
    
	//dismiss dialogs and dismiss event detail or edit view
	calendar.getToMainCalendarView();
	
	if (this.argv[0] && this.argv[0] != "null") {
		title = this.argv[0];
        createNewEvent = false;
	} else {
		//Create a unique event name based on the Unix Epoch
		var uniqueNum = new Date().getTime() % 2000;
		title = "Event " + uniqueNum;
        createNewEvent = true;
	}
	
	if ( this.argv[1] && this.argv[1] != "null") {
		loc = this.argv[1];
	} else {
		loc = "IL" + system.randomInteger(1,7);
	}
	
    if (createNewEvent) {
        try {
            calendar.addNewEvent( title, {location: loc} );
        } catch (e) {
            UIALogger.logError(e.message);
            this.testError = "Could not add event with title: " + title + " and location: " + loc;
            UIALogger.logError(this.testError);		
            return this.testResult = 0;
        }
    }
	

	UIALogger.logMessage("Title: " + title);
	try {
		var eventElementName = calendar.useCalendarListSearchToSearchForEvent(title).name();
		UIALogger.logMessage("Title: " + title);
	} catch (e) {
		UIALogger.logError(e.message);
		throw new Error( "Could not find event with title: " + title);
	}
	UIALogger.logMessage("Title: " + title);	
	//Delete the newly created event
	try { 
		UIALogger.logDebug("Attempting to delete event with title " + title);
		calendar.deleteCalendarEvent({eventTitle:title, deleteRecurringEvents:true});
	} catch (e){
		UIALogger.logError(e.message);
		this.testError =  "Could not delete event: " + title + ".  The test has not failed, but there was an error deleting the event";
		return this.testResult = 0;		
	}
	
	return this.testResult = 1;
	
} // end calTest_searchForEventUsingSearchBar

	
// --------------------------------------------------------------------------------
//	Function: calTest_deleteCalendarEvent 
//		Create an event, delete the event and validate that it has been deleted
//	
//	Parameters:
//		title ( String ) - title of event.  If none is specified, "Event" + a random number based on today's date and time will
//							be used to create a unique event name
//
//	Returns:
//		0 if the test failed, 1 if the test passed.
// --------------------------------------------------------------------------------
function calTest_deleteCalendarEvent() {

	this.testResult = 0;
	this.testError = "";
	
	var title;
	var event;
	var deleteEventResult;
	var verifyEventDeletion;

	if (this.argv[0] && this.argv[0] != "null") {
		title = this.argv[0];
	} else {
		//Create a unique event name based on the Unix Epoch
		var uniqueNum = new Date().getTime() % 2000;
		title = "Event " + uniqueNum;
	}
	
	//dismiss dialogs and dismiss event detail or edit view
	calendar.getToMainCalendarView();
	
	// Switch to List view
	try {
		calendar.getToCalendarView("List");
	} catch (e) {
		UIALogger.logError(e.message);
		this.testError = "Could not switch to List view";
		return this.testResult = 0;
	}
	
	UIALogger.logMessage( "Creating an event to delete");

	try{ 
		calendar.addNewEvent( title );
	} catch (e) {
		UIALogger.logError(e.message);		
		this.testError = "Could not add event with title: " + title;
		return this.testResult = 0;
	}
	UIALogger.logMessage( "Created event: " + title);		
	
	//Next, delete the newly created event
	try {
		calendar.deleteCalendarEvent({eventTitle:title, deleteRecurringEvents:true});
	} catch (e) {
		UIALogger.logError(e.message);
		this.testError = "Could not delete event";
		return this.testResult = 0;	
	}	

	//Wait for animations to stop
	UIATarget.localTarget().delay(1);
	
	//Go back to the main calendar view
	calendar.getToMainCalendarView();
	
	//Wait for animations to stop
	UIATarget.localTarget().delay(1);

	//Is the event still present?
	try {
		var newEventElement = calendar.useCalendarListSearchToSearchForEvent(title);
	} catch (e) {
		UIALogger.logMessage("Did not find event with title: " + title + ". Deletion successful");
		return this.testResult = 1;
	}
	
	this.testError = "Event was found in list table.  Event deletion failed";
	return this.testResult = 0;
	
} // end calTest_deleteCalendarEvent



// --------------------------------------------------------------------------------
//	Function: calTest_addEventAndValidateAlert 
//		Create an event, delete the event and validate that it has been deleted
//	
//	Parameters:
//			title			(string) - title of the event
//			systemDate		(string) -	a string in the format yyyy:mm:dd:hh:mm to specify the date/time the 
//										system should be set to, before adding the alarm
//			startTime		(string) - a string in the format yyyy:mm:dd:hh:mm to specify the date/time the 
//										event is
//			timezone		(string) - the timezone the system should be set to, before adding the alarm	
//			alertReminder	(string) - when the event reminder alert should fire.  Should be one of the following:
//									5 minutes before
//									15 minutes before
//									30 minutes before
//									1 hour before
//									2 hours before
//									1 day before
//									2 days before
//									On date of event
//
//	Returns:
//		0 if the test failed, 1 if the test passed.
// --------------------------------------------------------------------------------
function calTest_addEventAndValidateAlert() {
	
	var systemDate = UIAUtility.valuesForKey("systemDate", this.argv, 1);
	var timezone = UIAUtility.valuesForKey("timezone", this.argv, 1);
	var title = UIAUtility.valuesForKey("title", this.argv, 1);
	var alertReminder = UIAUtility.valuesForKey("alertReminder", this.argv, 1);
	var startTime = UIAUtility.valuesForKey("startTime", this.argv, 1);
	var repetition = UIAUtility.valuesForKey("repetition", this.argv, 1);
	var deleteNewEvent = true;
	
	var alarmDate; //stores the time in a dictionary object of when the alarm should fire off (will not change over the course of the test)
	var useOriginalTimeForVerification = true;

	if (timezone) {
		UIALogger.logMessage("Setting time zone to: " + timezone);
		settings.launchIfNotActive();
		settings.setTimeZone(timezone);
	}
	
	if (systemDate) {
		UIALogger.logMessage("Setting system date to: " + systemDate);
		settings.setDateAndTime(UIADate.dateWithDateString(systemDate));
	}
	
	// launches, dismisses dialogs and makes sure we're on the main screen
	calendar.getToMainCalendarView();

		
	startTime = UIADate.dateWithDateString(startTime);
	startTime.setWithOptions({minutes:calendar._roundMinutes(startTime.getMinutes())});

	try {
		calendar.addNewEvent(title, {startEndOptions:{starts:startTime}, repeat:repetition, alert:alertReminder});
	} catch (e) {
		UIALogger.logError(e.message);
		this.testError = "Could not add a new event.";
		UIALogger.logError(this.testError);
		return this.testResult = 0;
	}
	UIALogger.logMessage("startTime: " + startTime);
	
	// To validate the alert, set the system time to the event start time
	var validationSystemDate = UIADate.dateWithDateString(startTime.getDateString());
	UIALogger.logDebug("validationSystemDate: " + validationSystemDate.toString());
	var alertReminderDelta = alertReminder.split(" ")[0];
	

	// next, use the alert reminder time to calculate when the alert will fire
	if (alertReminder.match(/minutes/)) {
		validationSystemDate.setWithOptions({minutes:"-"+alertReminderDelta});
	} else if (alertReminder.match(/hour/)) {
		validationSystemDate.setWithOptions({hours:"-"+alertReminderDelta});
	} else if (alertReminder.match(/day/)) {
		validationSystemDate.setWithOptions({hours:"-"+(parseInt(alertReminderDelta,10) * 24)});
	} else if (alertReminder.match(/date/)) {

	} else {
		UIALogger.logMessage("No valid alert reminder specified");
	}
	
	UIALogger.logDebug("Event time: " + startTime.toString() + ".  Reminder alert time: " + validationSystemDate.toString());

	
	var validated = false;

	// How many minutes to wait for alarm to fire after setting system date
	var waitInterval = 2;
	var newSystemDate = UIADate.dateWithDateString(validationSystemDate.getDateString());

	// New system date to set with a 2 minute buffer before expected alarm firing time
	newSystemDate.setWithOptions({minutes:"-"+waitInterval});
	UIALogger.logDebug("System date being set to " + newSystemDate.getDateString());
	
	settings.setDateAndTime(newSystemDate);
	
	validated = true;
	var alarmActivated = false;
	UIATarget.localTarget().clickMenu();
	var date = new UIADate();
	UIALogger.logMessage("Waiting for " + waitInterval*60 + " seconds for the alarm...");

	// Loop for (waitInterval * 60) seconds and check for any alerts that fired between loops.
	for (var i=0; i<waitInterval*60; i=i+5) {
		var lastAlert = springboard.alertSinceDate(date);
		
		if (lastAlert && lastAlert.alertMessageArray[0] == title) {
			//check the alert fired off at the correct time
			lastAlert.uiaDate = new UIADate();
			lastAlert.uiaDate.setTime(lastAlert.date.getTime());
			
			UIALogger.logMessage("Reminder alert was activated as expected. Checking if it activated at the correct time...");
			if (lastAlert.uiaDate.getHours() == parseInt(validationSystemDate.getHours(), 10) &&
				lastAlert.uiaDate.getMinutes() == parseInt(validationSystemDate.getMinutes(), 10)) {
				alarmActivated = true;
				springboard.lastAlert = null; //reseting the lastAlert. Should really do something better...
				UIALogger.logError("Reminder activated at the correct time");
				UIALogger.logDebug("Reminder alert fire off time: " + lastAlert.uiaDate.toString());
				UIALogger.logDebug("Reminder alert expected time: hours:" +  validationSystemDate.getHours() + " minutes: " + validationSystemDate.getMinutes());

				break;
			} else {
				UIALogger.logError("Reminder alert did not activate at the correct time");
				UIALogger.logDebug("Reminder alert fire off time: " + lastAlert.uiaDate.toString());
				UIALogger.logDebug("Reminder alert expected time: hours:" +  validationSystemDate.getHours() + " minutes: " + validationSystemDate.getMinutes());
				break;
			}
		}
		UIATarget.localTarget().delay(5);
	}
	
	//if the option to delete the newly created event is true, then do some cleanup and delete the new event. 
	//Note, no validation is performed
	if (deleteNewEvent) {
		
		try {
			UIALogger.logMessage("Performing cleanup - deleting newly added event");
			calendar.launchIfNotActive();
			calendar.deleteCalendarEvent({eventTitle:title, deleteRecurringEvents:true});
		} catch (e) {
			UIALogger.logError("Exception thrown: " + e.message);
			UIALogger.logError("Could not delete event. Passing, but no cleanup performed");
		}
	}
	
	if (!alarmActivated) {
		var expectedAlarmDateString = "hours:" +  validationSystemDate.getHours() + " minutes: " + validationSystemDate.getMinutes();
		var errorString = "Reminder alert did not get activated for " + expectedAlarmDateString;
		this.testError = (!this.testError) ? errorString : this.testError + ", " + expectedAlarmDateString;
		UIALogger.logError(errorString);
		return this.testResult = 0;
	}

	return this.testResult = 1;	
	
} // end calTest_deleteCalendarEvent


// --------------------------------------------------------------------------------
//	Function: selectCalendars 
//		select calendars to show or hide from the available calendars
//
//	Optional Parameters:
//		calendarSettings (String or Array ) - To hide or show all calendars, 
//                          pass in the string "Show All" or "Hide All"
//                      
//                          Otherwise, to set the visibility of individual 
//                          calendars, pass in an array with each element in the 
//                           having the format:
//                          "<calendar_name_strimg:<numberic_boolean_value>"
//
//                          For example:
//                          "Birthdays:1", "Calendar:0"
//
//  Returns: 
//		0 if a calendar's visibility could not be set for any reason, 1 if the
//      visibility for all calendars was successfully set
//
// --------------------------------------------------------------------------------
function calTest_selectCalendars() {

    if (this.argv.length < 1) {
        this.testError("Not enough parameters passed in.");
        return this.testResult = 0;
    }
    
    try {
        // If there is only one argument and there is not a colon separating the values, 
        // then pass the argument in as a string (this covers the case of setting 
        // "Show All Calendars" and "Hide All Calendars"
        if (this.argv.length == 1 && !this.argv[0].match(":")) calendar.selectCalendars(this.argv[0]);
        
        else {
            var settingArray = new Array();
            for(item in this.argv) {
                settingArray[this.argv[item].split(":")[0]] = this.argv[item].split(":")[1];
            }
            calendar.selectCalendars(settingArray);
        }

    } catch(e) {
        UIALogger.logError(e.message);
        this.testError("Failed to set the visiblity of all calendars");
        return this.testResult = 0;
    }
    
    return this.testResult = 1;

}



function calTest_addCalendars() {
    
    if (this.argv.length < 1) {
        this.testError("Not enough parameters passed in.");
        return this.testResult = 0;
    }
    
    try {
        var settingArray = new Array();
        for(item in this.argv) {
            settingArray[this.argv[item].split(":")[0]] = (this.argv[item].split(":")[1]) ? this.argv[item].split(":")[1] : "";
        }
        calendar.addCalendars(settingArray);
        
    } catch(e) {
        UIALogger.logError(e.message);
        this.testError("Failed to set the visiblity of all calendars");
        return this.testResult = 0;
    }
    
    return this.testResult = 1;

    
    
}

// Create self tests -- this is an unnamed function, just to make sure any local variables stay in the correct context	
(function() {	
	if (typeof calendar.selfTests == 'undefined') {
		calendar.selfTests = new Array();
	}

 
    calendar.selfTests.push(phtCreateTest("AddNewCalendars", ["cal1:", "cal2:", "cal3:Orange"], calTest_addCalendars, "Add Calendars on Device"));
    calendar.selfTests.push(phtCreateTest("SetVisibleCaledars", ["cal1:0", "cal2:1", "cal3:0"], calTest_selectCalendars, "Set Device Calendar Visibility"));
 
	if (UIATarget.localTarget().model() != "iPad") {
		calendar.selfTests.push(phtCreateTest("NavigateCalendarViews", null, calTest_navigateBetweenViews, "Navigate to each calendar view"));		
	} else {
		calendar.selfTests.push(phtCreateTest("NavigateCalendarViews", null, calTest_navigateBetweenViews, "View events in Day, Week, Month and List views"));		
	}
	calendar.selfTests.push(phtCreateTest("AddCalendarEvent", ["Event Title","Event Location", null, "Every Day","these are some notes for an event", true, true], calTest_addEvent, "Add an event to the calendar"));
	calendar.selfTests.push(phtCreateTest("SearchCalendarListViewWithSearchBar", null, calTest_searchForEventUsingSearchBar, "Search for an event using the List View Search Bar"));
	calendar.selfTests.push(phtCreateTest("DeleteCalendarEvent", null, calTest_deleteCalendarEvent, "Delete an event"));
	calendar.selfTests.push(phtCreateTest("AddAlarmAndValidateReminderAlert", ["systemDate:2011:01:01:01:00", "startTime:2011:01:06:11:00", "title:5 minute reminder", "alertReminder:5 minutes before"], calTest_addEventAndValidateAlert, "Add an event with a 2 hour reminder alert and validate the alert fired"));
	calendar.selfTests.push(phtCreateTest("AddAlarmAndValidateReminderAlert", ["systemDate:2011:01:01:01:00", "startTime:2011:01:06:11:00", "title:2 hour reminder", "alertReminder:2 hours before"], calTest_addEventAndValidateAlert, "Add an event with a 2 hour reminder alert and validate the alert fired"));
	calendar.selfTests.push(phtCreateTest("AddAlarmAndValidateReminderAlert", ["systemDate:2011:01:01:01:00", "startTime:2011:01:06:11:00", "title:2 day reminder", "alertReminder:1 day before"], calTest_addEventAndValidateAlert, "Add an event with a 1 day reminder alert and validate the alert fired"));
	calendar.selfTests.push(phtCreateTest("AddAlarmAndValidateReminderAlert", ["systemDate:2011:01:01:01:00", "startTime:2011:01:06:11:00", "title:1 day reminder", "alertReminder:2 days before"], calTest_addEventAndValidateAlert, "Add an event with a 2 day reminder alert and validate the alert fired"));
	calendar.selfTests.push(phtCreateTest("AddAlarmAndValidateReminderAlert", ["systemDate:2011:01:01:01:00", "startTime:2011:01:06:11:00", "title:Day-of reminder", "alertReminder:On date of event"], calTest_addEventAndValidateAlert, "Add an event with reminder alert on the date of event and validate the alert fired"));
 }())

