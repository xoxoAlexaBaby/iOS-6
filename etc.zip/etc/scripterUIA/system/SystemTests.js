#import "../libs/System.js"
#import "../libs/SpringBoard.js"
#import "../libs/PHTesting.js"

// --------------------------------------------------------------------------------
//	systemTest_doNothing - This function just sleeps the device for the given 
//		amount of time.
//
//	Arguments:
//	 timeout (string) - seconds to sleep
//
//	Return:
//	 1 on pass, 0 on fail.  
// --------------------------------------------------------------------------------
function systemTest_doNothing() {
	if (this.argv.length < 1) {
		this.testError = "Must supply the shell command to issue.";
		this.testResult = 0;
		return this.testResult;
	}
	var timeout = this.argv[0];
	UIATarget.localTarget().delay(timeout);
	
	this.testResult = 1;
	return this.testResult;	
}

// --------------------------------------------------------------------------------
//	Function: systemTest_lockAndUnlockDevice 
//		Lock the device for a certain amount of time and then unlock it.
//	
//	Parameters:
//		timeToStayLocked (integer) - number of seconds to keep device locked (optional)
//		passcode (string) - passcode to use. (optional)
//
//	Returns:
//		1 on pass, 0 on fail. 
// --------------------------------------------------------------------------------
function systemTest_lockAndUnlockDevice() {


	if (this.argv.length < 1) {this.argv.push(system.randomInteger(5, 10));}
 	var timeToStayLocked = parseInt(this.argv[0]);

	var passcode;
	this.testResult = 0;	

	if (this.argv.length > 1) {
		passcode = this.argv[1];
		UIALogger.logMessage("Passcode is set to " + passcode + ".");
	}
 	
	UIALogger.logMessage("Locking for " + timeToStayLocked + " seconds.");

	this.testResult = lockAndSetWakeUp(timeToStayLocked);
	if (this.testResult) {
		UIALogger.logMessage("Sleeping script until system wakes.");
		system.sleepUntilPowerOn(timeToStayLocked);
		UIALogger.logMessage("System is awake.");
		try {
			UIATarget.localTarget().unlockScreenIfNecessary(passcode);
		} catch(e) {
			this.testError = "Failed to unlock: " + e.message;
			this.testResult = 0;
		}
	} else {
		this.testError = "Failed to lock.";
	}
	return this.testResult;
}

// --------------------------------------------------------------------------------
//	systemTest_isWiFiInterfaceActive - check whether wifi interface is active
//
//	Arguments: None
//
//	Return:
//	 1 if WiFi interface is active, 0 if it fails.
// --------------------------------------------------------------------------------
function systemTest_isWiFiInterfaceActive()
{
	this.testResult = 0;
	var searchString = "status: active"
	var searchString169 = "inet 169."
	var searchStringInet = "inet "
		
	cmd = "/sbin/ifconfig en0"
	output = UIAUtility.logToolOutput(cmd, 5);
	
	var total_output = "";
	if (output) {
		total_output = total_output + output; 
		//var outputList = total_output.split("\n");
	
		var matchList = total_output.match(searchString); 
		if (matchList != null) {
			UIALogger.logMessage("en0 is active");
			var matchListInet = total_output.match(searchStringInet);
			var matchList169 = total_output.match(searchString169);
			if ((matchListInet != null) && (matchList169 == null)) {
			UIALogger.logMessage("We have a valid IP address")
			}
			else {
				this.testError = "We did not get a valid IP address"
				UIALogger.logMessage(this.testError);
				this.testResult = 0;
				return this.testResult;
			}
		}
		else {
			this.testError = "en0 is inactive"
			UIALogger.logMessage(this.testError);
			this.testResult = 0;
			return this.testResult;
		}
	}
	
	this.testResult = 1;
	return this.testResult;
}

// --------------------------------------------------------------------------------
//	systemTest_ping - Check WiFi/3G Internet Connection using ping.
//
//	Arguments:
//	 ping_destination (string) - ping destination: URL or IP address; 
//			(optional-- default is www.google.com)
//
//	Return:
//	 1 if test succeeds, 0 if it fails.
// --------------------------------------------------------------------------------
function systemTest_ping()
{
	var ping_destination = "www.google.com";
	this.testResult = 0;
			
	if (this.argv.length < 1) {
		UIALogger.logMessage("ping default address: " + ping_destination)
	}
	else {
		ping_destination = this.argv[0];
		UIALogger.logMessage("ping " + ping_destination)
	}
			
	var success = false;
	var searchString = "round-trip"
	
	for (var j=0; j<3; j=j+1) {
		output = UIAUtility.logToolOutput("/sbin/ping -t 5 " + ping_destination, 10);
		
		var total_output = "";
		if (output) {
			total_output = total_output + output; 
			var outputList = total_output.split("\n"); 
			for (var i=0; i<outputList.length; i++) {
				var matchList = outputList[i].match(searchString);
					if (matchList != null) {
						//system.println(outputList[i]);
						UIALogger.logMessage("ping " + ping_destination + " pass")
						success = true;
						break;
					}
					
				}
		}
		
		if (!success){
			UIALogger.logMessage("ping " + ping_destination + " fail, try again")
		}
		else {
			break;
		}
		
		system.sleep(1);
	}
	
	if (!success) {
		this.testError = "We tried to ping " + ping_destination + ", but failed";
		UIALogger.logError(this.testError);
		return 0;
	}
	
	this.testResult = 1;
	return 1;
}


// --------------------------------------------------------------------------------
//	systemTest_runPictureFrame - Locks the device, taps the picture frame button, 
//		and lets the picture frame run for the specified amount of time. Please 
//		note that this test only runs on Wildcat.
//
//	Arguments:
//		timeToShowPictureFrame (integer) - number of seconds to let the picture 
//			frame run (optional)
//		passcode (string) - passcode to use. (optional)
//
//	Return:
//	 1 on pass, 0 on fail.  
// --------------------------------------------------------------------------------
function systemTest_runPictureFrame() {
	this.testResult = 0;
	
	if (UIATarget.localTarget().model() != 'iPad') {
		this.testError = "This test should only run on iPads";
		return this.testResult = 0;
	}
	
	if (this.argv.length < 1) this.argv.push(system.randomInteger(5, 10));
	var timeToShowPictureFrame = parseInt(this.argv[0]);
	
	var passcode;
	if (this.argv.length > 1) {
		passcode = this.argv[1];
		UIALogger.logMessage("Passcode is set to " + passcode + ".");
	}
	
	system.runPictureFrame(timeToShowPictureFrame, passcode);
	return this.testResult = 1;
}


function system_addSelfTest() {
	SELF_TEST_ARRAY.push(phtCreateTest("LockUnlock", ["0"], systemTest_lockAndUnlockDevice, "Lock and unlock the device"));
	SELF_TEST_ARRAY.push(phtCreateTest("LockUnlockWithPasscode", ["0", "1234"], systemTest_lockAndUnlockDevice, "Lock and unlock the device with passcode set"));
	if (UIATarget.localTarget().model() == 'iPad') {
		SELF_TEST_ARRAY.push(phtCreateTest("RunPictureFrame", ["6"], systemTest_runPictureFrame, "Run picture frame for 6 seconds"))
	}
}