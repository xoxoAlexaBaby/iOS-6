#import "UIAAppStressLibrary.js"


var firstNames = new Array("Andy", "Dave", "Evan", "Fredrick", "Heather", "Ingus", "Luther", "Rickie", "Usher", "Yani");
var phoneNumbers = new Array("4089748874", "8586515050");

// call object
function _stressPhone_CallInfo(phoneNumber, startTime) {
	this.phoneNumber = phoneNumber;
	this.startTime = startTime;

	this.duration = function callDuration() {
		var now = new Date();
		return (now.getTime() - startTime)/1000;
	}

	this.isActive = function callActive() {
		return telephony.callExists(null, "Active", 5);
	}
}


if (typeof phone != 'undefined') {
	phoneStress = AppStressBase.stressTest('Phone');
	
	if (typeof phoneStress != 'undefined') {
		phoneStress.calls = new Array();
		phoneStress.recentCallList = new Array();
		phoneStress.favoritesList = new Array();
		
		phoneStress.setup = function setup () {
			// Only do phone tests if we have a sim
			if (!telephony.isSIMReady()) {
				// try to turn off airplane mode to see if that fixes things.
				phoneStress.executeTest( "SetAirplaneMode", 
						 				 [ "Airplane Mode", "Airplane Mode", 0 ], 
						 				 settingsTest_changeSingleSwitch, "Turning off airplane mode." );
				if (!telephony.isSIMReady()) {
					phoneStress.weight = 0;
					return false;
				}
			}
			
			// hang up any existing calls (phone.getToKeypadView takes care of this)
			try {
				phone.getToKeypadView();
			}
			catch(e) {
				UIALogger.logError("Unable to get to phone keypad view -- not running phone tests.");
				return false;
			}
			
			phoneStress.addTest(phoneStress._makeCall);
			phoneStress.addTest(phoneStress._endCall);
			phoneStress.addTest(phoneStress._makeCallToContact);
			phoneStress.addTest(phoneStress._makeCallFromRecents);
			phoneStress.addTest(phoneStress._addContactToFavorites);
			phoneStress.addTest(phoneStress._removeContactFromFavorites);
			phoneStress.addTest(phoneStress._makeCallInAirplaneMode);
			
			return true;
		}
		
		phoneStress.init = function init () {
			// try to turn off airplane mode to see if that fixes things.
			phoneStress.executeTest( "SetAirplaneMode", 
					 				 [ "Airplane Mode", "Airplane Mode", 0 ], 
					 				 settingsTest_changeSingleSwitch, "Turning off airplane mode." );
			
			return true;
		}
		
		phoneStress.run = function run () {
			phoneStress.executeRandomTests(2);
		}
		
		// make call
		phoneStress._makeCall = function _makeCall () {
			var phoneNumber = UIAUtility.randomFromArray(phoneNumbers);
			var result;
					
			if (phoneStress.calls.length > 0) {
				if (!phoneStress._endCall()) {
					UIALogger.logError("Skipping test: This test can not be run while on a call.");
					return false;
				}
			}
			
			UIALogger.logMessage("Number if calls being tracked is " + phoneStress.calls.length);
			
			result = phoneStress.executeTest("MakeCall", [phoneNumber], phoneTest_makeCall, "Make call to " + phoneNumber + " using dialer.");
			
			if (result) {
				var currentDate = new Date();
				phoneStress.calls.push(new _stressPhone_CallInfo(phoneNumber, currentDate));
				gAppStressData.incCounter("CallCount");
			}
			
			// workaround for <rdar://problem/8268412> Baker 8B99 N82: drained while running stress
			if (system.queryLockdown("NULL", "HardwareModel" ) == "N82AP") {
				result = phoneStress._endCall();
			}

			return result;
		}

		// end call
		phoneStress._endCall = function _endCall () {
			var result;
			var call;
			
			if (phoneStress.calls.length < 1) {
				if (!phoneStress._makeCall()) { 
					UIALogger.logMessage("Skipping test: This test requires an active call.");
					return false;
				}	
			}

			call = phoneStress.calls.pop();

			if ((telephony.getCallCount() > 0) && (call.isActive())) {
				var minutes = Math.floor(call.duration()/60);
				var seconds = Math.floor(call.duration()%60);
				
				var result = phoneStress.executeTest( "EndCall", 
													  [ call.phoneNumber ], phoneTest_endCall, 
													  "Ending call to '" + call.phoneNumber + 
													  "' (call time: " + minutes + " minutes, " + seconds + " seconds)." );
				
				return result;
			}
			
			UIALogger.logError("Skipping test: The call was dropped.");
			gAppStressData.incCounter("DropCount");
			return true;
		}
		
		// make call to contact
		phoneStress._makeCallToContact = function _makeCallToContact() {
			var contactName;
			var result;
			
			if (phoneStress.calls.length > 0) {
				if (!phoneStress._endCall()) {
					UIALogger.logError("Skipping test: This test can not be run while on a call.");
					return false;
				}
			}
			
			contactName = phoneStress._pickContact();
			
			result = phoneStress.executeTest( "MakeCallToContact", 
											  [ contactName ], phoneTest_makeCallToContact, 
											  "Make phone call to contact: " + contactName + ".");
			
			if (result) {
				phoneStress.recentCallList.push(contactName);
			}
			
			return result;
		}
		
		// make call from recents
		phoneStress._makeCallFromRecents = function _makeCallFromRecents() {
			var contactName;
			
			if (phoneStress.calls.length > 0) {
				if (!phoneStress._endCall()) {
					UIALogger.logError("Skipping test: This test can not be run while on a call.");
					return false;
				}
			}
			
			if (phoneStress.recentCallList.length == 0) {
				if (!phoneStress._makeCallToContact()) { return false }
			}
			
			contactName = UIAUtility.randomFromArray(phoneStress.recentCallList);
			
			result = phoneStress.executeTest( "MakeCallFromRecents", 
											  [ contactName ], phoneTest_makeCallFromRecents, 
											  "Make phone call to recent contact: " + contactName + "." );
			
			return result;
		}

		// add contact to favorites
		phoneStress._addContactToFavorites = function _addContactToFavorites() {
			var contactName = phoneStress._pickContact();
			var result;
			
			if (!contactName) {
				UIALogger.logError("Unable to pick a contact to add to favorites -- skipping test.");
				return false;
			}
				
			result = phoneStress.executeTest( "AddContactToFavorites", 
							  		   		  [ contactName ], phoneTest_addContactToFavorites,
							  		   		  "Add " + contactName + " to Favorites." );

			if (result) {
				phoneStress.favoritesList.push(contactName);
			}
			
			return result;
		}
		
		// remove contact from favorites
		phoneStress._removeContactFromFavorites = function _removeContactFromFavorites() {
			var contactName;
			
			if (phoneStress.favoritesList.length == 0) {
				if (!phoneStress._addContactToFavorites()) {
					UIALogger.logError("No contacts to remove -- skipping test.");
				}
			}
			
			contactName = UIAUtility.randomFromArray(phoneStress.favoritesList);
			
			result = phoneStress.executeTest( "RemoveContactToFavorites", 
											  [ contactName ], phoneTest_removeContactFromFavorites, 
											  "Removing " + contactName + " from favorites." );
			
			if (result) {
				phoneStress.favoritesList.splice(phoneStress.favoritesList.indexOf(contactName));
			}
			
			return result;
		}
		
		// make call in airplane mode
		phoneStress._makeCallInAirplaneMode = function _makeCallInAirplaneMode() {
			var result;
			
			result = phoneStress.executeTest( "SetAirplaneMode", 
					 						  [ "Airplane Mode", "Airplane Mode", 1 ], 
					 						  settingsTest_changeSingleSwitch, "Turning on airplane mode." );
			
			if(!result) {
				UIALogger.logError("Can't turn on airplane mode -- skipping test.");
				return false;
			}
			
			phoneNumber = UIAUtility.randomFromArray(phoneNumbers);
			
			result = phoneStress.executeTest( "MakeCallinAirplaneMode", 
											  [ phoneNumber, "You must disable airplane mode to place a call." ], 
											  phoneTest_makeCallInAirplaneMode, 
											  "Calling " + phoneNumber + " while in Airplane Mode." );
			
			// turn off airplane mode no matter what the results
			phoneStress.executeTest( "SetAirplaneMode", 
									 [ "Airplane Mode", "Airplane Mode", 0 ], 
									 settingsTest_changeSingleSwitch, "Turning off airplane mode." );
			
			return result;
		}
		
		// helper function -- pick a contact to add/call
		phoneStress._pickContact = function _pickContact() {
			if (typeof contactsStress != 'undefined') {
				contactName = contactsStress.pickContact().asStr();
			}
			else {
				contactName = UIAUtility.randomFromArray(firstNames) + " " + UIAUtility.randomFromArray(lastNames);
			}
			
			return contactName;
		}
	}
}
