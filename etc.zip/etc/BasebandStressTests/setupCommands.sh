date

source $SCRIPTS_DIR/config.sh

echo " Baseband Reset Happened -- Capturing the output of TOP to make sure things are clean" >> top_output_$DEVICENAME.log
date >> top_output_$DEVICENAME.log
top -o -cpu  -l 10 >> top_output_${DEVICENAME}.log
cp top_output_${DEVICENAME}.log /Library/Logs/CrashReporter/
echo "*********************************************************\n" >> top_output_$DEVICENAME.txt


myDate=`perl -e '($s,$m,$H,$d,$M) = localtime(); $Y += 1900; $M++; printf ("%02d%02d-%02d%02d",$M,$d,$H,$m); ' `
date
echo "Saving locationd logs."
tail -15000 /var/root/Library/Caches/locationd/locationd.log > /var/root/Library/Caches/locationd/locationd-${myDate}.log
cp /var/root/Library/Caches/locationd/locationd-${myDate}.log /Library/Logs/CrashReporter/


date
echo "*******  Sleeping for 2 Seconds:"
sleep 2
echo "Setting up AT Commands... "

#echo "1. Setting up Aeneas Trace Flags..."
#sleep 3
#${SEND_AT_COMMAND} -d ${DLCI_DEV_NODE} "@XL1:aeneas_enable_trace(-1, {00000001 01328e8b 00028457 15250000 29070090 15010000 00000024 00000003 00000021 8002000f 00000027 00000003 00000025 0000000f 00000023 000001fb 00000029 00000387 00000028 00000003 00000022 000001ff 00000037 00000003 00000032 00001003 00000034 00000003 00000039 0000000b 00000033 00000003 00000038 00001f0b 00000036 00000003 00000031 00000003 00000035 00000003 00000041 0000000b 00000047 000001eb 00000048 00000003 00000049 0000000b} )"
#echo "1. Setting up Aeneas Trace Flags..."
#${SEND_AT_COMMAND} -d ${DLCI_DEV_NODE} "@XL1:aeneas_trace_config(0)"
#sleep 2

echo "AT+XMUX=1,3,4095"
${SEND_AT_COMMAND} -d ${DLCI_DEV_NODE} +xmux=1,3,4095
sleep 1
echo "at+xl1set=\"L36\""
${SEND_AT_COMMAND} -d ${DLCI_DEV_NODE} +xl1set="L36"
echo "Done Setting up AT Command.\n\n"
