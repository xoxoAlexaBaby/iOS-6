#import "../libs/SpringBoard.js"
#import "../libs/PHTesting.js"

facebook = UIAApp.application("Facebook", "com.facebook.Facebook");

//----------------------------------------------------------------------------------------
//	facebookTest_launch 
//		Launch facebook and ensure that an expected view is there.
//
//	Parameters: 
//		none
//
//	Returns: 
//		1 if we can verify facebook launched, 0 if not.
//----------------------------------------------------------------------------------------
function facebookTest_launch() {

	facebook.launchIfNotActive();
	var passwordField = facebook.mainWindow().tableViews()[0].cells().firstWithPredicate("ANY secureTextFields.value == 'Password'");
	
	// login page
	if (passwordField.isValid()) {
		UIALogger.logDebug("Facebook found the 'Password' field.  Launched successfully.");
		return this.testResult = 1;
	}
	
	//nav bar with a button should be good enough...
	if (!facebook.navigationBar().buttons()[0].isValid()) {
		this.testError = "No nav bar button found";
		UIALogger.logError(this.testError);
		return this.testResult = 0;
	}
	
	return this.testResult = 1;
}

// Create self tests -- this is an unnamed function, just to make sure any local variables stay in the correct context
(function() {
	if (typeof facebook.selfTests == 'undefined') {
		facebook.selfTests = new Array();
	}
	
	facebook.selfTests.push(phtCreateTest("LaunchFacebook", null, facebookTest_launch, "Launch a purchased 3rd party app 'Facebook'"));
}())