#import "UIAAppStressLibrary.js"

var searchWords = new Array("auto", "pizza", "school", "museum");
var startUSCities = new Array("Los Angeles, CA", "San Francisco, CA", "Seatle, WA", "Washington, D.C.", "New York, NY", "Denver, CO", "Atlanta, GA", "Boston, MA");
var endUSCities = new Array("San Jose, CA", "Grand Canyon, AZ", "Las Vegas, NV", "Orlando, FL", "Nashville, TN", "New Orleans, LA", "Dallas, TX", "Portland, OR", "Portland, ME");


if (typeof maps != 'undefined') {
	mapsStress = AppStressBase.stressTest("Maps");
	
	if (typeof mapsStress != 'undefined') {
		
		mapsStress.setup = function setup() {
			mapsStress.addTest(mapsStress._mapLocation);
			mapsStress.addTest(mapsStress._mapSearchAndSelect);
			mapsStress.addTest(mapsStress._flickDragZoom);
			mapsStress.addTest(mapsStress._mapTraffic);
			mapsStress.addTest(mapsStress._getCurrentLocation);
			mapsStress.addTest(mapsStress._showStreetView);
			mapsStress.addTest(mapsStress._viewLocationDetail);
			mapsStress.addTest(mapsStress._getDirections);
			
			if (STRESS_MAIL_ACCOUNT && STRESS_MAIL_PASSWORD) {
				mapsStress.addTest(mapsStress._shareLocation);
			}
		}
		
		mapsStress.run = function run() {
			mapsStress.executeRandomTests(5);
		}
		
		
		mapsStress._mapLocation = function _mapLocation() {
			var city = randomCityData();
			var search = city.name + ", " + city.country;
			
			mapsStress.executeTest( "MapLocation", [ search ], mapsTest_search, "Mapping " + search + ".");
		}
		
		
		mapsStress._mapSearchAndSelect = function _mapSearchAndSelect() {
			var searchWord = UIAUtility.randomFromArray(searchWords);
			
			mapsStress.executeTest( "MapSearchAndSelect", 
									[searchWord], mapsTest_search, 
									"Searching for " + searchWord + " in maps." );
		}
		
		
		mapsStress._flickDragZoom = function _flickDragZoom() {
			var count = system.randomInteger(1, 10);
			var totalResult = 1;
			var testResult;
			
			for (var i=0; i < count; i++) {
				switch(system.randomInteger(0, 3)) {
					case 0:
						testResult = mapsStress.executeTest("FlickMap", [], mapsTest_flick, "Flicking map (" + (i+1) + "/" + count + ")");
						break;
					case 1:
						testResult = mapsStress.executeTest("DragMap", [], mapsTest_drag, "Dragging map (" + (i+1) + "/" + count + ")");
						break;
					case 2:
						testResult = mapsStress.executeTest("ZoomInMap", [], mapsTest_zoomIn, "Zooming into map (" + (i+1) + "/" + count + ")");
						break;
					case 3:
						testResult = mapsStress.executeTest("ZoomOutMap", [], mapsTest_zoomOut, "Zooming out of map (" + (i+1) + "/" + count + ")");
				}
				
				totalResult = totalResult && testResult;

				system.sleep(7);
			}
			
			return totalResult;
		}
		
		
		mapsStress._mapTraffic = function _mapTraffic() {
			var city = UIAUtility.randomFromArray(startUSCities);
			
			mapsStress.executeTest( "MapTraffic", ["searchLocation:"+city], mapsTest_showTraffic, "Show traffic in maps.");
		}
						
		
		mapsStress._getCurrentLocation = function _getCurrentLocation() {
			mapsStress.executeTest( "GetCurrentLocation", [], mapsTest_getCurrentLocation, "Get the current location.");
		}
		
		
		mapsStress._showStreetView = function _showStreetView() {
			var city = UIAUtility.randomFromArray(startUSCities);
			
			mapsStress.executeTest( "ShowStreetView", ["searchLocation:"+city], mapsTest_showStreetView, "Show street view.");
		}
		
		
		mapsStress._viewLocationDetail = function _viewLocationDetail() {
			var city = randomCityData();
			
			mapsStress.executeTest( "ViewLocationDetail", ["searchLocation:"+city.name], mapsTest_viewLocationDetail, "View location detail.");
		}
		
		
		mapsStress._getDirections = function _getDirections() {
			var startCity = UIAUtility.randomFromArray(startUSCities);
			var endCity = UIAUtility.randomFromArray(endUSCities);
			
			mapsStress.executeTest( "GetDirections", [startCity, endCity], mapsTest_getDirections, "Get map directions.");
		}
		
		
		mapsStress._shareLocation = function _shareLocation() {
			var city = randomCityData();
			
			mapsStress.executeTest( "ShareLocation", 
									[ "sendThru:Email", "mailRecipient:" + STRESS_MAIL_ACCOUNT, "searchLocation:" + city.name ], 
									mapsTest_shareLocation, "Share location via email." );
		}
			
	}
}
