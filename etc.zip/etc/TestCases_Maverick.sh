#!/bin/sh
#################################################################################################
#                                                                                               #
#   ScriptName: TestCases.sh                                                                    #
#                                                                                               #
#   Usage:      <path_to_Script>/TestCases.sh                                                   #
#                                                                                               #
#   Purpose:    This Scripts contains functions for running the test cases on PhoenixStress     #
#                                                                                               #
#   Author:     Jerome Jesu                                                                     #
#   Contact:    jesu@apple.com                                                                  #
#   Version:    v20                                                                             #
#                                                                                               #
#   Copyright   2010 Apple. All rights reserved.                                                #
#################################################################################################


TOOLS_DIR="/usr/local/bin"
protocol=HTTP
OTHERS_DIR="/usr/local/etc/BasebandStressTests/"

###########################################################################
# FUNCTION to Send/Receive (MO/MT) SMS
# USAGE: sendSMS DEVICE_PHONE_NUMBER COUNT SMS_STRING -- count is optional
###########################################################################
sendSMS()
{
	sleep 1
	echo `date` ": _____SENDING SMS START - $dcount,$2 ____"  >> $LOGSFILE
	echo "${TESTCT} -s $1 \"$2 $3\""
	${TESTCT} -s $1 "$2 $3" 2>&1 /tmp/dummy.txt
	grep "SMSSent PASS" /tmp/dummy.txt; resultSms=$?; rm /tmp/dummy.txt;
	
	if [ $resultSms -eq 0 ]; then
		((spass++)); 
		echo `date` ": SMS ($2) Sent Passed.	Pass: $spass\tFail: $sfail." >> SmsStressTest.txt
	else
		((sfail++));
		echo `date` ": _____SMS $2 FAILED - $dcount ____"	>> $LOGSFILE
		echo `date` ": SMS ($2) FAILED. Iteration: $dcount.";
		echo `date` ": SMS ($2) Sent FAILED.	Pass: $spass\tFail: $sfail." >> SmsStressTest.txt
	fi
	echo `date` ": _____SENDING SMS END - $dcount,$2 ____" >> $LOGSFILE
	sleep 1
}

###########################################################################
# FUNCTION to Send/Receive (MO/MT) MMS
# USAGE: sendSMS DEVICE_PHONE_NUMBER COUNT MMS_FILE -- count is optional
###########################################################################
sendMMS()
{
	sleep 1
	echo `date` ": _____SENDING MMS - $3 - START - $dcount,$2 ____"  >> $LOGSFILE
	echo "${TESTCT} -m $1 \"$3\""
	${TESTCT} -m $1 "$3" > /tmp/dummy.txt
	echo `date` ": _____SENDING MMS END - $dcount,$2 ____" >> $LOGSFILE
	
	grep "MSSent PASS" /tmp/dummy.txt; resultmms=$?; rm /tmp/dummy.txt;
	if [ $resultmms -eq 0 ]; then
		((mpass++)); 
		echo `date` ": MMS ($2) Sent Passed.	Pass: $mpass\tFail: $mfail." >> SmsStressTest.txt
	else
		((mfail++)); echo `date` ": MMS ($2) FAILED. Iteration: $dcount.";
		echo `date` ": MMS ($2) Sent FAILED.	Pass: $mpass\tFail: $mfail." >> SmsStressTest.txt
		if [ $smsFailureLogs ]; then takeK00lState "Sending_MMS--$2--FAILED."; fi
	fi
	sleep 5;
}


###########################################################################
# FUNCTION to Make a MO Call
# USAGE: makeCall LOOPBACKNUMBER CALL_INTERVAL COUNT (optional)
###########################################################################
checkForExistingCall()
{
	${TESTCT} -x | grep status
	if [ $? -eq 0 ]; then 
		${CT_MONITOR} -q 2> CT.txt
		echo "**** Iteration $dcount" >> CallsStressTest.txt;
		date  >> CallsStressTest.txt;
		grep "Call to " CT.txt >> CallsStressTest.txt
		echo `date` ": ***** Ongoing Call before Dialing Call ($1).... Ending it now" >> CallsStressTest.txt;
		echo "***** Calls are still active... even though they should be ended by now. Ending them now"
		/usr/local/etc/scripterUIA/general/ExecuteTest.js phoneTest_endCall
		eventer c "End"    #end all active calls
		echo "Checking Call Status again"
		${TESTCT} -x
	else
		echo " There are no active calls to end."
	fi
}

makeCALL()
{	
	echo `date` ": Sleeping for 7 seconds before making Voice Call"
	sleep 7;
	echo `date` ": _____MOCALL $2 START - $dcount ____" >> $LOGSFILE
	checkForExistingCall $3
	${TESTCT} -c $1 > /tmp/dummy.txt
	sleep $2; 
	grep "CallStatusActive PASS" /tmp/dummy.txt; resultCall=$?; rm /tmp/dummy.txt;
	
	if [ $resultCall -eq 0 ]; then
		((pass++))
		echo `date` ": Call ($3) passed.  Passed: $pass\tFailed: $fail." >> CallsStressTest.txt;
		echo `date` ": _____MOCALL $2 PASSED - $dcount ____"	>> $LOGSFILE
		${TESTCT} -e

	else
		((fail++)); echo `date` ": Call ($3) FAILED. Iteration: $dcount.";
		echo `date` ": Call ($3) FAILED.  Passed: $pass\tFailed: $fail." >> CallsStressTest.txt;
		echo `date` ": _____MOCALL $2 FAILED - $dcount ____"	>> $LOGSFILE
	fi

	echo `date` ": _____MOCALL $2 END - $dcount ____"	>> $LOGSFILE
	sleep 5
} 


###########################################################################
# FUNCTION to Check if WiFi is enabled.
###########################################################################
checkWiFiEnabled()
{
	WiFiEnabled=
	WiFiEnabled=`ifconfig -a | perl -lne ' if ( !/pdp/) { print;} else {exit};' | perl -lne ' if ( /inet / && ! /127.0.0.1/ ){ print 1; exit 0}'`
	echo "******WiFiEnabled = $WiFiEnabled;"
	if [ "$WiFiEnabled" ]; then echo "Disabling WiFi since it is enabled..."; disableWifi; fi
}

printDownloadRates()
{
	FOUND=`grep Average /tmp/DownloadDummy.txt`
	echo `date` ": _____DOWNLOAD - Attempts = $DataAttempts, Rate = $FOUND _____" >> $LOGSFILE
}

printUploadRates()
{
	FOUND=`grep Average /tmp/UploadStressTest.txt`
	echo `date` ": _____UPLOAD - Attempts = $uploadAttempts, Rate = $FOUND _____" >> $LOGSFILE
}

getPingParameters()
{		
		length=${#PING_PACKET_SIZE[@]}
		index=$((RANDOM % $length))
		packetSize=${PING_PACKET_SIZE[$index]}
		maxPings=$((RANDOM % 10 +  5))
		pingCount=$((10 - $index))
		
		length=${#PING_INTERVALS[@]}
		index=$((RANDOM % $length))
		pingInterval=${PING_INTERVALS[$index]}
}

stopKillingProcess()
{
	stopKilling=`ps -A | grep killHungProcess | grep -v grep | awk '{print $1}'`
	kill -9 $stopKilling
}


###########################################################################
# Function to Download Data using StreamPerf
# USAGE: DownloadData URL TIMES_to_REPEAT COUNT (optional)
###########################################################################
DownloadData() 
{
	sleep 1
	webpage=$2
	wAttempts=$1
	echo "checking whether WiFi is enabled..."
	checkWiFiEnabled
	pdpid=0
	activatePDPContext $pdpid

	if [ $proceedDataTransfer -eq 1 ]; 
	then
	
		((DataAttempts++))
		echo "\n #####  $3. Dowloading $webpage  $wAttempts time(s)."; date;
		echo `date` " #####  $3. Dowloading $webpage  $wAttempts time(s). #####" >> DownloadStressTest.txt
		echo `date` ": _____DOWNLOADDATA $webpage START - $dcount,$3 _____"  >> $LOGSFILE
		nohup $OTHERS_DIR/killHungProcess.sh "StreamPerf" 300 &
		${STREAMPERF} HTTP -MT ${MAX_TIME_FOR_DOWNLOADS} -c $pdpid -x $wAttempts $webpage > /tmp/DownloadDummy.txt
	
		cat /tmp/DownloadDummy.txt >> DownloadStressTest.txt
		#if [ $logDataFailure -eq 1 ]; then logDataDownloadFailures $dcount $3 $wAttempts; fi
		logDataDownloadFailures $dcount $3 $wAttempts;
		echo `date` ": Downloading $2 $1 time(s) finished.";
		
		printDownloadRates
		stopKillingProcess
		echo `date` ": _____DOWNLOADDATA $webpage END - $dcount,$3 _____"  >> $LOGSFILE

	fi
	#echo `date` ": _____DEACTIVATE PDP - $dcount _____"  >> $LOGSFILE
	#${TOOLS_DIR}/DataContext -c $pdpid down;
	sleep 5;
}

###########################################################################
# FUNCTION to do uploads
# USAGE: uploadData 
###########################################################################
UploadData()
{
	sleep 1
	echo `date` ": _____UPLOADDOWNLOAD START - $dcount _____"  >> $LOGSFILE
	if [ "$1" ]; then fileSize=$1;
	else fileSize=1; fi
	
	#uploadServer=$iPERFURL
	uploadServer="ftp://testftp:tftp95014*@pttest.apple.com/Bandwidth/iceTest.txt"
	date
	pdpid=0
	activatePDPContext $pdpid
	
	if [ $proceedDataTransfer -eq 1 ]; then
	
		((uploadAttempts++));
		uploadSize=`expr $fileSize \* 1048576`
		
		echo `date` ": _____UPLOAD - Uploading $uploadSize to $uploadServer START - $dcount _____"  >> $LOGSFILE
		echo `date` " #####  $dcount. Uploading $uploadSize to $uploadServer #####" >> UploadStressTest.txt 
		nohup $OTHERS_DIR/killHungProcess.sh "StreamPerf" 180 &
		ps -A | grep StreamPerf
		
		${STREAMPERF} FTP -c $pdpid -MT ${MAX_TIME_FOR_DOWNLOADS} -e -w -N $uploadSize $uploadServer >& /tmp/UploadStressTest.txt
		cat /tmp/UploadStressTest.txt >> UploadStressTest.txt
		cat /tmp/UploadStressTest.txt
		logDataUploadFailures
		
		printUploadRates
		stopKillingProcess

	fi
	
	echo `date` ": _____UPLOAD END - $dcount _____"  >> $LOGSFILE
	sleep 5;
}



###########################################################################
# FUNCTION to do uploads
# USAGE: uploadData 
###########################################################################
UploadData1()
{
	pdpid=0
	activatePDPContext $pdpid	
	echo `date` ": PING TEST START: "
	echo `date` ": _____UPLOADDATA1 - PING TEST START - $dcount ____" >> $LOGSFILE
	getPingParameters

	echo `date` ": _____UPLOADDATA1 - ping -s $packetSize -c $pingCount -i $pingInterval google.com ____" >> $LOGSFILE

	echo "ping -s $packetSize  -c $pingCount  -i $pingInterval google.com"
	ping -b pdp_ip0 -s $packetSize  -c $pingCount  -i $pingInterval google.com	

	echo `date` ": _____UPLOADDATA1 - PING TEST END - $dcount ____" >> $LOGSFILE
}

## iPERF REMOVED
		#uploadServer=$iPERFURL
		#echo "${TOOLS_DIR}/iperf -c $uploadServer -n 500k"
		#${TOOLS_DIR}/iperf -c $uploadServer -n 500k > /tmp/UploadStressTest.txt 
		#${TOOLS_DIR}/iperf -c $uploadServer -n 1M > /tmp/UploadStressTest.txt 
## iPERF REMOVED


###########################################################################
# FUNCTION to do simultaneous uploads and downloads
# USAGE: uploadDownloadData 
# PARAMS: 1.$Repetition  2.$URL  3.$waitUploadDownload 
# PARAMS: 4.countForLogs(optional)
###########################################################################
uploadDownloadData()
{
	sleep 1
	echo `date` ": _____UPLOADDOWNLOAD START - $dcount _____"  >> $LOGSFILE
	wAttempts=$1
	webpage=$2
	waitUploadDownload=$3
	pdpid=0
	fileSize=2
	date;

	echo "checking whether WiFi is enabled..."
	checkWiFiEnabled
	activatePDPContext $pdpid


	if  [ $proceedDataTransfer -eq 1 ]; then
		
		stopKillingProcess
		((DataAttempts++))
		((uploadAttempts++));
		uploadSize=`expr $fileSize \* 1048576 `
		uploadServer="ftp://testftp:tftp95014*@pttest.apple.com/Bandwidth/mytest"
		
		## Download
		echo `date` ": _____UPLOADDOWNLOAD-Downloading  $2 START - $dcount,$4 _____"  >> $LOGSFILE
		echo " #####  $4. Dowloading $2  $wAttempts time(s).";date;
		echo `date` ": #####  $4. Dowloading $2  $wAttempts time(s). #####" >> DownloadStressTest.txt 
		${STREAMPERF} HTTP -MT ${MAX_TIME_FOR_DOWNLOADS} -c $pdpid -x $wAttempts $webpage > /tmp/DownloadDummy.txt  &
		ps -A | grep StreamPerf


		# Kill Hung Process
		date; echo;
		nohup $OTHERS_DIR/killHungProcess.sh "StreamPerf" 300 &

		
		## UPLOAD
		echo `date` ": _____UPLOADDOWNLOAD - Uploading START - $dcount _____"  >> $LOGSFILE
		echo " #####  $dcount. Uploading Data to $uploadServer";date;
		echo `date` "\n #####  $dcount. Uploading $uploadSize MB to $uploadServer #####" >> UploadStressTest.txt 
		${STREAMPERF} FTP -c $pdpid -MT ${MAX_TIME_FOR_DOWNLOADS} -e -w -N $uploadSize $uploadServer > /tmp/UploadStressTest.txt
		cat /tmp/UploadStressTest.txt
		
		echo `date` ": Sleeping for $waitUploadDownload seconds..."
		sleep $waitUploadDownload

		UploadData1
		
		cat /tmp/UploadStressTest.txt >> UploadStressTest.txt
		cat /tmp/DownloadDummy.txt >> DownloadStressTest.txt
		logDataDownloadFailures $dcount $3 $wAttempts;
		logDataUploadFailures
		printDownloadRates
		printUploadRates
		
		stopKillingProcess
		#$TOOLS_DIR/DataContext down
	
	fi
}


###########################################################################
# Activate PDP Context and check for Failures
###########################################################################
activatePDPContext()
{
	if [ "$1" ]; then pdpid=$1;
	else pdpid=0; fi
	((pdpAttempts++))
	proceedDataTransfer=1
	
	echo `date` ": _____ACTIVATE PDP START - $dcount _____"  >> $LOGSFILE
	${TOOLS_DIR}/DataContext -c $pdpid up >& /tmp/DataContextStatus
	cat /tmp/DataContextStatus  >> DataContextStatus.txt
	
	echo "****Search Result"
	grep -c -i  "Fail" /tmp/DataContextStatus
	result=`grep -c -i "Fail" /tmp/DataContextStatus`
	echo "**** RESULT = $result..."
	
	if [ $result -ne 0 ]; then
		((pdpFails++)); 
		if [ $dataFailureLogs -eq 1 ]; then  
			${TESTCT} -l "$dcount Dump State: PDP_$pdpid Activation Failure";
			sleep 10
		fi
		echo `date` " : **** PDP Context $pdp_id Activation FAILED for ${dcount}-${activationCount}";
		#proceedDataTransfer=0
	fi
	
	date
	commUpdate=`grep -c "t get updated status from CommCenter" /tmp/DataContextStatus`
	if [ $commUpdate -gt 0 ]; then
		echo `date` " **** ERROR:  Didn't get updated status from CommCenter..."
		((pdpFails++))
		#echo `date` ": Collecting Samples of CommCenter, simulatecrash and ps -A"
		#echo `date` ": /usr/bin/sample CommCenter"
		#/usr/bin/sample CommCenter
		#cp /tmp/*sample.txt /var/mobile/Library/Logs/CrashReporter/
		#Comm=`ps -A | grep Comm | grep -v grep | awk '{print $1}'`
		#echo `date` ": /usr/bin/simulatecrash -k $Comm"
		#/usr/bin/simulatecrash -k $Comm
		#ps -A
		#${TESTCT} -l "Dump State: Didn't get updated status from CommCenter"
		#sleep 10
		#proceedDataTransfer=0
	fi
	date
	
	#rm /tmp/DataContextStatus
	echo `date` ": _____ACTIVATE PDP END - $dcount, result=$result, proceed=$proceedDataTransfer _____"  >> $LOGSFILE
}


#########################################################
# STOP and START LOCMON on the background every 25 iterations
#########################################################
startLocmon()
{
	echo `date` ": _____startLocmon: LOCMON START - $count _____"  >> $LOGSFILE
	echo `date` " *** STARTING GPS IN THE BACKGROUND"
	echo `date` " ${LOCMON} -l -m ${LOCMON_RUNTIME} -z ${LOCMON_SLEEPTIME}"
	${LOCMON} -l -m ${LOCMON_RUNTIME} -z ${LOCMON_SLEEPTIME}  2> locmonStressTest_${dcount}.txt  &
}

restartLocmonIfStopped()
{
	echo `date` "Finding Locmon Process.."
	PIDS=`ps -A | grep locmon | perl -lne ' if ( !/grep/ ) { @L = split; $L[0] =~ s/\s*//g; print $L[0];} ' `
	
	if [ "$PIDS" ]; then 
		echo `date` " Locmon is still running so not doing anything"; 
	else 
		echo `date` ": _____restartLocmonIfStopped: RESTARTING LOCMON - $dcount _____"  >> $LOGSFILE
		echo `date` ": Restarting Locmon since it is not running."
		${LOCMON} -l -m ${LOCMON_RUNTIME} -z ${LOCMON_SLEEPTIME}  2> locmonStressTest_${dcount}.txt  &
	fi
	
	echo `date` ": _____restartLocmonIfStopped: Locmon Started - $dcount _____"  >> $LOGSFILE
}

stopStartLocmon()
{
	echo `date` ": Entering Function to check whether GPS is running... "
	PIDS=`ps -A | grep locmon | perl -lne ' if ( !/grep/ ) { @L = split; $L[0] =~ s/\s*//g; print $L[0];} ' `
	echo `date` ": Killing Processes  --- $PIDS.\n"
	echo `date` ": _____Locmon STOP Process IDs-> $PIDS - $dcount _____"  >> $LOGSFILE
	kill $PIDS
	echo `date` ": _____Locmon PAUSE - $dcount _____"  >> $LOGSFILE
	sleep 30
	${LOCMON} -l -i 2> locmonStressTest.txt &
	echo `date` ": _____Locmon START - $dcount _____"  >> $LOGSFILE
}


###########################################################################
# Function to Dump the Unwanted Logs 
###########################################################################
dumpLogs()
{
		echo ": Dumping Logs after $1 iterations using SIGUSR2...   \c"; date;
		${TESTCT} -l "Dumping logs after $dcount iternations"
		sleep 10
}

getRegistrationStatus()
{
		echo `date` "Dumping CoreTelephonyMonitorStats: "
		${CT_MONITOR} -q 2> CT.txt
		echo `date` " **** Iteration $dcount" >> RegistrationStatus.txt
		date  >> RegistrationStatus.txt
		egrep "Data Indicator:|Operator:|Registration Status:|Data 0 " CT.txt >> RegistrationStatus.txt
}


#########################################################
# Functions to check whether Baseband is in reset state
# or Power Asserted before entering Sleep Cycler.
#########################################################
checkResetState()
{
	isBBReset=0
	${CT_GET_RESET_STATE} | grep "CommCenter in reset state";
	
	if [ $? -eq 0 ]; then isBBReset=1;
	else isBBReset=0;
	fi
	
	echo `date` "CheckResetState: isBBReset = $isBBReset."
}

checkPowerAssertion()
{
	isPowerAsserted=1
	powerCount=0
	#assertion=`${TOOLS_DIR}/powerstat  | head -n 2 | tail -n 1 | tr -d ' '`

	while [ $isPowerAsserted -eq 1 ]; do
		assertion=`${TOOLS_DIR}/powerstat | grep PreventUserIdleSystemSleep | grep -v springboard`
		echo `date` "Assertions: $assertion"
		
		if [ "$assertion" ]; then
			((powerCount++))
			echo "PowerCount = $powerCount, assertion= $assertion"
			isPowerAsserted=1
		else
			isPowerAsserted=0
			echo "No Power Assertion.. Assertion=$assertion, isPowerAsserted=$isPowerAsserted."
			break;
		fi
		
		if [ $powerCount -gt 2 ]; then 
			echo "PowerCount = $powerCount, assertion= $isPowerAsserted"
			break; 
		fi
		sleep 5

	done
}

readyToRunSleepCycler()
{
	timeToSleep=0
	maxTimeToWait=210
	
	checkResetState
	
	while [ $isBBReset -eq 1 ]; 
	do
		echo `date` "Sleeping for 30 seconds before checking again."
		sleep 30;
		timeToSleep=$(($timeToSleep + 30));
		
		if [ $timeToSleep -ge $maxTimeToWait ]; then 
			echo "Max Timer exceeded $maxTimeToWait seconds wait period."
			break; 
		fi
		echo "checking again after $timeToSleep seconds... since isBBReset = $isBBReset."
		checkResetState
		
	done
	
	checkPowerAssertion
	echo `date` "checkPowerAssertion: isPowerAsserted = $isPowerAsserted, $assertion."
	echo `date` "readyToRunSleepCycler: isBBReset = $isBBReset. isPowerAsserted = $isPowerAsserted."

}


#########################################################
# run SleepCycler for 1 iteration $2=sleepTime $1=Count
#########################################################
runSleepCycler()
{	
	echo `date` "Check if we are READY to run SleepCycler..."
	sleep 5
	readyToRunSleepCycler
	#isBBReset=0
	#isPowerAsserted=0
	
	if [ $isBBReset -eq 0 ] && [ $isPowerAsserted -eq 0 ]; then
		echo `date` ": _____DEVICE ENTERING SLEEP -- RESET=$isBBReset,POWER=$isPowerAsserted-$assertion - $dcount,$1, STIME = $2 _____"  >> $LOGSFILE
		echo `date` "\n$1. Sleepcycling 1 time -n 1 -s $2";
		${TOOLS_DIR}/SleepCycler -n 1 -s $2;
		echo `date` ": _____WAKE UP FROM SLEEP - LOOP = $dcount,$1, STIME = $2 _____"
		echo `date` ": _____WAKE UP FROM SLEEP - LOOP = $dcount,$1, STIME = $2 _____"  >> $LOGSFILE
	else 
		echo "Skipping SleepCycler since Baseband is resetting or Power Asserted..."
		echo `date` ": _____NO SLEEPCYCLING -- RESET=$isBBReset,POWER=$isPowerAsserted-$assertion - $dcount,$1 _____"  >> $LOGSFILE
	fi
	
}


collectTopOutputOnly()
{
	echo `date` ": _____COLLECTING TOP OUTPUT - $dcount _____"  >> $LOGSFILE
	echo " *********************************************************\n\n" >> top_output_${DEVICENAME}_${dcount}.txt
	echo " ******  Capturing output of TOP" >> top_output_${DEVICENAME}_${dcount}.txt
	date >> top_output_$DEVICENAME.txt
	top -o -cpu -s 5 -l 10 >> top_output_${DEVICENAME}_${dcount}.txt  &
}

logDataUploadFailures()
{
	echo `date` ": _____LOGGING DATA UPLOAD FAILURES - $dcount _____"
	
	isUploadPASS=`perl -lne 'BEGIN {$count = 0; }  END { print "$count"; }  if (/Mean Throughput|Average Throughput/) { @w = split; $count++ if ( $w[4] =~ /^\d{1,3}[.]\d{1,4}/ & $w[4] !~ /^[0]{1,3}[.][0]{3,}/ ); } ' /tmp/UploadStressTest.txt `
	upThroughput=`cat /tmp/UploadStressTest.txt | egrep "Mean Throughput|Average Throughput" |
				perl -lne '	BEGIN {$rate = 0; }   END { print "$rate"; }  @w = split; 
					if ( $w[4] =~ /^\d{1,3}[.]\d{1,5}/ & $w[4] !~ /^[0]{1,3}[.][0]{3,}/ ) { $rate = $w[4] } ' `
		
	if [ $isUploadPASS -gt 0 ]; then ((uploadPassCount++)); else  ((uploadFailCount++)); fi

	echo "******** Upload Attempts -> $uploadAttempts, Upload Fail Count -> $uploadFailCount; Upload Pass Count -> $uploadPassCount---$isUploadPASS($upThroughput)." >> UploadStressTest.txt	
		
}


###########################################################################
#  WIFI Upload Helper Functions
###########################################################################
enableWifi()
{
	#echo "Enable WiFi -- ${TOOLS_DIR}/mobilewifitool -- device power -i en0 1"
	#${TOOLS_DIR}/mobilewifitool -- device power -i en0 1 
	echo "/usr/local/etc/scripterUIA/general/ExecuteTest.js settingsTest_setWifi 1"
	#/usr/local/etc/scripterUIA/general/ExecuteTest.js settingsTest_setWifi 1
	/usr/local/bin/WirelessTester -command "wifi.on" > WiFiOn.txt;
}

disableWifi()
{
	#echo "${TOOLS_DIR}/mobilewifitool -- device power -i en0 0"
	#${TOOLS_DIR}/mobilewifitool -- device power -i en0 0
	echo "/usr/local/etc/scripterUIA/general/ExecuteTest.js settingsTest_setWifi 0"
	#/usr/local/etc/scripterUIA/general/ExecuteTest.js settingsTest_setWifi 0
	/usr/local/bin/WirelessTester -command "wifi.off" > WiFiOff.txt;
}

getSSID()
{
	echo "Checking again for SSID - $SSID."
	${TOOLS_DIR}/apple80211 -ssid > /tmp/currentssid
	grep "$SSID" /tmp/currentssid
	isCorrectSSID=$?
}

stopKilling()
{
	GREP="grep killHungProcess"
	PIDS=`ps -A | $GREP | perl -lne 'chomp; if ( !/grep/ ) { $p = (split)[0]; $p =~ s/\s*//g; print $p;} ' `;
	PidsSleep=`ps -A | grep "sleep [1-6]" | perl -lne 'chomp; if ( !/grep/ ) { $p = (split)[0]; $p =~ s/\s*//g; print $p;} ' `;
	kill -9 $PIDS
	kill -9 $PidsSleep
}

uploadIQMetrics()
{
	if [ $EnableAWD -eq 1 ]; then
		echo `date` ": AWD Agent Uploading is enabled. Upload stats to the AWD server."
		${TESTCT} -c "#*362253293#"
		${TESTCT} -c "#*782648#"
		sleep 60
	fi
}


###########################################################################
# Function to join WIFI n/w repeatedly until it succeeds in MAX_JOIN_ATTEMPTS
###########################################################################
joinWifiNetwork()
{
	attempt=0
	doUpload=0
	if [ -e $SCRIPTS_DIR/config_maverick.sh ]; then
		echo `date` ": config_maverick.sh file is present. Getting the values.";
		source $SCRIPTS_DIR/config_maverick.sh;
		SSID=$DEFAULT_SSID; 	
		WEPKEY=$DEFAULT_WEP_KEY;
		SECURITY=$DEFAULT_SECURITY;
		if [ $changeSSID -eq 1 ]; then 
			SSID="Dejavu";
			WEPKEY="csin92qa";
		elif [ $changeSSID -eq 2 ]; then 
			SSID="CAPSULE";
			WEPKEY="123456789b";
		elif [ $changeSSID -eq 3 ]; then 
			SSID="ANDROMEDA1";
			WEPKEY="777711112b";
		fi
	else
		echo `date` ": WiFiSettings.sh file is not present... Going with Default Settings.";
		if [ $changeSSID -eq 1 ]; then 
			SSID="Dejavu";
			WEPKEY="csin92qa";
		elif [ $changeSSID -eq 2 ]; then 
			SSID="CAPSULE";
			WEPKEY="123456789b";
		elif [ $changeSSID -eq 3 ]; then 
			SSID="ANDROMEDA1";
			WEPKEY="777711112b";
		fi

	fi

	echo `date` ": _____JOINING WIFI NETWORK $SSID - $dcount_____"  >> $LOGSFILE
	echo `date` ": Powering on radio."
	nohup $OTHERS_DIR/killHungProcess.sh "mobilewifitool" 60 &
	enableWifi
	sleep 2
	
	
	while [ $attempt -le $MAX_JOIN_ATTEMPTS ]
	do
		echo `date` ": ${TOOLS_DIR}/wifitool -s -j $SSID -e $SECURITY -p $WEPKEY -d 20"
		${TOOLS_DIR}/wifitool -s -j $SSID -e $SECURITY -p $WEPKEY -d 20  > /tmp/reg_dump.txt
		sleep 3
		grep "error 0" /tmp/reg_dump.txt; success=$?; rm /tmp/reg_dump.txt;
	
		if [ $success -ne 0 ]; then 
			((attempt++))
			doUpload=0
		else
			sleep 5
			doUpload=1
			echo `date` " **** Successfully Joined - $SSID - network. DoUpload - $doUpload****"
			break
		fi
		
		if [ $attempt -eq $MAX_JOIN_ATTEMPTS ]; then 
			doUpload=0;
			((wifiFailCount++))
			echo " Cannot Join WiFi Network. Joining $SSID Failed after $attempts attempts."
			echo " UPLOADING FAILED !!!!!!!!";
			echo " Powering down WiFi"
			echo " Resetting WiFi chip as a workaround !!!!!!!!!!!"
			#if [ $SSID != "CSIQA" ] &&  [ ${wifiFailCount} -ge 5 ]; then
				#echo " Resetting WiFi chip as a workaround !!!!!!!!!!!"
				#/usr/local/bin/apple80211 -ssid=w
			#	wifiFailCount=0
			#fi
			disableWifi
			echo `date` ": _____UPLOADING FAILED - $dcount_____"  >> $LOGSFILE
		fi
		
	done
}

###########################################################################
# Function to upload Stats to the Server using SSID - CSIQA
###########################################################################
uploadStats()
{
	echo `date` ": _____UPLOADING STATS START - $dcount_____"  >> $LOGSFILE
	joinWifiNetwork
	uploadIQMetrics
	isCorrectSSID=0
	
	if [ $doUpload -eq 1 ]; then
			echo `date` ": _____Wifi Associated Uploading Stats - $dcount____"  >> $LOGSFILE
			nohup $OTHERS_DIR/killHungProcess.sh "tcpClient.pl" 60 &
			echo `date` ": $OTHERS_DIR/tcpClient.pl $SERVER_ADDR $serverDir $ResultsFile"
			perl $OTHERS_DIR/tcpClient.pl $SERVER_ADDR $serverDir $ResultsFile 
			sleep 2

			nohup $OTHERS_DIR/killHungProcess.sh "tcpClient.pl" 60 &
			echo `date` ": $OTHERS_DIR/tcpClient.pl $SERVER_ADDR $serverDir $CsiLogsFile"
			perl $OTHERS_DIR/tcpClient.pl $SERVER_ADDR $serverDir $CsiLogsFile 
			sleep 2			
		
			sleep 15
			echo "Powering down WiFi"
			disableWifi
			echo " Dissassociated from $SSID and Wifi Radio Powered down."
	else
			echo `date` ": _____UNABLE TO JOIN WIFI  - $dcount____"  >> $LOGSFILE

	fi
	date
	stopKilling
	doUpload=0
	echo `date` ": _____UPLOADING STATS END - $dcount_____"  >> $LOGSFILE
}


###########################################################################
# Function to upload Logs to the Server using SSID - CSIQA
###########################################################################
uploadLogs()
{
	echo "Entering function UploadLogs to upload Logs to $SSID."
	echo `date` ": _____UPLOADING LOGS START - $dcount_____"  >> $LOGSFILE
	joinWifiNetwork
	echo `date` ": _____UPLOADING LOGS - IQ METRICS USING WIFI - $dcount_____"  >> $LOGSFILE
	uploadIQMetrics
	
	if [ $doUpload -eq 1 ]; then
		fileCount=0
		
		totalCrashesToUpload=`ls  $crashDir/*.log $crashDir/*.plist $wirelessDir/*.plist $mobileDir/Retired/*plist $mobileLogs | wc -l | perl -lne ' s/\s*//; print'`	
		echo `date` ": _____UPLOADING LOGS - CRASH LOGS Crashes = $totalCrashesToUpload - $dcount_____"  >> $LOGSFILE

		for fname in  $wirelessDir/*.plist  $crashDir/*log $crashDir/*.plist $mobileLogs $mobileDir/Retired/*plist; do
			((fileCount++))
			echo "\n\n Crash logs.. $fileCount. $fname"
			uploadSleep=120
					
			nohup $OTHERS_DIR/killHungProcess.sh "tcpClientBin.pl" $uploadSleep &
			date
			
			if [ $totalCrashesToUpload -gt 0 ] && [ $fileCount -le $MAX_FILES_TO_UPLOAD ]; then
				echo `date` ":$OTHERS_DIR/tcpClientBin.pl $SERVER_ADDR $serverDir $DEVICENAME/ $fname"
				perl $OTHERS_DIR/tcpClientBin.pl $SERVER_ADDR $serverDir $DEVICENAME/ $fname 
				success=$?
				ps -A
					
				if [ $success -eq 10 ]; then 
					echo "$fname -- Uploaded Successfully.";
					((totalUploaded++)); success=0;
				else
					break;			
				fi
				stopKilling
			else
				break
			fi			
		done
		
		echo `date` ": _____UPLOADING LOGS - CRASHES UPLOADED TOTAL = $totalUploaded - $dcount_____"  >> $LOGSFILE
		fileCount=0 
		totalBBLogsToUpload=`ls $logsDir/*  | wc -l | perl -lne ' s/\s*//; print'`


		echo `date` ": _____UPLOADING LOGS - BASEBAND LOGS TOTAL = $totalBBLogsToUpload - $dcount_____"  >> $LOGSFILE
		for fname in $logsDir/*; do
			((fileCount++))
			echo "\n\n Crash logs.. $fileCount. $fname"
			uploadSleep=240
			
			nohup $OTHERS_DIR/killHungProcess.sh "tcpClientBin.pl" $uploadSleep &
			date
			
			if [ $totalBBLogsToUpload -gt 0 ] && [ $fileCount -le $MAX_FILES_TO_UPLOAD ]; then
				echo `date` ": $OTHERS_DIR/tcpClientBin.pl $SERVER_ADDR $serverDir $DEVICENAME/Baseband/ $fname"
				perl $OTHERS_DIR/tcpClientBin.pl $SERVER_ADDR $serverDir $DEVICENAME/Baseband/ $fname
				success=$?
					
				if [ $success -eq 10 ]; then 
					echo "$fname -- Uploaded Successfully.";
					((totalUploaded++)); success=0;
				else
					break;			
				fi
				stopKilling
			else
				break;
			fi			

		done
		totalFilesToUpload=$(($totalBBLogsToUpload + $totalCrashesToUpload))

		echo "Powering down WiFi..."
		disableWifi
		date
		echo "\n  ******* Total Files Waiting for Upload - $totalFilesToUpload.\n"
		echo "\t Files Uploaded on this run - $totalUploaded"
		echo "\t Total Crashes to upload - $totalCrashesToUpload"
		echo "\t Total Baseband Logs - $totalBBLogsToUpload"
		echo "  ******* Total Uploaded So Far from the Device - $filesUploadedSoFar.\n"

	else
			echo `date` ": _____UNABLE TO JOIN WIFI  - $dcount____"  >> $LOGSFILE

	fi
	
	date
	stopKilling
	sleep 60
	doUpload=0
	echo `date` ": _____UPLOADING LOGS END - $dcount_____"  >> $LOGSFILE
}
