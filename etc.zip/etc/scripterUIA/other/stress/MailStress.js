#import "UIAAppStressLibrary.js"

STRESS_MAIL_ACCOUNT = null;
STRESS_MAIL_PASSWORD = null;

var MAIL_PREFERENCES_FILE = "com.apple.AppStressMailAccount";
var LARGE_EMAIL_FILE = "MailStressLargeEmail.html";

if (typeof mail != 'undefined') {
	mailStress = AppStressBase.stressTest('Mail');
	
	if (typeof mailStress != 'undefined') {
		
		mailStress.setup = function setup() {
			// unlike most setup functions, we don't return false from this one as it will stop the entire run
			// instead, we set STRESS_MAIL_* to null which prevents mail tests from being run
			
			// set up mail accounts
			if (!(STRESS_MAIL_ACCOUNT && STRESS_MAIL_PASSWORD)) {
				STRESS_MAIL_ACCOUNT = system.getDefault(MAIL_PREFERENCES_FILE, "account");
				STRESS_MAIL_PASSWORD = system.getDefault(MAIL_PREFERENCES_FILE, "password");
				
				if (!(STRESS_MAIL_ACCOUNT && STRESS_MAIL_PASSWORD)) {
					UIALogger.logError("No email account information provided -- mail tests will not be run.");
					return true;
				}
				
				// open mail and check to see that at least one account has been created
				mail.launchIfNotActive();
				system.sleep(2);
				
				// if we see the 'Welcome to Mail' navigation bar, then no accounts have been created
				if (mail.visibleElementsWithName(mail.mainWindow().navigationBar(), 'Welcome to Mail').length > 0) {
					if (!mailStress.executeTest( "CreateEmailAccount",
												 [ "me", "TestingTester", STRESS_MAIL_ACCOUNT, STRESS_MAIL_PASSWORD, 
												   "notesSync:false", "contactsSync:false", "calendarsSync:false", "bookmarksSync:false" ],
												 settingsTest_createEmailAccount,
												 "Create an email account." )) {
						STRESS_MAIL_ACCOUNT = null;
						STRESS_MAIL_PASSWORD = null;
						return true;
					}
				}
			}
			
			// workaround for <rdar://problem/8241073>
			if (UIATarget.localTarget().model() != "iPad") {
				try {
					settings.launchIfNotActive();
					settings.navigateNavigationViews(["Mail, Contacts, Calendars"], {returnToTopLevel:true});
					var acctButton = settings.mainWindow().tableViews()[0].scrollToElementWithPredicate("name matches '.*" + STRESS_MAIL_ACCOUNT + ".*'")
					
					if (acctButton.isValid()) {
						acctButton.tap();
						settings.setSwitchSetting("Contacts", 0);
						settings.setSwitchSetting("Calendars", 0);
						settings.setSwitchSetting("Bookmarks", 0);
						
						if (system.hasCapability('multi-tasking')) {
							settings.setSwitchSetting("Notes", 0);
						}
					}
	
				}
				catch (e) {
					UIALogger.logError("Unable to check mail account settings, error: " + e);
					STRESS_MAIL_ACCOUNT = null;
					STRESS_MAIL_PASSWORD = null;
					return true;
				}
			}

			// add test cases
			mailStress.addTest(mailStress._composeAndSendRandomMessage);
			mailStress.addTest(mailStress._deleteRandomMailMessage);
			mailStress.addTest(mailStress._searchMail);
			mailStress.addTest(mailStress._downloadLargeEmail);
			
			return true;
		}
		
		mailStress.init = function init() {
			var result = true;
			
			if (!(STRESS_MAIL_ACCOUNT && STRESS_MAIL_PASSWORD)) {
				// try to set them up again
				mailStress.setup();
			}
			
			return (STRESS_MAIL_ACCOUNT && STRESS_MAIL_PASSWORD) ? true : false;
		}
		
		mailStress.run = function run() {
			mailStress.executeRandomTest();
		}
		
		
		mailStress._composeAndSendRandomMessage = function _composeAndSendRandomMessage() {
			mailStress.executeTest( "ComposeAndSendRandomMessage", 
									[ STRESS_MAIL_ACCOUNT, getRandomWord(), getRandomMessage(), "me" ], 
									mailTest_composeAndSendEmail,
									"Compose and send a random message.  Create email account if necessary." );
		}
		
		
		mailStress._deleteRandomMailMessage = function _deleteRandomMailMessage() {
			mailStress.executeTest( "DeleteRandomMailMessage", [ "RANDOM" ],
									mailTest_deleteEmail, "Delete a random email message." );
		}
		
		// can't do reply yet
		// can't to forward yet
		// can't do bulk delete let
		
		mailStress._searchMail = function _searchMail() {
			mailStress.executeTest( "Search", 
									[ STRESS_MAIL_ACCOUNT, STRESS_MAIL_ACCOUNT, "From", "shouldSearchServer:true" ],
									mailTest_search, "Search mail." );
		}
		
		
		mailStress._downloadLargeEmail = function _downloadLargeEmail() {
			mailStress.executeTest( "DownloadLargeEmail",
									[ "Stress Rack Large Email With HTML", STRESS_MAIL_ACCOUNT, "Subject", "shouldSearchServer:true" ],
									mailTest_search, "Download large email." )
		}
		
		mailStress._outputError = function _outputError() {
			UIALogger.logError("No mail acount or password found.");
			UIALogger.logError("To run mail tests, please create a plist with 2 keys; 'account' and 'password'.");
			UIALogger.logError("Name the plist 'com.apple.AppStressMailAccount.plist' and put the file in /var/root/Library/Preferences.");
		}
		

	}
}
