#!/usr/bin/perl
$success = 0;
system ("/sbin/reboot");
while (1)
{
}
for ($n = 0; ($n < 3) && !$success; $n++)
{
	system ("/bin/launchctl unload /System/Library/LaunchDaemons/com.apple.CommCenter.plist");
	#system ("/usr/local/bin/bbctl powercycle");	
	#system ("/usr/local/bin/bbctl reset");	
	#system ("/usr/local/bin/bbctl radio on");
	#system ("/usr/local/bin/bbctl usb on");	
	#system ("/usr/local/bin/bbusbctl on");
	#printf ("sleep ...\n");
	#system ("/bin/sleep 12");
	#printf ("sleep done\n");
	#Read the latest firmware name from the file
	open (CT, "cat /usr/standalone/firmware/Trek-Latest.txt |");
	while (<CT>)
	{
		s/[\r\n]//g;
		$filename = $_;
	}
	close (CT);
	open (PS, "/usr/local/bin/BBUpdaterSupreme uf -z /usr/standalone/firmware/Trek-personalized.zip -a -w |");
	open (FP, "> /var/logs/WiPASmini/WiPASmini.d.log");
	$oldh = select (FP);
	$| = 1;
	select ($oldh);
	$loadaborted = 0;
	while (<PS>)# && $loadaborted == 0)
	{
		$line = $_;
		printf ("#%s", $line);
		printf (FP "%s", $line);
		if ($line =~ /END\:\ Perform\ stage\ at\ second/)
		{
			$loadaborted = 1;
			last;
		}
	}
	close (PS);
	if (!$loadaborted)
	{
		close (FP);		
		next;
	}
	$success = 0;
	printf (FP "sleep 4...\n");
	system ("sleep 4");
	for ($m = 0; ($m < 20) && !$success; $m++)
	{
		open (PS, "/usr/local/bin/ETLTool ping|");
		while (<PS>)
		{
			$line = $_;
			printf ("#%s", $line);
			printf (FP "%s", $line);
			if ($line =~ /Software Version Strings/)
			{
				$success = 1;
				#system ("sleep 1");
			}
		}
		close (PS);
	}
	close (FP);
}