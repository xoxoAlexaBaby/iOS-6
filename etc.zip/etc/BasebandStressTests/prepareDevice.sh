#!/bin/sh

	
	/bin/rm -r /var/root/ipc_*Crashes*;
	/bin/rm -r /var/root/ipc_*Stats-*;
	/bin/rm -r /var/root/StressTest-*;
	/bin/rm -r /var/root/StressTests-*;
	/bin/rm -r /var/root/Library/Caches/locationd/location*;
	/bin/rm    /Library/Logs/CrashReporter/*.log
	/bin/rm    /Library/Logs/CrashReporter/*plist;
	/bin/rm -r /Library/Logs/CrashReporter/Baseband/;
	/bin/rm    /var/mobile/Library/Logs/CrashReporter/*plist;
	/bin/rm -r /var/mobile/Library/Logs/CrashReporter/Baseband/;
	/usr/local/bin/testCT -c "#*293#"
	
echo 'All done!'