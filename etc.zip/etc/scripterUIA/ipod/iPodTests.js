#import "./iPod.js"
#import "../libs/PHTesting.js"

//----------------------------------------------------------------------------------------
//	Fucntion: iPodTest_playMovieFromVideoList
//		Plays a video for a certain duration.
//
//	Parameters:	
// 		videoName (string) - name of the video to play.  Random video picked if not specified.
//		timeToPlay (int) - number of seconds to play the video for.  If this is set to -1, it
//			the video will start playing and the function will exit. (optional -- if not
//			specified, video is played for 5-15 seconds)
//		videoPath (string) - Multiple strings can be specified to indicate the path to the 
//			video. If no path is specified, the test tries to find it in 'Videos' table (optional)
//
//		e.g. "Trailer H" 10 "Videos" "The Simpsons Movie" 
//
//	Returns: 
//		1 if test passes, 0 if it fails
//----------------------------------------------------------------------------------------	
function iPodTest_playMovieFromVideoList() {
	var videoName = null;
	var timeToPlay = null;
	var videoPath = new Array();
	
	UIALogger.logMessage("Got # of argvs = " + this.argv.length);
	
	if ((this.argv.length > 0) && (this.argv[0] != null) && (this.argv[0] != "null") && (this.argv[0] != "")) { 
		videoName = this.argv[0];
		UIALogger.logMessage("Setting videoName to " + videoName);
	} 
	
	if (this.argv.length > 1 && this.argv[1] != "null" && this.argv[1] != null) {
		timeToPlay = parseInt(this.argv[1]);
		UIALogger.logMessage("Setting timeToPlay to " + timeToPlay);
	}
	
	for (var i=2; i<this.argv.length; i++) videoPath.push(this.argv[i]);
	
	video.launchIfNotActive(); 	
	this.testResult = 0;
	
	try {
		videoName = video.pickAndPlayVideo(videoName, videoPath);
	} catch(e) {
		UIALogger.logError(e.message);
		this.testError = "Could not pick and play video " + videoName;
		return this.testResult = 0;
	}
	
	if (!timeToPlay || timeToPlay == "null") {
		timeToPlay = system.randomReal(5, 15);
	}
	
	UIALogger.logMessage("Playing " + videoName + " for " + Math.round(timeToPlay) + " seconds.");
	
	UIATarget.localTarget().pushTimeout(10);
	var isVideoViewVisible = video.isInVideoView();
	UIATarget.localTarget().popTimeout();
	
	if (!isVideoViewVisible) {
		this.testError = "Clicked '" + videoName + "', but did not get to the video view";
		UIALogger.logError(this.testError);
		return this.testResult;
	}
	
	try {
		var timeArg = (timeToPlay < 0) ? null : timeToPlay;
		video.controlVideoPlaybackState(video.playbackActions.PLAY, timeArg);
	} catch(e) {
		UIALogger.logError(e.message);
		this.testError = "Could not play the video";
		this.testResult = 0;
	}
	
	// If timeToPlay was set to -1, we should start playing the video and then exit the script, so the video can play indefinitely.
	if (timeToPlay < 0) {
		UIALogger.logMessage("Started playing '" + videoName + "', and am letting it play while I exit");
		return this.testResult = 1;
	}
	
	
	try {
		video.getToMoviesView();
	} catch(e) {
		UIALogger.logError(e.message);
		this.testError = "Could not get back to movies view";
		return this.testResult = 0;
	}

	this.testResult = (this.testError) ? 0 : 1;
	
	return this.testResult;
	
}

//----------------------------------------------------------------------------------------
//	Function: iPodTest_playSongFromSongList
//		Plays a song for a certain duration.
//
//	Optional Parameters:	
// 		songName (string) - the name of the song that needs to be played. If no value is 
//			specified, a random song is played.
//		timeToPlay (int) - number of seconds to play the song for.  If this is set to -1, it
//			the song will start playing and the function will exit. (if not specified, song 
//			is played for 5-15 seconds)
//		songPath (string) - Multiple strings can be specified to indicate the path to the song.
//			If no path is specified, the test tries to find the song in the 'Songs' table.
//
//		e.g. "Yesterday" 10 "Artists" "All Albums" "All Songs"
//
//	Returns: 
//		1 if test passes, 0 if it fails
//----------------------------------------------------------------------------------------
function iPodTest_playSongFromSongList() {
	var songName = null;
	var timeToPlay = null;
	var songPath = new Array();
	
	UIALogger.logMessage("Got # of argvs = " + this.argv.length);
	
	if ((this.argv.length > 0) && (this.argv[0] != null) && (this.argv[0] != "null") && (this.argv[0] != "")) { 
		songName = this.argv[0];
		UIALogger.logMessage("Setting songName to " + songName);
	} 
	
	if (this.argv.length > 1 && this.argv[1] != "null" && this.argv[1] != null) {
		timeToPlay = parseInt(this.argv[1]);
		UIALogger.logMessage("Setting timeToPlay to " + timeToPlay);
	}
	
	for (var i=2; i<this.argv.length; i++) songPath.push(this.argv[i]);
	
	audio.launchIfNotActive();
	this.testResult = 0;
	
	try {
		songName = audio.pickAndPlaySong(songName, songPath);
	} catch(e) {
		UIALogger.logError(e.message);
		this.testError = "Could not pick and play song " + songName;
		UIALogger.logError(this.testError);
		return this.testResult;
	}

	
	if (timeToPlay == null || timeToPlay == "null") {
		timeToPlay = system.randomReal(5, 15);
	}
	
	UIALogger.logMessage("Playing " + songName + " for " + Math.round(timeToPlay) + " seconds.");
	
	// If timeToPlay was set to -1, we should start playing the video and then exit the script, so the video can play indefinitely.
	if (timeToPlay < 0) {
		UIALogger.logMessage("Started playing '" + songName + "', and am letting it play while I exit");
		return this.testResult = 1;
	}
	
	try {
		audio.verifyMusicIsPlaying(timeToPlay);
	} catch(e) {
		UIALogger.logError(e.message);
		this.testError = "Could not verify music is playing";
		return this.testResult = 0;
	}
	
	try {
		audio.pauseSong();
		audio.getToSongsView();
	} catch(e) {
		UIALogger.logError(e.message);
		this.testError = "Could not pause the song and get to songs view";
		return this.testResult = 0;
	}

	return this.testResult = 1;
}

//----------------------------------------------------------------------------------------
//	Function: iPodTest_flipThroughCoverFlow
//		Switches to cover flow mode, and flips through album artwork. Note that this test 
//		is not supported on iPad
//
//	Optional Parameters:	
// 		songName (string) - the name of the song to be played before switching to the 
//			coverflow mode. If no song is specified, the test navigates to the 'Songs' list
//			and then switches to the coverflow mode. 
//		action (string) - either "forward" or "back", depending on whether the test should 
//			flip forward or back. Multiple action values can be provided to specify the 
//			flips types.
//		For e.g. iPodTest_flipThroughCoverFlow "songName:Yesterday" "action:forward" 
//			"action:forward" "action:back", will select the song 'Yesterday', then switch 
//			to cover flow mode, then flip forward two times and then back once. 
//
//	Returns: 
//		1 if test passes, 0 if it fails
//----------------------------------------------------------------------------------------
function iPodTest_flipThroughCoverFlow() {
	
	if (UIATarget.localTarget().model() == 'iPad') {
		this.testError = "cover flow test not supported on iPad";
		return this.testResult = 0;
	}
	var songName = UIAUtility.valuesForKey("songName", this.argv, 1);
	var actions = UIAUtility.valuesForKey("action", this.argv, this.argv.length);
	
	var originalOrientation = UIATarget.localTarget().frontMostApp().interfaceOrientation();
	UIALogger.logDebug("The original orientation is " + originalOrientation);
	
	try {
		if (actions && actions.length > 0) {
			for (var i=0; i<actions.length; i++) {
				if (actions[i].toLowerCase() == "forward") actions[i] = audio.flipActions.FORWARD;
				else if (actions[i].toLowerCase() == "back") actions[i] = audio.flipActions.BACK;
				else {
					UIALogger.logError("Unknown action type: " + actions[i]);
					return 64;
				}
			}
		}
		audio.getToSongsView();
		
		if (songName) {
			UIALogger.logDebug("Need to select '" + songName + "' first");
			audio.pickAndPlaySong(songName);
			UIATarget.localTarget().delay(1);
			UIATarget.localTarget().setDeviceOrientation(UIA_DEVICE_ORIENTATION_LANDSCAPELEFT);
			
			if (!audio.mainWindow().buttons()["Track list"].isVisible()) {
				this.testError = "Could not switch to the coverflow mode";
				UIALogger.logError(this.testError);
				return this.testResult = 0;
			}
			
			if (!audio.mainWindow().elements().firstWithPredicate("name contains '" + songName + "'").isValid()) {
				this.testError = "Could not verify the correct album art was being displayed in the coverflow mode";
				UIALogger.logError(this.testError);
				return this.testResult = 0;
			}
		}
		
		audio.flipThroughCoverFlow(actions);
		
		//setting it back to the original orientation
		UIATarget.localTarget().setDeviceOrientation(originalOrientation);
	} catch(e) {
		//setting it back to the original orientation
		UIATarget.localTarget().setDeviceOrientation(originalOrientation);
		
		throw e;
	}
	
	return this.testResult = 1;
	
}

//----------------------------------------------------------------------------------------
//	Function: iPodTest_startPlaylist
//		Selects the specified playlist, and plays the first song in the playlist.
//
//	Parameters:	
// 		playlistName (string) - optional - the name of the playlist that has be to played.
//			If no value is specified, a playlist is selected at random.
//
//	Returns: 
//		1 if test passes, 0 if it fails
//----------------------------------------------------------------------------------------
function iPodTest_startPlaylist() {
	if (this.argv.length > 0) { 
		var playlistName = this.argv[0];
	} else {
		var playlistName = "";	
	}
	
	try {
		audio.getToSongsView();
	} catch(e) {
		UIALogger.logError(e.message);
		this.testError = "Could not get to Songs view";
		return this.testResult = 0;
	}
	
	if (!audio.areSongsOnDevice()) {
		this.testError = "No songs are present on device!";
		UIALogger.logError(this.testError);
		return this.testResult = 0;
	}
	
	try {
		audio.selectPlaylist(playlistName);
	} catch(e) {
		UIALogger.logError(e.message);
		this.testError = "Could not select the playlist";
		UIALogger.logError(this.testError);
		return this.testResult = 0;
	}
	UIATarget.localTarget().delay(1);
	
	var songElement = audio.getFirstSongInPlaylist();
	if (!songElement.isValid()) {
		this.testError = "Could not find a song in the chosen playlist";
		UIALogger.logError(this.testError);
		return this.testResult = 0;
	}
	
	UIALogger.logMessage("Playing " + songElement.name());
	songElement.scrollToVisible();
	songElement.tap();
	
	// currently songs play automatically.  
	UIATarget.localTarget().delay(.5); 
	return this.testResult = 1;
}

//----------------------------------------------------------------------------------------
//	Function: iPodTest_stopPlaylist
//		Pauses the current song that is playing.
//
//	Parameters:	
// 		None.
//
//	Returns: 
//		1 if test passes, 0 if it fails
//----------------------------------------------------------------------------------------
function iPodTest_stopPlaylist() {
	
	audio.launchIfNotActive();
	this.testResult = 0;
	
	if (!audio.areSongsOnDevice()) {
		this.testError = "No songs are present on device!";
		UIALogger.logError(this.testError);
		return this.testResult = 0;
	}
	
	try {
		var songName = audio.getSongName();
	} catch(e) {
		UIALogger.logError(e.message);
		this.testError = "Could not get the song name of the current song.";
		return this.testResult = 0;
	}

	UIALogger.logMessage("Stopping playback of " + songName);
	
	try {
		audio.pauseSong();
	} catch(e) {
		UIALogger.logError(e.message);
		this.testError = "Could not stop playback of song: " + songName;
		return this.testResult = 0;
	}
	
	return this.testResult = 1;	
}

//----------------------------------------------------------------------------------------
//	Function: iPodTest_isExpectedSongPlaying
//		Takes the expected song as input and checks to see if it is the one currently being played.
//
//	Parameters: 
//		expectedSong (string) - song we expect to be playing
// 
//	Returns:
//		1 if test passes, 0 or 64 if test fails.
//----------------------------------------------------------------------------------------
function iPodTest_isExpectedSongPlaying() {
	if (this.argv.length < 1) {
		this.testError = "Must enter an expected song title";
		return this.testResult=0;
	}
	
	var expectedSong = this.argv[0];
	audio.launchIfNotActive();
	
	try {
		var theSong = audio.getSongName();
	} catch(e) {
		UIALogger.logError(e.message);
		this.testError = "Could not get the song name of the current song.";
		return this.testResult = 0;
	}
	
	if (theSong != expectedSong) {
		this.testError = "Expected to be playing '" + expectedSong + "', but got '" + theSong + "'";
		return this.testResult = 0;
	}
	else {
		UIALogger.logMessage("We are playing '" + theSong + "', as expected.");
		return this.testResult = 1;
	}
}

//----------------------------------------------------------------------------------------
//	Function: iPodTest_createPlaylist 
//		Creates a new playlist
//
//	Parameters:	
// 		playlistName (string) - the name of the playlist to be created.
//		song (string) - optional - the name of the song to be added to the playlist. You
//			can also specify the path to the song using a ':' delimited string
//				e.g. 'Artists:The Beatles:All Songs:Yesterday'
//		Multiple songs can be specified.
//			e.g. iPodTest_createPlaylist 'Test 1' 'Delerium' 'Artists:The Beatles:All Songs:Yesterday'
//			will create a new playlist, Test 1, and add two songs - Delerium and Yesterday.
//		If no songs are specified, random songs are added to the playlist.
//
//	Returns: 
//		1 if test passes, 0 if it fails
//----------------------------------------------------------------------------------------
function iPodTest_createPlaylist() {
	if (this.argv.length < 1) {
		UIALogger.logError("Not enough args being passed.");
		return 64;	
	}
	var playlistName = this.argv[0];
	var songs = new Array();
	
	if (this.argv.length > 1) {
		for (var i=1; i<this.argv.length; i++) {
			if (this.argv[i].indexOf(':') < 0)
				songs.push(this.argv[i]); //this is just the song name
			else {
				//song path
				songs.push(this.argv[i].split(':'));
			}
		}
	} else {
		UIALogger.logError("No songs specified. Will add random songs");
		songs = null;
	}
	
	UIALogger.logDebug("Creating a playlist with name '" + playlistName + "'");	
	audio.getToSongsView();
	audio.createPlaylist(playlistName, songs, true);
	
	return this.testResult = 1;
}

//----------------------------------------------------------------------------------------
//	Function: iPodTest_editPlaylist
//		Edits a playlist
//
//	Parameters:	
// 		playlistName (string) - the name of the playlist to be edited.
//		song (string) - optional - the name of the song to be added/removed. If a song
//			needs to be added, prefix the song name with 'add:'. Similarly, if it needs
//			to be deleted, prefix the name with 'delete:'
//		Multiple songs can be specified.
//			e.g. iPodTest_editPlaylist 'Test 1' 'delete:Delerium' 'add:Yesterday'
//			will delete 'Delerium' from the playlist, and add 'Yesterday' to it.
//		If no songs are specified, random songs are deleted/added to the playlist.
//
//	Returns: 
//		1 if test passes, 0 if it fails
//----------------------------------------------------------------------------------------
function iPodTest_editPlaylist() {
	if (this.argv.length < 1) {
		UIALogger.logError("Not enough args being passed.");
		return 64;	
	}
	var playlistName = this.argv[0];
	var songsToAdd = new Array();
	var songsToDelete = new Array();
	
	if (this.argv.length > 1) {
		for (var i=1; i<this.argv.length; i++) {
			if (this.argv[i].indexOf(':') < 0) {
				UIALogger.logError("Incorrectly formatted argument.");
				return 64;
			} else {
				var songInfo = this.argv[i].split(':');
				if (songInfo[0].toLowerCase() == "add") {
					UIALogger.logDebug("Adding '" + songInfo[1] + "' to the songs add list");
					songsToAdd.push(songInfo[1]);
				} else if (songInfo[0].toLowerCase() == "delete") {
					UIALogger.logDebug("Adding '" + songInfo[1] + "' to the songs delete list");
					songsToDelete.push(songInfo[1]);
				} else {
					UIALogger.logError("Incorrectly formatted argument header: " + songInfo[0]);
					return 64;
				}
			}
		}
	} else {
		UIALogger.logDebug("No songs specified. Choosing random songs");
		songsToAdd = null;
		songsToDelete = null; //there might be no songs to delete
	}
	
	audio.getToSongsView();
	
	UIALogger.logDebug("Selecting '" + playlistName + "'");
	audio.selectPlaylist(playlistName);
	UIATarget.localTarget().delay(1); //one second for animations
    
	if (UIATarget.localTarget().model() == 'iPad') {
		audio.topBarElementWithName("Edit").tap();
		
		var doneButton = audio.topBarElementWithName("Done");
	} else {
		var playlistTable = audio.mainWindow().tableViews()[0];
		audio.cellsContainingElementsWithPredicate(playlistTable, "name contains 'Edit'")[0].buttons()["Edit"].tap();
		
		var doneButton = playlistTable.cells()["Done"];
	}
	if (!doneButton.isValid()) {
		this.testError = "Tapped 'Edit' but the 'Done' button did not show up";
		return this.testResult = 0;
	}
	
	UIALogger.logDebug("Deleting songs first");	
	var numOfSongs = audio.numOfSongsInPlaylist();
	
	UIALogger.logDebug("No. of songs in playlist: " + numOfSongs)
	if (songsToDelete == null && numOfSongs == 0) {
		UIALogger.logDebug("No songs to delete.");
	} else {
		UIALogger.logDebug("Deleting songs...");
		var deletedSongs = audio.deleteSongsInPlaylist(songsToDelete);
		
		UIALogger.logDebug("Verifying that the songs were deleted");
		var currentNoOfSongs = audio.numOfSongsInPlaylist();
		
		UIALogger.logDebug("No. of songs that were deleted = " + deletedSongs.length);
		UIALogger.logDebug("No. of songs remaining = " + currentNoOfSongs);
		
		if (currentNoOfSongs != numOfSongs-deletedSongs.length) {
			UIALogger.logError("Expected number of songs = " + (numOfSongs-deletedSongs.length));
			UIALogger.logError("Actual number of songs = " + currentNoOfSongs);
			this.testError = "Unexpected number of songs after deleting";
			return this.testResult = 0;
		}
	}
	
	UIALogger.logDebug("Adding songs to the playlist");
	var addSongsButtonName = (UIATarget.localTarget().model() == 'iPad') ? "Add Songs" : "Add";
	audio.topBarElementWithName(addSongsButtonName).tap();
	
	var addedSongs = audio.addSongsToPlaylist(songsToAdd);
	
	audio.topBarElementWithName("Done").tap();
	
	if (UIATarget.localTarget().model() == 'iPad') {
		doneButton = audio.topBarElementWithName("Done");
	} else {
		playlistTable = audio.mainWindow().tableViews()[0];
		doneButton = playlistTable.cells()["Done"];	
	}
	if (!doneButton.withPredicate("isVisible != 1")) {
		this.testError = "Tapped the 'Done' button on the add songs view, but did not go back to the playlist view";
		return this.testResult = 0;
	}
	
	UIALogger.logDebug("Verifying the songs were added");
	var playlistTable = audio.songsTable();
	for (var i=0; i<addedSongs.length; i++) {
		UIALogger.logDebug("Verifying the " + (i+1) + "th song '" + addedSongs[i] + "' was added");
		var songElement = playlistTable.cells().firstWithPredicate("name matches '.*" + UIAUtility.escapeString(addedSongs[i]) + ".*'");
		if (!songElement.isValid()) {
			UIALogger.logError("Did not find '" + addedSongs[i] + "' in the playlist");
			this.testError = "Could not verify that the songs were added";
			return this.testResult = 0;
		}
	}
	
	UIATarget.localTarget().delay(1);
	doneButton.scrollToVisible();
	doneButton.tap();
	
	return this.testResult = 1;
}

//----------------------------------------------------------------------------------------
//	Function: iPodTest_clearPlaylist 
//		Clears the specified playlist. N/A for Wildcat
//
//	Parameters:	
// 		playlistName (string) - the name of the playlist to be cleared.
//
//	Returns: 
//		1 if test passes, 0 if it fails
//----------------------------------------------------------------------------------------
function iPodTest_clearPlaylist() {
	if (this.argv.length < 1) {
		UIALogger.logError("Not enough args being passed.");
		return 64;	
	}
	var playlistName = this.argv[0];
	
	UIALogger.logDebug("Clearing a playlist with name '" + playlistName + "'");	
	audio.getToSongsView();
	audio.clearPlaylist(playlistName);
	
	return this.testResult = 1;
}

//----------------------------------------------------------------------------------------
//	Function: iPodTest_deletePlaylist
//		Deletes the specified playlist.
//
//	Parameters:	
// 		playlistName (string) - the name of the playlist to be deleted.
//
//	Returns: 
//		1 if test passes, 0 if it fails
//----------------------------------------------------------------------------------------
function iPodTest_deletePlaylist() {
	if (this.argv.length < 1) {
		UIALogger.logError("Not enough args being passed.");
		return 64;	
	}
	var playlistName = this.argv[0];
	
	UIALogger.logDebug("Deleting a playlist with name '" + playlistName + "'");
	audio.getToSongsView();
	audio.deletePlaylist(playlistName);
	
	return this.testResult = 1;
}

//----------------------------------------------------------------------------------------
//	Function: iPodTest_playPauseSong 
//		Plays/Pauses the song in the order specified
//
//	Parameters:	
// 		songName (string) - optional - the name of the song that needs to be played. If a 
//			null value is specified, the song that is already playing is used. If no song is 
//			playing, then a random song is played.
//		actions (string) - either "Pause" or "Play", depending on the desired action. Can also 
//			specify the time (in seconds) for which the desired action needs to be performed 
//			<action>:<time>. If no time is specified, the action is performed for a random 
//			amount of time. Can specify multiple actions.
//
//		e.g. iPodTest_playPauseSong Yesterday Play:10 Pause:5 Play:10 will pick the song 
//			Yesterday, play it for 10 seconds, then pause it for 5 seconds, and then play 
//			it again for 10 seconds
//
//
//	Returns: 
//		1 if test passes, 0 if it fails
//----------------------------------------------------------------------------------------
function iPodTest_playPauseSong() {
	
	audio.launchIfNotActive();
	
	var songName;
	var actions = new Array();
	
	if (this.argv.length > 0 && this.argv[0] != null && this.argv[0] != "null")
		songName = this.argv[0];
	
	if (this.argv.length < 2) {
		UIALogger.logError("No action specified.");
		return 64;
	} 
	
	for (var i=1; i<this.argv.length; i++) {
		var actionArray = this.argv[i].split(':');
		
		var actionName;
		if (actionArray[0].toLowerCase() == "play") actionName = audio.playbackActions.PLAY;
		else if (actionArray[0].toLowerCase() == "pause") actionName = audio.playbackActions.PAUSE;
		else {
			UIALogger.logError("Unexpected action type:" + actionArray[0]);
			return 64;
		}
		var actionTime = (actionArray.length > 1) ? parseInt(actionArray[1]) : system.randomInteger(2,6);
		UIALogger.logMessage("Pushing action with name=" + actionName + " time=" + actionTime);
		actions.push({name:actionName, time:actionTime});
	}
	
	if (songName) {
		UIALogger.logMessage("Need to play " + songName);
		try {
			audio.pickAndPlaySong(songName);
		} catch(e) {
			UIALogger.logError(e.message);
			this.testError = "Could not pick and play " + songName;
			UIALogger.logError(this.testError);
			return this.testResult = 0;
		}
	} else {
		UIALogger.logMessage("No song specified. Checking if there is a song playing");
		try {
			var currentSongName = audio.getSongName();
			UIALogger.logMessage("Using the 'Now Playing' song " + currentSongName);
		} catch(e) {
			UIALogger.logError(e.message);
			UIALogger.logMessage("No song is playing. Will play a random song now");
			try {
				audio.pickAndPlaySong(); //
			} catch(e) {
				UIALogger.logError(e.message);
				this.testError = "Pick and play random song failed";
				return this.testResult = 0;
			}	
		}
	}
	
	for (var i=0; i<actions.length; i++) {
		UIALogger.logMessage("Performing " + (i+1) + "th action. Going to '" + actions[i].name + "' the song for " + actions[i].time + " seconds.");
		try {
			audio.controlSongPlaybackState(actions[i].name, actions[i].time);
			UIALogger.logMessage("Done with " + (i+1) + "th action");
			
			//need to account for when it exits pre-maturely
			try {
				audio.getSongName(); 
			} catch(e) {
				UIALogger.logError(e.message);
				UIALogger.logMessage("The song seems to have exited pre-maturely");
				return this.testResult = 1;
			}
		} catch(e) {
			this.testError = e.message;
			UIALogger.logError(this.testError);
			return this.testResult = 0;
		}
	}
	
	return this.testResult = 1;
}

//----------------------------------------------------------------------------------------
//	Function: iPodTest_playPauseVideo 
//		Plays/Pauses the video in the order specified.This test does not work on Wildcat. 
//
//	Parameters:	
// 		videoName (string) - optional - the name of the video that needs to be played. If a 
//			null value is specified, the video that is already playing is used. If no video is 
//			playing, then a random video is played.
//		actions (string) - either Pause or Play, depending on the desired action. Can also 
//			specify the time (in seconds) for which the desired action needs to be performed 
//			<action>:<time>. If no time is specified, the action is performed for a random 
//			amount of time. Can specify multiple actions.
//
//		e.g. iPodTest_playPauseVideo Yesterday Play:10 Pause:5 Play:10 will pick the video 
//			Yesterday, play it for 10 seconds, then pause it for 5 seconds, and then play 
//			it again for 10 seconds
//
//
//	Returns: 
//		1 if test passes, 0 if it fails
//----------------------------------------------------------------------------------------
function iPodTest_playPauseVideo() {
	
	video.launchIfNotActive();
	
	var videoName;
	var actions = new Array();
	
	if (this.argv.length > 0 && this.argv[0] != null && this.argv[0] != "null")
		videoName = this.argv[0];
	
	if (this.argv.length < 2) {
		UIALogger.logError("No action specified.");
		return 64;
	} 
	
	for (var i=1; i<this.argv.length; i++) {
		var actionArray = this.argv[i].split(':');
		var actionName;
		if (actionArray[0].toLowerCase() == "play") actionName = video.playbackActions.PLAY;
		else if (actionArray[0].toLowerCase() == "pause") actionName = video.playbackActions.PAUSE;
		else {
			UIALogger.logError("Unexpected action type:" + actionArray[0]);
			return 64;
		}
		
		var actionTime = (actionArray.length > 1) ? parseInt(actionArray[1]) : system.randomInteger(2,6);
		UIALogger.logMessage("Pushing action with name=" + actionName + " time=" + actionTime);
		actions.push({name:actionName, time:actionTime});
	}
	
	if (videoName) {
		UIALogger.logMessage("Need to play " + videoName);
		try {
			video.pickAndPlayVideo(videoName);
		} catch(e) {
			UIALogger.logError(e.message);
			this.testError = "Could not pick and play " + videoName;
			return this.testResult = 0;
		}
	} else {
		UIALogger.logMessage("No video specified. Checking if there is a video playing");
		if (!video.isInVideoView()) {
			UIALogger.logMessage("No video is playing. Will play a random video now");
			try {
				video.pickAndPlayVideo();
			} catch(e) {
				UIALogger.logError(e.message);
				this.testError = "Pick and play random video failed";
				UIALogger.logError(this.testError);
				return this.testResult = 0;
			}
		} else {
			UIALogger.logMessage("Using the video that is currently playing");
		}
	}
	
	for (var i=0; i<actions.length; i++) {
		UIALogger.logMessage("Performing " + (i+1) + "th action. Going to '" + actions[i].name + "' the video for " + actions[i].time + " seconds.");
		try {
			video.controlVideoPlaybackState(actions[i].name, actions[i].time);
			//need to account for when it exits pre-maturely
			if (!video.isInVideoView()) {
				UIALogger.logMessage("The video seems to have exited pre-maturely");
				return this.testResult = 1;
			}
		} catch(e) {
			this.testError = e.message;
			UIALogger.logMessage(this.testError);
			return this.testResult = 0;
		}
	}
	
	return this.testResult = 1;
}

//----------------------------------------------------------------------------------------
//	Function: iPodTest_scrubSong
//		Scrubs the progress slider of a song. 
//
//	Optional Parameters:	
// 		songName (string) - the name of the song that needs to be played. If a null value is 
//			specified, the song that is already playing is used. If no song is playing, then 
//			a random song is played.
//		desiredLevel (float) - value between 0.0 to 1.0 representing the progress to which 
//			the slider should be dragged to (1.0 represents all the way to the left and 0.0 
//			represents all the way to the right). If no value is provided, a random value 
//			between 0 and 1 is selected. 
//
//	Returns: 
//		1 if test passes, 0 if it fails
//----------------------------------------------------------------------------------------
function iPodTest_scrubSong() {
	
	audio.launchIfNotActive();
	
	var songName;
	var desiredLevel;
	
	if (this.argv.length > 0 && this.argv[0] != null && this.argv[0] != "null")
		songName = this.argv[0];
	
	if (this.argv.length > 1 && this.argv[1] != null && this.argv[1] != "null")
		desiredLevel = parseFloat(this.argv[1]);
	
	if (songName) {
		UIALogger.logDebug("Need to play " + songName);
		audio.pickAndPlaySong(songName);
	} else {
		UIALogger.logDebug("No song specified. Checking if there is a song playing");
		try {
			var currentSongName = audio.getSongName();
			UIALogger.logDebug("Using the 'Now Playing' song " + currentSongName);
		} catch(e) {
			UIALogger.logError(e.message);
			UIALogger.logDebug("No song is playing. Will play a random song now");
			currentSongName = audio.pickAndPlaySong();
		}
	}
	
	//pause the song for better verification
	try {
		audio.pauseSong();
	} catch(e) {
		UIALogger.logError(e.message);
		UIALogger.logDebug("Could not pause song -- possibly because it was already paused");
	}
	
	if (!desiredLevel) desiredLevel = system.randomReal(0.0,0.9);
	
	try {
		audio.scrubSong(desiredLevel);
	} catch(e) {
		this.testError = e.message;
		UIALogger.logDebug(this.testError);
		return this.testResult = 0;
	}
	
	return this.testResult = 1;
}

//----------------------------------------------------------------------------------------
//	Function: iPodTest_scrubVideo 
//		Scrubs the progress slider of a video. This test does not work on Wildcat. 
//
//	Optional Parameters:	
// 		videoName (string) - the name of the video that needs to be played. If a null value is 
//			specified, the video that is already playing is used. If no video is playing, then 
//			a random video is played.
//		desiredLevel (float) - value between 0.0 to 1.0 representing the progress to which 
//			the slider should be dragged to (1.0 represents all the way to the left and 0.0 
//			represents all the way to the right). If no value is provided, a random value 
//			between 0 and 1 is selected. 
//
//	Returns: 
//		1 if test passes, 0 if it fails
//----------------------------------------------------------------------------------------
function iPodTest_scrubVideo() {
	
	video.launchIfNotActive();
	
	var videoName;
	var desiredLevel;
	
	if (this.argv.length > 0 && this.argv[0] != null && this.argv[0] != "null")
		videoName = this.argv[0];
	
	if (this.argv.length > 1 && this.argv[1] != null && this.argv[1] != "null")
		desiredLevel = parseFloat(this.argv[1]);
	
	if (videoName) {
		UIALogger.logDebug("Need to play " + videoName);
		video.pickAndPlayVideo(videoName);
	} else {
		UIALogger.logDebug("No video specified. Checking if there is a video playing");
		if (!video.isInVideoView()) {
			UIALogger.logDebug("No video is playing. Will play a random video now");
			var currentVideoName = video.pickAndPlayVideo();
		} else {
			UIALogger.logDebug("Using the video that is currently playing");
		}
	}
	
	if (desiredLevel == null) desiredLevel = system.randomReal(0.0,0.9);
	UIALogger.logDebug("Scrubbing to " + desiredLevel);

	try {
		video.scrubVideo(desiredLevel, {pauseBeforeScrubbing:true});
	} catch(e) {
		this.testError = e.message;
		UIALogger.logError(this.testError);
		return this.testResult = 0;
	}
	
	return this.testResult = 1;
}

//----------------------------------------------------------------------------------------
//	Function: iPodTest_selectPreviousNextSong
//		Navigates to the next/previous song. 
//
//	Parameters:	
// 		songName (string) - optional - the name of the song that needs to be played. If a 
//			null value is specified, the song that is already playing is used. If no song is 
//			playing, then a random song is played.
//		actions (string) - either "previous" or "next", depending on the desired action. Can 
//			specify multiple actions. 
//
//		e.g. iPodTest_selectPreviousNextSong Next Previous Next will tap 'Next', then 
//			'Previous', and then again 'Next'
//
//
//	Returns: 
//		1 if test passes, 0 if it fails
//----------------------------------------------------------------------------------------
function iPodTest_selectPreviousNextSong() {
	
	audio.launchIfNotActive();
	
	var actions = new Array();
	var songNames = new Array();
	var songName;
	
	if (this.argv.length > 0 && this.argv[0] != null && this.argv[0] != "null")
		songName = this.argv[0];
	
	if (this.argv.length < 2) {
		UIALogger.logMessage("No action specified.");
		return 64;
	} 
	
	for (var i=1; i<this.argv.length; i++) {
		UIALogger.logMessage("Pushing action " + this.argv[i]);
		if (this.argv[i].toLowerCase() == "previous") 
			actions.push(audio.playbackActions.PREVIOUS);
		else if (this.argv[i].toLowerCase() == "next") 
			actions.push(audio.playbackActions.NEXT);
		else {
			UIALogger.logError("Unexpected action type:" + this.argv[i]);
			return 64;
		}
	}
	
	if (songName) {
		UIALogger.logMessage("Need to play " + songName);
		try {
			audio.pickAndPlaySong(songName);
		} catch(e) {
			UIALogger.logError(e.message);
			this.testError = "Could not pick and play " + songName;
			return this.testResult = 0;
		}
	} else {
		UIALogger.logMessage("No song specified. Checking if there is a song playing");
		try {
			var currentSongName = audio.getSongName();
			UIALogger.logMessage("Using the 'Now Playing' song " + currentSongName);
		} catch(e) {
			UIALogger.logError(e.message);
			UIALogger.logMessage("No song is playing. Will play a random song now");
			try {
				audio.pickAndPlaySong();
			} catch(e) {
				UIALogger.logError(e.message);
				this.testError = "Pick and play random song failed";
				return this.testResult = 0;
			}
		} 
	}
	
	UIALogger.logMessage("Should be playing a song now. Now, selecting Previous/Next.");
	try {
		audio.navigatePreviousNext(actions, true);
	} catch(e) {
		UIALogger.logError(e.message);
		this.testError = "Could not select previous/next controls";
		return this.testResult = 0;
	}
	
	return this.testResult = 1;
}


// Create self tests -- this is an unnamed function, just to make sure any local variables stay in the correct context
(function() {
	if (typeof audio.selfTests == 'undefined') {
		audio.selfTests = new Array();
	}
	if (typeof video.selfTests == 'undefined') {
		video.selfTests = new Array();
	}
	
	//	Audio Tests
	audio.selfTests.push(phtCreateTest("PlayRandomSong", [null, 10], iPodTest_playSongFromSongList, "Play Random Song for 10 Seconds"));
	audio.selfTests.push(phtCreateTest("StartPlaylist", ["dailyQL content"], iPodTest_startPlaylist, "Start Playback on a Playlist"));
	audio.selfTests.push(phtCreateTest("IsExpectedSongPlaying", ["Atom Bomb (Atomix 1)"], iPodTest_isExpectedSongPlaying, "Check if Expected Song is Playing"));
	audio.selfTests.push(phtCreateTest("StopPlaylist", null, iPodTest_stopPlaylist, "End Playback on a Playlist"));	
	if (UIATarget.localTarget().model() != 'iPad') {
		audio.selfTests.push(phtCreateTest("UseCoverFlow", ["songName:Yesterday", "action:Back", "action:Back", "action:Forward"], iPodTest_flipThroughCoverFlow, "Use cover flow"));
		audio.selfTests.push(phtCreateTest("UseRandomCoverFlow", [], iPodTest_flipThroughCoverFlow, "Use random cover flow"));
	}
	audio.selfTests.push(phtCreateTest("CreatePlaylist", ["Self-test playlist", "Yesterday"], iPodTest_createPlaylist, "Create a playlist"));
	audio.selfTests.push(phtCreateTest("EditPlaylist", ["Self-test playlist", "delete:Yesterday", "add:Delerium DRM"], iPodTest_editPlaylist, "Edits a playlist"));
	if (UIATarget.localTarget().model() != 'iPad') {
		audio.selfTests.push(phtCreateTest("ClearPlaylist", ["Self-test playlist"], iPodTest_clearPlaylist, "Clears a playlist"));
	}
	audio.selfTests.push(phtCreateTest("DeletePlaylist", ["Self-test playlist"], iPodTest_deletePlaylist, "Deletes a playlist"));
	audio.selfTests.push(phtCreateTest("PlayPauseSong", [null,"Play:5","Pause:5"], iPodTest_playPauseSong, "Plays and then pause a song for 5 seconds"));
	audio.selfTests.push(phtCreateTest("ScrubSong", [null,0.3], iPodTest_scrubSong, "Scrubs the progress slider of a song"));
	audio.selfTests.push(phtCreateTest("SelectPreviousNextSong", [null,"next","previous","next"], iPodTest_selectPreviousNextSong, "Selects the previous and next controls"));
	
	// Video Tests
	video.selfTests.push(phtCreateTest("PlayRandomVideo", [null, 10], iPodTest_playMovieFromVideoList, "Play Random Video for 10 Seconds"));
	video.selfTests.push(phtCreateTest("PlayPauseVideo", [null,"Play:5","Pause:5"], iPodTest_playPauseVideo, "Plays and then pause a video for 5 seconds"));
	video.selfTests.push(phtCreateTest("ScrubVideo", [null,0.5], iPodTest_scrubVideo, "Scrubs the progress slider of a video"));
}())


/*
function pushVideoSelfTests() {
	SELF_TEST_ARRAY.push(phtCreateTest("PlayRandomVideo", [null, 10], iPodTest_playMovieFromVideoList, "Play Random Video for 10 Seconds"));
	SELF_TEST_ARRAY.push(phtCreateTest("PlayPauseVideo", [null,"Play:5","Pause:5"], iPodTest_playPauseVideo, "Plays and then pause a video for 5 seconds"));
	SELF_TEST_ARRAY.push(phtCreateTest("ScrubVideo", [null,0.5], iPodTest_scrubVideo, "Scrubs the progress slider of a video"));
}

video.addSelfTest = function addSelfTest() {
	pushVideoSelfTests();
}

audio.addSelfTest = function addSelfTest() {
	SELF_TEST_ARRAY.push(phtCreateTest("DeletePlaylist", ["Self-test playlist"], iPodTest_deletePlaylist, "Deletes a playlist"));
	
	if (audio == video) {
		UIALogger.logMessage("Audio is equal to video");
		pushVideoSelfTests();
	}
}

*/
	
