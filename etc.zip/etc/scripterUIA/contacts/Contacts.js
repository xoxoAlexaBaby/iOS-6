/*
 Class: UIApp (addressbook)
 Contacts object
 */

#import "../libs/SpringBoard.js"
#import "../phone/Phone.js"
#import "../libs/UIAAppContactsAdditions.js"

if (typeof telephony == 'undefined') telephony = new Telephony();

if (UIATarget.localTarget().model() == "iPod touch" || UIATarget.localTarget().model() == "iPad") {
	addressbook = UIAApp.application("Contacts", "com.apple.MobileAddressBook");
} else {
	addressbook = UIAApp.application("Phone", "com.apple.mobilephone");
};


if (typeof addressbook != 'undefined') {
	// this list needs to be updated when the defaults tones are.  we should be generating this list programatically
	var _contacts_ringtones = new Array("Marimba", "Alarm", "Ascending", "Bark", "Bell Tower", "Blues", "Boing", "Crickets",
										"Digital", "Doorbell", "Duck", "Harp", "Motorcycle", "Old Car Horn", "Old Phone", "Piano Riff", "Pinball", "Robot",
										"Sci-Fi", "Sonar", "Strum", "Timba", "Time Passing", "Trill", "Xylophone");
	
	addressbook.ringtones = function () {
		return _contacts_ringtones;
	}
	
	var _contacts_numberTypes = new Array("mobile", "home", "work", "main", "home fax", "work fax", "pager");
	addressbook.numberTypes = function () {
		return _contacts_numberTypes;
	}
	
	var _contacts_emailTypes = new Array("home", "work", "other");
	addressbook.emailTypes = function () {
		return _contacts_emailTypes;
	}
	
	addressbook.alertHandler = function alertHandler(alert) {
		//only needed for iPad devices
		UIATarget.localTarget().pushTimeout(0);
		//Delete Contact message
		if (alert.staticTexts().firstWithPredicate("name contains 'Delete Contact'").isValid()) {
			UIALogger.logMessage("Got the delete contact alert");
			alert.buttons()["Delete"].tap();
		}
		UIATarget.localTarget().popTimeout();
		
		if (!alert.waitForInvalid()) {
			throw new Error("Could not handle the alert");
		}
		
		return true;
	}
	
	//overwriting the function for iPad
	addressbook.controlButtonWithIdentifier = function controlButtonWithIdentifier(identifier) {
		if (UIATarget.localTarget().model() == 'iPad') {
			if (identifier instanceof UIAPredicateString) 
				return this.mainWindow().buttons().firstWithPredicate(identifier.predicateString + "' and isVisible == 1");
			else 
				return this.mainWindow().buttons().firstWithPredicate("name == '" + identifier + "' and isVisible == 1");
		}
		return this.__proto__.controlButtonWithIdentifier.apply(this, [identifier]);
	}
	
	//overwriting the function for iPad
	addressbook.topBarStaticTextWithName = function topBarStaticTextWithName(name) {
		if (UIATarget.localTarget().model() == 'iPad') {
			return this.mainWindow().staticTexts().firstWithPredicate("name == '" + name + "' and isVisible == 1");
		} 
		
		return this.__proto__.topBarStaticTextWithName.apply(this, [name]);
	}
	
	//overwriting the function for iPad
	addressbook.searchResultsTable = function searchResultsTable() {
		if (UIATarget.localTarget().model() == 'iPad') {
			UIATarget.localTarget().pushTimeout(0.01);
			var resultsTable = this.mainWindow().images().firstWithPredicate("ANY tableViews.isVisible == 1").tableViews()[0];
			UIATarget.localTarget().popTimeout();
			return resultsTable;
		} 
		
		return this.__proto__.searchResultsTable.apply(this);
	}
}