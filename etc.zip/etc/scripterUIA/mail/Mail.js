/*
 Class: UIApp (mail)
 Mail object
 */
#import "../libs/SpringBoard.js"
#import "../libs/UIAAppMailAdditions.js"
#import "../libs/UIAAppPrintingAdditions.js"
#import "../libs/UIAAppDataDetectionAdditions.js"

mail = UIAApp.application("Mail", "com.apple.mobilemail");

if (typeof mail != 'undefined') {
	//----------------------------------------------------------------------------------------
	//	mail.createEmailAccount --> use settings.createEmailAccount
	//----------------------------------------------------------------------------------------
	
	//----------------------------------------------------------------------------------------
	//	Function: isiPadAndPortrait
	//		This function returns true if the device is an iPad and the orientation is in Portrait
	//			(either right side up or upside down).  This indicates whether or not we use
	//			the popover for navigation.
	//
	//	Parameters: 
	//		None
	//
	//	Returns: 
	//		true if this is an ipad and it's in portrait mode.  False if not.
	//----------------------------------------------------------------------------------------
	mail.isiPadAndPortrait = function isiPadAndPortrait() {
		var theOrientation = UIATarget.localTarget().frontMostApp().interfaceOrientation();
		
		if ((UIATarget.localTarget().model() == "iPad") &&
			(theOrientation == UIA_DEVICE_ORIENTATION_PORTRAIT) || (theOrientation == UIA_DEVICE_ORIENTATION_PORTRAIT_UPSIDEDOWN)) {
				return true;
		}
		else {
			return false;
		}
	}
		
	//----------------------------------------------------------------------------------------
	//	Function: chooseRandomEmail 
	//		Chooses a random email UIElement from the current mailbox and returns it.
	//		Assumes that we're looking at the list of emails.
	//
	//	Parameters: 
	//		None
	//
	//	Returns: 
	//		Throws an error if it is not successful
	//----------------------------------------------------------------------------------------
	mail.chooseRandomEmail = function chooseRandomEmail() {
		var mailTitles = this.mainWindow().tableViews()[0].cells();
		if (!mailTitles || (mailTitles.length <= 0)) {
			throw new Error ("Could not choose a random email.");
		}
		var theMail = UIAUtility.randomFromArray(mailTitles);
		UIALogger.logMessage("Random email chosen is '" + theMail.name() + "'");
		return theMail;
	}
	
	//----------------------------------------------------------------------------------------
	//	Function: isInEmailView
	//		Returns true if we're currently viewing an email, false if not.
	//
	//	Parameters: 
	//		None
	//
	//	Returns: 
	//		Throws an error if it is not successful
	//----------------------------------------------------------------------------------------
	mail.isInEmailView = function isInEmailView() {
		return this.mainWindow().toolbars()[0].buttons()["Move"].isValid();
	}

	//----------------------------------------------------------------------------------------
	//	Function: getToMailboxesPage 
	//		Goes to the "first" mail page--it lists all the accounts, if
	// 		if there are multiple accounts, or it shows the folders inside the account, if
	//		there is only one.
	//
	//	Parameters: 
	//		None
	//
	//	Returns: 
	//		Throws an error if it is not successful
	//----------------------------------------------------------------------------------------
	mail.getToMailboxesPage = function getToMailboxesPage(account) {
		this.launchIfNotActive(); 
		
		UIATarget.localTarget().delay(1);  // <rdar://problem/9845771> Tapping a navbar button right after launching an app doesn't work -- animation not complete
		UIATarget.localTarget().pushTimeout(1);
		
		// check to make sure the device has an account on it
		var navBar = this.navigationBar();
		if (navBar.isValid() && (navBar.name() == "Welcome to Mail")) {
			throw new Error("No mail account configured.")
		}
		
		// If a popover is up, dismiss it.  There are several different popovers in mail.
		if (UIATarget.localTarget().model() == "iPad") {
			var thePopover = this.mainWindow().popover();
			if (this.mainWindow().popover().isValid()) {
				UIALogger.logMessage("Dismissing popover");
				try {
					thePopover.dismiss();
					UIATarget.localTarget().delay(1);
				}
				catch (e) {
					UIALogger.logError("Caught Error: " + e.message);
					UIALogger.logMessage("Could not dismiss the popover");
				}
			}
		}

		// Tap the left navigation a couple of times, if it exists.  This gets us out of viewing an email and/or attachment
		// Doing this first, because it may bring up the "Cancel" button that shows up in the search page or the "Cancel" button
		// that shows up after an email has been composed
		var leftButton = this.mainWindow().navigationBar().leftButton();

					
		var theCount = 0;
		if (UIATarget.localTarget().model() == "iPad") {
			// tap the middle of the main window to try to bring up controls.  This will
			//  get us out from viewing an attachment
			this.mainWindow().tap();
			UIATarget.localTarget().delay(1);  // give the animation a bit of time to take place
			UIALogger.logMessage("Tapping middle of main window to try to bring up controls");
			leftButton = this.mainWindow().navigationBar().leftButton();  
			if (leftButton.isValid() && leftButton.isVisible()) {
				leftButton.tap();  // Tap the 'Done' button
			}
		}
		if (!leftButton.checkIsValid() || !leftButton.isVisible()) { // Since we may have done something above, we should make sure it's still valid.
			var leftButton = this.mainWindow().toolbars().firstWithPredicate("isVisible == 1").buttons()[0]; // button to bring up mailboxes on ipads
		}
		
		while (leftButton.isVisible() && theCount < 5) {
			UIALogger.logMessage("Tapping left nav bar button");
			leftButton.tap();
			UIATarget.localTarget().delay(1); // give a bit of time here for things to reset...
			leftButton = this.mainWindow().navigationBar().leftButton();
			theCount++
		}
		
		// If we're editing an email, we should have hit the 'Cancel' button already (from above).  Now it's time to hit the popover that might come up
		var deleteDraftButton = this.mainWindow().popover().actionSheet().buttons()['Delete Draft'];
		if (deleteDraftButton.isValid() && deleteDraftButton.isVisible()) {
			UIALogger.logMessage("Tapping 'Delete Draft' button.");
			deleteDraftButton.tap();
			
			// The button to get to the list of mailboxes on an ipad is in the toolbar
			if (UIATarget.localTarget().model() == "iPad")
				UIATarget.localTarget().delay(1);
				var toolbarButton = this.mainWindow().toolbars().firstWithPredicate("isVisible == 1").buttons()[0];
				if (toolbarButton.isValid()) {
					UIALogger.logDebug("Tapping first Toolbar button.")
					toolbarButton.tap();
					UIATarget.localTarget().delay(1);
				}
		}
		
		// Get out of 'move' area for iPad
		if (UIATarget.localTarget().model() == 'iPad') {
			var cancelButton = this.mainWindow().toolbars().firstWithPredicate("ANY buttons.name == 'Cancel'").buttons()["Cancel"]; // sometimes there are several toolbars up
			if (cancelButton.isValid() && cancelButton.isVisible()) {
				UIALogger.logMessage("Tapping 'Cancel' button in toolbar");
				cancelButton.tap(); 
				UIATarget.localTarget().delay(1);  // wait for animations to finish
			}
		}
	
		// There may already be a cancel button or the left button may bring up an alert sheet.  Tap cancel, if an alert sheet is there.
		var theActionSheet = this.actionSheet();
		if (theActionSheet.isValid()) {
			UIALogger.logMessage("Found an action sheet--trying to get rid of it");
			var deleteButton = theActionSheet.buttons().firstWithPredicate("name beginswith 'Delete'");
			var cancelButton = theActionSheet.buttons().firstWithPredicate("name beginswith 'Cancel'");
			var noButton = theActionSheet.buttons()["No"];
			if (deleteButton.isValid()) {
				deleteButton.tap();
				UIALogger.logMessage("Tapping the 'Delete' button in an action sheet.");
				UIATarget.localTarget().delay(1);
			}
			else if (cancelButton.isValid()) {
				cancelButton.tap();
				UIALogger.logMessage("Tapping the 'Cancel' button in an action sheet.");
				UIATarget.localTarget().delay(1);
				var leftButton = this.mainWindow().navigationBar().leftButton();
				if (leftButton.isValid) { 
					// This section is needed if there is a "Action" action sheet up with an email behind it (i.e. reply, forward, etc).  
					// Tap the left button once to see if we get back to a page with 'Cancel' (i.e. a search page)
					leftButton.tap(); 
					UIALogger.logMessage("Tapping left button.");
					UIATarget.localTarget().delay(1);
				}
			}
			else if (noButton.isValid()) {
				noButton.tap();
				UIALogger.logMessage("Tapping the 'No' button in an action sheet.");
				UIATarget.localTarget().delay(1);
			}
			else throw new Error("Action Sheet found but could not tap the 'Cancel' button!");
		}	
		
		// Tap 'Cancel' button that shows up in search page
		var cancelButton;
		if (UIATarget.localTarget().model() == "iPad") {
			cancelButton = this.mainWindow().buttons()["Cancel"];
		}
		else {
			cancelButton = this.mainWindow().tableViews()[0].elements()["Cancel"];
		}
		if (cancelButton.isValid() && cancelButton.isVisible()) {
			UIALogger.logMessage("Tapping 'Cancel' button to get rid of search bar");
			cancelButton.tap();
			UIATarget.localTarget().delay(1); // give a bit of time here for things to reset...
		}	
		
		// Tap the right nav bar button if it is named "Cancel"  (i.e. when in delete bulk)
		var navBarCancelButton = this.mainWindow().navigationBar().rightButton();		
		if (navBarCancelButton.name() == "Cancel") {
			UIALogger.logMessage("Tapping right nav bar button, because it is a 'Cancel' button")
			navBarCancelButton.tap();
		}
		
		UIATarget.localTarget().popTimeout();
		
		// Now that we've gotten through all the weird cases, we should just be able to hit the nav bar enough times to get back to the main page.
		this.returnToTopLevel();
	}
	
	//----------------------------------------------------------------------------------------
	//	Function: getToEmailFolder
	//		Goes to the page that contains the list of emails for the
	//		particular account and mailbox (i.e. weliketesting@gmail.com, Inbox)
	//
	//  Parameters:
	//		account (string) - The name of the account whose folder view page has to be 
	//							displayed. By default, this is the same as the email address
	//							of the account. If the provided argument is null, it will choose 
	//							the first thing in the list (usually 'All Inboxes', if there
	//							are several accounts or "Inbox" if there is only one) (optional)
	//
	//		folder (string) - The mailbox to use. (optional, if not specified will use Inbox).
	//						    Can't specify folder, if account is not specified
	//
	//  Returns: 
	//		None
	//
	//	Throws: 
	//		throws an error if something unexpected occurs.
	//----------------------------------------------------------------------------------------
	mail.getToEmailFolder = function getToEmailFolder(account, folder) {
		this.getToMailboxesPage();
		if ((typeof folder == 'undefined') || !folder) folder = "Inbox";  // If folder isn't specified, go to inbox
		
		UIALogger.logMessage("Getting to folder '" + folder +"' of account '" + account + "'");
		var theMailboxes = this.mainWindow().tableViews()[0].cells();
		var theOrientation = UIATarget.localTarget().frontMostApp().interfaceOrientation();
		
		if (account) {
			// Looking for "Inboxes" here instead of "All Inboxes," because of this bug:
			// <rdar://problem/7910931> "All Inboxes" element in mail sometimes shows up with wrong name when it is scrolled off-screen
			var multipleAccounts = this.mainWindow().tableViews()[0].scrollToElementWithName("Inboxes").isValid();
			if (multipleAccounts) {
				try {
					var theAccount = theMailboxes.withPredicate("name beginswith '" + account + "'")[1];
					// More than one email account is on the device and account is on the device.
					// Tap the second occurrance of the account, which gets us to the list of folders for the account, instead of going directly to the inbox.
					theAccount.scrollToVisible();
					UIALogger.logMessage("Tapping '" + theAccount.name() + "' to get to the email account");
					theAccount.tap();	
					UIATarget.localTarget().delay(1); 
				}
				catch(e) {
					// more than one email account is on the device and we couldn't find the account we're looking for.  fail the test.
					UIALogger.logMessage("Caught error: " + e.message);
					throw new Error("There are multiple email accounts and we can't find the account '" + account + "' in the list");
				}
			}
			else {
				// we only have one email account on the device -- if that is the case we should just assume we're looking at the right mailbox
				UIALogger.logMessage("Only one email account on device, assuming we have the right one");
			}
			
			UIALogger.logMessage("Tapping folder '" + folder + "'");
			try {
				this.mainWindow().tableViews()[0].scrollToElementWithPredicate("name beginswith '" + folder + "'").tap();
			}
			catch(e) {
				UIALogger.logMessage("Caught error: " + e.message);
				throw new Error("Could not tap the mail folder '" + folder + "'");
			}
		}
		else {
			// no folder specified, we're going to assume that we'll use the inbox
			if (folder.toLowerCase() == "inbox") {  
				// tap the first cell, probably "All Inboxes", but could be the first (or only) inbox
				var firstCell = theMailboxes[0];
				UIALogger.logMessage("Account not specified and folder was either set to null or 'inbox', clicking the first cell '" + firstCell.name() + "'");
				try {
					firstCell.scrollToVisible();
					firstCell.tap();
				}
				catch(e) {
					UIALogger.logMessage("Caught error: " + e.message);
					throw new Error("Could not tap the inbox folder");
				}
			}
			else {
				UIALogger.logMessage("Tapping folder '" + folder + "'");
				try {
						this.mainWindow().tableViews()[0].scrollToElementWithPredicate("name beginswith '" + folder + "'").tap();
				}
				catch(e) {
					UIALogger.logMessage("Caught error: " + e.message);
					throw new Error("Could not tap the proper folder: '" + folder + "'");
				}
			}
		}
		
		// Wait for 'Checking for Mail' status to go away.
		var checkForMail = this.mainWindow().toolbar().elements()["Checking for Mail..."];
		if (checkForMail.isValid()) {
			UIATarget.localTarget().pushTimeout(10);  // TODO change this to 60 or 120 once <rdar://problem/7741620> is fixed
			UIALogger.logMessage("Waiting for 'Checking for Mail' to go away--this is another bad one");
			if (!checkForMail.waitForInvalid()) UIALogger.logWarning("'Checking for Mail' did not go away");
			UIATarget.localTarget().popTimeout();
		}
		
		// TODO -- check that we're actually in an inbox...
		
	}
	//----------------------------------------------------------------------------------------
	//	mail.composeEmail - use UIAApp.composeEmail
	//----------------------------------------------------------------------------------------

	//----------------------------------------------------------------------------------------
	//	mail.typeEmailRecipients - use UIAApp.typeEmailRecipients.
	//----------------------------------------------------------------------------------------
	
	//----------------------------------------------------------------------------------------
	//	Function: getSubjectElement 
	//		Returns the subject element with the predicate specified				
	//
	//	Requires:
	//		Currently in the correct mailbox and folder (i.e. inbox, trash, whatever)
	//
	//	Parameters:
	//		predicate (string) - The predicate of the item to return.
	//
	//	Returns: 
	//		the item if it can be found or UIAElementNil if it cannot be found.
	//----------------------------------------------------------------------------------------
	mail.getSubjectElement = function getSubjectElement(predicate) {
		return this.mainWindow().tableViews()[0].elements().firstWithPredicate(predicate);
	}

	//----------------------------------------------------------------------------------------
	//	Function: verifyEmailExists 
	//		Checks if an email with the specified subject exists in
	//		the specified folder of an account.  Note that the subject search is a
	//		.*subject.* search in the title of the mail.
	//						
	//
	//	Requires:
	//		The folder and account exist on the phone
	//
	//	Parameters:
	//		(string) subject = The subject title to look for
	//		(string) account = The name of the account in which to search
	//		(string) folder = The folder of the account in which to search (optional, if not
	//			set, 'Inbox' is used)
	//		(int) timeout = The number of seconds to wait for the email to arrive (optional, 
	//			if not set, 60 is used
	//
	//	Returns: 
	//		True if the emails with the specified subjects exist
	//----------------------------------------------------------------------------------------
	mail.verifyEmailExists = function verifyEmailExists(subject, account, folder, timeout, options) {
		
		UIALogger.logMessage("Looking for email with subject '" + subject + "' in " + folder + " folder of " + account);
		
		if (!timeout) timeout = 60;
		if (!folder) folder = "Inbox";
		if (typeof options == 'undefined' || !options) options = new Object();
		
		this.getToEmailFolder(account, folder);
		
		var start = new Date().getTime();
		var elapsedTime = 0;
		
		while (timeout > elapsedTime) {
			UIALogger.logMessage("Searching for subject '" + subject + "' (timeout in " + Math.round(timeout - elapsedTime) + " seconds).");
			
			// check for the subject 5 times in a row before trying to go back to the inbox
			for (var i=0; i < 5; i++) {
				// Tap refresh button
				try {
					this.mainWindow().toolbar().elements()["Refresh"].tap();
				}
				catch (e) {
					UIALogger.logMessage("caught error: " + e.message);
					throw new Error("Could not tap 'Refresh' button.");
				}
				
				var subjectElement = mail.getSubjectElement("name contains '" + subject + "'");
				if (subjectElement.isValid()) {
					UIALogger.logMessage("Successfully found email with name '" + subjectElement.name() + "', email with subject '" + subject + "'");
					return true;
				}
				UIATarget.localTarget().delay(1);
			}
					
			// navigate back to the folder to make absolutely sure we're checking in the right place.
			this.getToEmailFolder(account, folder);
			elapsedTime = ((new Date().getTime()) - start)/1000;
		}

		UIALogger.logMessage("Tried fetching mail for " + timeout + " seconds.  Couldn't find the email with subject '" + subject + "'");  
		this.logElementTree();  // adding in some extra logging to try to catch <rdar://problem/8499723>
		return false;
	}
	
	//----------------------------------------------------------------------------------------
	//	Function: chooseEmail 
	//		Checks if an email with the specified subject exists in
	//		the specified folder of an account and then clicks on it.				
	//
	//	Requires:
	//		The folder and account exist on the phone
	//
	//	Parameters:
	//		(string) subject = The subject title to look for
	//		(string) account = The name of the account in which to search (optional, if not
	//			set, uses the first account it can find, probably will end up being all inboxes)
	//		(string) folder = The folder of the account in which to search (optional, if not
	//			set, 'Inbox' is used.  Please note that 'account' has to be set in order to
	//			use this option)
	//
	// Optional Parameters: 
	//		timeout (string) - The number of seconds to wait for the email to show up.  If not defined, 
	//			wait for 60 seconds.
	//		those used in verifyEmailExists()
	//	
	//	Returns: 
	//		None
	//
	//	Throws: 
	//		Error if the email can't be found.  
	//----------------------------------------------------------------------------------------
	mail.chooseEmail = function chooseEmail(subject, account, folder, options) {
		if (typeof options == 'undefined' || !options) { options = new Object(); }
		
		UIALogger.logMessage("Choosing email with subject '" + subject + "'");
		var timeout = 60;
		if (typeof options.timeout != 'undefined') timeout = options.timeout;
		
		if (!this.verifyEmailExists(subject, account, folder, timeout, options)) {
			throw new Error("Email with subject '" + subject + "' doesn't exist");
		}
	
		var subjectElement = mail.getSubjectElement("name contains '" + subject + "'");
		if (subjectElement.isValid()) {
			UIALogger.logMessage("Tapping email with name '" + subjectElement.name() + "', email with subject '" + subject + "' exists!");
			subjectElement.scrollToVisible();
			subjectElement.tap();
			return;
		}
		else {
			throw new Error("Could not choose email with subject '" + subject + "'");
		}
		
	}
	
	//----------------------------------------------------------------------------------------
	//	Function: deleteEmail 
	//		Checks if an email with the specified subject exists in
	//		the specified folder of an account and then deletes the email.					
	//
	//	Requires:
	//		The folder and account exist on the phone
	//
	//	Parameters:
	//		subject (string) - The subject title to look for.  If it's set to "RANDOM", it will
	//			delete a random email.
	//		account (string) - The name of the account in which to search (optional, if not
	//			set, uses the first account it can find, probably will end up being all inboxes)
	//		folder (string) - The folder of the account in which to search (optional, if not
	//			set, 'Inbox' is used.  Please note that 'account' has to be set in order to
	//			use this option)
	//
	//	Returns: 
	//		None
	//
	//	Throws:
	//		Error if the email can't be deleted.
	//----------------------------------------------------------------------------------------
	mail.deleteEmail = function deleteEmail(subject, account, folder) {
		
		UIALogger.logMessage("Looking for email with subject '" + subject + "' in " + folder + " folder of " + account);
		if (!folder) folder = "Inbox";
		
		if (subject != "RANDOM") {
			if (!this.verifyEmailExists(subject, account, folder)) {
				throw new Error("Email with subject '" + subject + "' doesn't exist");
			}
		}
		else {
			// Deleting a random email.  We should get to the proper account and then choose a random email title
			UIALogger.logDebug("Getting to the email account folder, so we can choose a random email to delete.");
			mail.getToEmailFolder(account, folder);
			UIALogger.logDebug("Got to the list of emails.");
			subject = mail.chooseRandomEmail().name();
			UIALogger.logMessage("Random email to delete is '" + subject + "'");
		}
		
		var initialCount = 1;
		UIALogger.logMessage("Tapping first email message with subject '" + subject + "'");
		try {
			var subjectElement = mail.getSubjectElement("name contains '" + subject + "'");
			if (subjectElement.isValid()) {
				UIALogger.logMessage("Tapping email with name '" + subjectElement.name() + "', email with subject '" + subject + "' exists!");
				subjectElement.scrollToVisible();
				subjectElement.tap();
			}
			else {
				throw new Error("Could not choose email with subject '" + subject + "'");
			}
		}
		catch(e) {
			UIALogger.logMessage("Caught error: " + e.message);
			throw new Error("Could not tap email with subject '" + subject + "'");
		}
		UIATarget.localTarget().delay(3);  // give a few extra seconds for the mail to load
		
		if (!this.mainWindow().toolbar().elements()["Delete"].isValid()) {
			// Got into a thread, get the initial count 
			var emailsMatching = this.mainWindow().tableViews()[0].cells().withPredicate("name contains '" + subject + "'");
			initialCount = emailsMatching.length;
			if (initialCount <= 0) {
				throw new Error("Could not find email with subject '" + subject + "' in list");
			}
			UIALogger.logMessage("In thread view--tapping message with name '" + emailsMatching[0].name() + "'");
			emailsMatching[0].tap();  // tap the first email in the thread
			UIATarget.localTarget().delay(3);  // give a few extra seconds for the mail to load
		}
		
		// Tap the delete button to delete the email
		UIALogger.logMessage("Tapping the delete button");
		try {	
			this.mainWindow().toolbars().firstWithPredicate("ANY elements.name == 'Delete'").elements()["Delete"].tap();
		}
		catch(e) {
			UIALogger.logMessage("Caught error: " + e.message);
			throw new Error("Could not tap the 'Delete' button");
		}
		UIATarget.localTarget().delay(3);  // wait for delete to take place... sometimes this takes a while.
		
		// Hit the navigation button to go back to the list of emails.
		UIALogger.logMessage("Going back to the list of emails");
		try {
			if (UIATarget.localTarget().model() == 'iPad') {
				this.getToEmailFolder(account, folder)
			}
			else {
				this.navigationBar().leftButton().tap();
			}
		}
		catch(e) {
			UIALogger.logMessage("Caught error: " + e.message);
			throw new Error("Could not tap the nav button to go back to the list of emails");
		}
		UIATarget.localTarget().delay(1);
		
		// make sure that the delete worked--compare the last count with the new one
		emailsMatching = this.mainWindow().tableViews()[0].cells().withPredicate("name contains '" + subject + "'");
		if (initialCount > emailsMatching.length) {
			UIALogger.logMessage("Successfully deleted email with subject '" + subject + "'");
			return true;
		}
		else {
			throw new Error("Could not delete email with subject '" + subject + "', count was " + initialCount + ", but is now " + emailsMatching.length);
		}
	}
	
	//----------------------------------------------------------------------------------------
	//	Function: search
	//		Searches for a specified title (partial match), and clicks on the first
	//		one, if a click is specified.  Returns false if the title is not found.					
	//
	//	Requires:
	//		The folder and account exist on the phone
	//
	//	Parameters:
	//		(string) searchString - The string to search for
	//
	//	Optional Parameters:
	//		(string) searchType - The type of search to use, i.e. "From", "To", "Subject", "All".
	//			If not specified, we assume "Subject".
	//		(string) account - The name of the account in which to search (optional, if not
	//			set, uses the first account it can find, probably will end up being all inboxes)
	//		(string) folder - The folder of the account in which to search (optional, if not
	//			set, 'Inbox' is used.  Please note that 'account' has to be set in order to
	//			use this option)
	//		(string) shouldSearchServer - bool indiating whether or not to search on the server
	//			set to false by default.
	//		(string) shouldTap - set to 0 by default.
	//		(integer) timeout - amount of time to wait for results to show up.  Set to 60 by
	//			default.
	//
	//	Returns: 
	//		True if the emails with the specified subjects exist
	//----------------------------------------------------------------------------------------
	mail.search = function search(searchString, options) {
		if (typeof options == 'undefined' || !options) options = new Object();
		if (typeof options.searchType == 'undefined' || !options.searchType) options.searchType = "Subject";
		if (typeof options.account == 'undefined') options.account = null;
		if (typeof options.folder == 'undefined') options.folder = null;
		if (typeof options.shouldSearchServer == 'undefined') options.shouldSearchServer = 0;
		if (typeof options.shouldTap == 'undefined') options.shouldTap = 0;
		if (typeof options.timeout == 'undefined') options.timeout = 60;
		
		UIALogger.logMessage("Going to account '" + options.account + "' and folder '" + options.folder + "'.");
		mail.getToEmailFolder(options.account, options.folder);

		UIATarget.localTarget().delay(1);
				
		// Tap SearchBar to bring up search UI
		try {
			UIALogger.logMessage("Searching for email using string '" + searchString + "'");
			var searchBar;
			if (UIATarget.localTarget().model() == 'iPad') {
				searchBar = this.mainWindow().searchBars()[0];
			}
			else {
				searchBar = this.mainWindow().tableViews()[0].searchBars()[0]; 
			}
			searchBar.scrollToVisible();
			searchBar.tap();
		}
		catch (e) {
			UIALogger.logMessage("Caught error: " + e.message);
			throw new Error("Could not tap the search bar to bring up the search UI");
		}
		UIATarget.localTarget().delay(1);
		
		// choose searchType
		UIALogger.logMessage("Choosing searchType: " + options.searchType);
		try {
			if (UIATarget.localTarget().model() == 'iPad') {
				this.mainWindow().segmentedControls()[0].elements().firstWithPredicate("name beginswith '" + options.searchType + "'").tap();
			}
			else {
				this.mainWindow().tableViews()[0].segmentedControls()[0].elements().firstWithPredicate("name beginswith '" + options.searchType + "'").tap();
			}
		}
		catch(e) {
			UIALogger.logMessage("Caught error: " + e.message);
			throw new Error("Could not choose the search type '" + options.searchType + "'");
		}
		UIATarget.localTarget().delay(1);
		
		// Type searchString in SearchBar
		UIALogger.logMessage("Searching for '" + searchString + "'");
		searchBar.setValue(searchString);
		UIATarget.localTarget().delay(2);
		
		// Search on server
		var searchResultsString = "Search results"
		if ((options.shouldSearchServer == "true") || (options.shouldSearchServer == 1) || (options.shouldSearchServer == true) || (options.shouldSearchServer == "1")) {
			UIALogger.logMessage("Choosing the option to search on server");
			try {
				this.mainWindow().tableViews().firstWithPredicate("name contains '" + searchResultsString + "'").scrollToElementWithPredicate("name beginswith 'Continue Search on Server'").tap();
			}
			catch (e) {
				UIALogger.logMessage("Caught Error: " + "e.message");
				UIALogger.logError("Could not choose the option for searching on the server")
			}
			UIATarget.localTarget().delay(1);
		}
		
		UIALogger.logMessage("Waiting up to " + options.timeout + " seconds for match to show up.");
		UIATarget.localTarget().pushTimeout(options.timeout);
		var theTableView = theTableView = this.mainWindow().tableViews();
		var theFoundElement = theTableView.firstWithPredicate("name contains '" + searchResultsString + "'").cells().firstWithPredicate("name contains '" + searchString + "'");
		UIATarget.localTarget().popTimeout();
		if (!theFoundElement.isValid()) {
			if ((options.searchType.match("From") == null) && (options.searchType.match("All") == null)) {
				throw new Error("Could not find the string '" + searchString + "' as '" + options.searchType + "' in mail");
			}

			// The search string may not be in the title (i.e. it is in the 'from' field or the body).  Get the first search result and make sure
			//		that the first result isn't 'Continue Search on Server'
			theFoundElement = this.mainWindow().tableViews().firstWithPredicate("name contains '" + searchResultsString + "'").cells()[0];
			if (!theFoundElement.isValid() || (theFoundElement.name().match("Continue Search on Server"))) {
				throw new Error("No results for '" + searchString + "' using search type '" + options.searchType + "' in mail");
			}
		}
		UIALogger.logMessage("Successfully found email matching '" + searchString + "'");
		
		if ((options.shouldTap == "true") || (options.shouldTap == 1) || (options.shouldTap == true) || (options.shouldTap == "1")) {
			UIALogger.logMessage("Tapping '" + theFoundElement.name() + "'");
			theFoundElement.scrollToVisible();
			try {
				theFoundElement.tap();  
			}
			catch(e) {
				UIALogger.logMessage("Caught error: " + e.message);
				throw new Error("Could not tap '" + theFoundElement + "'");
			}
		}
		return true;
	}
	
	//----------------------------------------------------------------------------------------
	//	mail.downloadAttachment - Downloads the specified attachment.				
	//
	//	Requires:
	//		The folder and account exist on the phone
	//
	//	Parameters: 
	//	    emailTitle (string) - title of the email to look for (required)	
	//		attachmentName (string) - name of the attachment (optional)
	//		
	//	Optional Parameters:
	//		account (string) - mail account in which the email should be
	//		folder (string) - folder in which the email should reside
	//		timeout (number) - number of seconds to wait for attachment to download (optional--
	//			default is 2 minutes)
	//		waitForMailTimeout (number) - number of seconds to wait for mail to be present in
	//			inbox.  If set to 0, we bypass checking in mail list completely and just do
	//			a search
	//		exactMatch (bool) - set to 'true' if you want an exact match of the attachment name, 
	//			false if you want a partial match (i.e. "name contains 'attachmentName'").  This is false by default.
	//		noVerification (bool) - set to true if verification that the attachment was downloaded
	//			is not desired.  This is assumed to be false by default (i.e. verification is done
	//			by default).  The verification done here is to check that the title of the attachment
	//			is contained in the navBar.
	//		elementToValidate (bool) - This is separate from noVerification.  If an elementToValidate is
	//			passed in, we ensure, at the end, that the element exists 
	//			(i.e. elementToValidate:UIATarget.localTarget().frontMostApp().mainWindow().navigationBar().buttons()['Cancel'])
	// 			If this is left blank, this verification does not occur.
	//
	//	Returns: TRUE if the emails with the specified subjects exist
	//----------------------------------------------------------------------------------------
	mail.downloadAttachment = function downloadAttachment(emailTitle, attachmentName, options) {
		if (typeof options == 'undefined' || !options) options = new Object();
		if (typeof options.account == 'undefined') options.account = null;
		if (typeof options.folder == 'undefined') options.folder = null;
		if (typeof options.timeout == 'undefined') options.timeout = 120;
		if (typeof options.waitForMailTimeout == 'undefined') options.waitForMailTimeout = 10;
		if (typeof options.exactMatch == 'undefined') options.exactMatch = false;
		if (typeof options.noVerification == 'undefined') options.noVerification = false;
		
		try {
			// try choosing the email from the email list, use the timeout specified
			var chooseEmailOptions = new Object();
			chooseEmailOptions.timeout = options.waitForMailTimeout;
			mail.chooseEmail(emailTitle, options.account, options.folder, chooseEmailOptions);
		}
		catch (e) {
			// if we can't find the email in the mailbox, we'll search the server for it.
			UIALogger.logMessage("Could not find email in list of emails, got error: " + e.message);
			UIALogger.logMessage("Searching for email now.")
			options.searchType = "Subject";
			options.shouldSearchServer = true;
			options.shouldTap = true;
			if (!mail.search(emailTitle, options)) {
				throw new Error("Could not find the email with subject " + emailTitle);
			}
		}
		// Give the attachment some time to download
		UIATarget.localTarget().delay(10);
		
		// tap the attachment
		try {
			if ((options.exactMatch == true) || (options.exactMatch == "true")) {
				UIALogger.logMessage("Trying to tap the attachment '" + attachmentName + "' with an exact match");
				this.mainWindow().scrollViews()[0].webViews().firstWithPredicate("ANY staticTexts.name == '" + attachmentName + "'").staticTexts()[attachmentName].tap();
			}
			else {
				UIALogger.logMessage("Trying to tap the attachment '" + attachmentName + "' with a partial match");
				this.mainWindow().scrollViews()[0].webViews().firstWithPredicate("ANY buttons.name contains '" + attachmentName + "'").buttons().firstWithPredicate("name contains '" + attachmentName + "'").tap();
				
			}
		}
		catch (e) {
			UIALogger.logMessage("Caught Error: " + e.message);
			throw new Error ("Could not tap the attachment with name " + emailTitle);
		}
		
		// wait for attachment to download and ensure we are where we expect to be
		if (!options.noVerification) {
			UIALogger.logMessage("Waiting for attachment to download.")
			UIATarget.localTarget().pushTimeout(options.timeout);
			var navBar = this.navigationBar();
			UIATarget.localTarget().popTimeout();
			if ((navBar.isValid()) && ((navBar.name() == attachmentName) || (navBar.staticTexts()[attachmentName].isValid()))) {
				UIALogger.logMessage("Clicked on the attachment and saw the expected title in the nav bar.");
			}
			else {
				throw new Error("Clicked on the attachment, but did not see the proper title in the nav bar");
			}
		}
		
		// If an elementToValidate is specified, check to make sure we have it.
		if ((options.elementToValidate != 'undefined') && options.elementToValidate) {
			UIALogger.logMessage("Validating specified element: '" + options.elementToValidate + "'");
			UIATarget.localTarget().pushTimeout(options.timeout);
			var isElementValid = eval (options.elementToValidate).isValid();			
			UIATarget.localTarget().popTimeout();
			if (!isElementValid) {
				throw new Error("Could not find '" + options.elementToValidate + "' on screen.");
			}
		}
	
	}
	
	//----------------------------------------------------------------------------------------
	//	mail.selectMessages - selects the specified message titles. If no titles are given, it
	//		choses "numMessages" number of random messages.  If that's not specified,
	//		it selects one random message.
	//
	//	Requires:
	//		Must be in a folder that has messages in it.
	//
	//	Optional Parameters:
	//		emailTitles (string or array) - the titles of the emails that should be selected.
	//		numMessages (integer) - number of random messages to select.
	//
	//	Returns:
	//	 throws error if it cannot select the messages.  If it can select messages, this function
	//		returns the array of messages that were selected.
	//----------------------------------------------------------------------------------------
	mail.selectMessages = function selectMessages(options) {
		if (typeof options == 'undefined' || !options) options = new Object();
		if (typeof options.numMessages == 'undefined') options.numMessages = 1;
		var selectedMessages = new Array();

		// email titles were specified.  we should find those and choose them.  
		// IMPORTANT: please note that this will not always work.  mail (like most other apps) does not contain table cells with all of the
		// downloaded emails.  So, only a subset of the emails will be located.  To fix this, we could scroll through the table, but it's 
		// probably not worth it at this point.  Please note that we can't do a search within mail, because, even though the email would be
		// found, mail doesn't support selecting emails from the search area.
		if ((typeof options.emailTitles != 'undefined')  && (options.emailTitles != null) && (options.emailTitles.length > 0)) {
			var subjects = options.emailTitles;
			if (typeof subjects == 'string') {
				// put it into an array for easier use
				UIALogger.logMessage("Putting subjects into an array");
				subjects = new Array(subjects);
			}
			for (var i = 0; i < subjects.length; i++) {
				// looks like if something is selected the value can either be true or 'SELECTED'
				var tableView = this.mainWindow().tableViews()[0];
				var subjectElement = tableView.elements().firstWithPredicate("name contains '" + subjects[i] + "' and value != 'SELECTED' and value != true");
				if (!subjectElement.isValid()) {
					throw new Error("Could not find email with subject " + subjects[i]);
				}
				try {
					UIALogger.logMessage("Successfully found email with name '" + subjectElement.name() + "', email with subject '" + subjects[i] + "'");
					subjectElement.scrollToVisible();
					subjectElement.tap();
					selectedMessages.push(subjectElement);
				}
				catch (e) {
					UIALogger.logMessage("Caught Error: " + e.message);
					throw new Error("Found the subject element with name '" + subjectElement.name() + "', but could not tap or scroll to it.");
				}
				UIATarget.localTarget().delay(0.5); // wait for chosen elements to get marked "Selected"
			}
		}
		
		// otherwise we select the numMessages that was requested.
		else {
			for (var i = 0; i < options.numMessages; i++) {
				var MessageArray = this.mainWindow().tableViews()[0].cells().withPredicate("value != 'SELECTED'");
				if (messageArray.length == 0) {
					throw new Error("Not enough messages in folder.  Couldn't delete '" + options.numMessages + "' messages.")
				}
				var theMessageIndex = system.randomInteger(0, messageArray.length);
				theMessage = messageArray[theMessageIndex];
				if (theMessage.name().match("Load More Messages")) { i--; continue; }  // don't want to choose "Load more messages"
				UIALogger.logMessage("Selecting message with subject '" + theMessage.name() + "' as a random message.");
				
				theMessage.scrollToVisible();
				theMessage.tap();
				selectedMessages.push(theMessage);
			}
		}
		return selectedMessages;
		
	}
	
	//----------------------------------------------------------------------------------------
	//	mail.deleteBulk - deletes the emails in bulk, choosing random ones if none are specified
	//
	//	Requires:
	//		There must be an account setup and there must be some emails to delete from that account.
	//
	//	Optional Parameters:
	//		account (string) - mail account in which the email should be.  If not specified, chooses
	//			the first account.
	//		folder (string) - folder from which the email(s) should be deleted.  If not specified,
	//			choose "Inbox"
	//		emailTitles (string) - title of the email to look for.  If not specified, chooses a random
	//			one
	//		numMessages (integer) - number of emails to delete.  If one or more titles are speicfied,
	//			this preference is ignored.  Otherwise, this preference indicates the number of 
	//			random emails to delete.
	//
	//	Returns:
	//	 0 if test failed, 1 if it succeeded.  Uses the PHTesting object.
	//----------------------------------------------------------------------------------------
	mail.deleteBulk = function deleteBulk(options) {
		if (typeof options == 'undefined' || !options) options = new Object();
		if (typeof options.account == 'undefined') options.account = null;
		if (typeof options.folder == 'undefined') options.folder = null;
		if (typeof options.emailTitles == 'undefined') options.emailTitles = null;
		if (typeof options.numMessages == 'undefined') options.numMessages = 1;	
		
		// If the account is specified, we should go to that account and folder.
		UIALogger.logMessage("Going to account '" + options.account + "' and folder '" + options.folder + "'.");
		this.getToEmailFolder(options.account, options.folder);
		
		try {
			this.navigationBar().buttons()['Edit'].tap();
			UIATarget.localTarget().delay(0.5);
		}
		catch (e) {
			UIALogger.logMessage("Caught Error: " + e.message);
			throw new Error("Could not tap 'Edit' button");
		}
	
		selectedMessages = this.selectMessages(options);

		// if someone specified one or more titles, use that for numMessages
		if ((options.emailTitles != null) && (options.emailTitles.length > 0)) {
			options.numMessages = options.emailTitles.length;
		}
		
		var theToolbar = this.toolbar(); 
		var deleteButton = theToolbar.buttons().firstWithPredicate("name beginswith 'Delete'");
		if (!deleteButton.isValid()) {
			throw new Error("Could not find the 'Delete' button");
		}
		
		// Figure out how many messages are actually going to be deleted, i.e. button is named 'Delete (5)'
		var deleteButtonName = deleteButton.name();
		var openingParenIndex = deleteButtonName.indexOf("(");
		var closingParenIndex = deleteButtonName.indexOf(")");
		if ((openingParenIndex < 0) || (closingParenIndex < 0)) {
			throw new Error("Could not calculate the actual number of messages that are going to be deleted.")
		}
		var actualNumMessagesToDelete = parseInt(deleteButtonName.substring(openingParenIndex+1, closingParenIndex)); 
		if (actualNumMessagesToDelete != options.numMessages) {
			throw new Error("We should be deleting " + options.numMessages + ", but after choosing the messages, we're deleting " + actualNumMessagesToDelete);
		}
		UIALogger.logMessage("Deleting " + actualNumMessagesToDelete + " email messages.");
		
		// tap the delete button
		deleteButton.tap();
		
		// TODO look for the messages we were supposed to delete to make sure they're actually gone
		// This is a little tricky, because we could have several emails with the same name.
		//for (var i=0; i<selectedMessages.length; i++) {
		//	if (this.mainWindow().tableViews()[0].elements()[selectedMessages[i].name()].isValid()) {
		//		throw new Error("Found message with subject '" + selectedMessages[i].name() + "' even though it should have been deleted.")
		//	}
		//}
	}
	
	//----------------------------------------------------------------------------------------
	//	mail.printEmail - prints the email that the mail app is currently on.
	//
	//	Requires:
	//		Mail must currently be displaying the email that will be printed.  
	//
	//	Optional Parameters:
	//		printerName (string) - the name of the printer. If no value is specified, 
	//			a random printer is selected
	//		numberOfCopies (number) - the number of print copies. If no value is 
	//			specified, the default value is not changed.
	//
	//	Returns:
	//	 0 if test failed, 1 if it succeeded.  Uses the PHTesting object.
	//----------------------------------------------------------------------------------------
	mail.printEmail = function printEmail(options) {
		
		// tap the 'Reply' button to bring up options for doing something with the email (i.e. 'Print', 'Forward', etc)
		try {
			this.mainWindow().toolbars().firstWithPredicate("ANY buttons.name == 'Reply'").buttons()["Reply"].tap();
			UIATarget.localTarget().delay(2); // wait for animation to finish
		}
		catch (e) {
			UIALogger.logError("Caught Error: " + e.message);
			throw new Error ("Could not tap 'Reply' button");
		}
		
		// tap print
		try {
			if (UIATarget.localTarget().model() == 'iPad') {
				this.mainWindow().popover().actionSheet().buttons()["Print"].tap();
			}
			else {
				this.actionSheet().buttons()["Print"].tap();
			}
			UIATarget.localTarget().delay(1);  // wait for animation to finish
		}
		catch (e) {
			UIALogger.logError("Caught Error: " + e.message);
			throw new Error ("Could not tap 'Print' button in the action sheet");
		}
		
		// check to see if there is an action sheet asking if we want to download the message first 
		var yesButton = this.actionSheet().buttons()["Yes"];
		if (yesButton.isValid()) {
			UIALogger.logMessage("Clicking 'yes' to action sheet, probably asking if I want to download the rest of the message");
			this.actionSheet().buttons()["Yes"].tap();
		}
		
		mail.printWithOptions(options);
		
	}
	
    
	//----------------------------------------------------------------------------------------
	//	Function: mail.checkDataDetection
	//      Loads a sample e-mail and checks the links produced by data detection.
	//
	//	Assumes: 
	//		Assumes mail is already set up.
	//
	//	Parameters:
	//      subject (string) - the subject of the mail to check
	//		account (string) - the address or account description in which the email should be located
	//		folder  (string) - the folder in which the email should be located.
	//		expectedURLs (array) - an array of {url, name} elements (as strings).
	//
	// Optional Parameters: 
	//		those used in chooseEmail()
	//	
	//	Returns:
	//	 false if test failed, true if it succeeded.  Uses the PHTesting object.
	//----------------------------------------------------------------------------------------
	mail.checkDataDetection = function checkDataDetection(subject, account, folder, expectedURLs, options) {
	
		mail.chooseEmail(subject, account, folder, options);
    
		var webView = mail.mainWindow().scrollViews()[0].webViews()["Message"];
		var success = mail.checkWebViewDataDetection(webView, expectedURLs);
	
		return (success);
	}

}