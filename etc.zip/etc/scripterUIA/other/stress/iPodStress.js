#import "UIAAppStressLibrary.js"

// audio stress tests
if (typeof audio != 'undefined') {
	audioStress = AppStressBase.stressTest("Audio");
	
	if (typeof audioStress != 'undefined') {
		
		audioStress.setup = function setup() {
			audioStress.addTest(audioStress._playSongFromSongList);
			audioStress.addTest(audioStress._startPlaylist);
			audioStress.addTest(audioStress._scrubSong);
			audioStress.addTest(audioStress._playPauseSong);
			audioStress.addTest(audioStress._selectPreviousNextSong);
			
			return true;
		}
		
		audioStress.init = function init() {
			gAppStressAudioObject.checkIfAudioIsPlayingAndUpdateObject();
			gAppStressAudioObject.printTotals();
			
			return true;
		}
		
		audioStress.run = function run() {
			audioStress.executeRandomTests(4);
		}
		
		audioStress._playSongFromSongList = function _playSongFromSongList() {
			audioStress.executeTest("PlaySongFromSongList", [], iPodTest_playSongFromSongList, "Play a song from the song list.");
		}
		
		audioStress._startPlaylist = function _startPlaylist() {
			if(!gAppStressAudioObject.shouldBePlayingMusic) {
				audioStress.executeTest("StartPlaylist", [], iPodTest_startPlaylist, "Start playing a playlist.");
			}
			else {
				audioStress.executeTest("StopPlaylist", [], iPodTest_stopPlaylist, "Stop playing a playlist.");
			}
		}
		
		audioStress._scrubSong = function _scrubSong() {
			gAppStressAudioObject.startPlayingMusic();
			audioStress.executeTest("ScrubSong", [], iPodTest_scrubSong, "Scrubs the progress slider of a song.");
		}
		
		audioStress._playPauseSong = function _playPauseSong() {
			audioStress.executeTest( "PlayPauseSong", 
									 [null, "play", "pause", "play", "pause"],
									 iPodTest_playPauseSong, "Play and pause a song." );
		}
		
		audioStress._selectPreviousNextSong = function _selectPreviousNextSong() {
			audioStress.executeTest( "SelectPreviousNextSong", 
									 [null, "Next", "Next", "Previous", "Previous"],
									 iPodTest_selectPreviousNextSong, "Switch between next and previous songs." );
		}
	}
}


// video stress tests
if (typeof video != 'undefined') {
	videoStress = AppStressBase.stressTest("Video");
	
	if (typeof video != 'undefined') {
		
		videoStress.setup = function setup() {
			videoStress.addTest(videoStress._playMovieFromVideoList);
			videoStress.addTest(videoStress._scrubVideo);
			videoStress.addTest(videoStress._playPauseVideo);
		}
		
		videoStress.init = function init() {
			gAppStressAudioObject.stopPlayingMusic();
		}
		
		videoStress.run = function run() {
			videoStress.executeRandomTests(4);
		}
		
		
		videoStress._playMovieFromVideoList = function _playMovieFromVideoList() {
			videoStress.executeTest("PlayMovieFromVideoList", [], iPodTest_playMovieFromVideoList, "Play a movie from the video list.");
		}
		
		videoStress._scrubVideo = function _scrubVideo() {
			videoStress.executeTest("ScrubVideo", [], iPodTest_scrubVideo, "Scrub video.");
		}
		
		videoStress._playPauseVideo = function _playPauseVideo() {
			videoStress.executeTest("PlayPauseVideo", [null, "play", "pause", "play", "pause"], iPodTest_playPauseVideo, "Play and pause a video.");
		}
	}
}
