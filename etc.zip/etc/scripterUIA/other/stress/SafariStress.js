#import "UIAAppStressLibrary.js"

//The URLs to  use for Safari Stress Tests
//- first item will be used to generate a test name (should be short and avoid spaces, special chars etc)
var urls = new Array();
urls.push(
	["Google", "http://www.google.com/", "Google"],
	["Apple", "http://www.apple.com/", "Apple"],
	["Flickr", "http://m.flickr.com/#/home", "Flickr"],
	["CNN", "http://m.cnn.com/#___1__", "CNN"],
	["Digg", "http://m.digg.com/", "Digg - All News, Videos, & Images"],
	["Delicious", "http://delicious.com/", "Delicious"],
	["Wikipedia", "http://www.wikipedia.org/", "Wikipedia"],
	["AppleTrailers", "http://www.apple.com/trailers/iphone/", "Apple - Movie Trailers"],
	["NYTimes", "http://www.nytimes.com/", "The New York Times - Breaking News, World News & Multimedia"],
	["WallStreetJournal", "http://online.wsj.com/home-page", "Business News, Finance News, World, Political & Sports News from The Wall Street Journal - WSJ.com"],
	["BBC", "http://www.bbc.co.uk/mobile/i/", "bbc.com"],
	["ChinaNews", "http://www.china.com.cn/", "中国网--网上中国"]
);
var crawlList = [];
crawlList.push(
	["Google", "http://www.google.com/", "Google"],
	["Apple", "http://www.apple.com/", "Apple"],
	["Flickr", "http://m.flickr.com/#/home", "Flickr"],
	["CNN", "http://m.cnn.com/#___1__", "CNN"],
	["Digg", "http://m.digg.com/", "Digg - All News, Videos, & Images"],
	["Delicious", "http://delicious.com/", "Delicious"],
	["Wikipedia", "http://www.wikipedia.org/", "Wikipedia"],
	["AppleTrailers", "http://www.apple.com/trailers/iphone/", "Apple - Movie Trailers"],
	["NYTimes", "http://www.nytimes.com/", "The New York Times - Breaking News, World News & Multimedia"],
	["WallStreetJournal", "http://online.wsj.com/home-page", "Business News, Finance News, World, Political & Sports News from The Wall Street Journal - WSJ.com"],
	["BBC", "http://www.bbc.co.uk/mobile/i/", "bbc.com"],
	["ChinaNews", "http://www.china.com.cn/", "中国网--网上中国"],
	["eBay", "http://www.ebay.com/", "eBay Mobile"],
	["Amazon", "http://www.amazon.com/", "Amazon"],
	["Twitter", "http://www.twitter.com/", "Twitter"]
	);
var suggestionList = [];
suggestionList.push(
	["goog", "http://www.google.com/", "http://www.google.com/"],
	["yah", "http://www.yahoo.com/", "http://m.yahoo.com/?.tsrc=yahoo&mobile_view_default=true"],
	["app", "http://www.apple.com/", "http://www.apple.com/"],
	["app", "http://www.apple.com/webapps/", "http://www.apple.com/webapps/"]
	);
var googleList = [];
googleList.push(
	["apple", "www.apple.com"],
	["google", "www.google.com"],
	["nytimes", "www.nytimes.com"],
	["digg", "digg.com"],
	["cnn", "www.cnn.com"],
	["bbc", "www.bbc.co.uk"]
	);

if (typeof safari != 'undefined') {
	safariStress = AppStressBase.stressTest("Safari");
	
	if (typeof safariStress != 'undefined') {

		safariStress.setup = function setup () {
			safariStress.addTest(safariStress._flickDragZoomPinch);
			safariStress.addTest(safariStress._refreshPage);
			safariStress.addTest(safariStress._openWebPageFromPreviousTab);
			safariStress.addTest(safariStress._addBookmark);
			safariStress.addTest(safariStress._addBookmarkToHomeScreen);
			safariStress.addTest(safariStress._selectItemFromSuggestionList);
			safariStress.addTest(safariStress._crawlWebsite);
			safariStress.addTest(safariStress._loadRandomBookmark);
			safariStress.addTest(safariStress._performGoogleSearch);
			
			return true;
		}
		
		safariStress.init = function init () {
			safari.launchIfNotActive();
			
			var actionSheet = safari.actionSheet();
			if (actionSheet.isValid()) {
				var cancelButton = actionSheet.buttons()["Cancel"];
				if (cancelButton.isValid()) { cancelButton.tap() }
				else {
					UIALogger.logError("Encountered an action sheet we don't know how to clear -- aborting test area.");
					return false;
				}
			}
		}

		safariStress.run = function run () {
			safariStress.executeRandomTests(3);
		}
		
		// flick, drag, zoom, pinch
		safariStress._flickDragZoomPinch = function _flickDragZoomPinch() {
			var count = system.randomInteger(1, 5);
			var url = UIAUtility.randomFromArray(urls);
			var testArgs = new Array(url[1], true);
			
			for (var i = 0; i < count; i++) { testArgs.push("random") }
			
			safariStress.executeTest("FlickDragZoomPinch", testArgs, safariTest_loadSafariPage,  "Loading " + url[1] + " in Safari.");
		}
		
		
		
		// refresh page
		safariStress._refreshPage = function _refreshPage() {
			var url = UIAUtility.randomFromArray(urls);
			safariStress.executeTest( "RefreshPage", [ url[1] ], safariTest_refreshPage, "Loading and reloading url " + url[1] + ".");
		}
			
		// open web page from previous tab
		safariStress._openWebPageFromPreviousTab = function _openWebPageFromPreviousTab() {
			var url1 = UIAUtility.randomFromArray(urls);
			var url2 = UIAUtility.randomFromArray(urls);
			safariStress.executeTest( "OpenWebPageFromPreviousTab", 
						 			  [ url1[1], url2[1], url1[2], url2[2] ], 
						 			  safariTest_openWebPageFromPreviousTab,
						 			  "Opening url " + url1[1] + ", then opening url " + url2[1] + " in another tab." );
		}
			
		// add bookmark
		safariStress._addBookmark = function _addBookmark() {
			safariStress.executeTest("AddBookmark", [], safariTest_addBookmark, "Add the current page as a bookmark.");
		}
		
		// add bookmark to home screen
		safariStress._addBookmarkToHomeScreen = function _addBookmarkToHomeScreen() {
			safariStress.executeTest( "AddBookmarkToHomeScreen", 
									  [ null, 48 ], 
									  safariTest_addBookmark, 
									  "Add the current page as a bookmark on the home screen." );
		}
		
		// select item from suggestion list
		safariStress._selectItemFromSuggestionList = function _selectItemFromSuggestionList() {
			var site = UIAUtility.randomFromArray(suggestionList);
			safariStress.executeTest( "SelectItemFromSuggestionList", 
									  [ site[0], site[1], site[2] ],
									  safariTest_selectItemFromSuggestionList,
									  "Types in part of a URL and selects the link from the suggestion list." );
		}
		
		// crawl website
		safariStress._crawlWebsite = function _crawlWebsite() {
			var url = UIAUtility.randomFromArray(crawlList);
			var testArgs = new Array(url[1]);
			testArgs.push(system.randomInteger(10, 50));
			testArgs.push(true);
			
			safariStress.executeTest( "CrawlWebsite" + url[0],
									  testArgs,
									  safariTest_crawlWeb,
									  "Crawling website in safari starting with " + url[1] );
		}
		
		// load random bookmark
		safariStress._loadRandomBookmark = function _loadRandomBookmark() {
			safariStress.executeTest("LoadRandomBookmark", [], safariTest_loadRandomBookmark, "Selecting a random bookmark to load in Safari.");
		}
		
		// perform Google search
		safariStress._performGoogleSearch = function _performGoogleSearch() {
			var search = UIAUtility.randomFromArray(googleList);
			safariStress.executeTest( "PerformGoogleSearch",
									  [ search[0], search[1], false ],
									  safariTest_performGoogleSearch,
									  "Performs a Google search." );
		}
	}
}
	
	
	