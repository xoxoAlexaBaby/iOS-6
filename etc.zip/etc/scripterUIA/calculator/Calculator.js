/*
 Class: UIApp (calculator)
 Calculator object
 */
#import "../libs/SpringBoard.js"

calculator = UIAApp.application("Calculator", "com.apple.calculator");

if (typeof calculator != 'undefined') {
	
	calculator.launchIfNotActive = function launchIfNotActive() {
		try {
			this.__proto__.launchIfNotActive.apply(this);
		} catch(e) {
			UIALogger.logError(e.message);
			if (e.message && e.message.indexOf("Could not find the app icon") < 0) throw e;
			
			UIALogger.logDebug("Could not find the app icon -- will look in the utilities folder");
			appIcon = springboard.getToIconWithNameInFolder(this.name, "Utilities");
			// try up to three times to launch app (sometimes it doesn't seem to launch on the first try...)
			for (var j=0; j<3; j++) {
				appIcon.tap();
				
				// verify that the app has launched
				var isActive = this.waitForActive();	
				if (isActive) { 
					UIALogger.logMessage("Successfully launched '" + this.name + "', j = " + j);
					return;
				}
			}
			
			throw new Error("Failed to launch " + this.name + ".");			
		}
	}
	
	// --------------------------------------------------------------------------------
	//	Function: displayedNumber  
	//		Returns the currently displayed number 
	//
	//	Parameters:
	//		None
	//
	//	Return:
	//		The displayed number
	// --------------------------------------------------------------------------------
	calculator.displayedNumber = function displayedNumber() {
		var displayElement = this.mainWindow().staticTexts()["displayBackgroundSlice"];
		if (!displayElement.isValid()) {
			UIALogger.logWarning("Did not find display value element");
			return null;
		}
		return displayElement.value().split(",").join("");
	}
	
	// --------------------------------------------------------------------------------
	//	Function: precisionOfDisplayedNumber  
	//		Precision of the displayed number
	//
	//	Parameters:
	//		None
	//
	//	Return:
	//		The precision of the displayed number
	// --------------------------------------------------------------------------------
	calculator.precisionOfDisplayedNumber = function precisionOfDisplayedNumber() {
		var displayedNumber = this.displayedNumber();
		var significantNumber = displayedNumber.match(/\d*\.*\d+/);
		if (significantNumber == null) throw new Error("No digits in the displayed number");
		return significantNumber[0].replace('.', '').length;
	}
	
	// --------------------------------------------------------------------------------
	//	Function: calculatorButtonWithSymbol
	//		Return the specified calculator button
	//
	//	Parameters:
	//		buttonID (string) - symbol of the button to tap. The symbol is the same as 
	//			the one that appears on the calculator (e.g. '+' for addition, '1' for the 
	//			digit 1, etc.)
	//
	//	Throws: 
	//		Error
	//
	//	Returns:
	//		The calculator button with the specified symbol
	// --------------------------------------------------------------------------------
	calculator.calculatorButtonWithSymbol = function calculatorButtonWithSymbol(buttonID) {
		var buttonName;
		switch(buttonID) {
			case '+':
				buttonName = "add";
				break;
			case '-':
				buttonName = "subtract";
				break;
			case '*':
				buttonName = "multiply";
				break;
			case '/':
				buttonName = "divide";
				break;
			case '.':
				buttonName = "decimal";
				break;
			case '=':
				buttonName = "equals";
				break;
			case 'c':
				buttonName = "clear";
				break;
			default:
				buttonName = buttonID;
				break;
		}

		return this.mainWindow().images()[0].elements().firstWithName(buttonName);
	}
	
	// --------------------------------------------------------------------------------
	//	Function: typeString
	//		Types a sequence of calculator buttons using calculatorButtonWithSymbol
	//
	//	Parameters:
	//		(string) - the sequence of caluclator buttons to tap
	//		(float) - minimum delay speed, unit is seconds
	//		(float) - maximum delay speed, unit is seconds
	//
	//	Returns:
	//		none
	// --------------------------------------------------------------------------------
	calculator.typeString = function (string, minDelay, maxDelay) {
		if (!minDelay) { minDelay = system.randomReal(0.15, 0.75); }
		if (!maxDelay) { maxDelay = system.randomReal(minDelay, 1.5); }
		
		UIALogger.logMessage("Typing '" + string + "." + "'");
		for (var i = 0; i < string.length; i++) {
			var delay = system.randomInteger(minDelay, maxDelay);
			UIATarget.localTarget().delay(delay);
			UIALogger.logMessage("Button: '" + string.charAt(i) + "." + "'");
			var buttonElement = this.calculatorButtonWithSymbol(string.charAt(i));
			if (!buttonElement.isValid() && string.charAt(i) == 'c') {
				UIALogger.logDebug("clear button not present -- checking if this is expected");
				if (this.displayedNumber() == "0") continue;
			}
			buttonElement.tap();
		}
	}
}
