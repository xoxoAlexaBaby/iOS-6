#import "UIAAppStressLibrary.js"


if (typeof messages != 'undefined') {
	messagesStress = AppStressBase.stressTest('Messages');
	
	if (typeof messagesStress != 'undefined') {
		
		messagesStress.setup = function setup() {
			messagesStress.addTest(messagesStress._sendReceiveTextMessage);
			messagesStress.addTest(messagesStress._sendReceiveBulkSMS);
			messagesStress.addTest(messagesStress._sendReceivePhotoOrVideoMMS);
		}
		
		messagesStress.run = function run() {
			messagesStress.executeRandomTests(2);
		}
		
		// send/receive text message
		messagesStress._sendReceiveTextMessage = function _sendReceiveTextMessage() {
			var textToSend = getRandomMessage(1, 20, 1, 10);
			messagesStress.executeTest( 'SendReceiveTextMessage', [ textToSend, "timeout:120" ],
										messagesTest_sendReceiveTextMessage, "Send and receive a text message." );
		}
		
		// send/receive bulk SMS
		messagesStress._sendReceiveBulkSMS = function _sendReceiveBulkSMS() {
			var textToSend = "Stress Bulk SMS " + (new Date()).toDateString();
			var args = new Array ( 
					textToSend,
					"phoneNumber:4083321896",
					"phoneNumber:4083323272",
					"expectedMessage:" + textToSend,
					"timeout:120",
					"expectedPercentage:.5"
					);
			
			messagesStress.executeTest('SendReceiveBulkSMS', args, messagesTest_sendReceiveBulkSMS, "Send and receive bulk SMS.");
		}
		
		// send/receive photo or video (MMS)
		messagesStress._sendReceivePhotoOrVideoMMS = function _sendReceivePhotoOrVideoMMS() {
			var textToSend = getRandomMessage(1, 20, 1, 10);
			messagesStress.executeTest( 'SendReceivePhotoOrVideoMMS', [ 'textToSend:' + textToSend, 'timeout:120' ], 
										messagesTest_sendReceivePhotoOrVideoMMS, "Send and receive a photo or video MMS." );
		}
	}
}