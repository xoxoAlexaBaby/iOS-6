/*
 Class: UIApp (safari)
 Safari object
 */
#import "../libs/SpringBoard.js"
#import "../libs/UIAAppMailAdditions.js"
#import "../libs/UIAAppPrintingAdditions.js"
#import "../libs/UIAWebViewAdditions.js"

safari = UIAApp.application("Safari", "com.apple.mobilesafari");

if (typeof safari != 'undefined') {
	
	safari._expectedAlertMessages = {}
	safari._expectedAlertMessages.currentLocationMessage = "Would Like To Use Your Current Location";
	safari._expectedAlertMessages.yahooSearchRecommendationMessage = "Do you want to change your search engine to Yahoo";
	
	safari.alertHandler = function alertHandler(alert) {
		if (!alert.isVisible()) {
			UIALogger.logWarning("Alert not visible");
		}

		UIATarget.localTarget().pushTimeout(0);
		//Current Location message

		if (alert.staticTexts().firstWithPredicate("name matches '.*"+ safari._expectedAlertMessages.currentLocationMessage + ".*'").isValid()) {
			UIALogger.logMessage("Got the current location alert");
			alert.buttons()["OK"].tap();
		} else if (alert.staticTexts().firstWithPredicate("name contains '" + safari._expectedAlertMessages.yahooSearchRecommendationMessage + "'").isValid()) {
			UIALogger.logMessage("Got the yahoo search recommendation alert");
			alert.buttons()["Cancel"].tap();
		}
		UIATarget.localTarget().popTimeout();

		if (!alert.waitForInvalid()) throw new Error("Could not handle the alert");
		return true;
	}
	
	safari.loadURL = function loadURL(url) {
		return this.asApplication().loadURL(url);
	}
	
	safari.isLoading = function isLoading() {
		return this.asApplication().isLoading();
	}

	
	safari.activeURL = function activeURL() {
		return this.asApplication().activeURL();
	}
	
	safari.linksOnActivePage = function linksOnActivePage() {
        var parentQueue = [this.mainWindow().scrollViews()[0].webViews()[0]];
        var links = [];
        UIATarget.localTarget().pushTimeout(0);
        while (parentQueue.length > 0) {
            var parentElement = parentQueue.shift();
            parentQueue = parentQueue.concat(parentElement.elements().withPredicate("className != 'UIALink'").toArray());
            links = links.concat(parentElement.links().toArray());
        }
		UIATarget.localTarget().popTimeout();
		return links;
	}

	//--------------------------------------------------------------------------------
	//	safari.addressBar - returns the address bar UIAElement
	//
	//	Parameters: 
	//		None
	//
	//	Returns: 
	//		the UIAElement corresponding to the address bar
	// --------------------------------------------------------------------------------
	safari.addressBar = function addressBar() {
		//there are two elements with the name "Address" (one of them is a UIATextField and the other is a UIAElement)
		//when the address bar has keyboard focus, the UIATextField element is visible, otherwise the other element
		//should be visible. 
		var addressBar = this.mainWindow().elements().firstWithPredicate("name == 'Address' and isVisible == 1");
		if (!addressBar.isValid()) {
			UIALogger.logDebug("Did not find a visible address bar in the first try -- returning the UIAElement addressBar");
			addressBar = this.mainWindow().elements().firstWithPredicate("name == 'Address' and className != 'UIATextField'"); 
			if (!addressBar.isVisible()) UIALogger.logWarning("The address bar is not visible");
		}
		return addressBar;
	}
	
	//--------------------------------------------------------------------------------
	//	Function: checkForPageLoadErrorSinceDate 
	//		Determines whether there was a page load error
	//		
	//	Parameters: 
	//		date (Date object) - check if a page load error occurred since the specified
	//			date
	//
	//	Returns: 
	//		true if there was no page load error, false otherwise. 
	// --------------------------------------------------------------------------------
	safari.checkForPageLoadErrorSinceDate = function checkForPageLoadErrorSinceDate(date) {
		UIALogger.logMessage("Checking for page load error...");
		
		var loadAlert = this.alertSinceDate(date);
		if (loadAlert) {
			//check if it is one of the expected alerts...
			for (var key in safari._expectedAlertMessages) {
				var alertMessage = loadAlert.alertMessageArray[0];
				if (alertMessage && alertMessage.indexOf(safari._expectedAlertMessages[key]) >= 0) {
					UIALogger.logDebug("Encountered an expected alert");
					return true;
				}
			}
			UIALogger.logError("Encountered an error");
			return false;
		}
		
		return true;
	}
	
	// --------------------------------------------------------------------------------
	//	Function: loadPageAndWait
	//		Loads the specified page, and waits for the page to load. 
	//
	//	Parameters: 
	//		page (string) - the page url that needs to be loaded
	//		waitTime (int) - the number of seconds to wait for the page to load
	//
	//	Returns: 
	//		None
	//
	//	Throws: 
	//		Error if the page did not load successfully 
	// --------------------------------------------------------------------------------	
	safari.loadPageAndWait = function loadPageAndWait(page,waitTime)
	{
		if (!page) throw new Error("No page specified");
		
		UIALogger.logMessage("Loading " + page + " ...");
		
		this.reset();
		
		var date = new Date();
		this.loadURL(page);
		
		// Wait for page to finish loading
		try {
			this.waitForPageToLoad(waitTime, {date:date});
		} catch(e) {
			UIALogger.logError(e.message);
			throw new Error("The page did not load");
		} 
	}

	// --------------------------------------------------------------------------------
	//	Function: waitForPageToLoad 
	//		Waits for the current page to finish loading. 
	//
	//	Parameters: 
	//		timeout (int) - the number of seconds to wait for the page to load
	//
	//	Optional Parameters:
	//		date (Date object) - a date object to use with alertSinceDate call to check 
	//			for page load errors. This date should ideally be set just before the page 
	//			load action begins. If no value is specified, a date object is created 
	//			at the start.
	//
	//	Returns: 
	//		None
	//
	//	Throws: 
	//		Error if the page did not load successfully
	// --------------------------------------------------------------------------------	
	safari.waitForPageToLoad = function waitForPageToLoad(timeout, options) {
		if (!options) options = new Options();
		var date = (options.date) ? options.date : new Date();
		
		var addressBar = this.addressBar();
		if (!addressBar.isValid()) {
			throw new Error("Did not find the address bar");
		}
		
		// Wait for page to finish loading
		for (var s = 0; s < timeout; s++) {
			// If we are loaded, break out of our wait loop
			if (!this.isLoading()) {
				if (this.checkForPageLoadErrorSinceDate(date)) {
					UIALogger.logMessage("Done loading page");
					return ;
				} 
				else {
					throw new Error("FAILED page load - found error dialog");
				}
			} else {
				UIALogger.logMessage("Status: " + addressBar.value());
			}
			UIATarget.localTarget().delay(1);
		}
		
		throw new Error("FAIL to load page -- Time out");	
	}
	
	// replace this code once <rdar://problem/7626322> is fixed. Implement a withUrl on UIAElementArray,
	// which can be called on links()
	// --------------------------------------------------------------------------------
	//	Function: findLinkOnPage 
	//		Looks for the provided link on the current page
	//
	//	Parameters: 
	//		url (string) - the url of the link to look for
	//		checkForExactMatch (bool) - if true, check for exact match, if false, 
	//			try to find partial match 
	//
	//	Returns: 
	//		True if found, false if not found
	// --------------------------------------------------------------------------------
	safari.findLinkOnPage = function findLinkOnPage(link, checkForExactMatch) {
		if (typeof checkForExactMatch == 'undefined') {
			checkForExactMatch = true;
		}
		var linksArray = this.linksOnActivePage();
		var found = false;
		for (var j=0; j < linksArray.length; j++) {
			//system.println("Link " + j + ": " + linksArray[j]);
			var url = linksArray[j].url();
			if (((checkForExactMatch) && (url == link)) || ((!checkForExactMatch) && (url && url.match(link)))) {
				UIALogger.logMessage("Found the link: " + linksArray[j].name());
				found = true;
				break;
			}
		}
		if (!found) {
			UIALogger.logMessage("Could not find link: '" + link + "'");
			UIALogger.logMessage("Dumping the links that where found on the loaded page.");
			for (var j=0; j < linksArray.length; j++) { UIALogger.logMessage("Link " + j + ": " + linksArray[j].url()) };
		}
		return found;
	}

	
	// --------------------------------------------------------------------------------
	//	Function: tapBookmarksBackButton 
	//		Taps the bookmark back button
	//
	//	Parameters: 
	//		None
	//
	//	Returns: 
	//		None
	//
	//	Throws: 
	//		Error the back button was not tapped successfully 
	// --------------------------------------------------------------------------------
	safari.tapBookmarksBackButton  = function tapBookmarksBackButton() {
		//find the nav bar first
		if (UIATarget.localTarget().model() == 'iPad')
			var navBar = this.mainWindow().popover().navigationBar();
		else
			var navBar = this.navigationBar();
		if (!navBar.isValid()) throw new Error("Could not find the nav bar");
		
		var backButton = navBar.leftButton();
		navBar.logElementTree();
		if (!backButton.isValid()) throw new Error("Could not find a back button");
		backButton.tap();
		UIATarget.localTarget().delay(1);
	}

	// --------------------------------------------------------------------------------
	//	Function: returnToFirstBookmarkPage 
	//		Returns to the first bookmark folder page
	//
	//	Parameters: 
	//		None
	//
	//	Returns: 
	//		None
	//
	//	Throws: 
	//		Error 
	// --------------------------------------------------------------------------------
	safari.returnToFirstBookmarkPage = function returnToFirstBookmarkPage() {
		var limit = 5;
		if (UIATarget.localTarget().model() == 'iPad')
			var navBar = this.mainWindow().popover().navigationBar();
		else
			var navBar = this.navigationBar();
		var returnedToFirstPage = false;
		
		// return to the first bookmarks page
		for(var x = 0; x < limit; x++) {
			// check to see that we have an Edit and a History button
			if (navBar.withName("Bookmarks").isValid()) {
				UIALogger.logMessage("Returned to top page");
				returnedToFirstPage = true;
				break;
			}
			try {
				this.tapBookmarksBackButton();
			} catch(e) {
				UIALogger.logError(e.message);
				throw new Error("Could not select the back button on the bookmark page");
			}
			UIATarget.localTarget().delay(0.5);
		}
		
		if (!returnedToFirstPage) throw new Error("Did not return to the first bookmark page");
	}
	
	
	safari.getWebpageName = function getWebpageName() {
		return this.mainWindow().elements()[7].name();
	}
	
	//	----------------------------------------------------------------------------------------------------------------------
	//	Function: getCurrentView 
	//		Returns a name for the current page you are on within safari
	//
	//	Parameters:
	//
	//	Returns:
	//	 (string) - returns a string of the name of the view. If no matching view is found, it returns null.
	//
	//	Notes:
	//		Here are the possible results returned:
	//			- "WebpageView" - the webpage view
	//			- "BookmarkFolderView" - a list of bookmarks. 
	//			- "BookmarkListEditView" - a list of bookmarks after hitting the 'Edit button. 
	//			- "BoomarkEditView" - this view comes up after hitting 'Edit' button, and selecting a bookmark. 
	//			- "FolderEditView" - this view comes up after hitting 'Edit' button, and selecting a bookmark folder, or selecting the 'New 
	//				Folder' option. 
	//			- "TabView" - the tabbed view. 
	//			- "AddBookmarkView" - this view comes up after hitting the '+' button, and then selecting 'Add Bookmark'. 
	//			- "AddBookmarkPopupView" - this view comes up after tapping the '+' button. 
	//			- "AddToHomeView" - this view comes up after hitting the '+' button, and then selecting 'Add to Home Screen'. 
	//			- "AddressBarTextFieldView" - this view comes up when the url or google search text field is tapped. 
	//			- "VideoView" - this view comes up when a quicktime movie is played in full-screen. 
	//			- "MailComposeView" - the email compose view (for sending the links)
	//			- "PrinterOptionsView" - the printer options view
	//			- "PrinterListView" - the view that comes up when selecting a printer from a list
	//			- "LinkOptionsActionSheetView" - the view with the action sheet that comes up when touch and holding on a link
	//	----------------------------------------------------------------------------------------------------------------------
	safari.getCurrentView = function getCurrentView() {
		UIALogger.logMessage("Getting current view...");
		
		UIATarget.localTarget().pushTimeout(0);
		
		if (UIATarget.localTarget().model() == 'iPad')
			var navBar = this.mainWindow().popover().navigationBar();
		else
			var navBar = this.navigationBar();
		if (navBar.isValid()) {			
			//BoomarkEditView 
			if (navBar.name() == "Edit Bookmark") {
				UIALogger.logMessage("In BoomarkEditView");
				UIATarget.localTarget().popTimeout();
				return "BoomarkEditView";
			}
			
			//FolderEditView
			if (navBar.name() == "Edit Folder") {
				UIALogger.logMessage("In FolderEditView");
				UIATarget.localTarget().popTimeout();
				return "FolderEditView";
			}

			//AddToHomeView
			if (navBar.name() == "Add to Home") {
				UIALogger.logMessage("In AddToHomeView");
				UIATarget.localTarget().popTimeout();
				return "AddToHomeView";
			}
			
			//AddBookmarkView
			if (navBar.name() == "Add Bookmark") {
				UIALogger.logMessage("In AddBookmarkView");
				UIATarget.localTarget().popTimeout();
				return "AddBookmarkView"
			}
			
			if (navBar.name() == "Printer") {
				UIALogger.logMessage("In PrinterListView");
				UIATarget.localTarget().popTimeout();
				return "PrinterListView"
			}
			
			if (navBar.name() == "Printer Options") {
				UIALogger.logMessage("In PrinterOptionsView");
				UIATarget.localTarget().popTimeout();
				return "PrinterOptionsView"
			}
			
			if (UIATarget.localTarget().model() == 'iPad')
				var hasATable = this.mainWindow().popover().tableViews()[0].isValid();
			else
				var hasATable = this.mainWindow().tableViews()[0].isValid();
			if (hasATable) {
				if (UIATarget.localTarget().model() == 'iPad')
					var isInFolderView = navBar.rightButton().withPredicate("name == 'Edit' or name == 'Clear History'").isValid() || (navBar.name() == "Reading List");
				else
					var isInFolderView = navBar.rightButton().withName("Done").isValid();

				if (isInFolderView) {
					//BookmarkFolderView
					UIALogger.logMessage("In BookmarkFolderView");
					UIATarget.localTarget().popTimeout();
					return "BookmarkFolderView"				
				} else {
					//BookmarkListEditView
					UIALogger.logMessage("In BookmarkListEditView");
					UIATarget.localTarget().popTimeout();
					return "BookmarkListEditView";
				}
			}
		}
		
		//AddBookmarkPopupView
	
		var actionSheet;
		if (UIATarget.localTarget().model() == 'iPad') 
			actionSheet = this.mainWindow().popover().actionSheet();
		else
			actionSheet = this.actionSheet();
		if (actionSheet.isValid()) {
			if (actionSheet.buttons()["Add Bookmark"].isValid()) {
				UIALogger.logMessage("In AddBookmarkPopupView");
				UIATarget.localTarget().popTimeout();
				return "AddBookmarkPopupView"; 
			}
            
			if (actionSheet.buttons()["Open"].isValid()) {
				UIALogger.logMessage("In LinkOptionsActionSheetView");
				UIATarget.localTarget().popTimeout();
				return "LinkOptionsActionSheetView"; 
			}
		}
	
		//MailComposeView
		if (this.isDisplayingEmailComposeSheet()) {
			UIALogger.logMessage("In MailComposeView");
			UIATarget.localTarget().popTimeout();
			return "MailComposeView"		
		}

		//VideoView
		if (this.isInVideoView()) {
			UIALogger.logMessage("In VideoView");
			UIATarget.localTarget().popTimeout();
			return "VideoView"
		}
		
		//TabView
		if (UIATarget.localTarget().model() == 'iPad') 
			var isInTabView = this.mainWindow().buttons()["New Page"].isValid();
		else
			var isInTabView = this.mainWindow().pageIndicators()[0].isValid();

		if (isInTabView) {
			UIALogger.logMessage("In TabView");
			UIATarget.localTarget().popTimeout();
			return "TabView";
		}

		//AddressBarTextFieldView
		var searchBar = this.mainWindow().searchBars()[0];
		var addressBar = this.addressBar();
		if ((searchBar.isValid() && searchBar.hasKeyboardFocus()) || 
			(addressBar.isVisible() && addressBar.hasKeyboardFocus())) {
			UIALogger.logMessage("In AddressBarTextFieldView");
			UIATarget.localTarget().popTimeout();
			return "AddressBarTextFieldView";
		}
		
		//WebpageView
		UIATarget.localTarget().pushTimeout(5); //give this full 5 seconds since this is the last chance to find a matching view
		var webView = this.mainWindow().scrollViews()[0].webViews()[0];
		UIATarget.localTarget().popTimeout();
		if (webView.isValid()) {
			UIALogger.logMessage("In WebpageView");
			UIATarget.localTarget().popTimeout();
			return "WebpageView";
		} else {
			//check if it is a PDF document
			if (this.mainWindow().scrollViews()[0].isValid() &&
			this.mainWindow().toolbars().firstWithPredicate("ANY buttons.name contains 'Open in'").isValid()) {
				UIALogger.logMessage("In WebpageView");
				UIATarget.localTarget().popTimeout();
				return "WebpageView";
			}
		}
		
		UIALogger.logError("The view does not match any of the existing ones");
		UIATarget.localTarget().popTimeout();

		UIATarget.localTarget().frontMostApp().mainWindow().logElementTree();
		return null;
	}
	
	//	----------------------------------------------------------------------------------------------------------------------
	//	Function: getToWebpageView 
	//		Goes to the webpage view
	//
	//	Parameters:
	//		None
	//
	//	Returns:
	//	 None
	//
	//	Throws: Error
	//	----------------------------------------------------------------------------------------------------------------------
	safari.getToWebpageView = function getToWebpageView() {
		
		UIALogger.logMessage("Going to webpage view");
		
		this.launchIfNotActive();		
		//this.statusBar().tap();
		
		var currentPage = this.getCurrentView();
		if (!currentPage) {
			throw new Error("Could not find the current view");
		}
		
		UIALogger.logMessage("The current view is: " + currentPage);
		switch (currentPage) {
			case 'WebpageView':
				return ;
			case 'MailComposeView':
				this.navigationBar().buttons()["Cancel"].tap();
				UIATarget.localTarget().delay(1);
				this.actionSheet().buttons()["Delete"].tap();
				break;
			case 'VideoView':
				this.verifyMediaIsPlaying({controlQuery:"Done"});
				break;
			default: 
				if (UIATarget.localTarget().model() == 'iPad') {
					switch (currentPage) {
						case 'AddBookmarkView':
						case 'AddToHomeView':
							this.mainWindow().popover().navigationBar().buttons()["Cancel"].tap();
							break;
						case 'TabView':
							this.mainWindow().buttons()["New Page"].tap();
							//this goes to the AddressBarTextFieldView, so need to deal with this...
							var dismissKeyboardButton = this.keyboard().buttons()["Hide keyboard"];
							UIATarget.localTarget().delay(1); //give it a second to settle down
							dismissKeyboardButton.tap();
							break;
						case 'LinkOptionsActionSheetView':
						case 'AddBookmarkPopupView':
						case 'BookmarkFolderView':
						case 'PrinterOptionsView':
						case 'PrinterListView':
							this.mainWindow().popover().dismiss();
							break;
						case 'BookmarkListEditView':
							this.mainWindow().popover().toolbar().buttons().firstWithName("Done").tap();
							UIATarget.localTarget().delay(1);
							this.mainWindow().popover().dismiss();
							break;
						case 'BoomarkEditView':
							this.mainWindow().popover().navigationBar().leftButton().tap();
							UIATarget.localTarget().delay(1);
							this.mainWindow().popover().toolbar().buttons().firstWithName("Done").tap();
							UIATarget.localTarget().delay(1);
							this.mainWindow().popover().dismiss();
							break;
						case 'FolderEditView':
							this.mainWindow().popover().navigationBar().leftButton().tap();
							UIATarget.localTarget().delay(1);
							this.mainWindow().popover().toolbar().buttons().firstWithName("Done").tap();
							UIATarget.localTarget().delay(1);
							this.mainWindow().popover().dismiss();
							break;
						case 'AddressBarTextFieldView':
							this.keyboard().buttons()["Hide keyboard"].tap();
							break;
					}
				} else {
					switch (currentPage) {
						case 'AddBookmarkView':
						case 'AddToHomeView':
						case 'PrinterOptionsView':
							this.navigationBar().buttons()["Cancel"].tap();
							break;
						case 'TabView':
							this.toolbar().buttons().withName("Done")[0].tap();
							break;
						case 'BookmarkFolderView':
							this.navigationBar().buttons().firstWithName("Done").tap();
							break;
						case 'BookmarkListEditView':
							this.toolbar().buttons().firstWithName("Done").tap();
							UIATarget.localTarget().delay(1);
							this.navigationBar().buttons().firstWithName("Done").tap();
							break;
						case 'BoomarkEditView':
							this.navigationBar().leftButton().tap();
							UIATarget.localTarget().delay(1);
							this.toolbar().buttons().firstWithName("Done").tap();
							UIATarget.localTarget().delay(1);
							this.navigationBar().buttons().firstWithName("Done").tap();
							break;
						case 'FolderEditView':
							this.navigationBar().leftButton().tap();
							UIATarget.localTarget().delay(1);
							this.toolbar().buttons().firstWithName("Done").tap();
							UIATarget.localTarget().delay(1);
							this.navigationBar().buttons().firstWithName("Done").tap();
							break;
						case 'AddressBarTextFieldView':
							this.mainWindow().buttons()["Cancel"].tap();
							break;
						case 'LinkOptionsActionSheetView':
						case 'AddBookmarkPopupView':
							this.actionSheet().buttons()["Cancel"].tap();
							break;
						case 'PrinterListView':
							this.navigationBar().leftButton().tap();
							UIATarget.localTarget().delay(1);
							this.navigationBar().buttons()["Cancel"].tap();
							break;
					}
				}
		}
		
		UIATarget.localTarget().delay(2);
		currentPage = safari.getCurrentView();
		
		if (currentPage != 'WebpageView') {
			UIALogger.logError("Still in " + currentPage);
			throw new Error("Could not get to the main webpage view");
		}
		
		UIALogger.logMessage("In WebPageView");
	}
	
	safari.reset = function reset() {
		try {
			this.getToWebpageView();
		} catch(e) {
			UIALogger.logError("Encountered Error: " + e.message);
		}
	}
	
	//----------------------------------------------------------------------------------------
	//	Function: getToBookmarksView 
	//		Gets to the bookmark list
	//
	//	Parameters:  
	//		options - a hash of optional arguments
	//
	//	Optional Parameters:
	//		elementEvalString (string) - an eval string corresponding to an element that needs to be 
	//			tapped. By default, no element is tapped.
	//
	//	Returns:
	//		None
	//
	//	Throws: 
	//		Error
	//----------------------------------------------------------------------------------------
	safari.getToBookmarksView = function getToBookmarksView(options) {
		
		if (!options) options = new Object();
		
		this.reset();
		UIATarget.localTarget().delay(1);
		
		UIALogger.logMessage("Going to the bookmarks list view");
		try {
			var bookmarkElement = this.visibleElementsWithName(this.toolbar(), "Bookmarks")[0];
		} catch(e) {
			UIALogger.logError(e.message);
			throw new Error("Could not tap the Add Bookmark button");
		}
		bookmarkElement.tap();
		UIATarget.localTarget().delay(1);
		
		UIALogger.logMessage("Going to the first bookmark page");
		try {
			safari.returnToFirstBookmarkPage();
		} catch(e) {
			UIALogger.logError(e.message);
			throw new Error("Could not get to the first bookmark page");
		}
		UIATarget.localTarget().delay(1);

		if (options.elementEvalString) {
			UIALogger.logMessage("Tapping the element with eval string '" + options.elementEvalString + "'");
			var elem = eval(options.elementEvalString);
			if (!elem.isValid()) {
				throw new Error("Could not tap the element " + options.elementEvalString);
			}
			elem.tap();
			UIATarget.localTarget().delay(1.5);
		}
	}
	
	//----------------------------------------------------------------------------------------
	//	Function: getToAddBookmarkView 
	//		Gets to the add bookmark view
	//
	//	Parameters:  
	//		options - a hash of optional arguments
	//
	//	Optional Parameters:
	//		alertButton (string) - the element to tap once the action sheet comes up. By default, 
	//			the 'Add Bookmark' is chosen.
	//
	//	Returns:
	//		None
	//
	//	Throws: 
	//		Error
	//----------------------------------------------------------------------------------------
	safari.getToAddBookmarkView = function getToAddBookmarkView(options) {
		
		if (!options) options = new Object();
		if (!options.alertButton) options.alertButton = "Add Bookmark";
		
		this.reset();
		
		UIALogger.logMessage("Now going to the add bookmark view...");
		try {
			var addBookmarkElement = this.visibleElementsWithName(this.toolbar(), "Utilities")[0];
		} catch(e) {
			UIALogger.logError(e.message);
			throw new Error("Cannot tap '+' button.");
		}
		addBookmarkElement.tap();

		if (UIATarget.localTarget().model() == 'iPad') {
			var actionSheet = this.mainWindow().popover().actionSheet();
		} else {
			var actionSheet = this.actionSheet();	
		}
		
		if (!actionSheet.isValid()) {
			throw new Error("The action sheet with the three part button never showed up.");
		}
		UIATarget.localTarget().delay(1);
		var alertButton = actionSheet.buttons().firstWithPredicate("name == '" + options.alertButton + "' and isVisible == 1");
		if (!alertButton.isValid()) {
			UIALogger.logDebug("action sheet button not found -- checking if it is present within a table");
			alertButton = actionSheet.tableViews()[0].scrollToElementWithName(options.alertButton);
		}
		alertButton.tap();
		UIATarget.localTarget().delay(2);
	}
	
	//----------------------------------------------------------------------------------------
	//	Function: deleteBookmark 
	//		Deletes the specified bookmark
	//
	//	Parameters:  
	//		bookmarkName (string) - the bookmark name
	//
	//	Returns:
	//		None
	//
	//	Throws: 
	//		Error
	//----------------------------------------------------------------------------------------
	safari.deleteBookmark = function deleteBookmark(bookmarkName) {
		
		UIALogger.logMessage("Deleting the bookmark with the name '" + bookmarkName + "'");
		try {
			if (UIATarget.localTarget().model() == 'iPad') 
				this.getToBookmarksView({elementEvalString:"this.mainWindow().popover().navigationBar().buttons()[\"Edit\"]"});
			else
				this.getToBookmarksView({elementEvalString:"this.toolbar().buttons()[\"Edit\"]"});

		} catch(e) {
			UIALogger.logError("Encountered an error: " + e.message);
			throw new Error("Could not navigate to the bookmarks list, and select 'Edit'");
		}
		
		try {
			var bookmarkElement = this.scrollToBookmarkWithName(bookmarkName);
		} catch(e) {
			UIALogger.logError(e.message);
			throw new Error("Could not scroll to the bookmark '" + bookmarkName + "'");
		}
		
		if (!bookmarkElement.isValid()) {
			throw new Error("Could not find the bookmark");
		}
		UIATarget.localTarget().delay(1);

		var editSwitch = bookmarkElement.switches().firstWithName(bookmarkElement.name());
		if (!editSwitch.isValid()) {
			throw new Error("Could not find the '-' button");
		}
		
		editSwitch.setValue("1");
		UIATarget.localTarget().delay(1);
		
		var confirmDeleteButton = bookmarkElement.buttons().firstWithPredicate("name matches 'Confirm Deletion for .*'");
		if (!confirmDeleteButton.isValid()) {
			throw new Error("Could not find the 'Delete' button");
		}
		confirmDeleteButton.tap();
		UIATarget.localTarget().delay(1);
	}

	//----------------------------------------------------------------------------------------
	//	Function: scrollToBookmarkWithName 
	//		Scrolls to the bookmark with the specified name
	//
	//	Parameters:  
	//		bookmarkName (string) - the name of the bookmark to be scrolled to
	//
	//	Returns:
	//		The bookmark element that was scrolled to. Throws Error, if the bookmark was not 
	//		found. 
	//
	//	Throws: 
	//		Error
	//----------------------------------------------------------------------------------------
	safari.scrollToBookmarkWithName = function scrollToBookmarkWithName(bookmarkName) {
		if (UIATarget.localTarget().model() == 'iPad')
			var bookmarkTable = this.mainWindow().popover().tableViews()[0];
		else
			var bookmarkTable = this.mainWindow().tableViews()[0];
		if (!bookmarkTable.isValid()) throw new Error("Could not find the bookmark table");
		UIALogger.logMessage("name matches '.*" + bookmarkName + ".*'");
		var bookmark = bookmarkTable.scrollToElementWithPredicate("name matches '.*" + bookmarkName + ".*'");
		if (!bookmark.isValid()) throw new Error("Could not find '" + bookmarkName + "'");
		return bookmark;
	}
	
	//----------------------------------------------------------------------------------------
	//	Function: selectRandomBookmarkOnPage 
	//		Selects a random bookmark on the bookmark page being displayed. 
	//		If a bookmark folder is chosen, a recursive call is made. 
	//
	//	Parameters:  
	//		None
	//
	//	Returns:
	//		true, if a bookmark was selected. false, if no bookmark could be selected -
	//		because there were no bookmarks. Throws error in all other cases.
	//
	//	Throws: 
	//		Error
	//----------------------------------------------------------------------------------------
	safari.selectRandomBookmarkOnPage = function selectRandomBookmarkOnPage() {
		
		UIALogger.logMessage("Determining the name of the current folder...");
		if (UIATarget.localTarget().model() == 'iPad')
			var bookmarkTableContainer = safari.mainWindow().popover();
		else
			var bookmarkTableContainer = safari.mainWindow();
		var navBar = bookmarkTableContainer.navigationBar();
		if (!navBar.isValid()) throw new Error("Could not find the navigation bar");
		
		var currentFolderName = navBar.name();
		if (!currentFolderName) {
			throw new Error("Could not determine the name of the current folder");
		}
		
		UIALogger.logMessage("Selecting bookmark in the folder " + currentFolderName);
		
		//do not select history -- the bookmark folders within History are not named like other bookmark folders.
		//Makes it harder to predict what view do expect.
		var bookmarkElements = bookmarkTableContainer.tableViews()[0].cells().withPredicate("name != 'History'");
		if (bookmarkElements.length == 0) {
			UIALogger.logMessage("No bookmarks. Should go back");
			safari.tapBookmarksBackButton();
			UIATarget.localTarget().delay(1);
			return false;
		}
		
		UIALogger.logMessage("Number of bookmarks found: " + bookmarkElements.length);
		var indices = UIAUtility.randomIndexArray(bookmarkElements.length); //shuffles the indices
		
		for (var i=0; i<indices.length; i++) {
			var bookmarkElement = bookmarkTableContainer.tableViews()[0].cells().withPredicate("name != 'History'")[(indices[i])];
			UIALogger.logMessage("Going to bookmark " + bookmarkElement.name());
			bookmarkElement.logElement();
			
			try {
				bookmarkElement.scrollToVisible();
			} catch(e) {
				UIALogger.logError(e.message);
				throw new Error("Could not scroll to '" + bookmarkElement.name() + "'");
			}
			var isBookmarkFolder = (bookmarkElement.name().indexOf("Folder") >= 0);
			
			bookmarkElement.tap();
			if (!bookmarkElement.withPredicate("isVisible == 0").isValid()) 
				UIALogger.logWarning("Bookmark table cell " + bookmarkElement.name() + " did not become invisible");
			
			UIATarget.localTarget().delay(2);
			
			var expectedView = (isBookmarkFolder) ? 'BookmarkFolderView' : 'WebpageView';
			if (expectedView == 'BookmarkFolderView') {
				if (!safari.navigationBar().withPredicate("name != '" + currentFolderName + "'").isValid()) 
					UIALogger.logWarning("The nav bar name did not seem to have changed from '" + currentFolderName + "'");
			} else { 
				if (!safari.mainWindow().scrollViews()[0].webViews()[0].isValid())
					UIALogger.logWarning("WebView did not come up");
			}
			var currentView = safari.getCurrentView();
			
			if (currentView != expectedView) {
				throw new Error("Expected to be in " + expectedView + ", but we are in " + currentView);
			}
	
			if (currentView == 'WebpageView') {
				UIALogger.logMessage("Successfully switched to webpage view");
				return true;
			}
			
			
			UIALogger.logMessage("Making sure the folder view actually changed...");
			var newFolderName = navBar.name();
			if (!newFolderName) {
				throw new Error("Could not determine the name of the new folder");
			}
			
			UIALogger.logMessage("New folder name=" + newFolderName + ". Current folder name=" + currentFolderName);
			if (newFolderName == currentFolderName) {
				throw new Error("Tapping on the bookmark folder name '" + currentFolderName + "' did not change the displayed folder name");
			}
			
			//recursive call because went to another folder
			try {
				UIALogger.logMessage("Now in " + bookmarkElement.name() + " folder. Trying again...");
				var result = selectRandomBookmarkOnPage();
				if (result) return true;
			} catch(e) {
				UIALogger.logError("Caught exception: " + e.message);
				throw e;
			}
			
			//now try another random bookmark since the previous one was no good
		}
		
		UIALogger.logMessage("Could not find a bookmark. Going back...");
		safari.tapBookmarksBackButton();
		UIATarget.localTarget().delay(1);
		return false;
	}
	
	//----------------------------------------------------------------------------------------
	//	Function: addBookmark 
	//		Adds a bookmark to the home screen.  No verification performed
	//
	//	Parameters:  
	//		typeOfBookmark (string) - either "bookmark" or "home screen".  If it's bookmark, it 
	//				adds the page to the bookmark list.  If it's home screen, it adds it
	//				to the home screen
	//		bookmarkURL (string) - url to navigate to before creating a bookmark. (optional)
	//				Will create a bookmark for the current page if no url is specified
	//	
	//	Returns:
	//		The name of the bookmark that was created.
	// 
	//	Throws: 
	//		Error
	//----------------------------------------------------------------------------------------
	safari.addBookmark = function addBookmark(typeOfBookmark, bookmarkURL) {
		UIALogger.logMessage("Creating a new bookmark.");
		
		//navigate to the given url only if it's specified
		if (bookmarkURL) {
			try {
				this.loadPageAndWait(bookmarkURL, 120);
			} catch(e) {
				UIALogger.logError(e.message);
				throw new Error("Could not load the specified page.");
			}
		}
				
		if (typeOfBookmark == "bookmark") {
			
			UIALogger.logMessage("Going to the add bookmark view...");
			try {
				this.getToAddBookmarkView();
			} catch(e) {
				UIALogger.logError(e.message);
				throw new Error("Error.  Cannot get to the add bookmark view.");
			}
			UIATarget.localTarget().delay(1);
			
			if (UIATarget.localTarget().model() == 'iPad') {
				bookmarkName = this.mainWindow().popover().tableViews()[0].cells()[0].textFields()[0].value();
				var saveButton = this.mainWindow().popover().navigationBar().buttons()["Save"];
			} else {
				bookmarkName = this.mainWindow().tableViews()[0].cells()[0].textFields()[0].value();
				var saveButton = this.navigationBar().buttons()["Save"];
			}
			if(!saveButton.isValid()) {
				throw new Error("Could not find 'Save'");
			}
			saveButton.tap();
			UIATarget.localTarget().delay(1);
			
		} else if (typeOfBookmark == "home screen") {
			
			UIALogger.logMessage("Going to the add to home screen view...");
			try {
				this.getToAddBookmarkView({alertButton:"Add to Home Screen"});
			} catch(e) {
				UIALogger.logError(e.message);
				throw new Error("Error.  Cannot get to the add to home screen view.");
			}
			UIATarget.localTarget().delay(1);
			
			if (UIATarget.localTarget().model() == 'iPad') {
				bookmarkName = this.mainWindow().popover().tableViews()[0].cells()[0].textFields()[0].value();	
				// wait for the add to home animation
				var addButton = this.mainWindow().popover().navigationBar().buttons()["Add"];
			} else {
				bookmarkName = this.mainWindow().tableViews()[0].cells()[0].textFields()[0].value();	
				// wait for the add to home animation
				var addButton = this.navigationBar().buttons()["Add"];
			}
			if(!addButton.isValid()) {
				throw new Error("Could not find 'Add'");
			}
			addButton.tap();
			
			// wait for safari to suspend and the icon to show up
			this.waitForInvalid();
			springboard.mainWindow().elements()[bookmarkName];
		} else {
			throw new Error("Bookmark type not specified.");
		}
		
		UIALogger.logMessage("Created bookmark " + bookmarkName + ".");
		return bookmarkName;
	}
	
	//----------------------------------------------------------------------------------------
	//	Function: openNewTab 
	//		Selects 'New Page' to open a new tab
	//
	//	Parameters:  
	//		None
	//
	//	Returns:
	//		None
	//
	//	Throws: 
	//		Error
	//----------------------------------------------------------------------------------------
	safari.openNewTab = function openNewTab() {
		
		UIALogger.logMessage("Opening a new tab");
		
		var toolbar = this.toolbar();
		if (!toolbar.isValid()) throw new Error("Could not find the toolbar");
		
        if (UIATarget.localTarget().model() == 'iPad') {
            this.mainWindow().buttons()["New tab"].tap();
        } else {
            try {
                var tabButton = this.visibleElementsWithName(this.toolbar(), "Pages")[0];
            } catch(e) {
                UIALogger.logError(e.message);
                throw new Error("Could not find the nav tab button");
            }
            tabButton.tap();
            UIATarget.localTarget().delay(2);
            try {
                var newPageButton = this.visibleElementsWithName(toolbar, "New Page")[0];
                newPageButton.tap();
                UIATarget.localTarget().delay(2);
            } catch(e) {
                UIALogger.logError(e.message);
                throw new Error("Could not tap the 'New Page' button");

            }
        }

		this.reset(); //get out of the address bar text field view
	}
	
	//----------------------------------------------------------------------------------------
	//	Function: openNewTabWithWebPage 
	//		Loads a webpage in a new tab
	//
	//	Parameters:  
	//		webPage (string) - the url of the webpage to be loaded
	//		timeout (int) - optional - the number of seconds to wait for the page to load. If 
	//			no timeout is specified, the function does not wait for the page to load.
	//
	//	Returns:
	//		None
	//
	//	Throws: 
	//		Error
	//----------------------------------------------------------------------------------------
	safari.openNewTabWithWebPage = function openNewTabWithWebPage(webPage, timeout) {
		
		UIALogger.logMessage("Opening " + webPage + " in a new tab");
		
		try {
			this.openNewTab();
		} catch(e) {
			UIALogger.logError(e.message);
			throw new Error("Could not open a new tab");
		}
		
		if (timeout) {
			UIALogger.logMessage("Loading and waiting for webpage: " + webPage);
			try { 
				this.loadPageAndWait(webPage, 240);
			} catch(e) {
				UIALogger.logError(e.message);
				throw new Error("Could not load page " + webPage);
			}
		} else {
			var date = new Date();
			UIALogger.logMessage("Loading webpage: " + webPage);
			this.loadURL(webPage);
			try {
				this.checkForPageLoadErrorSinceDate(date);
			} catch(e) {
				UIALogger.logError(e.message);
				throw new Error("Could not load page " + webPage);
			}
		}
	}

	//----------------------------------------------------------------------------------------
	//	Function: goToTab 
	//		Navigates to the tab with the specified index
	//
	//	Parameters:  
	//		tabIndex (int) - the index of the tab (the 1st tab will have index 0, etc.)
	//
	//	Returns:
	//		The tab element. If the tab element is not found, an error is thrown. 
	//
	//	Throws: 
	//		Error
	//----------------------------------------------------------------------------------------
	safari.goToTab = function goToTab(tabIndex) {
		if (UIATarget.localTarget().model() == 'iPad') {
			var tabs = this.mainWindow().elements().withPredicate("name endswith ', Tab'");
			if (tabs.length <= tabIndex) throw new Error("Invalid tab index: " + tabIndex + ". " + tabs.length + " tabs exist");
			var tab = tabs[tabIndex];
		} else {
			var pageIndicator = this.mainWindow().pageIndicators()[0];
			if (!pageIndicator.isValid()) throw new Error("Could not find the page indicator");
			UIALogger.logMessage("Currently on " + pageIndicator.pageIndex() + " page. Need to go to " + tabIndex + " page")
			pageIndicator.selectPage(tabIndex);
		
			var tabs = this.visibleElementsWithPredicate(this.mainWindow().scrollViews()[0], "hint == 'Opens the web page'");
			UIALogger.logMessage("Found " + tabs.length + " tabs. ");
			var tab = tabs[0];
		}
		if (!tab.isValid()) throw new Error("Did not find the tab");
		return tab;
	}

    //----------------------------------------------------------------------------------------
	//	Function: tabWithName 
	//		Returns the element for tab with the specified name
	//
	//	Parameters:  
	//		name (string) - the label that appears on (or below) the tab element
	//
	//	Returns:
	//		The tab element
	//----------------------------------------------------------------------------------------
    safari.tabWithName = function tabWithName(name) {
        if (UIATarget.localTarget().model() == 'iPad') {
            return safari.mainWindow().elements().firstWithName(name + ", Tab");
        } else {
            return safari.mainWindow().elements()[name];
        }
    }
	//----------------------------------------------------------------------------------------
	//	Function: closeTab 
	//		Closes a tab
	//
	//	Parameters:  
	//		None
	//
	//	Optional Parameters:
	//		tabLabel (string) - the label of the tab. This parameter is only used on iPad devices.
	//			If no value is specified, the first tab is closed. 
	//
	//	Returns:
	//		None
	//
	//	Throws: 
	//		Error
	//----------------------------------------------------------------------------------------
	safari.closeTab = function closeTab(options) {
		if (!options) options = new Options();

		if (UIATarget.localTarget().model() == 'iPad') {
			var closeTabButtons = this.mainWindow().buttons().withPredicate("name beginswith 'Close tab'");
			if (options.tabLabel) {
				UIALogger.logDebug("Need to close tab with label '" + options.tabLabel + "'");
				var tabs = closeTabButtons.withPredicate("name contains '" + options.tabLabel + "'");
				if (tabs.length == 0) {
					UIALogger.logDebug("No tabs to close");
					return ;
				}
			} 
            var closeTabButton = closeTabButtons[0];
		} else {
            var currentView = this.getCurrentView();
            if (currentView != 'TabView')  {
                UIALogger.logMessage("Not in the TabView currently -- need to navigate to it");
                this.visibleElementsWithName(this.toolbar(), "Pages")[0].tap();
                
                currentView = this.getCurrentView();
                if (currentView != 'TabView') throw new Error("Could not get to the tab view");
            }
            
			var pageIndicator = this.mainWindow().pageIndicators()[0];
			UIALogger.logMessage("Closing the " + pageIndicator.pageIndex() + "th tab");
			var closeTabButton = this.visibleElementsWithName(this.mainWindow().scrollViews()[0], "Close page")[0];
			if (!closeTabButton.isValid()) {
				//check whether it is expected to have a close button
				if (pageIndicator.pageCount() == 1 && this.mainWindow().staticTexts()["Untitled"].isValid()) {
					UIALogger.logMessage("No tabs to close");
					return ;
				}
				throw new Error("Could not find the close tab button");
			}
		}
		closeTabButton.tap();
		UIATarget.localTarget().delay(1);
	}

	//----------------------------------------------------------------------------------------
	//	Function: closeAllTabs 
	//		Closes all tabs
	//
	//	Parameters:  
	//		None
	//
	//	Returns:
	//		None
	//
	//	Throws: 
	//		Error
	//----------------------------------------------------------------------------------------
	safari.closeAllTabs = function closeAllTabs() {
		
		UIALogger.logMessage("Closing all tabs...");
		var currentView = this.getCurrentView();
		
		if (UIATarget.localTarget().model() == 'iPad')
			var tabCount = this.mainWindow().staticTexts().withPredicate("name endswith 'Tab' and not name contains 'Untitled'").length;
		else {
            if (currentView != 'TabView') {
                // click the nav button to bring up tab view 
                var tabButton = this.visibleElementsWithName(this.toolbar(), "Pages")[0];
                tabButton.tap();
                UIATarget.localTarget().delay(1);
            }
			var tabCount = this.mainWindow().pageIndicators()[0].pageCount();
        }
		
		UIALogger.logDebug("Number of tabs to close is " + tabCount);
		
		for (var i=0; i<tabCount; i++) {
			this.closeTab();
			UIATarget.localTarget().delay(2);
		}
		
		UIATarget.localTarget().delay(2);

		this.reset();  // get us back out of tab view
	}

	//----------------------------------------------------------------------------------------
	//	Function: clearHistory 
	//		Goes to the the 'History' view, and clears it
	//
	//	Parameters:  
	//		None
	//
	//	Returns:
	//		None
	//
	//	Throws: 
	//		Error
	//----------------------------------------------------------------------------------------
	safari.clearHistory = function clearHistory() {
		UIALogger.logDebug("Clearing history");
		safari.getToBookmarksView();
		safari.scrollToBookmarkWithName("History").tap();
		var confirmDeletionActionSheet;
		if (UIATarget.localTarget().model() == 'iPad') {
			safari.mainWindow().popover().navigationBar().buttons()["Clear History"].tap();
			confirmDeletionActionSheet = safari.mainWindow().popover().actionSheet()
		} else {
			safari.toolbar().buttons()["Clear"].tap();
			confirmDeletionActionSheet = safari.actionSheet();
		}
		
		if (confirmDeletionActionSheet.isValid()) {
			UIALogger.logDebug("Got confirm 'Clear History' action sheet");
			confirmDeletionActionSheet.buttons()["Clear History"].tap();
		}
	}
	//----------------------------------------------------------------------------------------
	//	Function: mailLinkToPage 
	//		Emails a link to active page
	//
	//	Parameters:  
	//		toAddress (string) - Recipient of the email
	//
	//	Optional Parameters:
	//		subject (string) - the subject of the email
	//
	//	Returns:
	//		None
	//
	//	Throws: 
	//		Error
	//----------------------------------------------------------------------------------------
	safari.mailLinkToPage = function mailLinkToPage(toAddress, options) {
		
		if (!options) options = new Object();
		
		UIALogger.logDebug("Selecting the 'Mail Link to this Page' option");
		this.getToAddBookmarkView({alertButton:"Mail Link to this Page"});
		
		if (!this.isDisplayingEmailComposeSheet()) {
			throw new Error("Selected email link, but email compose sheet did not come up");
		}
				
		var email = new Object();
		email.to = toAddress;
		if (options.subject) email.subject = options.subject;
		this.composeEmail(email);
		
		UIALogger.logMessage("Sending email to '" + email.to + "'.");
		this.mainWindow().navigationBar().buttons()["Send"].tap();
	}
	
	//----------------------------------------------------------------------------------------
	//	Function: tapRefreshButton 
	//		Taps the refresh button
	//
	//	Parameters:  
	//		None
	//
	//	Returns:
	//		None
	//
	//	Throws: 
	//		Error
	//----------------------------------------------------------------------------------------
	safari.tapRefreshButton = function tapRefreshButton() {
		var refreshButton = this.mainWindow().buttons()["reload"];
		if (!refreshButton.isValid()) throw new Error("Could not find the refresh button");
		refreshButton.scrollToVisible(); //sometimes it is hidden
		UIATarget.localTarget().delay(1);
		refreshButton.tap();
	}
	
	// --------------------------------------------------------------------------------
	//	Function: scrollToLink 
	//		Scroll through the webpage being displayed to find the specified link. 
	//		Note that this function does NOT use the scrollToVisible AX action. 
	//
	//	Parameters:
	//		identifier (string|UIAPredicateString) - either the name of the link (in 
	//			which case the specified value should be a string), or a predicate 
	//			string (in which case the specified should be UIAPredicateString)
	//	Returns:
	//		None
	// --------------------------------------------------------------------------------
	safari.scrollToLink = function scrollToLink(identifier) {
		var webDocumentArea = safari.getSafeWebDocumentView();
		webDocumentArea.center = new Object();
		webDocumentArea.center.x = webDocumentArea.origin.x + 0.5*webDocumentArea.size.width;
		webDocumentArea.center.y = webDocumentArea.origin.y  + 0.5*webDocumentArea.size.height;
		
		//values for scrolling
		var offset = 10;
		webDocumentArea.minX = webDocumentArea.origin.x + offset;
		webDocumentArea.maxX = webDocumentArea.origin.x + webDocumentArea.size.width - offset;
		webDocumentArea.minY = webDocumentArea.origin.y + offset;
		webDocumentArea.maxY = webDocumentArea.origin.y + webDocumentArea.size.height - offset;
		
		var linkElement;
		if (identifier instanceof UIAPredicateString)
			linkElement = this.mainWindow().scrollViews()[0].webViews()[0].links().firstWithPredicate(identifier);
		else 
			linkElement = this.mainWindow().scrollViews()[0].webViews()[0].links()[identifier];
		
		for (var i=0; i<15; i++) {
			if (!linkElement.checkIsValid()) throw new Error("Could not find the link with identifier " + identifier);
			
			if (linkElement.isVisible()) {
				UIALogger.logDebug("Link is already visible");
				return ;
			}
			
			var linkCenter = new Object();
			linkCenter.x = linkElement.rect().origin.x + 0.5*linkElement.rect().size.width
			linkCenter.y = linkElement.rect().origin.y + 0.5*linkElement.rect().size.height;
			
			var fromPosition = new Object();
			var toPosition = new Object();
			if (linkCenter.x < webDocumentArea.origin.x) {
				//drag from left to right
				fromPosition.x = webDocumentArea.minX;
				toPosition.x = webDocumentArea.maxX;
			} else if (linkCenter.x > (webDocumentArea.origin.x + webDocumentArea.size.width)) {
				//drag from right to left
				fromPosition.x = webDocumentArea.maxX;
				toPosition.x = webDocumentArea.minX;
			} else {
				//in the middle somewhere
				toPosition.x = linkCenter.x;
				fromPosition.x = linkCenter.x;
			}
			
			if (linkCenter.y < webDocumentArea.origin.y) {
				//drag from top to bottom
				fromPosition.y = webDocumentArea.minY;
				toPosition.y = webDocumentArea.maxY;
			} else if (linkCenter.y > (webDocumentArea.origin.y + webDocumentArea.size.height)) {
				//drag from bottom to top
				fromPosition.y = webDocumentArea.maxY;
				toPosition.y = webDocumentArea.minY;
			} else {
				//in the middle somewhere
				toPosition.y = linkCenter.y;
				fromPosition.y = linkCenter.y;
			}
			
			UIALogger.logDebug("Scrolling " + (i+1) + "th time");
			UIALogger.logDebug("From: x: " + fromPosition.x + " y: " + fromPosition.y);
			UIALogger.logDebug("To x: " + toPosition.x + " y: " + toPosition.y);
			UIATarget.localTarget().dragFromToForDuration(fromPosition, toPosition, 1);
			UIATarget.localTarget().delay(1);
		}
		if (!linkElement.isVisible()) throw new Error("Could not scroll to the link");
	}
	
	//----------------------------------------------------------------------------------------
	//	Function: getSafeWebDocumentView 
	//		This will return a rect object corresponding to the the visible Web Document
	//		Area it will exclude the address bar if it is present.
	//
	//	Parameters:  
	//		options (Object) - dictionary of optional arguments
	//
	//	Optional parameters:
	//		excludeEdges (boolean) - if set to true, the rect will exclude the edges of the view
	//			so that is safe to call drag, etc. on any point in the rect . It is set to false 
	//			by default. 
	//
	//	Returns:
	//		The rect object corresponding to the web document area.
	//
	//	Throws: 
	//		Error
	//----------------------------------------------------------------------------------------
	safari.getSafeWebDocumentView = function getSafeWebDocumentView(options) {
		//TODO: should use contentArea once <rdar://problem/8119100> is fixed
		
		if (!options) options = new Object();
        
		var webView = this.mainWindow().scrollViews()[0].webViews()[0];
		if (!webView.isValid()) throw new Error("Could not find the web view");
		var statusbar = this.statusBar();
		if (!statusbar.isValid()) throw new Error("Could not find the status bar");
		
		//if the status bar is scrolled out of view, don't exempt the addressbar area
		var y = webView.rect().origin.y;
		var statusHeight = statusbar.rect().size.height;
		if (y <= statusHeight) {
			y = statusHeight;
		}
		
		var x = Math.max(webView.rect().origin.x, this.rect().origin.x);
		var minMaxX = Math.min(webView.rect().origin.x + webView.rect().size.width, this.rect().origin.x + this.rect().size.width)
		var width = minMaxX - x;
		
		var toolbar = this.toolbar();
		if (!toolbar.isValid()) throw new Error("Could not find the toolbar");
		var isAtBottom = (toolbar.rect().origin.y + toolbar.rect().size.height) == (this.rect().origin.y + this.rect().size.height);
		if (isAtBottom) {
			var height = toolbar.rect().origin.y - y;
		} else {
			y = toolbar.rect().origin.y + toolbar.rect().size.height;
			var height = this.rect().origin.y + this.rect().size.height - y;
		}
		
		if (options.excludeEdges) {
			x++;
			y++;
			width -= 2;
			height -= 2
		}
		UIALogger.logMessage("x:" + x + " y:" + y + " width:" + width + " height:" + height);
		return ({origin:{x:x, y:y}, size:{width:width, height:height}});
	}
	
	safari.crawlWeb = function crawlWeb (startPage, pages, zoomAndScroll) {
		
		var pageStack = new Array();
		var currentPage = startPage;
		
		UIALogger.logMessage("Loading initial page...");
		try {
			this.loadPageAndWait(startPage,120);
		} catch(e) {
			UIALogger.logError(e.message);
			throw new Error("Could not load startPage: " + startPage);
		}
		pageStack.push(startPage);
		
		UIALogger.logMessage("Successfully loaded initial page. Now, crawling....");
		var result = true;
		
		for (var page = 0; page < pages; page++) {	
			
			UIALogger.logMessage("Starting out with page " + (page+1));
			this.reset(); //loading the last page might have caused another app to launch
			
			//zoom and scroll around the page
			if (zoomAndScroll) {
				UIALogger.logMessage("Zooming and Scrolling...");
				var addressBar = this.addressBar();
				if (!addressBar.isValid()) UIALogger.logWarning("Could not find the address bar"); 
				addressBar.scrollToVisible(); //make the addressbar come in the view
				UIATarget.localTarget().delay(1);
				try {
					var mainWebView = this.getSafeWebDocumentView({excludeEdges:true});
				} catch(e) {
					UIALogger.logError(e.message);
					throw new Error("Error.  Could not find WebView.");
				}
                
				UIATarget.localTarget().randomDragsOrFlicks(mainWebView);
				UIATarget.localTarget().doubleTapRandomPoint(mainWebView);
				UIATarget.localTarget().delay(2);
				UIATarget.localTarget().randomDragsOrFlicks(mainWebView);
				UIATarget.localTarget().randomPinch(mainWebView);
			}
			
			UIALogger.logMessage("Looking for urls on the page...");
			var urls = new Array();
			var originalLinks = this.linksOnActivePage();
			
			if (originalLinks && originalLinks.length > 0) {
				//some types of links avoid
				var invalidLinkTypes = ["javascript:", "tel:", "youtube.com", "itunes.apple.com"];
				
				for (var i=0; i < originalLinks.length; i++) {
					var invalidLink = false;
					var url = originalLinks[i].url();
					for (var j=0; j < invalidLinkTypes.length; j++) 
						if (url && url.indexOf(invalidLinkTypes[j]) >= 0) {
							invalidLink = true;
							break;
						}	
					if (!invalidLink && url) urls.push(url);
				}
			} 
			
			// allow js to clean up the previous urls
			system.drain();
			
			var backLink = "Previous Page";
			if (pageStack.length > 1) urls.push(backLink); //no back on the first page
			
			var errorMessage = null;
			if (urls.length == 0) {
				errorMessage = "No urls on page: " + currentPage;
			} else {
				UIALogger.logMessage("Number of urls on page " + currentPage + " is " + urls.length);
				
				var linkIndex = system.randomInteger(0, urls.length-1);
				UIALogger.logMessage("Loading index " + linkIndex + " from " + currentPage);
				UIALogger.logMessage("urls[" + linkIndex + "] = " + urls[linkIndex]);
				currentPage = urls[linkIndex];
				
				var date = new Date();
				if (currentPage == backLink) {
					try {
						var backButton = this.visibleElementsWithName(this.toolbar(), "Back")[0];
					} catch(e) {
						UIALogger.logError(e.message);
						throw new Error("Could not find the 'Back' button");
					}
					backButton.tap();
				} else {
					this.loadURL(currentPage);
				}
				// If we fail to load, go back to our last page
				try {
					this.waitForPageToLoad(60, {date:date});
					UIALogger.logMessage("Successfully loaded: " + currentPage);
					pageStack.push(currentPage);
				} catch(e) {
					errorMessage = "Could not loaded the page: " + currentPage;
					result = false;
				}
			} 
			
			//if we could not load the page then we need to go back on page
			if (errorMessage) {
				UIALogger.logMessage(errorMessage + "... so going back...");
				
				do {
					currentPage = pageStack.pop();
					if (!currentPage) {
						throw new Error("No more pages in stack");
					}
					var date = new Date();
					//we selected the back button
					if (currentPage == backLink) {
						try {
							var backButton = this.visibleElementsWithName(this.toolbar(), "Back")[0];
						} catch(e) {
							UIALogger.logError(e.message);
							throw new Error("Could not find the 'Back' button");
						}
						backButton.tap();
					}
					else {
						UIALogger.logMessage("Going back to " + currentPage);
						this.loadURL(currentPage);
					}
					try {
						this.waitForPageToLoad(60, {date:date});
						break;
					} catch(e) {
						UIALogger.logError(e.message);
					}
				} while(true);
				
				pageStack.push(currentPage);
			}
			
			UIALogger.logMessage("Done with page " + (page + 1));
		} //end of for loop
		
		return result;
	}
}
