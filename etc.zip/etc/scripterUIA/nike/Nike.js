/*
 Class: UIApp (nike+)
 Messages object
 */

#import "../libs/SpringBoard.js"
if (system.hasCapability("nike-ipod")) {
	try { if (typeof nike == 'undefined') nike = UIAApp.application("Nike + iPod", "com.apple.nike"); }
	catch (theError) { system.println("WARNING! Failed to create object for Nike : " + theError); }
}


if (typeof nike != 'undefined') {
	// need to keep in sync with <Nike/STNotifications.h>
	nike.notifications = {};
	nike.notifications.NIKE_WORKOUT_DID_START_NOTIFICATION = "SWRunWorkoutControllerWorkoutStartedNotification";
	nike.notifications.NIKE_WORKOUT_DID_FINISH_NOTIFICATION = "SWRunWorkoutControllerWorkoutStoppedNotification";
	nike.notifications.NIKE_WORKOUT_DID_PAUSE_NOTIFICATION = "SWRunWorkoutControllerWorkoutPausedNotification";
	nike.notifications.NIKE_WORKOUT_DID_RESUME_NOTIFICATION = "SWRunWorkoutControllerWorkoutResumedNotification";

	nike.notifications.NIKE_WORKOUT_CANCELLED_NOTIFICATION = "STSportsWorkoutCancelledNotification";
	nike.notifications.NIKE_WORKOUT_GOAL_COMPLETED_NOTIFICATION = "STSportsWorkoutGoalCompletedNotification";

	nike.workoutSummary = {};
	nike.workoutSummary.NIKE_WORKOUT_SUMMARY_TYPE_KEY = "SWWorkoutDataGoalTypeKey";
	nike.workoutSummary.NIKE_WORKOUT_SUMMARY_TIME_KEY = "SWWorkoutDataElapsedTimeInSecondsKey";



	// need to keep in sync with <Nike/STWorkoutTypes.h>
	nike.workoutGoalTypes = {};
	nike.workoutGoalTypes.INACTIVE = -1;
	nike.workoutGoalTypes.BASIC = "SWRunWorkoutControllerGoalTypeNone";
	nike.workoutGoalTypes.TIME = "SWRunWorkoutControllerGoalTypeTimeInSeconds";
	nike.workoutGoalTypes.DISTANCE = "SWRunWorkoutControllerGoalTypeDistanceInMiles";
	nike.workoutGoalTypes.CALORIES = "SWRunWorkoutControllerGoalTypeCalories";

	// --------------------------------------------------------------------------------
	//	Function: convertTextToWorkoutID
	//
	//	Parameters:
	//		text (string) - type of workout (Basic, Time, Distance, Calories)	
	//	
	//  Optional:	
	//
	//	Returns: 
	//		The workout goal type as used by Nike+
	//	
	//	Throws:
	//		Nothing
	// --------------------------------------------------------------------------------	
	nike.convertTextToWorkoutID = function convertTextToWorkoutID(text) {
		switch (text) {
			case "Basic":
				return this.workoutGoalTypes.BASIC;
			case "Time":
				return this.workoutGoalTypes.TIME;
			case "Distance":
				return this.workoutGoalTypes.DISTANCE;
			case "Calorie":
				return this.workoutGoalTypes.CALORIE;
			default:
				UIALogger.logError("Unknown type '" + text + "'.");
				return this.workoutGoalTypes.INACTIVE;
		}
	}

	
	// --------------------------------------------------------------------------------
	//	Function: startWorkout
	//		Start a workout of type workoutType
	//
	//	Parameters:
	//		workoutType (string) - type of workout "Basic", "Time", "Distance", "Calorie"
	//		workoutGoal (string) - Time, Distance, or Calorie goal for workout
	//								If a custom workout is needed, specify the 
	//								custom distance, calories or time.  The specified
	//								value must be *exactly* as it is displayed in the app.
	//								For example, "10.00 km" (not "10.00km")
	//											 "10 minutes" or 
	//
	// Optional:
	//		workoutPlaylist (string) - playlist to choose
	//		weight (string) - weight 
	//
	//	Returns: 
	//		None
	//	
	//	Throws:
	//		A tantrum
	// --------------------------------------------------------------------------------
	nike.startWorkout = function startWorkout(workoutType, workoutGoal, options) {
		
		nike.launchIfNotActive();
		// maximum number of attempts to connect to a sensor if multiple are found
		var maxAttempts = 5;
		
		// Set default options 
		if ( !options ) options = new Object();
		var weight = (options.weight) ? options.weight : "155.0 kg";
		var workoutPlaylist = (options.workoutPlaylist) ? options.workoutPlaylist : "None";
		
		// next, get to the main workout view
		this.returnToWorkoutSelection();
		
		// choose the workoutType
		this.chooseWorkoutType(workoutType);
		
		// if not a basic workout, choose workoutGoal
		if (workoutType != "Basic") this.chooseWorkoutGoal(workoutGoal);
		
		// if a playlist is specified, 
		this.chooseWorkoutMusic(workoutPlaylist);
		
		// if in weight view, enter weight
		if (this.mainWindow().navigationBar().name() == "Weight"){
			this.setPickerWheels(weight);
			this.navigationBar().buttons()["Done"].tap();
		}
		
		// Wait for Sensor view to appear
		UIATarget.localTarget().pushTimeout(60);
		UIALogger.logMessage("Looking for the sensor locating view");
		var sensorView = this.mainWindow().navigationBars().firstWithName("Sensor");
		if (sensorView.isVisible()) {
			UIALogger.logMessage("Sensor view is up.");
		} else {
			this.logElementTree();
			throw new Error("Timed out waiting for sensor to appear");
		}
		UIATarget.localTarget().popTimeout();
		var startTime = new Date();
		if (!sensorView.waitForInvalid()) {
			if (this.mainWindow().elements().firstWithPredicate("ANY elements.name beginswith 'Multiple Sensors Found'").isValid()) {
				UIALogger.logDebug("Multiple sensors found - could not connect with Nike+ sensor");
				throw new Error("Multiple sensors found - could not connect with Nike+ sensor");
			}			
		}			
		
		var totalTime = ((new Date()) - startTime) / 1000;
		
		// Give the sensor a chance to connect
		UIATarget.localTarget().delay(3);
		
		UIALogger.logMessage("Time required to connect with sensor: " + totalTime + " seconds.");
		
		// Look for workoutType + 'Workout' button
		var startButton = this.mainWindow().buttons()[workoutType + " Workout"];
		if (!startButton) throw new Error("Could not find the button to start workout");
		
		// Tap button to start workout
		startButton.tap();
			
		if (!this.isWorkoutActive(workoutType)) throw new Error("Workout has not started.");
		UIALogger.logMessage("Workout has started");
		return;
	} // end nike.startWorkout
	
	
	// --------------------------------------------------------------------------------
	//	Function: pauseWorkout
	//		function to pause a workout
	//
	//	Parameters:
	//		duration (int) - duration of pause.  If no duration is specified, the workout
	//						will be paused indefinitely
	//	
	//	Returns: 
	//		None
	//	
	//	Throws:
	//		An error if the pause button could not be found
	// --------------------------------------------------------------------------------
	nike.pauseWorkout = function pauseWorkout() {

		UIATarget.localTarget().unlockScreenIfNecessary();
		// Look for Pause Workout button
		var pauseButton = this.mainWindow().buttons().firstWithPredicate("name endswith 'Workout'");
		if (pauseButton.isVisible()) pauseButton.tap();
		else throw new Error("Could not find the pause workout button");

		if (duration) {
			UIATarget.localTarget().delay(duration);
			pauseButton.tap();
		}

		//Allow any animations to cease
		UIATarget.localTarget().delay(2);
		
		return;		
	} // end nike.pauseWorkout
	
	
	// --------------------------------------------------------------------------------
	//	Function: endWorkout
	//		End a workout
	//
	//	Parameters:
	//		None
	//
	//	Returns: 
	//		None
	//	
	//	Throws:
	//		An error if the "End Workout" button was not found
	// --------------------------------------------------------------------------------
	nike.endWorkout = function endWorkout() {

		UIATarget.localTarget().unlockScreenIfNecessary();
		// Look for End Workout button
		var endWorkoutButton = this.mainWindow().buttons().firstWithPredicate("name beginswith 'End Workout' or name beginswith 'Cancel'");
		if (endWorkoutButton.isValid()) endWorkoutButton.tap();
		else throw new Error("Did not find the 'End Workout' button");

		if (this.isWorkoutActive()) throw new Error("Workout is still active.");

		//Allow any animations to cease
		UIATarget.localTarget().delay(2);
		
		return;
		
	} // end nike.endWorkout

	// --------------------------------------------------------------------------------
	//	Function: latestWorkoutSummary
	//		Wrapper for ASEvent which collects workout data for the last workout from the app
	//
	//	Parameters:
	//		None
	//
	//	Returns: 
	//		summary (object) - object containing summary information accessed by keys defined in nike.workoutSummary
	//	
	// --------------------------------------------------------------------------------
	nike.latestWorkoutSummary = function latestWorkoutSummary() {
		return this.asApplication().latestWorkoutSummary();
	}
	
	
	// --------------------------------------------------------------------------------
	//	Function: waitForWorkoutNotification
	//		Wait for the supplied notification from Nike+
	//
	//	Parameters:
	//		timeout (int) - how long to wait for the notifaction
	//
	//	Returns: 
	//		None
	//	
	//	Throws:
	//		An error if the timeout was reached before the notification was received
	// --------------------------------------------------------------------------------
	nike.waitForWorkoutNotification = function waitForWorkoutNotification(notification, timeout) {
		if (!timeout) timeout = 10;
		var result = system.waitForNotification(notification, timeout);
		if (!result) throw new Error("Timed out waiting " + timeout + " seconds for notification " + notification);
		
		return;
	} // end nike.waitForWorkoutNotification
		
	
	// --------------------------------------------------------------------------------
	//	Function: chooseWorkoutType
	//		Return to the workout selection view (if needed) and choose a workout from 
	//		the list
	//
	//	Parameters:
	//		workout (string) - the type of workout to choose
	//	
	//	Returns: 
	//		None
	//	
	//	Throws:
	//		An error if the workout could not be selected
	// --------------------------------------------------------------------------------
	nike.chooseWorkoutType = function chooseWorkoutType(workout) {
		if (this.mainWindow().navigationBar().name() != "Workouts") this.returnToWorkoutSelection();
		
		var image = this.mainWindow().images().firstWithPredicate("ANY tableViews.isVisible == true");
		var table = image.tableViews()[0];
		var workoutTableCell = table.cells().firstWithPredicate("name beginswith '" + workout + "'");
		if (workoutTableCell.isValid()) workoutTableCell.tap();
		else throw new Error("Could not find the table cell for workout " + workout);

		//Allow any animations to cease
		UIATarget.localTarget().delay(2);
		
		return;		
	} // end nike.chooseWorkoutType
	
	
	// --------------------------------------------------------------------------------
	//	Function: chooseWorkoutMusic
	//		Choose music for a workout
	//		
	//	Parameters:
	//		workoutMusic (string) - "None" "Shuffle Songs" or a specific playlist name.  If
	//								the specified playlist could not be found, "Shuffle Songs"
	//								will be chosen by default
	//	
	//	Returns: 
	//		None
	//	
	//	Throws:
	//		An error if the music selection could not be found
	// --------------------------------------------------------------------------------
	nike.chooseWorkoutMusic = function chooseWorkoutMusic(workoutMusic) {
		if (this.mainWindow().navigationBar().name() != "Music") throw new Error("Not in the Music view.");
		
		UIALogger.logMessage("Choosing " + workoutMusic + " as workout music");

		var image = this.mainWindow().images().firstWithPredicate("ANY tableViews.isVisible == true");
		var table = image.tableViews()[0];
		var musicSelection = table.cells().firstWithName(workoutMusic);
		if (musicSelection.isValid()) {
			musicSelection.tap();
		} else if (table.cells().firstWithName("Playlists")) {
			table.cells().firstWithName("Playlists").tap();
			UIATarget.localTarget().delay(2);
			if (!table.cells().firstWithName(workoutMusic).isValid()) {
				// Per <rdar://problem/8819688> Nike+ Basic workout in Script fails to start when looking for music,
				// Choose "Shuffle" if the specified music playlist is cannot be found
				this.navigationBar().leftButton().tap();
				workoutMusic = "Shuffle Songs";
				UIATarget.localTarget().delay(1);
			}
			table.cells().firstWithName(workoutMusic).tap();
		} else {
			this.logElementTree();
			throw new Error("Cound not choose workout music.");
		}

		//Allow any animations to cease
		UIATarget.localTarget().delay(2);
		
		return;
	} // end nike.selectMusic
	
	// --------------------------------------------------------------------------------
	//	Function: isWorkoutActive
	//		Uses the latestWorkoutSummary method in the Nike+ app to determine if the
	//		workout is active - i.e., the timer is running 
	//
	//	Parameters:
	//		None
	//
	//	Returns: 
	//		true if the workout is active, false otherwises
	//	
	//	Throws:
	//		none
	// --------------------------------------------------------------------------------
	nike.isWorkoutActive = function isWorkoutActive() {
		UIATarget.localTarget().delay(3);		
		// Workaround for <rdar://problem/8718115> latestWorkoutSummary() does not seem to work to query Nike+ workout data in UI Automation
		var summary = nike.latestWorkoutSummary();
		var startWorkoutTime = parseInt(summary[this.workoutSummary.NIKE_WORKOUT_SUMMARY_TIME_KEY]);
		if (!startWorkoutTime) return false;
		startWorkoutTime = parseInt(startWorkoutTime);
		UIALogger.logDebug("starting workout time: " + startWorkoutTime);
		UIATarget.localTarget().delay(1);
		
		summary = nike.latestWorkoutSummary();
		var currentWorkoutTime = parseInt(summary[this.workoutSummary.NIKE_WORKOUT_SUMMARY_TIME_KEY]);
		UIALogger.logDebug("current workout time: " + currentWorkoutTime);
		if (currentWorkoutTime > startWorkoutTime) return true;
		else return false;
		
	} // end nike.isWorkoutActive
	
	// --------------------------------------------------------------------------------
	//	Function: verifyWorkoutCategory
	//		Uses the latestWorkoutSummary method in Nike+ to determine that the 
	//		current workout is the expected workout
	//
	//	Parameters:
	//		workout (string) - the expected workout
	//	
	//	Returns: 
	//		None
	//	
	//	Throws:
	//		An error if the current workout does not match the expected workout
	// --------------------------------------------------------------------------------
	nike.verifyWorkoutCategory = function verifyWorkoutCategory(workout) {
		
		// Workaround for <rdar://problem/8718115> latestWorkoutSummary() does not seem to work to query Nike+ workout data in UI Automation
		var summary = nike.latestWorkoutSummary();
		currentWorkout = summary[this.workoutSummary.NIKE_WORKOUT_SUMMARY_TYPE_KEY];
		UIALogger.logMessage("Current workout is " + currentWorkout);
		if (currentWorkout != workout) throw new Error("Current workout does not match expected workout. Current workout: " + currentWorkout + ", expected workout: " + workout);
		
		return;
	} // end nike.verifyWorkoutCategory
	
	// --------------------------------------------------------------------------------
	//	Function: 
	//
	//	Parameters:
	//					
	//	
	//  Optional:	
	//
	//	Returns: 
	//		None
	//	
	//	Throws:
	//		An error if the value was not found
	// --------------------------------------------------------------------------------
	nike.verifyCompletedWorkout = function verifyCompletedWorkout(category, workout) {
		// Pending latestWorkoutSummary fix
	} // end nike.verifyCompletedWorkout
	
	
	// --------------------------------------------------------------------------------
	//	Function: returnToWorkoutSelection
	//		Returns to the main workout selection view
	//
	//	Parameters:
	//		None
	//
	//	Returns: 
	//		None
	//	
	//	Throws:
	//		An error if the workout selection view could not be reached
	// --------------------------------------------------------------------------------
	nike.returnToWorkoutSelection = function returnToWorkoutSelection() {

		UIATarget.localTarget().unlockScreenIfNecessary();
		if (this.tabBar().isValid() && this.tabBar().buttons()["Workouts"].value() != 1) this.tabBar().buttons()["Workouts"].tap();
		
		if (this.mainWindow().navigationBar().isVisible() && this.mainWindow().navigationBar().name() == "Workouts") {
			UIALogger.logMessage("Already in the workout selection view");
			return;
		}

		try{
			this.endWorkout();
		} catch(e) {
			UIALogger.logMessage("Not currently in the workoutView");
		}
		
		// Allow any animations to cease
		UIATarget.localTarget().delay(1);

		this.returnToTopLevel();
		
		// Allow any animations to cease
		UIATarget.localTarget().delay(1);

		if (!this.mainWindow().navigationBar().staticTexts().firstWithName("Workouts").isVisible()) {
			throw new Error("Could not return to the workout selection view");
		}

		UIALogger.logMessage("Reached the workout selection view");

		//Allow any animations to cease
		UIATarget.localTarget().delay(2);
		
		return;
		
	} // end nike.returnToWorkoutSelection
	
	

	// --------------------------------------------------------------------------------
	//	Function: chooseWorkoutGoal
	//		Choose a goal from the table
	//
	//	Parameters:
	//		workoutGoal (string) - a workout goal from the Time, Distance or Calorie workouts
	//			For example, "3K workout", "20 minutes", "100 calories"
	//	
	//	Returns: 
	//		None
	//	
	//	Throws:
	//		An error if "Custom" is chosen as a workout goal
	// --------------------------------------------------------------------------------
	nike.chooseWorkoutGoal = function chooseWorkoutGoal(workoutGoal) {
		var image = this.mainWindow().images().firstWithPredicate("ANY tableViews.isVisible == true");
		var table = image.tableViews()[0];
		var workoutGoalCell = table.cells().firstWithName(workoutGoal);
		if (!workoutGoalCell.isValid()) {
			
			workoutGoalCell = table.cells()["Custom"];
			workoutGoalCell.scrollToVisible();
			workoutGoalCell.tap();
			//Allow any animations to cease
			UIATarget.localTarget().delay(2);

			this.setPickerWheels(workoutGoal);

			this.navigationBar().buttons()["Done"].tap();
		} else {
			workoutGoalCell.tap();
		}
		
		//Allow any animations to cease
		UIATarget.localTarget().delay(2);

		return;		
	} // end chooseWorkoutGoal

		
	// --------------------------------------------------------------------------------
	//	Function: setPickerWheels
	//		Set the picker to a specified value. This method is used to select custom
	//		workout goals or set the weight of a user
	//
	//	Parameters:
	//		pickerValue (string) - the value to set the picker to
	//	
	//	Returns: 
	//		None
	//	
	//	Throws:
	//		An error if the picker could not be set to the specified value
	// --------------------------------------------------------------------------------	
	nike.setPickerWheels = function setPickerWheels(pickerValue) {
		// Could be working better:  <rdar://problem/8744833> selectValue not working correctly
		var pickerType = this.navigationBar().name();
		pickerType = pickerType.match(/Calorie|Weight|Time|Distance/);
		var pickerValue;
		
	
		// --------------------------------------------------------------------------------	
		// Internal methods to handle splitting the specified picker value into 
		// individual components to set the picker wheels
	
		var getWeightValues = function getWeightValues(weight) {
			UIALogger.logMessage("Setting weight using weight picker");

			var wheelValues = new Array();
			wheelValues[0] = weight.split(".")[0];
			wheelValues[1] = weight.split(".")[1].split(" ")[0];
			if (parseInt(wheelValues[1]) == 5) wheelValues[1] = "½";
			wheelValues[2] = weight.split(" ")[1];
			if (wheelValues[2] == "lbs") wheelValues[2] = "Pounds";
			else wheelValues[2] = "Kilograms";
			UIALogger.logMessage("Spinning wheels to values: " + wheelValues);
			return wheelValues;
		} // end setWeight	
		
		var getCalorieValues = function getCalorieValues(calories) {
			UIALogger.logMessage("Setting calorie goal using calorie picker");
			calories = calories.split(" ")[0];

			var length = calories.length;
			var wheelValues = new Array();

			wheelValues[0] = calories.substring(0, length - 2) + ".";
			wheelValues[0] = (wheelValues[0] == ".") ? "0." : wheelValues[0];
			wheelValues[1] = calories.substring(length - 2) + ".";

			UIALogger.logMessage("Spinning wheels to values: " + wheelValues);
			return wheelValues;
		} // end setCalories
		
		var getTimeValues = function getTimeValues(time) {
			UIALogger.logMessage("Setting time goal using time picker");
			var wheelValues = new Array();
			if (time.match(",")) {
				wheelValues[0] = time.split(", ")[0];
				wheelValues[1] = time.split(", ")[1].split(" ")[0] + " min";
				
			} else {
				wheelValues[1] = time.split(" ")[0].split(" ")[0] + " min";
				wheelValues[0] = "0 hours";
			}
			UIALogger.logMessage("wheelValues: " + wheelValues);			
			// Add a 0 to the front of the picker wheel value if it is < 10
			wheelValues[1] = (parseInt(wheelValues[1].split(" ")) < 10 && parseInt(wheelValues[1].split(" ")) != 0 ) ? "0" + wheelValues[1]: wheelValues[1];

			UIALogger.logMessage("Spinning wheels to values: " + wheelValues);
			return wheelValues;
		} // end setTime
		
		var getDistanceValues = function getDistanceValues(distance) {
			UIALogger.logMessage("Setting distance goal using distance picker");

			var wheelValues = new Array();

			wheelValues[0] = distance.split(".")[0] + ".";
			wheelValues[1] = distance.split(".")[1].split(" ")[0] + ".";
			wheelValues[2] = distance.split(" ")[1];

			UIALogger.logMessage("Spinning wheels to values: " + wheelValues);
			return wheelValues;
		} // end setDistance()
		
		// end internal method declarations
		// --------------------------------------------------------------------------------	
		

		UIALogger.logMessage("Current picker type: " + pickerType + "");

		// switch seems to use the === in it's conditional, so the type of pickerType needs to
		// be explicitly set to a string
		switch (pickerType.toString()) {
			case "Weight":
				pickerValue = getWeightValues(pickerValue);
				break;
				
			case "Calorie":
				pickerValue = getCalorieValues(pickerValue);
				break;

			case "Time":
				pickerValue = getTimeValues(pickerValue);
				break;
				
			case "Distance":
				pickerValue = getDistanceValues(pickerValue);
				break;
				
			default:
				UIALogger.logMessage("Default");
				return;

		} // end switch
		
		var length = pickerValue.length;
		UIALogger.logMessage("Setting wheel values to: " + pickerValue);
		var picker = this.mainWindow().pickers()[0];
		
		// Iterate through all the picker wheels
		for (var i = 0; i < length; i++) {
			UIALogger.logMessage("Setting wheel " + i + " to |" + pickerValue[i] + "|");

			// To ensure that the picker is scrolled in the correct direction,
			// split the current picker value and determine if the value is a number
			var val = pickerValue[i].split(" ")[0];
			var currentPickerVal = picker.wheels()[i].value().split(" ")[0];
			var direction = 0;
			if (!isNaN(currentPickerVal) && !isNaN(val)) {
				UIALogger.logMessage("Parsed values: currentPickerVal: " + currentPickerVal + ", " + val);
				// If the value is a number, scroll accordingly
				if (parseInt(currentPickerVal) > parseInt(val)) direction = 0;
				else direction = 1;

			} else {
				// If it's not a number, use the special case conditional to set the direction
				// lbs and mi are the first value in the picker, so scroll down to kg or km
				if (currentPickerVal.match("Pounds") || currentPickerVal.match("mi") || pickerValue[i] == "½") direction = 1;
			}

			UIALogger.logMessage("Set direction to: " + direction);			
			UIALogger.logMessage("Spinning wheel to: " + pickerValue[i] + ". Currently at value: " + currentPickerVal);

			UIAUtility.scrollWheelToValueWithOptions(picker.wheels()[i], new UIAPredicateString("value beginswith '" + pickerValue[i] + "'" ), {direction:direction});
		}
		
	} // end setPickerWheels

	
	// --------------------------------------------------------------------------------
	//	Function: determineTimeoutValue
	//		Determine the timeout based on the type of workout and the workout goal.  
	//		This method calculates a total time the workout will last.  (I'm sorry - it's ugly,
	//		but it works).  Based on potential errors in calculating the total duration, 
	//		please allot at least 1 minute for the method to return.
	//
	//	Parameters:
	//		workoutType (string) - The type of workout (Distance, Calorie, Time)
	//		goal (string) - the actual goal of the workout ("Full Marathon Distance", "3K workout", etc
	//
	//	Returns: 
	//		None
	//	
	//	Throws:
	//		An error timeout could not be determined
	// --------------------------------------------------------------------------------	
	
	nike.determineTimeoutValue = function determineTimeoutValue(workoutType, goal) {
		
		var timeout;
		switch(workoutType) {
			
			case "Calorie":
				goal = goal.replace(/[a-zA-Z ]/g,"");
				UIALogger.logDebug("Refined goal: " + goal + ".");
				var calTimeDelta = 60;
				var calorieElement = this.mainWindow().elements().firstWithPredicate("name endswith ', cal'");
				
				var startCalories = calorieElement.name().split(", cal")[0];
				UIATarget.localTarget().delay(calTimeDelta);

				if (!calorieElement.checkIsValid()) throw new Error("Calorie element went invalid");
				var endCalories = calorieElement.name().split(",")[0];
				timeout = (goal / (endCalories - startCalories)) * calTimeDelta;
				UIALogger.logDebug("Start calories: " + startCalories + " End calories: " + endCalories + " Timeout: " + timeout);
				return Math.round(timeout);
				
			case "Distance":


				if (goal.match("marathon")) goal = (goal.match("Full")) ? 26 : 13;
				goal = goal.replace(/[a-zA-Z ]/g,"");					
				UIALogger.logDebug("Refined goal: " + goal + ".");
				
				var distanceTimeDelta = 60;
				var distanceElement = this.mainWindow().elements().firstWithPredicate("(name endswith ', km') or (name endswith ', mi')");
				
				var startDistance = distanceElement.name().split(",")[0];
				UIATarget.localTarget().delay(distanceTimeDelta);
				if (!distanceElement.checkIsValid()) throw new Error("Distance element went invalid");
				
				var endDistance = distanceElement.name().split(",")[0];
				timeout = (goal / (endDistance - startDistance)) * distanceTimeDelta;
				UIALogger.logDebug("Start distance: " + startDistance + " End distance: " + endDistance + " Timeout: " + timeout);
				return Math.round(timeout);

			case "Time":
				var hours = 0;
				var minutes = 0;
				
				if (goal && goal.match("hour")) {
					hours = goal.split(",")[0];
					hours = hours.replace(/[a-zA-Z ]/g, "");
					goal = goal.split(",")[1];
				} 
				
				if (goal && goal.match("minute")) {
					minutes = goal.replace(/[a-zA-Z ]/g, "");
				} 

				UIALogger.logDebug("Minutes: " + minutes);
				timeout = (hours * 3600) + (minutes * 60);
				UIALogger.logDebug("Timeout: " + timeout);				
				return Math.round(timeout);
			default:
				UIALogger.logError("Invalid workout goal: " + workoutGoal);
				throw new Error("Invalid workout goal: " + workoutGoal);
		}
				
		
		
	} // end determineTimeoutValue
		
	
}
	