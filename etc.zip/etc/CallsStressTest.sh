#!/bin/sh

callLength=60
LOOPS=100
number="4089748874"
timeBetweenCalls=60
count=0
pass=0
fail=0

startTime=`date "+%s"`
elapsedTime=0
currentTime=$startTime
tStartTime=`date -r $startTime`
echo "Starting the Tests:"
echo "Number = $number. Iterations = $LOOPS."
echo "Current Time - $currentTime"
lastKOOLStateTime=$startTime
timeForKOOLState=0
rm CallsStressTest.txt

#if [ $number -gt 2146053017 ] || [ $number -lt 2146053129 ]; then
#	echo "Please check your number."
#	exit 
#fi
/usr/local/bin/cthistory -r 'all'

while [ $count -le $LOOPS ];
#while(true);
do
	((count++))

	# Making a MO Call to LoopBack Number
	/usr/local/bin/testCTP -c $number > dummy.txt
	sleep 1
	grep "CallStatusActive PASS" dummy.txt
   	resultCall=$?
	rm dummy.txt

	sleep $callLength

	# Checking the Call Success/Failure
	if [ $resultCall -eq 0 ]; then
		((pass++))
		echo `date` ":  Call ($count) Passed."
		echo `date` ":  Call ($count) PASSED." >> CallsStressTest.txt
		/usr/local/bin/testCTP -e
	else
		((fail++))
		echo `date` ":  Call ($count) Failed."
		echo `date` ":  Call ($count) FAILED." >> CallsStressTest.txt
		#/usr/local/bin/testCTP -e
	fi
	
	
	echo "Calculating timers..."
	currentTime=`date "+%s"`
	elapsedTime=$(($currentTime - $startTime))
	timeForKOOLState=$(($currentTime - $lastKOOLStateTime))
	tCurrentTime=`date -r $currentTime`
	
	echo "Start Time = $startTime *** Current Time = $currentTime, $tCurrentTime, *** Elapsed Time = $elapsedTime"
	echo "Call KOOLSTATE Timer = $timeForKOOLState, Last KOOLSTATE = $lastKOOLStateTime\n"

	if [ $timeForKOOLState -ge 3600 ]; then
		echo "Taking *KOOL*STATE"
		testCT -l "Dumping logs after $count Voice Calls"
		lastKOOLStateTime=$currentTime
		sleep 10
		echo "\n\n Printing out the Call History:"
		/usr/local/bin/cthistory -c'all'
		echo "Done.\n"
	fi
	
	echo  `date` ": ( $count ) MO Calls were made so far... Passed: $pass Failed: $fail."
	echo "Sleeping for $timeBetweenCalls seconds..."
	sleep $timeBetweenCalls

done
