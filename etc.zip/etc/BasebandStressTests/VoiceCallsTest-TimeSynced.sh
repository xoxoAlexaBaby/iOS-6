#########################
##	ScriptName:	3GVoiceCallsTest.sh
##	Usage:		./3GCallsOnly.sh {iterations to run} {Max_Length_of_Calls_in_minutes,0=NO LIMT}
##	Purpose: 	To make calls on 3G and keep them active till either a call drop happens or 
##				the device hands over to 2G, keep call active for 30 seconds after HO to ensure that 
##				the HO succeeded.
##				Length of call can be user specified in minutes or 2 hours if given as 0 minutes
##				After every iteration check whether the device is still on 3G or not, otherwise 
##				try forcing 3G by going in/out of Airplane mode.
##	Author:		Jerome Jesu 
##	Revision History
VERSION=v2
##
##  VERSION		2
##	07/13/2010		Jerome Jesu jesu@apple.com. V21 -- Time Synced
##################################################

echo "Running Version $VERSION of the scripts..."
SCRIPTS_DIR="/usr/local/etc/BasebandStressTests/"
WAIT_TIME=60     # Interval between calls.
NUMBER="4089748874"


## PARAMETERS VALIDATION
startTime=0
loops=0
ratSelection=0  # default is 3G
interval=0
while getopts 's:i:t:r:h' OPTION; 
do
	case "$OPTION" in
		s ) startTime=1
			kickOffTime="$OPTARG";;
		i )	loops=1; 
			TOTAL_CALLS="$OPTARG";;
		t )	interval="$OPTARG";;
		r )	ratSelection="$OPTARG";;
		h ) echo "Usage: ./VoiceCallsTest--TimeSynced.sh -s <Start Time in HHMM HH-hours, MM- Minutes in 24H format>  -i <iterations>   -t <Call Interval in minutes> -r <0 | 1>"; exit 1;;
		/?)	echo "INVALID OPTIONS.\n"; exit 1;;
	esac
done
shift $(($OPTIND - 1))

if [ $loops -ne 1 ] || [ $startTime -ne 1 ]; then
	echo "\nUSAGE: $0  -s <Start Time in HHMM HH-hours, MM- Minutes in 24H format>  -i <iterations>   -t <Call Interval in minutes> -r <0 | 1>"
	echo "		example: $0   -s 1115     -i 100    -t 10  -- start at 11:15 AM and run 100 calls -r 0\n"
	exit 1
fi

if  [ $interval -gt 0 ]; then 
	MaxCallLength=`expr $interval \* 60`
else 
	MaxCallLength=`expr 2 \* 60 \* 60`	  
fi

HOURS=`echo $kickOffTime | perl -lne '
	$L=length; 
	($d1,$d2,$d3,$d4)=split//; 
	if ($L == 4) {print "$d1$d2";}
	elsif ($L == 3) {print $d1;}
	else {print "255"} '`

MINS=`echo $kickOffTime | perl -lne '
        $L=length;
        ($d1,$d2,$d3,$d4)=split//;
        if ($L == 4) {$m = "$d3$d4";}
        elsif ($L == 3) {$m = "$d2$d3";}
        else {$m = "0";}
        if ($m <= 15 && $m > 0) { $m = 15; }
        elsif ($m > 15 && $m <=30){ $m = 30;}
        elsif ($m > 30 && $m <=45){ $m = 45;}
        print $m;'`

if [ $HOURS -eq 255 ]; then 
	echo "USAGE Please specify Valid time in 24 hour format -->  \" -s HHMM \" "
	echo "      EX: \"-s 0730 \" for 07:30 AM\n      \" -s 2230 \" for 10:30 PM."
	exit 1;
fi

SECS=00
START_TIME=`echo "$HOURS $MINS $SECS" | perl -lne '
	use Time::Local;
	my ($Hour, $Min, $Sec) = split;
	my $time = time;
	my ($sec, $min, $hour, $day,$month,$year) = (localtime($time))[0,1,2,3,4,5,6];
	use integer;
	if ($Hour < $hour) { $Hour = $hour;
		if ($min >= 45) {$Hour++;$Min=0;}
		else { $temp = $min/15; $Min = ($temp * 15) +15; } 
	} elsif ($Hour == $hour && $Min < $min ) {
		if ($min < 45 ) { my $temp = $min/15; $Min = ($temp * 15) +15;}
		elsif ($min >= 45) { $Hour++; $Min=0;} 
	} elsif ($Hour == $hour && $Min > 45) {  $Hour++; $Min=0;	
	} elsif ($Hour > $hour) { if ($Min > 45) {$Hour++;$Min=0;}
	}
	my $time = timelocal($Sec,$Min,$Hour,$day,$month,$year);
	print "$time";  ' `

echo "START_TIME=$START_TIME"
date -r $START_TIME
echo "CAll LENGTH = $MaxCallLength. Interval = $interval,  iterations = $TOTAL_CALLS"

now=`date "+%s"`
tNow=`date -r $now`
echo "Current Time = $now, $tNow"

DEVICE_NAME=`hostname`
SUFFIX1=`echo $DEVICE_NAME | perl -lne '($s,$m,$H,$d,$M,$Y,$D) = localtime(); $Y += 1900; $M++; printf ("%s_%02d%02d-%02d%02d",$_,$M,$d,$H,$m); ' `


##############################################################################
##### HELPER FUNCTIONS 

getBuildVersions()
{
	/usr/local/bin/CoreTelephonyMonitor -q 2> BBVersion.txt &
	sleep 2; killall -9 CoreTelephonyMonitor; sleep 1;
	BB_Build=`perl -lne 'if (/\QFirmware Version\E/ ) { @vers = split; $vers[2] =~ s/\[|\]//g;  print "$vers[2]" }' BBVersion.txt`
	IMEI=`perl -lne 'if (/\QIMEI:\E/ ) { @imei = split; $imei[1] =~ s/\[|\]//g;  print "$imei[1]"; last; }' BBVersion.txt`
	SERIAL=`/usr/local/bin/lockdown_query get NULL SerialNumber 2>&1`
	if [ $DEVICE_NAME == "iPhone" ]; then  DEVICE_NAME=$SERIAL; fi
	APBuild=`sw_vers | perl -lne 'if (/\QBuildVersion\E/ ) { @vers = split; print "$vers[1]" }'`
}

initialize()
{
	HandOverInCurrentCall=NO
	dismissAlerts	
	#/usr/local/bin/testCT -x | grep status
	grep "Call to $NUMBER"  CT.txt
	if [ $? -eq 0 ]; then 
		echo "Initialize:::: there are still some calls. Ending them"
		/usr/local/bin/testCT -e    #end all active calls
	fi
	
	#Go to home scren
	/usr/local/bin/eventer h

	# kill any stray CTM processes from previous iterations/runs
	killall -9 CoreTelephonyMonitor					
	isCallDropped=1
}

generateReport()
{  	
    	echo "\n #################### Processing Logs ##########################"
		echo; ls -rlt $logsDir/log-bb-*;
		sleep 5;
		processCsiLogs
		echo " #################### Processing Completed ##########################\n"
		echo "Device_Name, Baseband Build, Iteration, Pass, Drop, Fail, Total Hand Overs in Test, HandOver In This Call, Call Start Time, Call End Time, Length Of Current Call, CallDrops(CSI_logs), CallFailures(CSI_Logs), Modem Resets, AP_Build, IMEI, SERIAL, 3G Drop, 2G within 15s, 2G after 15s, CALL DROP DURING" 
		echo "$DEVICE_NAME,$BB_Build,$COUNT,$PASS,$DROP,$FAIL,$HandOver,$HandOverInCurrentCall,$callStarted,$callEnded,$currentCallLength,$totalCallDrops,$totalCallFailures,$modemReset,$APBuild,$IMEI,$SERIAL,$umts,$umtsgsm,$gsm,$CALLDROPDURING,"
		echo "$DEVICE_NAME,$BB_Build,$COUNT,$PASS,$DROP,$FAIL,$HandOver,$HandOverInCurrentCall,$callStarted,$callEnded,$currentCallLength,$totalCallDrops,$totalCallFailures,$modemReset,$APBuild,$IMEI,$SERIAL,$umts,$umtsgsm,$gsm,$CALLDROPDURING,"  >> $resultFile.csv
		
		cp 	$resultFile.csv /Library/Logs/CrashReporter/
		cp  callended_${SUFFIX1}.txt /Library/Logs/CrashReporter/
}

dismissAlerts()
{
	echo "Dismissing Alerts.."
	/usr/local/bin/scripter -f /usr/local/etc/scripter/general/Interact.js com.apple.springboard "dismissAlerts(app)"
}

#prints the date in a CFAbsoluteTime format , used for syncing call drops with locations from GPS
logCallEndedDate()
{
	callEnded=`date`
	i=`date +%s`
	dateInCFAbsoluteSeconds=`expr $i - 0`
	echo $dateInCFAbsoluteSeconds >> callended_${SUFFIX1}.txt
	echo " CALL Ended at $dateInCFAbsoluteSeconds -- Playing OLD CAR HORN Sound.\n" 
	killHungProcess  figplayAV 10 &
	/usr/local/bin/figplayAV -a /Library/Ringtones/Old\ Car\ Horn.m4r 
	musicPlayed=$?
	if [ $musicPlayed -eq 0 ]; then echo "OLD CAR HORN was played. Check your ENT specialist if you dont hear."; fi
}	

checkIfCallDropped()
{
		/usr/local/bin/testCT -x | grep status
		grep -i "There are currently no calls." CT.txt
		isCallDropped=$?
}

logCallPASS()
{
		PASS=`expr $PASS + 1`
		CALLDROPDURING=""
		dismissAlerts
}

processCsiLogs()
{
	cp  $logFiles  $csiLogsDir/
	ls $csiLogsDir/*csi* | perl -lne '$f = $_; open (F, $f); $f =~ s/(.*\Qlog-bb-\E)(.*)(\Q-csi.\E(.*))/$2/; foreach (<F>) { chomp; if (/\QReason: \E/) { s/^(.*Reason: )//; $i=$_; print "$i,$f"; last; } } close F; '  > /tmp/crashReasons
	
	totalCsiLogs=`ls $csiLogsDir/*csi* | wc -l | perl -lne ' s/\s*//; print'`
	totalModemResets=`cat /tmp/crashReasons | grep "modem reset" | wc -l | perl -lne ' s/\s*//; print'`
	totalBasebandCrashes=`cat /tmp/crashReasons | grep "baseband crash"| wc -l | perl -lne ' s/\s*//; print'`
	totalCallFailures=`cat /tmp/crashReasons | grep -i "call fail" | wc -l | perl -lne ' s/\s*//; print'`
	totalCallDrops=`cat /tmp/crashReasons | grep -i "call drop"| wc -l | perl -lne ' s/\s*//; print'`
	totalFTO=`cat /tmp/crashReasons | grep "FTO" | wc -l | perl -lne ' s/\s*//; print' `
	totalBBResets=$(($totalModemResets + $totalBasebandCrashes))
	totalBBResets=`echo $totalBBResets | perl -lne ' if (/^\s*$/) { print "0";} else { print;} ' `
	cp /tmp/crashReasons CrashReasons.csv
	
	echo "\n ****************  LOG DETAILS:  *********************"
	echo "  RESETS-$totalModemResets  CRASHES-$totalBasebandCrashes   TOTAL-$totalBBResets"
	echo "  FAIL-$totalCallFailures,  DROPS-$totalCallDrops,  FTO-$totalFTO,"
	echo "  TOTAL-$totalCsiLogs\n"
	echo "\n ****************  REASONS FOR CSI LOGS:  *********************"
	head -1 $logFiles
	cp  $logFiles  $csiLogsDir/
} 

killHungProcess()
{
		echo "Sleeping $2 seconds..."
		sleep $2
		echo "Killing $1"
		GREP="grep $1"
		PIDS=`ps -A | $GREP | perl -lne ' if ( !/grep/ && !/killHungProcess/ ) { $p = (split)[0]; $p =~ s/\s*//g; print $p;} ' `
		echo " Showing Process.."
		ps -A | $GREP
		echo "KILLING Processes -- $PIDS.\n"
		kill -9 $PIDS
}

generateHoToneAndWaitFor15s()
{
	HandOverInCurrentCall=YES
	killHungProcess  figplayAV 5 &
	/usr/local/bin/figplayAV /Library/Ringtones/Doorbell.m4r &
	echo "HO Happened"
    HandOver=`expr $HandOver + 1`
	# wait for 15 seconds to ensure HO was successful and the call is still going
	# on 2G
	sleep_afterHO=0
	CALLDROPDURING="Within 10 seconds after HO"
						
	while [ $sleep_afterHO -lt 10 ]; do
		sleep 1;
		grep -i "There are currently no calls." CT.txt
		if [ $? -eq 0 ]; then break;  fi
		if [  $sleep_afterHO -gt 15 ]; then  CALLDROPDURING="On 2G 15 seconds after HO"; fi
		CALLDROPDURING="On 2G 15 seconds after HO"
		sleep_afterHO=`expr $sleep_afterHO + 1`; 
	done	
                		
}

reselectTo3G()
{
		echo "Checking for 3G indication"
		checkFor3G_seconds=0
		
		while [ $checkFor3G_seconds -le 60 ]; 
		do
                grep -i kCTRegistrationDataIndicator3G CT.txt
                if [ $? -eq 0 ]; then
                	killall -9 CoreTelephonyMonitor				
					echo "On 3G"
                	break;
                fi
				echo "No 3G yet, waiting for 3G indication"
				sleep 2;	
				checkFor3G_seconds=`expr $checkFor3G_seconds + 2`
		done
		echo "Waited for reselection: $checkFor3G_seconds seconds"
		CALLDROPDURING="On 3G"
}

handleIRATHandover()
{
		generateHoToneAndWaitFor15s
		#check if the call is still active
		checkIfCallDropped
		
		if [ $isCallDropped -ne 0 ]; then
			echo "CALL PASSED: HO Successful"
			logCallPASS
			testCT -l " Call Ending after IRAT Handover."
		else
			echo "CALL DROPPED AFTER IRAT HO"
			DROP=`expr $DROP + 1`
			if [  $sleep_afterHO -ge 10 ]; then ((gsm++));
			else ((umtsgsm++)); fi
			echo " #### Call dropped - $DROP - after IRAT\n #### Logging the Call Ended time."
			logCallEndedDate
		fi	
}


##############################################################################

# start counter
COUNT=0
PASS=0
FAIL=0
DROP=0
HandOver=0
HandOverInCurrentCall=NO
umts=0
gsm=0
umtsgsm=0
CALLDROPDURING=""
modemReset=0
totalCallDrops=0
totalCallFailures=0
modemReset=0

logsDir="/private/var/wireless/Library/Logs/CrashReporter/Baseband/"
logFiles="$logsDir/*csi*"
csiLogsDir="CsiLogs_Temp"
getBuildVersions
resultFile=`echo $DEVICE_NAME | perl -lne '($s,$m,$H,$d,$M,$Y,$D) = localtime(); $Y += 1900; $M++; printf ("Results_%s_%02d%02d-%02d%02d",$_,$M,$d,$H,$m); ' `
echo "Device_Name, Baseband Build, Iteration, Pass, Drop, Fail, Total Hand Overs in Test, HandOver In This Call, Call Start Time, Call End Time, Call Length in s, CallDrops(CSI_logs), CallFailures(CSI_Logs), Modem Resets, AP_Build, IMEI, SERIAL, 3G Drop, 2G within 15s, 2G after 15s, CALL DROP DURING" >> $resultFile.csv
mv $csiLogsDir $csiLogsDir-$SUFFIX1/
mkdir $csiLogsDir/

getBuildVersions
echo 

TotalCallTime=$(($MaxCallLength + $WAIT_TIME))
#END_TIME=`expr $START_TIME +  $totalCalls \* $TotalCallTime `
nextCallStartTime=$START_TIME


# Starting the Drive Tests
while [ $COUNT -lt $TOTAL_CALLS ]
do
		COUNT=`expr $COUNT + 1`;
		echo "\n\n******************* Beginnning Iteration: $COUNT ********************"
		initialize

		# Calculating Timers
		CurrentCallStartTime=$nextCallStartTime
		nextCallDiff=$(($CurrentCallStartTime - $now))
		if [ $nextCallDiff -gt 1800 ]; then
				echo " ****** Since the next call Start Time is more than 30 minutes... so restarting last Call..."
				COUNT=`expr $COUNT + 1`
				CurrentCallStartTime=$now;
		else
			CurrentCallEndTime=`expr $CurrentCallStartTime  +  $MaxCallLength `
			nextCallStartTime=`expr $START_TIME +  $COUNT \* $TotalCallTime `
		fi
		
		echo "******* CALL: Current StartTime - $CurrentCallStartTime, CurrentCallEndTime = $CurrentCallEndTime;"
		echo "******  CALL: nextCallStartTime = $nextCallStartTime;"

		
		##### Checking for Time to start from Epoch
		timeCount=0
		while [ $now -lt $CurrentCallStartTime ]; do
				sleep 1
				now=`date "+%s"`
				if [ $(($timeCount % 15)) -eq 0 ]; then echo `date` ": Now = $now."; fi
				((timeCount++))
		done
		

		# Wait for registration on 3G
        /usr/local/bin/CoreTelephonyMonitor 2>CT.txt &
		if [ $ratSelection -eq 0 ]; then
			echo "Wait for the Device to Reselect to 3G"
			reselectTo3G
			echo "Time to Reselect to 3G: $checkFor3G_seconds seconds"
		fi
		dismissAlerts
        
		if [ $checkFor3G_seconds -gt 60 ]; then
				echo "3G Reselection took more than a minute, so skipping this call."
				skipCallTimer=$(( $MaxCallLength - 120 ))
				echo "Sleeping for $skipCallTimer seconds..."
				sleep $skipCallTimer
		fi
		

		##### MAKING VOICE CALL		
		callStarted=`date`
        /usr/local/bin/testCT -c $NUMBER
        
        if [ $? -eq 0 ];  
        then   #call succeeded       
		 		now=`date "+%s"`
				callStartTimeSeconds=$now
        		killall -9 CoreTelephonyMonitor
        		/usr/local/bin/CoreTelephonyMonitor 2>CT.txt &
			
				## Waiting till the Call Drops or Hands over or Call length reached...
	        	while [ $now -le $CurrentCallEndTime ]
    	    	do
						echo "Call status processing"
						sleep 5
						
                 		if [ $ratSelection -eq 0 ]; then
                			grep -i kCTRegistrationDataIndicatorNone CT.txt
                			hoHappened=$?
                			if [ $hoHappened -eq 0 ]; then
								handleIRATHandover
								break;
							fi

                		fi
                
       					#check if the call is still active	         
						checkIfCallDropped
						if [ $isCallDropped -ne 0 ]; 
						then
                 				now=`date "+%s"`
                				#tNow=`date -r $now`
								if [ $(($CurrentCallEndTime - $now)) -gt 70 ]; then  sleepTime=60;
								else sleepTime=5; fi
								echo `date` ": Call still ongoing.. \nSleeping for $sleepTime seconds."
								sleep $sleepTime
								diff=$(($now - $callStartTimeSeconds + $sleepTime))
                				echo "Approximate time since call is up: $diff seconds, $now. "
                				CALLDROPDURING=""
 						else    	
								echo "CALL DROPPED ON 3G"
								CALLDROPDURING="ON 3G
        	        			DROP=`expr $DROP + 1`
        	        			((umts++))
        	        			echo " #### Call dropped on 3G -- Drop = $DROP\n #### Logging the Call Ended time."
        	        			logCallEndedDate
                        		break;                
                		fi  
                             
                		now=`date "+%s"`
				done
			
		else	
				callStartTimeSeconds=`date "+%s"`
				#call failed
				echo "CALL SETUP FAILED"
        		callEnded=`date`                
				CALLDROPDURING="Call Setup Failure"
               	FAIL=`expr $FAIL + 1`
               	date
               	echo " #### Call Failed - $FAIL - during ORIGINATION\n ####  Call Ended time is not logged."
               	endFlag=0
               	#logCallEndedDate
    	fi 
    	
		now=`date "+%s"`
    	#/usr/local/bin/testCT -x | grep status
		grep "Call to $NUMBER"  CT.txt
		if [ $? -eq 0 ]; then
				echo "Ending the Current Call... $COUNT"
				/usr/local/bin/testCT -e    #end all active calls
				callEnded=`date`;
		fi
		
		currentCallLength=$(($now - $callStartTimeSeconds))
    	generateReport
done




# takes 1 parameter the call number
takeK00lState()
{
		dismissAlerts
		/usr/local/bin/testCT -c *5005*78283#
        sleep 1
        #touch the Reply Button
        eventer t "Reply"
        eventer w "Call Number "
        eventer w $1
        #touch the Send button
        eventer c "Reply"
}

