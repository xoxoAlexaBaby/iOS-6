/*
 Class: UIApp (settings)
 Settings object
 */
#import "../libs/SpringBoard.js"
#import "../phone/Phone.js"
settings = UIAApp.application("Settings", "com.apple.Preferences");

if (typeof settings != 'undefined') {
	var _settings_passcode = "";
	
		
	//----------------------------------------------------------------------------------------
	//	Function: _getTableViewWithChild
	//		If the device is not an iPad, this helper function will return the first table view
	//		returned from tableViews().  If the device is an iPad, there are 2 choices.  If 
	//		a name is specified, then the predicate will do an exact match for name.  The name 
	//		and predicate parameters are mutually exclusive, however, if both are specified, the predicate
	//		will be used.
	// 
	//	Parameters:
	//		name (string) - if no matching (beginswith, endswith, contains) predicate is necessary, 
	//							this is the name of a child element in the table.  Essentially, 
	//							this name is wrapped in the predicate: 
	//							"ANY cells.name == '<element name goes here>'"
	//
	//		predicate (string) - if any type of non-matching is necessary, supply the full predicate
	//							string using this argument.
	//
	//  Returns:
	//		None
	//
	//	Usage:
	//		this._getTableViewWithChild({name:"Auto-Lock"})
	//		this._getTableViewWithChild({predicate:"ANY elements.name beginswith 'Auto'"})
	//----------------------------------------------------------------------------------------
	settings._getTableViewWithChild = function _getTableViewWithChild(options) {
		if (UIATarget.localTarget().model() == "iPad") {
			
			// If only one table is visible, choose it, as we're probably in a psudeo-popover
			if (this.mainWindow().tableViews().withPredicate("isVisible == 1").length == 1) {
				return this.mainWindow().tableViews().firstWithPredicate("isVisible == 1");
			}

			var predicate = "ANY cells.name == '" + options.name + "'";

			if (options.predicate) {
				predicate = options.predicate;
			}
			return this.mainWindow().tableViews().firstWithPredicate(predicate);
		} else {
			return this.mainWindow().tableViews()[0];
		}				
	} // end _getTableViewWithChild

	//----------------------------------------------------------------------------------------
	//	Function: _throwExceptionForAlert
	//		Throws an exception if an unidentified alert is found.  Used while running the
	//      createEmailAccount() test.
	// 
	//	Parameters:
	//		None
	//
	//  Returns:
	//		Throws error if an unidentified alert is found.
	//----------------------------------------------------------------------------------------
	settings._throwExceptionForAlert = function _throwExceptionForAlert(date) {
        var lastAlert = this.alertSinceDate(date);
        if (!lastAlert) {
            lastAlert = springboard.alertSinceDate(date);
        }
        if (lastAlert) {
            var theMessage = lastAlert.alertMessageArray.join(" - ");
            if (theMessage.indexOf("Allow MobileMe to Use the Location") > -1) {
                // This alert is expected. Don't throw an error because of it.
                UIALogger.logDebug("Got the MobileMe alert asking if it can use our current location. This is an expected alert.");
            }
            else {
                throw new Error("Got Alert: " + theMessage);
            }
        }
	}

	//----------------------------------------------------------------------------------------
	//	Function: createEmailAccount
	//		Creates an email account
	//
	//	Parameters: 
	//
	//		typeOfAccount (string) - one of the following: "yahoo", "gmail", "me", "aol", "exchange", or "other"
	//		name (string) - name of the person that the account belongs to (or username for exchange)
	//		address (string) - email address of the account that is to be created.
	//		password (string) - password of the email account.
	//		description (string) - description to give the account (optional).  
	//		server (string) - server for email - used for exchange accounts only (optional)
	//
	//	Optional Parameters:
	//		For Sync Page
	//			- mailSync (boolean) - true, if it needs to be turned on and false, if it needs to be turned off.
	//				If no value is specified, the default setting is used.
	//			- contactsSync (boolean) - true, if it needs to be turned on and false, if it needs to be turned off.
	//				If no value is specified, the default setting is used.
	//			- calendarsSync(boolean) - true, if it needs to be turned on and false, if it needs to be turned off.
	//				If no value is specified, the default setting is used.
	//			- bookmarksSync (boolean) - true, if it needs to be turned on and false, if it needs to be turned off.
	//				If no value is specified, the default setting is used.
	//			- findMyDevice (boolean) - true, if 'Find my iPhone' or 'Find my iPod touch' needs to be tuned on, and 
	//				false if it needs to be turned off. If no value is specified, the default setting is used.
	//
	//  Additional Optional Parameters
	//		alert (string) - string that contains <alert query>:<name of button to hit>, 
	//			(i.e. "alert:name matches 'Cannot Connect Using SSL':No")
	//		See mail.enterInfoToSetupOtherAccount() for optional parameters to use for accounts that need 
	//			to be set up under 'Other'.
	//
	//	Returns: 
	//		true if mail could create the email account, false if it could not.
	//----------------------------------------------------------------------------------------
	settings.createEmailAccount = function createEmailAccount(typeOfAccount, name, address, password, description, server, options) {
		if (typeof options == 'undefined' || !options) options = new Object();
		UIALogger.logMessage("In create new email account");

		// Disable alert handler if we want to handle alerts ourselves.
		if (options.alerts) {
			UIALogger.logMessage("Disabling onAlert() handling");
			UIATarget.disableOnAlert = 1;
		}
		
		this.getToAccountCreationView(typeOfAccount.toLowerCase());

		if (typeOfAccount.toLowerCase().match("exchange")) {
			this.enterExchangeAccountInfo(name, address, password, description, server, options) 
		}
		else {
			if (!this.enterEmailAccountInfo(typeOfAccount, name, address, password, description)) {
				throw new Error("Could not enter account information.");
			}
		}
		
		UIALogger.logMessage("Getting current date.")
		var date = new Date(); // used for alarm stuff further down.
		
		// Wait for activity indicator (usually says "Verifying") to go away.
		this.waitForActivityIndicatorToFinish(120); 		

		// If we have account of type "other", we need to fill in another form...
		if (typeOfAccount.toLowerCase().match("other") != null)  {
			if (!settings.enterInfoToSetupOtherEmailAccount(options)) {
				throw new Error("Could not enter the rest of information for 'other' account.");
			}
		}
		
		// Handle alerts that came up, per input (won't do anything if options.alerts is not specified)
		this.handleSpecifiedAlerts(options);
		
		// Set sync options -- most (or all?) email accounts seem to have this now
		var syncOptions = new Array();

		UIALogger.logMessage("Looking for sync options...");
		if (options.mailSync != null) 
			syncOptions.push({switchName:"Mail", setting:options.mailSync});	
		if (options.contactsSync != null) 
			syncOptions.push({switchName:"Contacts", setting:options.contactsSync});
		if (options.calendarsSync != null) 
			syncOptions.push({switchName:"Calendars.*", setting:options.calendarsSync});	
		if (options.bookmarksSync != null) 
			syncOptions.push({switchName:"Bookmarks", setting:options.bookmarksSync});	
		if (options.notesSync != null) 
			syncOptions.push({switchName:"Notes", setting:options.notesSync});
		if (options.findMyDevice != null) {
			syncOptions.push({switchName:"Find My.*", setting:options.findMyDevice});	
			if (UIATarget.localTarget().model() == "iPad") { UIATarget.disableOnAlert = 1; }  // disable alerts, because some this sync change brings up an alert.
		}
		if (options.shareLocation != null)
			syncOptions.push({switchName:"Share Location", setting:options.shareLocation});
			
		if (!options.alerts) {
    		this._throwExceptionForAlert(date);
    	}

		for (var i=0; i<syncOptions.length; i++) {
			var desiredSetting = syncOptions[i].setting;
			var theSwitchName = syncOptions[i].switchName;
			UIALogger.logMessage("Setting '" + theSwitchName + "' to " + desiredSetting);	
			
			// In iPad, switches are in the third table view and in the phone they're the first table view.
			if (i == 0)  UIATarget.localTarget().pushTimeout(60); // In the first iteration, we can wait a little longer just in case sync options take longer to bring up
			var theTableView = this.mainWindow().tableViews().firstWithPredicate("ANY cells.name matches '" + theSwitchName + "' and isVisible == true");
			if (i == 0)  UIATarget.localTarget().popTimeout();
			
			if (!theTableView.isValid()) {
				throw new Error ("Could not find the table view that contains the switch '" + theSwitchName + "'");
			}
			theTableView.elements().firstWithPredicate("name matches '" + theSwitchName + "'").switches().firstWithPredicate("name matches '" + theSwitchName + "'").setValue(desiredSetting);

			// Tap confirmation button for "Find My iPhone" and "Share Location" or "Merge with MobileMe" for merging calendars and contacts
			// TODO: eventually should pass a parameter indicating how to respond to merge questions
			var theActionSheet = this.actionSheet();
			if (theActionSheet.isValid()) {
				UIALogger.logMessage("Found an action sheet, going to try to choose an option.");
				UIATarget.localTarget().pushTimeout(0);
				var actionSheetButton = theActionSheet.buttons()["Allow"];
				if (!actionSheetButton.isValid()) actionSheetButton = theActionSheet.buttons().firstWithPredicate("name matches 'Merge.*'");			
				if (!actionSheetButton.isValid()) actionSheetButton = theActionSheet.buttons()["Continue"];
				if (actionSheetButton.isValid()) {
					UIALogger.logMessage("Tapping button '" + actionSheetButton.name() + "' in the action sheet");
					actionSheetButton.tap();
				}
				else {
					throw new Error ("Encountered an action sheet, but don't know how to respond!");
				}
				UIATarget.localTarget().popTimeout();
			}
			
			// iPad throws alerts instead of action sheets.
			if (UIATarget.localTarget().model() == "iPad") {
				var theAlert = this.alert();
				if (theAlert.isValid()) {
					if (!options.alerts) UIATarget.disableOnAlert = 0;  // we found an expected alert (the Find My .*) -- enable alerts again
					
					UIALogger.logMessage("Found an alert sheet, going to try to choose an option.");
					UIATarget.localTarget().pushTimeout(0);
					var alertButton = theAlert.buttons()["Continue"];
					if (!alertButton.isValid()) alertButton = theAlert.buttons()["Allow"];	
					if (!alertButton.isValid()) alertButton = theAlert.buttons()["OK"];	// Asks if it's okay to use current location
					if (alertButton.isValid()) {
						UIALogger.logMessage("Tapping button '" + alertButton.name() + "' in the alert");
						alertButton.tap();
						UIATarget.localTarget().delay(2); // wait for alert to go away.
						if (this.alert().isValid()) throw new Error ("Encountered an alert and couldn't get rid of it!");
						else this.lastAlert = null;
					}
					else {
						throw new Error ("Encountered an alert, but don't know how to respond!");
					}
					UIATarget.localTarget().popTimeout();
				}
			}
		}
			
		// Tap the 'Save' Button, if it exists.
		UIATarget.localTarget().pushTimeout(20); // give settings a little bit of extra time to talk to the server.
		var saveButton = this.mainWindow().navigationBar().rightButton();
		UIATarget.localTarget().popTimeout();
		UIATarget.localTarget().delay(1);  // make sure any animations are finished.
		if (saveButton.isValid()) {
			UIALogger.logMessage("Tapping 'Save' button in the navigation bar");
			saveButton.tap();
		}
			
		// Wait for progress indicator to stop
		this.waitForActivityIndicatorToFinish(120); 
		
		// Handle alerts that came up, per input (won't do anything if options.alerts is not specified)
		this.handleSpecifiedAlerts(options);
		
		if (options.alerts) {
			// Enable alerts again
			UIATarget.disableOnAlert = 0;
		}
		else {		
			// If there was an alert and we didn't expect one, we should throw an error.  
			// TODO - in the future, we may want to catch certain alerts and do special things with them
			this._throwExceptionForAlert(date);
		}
			
		// make sure we see the account name or description in settings 
		if (description) {
			var accountNameToSearchFor = description;
			if (typeOfAccount.toLowerCase().match("me")) {
				// if we are dealing with a Mobile Me account, we have to choose the account and change the description if one was given. 
				// We can no longer set the description when setting up the account.
				try {
					var accountNameToSearchFor = address;
					UIALogger.logMessage("Looking for description '" + accountNameToSearchFor + "'.");
					UIATarget.localTarget().pushTimeout(15);
					UIATarget.localTarget().delay(5); // make sure everything is done--sometimes this takes a little while...
					
					var tableElement = this._getTableViewWithChild({predicate:"ANY cells.name beginswith 'MobileMe'"});
					UIALogger.logDebug("Setting MobileMe Description--Tapping 'MobileMe'");
					tableElement.cells().firstWithPredicate("name beginswith 'MobileMe'").tap();
					
					UIATarget.localTarget().delay(1); // wait for animation to take place
					UIALogger.logDebug("Setting MobileMe Description--Tapping the account: " + accountNameToSearchFor);
					
					// Workaround for <rdar://problem/9464637> show apple id aliases in account info
					try {
						this.mainWindow().tableViews().firstWithPredicate("isVisible == true").cells().firstWithPredicate("value contains '" + accountNameToSearchFor + "'").tap();
					}
					catch (e) {
						UIALogger.logMessage("Caught error: " + e.message);
						var tmpAccountNameToSearchFor = accountNameToSearchFor.replace('me.com', 'mac.com');
						UIALogger.logMessage("Looking for " + tmpAccountNameToSearchFor + ", as a workaround for <rdar://problem/9464637>");
						this.mainWindow().tableViews().firstWithPredicate("isVisible == true").cells().firstWithPredicate("value contains '" + tmpAccountNameToSearchFor + "'").tap();
					}
					UIATarget.localTarget().delay(1); // wait for animation to take place
					
					UIALogger.logDebug("Setting MobileMe Description--Entering Description");
					var tableElement = this._getTableViewWithChild({predicate:"ANY cells.name beginswith 'Description'"});
					this.enterTextInTextField(tableElement.cells()["Description"].textFields()["Description"], description);
					UIATarget.localTarget().delay(1);
					
					for (var i=0; i<3; i++) {
						// Have to hit 'Done' button several times 
						var doneButton = this.mainWindow().navigationBar().buttons()["Done"];
						if (!doneButton.isValid()) {
							break;
						}
						UIALogger.logMessage("Setting MobileMe Description--Tapping Done Button");
						doneButton.tap()
						UIATarget.localTarget().delay(1); // wait for animation to take place
					}
					UIATarget.localTarget().popTimeout();
				}
				catch (e) {
					UIATarget.localTarget().popTimeout();
					UIALogger.logError("Caught Error: " + e.message);
					throw new Error("Could not set the description");
				}
				
			}
			else {
				UIALogger.logMessage("Looking for description '" + accountNameToSearchFor + "'.");
				var tableElement = this._getTableViewWithChild({predicate:"ANY elements.name contains '" + accountNameToSearchFor + "'"});
				// For all other types of accounts, we should have been able to set the description earlier -- now we can check it.
				if (!tableElement.cells().firstWithPredicate("name contains '" + accountNameToSearchFor + "'").isValid()) {
					throw new Error("Tried to setup the account, but no table cell with name '" + accountNameToSearchFor + "' could be found afterwards");
				}
				UIALogger.logMessage("Mail account setup passed -- table cell with name '" + accountNameToSearchFor + "' now exists");
			}
		}
		// TODO: if there is no description provided, we should look for the description that is provided automatically.  (i.e. MobileMe, etc)
		else {
			UIALogger.logMessage("Mail account setup passed, although we could not verify that it was created.");
		}
		return true;
	}
	
	//----------------------------------------------------------------------------------------
	//	Function: enterEmailAccountInfo
	//		Fills in the fields to create a new account (anything other than exchange)
	//
	//	Parameters: 
	//		(string) typeOfAccount - type of the account
	//		(string) name - name of the person that the account belongs to
	//		(string) address - email address of the account that is to be created.
	//		(string) password - password of the email account.
	//		(string) description - description to give the account (optional)
	//
	//
	//	Returns: 
	//		true if we could find the fields and fill them in, false if not
	//----------------------------------------------------------------------------------------
	settings.enterEmailAccountInfo = function enterEmailAccountInfo(typeOfAccount, name, address, password, description) {
    	UIALogger.logMessage("Creating a '" + typeOfAccount + "' account with name " + name);

		// look for the table view that contains the 'Name', 'Address', etc, text fields.
		// On iPad, this is usually the second table and on iPhone it's the first, but we don't want to make assumptions here.
		var theTableView = this.mainWindow().tableViews().firstWithPredicate("ANY elements.name == 'Password'");
		if (!theTableView.isValid()) {
			throw new Error ("Cannot find the table view containing the 'Name', 'Address', 'Password', etc, fields");
		}

		// Name
		if (typeOfAccount.toLowerCase().match("me") || typeOfAccount.toLowerCase().match("hotmail")) {
			UIALogger.logDebug("Mobile me or hotmail account -- 'Name' field not used.");
		}
		else {
			var nameCell = theTableView.cells()["Name"].textFields()["Name"];
			UIALogger.logMessage("Entering in name '" + name + "'");
			nameCell.tap();  // these taps are needed to get the right nav button to show up at the end
			nameCell.setValue(name);
		}

		// Address
		var atIndex = address.indexOf("@");
		if ((atIndex < 0) && (!typeOfAccount.toLowerCase().match("me"))) {
			// if we're not doing a mobileme account, add on "@<account>.com" to address, since it doesn't have an "@"
			address = address + "@" + typeOfAccount.toLowerCase() + ".com";
		}
		var addressCell = theTableView.cells()["Address"].textFields()["Address"];
		if (!addressCell.isValid()) {
			UIALogger.logMessage("Looking for 'Apple ID', instead of Name, since there doesn't seem to be a 'Name' field.")
			addressCell = theTableView.cells()["Apple ID"].textFields()["Apple ID"];
			if (!addressCell.isValid()) {
				UIALogger.logMessage("May have an instance of fields already partially filled out.  Trying different address cell.");
				addressCell = theTableView.textFields()["Apple ID"];
				if (!addressCell.isValid()) {
					// used with hotmail
					UIALogger.logMessage("Look for Email field.");
					addressCell = theTableView.cells()["Email"].textFields()["Email"];
					if (!addressCell.isValid()) {
						throw new Error("Could not find the text field in which to enter the email address");				
					}
				}
			}
		}
		UIALogger.logMessage("Entering email address '" + address + "'");
		this.enterTextInTextField(addressCell, address);
		
		// Password
		var passwordCell = theTableView.cells()["Password"].secureTextFields()["Password"];
		if (!passwordCell.isValid()) {
			UIALogger.logMessage("May have an instance of fields already partially filled out.  Trying different password cell.");
			passwordCell =  theTableView.secureTextFields()["Password"];
			if (!passwordCell.isValid()) {
				throw new Error("Could not find the password field");
			}
		}
		UIALogger.logMessage("Entering password");
		this.enterTextInTextField(passwordCell, password);
		
		// Description
		if ((description) && (!typeOfAccount.toLowerCase().match("me"))){
			var descriptionCell = theTableView.cells()["Description"].textFields()["Description"];
			UIALogger.logMessage("Entering description '" + description + "'");
			descriptionCell.tap();
			descriptionCell.setValue(description);
		} 
		else {
			UIALogger.logMessage("No description to set");
		}
			
		// Tap "Next" or "Save" button
		this.mainWindow().navigationBar().rightButton().tap(); 

		UIALogger.logMessage("Done entering account info");
		return true;
		
	}
	
	//----------------------------------------------------------------------------------------
	//	Function: enterInfoToSetupOtherAccount
	//		This function enters additional account information in order
	//		to setup an "other" account.
	//
	//	Parameters: 
	//		All Optional
	//
	//	Optional Parameters:
	//		usePop (bool) - "true" or "1" passed in if Pop account should be used.  Otherwise,
	//			IMAP is used.
	//		inHostName (string) - incoming host name 
	//		inUserName (string) - incoming username 
	//		inPassword (string) - incoming Password 
	//		outHostName (string) - outgoing host name 
	//		outUserName (string) - outgoing user name
	//		outPassword (string) - outgoing password
	//
	//	Returns: 
	//		true if the fields could be filled in, false if not.
	//----------------------------------------------------------------------------------------
	settings.enterInfoToSetupOtherEmailAccount = function enterInfoToSetupOtherEmailAccount(options) {
		UIALogger.logMessage("Creating an 'other' account");
		
		if (!options) { 
			throw new Error("Need to specify options for this function");
		}
		UIATarget.localTarget().pushTimeout(20);  // give a little more time if we need it for things to come up.
		var tableElement = this._getTableViewWithChild({predicate:"name beginswith 'POP' or name beginswith 'IMAP'"});
		UIATarget.localTarget().popTimeout();
		
		var theCells = tableElement.cells();

		if (options.usePop && ((options.usePop == "true") || (options.usePop == 1) || (options.usePop == true))) {
			UIALogger.logMessage("Setting option to use 'POP'");
			tableElement.cells().firstWithPredicate("name matches 'IMAP.*'").buttons().firstWithPredicate("name matches 'POP.*'").tap();
		}

		// First field we fill out is Host Name for Incoming Mail Server  --> this is the first occurrence of 'HostName'
		if (options.inHostName) {
			UIALogger.logMessage("Adding Incoming Mail Server Host Name: " + options.inHostName);
			var incomingHostNameTableCell = theCells["Host Name"].textFields()[0];
			incomingHostNameTableCell.scrollToVisible();
			incomingHostNameTableCell.setValue(options.inHostName);
		}
		
		// User Name for the Incoming Mail Server
		if (options.inUserName) {
			UIALogger.logMessage("Adding Incoming Mail Server User Name: " + options.inUserName);
			var incomingUserNameTableCell = theCells["User Name"].textFields()[0];
			incomingUserNameTableCell.scrollToVisible();
			incomingUserNameTableCell.setValue(options.inUserName);
		}

		// Password for the Incoming Mail Server
		if (options.inPassword) {
			UIALogger.logMessage("Adding Incoming Mail Server Password.");
			var incomingPasswordTableCell = tableElement.cells()["Password"].secureTextFields()[0];
			incomingPasswordTableCell.scrollToVisible();
			incomingPasswordTableCell.setValue(options.inPassword);
		}
		
		// Host Name for Outgoing Mail Server  --> this is the second occurrence of 'HostName'
		if (options.outHostName) {
			UIALogger.logMessage("Adding Outgoing Mail Server Host Name: " + options.outHostName);
			var outHostNameTableCell = theCells.withName("Host Name")[1].textFields()[0];
			outHostNameTableCell.scrollToVisible();
			outHostNameTableCell.setValue(options.outHostName);
		}
		
		// User Name for the Outgoing Mail Server
		if (options.outUserName && (options.outUserName != "BLANK")) {
			UIALogger.logMessage("Adding Outgoing Mail Server User Name: " + options.outUserName);
			var outUserNameTableCell = theCells.withName("User Name")[1].textFields()[0];
			outUserNameTableCell.scrollToVisible();
			outUserNameTableCell.setValue(options.outUserName);
		}

		// Password for the Outgoing Mail Server
		if (options.outPassword && (options.outPassword != "BLANK")) {
			UIALogger.logMessage("Adding Outgoing Mail Server Password.");
			var incomingPasswordTableCell = theCells.withName("Password")[1].secureTextFields()[0];
			incomingPasswordTableCell.scrollToVisible();
			incomingPasswordTableCell.setValue(options.outPassword);
		}
		UIATarget.localTarget().delay(1);  // delay a bit to make sure 'Next' button becomes active
		
		// Done filling in this page, go to the next one (sync options)
		this.mainWindow().navigationBar().rightButton().tap();
		UIALogger.logMessage("Tapped 'Next' button");
		
		// Wait for progress indicator to stop 
		//UIALogger.logMessage("Waiting for Activity Indicator to go away--this is another bad one");
		this.waitForActivityIndicatorToFinish(120);  
	
		return true;	
	}
	
	//----------------------------------------------------------------------------------------
	//	Function: enterExchangeAccountInfo 
	//		Fills in the fields to create a new exchange account 
	//
	//	Parameters: 
	//		name (string) - name of the person that the account belongs to
	//		address (string) - email address of the account that is to be created.
	//		password (string) - password of the email account.
	//		description (string) - description to give the account (optional)
	//		server (string) - server of the account (optional - if not given, uses
	//			last part of email address)
	//	
	//  Optional Parameters:
	//		alert (string) - used to dismiss dialog/alert boxes after an account is setup.  For example, 
	//			this can be used if setting up an "other" account that doesn't support SSL.
	//			alert:<string in alert to look for>:<string indicating what UIElement to tap>.  
	//			(i.e. "alert:name matches 'Cannot Connect Using SSL':No")
	//
	//	Returns: 
	//		true if we could find the fields and fill them in, false if not
	//----------------------------------------------------------------------------------------
	settings.enterExchangeAccountInfo = function enterExchangeAccountInfo(name, address, password, description, server, options) {
		
		UIALogger.logMessage("Creating an exchange account with name " + name);
		
		// Get the table view -- this is the second table view on the iPad and first on iPhone.
		var theTableView = this.mainWindow().tableViews().firstWithPredicate("ANY cells.name == 'Email'");
		
		// Email
		var theCell = theTableView.cells()["Email"].textFields()["Email"];
		UIALogger.logMessage("Entering in email '" + address + "'");
		theCell.scrollToVisible();
		theCell.setValue(address);
		UIATarget.localTarget().delay(1);
		
		// Username 
		var theCell = theTableView.cells()["Username"].textFields()["Username"];
		UIALogger.logMessage("Entering in username '" + name + "'");
		theCell.scrollToVisible();
		theCell.setValue(name);
		UIATarget.localTarget().delay(1);
		
		// Password 
		theCell = theTableView.cells()["Password"].secureTextFields()["Password"];
		UIALogger.logMessage("Entering in password.");
		theCell.scrollToVisible();
		theCell.setValue(password);
		UIATarget.localTarget().delay(1);
		
		// Description
		if (description) {
			theCell = theTableView.cells()["Description"].textFields()["Description"];
			UIALogger.logMessage("Entering in description '" + description + "'");
			theCell.scrollToVisible();
			theCell.setValue(description);
			UIATarget.localTarget().delay(1);
		} else {
			UIALogger.logMessage("No description to set");
		}
		
		// Done filling in this page, go to the next one, which shows the server information
		this.mainWindow().navigationBar().rightButton().tap();
		UIALogger.logMessage("Tapped 'Next' button");
		
		// Handle any alerts that may pop up
		this.handleSpecifiedAlerts(options);
		
		// Wait for progress indicator to stop
		//UIALogger.logMessage("Waiting for Activity Indicator to go away--this is another bad one");
		this.waitForActivityIndicatorToFinish(120); 
		
		// Get the new table view -- once again, this is a different index for iPad vs. iPhone
		var theTableView = this.mainWindow().tableViews().firstWithPredicate("ANY cells.name == 'Server'");
		
		// Server
		theCell = theTableView.cells()["Server"].textFields()["Server"];
		var serverName = ""
		if (server)  serverName = server;
		else {
			var indexOfAtSymbol = address.indexOf("@");
			serverName = address.substring(indexOfAtSymbol + 1); // extract the server name (i.e whatever.com)
		}
		UIALogger.logMessage("Entering in server '" + serverName + "'");
		theCell.scrollToVisible();
		theCell.setValue(serverName);
		UIATarget.localTarget().delay(1);
			
		// Done filling in this page, go to the next one (sync options)
		this.mainWindow().navigationBar().rightButton().tap();
		UIALogger.logMessage("Tapped 'Next' button");
		
		// Wait for progress indicator to stop 
		//UIALogger.logMessage("Waiting for Activity Indicator to go away--this is another bad one");
		this.waitForActivityIndicatorToFinish(120);  
		
	}
	
	//----------------------------------------------------------------------------------------
	//	Function: getToAccountCreationView 
	//		Moves through settings to get to the account creation pane for the specified account
	//		type
	//
	//	Parameters: 
	//		accountType (String) - the type of account to setup.  
	//	
	//	Returns: 
	//		None, throws an exception on failure
	//----------------------------------------------------------------------------------------
	settings.getToAccountCreationView = function getToAccountCreationView(accountType) {
		this.getToSpecifiedSetting(["Mail, Contacts, Calendars", "Add Account…"]);
		
		var accountChoice = undefined;
		var theTableView  = this.mainWindow().tableViews().firstWithPredicate("ANY cells.name == 'Yahoo account'");
		
		switch (accountType) {
			case "yahoo":    accountChoice = "Yahoo account";                         break;
			case "gmail":    accountChoice = "G-mail account";                        break;
			case "g-mail":   accountChoice = "G-mail account";                        break;
			case "me":       accountChoice = "MobileMe account";                      break;
			case "mobileme": accountChoice = "MobileMe account";                      break;
			case "aol":      accountChoice = "AOL account";                           break;
			case "exchange": accountChoice = "Microsoft Exchange account";			break;
			case "eas":      accountChoice = "Microsoft Exchange account"; 			break;
			case "hotmail":  accountChoice = "Windows Live Hotmail account"; 		break;
		}
		
		if (accountChoice == undefined) {
			UIALogger.logMessage("Moving to other account types");
			var otherCell = theTableView.elements()["Other"];
			otherCell.scrollToVisible();
			UIATarget.localTarget().delay(0.5);
			otherCell.tap();
			UIATarget.localTarget().delay(5);
			
			theTableView = this.mainWindow().tableViews().firstWithPredicate("ANY cells.name == 'Add Mail Account'");
			
			switch (accountType) {
				case "mail":    accountChoice = "Add Mail Account";        break;
				case "other":    accountChoice = "Add Mail Account";        break;  
				case "imap":    accountChoice = "Add Mail Account";        break;
				case "ldap":    accountChoice = "Add LDAP Account";        break;
				case "carddav": accountChoice = "Add CardDAV Account";     break;
				case "caldav":  accountChoice = "Add CalDAV Account";      break;
				case "subcal":  accountChoice = "Add Subscribed Calendar"; break;
			}
		}
		
		if (accountChoice == undefined) {
			throw new Error("Encountered an unsupported account type '" + accountType + "'");
		}
		
		UIALogger.logMessage("Mapped '" + accountType + "' to '" + accountChoice + "'");
		var accountChoiceCell = theTableView.cells()[accountChoice];
		accountChoiceCell.scrollToVisible();
		UIATarget.localTarget().delay(0.5);
		accountChoiceCell.tap();
	}
	
	//----------------------------------------------------------------------------------------
	//	Function: submitAccountData 
	//		Presses the top right navigation bar button, waits for any activity indicators to
	//		complete, and then returns a value that indicates if any alerts were encountered
	//
	//	Parameters: 
	//		None
	//	
	//	Returns: 
	//		None, throws an exception on failure
	//----------------------------------------------------------------------------------------
	settings.submitAccountData = function submitAccountData() {
		var button;
		var date;
		var alert;
		
		UIATarget.localTarget().delay(1);
		
		button = this.mainWindow().navigationBar().rightButton();
		date   = new Date();
		
		UIALogger.logMessage("Tapping '" + button.name() + "' button");
		button.tap();
		
		UIALogger.logMessage("Waiting for activity to complete");
		this.waitForActivityIndicatorToFinish(120);
 		
		alert = this.alertSinceDate(date);
		
		if (alert != null) {
			throw new Error("Unable to submit account info because of alert: " + alert.alertMessageArray.join(" - "));
		}
	}
	
	//----------------------------------------------------------------------------------------
	//	Function: createCalDAVAccount 
	//		Navigates to the CalDAV account pane, fills out the account info, and saves
	//
	//	Parameters: 
	//		username    (String) - name of the person that the account belongs to
	//		password    (String) - password for the account
	//		description (String) - a description for the account (can be null to leave the default value)
	//		server      (String) - the server for the account
	//	
	//	Returns: 
	//		None
	//----------------------------------------------------------------------------------------
	settings.createCalDAVAccount = function createCalDAVAccount(username, password, description, server) {
		this.getToAccountCreationView("caldav");
		
		var theTableView = this.mainWindow().tableViews().firstWithPredicate("ANY cells.name == 'Server'");
		var theTableCell;
		
		theTableCell = theTableView.cells().firstWithPredicate("ANY textFields.name == 'Server'");
		this.enterTextInTextField(theTableCell.textFields()["Server"],         server);
		
		theTableCell = theTableView.cells().firstWithPredicate("ANY textFields.name == 'User Name'");
		this.enterTextInTextField(theTableCell.textFields()["User Name"],      username);
		
		theTableCell = theTableView.cells().firstWithPredicate("ANY secureTextFields.name == 'Password'");
		this.enterTextInTextField(theTableCell.secureTextFields()["Password"], password);
		
		
		if (description != null) {
			theTableCell = theTableView.cells().firstWithPredicate("ANY textFields.name == 'Description'");
			this.enterTextInTextField(theTableCell.textFields()["Description"], description);
		}
		
		this.submitAccountData();
	}
	
	//----------------------------------------------------------------------------------------
	//	Function: createSubCalAccount 
	//		Navigates to the SubCal account pane, fills out the account info, and saves
	//
	//	Parameters: 
	//		username     (String) - name of the person that the account belongs to
	//		password     (String) - password for the account
	//		url          (String) - a description for the account (can be null to leave the default value)
	//		description  (String) - the server for the account
	//
	//	Optional Parameters:
	//		useSSL       (String) - "ON" or "OFF" to set SSL setting
	//		removeAlarms (String) - "ON" or "OFF" to set the Remove Alarms setting
	//	
	//	Returns: 
	//		None
	//----------------------------------------------------------------------------------------
	settings.createSubCalAccount = function createSubCalAccount(username, passsword, url, description, options) {
		if (typeof options == 'undefined' || !options) {
			options = {};
		}
		
		this.getToAccountCreationView("subcal");
		
		var theTableView = this.mainWindow().tableViews().firstWithPredicate("ANY cells.name == 'Server'");
		var theTableCell = theTableView.cells().firstWithPredicate("ANY textFields.name == 'Server'");
		
		this.enterTextInTextField(theTableCell.textFields()["Server"], url);
		
		this.submitAccountData();
		
		if (description != null) {
			theTableCell = theTableView.cells().firstWithPredicate("ANY textFields.name == 'Description'");
			this.enterTextInTextField(theTableCell.textFields()["Description"], description);
		}
		
		theTableCell = theTableView.cells().firstWithPredicate("ANY textFields.name == 'Username'");
		this.enterTextInTextField(theTableCell.textFields()["Username"], username);

		theTableCell = theTableView.cells().firstWithPredicate("ANY secureTextFields.name == 'Password'");	
		this.enterTextInTextField(theTableCell.secureTextFields()["Password"], passsword);
		
		if (options.useSSL) {
			UIALogger.logMessage("Setting 'Use SSL' to " + options.useSSL);
			theTableView.cells().firstWithName("Use SSL").switches()[0].setValue(options.useSSL);
		}
		
		if (options.removeAlarms) {
			UIALogger.logMessage("Setting 'Remove Alarms' to " + options.removeAlarms);
			theTableView.cells().firstWithName("Remove Alarms").switches()[0].setValue(options.removeAlarms);
		}
		
		this.submitAccountData();
		
		// this part is weird... subcal will come back, after pressing next, with
		// yet another option to save.
		this.submitAccountData();
	}
	
	//----------------------------------------------------------------------------------------
	//	Function: handleSpecifiedAlerts 
	//		Takes in the options, and handles alerts that are
	//		onscreen.  Automatic alert handling must be disabled for this function to work.  If alert
	//		is not specified in options, this function does nothing.
	//
	//	Optional Parameters: 
	//		alert (array) - array of strings that contains <alert query>:<name of button to hit>, 
	//			(i.e. "name matches 'Cannot Connect Using SSL':No")
	//
	//	Returns: 
	//		None.
	//----------------------------------------------------------------------------------------	
	settings.handleSpecifiedAlerts = function handleSpecifiedAlerts(options) {
		
		// Handle alerts that came up, per input
		if (options.alerts) {
			for (var i=0; i<5; i++) {  // look for a max of 5 alerts--will keep us from ending up in an infinite loop
				UIALogger.logMessage("Looking for an alert...");
				UIATarget.localTarget().pushTimeout(15);
				var actualAlertElement = UIATarget.localTarget().frontMostApp().alert();
				UIATarget.localTarget().popTimeout();
				if (actualAlertElement.isValid()) {
					UIALogger.logMessage("Found an alert...")
					// Create the string that includes all of the alert messages
					var theStaticTexts = actualAlertElement.staticTexts();
					
					// Go through each expected alert and see if it matches the message string.
					for (var alertIndex=0; alertIndex < options.alerts.length; alertIndex++) {
						var alertArray = options.alerts[alertIndex].split(":");
						if (alertArray.length < 2) {
							UIALogger.logError("alertArray was not specified correctly, need 'string:uiElement name', but got '" + options.alerts[alertIndex] + "'")
							break;
						}
						var expectedAlertPredicate = alertArray[0];
						var expectedAlertElement = alertArray[1];
					
						UIALogger.logMessage("Looking for: alert '" + expectedAlertPredicate + "', found actual alert '" + theStaticTexts[0].name() + "'");
						if (theStaticTexts.firstWithPredicate(expectedAlertPredicate).isValid()) {
							UIALogger.logMessage("Found alert matching '" + expectedAlertPredicate + "'");
							var elementToTap = actualAlertElement.elements().firstWithPredicate("name contains '" + expectedAlertElement + "'");
							if (!elementToTap.isValid()) { 
								throw new Error("Could not tap alert element with name matching '" + expectedAlertElement + "'");
							}
							UIALogger.logMessage("Tapping alert element '" + elementToTap.name() + "'");
							elementToTap.tap();		
							UIATarget.localTarget().delay(1);					

							// try tapping the save button again--it may be necessary after responding to alerts
							var saveButton = this.mainWindow().navigationBar().rightButton();
							if (saveButton.isValid()) {
								UIALogger.logMessage("Tapping 'Save' button in the navigation bar");
								saveButton.tap();
							}
							break;
						}
						else {
							UIALogger.logWarning("Did not find alert matching '" + expectedAlertPredicate + "'");
						}
					}
				}
				else {
					// no alerts found
					UIALogger.logMessage("No alert elements found.");
					break;
				}
			}
			UIATarget.localTarget().popTimeout();
		}
		else {
			UIALogger.logDebug("No alerts specified, this function is not doing anything.");
		}
	}

	//----------------------------------------------------------------------------------------
	//	Function: deleteEmailAccount 
	//		Deletes the given email account 
	//
	//	Parameters: 
	//		(string) address = address or description (whichever has been used) of the
	//			email account to be deleted.
	//
	//	Optional Parameters: 
	//		skipNavigation (boolean) - if true, attempts to remove the account without
	//			first navigating to "Mail, Contacts, Calendars"
	//
	//	Returns: 
	//		None
	//
	//	Throws:
	//		Exception if the function isn't able to delete the account.
	//----------------------------------------------------------------------------------------	
	settings.deleteEmailAccount = function deleteEmailAccount(address, options) {
		if (typeof options == 'undefined' || !options) {
			options = {skipNavigation:false};
		}
		
		UIALogger.logMessage("In delete email account, removing '" + address + "'");
		
		// launch settings, get to 'Mail, Contacts, Calendars' page
		try {
			if (!options.skipNavigation) {
				this.getToSpecifiedSetting(["Mail, Contacts, Calendars"]);
			}
		} catch (e) {
			UIALogger.logMessage("Caught error: " + e.message);
			throw new Error("Could not get to 'Mail, Contacts, Calendars' page in settings")
		}
		
		// find the email address and tap it
		var initialAccountCount;
		
		try {
			var accountsTableView = this.mainWindow().tableViews().firstWithPredicate("ANY cells.name BEGINSWITH '" + address + "'");
			
			initialAccountCount = accountsTableView.cells().length;
			
			accountsTableView.cells().firstWithPredicate("name beginswith '" + address + "'").tap();
		} catch (e) {
			UIALogger.logMessage("Caught error: " + e.message);
			throw new Error("Mail account with address '" + address + "' doesn't exist, so it can't be deleted");
		}
		UIATarget.localTarget().delay(2); // wait for animations to take place.
		
		if (UIATarget.localTarget().model() == "iPad") {
			UIATarget.disableOnAlert = 1;  // iPad pops up an alert asking if you are sure you want to delete the account.
		}
				
		// tap Delete Account button
		try {
			var theTableView = this.mainWindow().tableViews().firstWithPredicate("ANY groups.name == 'Delete Account'"); // need this for ipad, it is tableView()[0] for iphone
			UIALogger.logMessage("Tapping 'Delete Account' group")
			var deleteButton = theTableView.groups()["Delete Account"];
			deleteButton.scrollToVisible();
			deleteButton.tap();
			UIATarget.localTarget().delay(1);
		} catch (e) {
			UIALogger.logMessage("Caught error: " + e.message);
			if (UIATarget.localTarget().model() == "iPad") {
				UIATarget.disableOnAlert = 0;  // iPad pops up an alert asking if you are sure you want to delete the account.
			}
			throw new Error("Could not tap the 'Delete Account' button");
		}
		
		// Confirm the account deletion
		if (UIATarget.localTarget().model() != "iPad") {
			// tap confirmation button that comes up as an action sheet
			try {
				UIALogger.logMessage("Tapping action sheet button to confirm account deletion");
				var confirmDeleteAccount = this.actionSheet().buttons().firstWithPredicate("name matches 'Delete.*'");	
				UIATarget.localTarget().delay(1);
				confirmDeleteAccount.tap();
			} catch (e) {
				UIALogger.logMessage("Caught error: " + e.message);
				throw new Error("Could not tap the action sheet to confirm deletion of the account");
			}
		}
		else {
			// iPad pops up an alert that we have to dismiss
			try {
				UIALogger.logMessage("Tapping the alert to confirm deletion of account.");
				
				// MobileMe accounts prompt you to "Keep on your iDevice", or "Delete from your iDevice", but
				// all other accounts just present "Delete" or "Cancel"
				UIATarget.localTarget().frontMostApp().alert().buttons().firstWithPredicate("name matches 'Delete.*'").tap();  // this alert belongs to springboard
			} catch (e) {
				UIALogger.logMessage("Caught error: " + e.message);
				UIATarget.disableOnAlert = 0;
				throw new Error("Could not tap the alert to confirm deletion of the account.");
			}
		}
		
		// Make sure we re-enable automatic alert handling.
		if (UIATarget.localTarget().model() == "iPad") {
			UIATarget.disableOnAlert = 0; 
		}
		
		// wait for the activity indicator to go away
		var activityIndicator = this.mainWindow().activityIndicators()[0];
		if (activityIndicator.isValid()) {
			UIALogger.logMessage("Waiting for 'Deleting...' activity indicator to go away");
			UIATarget.localTarget().pushTimeout(300); 
			var result = activityIndicator.waitForInvalid();  
			if (!result) UIALogger.logWarning("Activity indicator for delete account never went away!");
			UIATarget.localTarget().popTimeout();
		}
		
		// make sure there are less rows in the account table then when we started
		var accountsTableView = this.mainWindow().tableViews().firstWithPredicate("ANY cells.name BEGINSWITH '" + address + "'");
		
		try {
			if (!options.skipNavigation) {
				this.getToSpecifiedSetting(["Mail, Contacts, Calendars"]);
			}
		} catch (e) {
			throw new Error("Could not get to 'Mail, Contacts, Calendars' page to verify that email account was deleted.")
		}
		
		if (!accountsTableView.isValid()) {
			// could not find the table with that address cell, so we are good
			UIALogger.logMessage("Successfully deleted '" + address + "'");
			return;
		}
		
		if (accountsTableView.cells().length < initialAccountCount) {
			// found the table, but it has less cells in it, so we've
			// successfully removed a row
			UIALogger.logMessage("Successfully deleted '" + address + "'");
			return;
		}
		
		throw new Error("Tried to delete the account, but the number of cells in the account table did not decrease");
	}
	
	//----------------------------------------------------------------------------------------
	//	Function: deleteAllAccounts
	//		Deletes all Mail, Contact and Calendar accounts on the device
	//
	//	Parameters: 
	//		None
	//
	//	Returns: 
	//		None
	//
	//	Throws:
	//		Exception if the function isn't able to delete all accounts
	//----------------------------------------------------------------------------------------
	settings.deleteAllAccounts = function deleteAllAccounts() {
		UIALogger.logMessage("Deleting all email accounts");
		
		this.getToSpecifiedSetting(["Mail, Contacts, Calendars"]);
		
		var theTableView  = this._getTableViewWithChild({name:"Add Account…"});
		var subcalPresent = false;
		var cell;
		var lastCount;
		
		do {
			lastCount = theTableView.cells().length;
			
			// jump through hoops to avoid the subcal cell
			if (!subcalPresent) {
				cell = theTableView.cells()[0];
			}
			else {
				cell = theTableView.cells()[1];
			}
			
			if (cell.name() == "Add Account…") {
				UIALogger.logMessage("Got to Add Account, we are done");
				break; // kill our loop
			}
			else if (cell.name() == "Subscribed Calendars") {
				UIALogger.logMessage("Skipping subcal accounts for now");
				subcalPresent = true;
				continue;
			}
			
			this.deleteEmailAccount(cell.name(), {skipNavigation:true})
			
		} while (lastCount > theTableView.cells().length)
		
		// All other account types should be gone.  Now, we just need to deal with the 
		// subscribed calendars
		if (subcalPresent) {
			UIALogger.logMessage("Now dealing with subcal accounts");
			
			this.getToSpecifiedSetting(["Mail, Contacts, Calendars", "Subscribed Calendars"]);
			
			theTableView = this._getTableViewWithChild({predicate:"ANY cells.name contains 'Subscribed Calendar'"});
			
			do
			{
				lastCount = theTableView.cells().length;
				cell      = theTableView.cells()[0];
				
				cell.tap();
				
				this.deleteEmailAccount(cell.name(), {skipNavigation:true})
				
			} while (theTableView.isValid() && lastCount > theTableView.cells().length);
		}
		
		UIALogger.logMessage("All accounts removed");
	}
	
	//----------------------------------------------------------------------------------------
	//	Function: changeAccountPushBehavior
	//		This function can change the global and account-specific push settings 
	//
	//	Parameters: 
	//		(string) label - label of the account to be modified, or null to change the
	//						global settings
	//		(string) setting - ["push", "fetch", "manual"]
	//		(number) fetchFrequency - [-1, 15, 30, 60], or omit to leave frequency as-is
	//
	//	Returns: 
	//		None
	//
	//	Throws:
	//		If the account settings cannot be changed
	//		If the fetchFrequency argument is not valid
	//		If the push setting is not valid
	//----------------------------------------------------------------------------------------	
	settings.changeAccountPushBehavior = function changeAccountPushBehavior(label, setting, fetchFrequency) {
		var pushTableView;
		
		// first, get to the Fetch New Data view
		this.getToSpecifiedSetting(["Mail, Contacts, Calendars", "Fetch New Data"]);
		
		pushTableView = this._getTableViewWithChild({name:"Push"});
		
		// Set the fetch frequency if that argument was given
		if (typeof fetchFrequency != "undefined") {
			UIALogger.logMessage("Setting the fetch frequency");
			
			var choice;
			
			switch (fetchFrequency) {
				case -1: choice = "Manually";         break;
				case 15: choice = "Every 15 Minutes"; break;
				case 30: choice = "Every 30 Minutes"; break;
				case 60: choice = "Hourly";           break;
				default: throw new Error("Invalid fetch frequency '" + fetchFrequency + "'");
			}
			
			pushTableView.cells()[choice].tap();
		}
		
		// if the label is null, change the global setting
		if (label == null) {
			UIALogger.logMessage("Changing the global switch");
			
			this.setSwitchSetting("Push", Number(setting == "push"));
			
			return;
		}
		else if (setting == "push") {
			// this must be done if you want push to work
			UIALogger.logMessage("Changing the global switch to push");
			
			this.setSwitchSetting("Push", 1);
		}
		
		UIALogger.logMessage("Navigating to advanced settings");
		
		pushTableView.scrollToElementWithName("Advanced");
		pushTableView.cells()["Advanced"].tap();
		UIATarget.localTarget().delay(5);
		
		var table;
		
		// get the table of accounts, and then navigate to that account's settings
		table = this.mainWindow().tableViews().firstWithPredicate("ANY cells.name BEGINSWITH '" + label + "'");
		
		UIALogger.logMessage("Moving to settings for '" + label +"'");
		
		table.cells().firstWithPredicate("name BEGINSWITH '" + label + "'").tap();
		UIATarget.localTarget().delay(5);
		
		// finally, adjust the setting to be push, fetch, or manual
		UIALogger.logMessage("Choosing '" + setting + "'");
		
		table = this._getTableViewWithChild({name:"Manual"});
		
		var choice;
		
		switch (setting) {
			case "push":   choice = "Push";   break;
			case "fetch":  choice = "Fetch";  break;
			case "manual": choice = "Manual"; break;
			default: throw new Error("Invalid push setting '" + setting + "'");
		}
		
		try {
			table.cells().firstWithPredicate("name == '" + choice + "'").tap();
		}
		catch (e) {
			UIALogger.logMessage("Caught error: " + e.message);
			throw new Error("Could not adjust the settings for the account label '" + label + "'");
		}
	}
	
	//----------------------------------------------------------------------------------------
	//	Function: changePushNotificationBehavior
	//		This function can change the global and app-specific push notification settings 
	//
	//	Parameters: 
	//		settings (object) - object containing key-value pairs used to set the notifications
	//							An example setup: {"Notifications":1, 
	//											   "Angry Birds":{"Badges":1, "Alerts":0, "Sounds":1},
	//											   "Twitter":{"Badges":1, "Alerts":0, "Sounds":1}}
	//	Returns: 
	//		None
	//
	//	Throws:
	//		An exception if the settings cannot be changed
	//----------------------------------------------------------------------------------------	
	settings.changePushNotificationBehavior = function changePushNotificationBehavior(settings) {
		
		var settingsTable = this.getSettingsTable();
		
		if (settings["Notifications"]) {
			UIALogger.logMessage("Turning on notifications");
			this.setSwitchSetting("Notifications", settings["Notifications"]);
		} else {
			UIALogger.logMessage("Turning off all notifications");
			this.setSwitchSetting("Notifications", settings["Notifications"]);
			return;
		}
		
		for (app in settings) {
			if (app == "Notifications") continue;
			UIALogger.logMessage("Setting '" + app + "' notification.");
			settingsTable.cells()[app].tap();
			UIATarget.localTarget().delay(2);
			for (notification in settings[app]) {
				UIALogger.logMessage("Setting '" + notification + "' to " + settings[app][notification]);
				this.setSwitchSetting(notification, settings[app][notification]);
			}
			this.mainWindow().navigationBar().leftButton().tap();
			UIATarget.localTarget().delay(1);
		}
		
	}
	
	
	//----------------------------------------------------------------------------------------
	//	Function: getToSpecifiedSetting 
	//		Goes to the specified settings page, dismissing alerts,
	//		hitting cancel buttons, etc, first.
	//
	//	Parameters: 
	//		settingsArray (array) - array of strings indicating which settings to choose
	//
	//	Returns: 
	//		None
	//
	//	Throws:
	//		An exception if the function isn't able to get to the list of accounts
	//		in settings
	//----------------------------------------------------------------------------------------	
	settings.getToSpecifiedSetting = function getToSpecifiedSetting(settingsArray) {
		var finalNavigationView = settingsArray[settingsArray.length - 1];
		UIALogger.logMessage("Going to " + finalNavigationView + " settings");
		this.launchIfNotActive();
	
		UIATarget.localTarget().pushTimeout(1);
		
		// Hit the 'Done' button in Nav bar, if it is up
		var doneButton = this.navigationBar().buttons()["Done"];
		if (doneButton.isValid()) {
			UIALogger.logDebug("Tapping the 'Done' button in the naviation bar");
			doneButton.tap();
			UIATarget.localTarget().delay(1);
		}
		
		var actionSheet = this.actionSheet();
		if (actionSheet.isValid()) {
			var cancelButton = actionSheet.buttons()["Cancel"];
			if (cancelButton.isValid()) {
				UIALogger.logMessage("Tapping 'Cancel' button in an action sheet");
				cancelButton.tap();
				UIATarget.localTarget().delay(1);
			}
			var editButton = actionSheet.buttons()["Edit"];
			if (editButton.isValid()) {
				UIALogger.logMessage("Tapping 'Edit' button in an action sheet");
				editButton.tap();
				UIATarget.localTarget().delay(1);
			}
		}
		
		// Get out of set passcode popover
		if (UIATarget.localTarget().model() == "iPad") {
			var navBarCancelButton = this.mainWindow().popover().navigationBar().buttons()["Cancel"];
			if (navBarCancelButton.isValid()) {
				UIALogger.logMessage("Tapping the 'Cancel' button in the popover navigation bar -- probably for the passcode")
				navBarCancelButton.tap();
				UIATarget.localTarget().delay(1);
			}
		}
		
		UIATarget.localTarget().popTimeout();

		if (!this.navigateNavigationViews(settingsArray)) {
			throw new Error("Could not get to mail " + finalNavigationView + " settings.");
		}
	}
	
	//----------------------------------------------------------------------------------------
	//	Function: chooseSetting
	//		Navigate to a specified setting (by scrolling up and down), and clicks it.
	//
	//	Parameters: 
	//		settingChoice (string) - Setting to navigate to
	//
	//	Returns: 
	//		None
	//	
	//	Throws:
	//		An exception if the setting could not be found and tapped
	//----------------------------------------------------------------------------------------

	settings.chooseSetting = function chooseSetting(settingChoice) {
		var settingsTableElement;

		var settingsTable = this._getTableViewWithChild({name:settingChoice});
		settingsTableElement = settingsTable.cells().firstWithName(settingChoice);

		try{
			if (!settingsTableElement.isValid()) throw new Error("Could not scroll to Element: " + settingChoice);
			settingsTableElement.scrollToVisible();
			settingsTableElement.tap();
		} catch(e) {
			UIALogger.logError(e.message);
			throw new Error ("Could not find and tap setting: " + settingChoice);
		}
	} // end settings.chooseSetting

	//----------------------------------------------------------------------------------------
	//	Function: settingExists 
	//		Checks if the specified setting exists on the page
	//
	//	Parameters: 
	//		settingChoice (string) - Setting to check for
	//
	//	Returns: Returns the settings table element if found
	//	
	//	Throws:
	//		An error if the table element could not be found
	//----------------------------------------------------------------------------------------
	settings.settingExists = function settingExists(settingChoice) {

		var settingsTableElement = this._getTableViewWithChild({name:settingChoice}).scrollToElementWithName(settingChoice);
		if (!settingsTableElement.isValid()) throw new Error("Could not find top setting: " + settingChoice);
				
		UIALogger.logMessage("Found setting choice " + settingChoice);
		return settingsElement;

	}  // end settings.settingExists

	//----------------------------------------------------------------------------------------
	//	Function: chooseCheckmarkedItem
	//		Chooses the chosen check-marked item in a list
	//
	//	Parameters:		
	//		itemToCheck (string) - name of the item to check.
	//		viewsToNavigate (array) - an array containing the views to navigate to the item to check
	//
	//  Options:
    //      noValidation (string) - set to "true" if you want to skip validation.
    //          This is useful if the item doesn't show a checkmark after it's 
    //          selected.  (i.e. "Mail, Contacts, Calendars" -> "My Info")
    //
	//	Returns: 
	//		None
	//
	//	Throws:
	//		An error if the specified element does not have a checkmark
	//----------------------------------------------------------------------------------------
	settings.chooseCheckmarkedItem = function chooseCheckmarkedItem(itemToCheck, viewsToNavigate, options) {
		
		UIALogger.logMessage("Navigating the view hierarchy with path: " + viewsToNavigate.join( " -> " ) );
		
		try {
			settings.navigateNavigationViews(viewsToNavigate, {returnToTopLevel:true});
		} catch (e) {
			UIALogger.logError(e.message);
			throw new Error ("Failed to navigate settings to final level: " + itemToCheck);
		}
		
		UIALogger.logMessage("Choosing " + itemToCheck );			
		
		try {
			settings.chooseSetting(itemToCheck);
		} catch (e) {
			UIALogger.logError(e.message);
			throw new Error("Could not choose setting: " + itemToCheck);
		}
		
		if ((options.noValidation == 1) || (options.noValidation == "true")) {
		    UIALogger.logDebug("No validation is being done on checkmarked item.");
		}
		else {
		    UIALogger.logDebug("Checking for check mark next to item.")
		    if (!settings.isMarkedWithCheckMark(itemToCheck)) {
			    throw new Error("Item is not marked with a checkmark '" + itemToCheck + "'");
		    }
		}
					
	} // end chooseCheckmarkedItem		
	
	//----------------------------------------------------------------------------------------
	//	Function: isMarkedWithCheckMark
	//		Takes an element name, finds the element, and verifies 
	//		that the element has been marked with a checkmark.  This method does not tap the 
	//		element, only verifies that it has a checkmark.
	//
	//	Parameters:		
	//		elementName (string) - name of the element to verify.
	//
	//	Returns: 
	//		None
	//
	//	Throws:
	//		An error if the specified element does not have a checkmark
	//----------------------------------------------------------------------------------------
	settings.isMarkedWithCheckMark = function isMarkedWithCheckMark(elementName) {
		
		var settingsElement = this._getTableViewWithChild({name:elementName}).scrollToElementWithName(elementName);
		if (settingsElement.isValid()) {
			if (settingsElement.value() == 1) {
				UIALogger.logMessage(arguments.callee.name + ": " + elementName + " has a check mark.");
				return true;
			} else {
				UIALogger.logMessage(arguments.callee.name + ": " + elementName + " does not have a check mark.");
				return false;
			}
		} else {
			throw new Error(arguments.callee.name + ": Could not find element '" + elementName + "'");
		}
	} //end settings.isMarkedWithCheckMark
	
	
	//----------------------------------------------------------------------------------------
	//	Function: changeSingleSwitch
	//		Changes a switch in settings (or verifies that the the switch is already set to the desired value).
	//
	//	Parameters:
	//		viewsToNavigate (array) - An array containing the path that should be followed to
	//									reach the switch to change. Each element will correspond
	//									to a table cell to tap.  By default, the test will 
	//									return to the top level of the navigation hierarchy before 
	//									attempting to navigate to the table containing the switch
	//									to change.
	//		switchName (string) - The name of the switch to change.
	//		switchValue (string) - The value that the switch should be set to:
	//									0: OFF 
	//									1: ON	
	//
	//	Throws:
	//		An error if the specified element does not have a checkmark
	//----------------------------------------------------------------------------------------
	settings.changeSingleSwitch = function changeSingleSwitch(viewsToNavigate, switchName, switchValue) {
		UIALogger.logMessage("Navigating the view hierarchy with path: " + viewsToNavigate.join( " -> " ) );
		
		try {
			this.navigateNavigationViews(viewsToNavigate, {returnToTopLevel:true});
		} catch (e) {
			UIALogger.logError(e.message);
			throw new Error("Could not navigate to '" + switchName + "'");
		}
		
		try {
			this.setSwitchSetting(switchName, switchValue);
		} catch (e) {
			UIALogger.logError(e.message);
			throw new Error("Could not change the switch setting '" + switchName + "' to '" + switchValue + "'");
		}
		
		return;
		
	} // end settings.changeSingleSwitch
	
	//----------------------------------------------------------------------------------------
	//	Function: setSwitchSetting 
	//		Sets switch to desired value. If switch is
	//		already at the value, this function does nothing.  It assumes we're already on the
	//		correct place in settings.
	//
	//	Parameters: 
	//		switchName (string) - Name of the switch to set.
	//		desiredSetting (string) - Value to set the switch to.  (0 or 1) 
	//									0: OFF 
	//									1: ON
	//
	//	Returns: 
	//		None
	//	
	//	Throws:
	//		An error if the switch could not be set
	//----------------------------------------------------------------------------------------
	settings.setSwitchSetting = function setSwitchSetting(switchName, desiredSetting) {
		
		var desiredSetting = parseInt(desiredSetting);
		var settingsTable;
		
		// Blah, special case to account for split views with multiple tables with cells that are named the same
		var numberOfTables = this.mainWindow().tableViews().withPredicate("ANY cells.name == '" + switchName + "'").length;
		UIALogger.logDebug("Number of tables: " + numberOfTables);
		if (numberOfTables > 1) {
			for (var i = 0; i < numberOfTables; i++ ) {
				var tempTable = this.mainWindow().tableViews()[i];
				UIALogger.logDebug("tempTable: " + tempTable.logElementTree());
				if ( tempTable.cells().firstWithName(switchName).switches().length != 0) settingsTable = tempTable;
			}
		} else {
			settingsTable = this._getTableViewWithChild({name:switchName});
		}
		
		var settingsTableElement = settingsTable.cells().firstWithName(switchName);
		settingsTableElement.scrollToVisible();
		if (!settingsTableElement.checkIsValid()) {
			throw new Error(arguments.callee.name + "Could not scroll to element: " + switchName);
		}

		//Get current value and check if value is already set
		var elementSwitch = settingsTableElement.switches()[0];
		if (elementSwitch.withValueForKey(desiredSetting, "value").checkIsValid()){
			UIALogger.logMessage( arguments.callee.name + ": Switch value already set to " + desiredSetting );
			return;
		} else {
//			elementSwitch.setValue(desiredSetting);
			settingsTableElement.switches()[0].setValue(desiredSetting);
		}
		elementSwitch = settingsTableElement.switches()[0];
		//Verify that desiredSetting is indeed the new value
		if (elementSwitch.withValueForKey(desiredSetting, "value").isValid()){
			UIALogger.logMessage( arguments.callee.name + ": Switch value set to " + desiredSetting );
			return;
		} 
		settingsTable.logElementTree();
		throw new Error( arguments.callee.name + ": Could not set switch value set to " + desiredSetting );



	} // end settings.setSwitchSetting

	//----------------------------------------------------------------------------------------
	//	Function: setSliderSetting 
	//		Sets slider to desired value. If slider is already at the value, this function does nothing.  
	//		It assumes we're already on the correct place in settings.
	//		
	//
	//	Parameters: 
	//		sliderName (string) - Name of the slider to set.
	//		desiredSetting (float) - Value to set the slider to: 0.0 -> 1.0
	//
	//	Returns: 
	//		None
	//	
	//	Throws:
	//		An error if the slider could not be set
	//----------------------------------------------------------------------------------------
	settings.setSliderSetting = function setSliderSetting(sliderName, desiredSetting) {
		if (typeof desiredSetting == 'string') desiredSetting = parseFloat(desiredSetting);

		var settingsTable = this._getTableViewWithChild({name:sliderName});
//		var settingsTableElement = settingsTable.cells().firstWithName(sliderName);

		// Using a predicate to search for the cell until [<rdar://problem/8192419> Name of slider and containing table cell changes after using dragToValue] is fixed
		var settingsTableElement = settingsTable.cells().firstWithPredicate("name contains[cd] '" + sliderName + "'");
		settingsTable.cells()[sliderName].scrollToVisible();
		if (!settingsTableElement.isValid()) {
			throw new Error(arguments.callee.name + ": Could not scroll to element: " + sliderName);
		}
		
		//Get current value and check if value is already set
		var elementSlider = settingsTableElement.sliders()[0];
		
		if (elementSlider.withValueForKey(desiredSetting, "value").isValid()){
			UIALogger.logMessage( arguments.callee.name + ": Slider value already set to " + desiredSetting );
			return;
		} else {
			elementSlider.dragToValue(desiredSetting);
		}

		desiredSetting = (desiredSetting * 100) + "%";
		//Verify that desiredSetting is indeed the new value
		if (elementSlider.withValueForKey(desiredSetting, "value").isValid()){
			UIALogger.logMessage( arguments.callee.name + ": Slider value set to " + desiredSetting );
			return;
		} 
		UIALogger.logMessage("Slider value is currently: " + elementSlider.value() + ".  The value should be: " + desiredSetting);
		//Removing the exception until [<rdar://problem/8192362> dragToValue does not drag to precise value] is fixed
//		throw new Error( arguments.callee.name + ": Could not set slider value set to " + desiredSetting );
		
	} // end settings.setSwitchSetting
	
	
	
	//----------------------------------------------------------------------------------------
	//	Function: chooseFromList 
	//		Chooses a string from a list, in the case where there is
	//		a list of separate items to choose from on the next page.  (For example, this 
	//		could be used to specify a language from the list of languages or an Auto-Lock option.)
	//
	//	Parameters: 
	//		settingName (string) - Name of the setting to change.
	//		desiredSetting (string) - Value to set the setting to (must be in a list).
	//	
	//	Optional Parameters:
	//		noValidation (bool) - Do not validate the change (usefulness limited mainly to changing languages
	//			in Settings, since the UI changes as soon as the language is set)
	//
	//	Returns: 
	//		None
	//
	//	Throws:
	//		An error if the setting could not be set
	//----------------------------------------------------------------------------------------
	settings.chooseFromList = function chooseFromList(settingName, desiredSetting, options) {

		
		UIALogger.logMessage(arguments.callee.name + ": Setting " + settingName + " to " + desiredSetting);
		UIATarget.localTarget().pushTimeout(1);

		var settingsTable = this._getTableViewWithChild({name:settingName});
		var settingsTableElement = settingsTable.cells()[settingName];
		settingsTableElement.scrollToVisible();

		if (!settingsTableElement.isValid()){
			UIATarget.localTarget().popTimeout();
			throw new Error(arguments.callee.name + ": Could not scroll to " + settingName);
		}

		if (settingsTableElement.withValueForKey(1, settingName).isValid()){
			UIATarget.localTarget().popTimeout();
			UIALogger.logMessage(arguments.callee.name + ":  " + settingName + " already set to " + desiredSetting );
			return;
		}

		try{
			settingsTableElement.tap();
		} catch(e) {
			UIATarget.localTarget().popTimeout();			
			throw new Error(arguments.callee.name + ": Could not select " + settingName + " to change setting." );
		}

		UIATarget.localTarget().delay(1);	
		var setting = settingsTable.cells()[desiredSetting];
		setting.scrollToVisible();
		
		if (!setting.isValid()){
			UIATarget.localTarget().popTimeout();			
			throw new Error(arguments.callee.name + ": Could not scroll to " + desiredSetting);
		}

		try {
			 settingsTable.elements()[desiredSetting].tap();
		} catch(e) {
			UIATarget.localTarget().popTimeout();			
			throw new Error(arguments.callee.name + ": Could not select " + desiredSetting + " setting." );
		}

		//Try to return to the previous navigation view by first attempting to tap 'Done'
		//and if it doesn't exist, try to return tap the back button
		try{
			var doneButton = this.mainWindow().navigationBar().buttons().firstWithName("Done");
			if (doneButton.isValid()) doneButton.tap();
			else this.mainWindow().navigationBar().leftButton().tap();
		} catch(e) {
			UIALogger.logMessage(e.message);
			UIATarget.localTarget().popTimeout();
			throw new Error(arguments.callee.name + ": Could not tap back button to return to General settings view." );
		}

		if (options && options.noValidation) return;
		settingsTableElement = settingsTable.cells()[settingName];
		settingsTableElement.scrollToVisible()
		
		if (!settingsTableElement.isValid()) {
			UIATarget.localTarget().popTimeout();			
			throw new Error(arguments.callee.name + ": Could not scroll to " + settingName + " to determine if we successfully set the value" );
		}
		
		if ( settingsTableElement.value() == desiredSetting ){
			UIALogger.logMessage(arguments.callee.name + ": Succesfully set " + settingName + " to " + desiredSetting );
			UIATarget.localTarget().popTimeout();			
			return;
		} 

		UIATarget.localTarget().popTimeout();
		throw new Error(arguments.callee.name + ": Could not set " + settingName + " to " + desiredSetting );

	} // end settings.chooseFromList

	//----------------------------------------------------------------------------------------
	//	_settings._typeNumber - Internal function used by the setPasscode and turnPasscodeOff
	//								methods 
	//
	//	Parameters: 
	//		number (string) - passcode to enter
	//	
	//	Returns: throws an error if the number could not be tapped
	//----------------------------------------------------------------------------------------	
	settings._typeNumber = function _typeNumber(number) {
		UIATarget.localTarget().delay(3);	
		
		var navBar;
		if (UIATarget.localTarget().model() == 'iPad') {
			navBar = this.mainWindow().popover().navigationBar();
		}
		else {
			navBar = this.mainWindow().navigationBar();
		}
		if (!navBar.staticTexts().firstWithPredicate("name endswith 'Passcode'").isValid()) {
			throw new Error("Nav bar name did not change.");
		}
		
		for (var i = 0; i < number.length; i++) {
			var digit = number[i];

			UIALogger.logMessage("Tapping '" + digit + "'");				
			try{
				if (UIATarget.localTarget().model() == "iPad") {
					if (!this.mainWindow().popover().keyboard().isValid()) {
						this.mainWindow().logElementTree();
						throw new Error("Could not find keypad");
					} else {
						this.mainWindow().popover().keyboard().elements().firstWithName(digit).tap();
					}
				} else {
					if (!this.keyboard().isValid()) {
						this.mainWindow().logElementTree();
						throw new Error("Could not find keypad");
					} else {
						this.keyboard().elements().firstWithName(digit).tap();
					}
				}
			} catch(e) {
				throw new Error("Could not tap '" + digit + "'");
			} 
			
			UIATarget.localTarget().delay(1);	
		} 
		
	} // end settings._typeNumber
	

	//----------------------------------------------------------------------------------------
	//	Function: setPasscode 
	//		Sets the passcode. NOTE: If no passcode is specified as an argument, 
	//		this will call settings.turnPasscodeOff
	//		
	//
	//	Parameters: 
	//		passcode (string) - passcode to enter
	//	
	//	Optional Parameters:
	//		currentPasscode (string) - provide the current passcode to set a passcode
	//
	//	Returns:
	//		None
	//
	//	Throws:
	//		An error if the passcode code could not be set
	//----------------------------------------------------------------------------------------	
	settings.setPasscode = function setPasscode(passcode, currentPasscode) {
		if (!passcode) {
			this.turnPasscodeOff();	
			return;
		} 
		var passcodeSet = false;
		settings.getToSpecifiedSetting(["General"]);
	
		var settingsTable = this._getTableViewWithChild({name:"Passcode Lock"});
settingsTable.logElementTree();
		var passcodeLockElement = settingsTable.scrollToElementWithName("Passcode Lock");

		// Scroll the table to the Passcode Lock table cell
		if (!passcodeLockElement.isValid()) {
			throw new Error("Could not scroll to 'Passcode Lock' table element");
		}
		
		UIATarget.localTarget().delay(1);
		
		// Check the status of the passcode lock - if it's off, then turn it on
		if (passcodeLockElement.value() == "Off"){

			UIALogger.logMessage("No passcode lock set.");
settingsTable.logElementTree();	
			// Tap the Passcode Lock table cell
			try {
				passcodeLockElement.tap();
			} catch (e) {
				UIALogger.logError(e.message);
				throw new Error("Could not tap the 'Passcode Lock' table element");
			}
			
			//Give the animation a chance to stop
			UIATarget.localTarget().delay(1);
			if (UIATarget.localTarget().model() == 'iPad') {
				settingsTable = this.mainWindow().tableViews()[1];
			} else {
				settingsTable = this.mainWindow().tableViews()[0];
			}
			
			var turnPasscodeOnButton = settingsTable.cells().firstWithName("Turn Passcode On");
			// Tap the Turn Passcode On button
			try {
				if (turnPasscodeOnButton.isValid()) turnPasscodeOnButton.tap();
			}catch(e){
				UIALogger.logError(e.message);
				throw new Error("Could not tap the 'Turn Passcode On' button");
			}
			
			// Check the navigation bar name 
			var navBar;
			if (UIATarget.localTarget().model() == "iPad") {
				navBar = this.mainWindow().popover().navigationBar().withName("Set Passcode");
			}
			else {
				navBar = this.navigationBar().withName("Set Passcode");
			}
			if (!navBar.isValid()) {
				settingsTable.logElementTree();
				throw new Error("Nav bar name did not change to 'Set Passcode'");
			}

			try {
				// Type in the passcode to set
				this._typeNumber(passcode);
				// Type the passcode in a second time to verify
				this._typeNumber(passcode);
			} catch (e) {
				UIALogger.logError(e.message);				
				throw new Error("Could not type passcode");
			}
			
		} else {

			// Otherwise, change the passcode
			UIALogger.logMessage("Passcode lock already set - changing passcode.");
			try {	
				passcodeLockElement.tap();
			} catch (e) {
				UIALogger.logDebug("Where the hell am I");
				UIALogger.logError(e.message);
				return false;
			}
			UIATarget.localTarget().delay(2);
			if (currentPasscode) _settings_passcode = currentPasscode;
			
			// Type in the existing passcode so that we can change it
			try {
				this._typeNumber(_settings_passcode);
			} catch (e) {
				UIALogger.logError(e.message);
				throw new Error("Could not type passcode");
			}
			if (UIATarget.localTarget().model() == 'iPad') {
				settingsTable = this.mainWindow().tableViews()[1];
			} else {
				settingsTable = this.mainWindow().tableViews()[0];
			}			
			var changePasscodeCell = settingsTable.cells().firstWithName("Change Passcode");
			
			try {
				changePasscodeCell.tap();
			} catch(e) {
				UIALogger.logError(e.message);
				throw new Error("Failed to tap 'Change Passcode'");
			}

			try {
				// Type in the old passcode to change
				this._typeNumber(_settings_passcode);
				// Type in the new passcode to set
				this._typeNumber(passcode);
				// Type the new passcode in a second time to verify
				this._typeNumber(passcode);
			} catch (e) {
				UIALogger.logError(e.message);				
				throw new Error("Could not type passcode");
			}

		} //end if - else 

		//Return to the topmost level of the Settings hierarchy and navigate back to the General nav view
		try {
			this.returnToTopLevel();
			this.chooseSetting("General");
		} catch (e) {
			UIALogger.logError(e.message);			
			throw new Error("Could not return to the General Settings view.");
		}

		if (UIATarget.localTarget().model() == 'iPad') {
			settingsTable = this.mainWindow().tableViews()[1];
		} else {
			settingsTable = this.mainWindow().tableViews()[0];
		}
		
		//Scroll to the Passcode lock table cell
		passcodeLockElement = settingsTable.scrollToElementWithName("Passcode Lock");
		if (!passcodeLockElement.isValid()) {
			throw new Error("Could not scroll to the Passcode Lock table cell.");
		}

		//Is the passcode lock off?
		if (passcodeLockElement.value() == "Off" ){
			throw new Error("Did not set the Passcode Lock.");
		} 
		_settings_passcode = passcode;
		UIALogger.logMessage("Successfully set the Passcode Lock.");
		return;

	} // end settings.setPasscode

	//----------------------------------------------------------------------------------------
	//	Function: turnPasscodeOff 
	//		Turns the passcode off.
	//
	//	Parameters: 
	//		passcode (int) - passcode to enter
	//	
	//	Returns: 
	//		None
	//	
	//	Throws:
	//		An error if the passcode cannot be turned off
	//----------------------------------------------------------------------------------------		
	settings.turnPasscodeOff = function turnPasscodeOff(passcode) {
		if (!passcode) passcode = _settings_passcode;

		// Return to the top-most view in the hierarchy
		settings.getToSpecifiedSetting(["General"]);		

		var settingsTable = this._getTableViewWithChild({name:"Passcode Lock"});
		var passcodeLockElement = settingsTable.scrollToElementWithName("Passcode Lock");

		// Scroll the table to the Passcode Lock table cell
		if (!passcodeLockElement.isValid()) {
			throw new Error(arguments.callee.name + ": Could not scroll to 'Passcode Lock' table element");
		}
		
		UIATarget.localTarget().delay(1);	
		
		// Check the status of the passcode lock - if it's on, then turn it off
		if (passcodeLockElement.value() == "On"){

			UIALogger.logMessage(arguments.callee.name + ": Turning passcode lock off.");
	
			// Tap the Passcode Lock table cell
			try {
				passcodeLockElement.tap();
			} catch (e) {
				UIALogger.logError(e.message);				
				throw new Error(arguments.callee.name + ": Could not tap the 'Passcode Lock' table element");
			}

			try {
				this._typeNumber(passcode);
			} catch (e) {
				UIALogger.logError(e.message);				
				throw new Error(arguments.callee.name + ": Could not type passcode");
			}			
			if (UIATarget.localTarget().model() == 'iPad') {
				settingsTable = this.mainWindow().tableViews()[1];
			} else {
				settingsTable = this.mainWindow().tableViews()[0];
			}
			
			var turnPasscodeOffButton = settingsTable.elements()["Turn Passcode Off"];

			// Tap the Turn Passcode Off button
			try {
				turnPasscodeOffButton.tap();
			}catch(e){
				UIALogger.logError(e.message);				
				throw new Error(arguments.callee.name + ": Could not tap the 'Turn Passcode Off' button");
			}
			
			UIATarget.localTarget().delay(2);

			try {
				this._typeNumber(passcode);
			} catch (e) {
				UIALogger.logError(e.message);				
				throw new Error(arguments.callee.name + ": Could not type passcode");
			}
			
		} else {
			UIALogger.logMessage(arguments.callee.name + ": Passcode already off");
			return;
		} //end if - else 


		//Return to the topmost level of the Settings hierarchy and navigate back to the General nav view
		try {
			this.returnToTopLevel();
			this.chooseSetting("General");
		} catch (e) {
			UIALogger.logError(e.message);			
			throw new Error(arguments.callee.name + ": Could not return to the General Settings view.");
		}

		if (UIATarget.localTarget().model() == 'iPad') {
			settingsTable = this.mainWindow().tableViews()[1];
		} else {
			settingsTable = this.mainWindow().tableViews()[0];
		}
		
		//Scroll to the Passcode lock table cell
		passcodeLockElement = settingsTable.scrollToElementWithName("Passcode Lock");
		if (!passcodeLockElement.isValid()) {
			throw new Error(arguments.callee.name + ": Could not scroll to the Passcode Lock table cell.");
		}

		//Is the passcode lock off?
		if (passcodeLockElement.value() == "On" ){
			throw new Error(arguments.callee.name + ": Did not turn the Passcode Lock off.");
		} 

		UIALogger.logMessage(arguments.callee.name + ": Successfully turned the Passcode Lock off.");


	}  // end settings.turnPasscodeOff


	//----------------------------------------------------------------------------------------
	//	Function: setDateAndTime
	//		sets the system date and time.  Be forewarned, setting the system date and time
	//		can have all kinds of weird side effects. We have tried to minimize these effects
	//		and have given the option to set the date and time via command line functions or
	//		via the Settings UI.  The command line option is used by default.
	//		
	//
	//	Parameters: 
	//		date ( Date object ) - The date and time to set
	//	
	//	Optional Parameters: 
	//		date (int) - (1 or 0) set the date (by default, this is true)
	//		time (int) - (1 or 0) set the time (by default, this is true)
	//		setViaUI (int) - (1 or 0) set the date and/or time via the Settings UI.  By default
	//						 the date and time are set via the command line tools 'date' and
	//						 'loctool' 
	//						 
	//
	//	Returns: 
	//		None
	//	
	//	Throws:
	//		An error if the wallpaper cannot be set
	//----------------------------------------------------------------------------------------		
	settings.setDateAndTime = function setDateAndTime(date, options) {
		
		if (!options) options = new Object();
		var setDate = (typeof options.date != 'undefined') ? options.date : 1;
		var setTime = (typeof options.time != 'undefined') ? options.time : 1;
		var setViaUI = (typeof options.setViaUI != 'undefined') ? options.setViaUI : 0;
		if (!date) throw new Error("No date provided");

		// Conversion array for JS getMonth() method
		var months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];	
		var picker;
		var table;
		var scrollDirection;

		if (setViaUI) {

			// Get the table element
			table = this.mainWindow().tableViews().firstWithPredicate("isVisible == 1");
			
			
			// Get to the 'Date & Time' table View
			try {
				this.navigateNavigationViews(["General", "Date & Time"], {returnToTopLevel:true});
			} catch (e) {
				UIALogger.logError(e.message);
				throw new Error("Could not navigate to 'Set Date & Time'");
			}
			
			// Turn off the 'Set Automatically' button on iPhones, if needed
			if (this.mainWindow().tableViews()[0].cells()["Set Automatically"].isValid()) {
				this.setSwitchSetting("Set Automatically", "0");
			}
			
			if (table.cells()["Set Date & Time"].isValid()) table.cells()["Set Date & Time"].tap();
			
			// Give any animations to cease
			UIATarget.localTarget().delay(3);

			// Set the time
			if (setTime) {
				table = this.mainWindow().tableViews().firstWithPredicate("isVisible == 1");
				table.cells()[1].tap();
				
				// Don't start spinning the scroll wheels just yet
				UIATarget.localTarget().delay(2);
				
				picker = this.mainWindow().pickers()[0];
				
				// Necessary time conversions
				var hours = (date.getHours() > 12) ? date.getHours() - 12 : date.getHours();
				if (hours == 0) hours = 12;
				var minutes = (date.getMinutes() < 10) ? "0" + date.getMinutes() : date.getMinutes();
				
				// Is the time AM (ante meridian) or PM (post meridian).  The JS object returns 0-23, so it needs converting
				var meridian = (date.getHours() > 12) ? "PM" : "AM";
				
				
				UIALogger.logMessage("Setting the time picker to:  " + hours + ", " + minutes + ", " + meridian);
				if (picker.checkIsValid()) {
					UIAUtility.scrollWheelToValueWithOptions(picker.wheels()[0], new UIAPredicateString("value beginswith '" + hours + " '"), {useSleep:1});
					UIAUtility.scrollWheelToValueWithOptions(picker.wheels()[1], new UIAPredicateString("value beginswith '" + minutes + "'"), {useSleep:1});
					
					if (picker.wheels()[2].value().match(/AM/) && !picker.wheels()[2].value().match(meridian)) scrollDirection = 1;
					if (picker.wheels()[2].value().match(/PM/) && !picker.wheels()[2].value().match(meridian)) scrollDirection = 0;
					 
					UIALogger.logDebug("Scroll direction: " + scrollDirection);
					UIAUtility.scrollWheelToValueWithOptions(picker.wheels()[2], new UIAPredicateString("value beginswith '" + meridian + "'"), {direction:scrollDirection, useSleep:1});
				} else {
					this.logElementTree();
					throw new Error("Could not find the time picker");
				}
			} // end if
			
			// Set the date
			if (setDate) {
				table = this.mainWindow().tableViews().firstWithPredicate("isVisible == 1");
				table.cells()[0].tap();
				
				// Don't start spinning the scroll wheels just yet
				UIATarget.localTarget().delay(2);

				picker = this.mainWindow().pickers()[0];
				UIALogger.logMessage("Setting the date picker to: " + months[date.getMonth()] + ", " + date.getDate() + ", " + date.getFullYear());


				if (picker.checkIsValid()) {
					UIAUtility.scrollWheelToValueWithOptions(picker.wheels()[0], months[date.getMonth()], {useSleep:1});
					scrollDirection = (date.getDate() < picker.wheels()[1].value()) ? 0	: 1;
					UIAUtility.scrollWheelToValueWithOptions(picker.wheels()[1], date.getDate(), {direction:scrollDirection, useSleep:1});

					scrollDirection = (date.getFullYear() < picker.wheels()[2].value()) ? 0	: 1;
					UIAUtility.scrollWheelToValueWithOptions(picker.wheels()[2], date.getFullYear(), {direction:scrollDirection, useSleep:1});
				} else {
					this.logElementTree();
					throw new Error("Could not find the date picker");
				}
			} // end if
		} else {
	 
			var result = system.run("/bin/date -f \"%s\"" + (date.getTime()/1000)).stdout
			UIALogger.logDebug("Set time to " + result);
			system.run("/usr/local/bin/loctool notify SignificantTimeChangeNotification");
			UIALogger.logDebug("Posted notification SignificantTimeChangeNotification");
			return;
		}
		
	} // end settings.setDateAndTime
	
	//----------------------------------------------------------------------------------------
	//	Function: setTimeZone 
	//		Sets time zone
	//
	//	Parameters: 
	//		timeZoneLocation ( string ) - name of a location to search for.  If it is a city,
	//										do not include the state.  E.g, "Denver", not "Denver, CO"
	//	
	//	Returns: 
	//		None
	//	
	//	Throws:
	//		An error if the wallpaper cannot be set
	//----------------------------------------------------------------------------------------		
	settings.setTimeZone = function setTimeZone(timeZoneLocation) {

		// Get to the 'Date & Time' table View
		try {
			this.navigateNavigationViews(["General", "Date & Time"], {returnToTopLevel:true});
		} catch (e) {
			UIALogger.logError(e.message);
			throw new Error("Could not navigate to 'Set Date & Time'");
		}
		
		// Turn off the 'Set Automatically' button on iPhones, if needed
		if (this.mainWindow().tableViews()[0].cells()["Set Automatically"].isValid()) {
			this.setSwitchSetting("Set Automatically", "0");
		}
		
		// Get the table element
		table = this.mainWindow().tableViews().firstWithPredicate("ANY cells.name == 'Time Zone'");
		table.cells()["Time Zone"].tap();
		
		// Give any animations to cease
		UIATarget.localTarget().delay(1);

		var searchBar = this.mainWindow().searchBars()[0];
		table = this.mainWindow().tableViews().firstWithPredicate("not ANY cells.name contains 'General'");
		if (!table.checkIsValid()) throw new Error("Could not find the search results table");
		UIALogger.logMessage("this._escapeQuotes(timeZoneLocation): " + this._escapeQuotes(timeZoneLocation)); 
		var result = table.cells().firstWithPredicate("name contains '" + this._escapeQuotes(timeZoneLocation) + "'");
		if (result.isValid()) {
			UIALogger.logMessage("Time Zone location already set to: " + result.name());
			return;
		}
		
		// Clear the search bar
		searchBar.buttons()[0].tap();
		
		this.search(timeZoneLocation);
		
		// Wait a few seconds for results to appear
		UIATarget.localTarget().delay(3);
			
		table.logElementTree();
		if (table.cells().length < 1) throw new Error("Search did not return any results");


		result = table.cells().firstWithPredicate("name contains '" + this._escapeQuotes(timeZoneLocation) + "'");
		if (!result.isValid()) throw new Error("Did not find " + timeZoneLocation + " in the search results");
		result.tap();
		
		return;
		
	} // end setTimeZone
	
	
	
	//----------------------------------------------------------------------------------------
	//	Function: selectWallpaper 
	//		Selects a wallpaper from the wallpaper thumbnails. No validation is performed here
	//
	//	Parameters: 
	//		photoChoice ( string ) - The album (if any) to choose a wallpaper from.  
	//			Defaults to "Wallpaper"
	//	
	//	Returns: 
	//		None
	//	
	//	Throws:
	//		An error if the wallpaper cannot be set
	//----------------------------------------------------------------------------------------		
	settings.selectWallpaper = function selectWallpaper(photoChoice) {
		if (!photoChoice) photoChoice = "Wallpaper";
		var wallpaperTableCellName = "Wallpaper";
		if (UIATarget.localTarget().model() == 'iPad')
			wallpaperTableCellName = "Brightness & Wallpaper";
		
		// Return to the top most level in the navigation view hierarchy
		this.returnToTopLevel();
		
		UIALogger.logMessage("Scrolling to '" + wallpaperTableCellName + "' table cell");

		this.chooseSetting(wallpaperTableCellName);

		UIATarget.localTarget().delay(2);
		// Determine if we can set the home screen background 
		if (system.hasCapability("homescreen-wallpaper")) {
			UIALogger.logMessage("Tapping 'Change wallpaper...'");
			this._getTableViewWithChild({name:"Change wallpaper…"}).cells().firstWithName("Change wallpaper…").tap();
		}
		
		UIATarget.localTarget().delay(2);
		var photoChoiceCell = this._getTableViewWithChild({name:photoChoice}).cells().firstWithName(photoChoice);
		
		if (photoChoiceCell.isValid()) {
			UIALogger.logMessage("Choosing '" + photoChoice + "' album");
			this._getTableViewWithChild({name:photoChoice}).cells().firstWithName(photoChoice).tap();
		}
		
		UIATarget.localTarget().delay(2);
		UIALogger.logMessage("Choosing thumbnail...");

		//non-iPad specific thumbnail view
		if (UIATarget.localTarget().model() != 'iPad')  {
			var numberOfThumbnailRows = this._getTableViewWithChild({name:photoChoice}).cells().length - 2;
		
			if (numberOfThumbnailRows == 0) throw new Error(arguments.callee.name + ": Could not find a thumbnail on the page");

			// choose a random row, and account for the last table cell with the total number of thumbnails
			var rowIndex = system.randomInteger(0, numberOfThumbnailRows);

			// choose a random column/image
			this._getTableViewWithChild({name:photoChoice}).cells()[rowIndex].scrollToVisible();
			var numberOfThumbnailColumns = this._getTableViewWithChild({name:photoChoice}).cells()[rowIndex].images().length;
			var columnIndex = system.randomInteger(0, numberOfThumbnailColumns - 1);

			UIALogger.logMessage(arguments.callee.name + ": Attempting to tap thumbnail at row: " + rowIndex + " and column: " + columnIndex + ".");
		
			try {
				this._getTableViewWithChild({name:photoChoice}).cells()[rowIndex].images()[columnIndex].tap();
			} catch(e) {
				throw new Error(arguments.callee.name + ": Could not tap the thumbnail");
			}

			var setButton = this.mainWindow().buttons().firstWithName("Set");
			UIATarget.localTarget().delay(1);
			try {
				setButton.tap();
			} catch(e) {
				UIATarget.localTarget().popTimeout();
				throw new Error(arguments.callee.name + ": Could not tap the 'Set' button.");
			}

		} else {
			var numberOfThumbnails = this.mainWindow().scrollViews()[0].buttons().length;
			
			if (numberOfThumbnails == 0) throw new Error(arguments.callee.name + ": Could not find a thumbnail on the page");
			
			// choose a random row, and account for the last table cell with the total number of thumbnails
			var thumbnailIndex = system.randomInteger(0, numberOfThumbnails);
			
			// choose a random column/image
			this.mainWindow().scrollViews()[0].buttons()[thumbnailIndex].scrollToVisible();
			UIALogger.logMessage(arguments.callee.name + ": Attempting to tap thumbnail at index: " + thumbnailIndex + " with name: " + this.mainWindow().scrollViews()[0].buttons()[thumbnailIndex].name());
			
			try {
				this.mainWindow().scrollViews()[0].buttons()[thumbnailIndex].tap();
			} catch(e) {
				throw new Error(arguments.callee.name + ": Could not tap the " + this.mainWindow().scrollViews()[0].buttons()[thumbnailIndex].name() + " thumbnail");
			}
		}			
			
		// If the system under test is does not support home screen wallpapers, then we can skip the next part
		if (system.hasCapability("homescreen-wallpaper")) {
			var setBothButton;
			UIALogger.logMessage("Setting both the homescreen and lock screen.");
			if (UIATarget.localTarget().model() != 'iPad')
				setBothButton = this.actionSheet().buttons().firstWithName("Set Both");
			else 
				setBothButton = this.navigationBar().buttons().firstWithName("Set Both");

			UIATarget.localTarget().delay(1);
			try {
				setBothButton.tap();
			} catch(e) {
				UIATarget.localTarget().popTimeout();
				throw new Error(arguments.callee.name + ": Could not tap the 'Set Both' button to set the Lock Screen and Home Screen wallpaper.");
			}
		}
		
		UIALogger.logMessage(arguments.callee.name + ": Done setting the wallpaper");
		
	} //end settings.selectWallpaper
	
	//----------------------------------------------------------------------------------------
	//	Function: setWifi 
	//		Sets up wifi via the Settings Wifi picker
	//
	//	Parameters:
	//		value (string) - Either "1" (ON) or "0" (OFF)
	//		network (string) - If value is 1, this should be the name of the network.
	//		password (string) - password to use for the chose network.
	//
	//  Optional Parameters:
	//		backupNetwork (string) - Specify an backup network here in the event the test cannot join the preferred network,  
	//		backupPassword (string) - Password for the backup network
	//	
	//	Returns: 
	//		true if the wifi network was successfully set up
	//	
	//	Throws:
	//		An error if there is a problem setting the network up
	//----------------------------------------------------------------------------------------		
	settings.setWifi = function setWifi(value, network, password, options) {
		var backupNetworkName = "";
		var backupPassword = "";
		var maxAttempts = 5;
		var result, actualNetwork;
		var joinBackupNetwork = false;
		var primaryNetworkName;
		var settingsTable;
		var settingsWifiCell;
		var WiFiCellName = "Wi-Fi"
		var waitForNetworkTimeout = 10
		
		if (system.hasWiFiCapability("WAPI")) {
			WiFiCellName = "WLAN"
		}
		
		if (typeof value == 'string' ) {
			value = parseInt(value);
		}
		
		//Set up options hash
		if (options && options.backupNetwork) {
			backupNetworkName = options.backupNetwork;
			backupPassword = options.backupPassword;
			UIALogger.logMessage("Backup network = " + backupNetworkName);
		}
		
		if (options && options.timeout) {
			waitForNetworkTimeout = parseInt(options.timeout)
		}
		
		UIALogger.logMessage("value = " + value + ", network = " + network + ", password = " + password);
		
		this.launchIfNotActive();

		//Return to the top-most level in the Settings hierarchy
		this.returnToTopLevel();
		
		UIATarget.localTarget().pushTimeout(0.1);

		if (UIATarget.localTarget().model() == 'iPad') {
			settingsTable = this.mainWindow().tableViews()[1];
		} else {
			settingsTable = this.mainWindow().tableViews()[0];
		}
		
		settingsWifiCell = this.mainWindow().tableViews()[0].cells().firstWithName(WiFiCellName);

		
		var currentWiFiNetworkName = settingsWifiCell.value();
		
		if (currentWiFiNetworkName == network && (value == 1)) {
			UIALogger.logMessage("Wifi is already set to use network " + network);
			return true;
		}
		
		UIALogger.logMessage("Choosing " + WiFiCellName);
		try {
			this.chooseSetting(WiFiCellName);
		} catch (e) {
			UIALogger.logError(e.message);
			throw new Error("Could not tap the " + WiFiCellName + " table element");
		}
		
		//Wait for all of the networks to load and animations to cease
		if (UIATarget.localTarget().model() == 'iPad') {
			UIATarget.localTarget().delay(7);
		} else {
			UIATarget.localTarget().delay(3);;
		}
		
		UIALogger.logMessage("Setting " + WiFiCellName + " switch");	
		try {
			
			var wifiSwitch = settingsTable.cells().firstWithName(WiFiCellName).switches()[0];
			if (wifiSwitch.value() != value) {
				wifiSwitch.setValue(value);
			} else {
				UIALogger.logMessage(WiFiCellName + " switch already set to " + value);
			}
			
			wifiSwitch = settingsTable.cells().firstWithName(WiFiCellName).switches()[0].withValueForKey(value, "value");
			if (!wifiSwitch.isValid()) {
				throw new Error("Did not set the " + WiFiCellName + " switch to " + value);
			}

		} catch (e) {
			UIALogger.logError(e.message);		
			throw new Error("Could not switch " + WiFiCellName + " setting to " + value);
		}
		
		if (value == 0) return true;
		
		if (network) {
			
			for ( var currentAttempt = 0; currentAttempt < maxAttempts; currentAttempt++) {
				UIALogger.logMessage("Attempting to connect to network '" + network + "', attempt #" + currentAttempt);
				// Increase Wait for network timeout for each attempt
				if (currentAttempt > 0) {
					waitForNetworkTimeout = waitForNetworkTimeout + 5
				}
				UIALogger.logMessage("Waiting up to " + waitForNetworkTimeout + " seconds for WiFi Preferences loading the networks")
				UIATarget.localTarget().pushTimeout(waitForNetworkTimeout);
				UIALogger.logMessage("Scrolling to network: " + network);
				try {
					//var networkView = this._getNetworkCell(network);
					var networkView = this.getSettingsTable().cells().firstWithPredicate("ANY staticTexts.name beginswith '" + network + "'");
				} catch(e) {
					UIALogger.logMessage("Failed to scroll to network named: " + network);
				}
										 
				UIATarget.localTarget().popTimeout();
				if (networkView.checkIsValid()) {
					//networkView.scrollToVisible();
					// So, we found the network, so let's tap the table cell and enter a password, if prompted for one
					UIALogger.logMessage("Choosing wifi network: " + network);
					networkView.scrollToVisible();
					networkView.logElement();
					networkView.tap();
					// Wait for a password prompt (if needed) to animate in
					UIATarget.localTarget().delay(2);
					if (this.mainWindow().navigationBars().firstWithPredicate("ANY staticTexts.name == 'Enter Password'").staticTexts().firstWithName("Enter Password").isValid()) {
						
						if (password == "" || !password || password == "null") {
							throw new Error("A password was not supplied for the network, but we are being asked for one.");
						}
						
						// Set the date for alertSinceDate
						var date = new Date();
						UIALogger.logMessage("Typing password for network " + network);
                        var passwordTableView;
                        
                        if (UIATarget.localTarget().model() == 'iPad') {
                            passwordTableView = this.mainWindow().tableViews().firstWithPredicate("isVisible == 1");
                            if (!passwordTableView.isVisible()) throw new Error("Table view containging password text field is not visible");
                        }
                        else passwordTableView = this.mainWindow().tableViews().firstWithPredicate("isValid == 1");
                        
                        if (!passwordTableView.checkIsValid()) throw new Error("Table view containging password text field is not valid");
						var passwordParentElement = passwordTableView.cells().firstWithPredicate("ANY secureTextFields.name == 'Password'");
                        passwordParentElement.logElementTree();
						this.enterTextInTextField(passwordParentElement.secureTextFields()[0], password);
						this.mainWindow().navigationBars().firstWithPredicate("ANY staticTexts.name == 'Enter Password'").buttons().firstWithName("Join").tap();
						// Wait for authentication to complete and look for an alert
						UIATarget.localTarget().delay(10);
						var lastAlert = this.alertSinceDate(date);
						if (lastAlert != null && lastAlert.alertMessageArray[0].match(/^Incorrect.*/)) {
							throw new Error("Could not join protected network - received an alert with the message: " + lastAlert.alertMessageArray[0] );
						} 
						
						// Check to see if we've returned to the main network picker table view
						// from the 'Enter Password' navigation view - if not, something has gone wrong
						// Until we can access each of the navigation bars on k48 (<rdar://problem/8127817> navigationBar() convenience function does not return the 'Add Bookmark' maps nav bar)
						// putting in this mildly-hackish workaround
						UIATarget.localTarget().pushTimeout(10);
						var returnToViewConfirmation = this.mainWindow().elements().firstWithName(WiFiCellName + " Networks").isValid();
						UIATarget.localTarget().popTimeout();
						if (!returnToViewConfirmation){
							throw new Error("After entering password, 'Enter Password' view did not disappear.");
						}
					} else {

						if (password) {
							throw new Error("A password was supplied, but the navigation bar is not valid");
						}
					}
					
					//Verify the network SSID
					for (var i=0; i<60; i=i+1) {
						result = system.run("/usr/local/bin/apple80211 --ssid", 5);
						actualNetwork = result.stdout.replace("\n", "").replace("ssid = ", "");
						if (actualNetwork == network){
							UIALogger.logMessage("Joined network " + actualNetwork );
							return true;
						}
						UIATarget.localTarget().delay(1);
					}
					
				} else if ((currentAttempt + 1) >= maxAttempts && !networkView.isValid() && backupNetworkName) {
					// If we fail to join the first specified network
					// use the backup network and password (if provided) and try another 3 times.
					if (!joinBackupNetwork) {
						UIALogger.logMessage("Attempting to connect to backup network");
						joinBackupNetwork = true;
						primaryNetworkName = network;
						network = backupNetworkName;
						password = backupPassword;
						currentAttempt = -1;
					} 
					
				} else {
					UIALogger.logError("Did not find network '" + network + "' on attempt #" + currentAttempt);
				}
				
			}  // end for		
			
			if (!networkView.isVisible()) {
				var networkError = "Could not join the network " + network;
				this.logElementTree();
				if (backupNetworkName) {
					networkError = "Could not join the network '" + primaryNetworkName + "' or the backup network '" + backupNetworkName + "'";
				}
				throw new Error(networkError);
			}
			
		} else {
			UIALogger.logMessage("No network to join provided");
			return true;
		}
	
	} // end setWifi
	
	
	//----------------------------------------------------------------------------------------
	//	Function: checkWiFiName
	//		Check if WiFi joined with correct SSID
	//
	//	Parameters:
	//		network (string) - name of the network.
	//		timeout (int) - timeout in seconds to check the SSID
	//
	//	Returns: 
	//		ture/false
	//	Throws:
	//		An error if there is a problem
	//----------------------------------------------------------------------------------------		
	settings.checkWiFiName = function checkWiFiName(network, timeout) {
		var actualNetwork = ""
		
		UIALogger.logMessage("Check if WiFi is joined with network: " + network);

		//Verify the network SSID
		for (var i=0; i<timeout; i=i+1) {
			var result = system.run("/usr/local/bin/apple80211 --ssid", 5);
			actualNetwork = result.stdout.replace("\n", "").replace("ssid = ", "");
			if (actualNetwork == network){
				UIALogger.logMessage("apple80211 --ssid shows: joined network " + actualNetwork );
				break;
				
			}
			UIATarget.localTarget().delay(1);
		}
		
		try {
			//if(settings.checkSettingsWiFiCellValue(network)) {
			if(settings.getWiFiTableCell().withValueForKey(network, "value").isValid()) {
				if (actualNetwork == network) {
					UIALogger.logMessage("WiFi is already set to use network " + network+", apple80211 --ssid shows: joined network " + actualNetwork);
					return true
				} else {
					UIALogger.logError("WiFi UI set to use network: "+network+", but apple80211 shows: " +actualNetwork);
				}
			} else {
				var WiFiTableCellValue = settings.getWiFiTableCell().value()
				UIALogger.logError("WiFi UI does not set to use network: "+network+", UI shows: " + WiFiTableCellValue +", apple80211 shows: " +actualNetwork);
			}
		
		} catch (e) {
			UIALogger.logError(e.message)
			throw new Error(e.message)
		}
		
		return false
	
	} // end checkWiFiName
	
	//----------------------------------------------------------------------------------------
	//	Function: selectWiFiNetwork
	//		find and tap a WiFi network or a tablecell in WiFi preferences.
	//
	//	Parameters:
	//		network (string) - The name of the network.
	//
	//	Returns: 
	//		None
	//	
	//	Throws:
	//		An error if there is a problem
	//----------------------------------------------------------------------------------------		
	settings.selectWiFiNetwork = function selectWiFiNetwork(network, options) {
		var maxAttempts = 3;
		var settingsTable;
		var value = 1;
		var waitForNetworkTimeout = 10
		
		if (options && options.timeout) {
			waitForNetworkTimeout = parseInt(options.timeout)
		}
		
		var WiFiCellName = "Wi-Fi"
		
		if (system.hasWiFiCapability("WAPI")) {
			WiFiCellName = "WLAN"
		}
		
		try {
			settings.getToWiFiPreferences()
		} catch (e) {
			UIALogger.logError(e.message)
			throw new Error("Can not get to WiFi Preferences")
		}
		
		settingsTable = settings.getSettingsTable()
		
		UIALogger.logMessage("Setting " + WiFiCellName + " switch");	
		try {

			var wifiSwitch = settingsTable.cells().firstWithName(WiFiCellName).switches()[0];
			if (wifiSwitch.value() != value) {
				wifiSwitch.setValue(value);
				UIATarget.localTarget().delay(3);
			} else {
				UIALogger.logMessage(WiFiCellName + " switch already set to " + value);
			}

			if (!wifiSwitch.withValueForKey(value, "value").isValid()) {
				throw new Error("Did not set the "+ WiFiCellName +" switch to " + value);
			}

		} catch (e) {
			UIALogger.logError(e.message);		
			throw new Error("Could not switch "+ WiFiCellName +" setting to " + value);
		}
		
			
		for ( var currentAttempt = 0; currentAttempt < maxAttempts; currentAttempt++) {
			UIALogger.logMessage("Attempting to find '" + network + "', attempt #" + currentAttempt);
			// Increase Wait for network timeout for each attempt
			if (currentAttempt > 0) {
				waitForNetworkTimeout = waitForNetworkTimeout + 5
			}
			UIALogger.logMessage("Waiting up to " + waitForNetworkTimeout + " seconds for WiFi Preferences loading the networks")	
			UIATarget.localTarget().pushTimeout(waitForNetworkTimeout);
			
			UIALogger.logMessage("Scrolling to network: " + network);
			networkTable = settings.getSettingsTable()
			var networkView = networkTable.scrollToElementWithPredicate("ANY elements.name contains '" + network + "'");
			UIATarget.localTarget().popTimeout();
			if (networkView.isValid()) {
				// So, we found the network, so let's tap the table cell
				UIALogger.logMessage("Choosing wifi network: " + network);
				networkView.tap();
				// Wait for a password prompt (if needed) to animate in
				UIATarget.localTarget().delay(2);
				return
			} else {
				UIALogger.logError("Did not find network '" + network + "' on attempt #" + currentAttempt);
			}
			
			//Add three seconds delay to allow WiFi preferences scan/update with more networks
			UIATarget.localTarget().delay(3);
				
		}  // end for		
			
		if (!networkView.isValid()) {
			var networkError = "Could not find the network " + network;
			this.logElementTree();
			throw new Error(networkError);
		}
			
	
	} // end selectWiFiNetwork
	
	//----------------------------------------------------------------------------------------
	//	Function: setWifiHidden 
	//		Sets up a hidden wifi network via the Settings Wifi picker
	//
	//	Parameters:
	//		network (string) - If value is 1, this should be the name of the network.
	//		password (string) - password to use for the chose network.
	//		security (string) - security type of the network: None, WEP, WPA, WPA2 WPA Enterprise, WPA2 Enterprise
	//	
	//	Returns: 
	//		true if the wifi network was successfully set up
	//	
	//	Throws:
	//		An error if there is a problem setting the network up
	//----------------------------------------------------------------------------------------		
	settings.setWifiHidden = function setWifiHidden(network, password, security, username, options) {
		var maxAttempts = 3;
		var other = "Other…"; 
		var settingsTable;
		var settingsWifiCell;
		var WiFiCellName = "Wi-Fi"
		
		if (system.hasWiFiCapability("WAPI")) {
			WiFiCellName = "WLAN"
		}
		
		UIALogger.logMessage("network = " + network + ", password = " + password+ ", security = " + security+ ", username = " + username);
		
		try {
			if (settings.checkWiFiName(network, 2)) {
				UIALogger.logMessage("Wifi is already set to use network " + network);
				return;
			} 
		} catch(e) {
			UIALogger.logMessage(e.message)
			throw new Error(e.message)
		}
		
		UIALogger.logMessage("Try to set WiFi uses network: " + network)
			
		for ( var currentAttempt = 0; currentAttempt < maxAttempts; currentAttempt++) {
		
			try	{
				settings.selectWiFiNetwork(other, options) 
			} catch (e) {
				UIALogger.logError(e.message)
				throw new Error("Could not select the network: " + other)
			}
				
			if (this.mainWindow().navigationBar().staticTexts().firstWithName("Other Network").isValid()) {

				if (password == "" && security != "None") {
					throw new Error("A password was not supplied for the network, but we need for one because security type is: " + security);
				}

					
				UIALogger.logMessage("Typing the name for network " + network);
				var nameParentElement = this.mainWindow().tableViews().firstWithPredicate("isVisible == 1").cells().firstWithPredicate("ANY textFields.name == 'Name'");
				this.enterTextInTextField(nameParentElement.textFields()[0], network);
					
				try {
					this.mainWindow().tableViews().firstWithPredicate("isVisible == 1").cells()["Security"].tap()
				} catch (e) {
					UIALogger.logError(e.message);
					throw new Error("Could not tap Security button");
				}
					
				UIATarget.localTarget().delay(2);
					
				try {
					this.mainWindow().tableViews().firstWithPredicate("isVisible == 1").cells()[security].tap()
				} catch (e) {
					UIALogger.logError(e.message);
					throw new Error("Could not select security type: "+security);
				}
				UIATarget.localTarget().delay(2);
					
				this.mainWindow().navigationBar().buttons()["Other Network"].tap();
				UIATarget.localTarget().delay(2);
					
				var date = new Date();
				if (security != "None") {
					if (security == "WPA Enterprise" || security == "WPA2 Enterprise") {
						var usernameParentElement = this.mainWindow().tableViews().firstWithPredicate("isVisible == 1").cells().firstWithPredicate("ANY textFields.name == 'Username'")
						this.enterTextInTextField(usernameParentElement.textFields()[0], username);
						this.keyboard().buttons().firstWithName("return").tap();
					}
						
					UIALogger.logMessage("Typing password for hidden network " + network);
					var passwordParentElement= this.mainWindow().tableViews().firstWithPredicate("isVisible == 1").cells().firstWithPredicate("ANY secureTextFields.name == 'Password'")						
					var passwordTextField = passwordParentElement.secureTextFields()[0]
						
					this.enterTextInTextField(passwordTextField, password);
					//passwordTextField.setValue(password)
						
				}
				this.mainWindow().navigationBars().firstWithPredicate("ANY staticTexts.name == 'Other Network'").buttons().firstWithName("Join").tap();
					
				if (security == "WPA Enterprise" || security == "WPA2 Enterprise") {
					UIALogger.logMessage("Waiting up to 20 seconds and check for certificate window");
					UIATarget.localTarget().pushTimeout(20);
					
					if (this.mainWindow().navigationBar().staticTexts().firstWithName("Certificate").isValid()) {
						UIATarget.localTarget().popTimeout();
						UIALogger.logMessage("Certificate Window Poped up");
						UIATarget.localTarget().delay(1);
						try {
							this.mainWindow().tableViews().firstWithPredicate("isVisible == 1").cells()[0].buttons()["Accept"].tap();
							UIALogger.logMessage("Tapped Accept Button");
						} catch (e) {
							UIALogger.logError(e.message);
							throw new Error("Could not find or type the Accept button");
						}
					} else {
						UIALogger.logMessage("No Certificate Window show up");
					}
				} 
				UIATarget.localTarget().popTimeout();
					
				// Wait for authentication to complete and look for an alert
				UIALogger.logMessage("Waiting for 10 seconds to check alert");
				UIATarget.localTarget().delay(10);
					
				UIATarget.localTarget().pushTimeout(10);
					
				var lastAlert = settings.alertSinceDate(date);
				
				if (lastAlert != null) {
					UIATarget.localTarget().popTimeout();
					throw new Error("Could not join hidden network - received an alert with the message: " + lastAlert.alertMessageArray[0] );
				} 

				// Check to see if we've returned to the main network picker table view
				// from the 'Enter Password' navigation view - if not, something has gone wrong
				var returnToViewConfirmation = this.mainWindow().navigationBars().firstWithName(WiFiCellName + " Networks").isValid();
				UIATarget.localTarget().popTimeout();
				if (!returnToViewConfirmation){
					throw new Error("After entering password, 'Enter Password' view did not disappear.");
				}

			}
			
			//Check network SSID
			try {
				if (settings.checkWiFiName(network, 10)) {
					UIALogger.logMessage("WiFi joined with "+network)
					return;
				} else {
					UIALogger.logError("Did not join network '" + network + "' on attempt #" + currentAttempt);
				}
				
			} catch(e) {
				UIALogger.logMessage(e.message)
				throw new Error(e.message)
			}
			
		}  // end for		
		
		UIALogger.logError("Failed to join hidden network " + network );
		throw new Error("Failed to join hidden network " + network );
	
	} // end setWifiHidden
	
	//----------------------------------------------------------------------------------------
	//	Function: setWifiEnterprise 
	//		Sets up a enterprise wifi network via the Settings Wifi picker
	//
	//	Parameters:
	//		network (string) - If value is 1, this should be the name of the network.
	//		password (string) - password to use for the chose network.
	//		username (string) - username of the network
	//	
	//	Returns: 
	//		true if the wifi network was successfully set up
	//	
	//	Throws:
	//		An error if there is a problem setting the network up
	//----------------------------------------------------------------------------------------		
	settings.setWifiEnterprise = function setWifiEnterprise(network, password, username, options) {
		var maxAttempts = 3;
		var WiFiCellName = "Wi-Fi"
		
		if (system.hasWiFiCapability("WAPI")) {
			WiFiCellName = "WLAN"
		}
		
		UIALogger.logMessage("network = " + network + ", password = " + password+ ", username = " + username);
		
		try {
			if (settings.checkWiFiName(network, 2)) {
				UIALogger.logMessage("Wifi is already set to use network " + network);
				return;
			} 
		} catch(e) {
			UIALogger.logMessage(e.message)
			throw new Error(e.message)
		}
			
		for ( var currentAttempt = 0; currentAttempt < maxAttempts; currentAttempt++) {
		
			try {
				settings.selectWiFiNetwork(network, options)
			} catch (e) {
				UIALogger.logError(e.message)
				throw new Error("Could not select the WiFi network: " + network)
			}
		
			if (this.mainWindow().navigationBar().staticTexts().firstWithName("Enter Password").isValid()) {

				UIALogger.logMessage("Typing the username and password for network " + network);

				var usernameParentElement = this.mainWindow().tableViews().firstWithPredicate("isVisible == 1").cells().firstWithPredicate("ANY textFields.name == 'Username'")						
				this.enterTextInTextField(usernameParentElement.textFields()[0], username);
			
				var passwordParentElement = this.mainWindow().tableViews().firstWithPredicate("isVisible == 1").cells().firstWithPredicate("ANY secureTextFields.name == 'Password'")	
				this.enterTextInTextField(passwordParentElement.secureTextFields()[0], password);
			
			
				var date = new Date();
				this.mainWindow().navigationBars().firstWithPredicate("ANY staticTexts.name == 'Enter Password'").buttons().firstWithName("Join").tap();
			
				UIALogger.logMessage("Waiting up to 20 seconds and check for certificate window");
				UIATarget.localTarget().pushTimeout(20);

				if (this.mainWindow().navigationBar().staticTexts().firstWithName("Certificate").isValid()) {
					UIATarget.localTarget().popTimeout();
					UIALogger.logMessage("Certificate Window Poped up");
					UIATarget.localTarget().delay(1);
					try {
						this.mainWindow().tableViews().firstWithPredicate("isVisible == 1").cells()[0].buttons()["Accept"].tap();
						UIALogger.logMessage("Tapped Accept Button");
					} catch (e) {
						UIALogger.logError(e.message);
						throw new Error("Could not find or type the Accept button");
					}
				} else {
					UIALogger.logMessage("No Certificate Window show up");
				}
				UIATarget.localTarget().popTimeout();
			
				// Wait for authentication to complete and look for an alert
				UIALogger.logMessage("Waiting for 10 seconds to check the alert");
				UIATarget.localTarget().delay(10);
			
				UIATarget.localTarget().pushTimeout(10);
			
				var lastAlert = settings.alertSinceDate(date);
		
				if (lastAlert != null) {
					UIATarget.localTarget().popTimeout();
					throw new Error("Could not join hidden network - received an alert with the message: " + lastAlert.alertMessageArray[0] );
				} 

				// Check to see if we've returned to the main network picker table view
				// from the 'Enter Password' navigation view - if not, something has gone wrong
				var returnToViewConfirmation = this.mainWindow().navigationBars().firstWithName(WiFiCellName + " Networks").isValid();
				UIATarget.localTarget().popTimeout();
				if (!returnToViewConfirmation){
					throw new Error("After entering password, 'Enter Password' view did not disappear.");
				}
			} else {
				throw new Error("Did not pop up Enter Username and Password Window")
			}
			
			//Check network SSID
			try {
				if (settings.checkWiFiName(network, 10)) {
					UIALogger.logMessage("WiFi joined with "+network)
					return;
				} else {
					UIALogger.logError("Did not join network '" + network + "' on attempt #" + currentAttempt);
				}

			} catch(e) {
				UIALogger.logMessage(e.message)
				throw new Error(e.message)
			}
			
		}  // end for		
		
		UIALogger.logError("Failed to join enterprise network " + network);
		throw new Error("Failed to join enterprise network " + network)
	
	} // end setWifiEnterprise

	//----------------------------------------------------------------------------------------
	//	Function: setWifiWAPIEnterprise 
	//		Sets up a enterprise WAPI wifi network via the Settings Wifi picker
	//
	//	Parameters:
	//		None
	//	
	//	Returns: 
	//		None
	//	
	//	Throws:
	//		An error if there is a problem setting the network up
	//----------------------------------------------------------------------------------------		
	settings.setWifiWAPIEnterprise = function setWifiWAPIEnterprise(network, options) {
		var maxAttempts = 3;
		var WiFiCellName = "Wi-Fi";
		
		if (system.hasWiFiCapability("WAPI")) {
			WiFiCellName = "WLAN";
		}
		
		UIALogger.logMessage("network = " + network);
		
		try {
			if (settings.checkWiFiName(network, 2)) {
				UIALogger.logMessage("Wifi is already set to use network " + network);
				return;
			} 
		} catch(e) {
			UIALogger.logMessage(e.message);
			throw new Error(e.message);
		}
			
		for ( var currentAttempt = 0; currentAttempt < maxAttempts; currentAttempt++) {
		
			try {
				settings.selectWiFiNetwork(network, options);
			} catch (e) {
				UIALogger.logError(e.message);
				throw new Error("Could not select the WiFi network: " + network);
			}
		
			if (this.mainWindow().navigationBar().staticTexts().firstWithName("Enter Password").isValid()) {

				UIALogger.logMessage("Select Root Certificate and WAPI Identity for network " + network);
				
				var rootCertCell = this.mainWindow().tableViews().firstWithPredicate("isVisible == 1").cells()["Root Certificate"];
				
				if(rootCertCell.isValid()) {
					rootCertCell.tap();
				} else {
					throw new Error("The Root Certificate Tabel Cell did not show up");
				}
				
				UIATarget.localTarget().delay(1);
				
				var rootCertNavigationBar = this.mainWindow().navigationBars().firstWithName("Root Certificate");
				if (rootCertNavigationBar.isValid()) {
					UIALogger.logMessage("Select the Root Certificate");
					var ASUCertCell = this.mainWindow().tableViews().firstWithPredicate("isVisible == 1").cells().firstWithPredicate("name endswith '@ASU'");
					
				} else {
					throw new Error("The Root Certificate Select Window did not show up");
				}
				
				if(ASUCertCell.isValid()) {
					ASUCertCell.tap();
					UIALogger.logMessage("Tapped root cert with name: "+ASUCertCell.name());
				} else {
					if (WiFiCellName == "Wi-Fi") {
						UIALogger.logMessage("Could not find the ASU Root Cert to choose");
						UIALogger.logMessage("This is not a China device, so it is not able to show the Root Certificate");
						return
					}
					throw new Error("Could not find the ASU Root Cert to choose");
				}
				
				rootCertNavigationBar.buttons()["Enter Password"].tap();
				UIATarget.localTarget().delay(1);
				
				var WAPIIdentityCell = this.mainWindow().tableViews().firstWithPredicate("isVisible == 1").cells()["WAPI Identity"];
				if(WAPIIdentityCell.isValid()) {
					WAPIIdentityCell.tap();
				} else {
					throw new Error("The WAPI Identity Tabel Cell did not show up");
				}
				
				var wapiIdentityNavigationBar = this.mainWindow().navigationBars().firstWithName("WAPI Identity");
				if (wapiIdentityNavigationBar.isValid()) {
					UIALogger.logMessage("Select the WAPI Identity");
					var WAPIIdentityCell = this.mainWindow().tableViews().firstWithPredicate("isVisible == 1").cells().firstWithPredicate("name endswith '@ASUE'");
					
				} else {
					throw new Error("The WAPI Identity Select Window did not show up");
				}
				
				if(WAPIIdentityCell.isValid()) {
					WAPIIdentityCell.tap();;
					UIALogger.logMessage("Tapped WAPI Identity with name: "+WAPIIdentityCell.name())
				} else {
					throw new Error("Could not find the WAPI Identity to choose");
				}
				
				wapiIdentityNavigationBar.buttons()["Enter Password"].tap();
				UIATarget.localTarget().delay(1);
				
				//Tap Join button to join the network
				var date = new Date();
				this.mainWindow().navigationBars().firstWithName("Enter Password").buttons()["Join"].tap();
			
				// Wait for authentication to complete and look for an alert
				UIALogger.logMessage("Waiting for 10 seconds to check the alert");
				UIATarget.localTarget().delay(10);
			
				UIATarget.localTarget().pushTimeout(10);
			
				var lastAlert = settings.alertSinceDate(date);
		
				if (lastAlert != null) {
					UIATarget.localTarget().popTimeout();
					throw new Error("Could not join hidden network - received an alert with the message: " + lastAlert.alertMessageArray[0] );
				} 

				// Check to see if we've returned to the main network picker table view
				// from the 'Enter Password' navigation view - if not, something has gone wrong
				var returnToViewConfirmation = this.mainWindow().navigationBars().firstWithName(WiFiCellName + " Networks").isValid();
				UIATarget.localTarget().popTimeout();
				if (!returnToViewConfirmation){
					throw new Error("After entering password, 'Enter Password' view did not disappear.");
				}
			} else {
				throw new Error("Did not pop up Enter Password Window");
			}
			
			//Check network SSID
			try {
				if (settings.checkWiFiName(network, 10)) {
					UIALogger.logMessage("WiFi joined with "+network);
					if (WiFiCellName == "Wi-Fi") {
						throw new Error("This is not a China device, but it joined a WAPI Enterprise AP");
					}
					return;
				} else {
					UIALogger.logError("Did not join network '" + network + "' on attempt #" + currentAttempt);
				}

			} catch(e) {
				UIALogger.logMessage(e.message);
				throw new Error(e.message);
			}
			
		}  // end for		
		
		UIALogger.logError("Failed to join enterprise network " + network);
		throw new Error("Failed to join enterprise network " + network);
	
	} // end setWifiWAPIEnterprise


	//----------------------------------------------------------------------------------------
	//	Function: setWifiProfile 
	//		Sets up a enterprise wifi network uses profile via the Settings Wifi picker; the profile
	//		needs to be installed in the device already
	//
	//	Parameters:
	//		network (string) - The name of the network.
	//	
	//	Returns: 
	//		None
	//	
	//	Throws:
	//		An error if there is a problem setting the network up
	//----------------------------------------------------------------------------------------		
	settings.setWifiProfile = function setWifiProfile(network, options) {
		var maxAttempts = 3;
		var WiFiCellName = "Wi-Fi"
		
		if (system.hasWiFiCapability("WAPI")) {
			WiFiCellName = "WLAN"
		}
		
		UIALogger.logMessage("Try to join network = " + network + " uses profile");
		
		try {
			if (settings.checkWiFiName(network, 2)) {
				UIALogger.logMessage("Wifi is already set to use network " + network);
				return;
			} 
		} catch(e) {
			UIALogger.logMessage(e.message)
			throw new Error(e.message)
		}
			
		for ( var currentAttempt = 0; currentAttempt < maxAttempts; currentAttempt++) {
			var date = new Date();
			try {
				settings.selectWiFiNetwork(network, options)
			} catch(e) {
				UIALogger.logError(e.message)
				throw new Error("Can not find the WiFi network: " + network)
			}
			
			UIALogger.logMessage("Waiting up to 20 seconds and check for certificate window");
			UIATarget.localTarget().pushTimeout(20);

			if (this.mainWindow().navigationBars().firstWithName("Certificate").isVisible()) {
				UIATarget.localTarget().popTimeout();
				UIALogger.logMessage("Certificate Window Poped up");
				UIATarget.localTarget().delay(1);
				try {
					this.mainWindow().tableViews().firstWithPredicate("isVisible == 1").cells()[0].buttons()["Accept"].tap();
					UIALogger.logMessage("Tapped Accept Button");
				} catch (e) {
					UIALogger.logError(e.message);
					throw new Error("Could not find or type the Accept button");
				}
			} else {
				UIALogger.logMessage("No Certificate Window show up");
			}
			UIATarget.localTarget().popTimeout();
			
			// Wait for authentication to complete and look for an alert
			UIALogger.logMessage("Waiting for 10 seconds to check the alert");
			UIATarget.localTarget().delay(10);
			
			UIATarget.localTarget().pushTimeout(10);
			
			var lastAlert = settings.alertSinceDate(date);
		
			if (lastAlert != null) {
				UIATarget.localTarget().popTimeout();
				throw new Error("Could not join profile network - received an alert with the message: " + lastAlert.alertMessageArray[0] );
			} 

			// Check to see if we've returned to the main network picker table view
			// if not, something has gone wrong
			var returnToViewConfirmation = this.mainWindow().navigationBars().firstWithName(WiFiCellName + " Networks").isValid();
			UIATarget.localTarget().popTimeout();
			if (!returnToViewConfirmation){
				throw new Error("Device did not go back to WiFi Preferences after tapped Join the network or Accept cert button");
			}
			
			//Check network SSID
			try {
				if (settings.checkWiFiName(network, 10)) {
					UIALogger.logMessage("WiFi joined with "+network)
					return;
				} else {
					UIALogger.logError("Did not join network '" + network + "' on attempt #" + currentAttempt);
				}

			} catch(e) {
				UIALogger.logMessage(e.message)
				throw new Error(e.message)
			}
			
		}  // end for		
		
		throw new Error("Failed to join enterprise network " + network );
	
	} // end setWifiProfile

	//----------------------------------------------------------------------------------------
	//	Function: setWifiWAPI 
	//		Sets up a WAPI wifi network via the Settings Wifi picker; 
	//
	//	Parameters:
	//		network (string) - The name of the network.
	//		password (string) - The password of the network
	//	
	//	Returns: 
	//		None
	//	
	//	Throws:
	//		For China device: An error if there is a problem for setting the network up
	//		For other devices: An error if UI does not report "Unable to join the network"
	//----------------------------------------------------------------------------------------		
	settings.setWifiWAPI = function setWifiWAPI(network, password, options) {
		var maxAttempts = 3;
		var WiFiCellName = "Wi-Fi"
		
		if (system.hasWiFiCapability("WAPI")) {
			WiFiCellName = "WLAN"
		}
		
		UIALogger.logMessage("Try to join WAPI network = " + network + "; password= " + password);
		
		try {
			if (settings.checkWiFiName(network, 2)) {
				UIALogger.logMessage("Wifi is already set to use network " + network);
				return;
			} 
		} catch(e) {
			UIALogger.logMessage(e.message)
			throw new Error(e.message)
		}
			
		for ( var currentAttempt = 0; currentAttempt < maxAttempts; currentAttempt++) {
			var date = new Date();
				
			try {
				settings.selectWiFiNetwork(network, options)
			} catch(e) {
				UIALogger.logError(e.message)
				throw new Error("Can not find the WiFi network: " + network)
			}
			
			UIATarget.localTarget().delay(2);
			if (this.mainWindow().navigationBars().firstWithPredicate("ANY staticTexts.name == 'Enter Password'").staticTexts().firstWithName("Enter Password").isValid()) {
				
				// Set the date for alertSinceDate
				var date = new Date();
				UIALogger.logMessage("Typing password for network " + network);
				var passwordParentElement = this.mainWindow().tableViews().firstWithPredicate("isVisible == 1").cells().firstWithPredicate("ANY secureTextFields.name == 'Password'");
				this.enterTextInTextField(passwordParentElement.secureTextFields()[0], password);
				this.mainWindow().navigationBars().firstWithPredicate("ANY staticTexts.name == 'Enter Password'").buttons().firstWithName("Join").tap();
				
			} else {

				throw new Error("The password navigation bar is not valid");
			}
			
			//Wait for 10 seconds for the alert
			UIATarget.localTarget().delay(10);
			UIATarget.localTarget().pushTimeout(10);
			var lastAlert = settings.alertSinceDate(date);
			if (lastAlert != null) {
				UIATarget.localTarget().popTimeout();
				
				if (WiFiCellName == "Wi-Fi") {
					if ( lastAlert.alertMessageArray[0].match(/Unable to join the network.*/)) {
						UIALogger.logMessage("This is not a China device, Alert shows '" + lastAlert.alertMessageArray[0] + "' as expected")
						return;
					} else {
						throw new Error("This is not a China device, expected to see 'Unable to join the network' alert, but encounter this alert: "+lastAlert.alertMessageArray[0])
					}
				}
				
				throw new Error("Could not join profile network - received an alert with the message: " + lastAlert.alertMessageArray[0] );
			} 

			// Check to see if we've returned to the main network picker table view
			// if not, something has gone wrong
			var returnToViewConfirmation = this.mainWindow().navigationBars().firstWithName(WiFiCellName + " Networks").isValid();
			UIATarget.localTarget().popTimeout();
			if (!returnToViewConfirmation){
				throw new Error("Device did not go back to WiFi Preferences after tapped Join the network button");
			}
			
			//Check network SSID
			try {
				if (settings.checkWiFiName(network, 10)) {
					UIALogger.logMessage("WiFi joined with "+network)
					if (WiFiCellName == "Wi-Fi") {
						throw new Error("This is not a China device, expected to see 'Unable to join the network' alert, but joined the WAPI network: "+ network)
					}
					return;
				} else {
					UIALogger.logError("Did not join network '" + network + "' on attempt #" + currentAttempt);
				}

			} catch(e) {
				UIALogger.logMessage(e.message)
				throw new Error(e.message)
			}
			
		}  // end for		
		
		throw new Error("Failed to join WAPI network " + network );
	
	} // end setWifiProfile
	
	//----------------------------------------------------------------------------------------
	//	Function: getToWiFiNetworkDetailedView 
	//		Sets up a hidden wifi network via the Settings Wifi picker
	//
	//	Parameters:
	//		network (string) - If value is 1, this should be the name of the network.
	//	
	//	
	//	Returns: 
	//		None
	//	
	//	Throws:
	//		An error if there is a problem to enter the network detail view
	//----------------------------------------------------------------------------------------		
	settings.getToWiFiNetworkDetailedView = function getToWiFiNetworkDetailedView(network, options) {
		var maxAttempts = 3;
		var settingsTable;
		var settingsWifiCell;
		var errorString = "Could not get to WiFi Network Detail View for: "+network
		var waitForNetworkTimeout = 10
		
		if (options && options.timeout) {
			waitForNetworkTimeout = parseInt(options.timeout)
		}
		
		UIALogger.logMessage("Try to enter network: " + network+" detail view");

		try {
			settings.getToWiFiPreferences()
		} catch(e) {
			UIALogger.logError(e.message)
			throw new Error(e.message)
		}
		
		UIATarget.localTarget().pushTimeout(1);

		if (UIATarget.localTarget().model() == 'iPad') {
			settingsTable = this.mainWindow().tableViews()[1];
		} else {
			settingsTable = this.mainWindow().tableViews()[0];
		}
		UIATarget.localTarget().popTimeout();

		for ( var currentAttempt = 0; currentAttempt < maxAttempts; currentAttempt++) {
			UIALogger.logMessage("Attempting to find '" + network + "', attempt #" + currentAttempt);
			if (currentAttempt > 0) {
				waitForNetworkTimeout = waitForNetworkTimeout + 5
			}
			UIALogger.logMessage("Waiting up to " + waitForNetworkTimeout + " seconds for WiFi Preferences loading the networks")
			UIATarget.localTarget().pushTimeout(waitForNetworkTimeout);
			UIALogger.logMessage("Scrolling to network: " + network);

			//Find the network try to forget, get the more info button next to the network name
			try {
				var moreInfoCell = this.cellsContainingElementsWithPredicate(settingsTable, "name BEGINSWITH[c] 'more info, "+network+"'")
			} catch (e) {
				UIALogger.logMessage(e.message)
				throw new Error(e.message)
}

			UIATarget.localTarget().popTimeout();

			if (moreInfoCell[0].isValid()) {
				// So, we found the network, so let's tap the more info button
				settingsTable.scrollToElementWithPredicate("ANY elements.name contains '" + network + "'");
				UIALogger.logMessage("Tap the more info button of the wifi network: " + network);
				moreInfoCell[0].buttons().firstWithPredicate("name BEGINSWITH[c] 'more info, "+network+"'").tap()
				
				UIATarget.localTarget().pushTimeout(5);
				var detailNavigationBar = this.mainWindow().navigationBars().firstWithPredicate("name matches '" + network + "'") 
				UIATarget.localTarget().popTimeout();
				
				if (detailNavigationBar.isValid()) {
					UIALogger.logMessage("Entered detail view of "+network)
					return

				} else {
					errorString = "Did not enter detail view of network '" + network+ "' on attempt #" + currentAttempt
					UIALogger.logError(errorString);
				}

			} else {
				errorString = "Did not find network '" + network + "' on attempt #" + currentAttempt
				UIALogger.logError(errorString);
			}

		}  // end for		
		throw new Error(errorString)
	
	} // end getToWiFiNetworkDetailedView
	
	//----------------------------------------------------------------------------------------
	//	Function: installProfile 
	//		install profile
	//
	//	Parameters:
	//		password -- Password needed for the profile installation
	//		timeout -- timeout for waiting for profile installation finish
	//
	//	Returns: 
	//		None
	//	
	//	Throws:
	//		An error if there is a problem while installing hte profile
	//----------------------------------------------------------------------------------------		
	settings.installProfile = function installProfile(password, timeout) {
		
		var profileTable = this.mainWindow().tableViews().firstWithPredicate("isVisible == 1")
		this.cellsContainingElementsWithPredicate(profileTable, "name matches 'Install'")[0].buttons()["Install"].tap()
		UIALogger.logMessage("Disabling onAlert() handling");
		UIATarget.disableOnAlert = 1;

		var warningBar = this.mainWindow().navigationBars().firstWithName("Warning")
		if (warningBar.isVisible()) {
			UIALogger.logMessage("The Warning for Unsigned Profile showed up, continue install")
			warningBar.buttons()["Install"].tap()
			UIATarget.localTarget().delay(2);
		} else {
			UIATarget.localTarget().pushTimeout(25);
			var actualAlertElement = settings.alert();
			UIATarget.localTarget().popTimeout()
			if (actualAlertElement.isValid()) {
				UIALogger.logMessage("Found an alert...")
				UIATarget.localTarget().delay(1);
				if (actualAlertElement.staticTexts().firstWithPredicate("name matches '(Unsigned|Unverified) Profile'").isVisible()) {
					UIALogger.logMessage("The Unsigned Profile alert window showed up")
					var buttonToTap = actualAlertElement.buttons()["Install Now"];
					if (!buttonToTap.isValid()) { 
						UIALogger.logMessage("Enabling onAlert() handling");
						UIATarget.disableOnAlert = 0;
						throw new Error("Could not tap alert button with name matching 'Install Now'");
					}
					UIATarget.localTarget().delay(1);
					UIALogger.logMessage("Tapping button 'Install Now'");
					buttonToTap.tap();		
					UIATarget.localTarget().delay(1);
				} else {
					UIALogger.logMessage("The Unsigned profile alert did not show up")
				}

			} 				
		}
		
		var passwordWindow = this.mainWindow().navigationBars().firstWithName("Enter Password")
		if (passwordWindow.isValid()) {
			UIALogger.logMessage("Ask to enter passwrod")
			if (password == "") {
				UIALogger.logMessage("Enabling onAlert() handling");
				UIATarget.disableOnAlert = 0;
				throw new Error("Did not provide a password, but we need one")
			}
			var passwordTableCell = this.mainWindow().tableViews().firstWithPredicate("isVisible == 1").cells()[0];
			this.enterTextInTextField(passwordTableCell.secureTextFields()[0], password);
			passwordWindow.buttons()["Next"].tap()
			
		}
				
		UIATarget.localTarget().pushTimeout(timeout);
		var installFinishWindow = this.mainWindow().navigationBars().firstWithName("Profile Installed")
		UIATarget.localTarget().popTimeout();
		
		if (installFinishWindow.isValid()) {
			UIATarget.localTarget().delay(1);
			installFinishWindow.buttons()["Done"].tap()
			UIALogger.logMessage("Profile install finished")
		} else {
			UIALogger.logMessage("Enabling onAlert() handling");
			UIATarget.disableOnAlert = 0;
			if (passwordWindow.isValid()) {
				var errorMessage = this.mainWindow().tableViews().firstWithPredicate("isVisible == 1").name()
				throw new Error("Password Pane showed up again because password is incorrect: " + errorMessage)
			}
			throw new Error("Profile Installed Window did not show up after " + timeout + " seconds")
		}
		UIALogger.logMessage("Enabling onAlert() handling");
		UIATarget.disableOnAlert = 0;
		
	} // end installProfile

	//----------------------------------------------------------------------------------------
	//	Function: deleteProfile 
	//		delete profile
	//
	//  Optional Parameters:
	//		profile (string) -- profile need to be deleted; if no parameter provided, all profiles will be 
	//			deleted.
	//
	//	Returns: 
	//		None
	//	
	//	Throws:
	//		An error if there is a problem while installing hte profile
	//----------------------------------------------------------------------------------------		
	settings.deleteProfile = function deleteProfile(options) {
		var settingsTable;
		var profileTableCell;
		var profilesTableCell;
		var profileTableView;
		var profileDeleteCount = 30;
		var profile = ""
		
		if (options && options.profileName)  {
			profile = options.profileName;
		}
		
		this.launchIfNotActive();
		//Return to the top-most level in the Settings hierarchy
		this.returnToTopLevel();

		UIATarget.localTarget().pushTimeout(1);

		if (UIATarget.localTarget().model() == 'iPad') {
			settingsTable = this.mainWindow().tableViews()[1];
		} else {
			settingsTable = this.mainWindow().tableViews()[0];
		}
		UIATarget.localTarget().popTimeout();
		
		UIALogger.logMessage("Choosing General");
		try {
			this.chooseSetting("General");
		} catch (e) {
			UIALogger.logError(e.message);
			throw new Error("Could not choose General");
		}
		
		UIALogger.logMessage("Choosing Profile");
	
		profileTableCell = settingsTable.cells().firstWithName("Profile")
		if (profileTableCell.isValid()) {
			var profileName = profileTableCell.value()
			UIALogger.logMessage("There is 1 profile installed: " + profileName)
			if (profile == "" || profile == profileName) {
				UIALogger.logMessage("Delete the profile: " + profileName)
			} else {
				throw new Error("Could not find the profile you want to deleted: " + profile)
			}
			
			settingsTable.scrollToElementWithName("Profile")
			profileTableCell.tap()
			
			try {
				settings.deleteSelectedProfile(profileName)
			} catch (e) {
				UIALogger.logError(e.message);
				throw new Error("Could not delete profile: " + profileName);
			}
			
		} else {
			profilesTableCell = settingsTable.cells().firstWithName("Profiles")
			if (profilesTableCell.isValid()) {
				var profileValue = profilesTableCell.value()
				UIALogger.logMessage("There are more than 1 profiles installed: " + profileValue)
			} else {
				UIALogger.logMessage("Could not find Profile/Profiles under General, there is no profile installed")
				return;
			}
			
			settingsTable.scrollToElementWithName("Profiles")
			profilesTableCell.tap()
			UIATarget.localTarget().delay(1);
			
			if (profile == "") {
				UIALogger.logMessage("Delete all the profiles")
				if (UIATarget.localTarget().model() == 'iPad') {
					profileTableView = this.mainWindow().tableViews()[1];
				} else {
					profileTableView = this.mainWindow().tableViews()[0];
				}
				for (var i = 1; i < profileDeleteCount+1 ; i++) {
					var deleteCell = profileTableView.cells()[0]
					if (deleteCell.isValid()) {
						deleteCell.tap()
						var deleteCellName = deleteCell.name()
						
						if (deleteCellName == "No profiles are currently installed") {
							UIALogger.logMessage("All profiles deteleted")
							break;
						}
						
						UIALogger.logMessage("Found " + i + " profile to delete: "+ deleteCellName)
						try {
							settings.deleteSelectedProfile(deleteCellName)
						} catch (e) {
							UIALogger.logError(e.message);
							throw new Error("Could not delete profile: " + deleteCellName);
						}
						UIALogger.logMessage(deleteCellName)
					} else {
						UIALogger.logMessage("All preferred networks deteleted")
						break;
					}
					
					UIATarget.localTarget().delay(1);
				}
				
			} else {
				UIALogger.logMessage("Try to delete the profile: " + profile)
			
				if (UIATarget.localTarget().model() == 'iPad') {
					profileTableView = this.mainWindow().tableViews()[1];
				} else {
					profileTableView = this.mainWindow().tableViews()[0];
				}
				var profileCell = profileTableView.cells().firstWithName(profile)
				
				if (profileCell.isVisible()) {
					UIALogger.logMessage("Find the profile need to be deleted")
					profileTableView.scrollToElementWithName(profile)
					profileCell.tap()
				} else {
					throw new Error("Could not find the profile need to be deleted")
				}
				
				try {
					settings.deleteSelectedProfile(profile)
				} catch (e) {
					UIALogger.logError(e.message);
					throw new Error("Could not delete profile: " + profileName);
				}
			}
			
		}
		
	} // end deleteProfile


	//----------------------------------------------------------------------------------------
	//	Function: deleteSelectedProfile 
	//		delete One profile after device is at the detail of the profile page
	//
	//	Parameters:
	//		profile (string) -- profile need to be deleted
	//
	//	Returns: 
	//		None
	//	
	//	Throws:
	//		An error if there is a problem while installing hte profile
	//----------------------------------------------------------------------------------------		
	settings.deleteSelectedProfile = function deleteSelectedProfile(profile) {
		var profileTableView
		
		var profileNavigationBar = this.mainWindow().navigationBars().firstWithPredicate("name == 'Profile' or name == 'Provisioning'");
		if (profileNavigationBar.isValid()) {
			if (UIATarget.localTarget().model() == 'iPad') {
				profileTableView = this.mainWindow().tableViews()[1];
			} else {
				profileTableView = this.mainWindow().tableViews()[0];
			}
			var profileTableCell = profileTableView.cells().firstWithPredicate("name BEGINSWITH '" + profile + "'")
			
			UIALogger.logMessage("Disabling onAlert() handling");
			UIATarget.disableOnAlert = 1;
			
			try {
				profileTableCell.buttons()["Remove"].tap();
			} catch (e) {
				UIALogger.logMessage("Enabling onAlert() handling");
				UIATarget.disableOnAlert = 0;
				UIALogger.logError(e.message);
				throw new Error("Could not choose the Remove button");
			}
		} else {
			throw new Error("Profile Navigation Bar is not valid")
		}
		
		UIATarget.localTarget().pushTimeout(25);
		var actualAlertElement = settings.alert();
		UIATarget.localTarget().popTimeout()
		if (actualAlertElement.isValid()) {
			UIALogger.logMessage("Found an alert...")
			UIATarget.localTarget().delay(1);
			if (actualAlertElement.staticTexts().firstWithPredicate("name == 'Remove Profile' or name == 'Remove Provisioning Profile'").isVisible()) {
				UIALogger.logMessage("The Remove Profile alert window showed up")
				var buttonToTap = actualAlertElement.buttons()["Remove"];
				if (!buttonToTap.isValid()) { 
					UIALogger.logMessage("Enabling onAlert() handling");
					UIATarget.disableOnAlert = 0;
					throw new Error("Could not tap alert button with name matching 'Remove'");
				}
				UIATarget.localTarget().delay(1);
				UIALogger.logMessage("Tapping button 'Remove'");
				buttonToTap.tap();		
				UIATarget.localTarget().delay(1);
				UIALogger.logMessage("Enabling onAlert() handling");
				UIATarget.disableOnAlert = 0;
			} else {
				UIALogger.logMessage("Enabling onAlert() handling");
				UIATarget.disableOnAlert = 0;
				throw new Error("The Remove Profile alert did not show up")
			}

		}
		
	} //end deleteSelectedProfile


	//----------------------------------------------------------------------------------------
	//	Function: setPersonalHotspot 
	//		Enable or Disable Personal Hotspot with given password
	//		Note: To continue the telent session after turn on /off personal hotspot
	//			This test will unload the /System/Library/LaunchDaemons/com.apple.usbethernetsharing.plist
	//
	//	Parameters:
	//		switchValue (string) - Either "1" (ON) or "0" (OFF)
	//		password (string) - password to use for the Personal.
	//		loadUSBTetheringPlistBack (boolean) - true, if you want to load the com.apple.usbethernetsharing.plist
	//			back at the end of the test. This test need to unload the plist to maintain the telnet session.
	//	
	//	Returns: 
	//		None
	//	
	//	Throws:
	//		An error if there is a problem setting the Personal Hotspot
	//----------------------------------------------------------------------------------------	
	settings.setPersonalHotspot = function setPersonalHotspot(switchValue, password, loadUSBTetheringPlistBack) {
		var viewsToNavigate = new Array()
		var switchName = "Personal Hotspot"
		var WiFiCellName = "Wi-Fi"
		
		viewsToNavigate[0] = "General"
		viewsToNavigate[1] = "Network"
		viewsToNavigate[2] = "Personal Hotspot" 
		
		if (typeof switchValue == 'string' ) {
			switchValue = parseInt(switchValue);
		}
		
		if (system.hasWiFiCapability("WAPI")) {
			WiFiCellName = "WLAN"
		}
		
		UIALogger.logMessage("value = " + switchValue + ", password = " + password);
		
		this.launchIfNotActive();
		
		try {
			//Unload the usbthernetsharing plist so the telnet session wont get killed
			try {
				settings.setUSBEthernetTethering(0)
			} catch (e) {
				UIALogger.logMessage(e.message)
			}
			
			this.changeSingleSwitch(viewsToNavigate, switchName, switchValue);
		} catch (e) {
			UIALogger.logError(e.message);
			if (loadUSBTetheringPlistBack) {
				UIATarget.localTarget().delay(3);
				try {
					settings.setUSBEthernetTethering(1)
				} catch (e) {
					UIALogger.logMessage(e.message)
				}
			}
			throw new Error("Could not change Personal Hotspot to " + switchValue + "'");
		}
		
		if (switchValue == 1) {
				try {
					var passwordTable = this.mainWindow().tableViews().firstWithPredicate("ANY cells.name matches '" + WiFiCellName +" Password'");
					passwordTable.cells()[WiFiCellName + " Password"].tap();
				} catch (e) {
					UIALogger.logError(e.message);
					if (loadUSBTetheringPlistBack) {
						UIATarget.localTarget().delay(3);
						try {
							settings.setUSBEthernetTethering(1)
						} catch (e) {
							UIALogger.logMessage(e.message)
						}
					}
					throw new Error("Could not tap the WiFi-Password to input WiFi password")
				}

				var passwordWindow = this.mainWindow().navigationBar().withName(WiFiCellName + " Password")
				if (passwordWindow.isValid()) {
					UIALogger.logMessage("We are in WiFi Password page, input password: " + password)

					var passwordTableCell = this.mainWindow().tableViews().firstWithPredicate("isVisible == 1").cells().firstWithPredicate("ANY secureTextFields.name == 'Password'");
					var passwordTextField = passwordTableCell.secureTextFields()["Password"]
					passwordTextField.buttons()["Clear text"].tap()

					try {
						this.enterTextInTextField(passwordTextField, password);
						passwordWindow.buttons()["Done"].tap();
					} catch (e) {
						UIALogger.logError(e.message);
						if (loadUSBTetheringPlistBack) {
							UIATarget.localTarget().delay(3);
							try {
								settings.setUSBEthernetTethering(1)
							} catch (e) {
								UIALogger.logMessage(e.message)
							}
						}
						throw new Error("Could not input password: " + password + " for WiFi Personal Hotspot")
					}
					
					passwordTable = this.mainWindow().tableViews().firstWithPredicate("ANY cells.name matches '" + WiFiCellName +" Password'");
					passwordValue = passwordTable.cells()[WiFiCellName + " Password"].value()
					
					if (passwordValue == password) {
						UIALogger.logMessage("The password is set as: " + passwordValue)
					} else {
						if (loadUSBTetheringPlistBack) {
							UIATarget.localTarget().delay(3);
							try {
								settings.setUSBEthernetTethering(1)
							} catch (e) {
								UIALogger.logMessage(e.message)
							}
						}
						throw new Error("The password is set as: " + passwordValue + " ; it should be: " + password)
					}
					
				} else {
					if (loadUSBTetheringPlistBack) {
						UIATarget.localTarget().delay(3);
						try {
							settings.setUSBEthernetTethering(1)
						} catch (e) {
							UIALogger.logMessage(e.message)
						}
					}
					throw new Error("The Wi-Fi Password Pane did not show up")
				}
		}
		
		if (loadUSBTetheringPlistBack) {
			UIATarget.localTarget().delay(3);
			try {
				settings.setUSBEthernetTethering(1)
			} catch (e) {
				UIALogger.logMessage(e.message)
			}
		}
		

	} // end setPersonalHotspot
	
	//----------------------------------------------------------------------------------------
	//	Function: setUSBEthernetTethering 
	//		Enable or Disable USB Ethernet Tethering by loading and unloading com.apple.usbethernetsharing.plist
	//		This is for Personal Hotspot tests, by disable the USB Ethernet Tethering, the telnet session won't get killed
	//
	//	Parameters:
	//		value (string) - Either "1" (Enable) or "0" (Disable)
	//	
	//	Returns: 
	//		None
	//	
	//	Throws:
	//		An error if there is a problem setting the USB Ethernet Tethering
	//----------------------------------------------------------------------------------------	
	settings.setUSBEthernetTethering = function setUSBEthernetTethering(value) {
	
		if (typeof value == 'string' ) {
			value = parseInt(switchValue);
		}
		
		if (value == 1) {
			UIALogger.logMessage("Try 'launchctl load /System/Library/LaunchDaemons/com.apple.usbethernetsharing.plist'")
			var result = system.run("/bin/launchctl load /System/Library/LaunchDaemons/com.apple.usbethernetsharing.plist", 5);
			if (result.stderr != "") {
				UIALogger.logMessage("com.apple.usbethernetsharing.plist load Failed")
				//UIALogger.logMessage(result.stderr)
				throw new Error(result.stderr)
			} else {
				UIALogger.logMessage("com.apple.usbethernetsharing.plist loaded")
			}	
		} else {
			UIALogger.logMessage("Try 'launchctl unload /System/Library/LaunchDaemons/com.apple.usbethernetsharing.plist'")
			var result = system.run("/bin/launchctl unload /System/Library/LaunchDaemons/com.apple.usbethernetsharing.plist", 5);
			if (result.stderr != "") {
				UIALogger.logMessage("com.apple.usbethernetsharing.plist unload Failed, the telnet session may get killed during this test")
				//UIALogger.logMessage(result.stderr)
				throw new Error(result.stderr)
			} else {
				UIALogger.logMessage("com.apple.usbethernetsharing.plist unloaded")
			}
		}
		
	} // end setUSBEthernetTethering
	
	//----------------------------------------------------------------------------------------
	//	Function: settings.deletePreferredNetwork 
	//		delete preferred WiFi network from Known Networks UI
	//
	//	Parameters:
	//		network (string) - the network need to be deleted, if network == "", all the networks will
	//		be deleted
	//
	//	Returns: 
	//		None
	//	
	//	Throws:
	//		An error if there is a problem during deleting the networks
	//----------------------------------------------------------------------------------------		
	settings.deletePreferredNetwork  = function deletePreferredNetwork(network) {
		var viewsToNavigate = new Array()
		var switchName = "Known Networks UI"
		var settingsTable;
		var settingsWifiCell;
		var value = 1
		var delete_count = 30

		viewsToNavigate[0] = "Internal Settings"
		viewsToNavigate[1] = "WiFi"

		var WiFiCellName = "Wi-Fi"
	
		if (system.hasWiFiCapability("WAPI")) {
			WiFiCellName = "WLAN"
		} 
		
		UIALogger.logMessage("Turn " + switchName + " ON");

		this.launchIfNotActive();

		try {
			this.changeSingleSwitch(viewsToNavigate, switchName, 1);
		} catch (e) {
			UIALogger.logError(e.message);
			throw new Error("Could not change Known Networks UI to 1");
		}
		
		try {
			settingsTable = this.getToWiFiPreferences()
		} catch (e) {
			UIALogger.logError(e.message);
			throw new Error("Could not get to WiFi Preferences");
		}

		if (UIATarget.localTarget().model() == 'iPad') {
			settingsTable = this.mainWindow().tableViews()[1];
		} else {
			settingsTable = this.mainWindow().tableViews()[0];
		}

		UIALogger.logMessage("Setting " + WiFiCellName + " switch");	
		try {

			var wifiSwitch = settingsTable.cells().firstWithName(WiFiCellName).switches()[0];
			if (wifiSwitch.value() != value) {
				wifiSwitch.setValue(value);
			} else {
				UIALogger.logMessage(WiFiCellName + " switch already set to " + value);
			}

			if (!wifiSwitch.withValueForKey(value, "value").isValid()) {
				throw new Error("Did not set the " + WiFiCellName + " switch to " + value);
			}

		} catch (e) {
			UIALogger.logError(e.message);		
			throw new Error("Could not switch " + WiFiCellName + " setting to " + value);
		}

		var knownNetworkCell = settingsTable.scrollToElementWithName("Known Networks");
		if (knownNetworkCell.isValid()) {
			knownNetworkCell.tap()
			
		} else {
			UIALogger.logMessage("Could not find Known Networks Button, no preffered networks saved")
			return
		}
		
		var knownNetworkNavigationBar = this.mainWindow().navigationBars().firstWithName("Known")
		if (knownNetworkNavigationBar.isValid()) {
			knownNetworkNavigationBar.buttons()["Edit"].tap()
		} else {
			throw new Error("Could not find 'Known' navigation bar")
		}
		
		if (UIATarget.localTarget().model() == 'iPad') {
			settingsTable = this.mainWindow().tableViews()[1];
		} else {
			settingsTable = this.mainWindow().tableViews()[0];
		}
				
		//Delete all the networks
		if (network == "") {
			for (var i = 1; i < delete_count+1 ; i++) {
				knownNetworkNavigationBar = this.mainWindow().navigationBars().firstWithName("Known")
				if (!knownNetworkNavigationBar.isValid()) {
					UIALogger.logMessage("All preferred networks deteleted")
					break;
				}
				
				var deleteCell = settingsTable.cells().firstWithPredicate("ANY switches.name BEGINSWITH 'Delete'")
				if (deleteCell.isValid()) {
					var deleteCellName = deleteCell.name()
					UIALogger.logMessage("Found " + i + " network to delete")
					deleteCell.switches()[0].setValue(1)
					deleteCell.buttons().firstWithPredicate("name BEGINSWITH 'Confirm Deletion'").tap()
					//Log message for which network has been deleted, it will output: Delete AppleWiFi
					UIALogger.logMessage(deleteCellName)
				} else {
					UIALogger.logMessage("All preferred networks deteleted")
					break;
				}
			}
			
		} else {
			var deleteCell = settingsTable.cells().firstWithPredicate("name = '"+ network +"'")
			UIALogger.logMessage("deleteCell name is: "+deleteCell.name())
			
			if (deleteCell.isValid()) {
				UIALogger.logMessage("Found the network: " + network + " to delete")
				deleteCell.switches()[0].setValue(1)
				deleteCell.buttons()["Confirm Deletion for "+ network].tap()
			} else {
				throw new Error("The network you want to delete is not in the preferred network list")
			}
		}

	} // end deletePreferredNetwork
	
	//----------------------------------------------------------------------------------------
	//	Function: disconnectPersonalHotspotClients 
	//
	//		Disconnect all personal hotspot clients for WiFi from UI. 
	//
	//	Parameters:
	//		None
	//
	//	Returns: 
	//		None
	//	
	//	Throws:
	//		An error if there is a problem
	//----------------------------------------------------------------------------------------		
	settings.disconnectPersonalHotspotClients = function disconnectPersonalHotspotClients() {
		var wifiStatus = "Off"
		var disconnectString = "Disconnect Wi-Fi Clients"
		var settingsWifiCell
		
		UIALogger.logMessage("Try to disconnect all the personal hotspot clients")
		try {
			settingsWifiCell = settings.getWiFiTableCell()
			var currentWiFiStatus = settingsWifiCell.value();
			UIALogger.logMessage("The WiFi UI status is: "+currentWiFiStatus)
			
			if (currentWiFiStatus == wifiStatus) {
				throw new Error("The WiFi UI shows as "+wifiStatus+". The personal hotspot may not be on.")
			}
			
		} catch(e) {
			UIALogger.logError(e.message)
			throw new Error("Could not get the current WiFi status from UI")
		}
		
		var settingsTable = this.mainWindow().tableViews()[0];
		var hotspotCell = settingsTable.cells().firstWithName("Personal Hotspot");
		var currentHotspotStatus = hotspotCell.value()
		UIALogger.logMessage("The Personal Hotspot UI status is: "+currentHotspotStatus)
		if (currentHotspotStatus == wifiStatus) {
			throw new Error("The WiFi UI shows as "+wifiStatus+". The personal hotspot may not be on.")
		}
		
		UIALogger.logMessage("Geting apple80211 --stalist")
		var result = system.run("/usr/local/bin/apple80211 --stalist", 5);
		if (result.stderr == "ioctl: Device not configured\n") {
			UIALogger.logError(result.stderr)
			throw new Error("The personal hotspot is not on because because apple80211 --stalist reports it is not configured")
		} else if (result.stdout == "Stations:\nNo stations associated\n") {
			UIALogger.logError(result.stdout)
			throw new Error("The personal hotspot has no client joined")
		} else if (result.stderr != "") {
			UIALogger.logError(result.stderr)
			throw new Error("Could not get station list using apple80211 --stalist")
		} else {
			UIALogger.logMessage("The station list is: ")
			UIALogger.logMessage(result.stdout)
		}
		
		try {
			settings.selectWiFiNetwork(disconnectString)
			UIALogger.logMessage("Find the "+disconnectString)
		} 	catch (e) {
			UIALogger.logError(e.message);		
			throw new Error("Could not find the "+disconnectString);
		}
		
		var disconnectButton = settings.actionSheet().buttons()["Disconnect"]
		if (disconnectButton.isValid()) {
			disconnectButton.tap()
			UIALogger.logMessage("Tapped Disconnect Button")
		} else {
			throw new Error("Did not pop up Disconnect Button")
		}
		
		UIATarget.localTarget().delay(3);
		UIALogger.logMessage("Geting apple80211 --stalist")
		var result = system.run("/usr/local/bin/apple80211 --stalist", 5);
		if (result.stderr == "ioctl: Device not configured\n") {
			UIALogger.logMessage("apple80211 --stalist: "+result.stderr)
			UIALogger.logMessage("All client disconnected")
		} else {
			UIALogger.logError("apple80211 --stalist output is: "+result.stdout)
			UIALogger.logError("apple80211 --stalist error output is: "+result.stderr)
			throw new Error("apple80211 --stalist shows wrong status")
		}
	
	} // end disconnectPersonalHotspotClients
	
	//----------------------------------------------------------------------------------------
	//	Function: getWiFiTableCell 
	//		Get WiFi TableCell from settings pane
	//
	//	Parameters:
	//		None
	//	
	//	Returns: 
	//		settingsWifiCell
	//	
	//	Throws:
	//		An error if there is a problem to get to the WiFi TableCell
	//----------------------------------------------------------------------------------------		
	settings.getWiFiTableCell = function getWiFiTableCell() {
		var settingsTable;
		var settingsWifiCell;
		var WiFiCellName = "Wi-Fi"
		
		if (system.hasWiFiCapability("WAPI")) {
			UIALogger.logMessage("This is a China device, will use WLAN not Wi-Fi")
			WiFiCellName = "WLAN"
		}
		
		UIALogger.logMessage("Try to get "+WiFiCellName+" Tablcell");
		
		settings.launchIfNotActive();
		
		//Return to the top-most level in the Settings hierarchy
		settings.returnToTopLevel();
		
		UIATarget.localTarget().pushTimeout(1);
		
		settingsTable = this.mainWindow().tableViews()[0];
		
		UIATarget.localTarget().popTimeout();
		
		try {
			settingsWifiCell = settingsTable.cells().firstWithName(WiFiCellName);
			return settingsWifiCell
		} catch(e) {
			 UIALogger.logError(e.message);
			throw new Error("Could not find the "+WiFiCellName+" TableCell");
		}
	} // end getWiFiTableCell
	
	//----------------------------------------------------------------------------------------
	//	Function: getToWiFiPreferences 
	//		Enter WiFi Preferences
	//
	///	Parameters:
	//		None
	//
	//	Returns: 
	//		None
	//	
	//	Throws:
	//		An error if there is a problem to enter WiFi Preferences
	//----------------------------------------------------------------------------------------		
	settings.getToWiFiPreferences = function getToWiFiPreferences() {
		var settingsWifiCell
		var WiFiCellName = "Wi-Fi"
		
		if (system.hasWiFiCapability("WAPI")) {
			UIALogger.logMessage("This is a China device, will use WLAN not Wi-Fi")
			WiFiCellName = "WLAN"
		}
		
		try {
			settingsWifiCell = settings.getWiFiTableCell()
		} catch (e) {
			UIALogger.logError(e.message);		
			throw new Error("Could not get to "+WiFiCellName+" TableCell");
		}
		
		UIALogger.logMessage("Choosing "+WiFiCellName);
		try {
			settings.chooseSetting(WiFiCellName);
			UIALogger.logMessage("Entered WiFi Preferences")
		} catch (e) {
			UIALogger.logError(e.message);
			throw new Error("Could not tap the "+WiFiCellName+" table element");
		}

		//Wait for all of the networks to load and animations to cease
		if (UIATarget.localTarget().model() == 'iPad') {
			UIATarget.localTarget().delay(7);
		} else {
			UIATarget.localTarget().delay(3);;
		}
	
	} // end getToWiFiPreferences

	// --------------------------------------------------------------------------------
	//	Function: checkWAPIUI
	//		check if China device shows WLAN not WiFi on UI
	//
	//	Parameters:
	//	 	None
	//
	//	Returns:
	//		ture/false
	//
	//  Throws:
	//		An error if there is a problem
	// --------------------------------------------------------------------------------

	settings.checkWAPIUI = function checkWAPIUI() {
		var WiFiCellName = "WLAN"
		var settingsTable

		if (system.hasWiFiCapability("WAPI")) {
			UIALogger.logMessage("This is a China device, will use WLAN not Wi-Fi")	
		} else {
			UIALogger.logError("This is not a China device, could not run this test")
			return false
		}

		try {
			settings.getToWiFiPreferences();
		} catch (e) {
			UIALogger.logError(e.message)
			throw new Error ("Coud not enter WiFi Preferences")
		}

		if (UIATarget.localTarget().model() == 'iPad') {
			settingsTable = this.mainWindow().tableViews()[1];
		} else {
			settingsTable = this.mainWindow().tableViews()[0];
		}

		UIALogger.logMessage("Trying to find the WLAN switch");	
		try {

			var wifiSwitch = settingsTable.cells().firstWithName(WiFiCellName).switches()[0];
			if (wifiSwitch.isValid()) {
				UIALogger.logMessage("Find the switch: " + WiFiCellName);
			} else {
				throw new Error("Could not find the switch: " + WiFiCellName);
			}

		} catch (e) {
			UIALogger.logError(e.message);		
			throw new Error("Could not find the switch: " + WiFiCellName);
		}

		UIALogger.logMessage("Trying to find the WLAN Networks Title in WiFi Preferences");
		var WLANNavigationBar = this.mainWindow().navigationBars().firstWithName(WiFiCellName + " Networks")
		if (WLANNavigationBar.isVisible()) {
			UIALogger.logMessage("Find the title: " + WiFiCellName + "Networks");
		} else {
			throw new Error("Could not find the title: " + WiFiCellName + " Networks");
		}

		UIALogger.logMessage("Trying to find the WLAN Address Table Cell in General-->About");

		var viewsToNavigate = new Array()
		viewsToNavigate[0] = "General"
		viewsToNavigate[1] = "Network"
		viewsToNavigate[2] = "WLAN"

		UIALogger.logMessage("Navigating the view hierarchy with path: " + viewsToNavigate.join( " -> " ) );

		try {
			this.navigateNavigationViews(viewsToNavigate, {returnToTopLevel:true});
		} catch (e) {
			UIALogger.logError(e.message);
			throw new Error("Could not navigate to '" + viewsToNavigate.join( " -> " ) + "'");
		}

		viewsToNavigate = new Array()
		viewsToNavigate[0] = "General"
		viewsToNavigate[1] = "About"
		viewsToNavigate[2] = "WLAN Address"

		UIALogger.logMessage("Navigating the view hierarchy with path: " + viewsToNavigate.join( " -> " ) );

		try {
			this.navigateNavigationViews(viewsToNavigate, {returnToTopLevel:true});
		} catch (e) {
			UIALogger.logError(e.message);
			throw new Error("Could not navigate to '" + viewsToNavigate.join( " -> " ) + "'");
		}
		
		return true
	} // end checkWAPIUI
	
	//----------------------------------------------------------------------------------------
	//	Function: getSettingsTable 
	//		Get Settings Table from current settings pane (for iPad, it is the right side table)
	//
	//	Parameters:
	//		None
	//	
	//	Returns: 
	//		settingsTable
	//	
	//	Throws:
	//		An error if there is a problem to get the settingsTable
	//----------------------------------------------------------------------------------------		
	settings.getSettingsTable = function getSettingsTable() {

		UIALogger.logMessage("Try to get the Settings Table");

		if (UIATarget.localTarget().model() == 'iPad') {
			return this.mainWindow().tableViews()[1];
		} else {
			return this.mainWindow().tableViews()[0];
		}

	} // end getSettingsTable

	
	// --------------------------------------------------------------------------------
	//	Function: setForwardingPhoneNumber
	//		Set the forwarding phone number for a device
	//
	//	Parameters:
	//		forwardingSetting (int) - 1 or 0 to turn forwarding on or off, respectively
	//		phoneNumber (string) - the phone number to forward to - any formatting is 
	//								allowed - all spaces, parenthases and hyphens will
	//								be stripped from this parameter, leaving any formatting 
	//								to be handled by the Settings app
	//
	//	Returns:
	//		1 on pass, 0 on fail.  
	// --------------------------------------------------------------------------------
	settings.setForwardingPhoneNumber = function setForwardingPhoneNumber(phoneForwardingSetting, phoneNumber) {
		
		this.launchIfNotActive();
		// Sanitize the phone number by removing any parenthases, spaces or hyphens.  The app will do any 
		// formatting for us once we enter the phone # and return to the Call Forwarding settings view
		
        if (phoneNumber) {
            UIALogger.logDebug("Phone Number before sanitization: " + phoneNumber);
            phoneNumber = phoneNumber.replace(/[\(\) -]/g, "");
            UIALogger.logDebug("Phone Number after sanitization: " + phoneNumber);
        }
		
		var navigationArray = new Array("Phone");
		
		this.navigateNavigationViews(navigationArray);
		var settingsTable = this.mainWindow().tableViews()[0];
		
		var cell = settingsTable.cells().firstWithName("Call Forwarding");

		if (!cell.isValid()) {

            if (phoneForwardingSetting == 0) {
                UIALogger.logMessage("Disabling CDMA Call forwarding (no validation performed)");
                phone.makeCall(["*73"]);
            } else {
                UIALogger.logMessage("Enabling CDMA Call Forwarding (no validation performed)");
                phone.makeCall(["*72" + phoneNumber]);
            }

        } else {
            
            cell.tap();
            UIATarget.localTarget().delay(15);
            
            var forwardingSwitch = this.mainWindow().tableViews()[0].cells().firstWithName("Call Forwarding").switches()[0];
            
            if (!forwardingSwitch.isVisible()) throw new Error("Could not find the call forwarding switch");
            UIALogger.logMessage("Switch is visible");
            UIALogger.logMessage("Setting the 'Call Forwarding' switch to " + phoneForwardingSetting);
            forwardingSwitch.setValue(phoneForwardingSetting);            
                        
            if (phoneForwardingSetting == 0) {
                //Turned forwarding off (check to see that button is switched off and 'Forward To' cell is gone
                if (forwardingSwitch.value() == 0 && !settingsTable.cells().firstWithName("Forward to").isValid()) return;
                else {
                    this.logElementTree();
                    throw new Error("Did not successfully turn off Call Forwarding");
                }
            } else {
                //Turning forwarding on again (Set switch and tap 'Forwarding To')
                //Forwarding is already on (tap 'Forwarding To')
                //Turning forwarding on for the first time (Automatically taken to 'Forwarding To' view)
                
                var forwardToCell = settingsTable.cells().firstWithName("Forward to");

                if (forwardToCell.isValid()) forwardToCell.tap();
                
                //Let any animations settle
                UIATarget.localTarget().delay(10);
                if (!this.mainWindow().navigationBar().staticTexts().firstWithName("Forwarding To").isValid()) {
                    this.logElementTree();
                    throw new Error("Could not reach the 'Forwarding To' view");
                }
            }

            var textField = settingsTable.cells()[0].textFields()[0];
            if (!textField.isValid()) {
                this.logElementTree();
                throw new Error("Text field is not a valid UIElement");
            }

            UIALogger.logMessage("Setting the phone number to: " + phoneNumber);
            UIATarget.localTarget().delay(5);
            textField.setValue(phoneNumber);
            UIATarget.localTarget().delay(5);		
            this.navigationBar().leftButton().tap();
            
            // Allow any animations to finish and Settings to update the 'Forwarding To' table cell
            UIATarget.localTarget().delay(10);
            
            var forwardingPhoneNoCell = settingsTable.cells().firstWithName("Forward to");
            
            if (!forwardingPhoneNoCell.isValid()) {
                this.logElementTree();
                throw new Error("Could not find the 'Forward to' table cell");
            }
            
            if (phoneNumber != forwardingPhoneNoCell.value().replace(/[\(\) -]/g, "")) {
                this.logElementTree();
                throw new Error("Specified phone number does not match the new forwarding phone number");
            }
            UIALogger.logDebug("New call forwarding # is: " + forwardingPhoneNoCell.value()	);
        } 
		
        

		return;

	} // end setForwardingPhoneNumber
	
	
	//----------------------------------------------------------------------------------------
	//	Function: turnLocationdLoggingOn 
	//		A library method to turn on locationd logging.  This method checks the locationd 
	//		daemon pid, restarts locationd via the UI, and checks to see if the pid has changed
	//		after the daemon was restarted
	//
	//	Parameters:
	//		None
	//	
	//	Returns: 
	//		none 
	//	
	//	Throws:
	//		An error if the locationd daemon could not be restarted
	//----------------------------------------------------------------------------------------			
	settings.turnLocationdLoggingOn = function turnLocationdLoggingOn() {

		var navigationArray = new Array("Internal Settings", "Location", "General Location");
		this.changeSingleSwitch( navigationArray, "Log Locations", 1);
		
		// Restart the locationd daemon
		var cell = this.getSettingsTable().cells().firstWithName("Restart Location Daemon");
		cell.scrollToVisible();
		
		var getPid = function getPid() {
			
			var result = system.run("/usr/bin/top -l1", 5).stdout;
			var lines = result.split("\n");
			for (line in lines) {
				
				if (lines[line].match(/locationd/)) {
					UIALogger.logMessage("line: " + lines[line]);
					return lines[line].split(" ")[0];
				}
			}
			throw new Error("Did not find locationd in the top output");
		} // end getPid
		
		UIALogger.logMessage("Getting the current locationd pid.")
		var pidBefore = getPid();
		UIALogger.logDebug("Current locationd pid = " + pidBefore);
		
		cell.tap();
		
		UIATarget.localTarget().delay(10);
		
		UIALogger.logMessage("Getting the new locationd pid.")
		var pidAfter = getPid();
		
		UIALogger.logDebug("Current locationd pid after restarting daemon = " + pidAfter);
		
		if ( pidBefore != pidAfter ) {
			UIALogger.logMessage("Location Daemon has been restarted");
		} else {
			throw new Error = "Location daemon did not restart after 10 seconds";
		}
		
		return;
		
	}	// end turnLocationdLoggingOn

 	
	//----------------------------------------------------------------------------------------
	//	Function: _escapeQuotes 
	//		A helper function to escape quotes.  the regular UIAUtility method is overkill - 
	//		only quotes need to be escaped. 
	//
	//	Parameters:
	//		string (string) - string with quotes to escape
	//	
	//	Returns: 
	//		escaped string 
	//	
	//	Throws:
	//		nothing
	//----------------------------------------------------------------------------------------			
	settings._escapeQuotes = function _escapeQuotes(string) {
			return string.replace(/([\"\'])/, "\\$1");
	}
	
	//----------------------------------------------------------------------------------------
	//	Function: setCarrierAPN 
	//		Sets the Main APN text field in Carrier Settings to the specified string.
	//
	//	Parameters: 
	//		apn (string) - string to enter into the text field.
	//
	//	Returns: 
	//		None
	//
	//	Throws:
	//		An exception if the function isn't able to set the text field.
	//----------------------------------------------------------------------------------------
	settings.setCarrierAPN = function setCarrierAPN(apn) {
		settings.launchIfNotActive();
		this.getToSpecifiedSetting(['Carrier Settings']);
		
		try {
			this.enterTextInTextField(this.getSettingsTable().cells().firstWithName("APN").textFields()["APN"], apn);
		} catch (e) {
			throw new Error(e.message);
		}
		
		return true
	}

	//----------------------------------------------------------------------------------------
	//	Function: tryOTAUpdate 
	//		Check to see if there is an OTA update available.   If so it triggers download and install.
	//
	//	Returns: 
	//
	//	Throws:
	//		An exception if an update is not available
	//----------------------------------------------------------------------------------------
	settings.tryOTAUpdate = function tryOTAUpdate() {
        UIALogger.logDebug("Trying to trigger OTA Upate"	);
        UIALogger.logDebug("Currently Apple VPN must be enabled for this to work!"	);
		settings.launchIfNotActive();
        UIALogger.logDebug("Clicking to General"	);
		this.getToSpecifiedSetting(['General']);
	    UIALogger.logDebug("Clicking update"	);
	    settings.mainWindow().tableViews()["Empty list"].elements()["Software Update"].tap();

		UIATarget.localTarget().delay(2); // give it a change to start searching

		if( settings.mainWindow().tableViews()["Empty list"].elements()["Downloading\u2026"].isVisible() )
		{
	    		UIALogger.logDebug("Download In progress");
			throw new Error("Download In progress");
		}

		// Checking can take a while, push a delay to make sure we don't beat the server.
		UIATarget.localTarget().pushTimeout(60);
		try {

        		UIALogger.logDebug("Waiting For Server"	);
			settings.mainWindow().tableViews()["Empty list"].elements()["Download and Install"].tap()
        		UIALogger.logDebug("Clicking Download and Install"	);
		} catch (e) {
			UIATarget.localTarget().popTimeout();
			throw new Error("Download and Install Not Found, likely network error");
		}
		UIATarget.localTarget().popTimeout();
		return true
	}



}

