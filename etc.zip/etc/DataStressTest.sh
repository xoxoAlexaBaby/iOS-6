#!/bin/sh

LOOPS=$1
COUNT=0
pass=0
fail=0
rm DataStress.txt DataFailureStress.txt

date
startTime=`date "+%s"`
COUNT=0
sleep 2
elapsedTime=0
currentTime=$startTime
tStartTime=`date -r $startTime`
echo "Current Time - $currentTime"
lastKOOLStateTime=$startTime
timeForKOOLState=0

while [ $COUNT -lt $LOOPS ]
do
	((COUNT++))

	# Activate the Data Context
	echo "\n\n ****** Beginning Iteration - $COUNT *************" 
	echo "\n\n *** Beginning Iteration - $COUNT ****" >> PDPStress.txt
	echo "Activating Data Context"
	/usr/local/bin/DataContext -c 1 up > dummy.txt
	sleep 1
	egrep -i "Failed" dummy.txt
   	resultData=$?
	cat dummy.txt >> PDPStress.txt

	# Checking the Call Success/Failure
	if [ $resultData -ne 0 ]; then
		((pass++))
        echo `date` ": Data Call Establishment ($COUNT) Passed."
   	else
		((fail++))
		echo `date` ": Data Call Establishment ($COUNT) Failed."
		echo `date` ": Data Call Establishment ($COUNT) FAILED." >> DataFailureStress.txt
		killall -USR2 CommCenter
	fi
	
	echo "\n\n ****** Beginning Iteration - $COUNT *************"  >> DownloadStress.txt
	echo `date` ": $COUNT. Downloading data"  >> DownloadStress.txt
	echo "1. Data Download begin..."
	/usr/local/bin/StreamPerf HTTP -c 1 http://17.254.20.251/10MB.txt  > Download.txt
	cat Download.txt >> DownloadStress.txt
	cat Download.txt
	
	# sleep for 60 seconds before to go into dormancy mode
	echo "Sleeping for 60 seconds to allow the device to go to dormant mode..."
	sleep 60
	
	# Try data transfer now after dormancy
	echo `date` ": $COUNT. Downloading data after entering dormancy"  >> DownloadStress.txt
	echo "2. Data Download begin..."
	/usr/local/bin/StreamPerf HTTP -c 1 http://17.254.20.251/1MB.txt  > Download.txt
	cat Download.txt >> DownloadStress.txt
	cat Download.txt
	
	# Bringing down the Data Call
	echo "Bringing down the DataContext"
	/usr/local/bin/DataContext -c 1 down
	
	echo "Calculating timers..."
	currentTime=`date "+%s"`
	elapsedTime=$(($currentTime - $startTime))
	timeForKOOLState=$(($currentTime - $lastKOOLStateTime))
	tCurrentTime=`date -r $currentTime`
	
	echo "DATA DOWNLOAD STRESS Start Time = $startTime *** Current Time = $currentTime, $tCurrentTime,"
	echo "DATA DOWNLOAD STRESS  *** Elapsed Time = $elapsedTime"
	echo "DATA DOWNLOAD STRESS KOOLSTATE Timer = $timeForKOOLState, Last KOOLSTATE = $lastKOOLStateTime\n"

	if [ $timeForKOOLState -ge 1800 ]; then
		echo "Taking *KOOL*STATE"
		killall -USR2 CommCenter
		lastKOOLStateTime=$currentTime
		sleep 10
	fi
	
	echo  `date` ": $COUNT Data Calls were made so far... Passed: $pass Failed: $fail."
	echo " Sleeping for 10 seconds...\n\n"
	sleep 10
	
done
