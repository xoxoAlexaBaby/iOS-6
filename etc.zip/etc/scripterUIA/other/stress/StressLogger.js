#import "../../libs/UIALogger.js"

//set the log file format
stdoutLogger.logString = function logString(info) {
    var typeString = UIALogger._stringForLogType(info.type);
    var d = info.date;
    var monStr = d.getMonth() + 1;
    var dayStr = d.getDate();
    var hrStr = d.getHours();
    var minStr = d.getMinutes();
    var secStr = d.getSeconds();
    
    if (monStr < 10) { monStr = "0" + monStr }
    if (dayStr < 10) { dayStr = "0" + dayStr }
    if (hrStr < 10) { hrStr = "0" + hrStr }
    if (minStr < 10) { minStr = "0" + minStr }
    if (secStr < 10) { secStr = "0" + secStr }

    var dateString = monStr + "/" + dayStr + "/" + d.getFullYear();
    var timeString = hrStr + ":" + minStr + ":" + secStr;
    return dateString + " " + timeString + " [SCRIPTER]\t" + info.callerFunction + ": " + info.message;
}