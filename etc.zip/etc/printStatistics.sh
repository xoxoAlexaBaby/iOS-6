#!/bin/sh
#################################################################################################
#                                                                                               #
#   ScriptName: printStatistics.sh                                                              #
#                                                                                               #
#   Usage:      <path_to_Script>/printStatistics.sh                                             #
#                                                                                               #
#   Purpose:    This Scripts helps in printing the Statistics for Stress Tests                  #
#                                                                                               #
#   Author:     Jerome Jesu                                                                     #
#   Contact:    jesu@apple.com                                                                  #
#   Version:    v20                                                                             #
#                                                                                               #
#   Copyright   2010 Apple. All rights reserved.                                                #
#################################################################################################


TOOLSDIR="/usr/local/bin"


###########################################################################
#Function to Convert given run time in seconds to HH:MM:SS
# USAGE: calculateTime RUN_TIME (in seconds) [1 to output to Stats file, 0 otherwise] 
###########################################################################
calculateTime()
{
	runTime=$1;
	hours=$(($runTime / 3600)); hours2=$(($hours * 3600));
	mins2=$(($runTime - $hours2)); mins=$(($mins2 / 60));
	abSecs=$(($hours * 3600 + $mins * 60)); secs=$(($runTime - $abSecs));
	if [ $hours -lt 10 ]; then  hours=`echo "0$hours"`;  fi
	if [ $mins -lt 10 ];  then  mins=`echo "0$mins"`;    fi
	if [ $secs -lt 10 ];  then  secs=`echo "0$secs"`;    fi
	totalTime="$hours:$mins:$secs"
	if [ $2 -eq 1 ]; then echo " Total RunTime : $totalTime, RunTime (in secs): $runTime." >> Stats.txt;	fi
	echo $totalTime
}

###########################################################################
# Function to calculate Percentages
# USAGE: calculatePercent <total Fails/Pass> <Total>
###########################################################################
calculatePercent()
{
	if [ $2 -ne 0 ]; then  Percent=$((100 * $1 / $2)); fi
	echo $Percent
}

###########################################################################
# FUNCTION to process the CSI logs and report the number of crashes and Call Drops
###########################################################################
processCsiLogs()
{
	echo `date` ": _____PROCESSING CSI LOGS - $dcount _____"  >> $LOGSFILE
	totalCsiLogs=`ls $csiLogsDir/*csi* | wc -l | tr -d ' '`
	
	echo "\n ****************  LOG DETAILS:  *********************"
	echo "TOTAL LOGS-$totalCsiLogs"
	
} 


###########################################################################
# Function to print the IPC Stress Test statistics to a CSV File.
###########################################################################
printIPCStatistics()
{
	cp  $logFiles  $csiLogsDir/
	
	testCurrentTime=$2
	testStartTime=$1	
	tcurTime="0"
	tcurTime=`date -r $testCurrentTime | cut -c5-19`
	tStartTime=`date -r $testStartTime | cut -c5-19`
	runTime=$(($testCurrentTime - $testStartTime))
	tRunTime=`calculateTime $runTime 255`
	callFailPercent=`calculatePercent $fail $callCount`
	smsFailPercent=`calculatePercent $sfail $smsCount`

	lastLogTime=$tcurTime
	if [ $minUpTime -le 0 ]; then  minUpTime=$(($firstResetTime - $startTime)); fi
	#echo "Calculating Download Data Rate/Failures..."		
	
	echo "START_TIME, CURRENT_TIME, IMEI, DEVICE_NAME, AP_BUILD, BB_BUILD, ITERATIONS, Total BB RESETS, Total_CALLS, Total_SMS, CALL_DROPS, CALL_FAILURES, FTOs, Download_Attempts, Download Pass, Download Fails, DataFailPercent, DownloadDataRate, Upload_Attempts, AvgUploadDataRate, CallFails_CT, SMSFails_CT, START_TIME(s), CURRENT_TIME(s), RUN_TIME(s), FirstResetTime(s), D3, PDPActAttempts, PDPActFAIL, UDID, RUN_TIME (Hours), VERSION, Hardware, SERIAL, CRASHES, TARGET, "
	
	echo "$tStartTime, $tcurTime, $IMEI, $DEVICENAME, $APBuild, $BB_Build, $dcount, $totalBBResets, $callCount, $smsCount, $totalCallDrops, $totalCallFailures, $totalFTO, $DataAttempts, $dataPassCount , $dataFailCount3, $dataFailPercent, $downloadDataRate, $uploadAttempts, $uploadDataRate, $fail, $sfail, $testStartTime, $testCurrentTime, $runTime, $minUpTime, $dataFailCount --$dataFailCount2, $pdpAttempts, $pdpFails, $UDID, $tRunTime, $VERSION, $Hardware, $SERIAL, $crash, $LOOPS, "
	
	echo "$tStartTime, $tcurTime, $IMEI, $DEVICENAME, $APBuild, $BB_Build, $dcount, $totalBBResets, $callCount, $smsCount, $totalCallDrops, $totalCallFailures, $totalFTO, $DataAttempts, $dataPassCount , $dataFailCount3, $dataFailPercent, $downloadDataRate, $uploadAttempts, $uploadDataRate, $fail, $sfail, $testStartTime, $testCurrentTime, $runTime, $minUpTime, $dataFailCount --$dataFailCount2, $pdpAttempts, $pdpFails, $UDID, $tRunTime, $VERSION, $Hardware, $SERIAL, $crash, $LOOPS, " >> $ResultsFile
		
}
