#!/usr/bin/perl
open (LOG, "> /var/logs/WiPASmini/WiPASmini.d.log") or die $!;
$oldh = select (LOG); $| = 1;
#select ($oldh);
$success = 0;
# unload CommCenter
system ("/bin/launchctl unload /System/Library/LaunchDaemons/com.apple.CommCenter.plist");
# power off BB
system ("/usr/local/bin/bbctl powercycle");
system ("/bin/sleep 9");
# power on BB
$bbfwname = "/usr/local/standalone/firmware/Baseband/Mav5/Mav5-personalized.zip";
$cmd = '/usr/local/bin/BBUpdaterSupreme uf -a -z ' . $bbfwname . ' -w';
print ("$cmd\n");
open (PS, "$cmd |") or die $!;
while (<PS>)
{
	$line = $_;
	print ("%s", $line);
}
close (PS);
print ("sleep 10...\n");
system ("sleep 10");
# UART BB ping
$cmd = '/usr/local/bin/ETLTool UART 115200 ping';
print ("$cmd\n");
$success = 0;
for ($m = 0; ($m < 20) && !$success; $m++)
{
	open (PS, "$cmd |");
	while (<PS>)
	{
		$line = $_;
		print ("#%s", $line);
		if ($line =~ /Software Version Strings/)
		{
			$success = 1;
		}
	}
	close (PS);
}
# Configuring to HSIC
$cmd = '/usr/local/bin/ETLTool UART 115200 raw 4b fd 31 00 06 00 00 00';
system ("$cmd\n");
system ("sleep 1");
# HSIC BB ping
$cmd = '/usr/local/bin/ETLTool ping';
print ("$cmd\n");
$success = 0;
for ($m = 0; ($m < 3) && !$success; $m++)
{
	open (PS, "$cmd |");
	while (<PS>)
	{
		$line = $_;
		print ("#%s", $line);
		if ($line =~ /Software Version Strings/)
		{
			$success = 1;
		}
	}
	close (PS);
}
close (LOG);
