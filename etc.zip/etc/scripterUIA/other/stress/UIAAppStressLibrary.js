#import "../../libs/SpringBoard.js"
#import "../../libs/PHTesting.js"

// set the log file format
stdoutLogger.logString = function logString(info) {
    var typeString = UIALogger._stringForLogType(info.type);
    var d = info.date;
    var monStr = d.getMonth() + 1;
    var dayStr = d.getDate();
    var hrStr = d.getHours();
    var minStr = d.getMinutes();
    var secStr = d.getSeconds();
    
    if (monStr < 10) { monStr = "0" + monStr }
    if (dayStr < 10) { dayStr = "0" + dayStr }
    if (hrStr < 10) { hrStr = "0" + hrStr }
    if (minStr < 10) { minStr = "0" + minStr }
    if (secStr < 10) { secStr = "0" + secStr }

    var dateString = monStr + "/" + dayStr + "/" + d.getFullYear();
    var timeString = hrStr + ":" + minStr + ":" + secStr;
    return dateString + " " + timeString + " " + typeString + "\t" + info.callerFunction + ": " + info.message;
}

// imports for all the test areas
#import "../../appstore/AppStoreTests.js"
#import "../../calculator/CalculatorTests.js"
#import "../../calendar/CalendarTests.js"
#import "../../camera/CameraTests.js"
#import "../../clock/ClockTests.js"
#import "../../contacts/ContactsTests.js"
#import "../../ipod/iPodTests.js"
#import "../../mail/MailTests.js"
#import "../../maps/MapsTests.js"
#import "../../messages/MessagesTests.js"
#import "../../notes/NotesTests.js"
#import "../../phone/PhoneTests.js"
#import "../../safari/SafariTests.js"
#import "../../settings/SettingsTests.js"
#import "../../springboard/SpringboardTests.js"
#import "../../stocks/StocksTests.js"
#import "../../system/SystemTests.js"
#import "../../weather/WeatherTests.js"
#import "../../youtube/YouTubeTests.js"


if (typeof topLevelRandom == 'undefined') topLevelRandom = new RandomGenerator();

// global stress vars
gAppStressDataPath = "/Library/Logs/AppStressResults.plist";
gAppStressWarningPath = "/Library/Logs/AppStressWarnings.plist";
gAppStressLogPath = "/Library/Logs/AppStressStatus.log";
gWarnings = new Object();
gPlistID = "com.apple.AppStress"; // plist identifier for storing counters and other persistent data
gAppStressAudioObject = new AudioObject(); // for tracking audio
gWifiBackupName = "AppleWiFi";
gWifiBackupPassword = "";
gWifiNamePath = "/var/root/wifiName";
gDefaultPasscode = "1234";

// turn on app switcher
UIAApp.prototype.shouldUseSwitcherForLaunching = true;

//for Matt D.
function whatami(item) {
    if (item.___mark___) {
            system.println("WARNING: This item has already been seen!");
    } else {
            item.___mark___=1;
    }

    var type = typeof item;
    system.println(type + " : " + String(item));
    if (type == "object") {
            system.println("<");
            for (var key in item) {
                    whatami(item[key]);
            }
            system.println(">");
    }
}


// base stress test prototype
function AppStressBase(name) {
	if (name == null) throw new Error("No specified name");
	
	this.name = name;
}

AppStressBase.stressTest = function stressTest(name) {
	var appTest = AppStressBase._appTests[name];
	if (appTest == null) {
		appTest = new AppStressBase(name)
		appTest.tests = new Array();
		AppStressBase._appTests[name] = appTest;
	}
	
	return appTest;
}

AppStressBase._appTests = new Array();

AppStressBase.prototype.setup = function setup() { return true }
AppStressBase.prototype.init = function init() { return true }
AppStressBase.prototype.run = function run() { }

AppStressBase.prototype.tests = null;

AppStressBase.prototype.addTest = function addTest (testFunction, weight) {
	var testCase = new AppStressTestCase(testFunction);
	
	if (weight == null) { weight = 1 }
	
	for (var i = 0; i < weight; i++) {
		this.tests.push(testCase);		
	}
}

AppStressBase.prototype.executeRandomTests = function executeRandomTests (maxIterations) {
	if (this.tests.length == 0) {
		UIALogger.logError("No tests are defined for this test area.");
		return;
	}
	
	var iterations = system.randomInteger(1, maxIterations);
	
	for (var i = 0; i < iterations; i++) {
		this.executeRandomTest();
	}
}


AppStressBase.prototype.executeRandomTest = function executeRandomTest () {
	if (this.tests.length == 0) {
		UIALogger.logError("No tests are defined for this test area.");
		return;
	}
	
	var test = UIAUtility.randomFromArray(this.tests);
	test.run();
}


AppStressBase.prototype.executeAllTests = function executeAllTests() {
	var testsRun = new Array();
	
	for (index in this.tests) {
		if (testsRun.indexOf(this.tests[index].name) < 0) { 
			this.tests[index].run();
			testsRun.push(this.tests[index].name);
		}
	}	
}


AppStressBase.prototype.executeTest = function executeTest (testName, testArgs, testFunction, testDesc) {
	var test;
	
	UIALogger.logStart("Starting Test: " + this.name + ':' + testName);
	UIALogger.logMessage(testDesc);
	
	test = phtCreateTest(testName, testArgs, testFunction, testDesc);
	
	try {
		test.execute();
	}
	catch(e) {
		test.testResult = 0;
		test.testError = e.message;
		test.onException(e);
	}
	
	try {
		gAppStressData.addResult("All", test.testName, test.testResult);
		gAppStressData.logResult("StressTestFormat", "All", test.testName);
	}
	catch (e) {
		UIALogger.logError("ERROR: " + e);
	}
	
	//Set the timeout to the default timeout
	if (UIATarget.localTarget().timeout() != UIATarget.defaultTimeout) 
		UIATarget.localTarget().setTimeout(UIATarget.defaultTimeout);
	
	return test.testResult;
}
	
// base stress test case prototype
function AppStressTestCase(testFunction) {
	this.run = testFunction;
}

// test area prototype
function StressTestArea(name, test, weight, setupFunc, initFunc)
{ 
	this.name = name;
	this.test = test;
	this.weight = weight;
	
	if (setupFunc != null) {
		this.test.setup = setupFunc;
	}
	
	if (initFunc != null) {
		this.test.init = initFunc;
	}
}

StressTestArea.prototype.runArea = function runArea() {
	test = this.test;
	
	UIATarget.localTarget().unlockScreenIfNecessary(gDefaultPasscode);
	
	UIALogger.logMessage(this.name + ": executing init()");
	if (test.init() == false) {
		throw new Error(test.name + " init() failed -- skipping tests.");
	}
	
	UIALogger.logMessage(this.name + ": executing run()");
	test.run();
}

// test data object

//--------------------------------------------------------------------------------
//	TestData - creates an object that can be used to load and store testing data to a plist
//
//	Arguments:
// 		(dataPath) - string - path where the plist is stored
//
//	Return:
// 		the object
//
//--------------------------------------------------------------------------------
function TestData(dataPath) {
	this.dataPath = dataPath;
	
	// this is a workaround for a bug in the javascript bridge that 
	// creates arrays instead of dictionaries
	function _fixData(source) {
		var newObject = new Object();
		for (var item in source) {
			if (((typeof source[item]) == 'object') || ((typeof source[item]) == 'array')) {
				newObject[item] = _fixData(source[item]);
			} else newObject[item] = source[item];
		}
		return newObject;
	}
	
	function _logData(data, header) {
		if (!header) {
			system.println("\nLogging data!");			
			header = "";
		}
		for (var item in data) {
			if ((typeof data[item]) == 'object') {
				_logData(data[item], header + item + ":");
			} else system.println("(" + (typeof data[item]) + ") " + header + item + "=" + data[item]);
		}
	}
	
	function _walkNodes(data, keys) {
		var node = data;
		for (var nodeIndex = 0; nodeIndex < keys.length; nodeIndex++) {
			if ((typeof node[keys[nodeIndex]] == 'undefined') || (!node[keys[nodeIndex]])) node[keys[nodeIndex]] = new Object();
			node = node[keys[nodeIndex]];
		}
		return node;
	}
	
	// inc a counter stored at the root level of the object (create and init the property if it doesn't exist)
	this.incCounter = function(keys) {
		var finalKey, node = this.data;
		if (typeof keys == 'object') {
			if (keys.length > 1) node = _walkNodes(node, keys.slice(0, keys.length-1));
			finalKey = keys[keys.length-1];
		} else finalKey = keys;
	
		if (typeof node[finalKey] != "number") node[finalKey] = 1;
		else node[finalKey] += 1;
		return node[finalKey];
	}
	
	// return the current value of a counter stored at the root level of the object
	this.getCounter = function(keys) {
		var finalKey, node = this.data;
		if (typeof keys == 'object') {
			if (keys.length > 1) node = _walkNodes(node, keys.slice(0, keys.length-1));
			finalKey = keys[keys.length-1];
		} else finalKey = keys;
	
		if (typeof node[finalKey] != "number") return 0;
		else return node[finalKey];
	}
	
	// set a property value for a given key or array of keys to traverse stored in the data object
	this.setDataForKey = function(keys, value) {
		var finalKey, node = this.data;
		if (typeof keys == 'object') {
			if (keys.length > 1) node = _walkNodes(node, keys.slice(0, keys.length-1));
			finalKey = keys[keys.length-1];
		} else finalKey = keys;
			
		node[finalKey] = value;
	}
	
	// lookup, by key or array of keys to traverse, the current property value stored in the data object
	this.dataForKey = function(keys) {
		var finalKey, node = this.data;
		if (typeof keys == 'object') {
			if (keys.length > 1) node = _walkNodes(node, keys.slice(0, keys.length-1));
			finalKey = keys[keys.length-1];
		} else finalKey = keys;
			
		if (typeof node[finalKey] == "undefined") return null;
		else return node[finalKey];
	}	
	
	// reset the property used to track the begining of an execution to the current time
	this.markExecutionStart = function() {
		this.incCounter("ExecutionCount");
		this.data["ExecutionStart"] = new Date().getTime();
	}
	
	// set the property used to track the begining and end of testing to the current time
	this.markTestStart = function() {
		this.data["TestStart"] = new Date().getTime();
	}
	
	// store a pass/fail type result for a given area / test
	this.addResult = function(testArea, testName, testResult) {
		var testRunTime = new Date() - this.data["TestStart"];
		if (typeof this.data["RunTime"] != "number") {
			this.data["RunTime"] = testRunTime;
		} else {
			this.data["RunTime"] += testRunTime;
		}
		
		var counterToInc = testResult ? "PassCount" : "FailCount";
		this.incCounter(counterToInc);
		this.incCounter([testArea, testName, counterToInc]);		
	}
	
	function _formatTime(time) {
		var msPerSec = 1000;
		var msPerMin = 60*msPerSec;
		var msPerHour = 60*msPerMin;
			
		// format the time
		var hours = Math.floor(time/msPerHour);
		var remTime = time - (hours*msPerHour);
		var minutes = Math.floor(remTime/msPerMin);
		remTime = remTime - (minutes*msPerMin);
		var seconds = Math.floor(remTime/msPerSec);
		
		// add preceeding zeros if needed
		if (minutes.length < 2) minutes = "0" + seconds;
		if (seconds.length < 2) seconds = "0" + seconds;
		
		var formatedTime = hours + " hour(s), " + minutes + " minute(s), " + seconds + " second(s)";
	
		return formatedTime;
	}
	
	function _timeSince(time) {
		var now = new Date().getTime();
		return now - time;
	}
	
	// returns the elapsedTime (in ms) since the beginning of last test
	this.elapsedTestTime = function() {
		return _timeSince(this.data.TestStart);
	}
	
	// returns the elapsedTime since the beginning of last test as a formatted string
	this.elapsedTestTimeFormatted = function() {
		return _formatTime(elapsedTestTime);
	}
	
	// print out a summary of the results
	// format allows alternate formatting to be used for different scenerios (currently we just have one that we used for stress tests)
	// testArea and testName are optional and allow additional summary data for a specific test to be included
	this.logResult = function(format, testArea, testName) {
		var now = new Date();
	
		var totalPassCount = this.getCounter("PassCount");
		var totalFailCount = this.getCounter("FailCount");
		var totalCount = totalPassCount + totalFailCount;
		var percentPass = (totalPassCount/totalCount)*100;
		var percentFail = (totalFailCount/totalCount)*100;
		
		var dropCount = this.getCounter("DropCount");
		var callCount = this.getCounter("CallCount");
		var sleepCount = this.getCounter("SleepCount");
		
		var divider = new Array(80).join("_");
	
		var startTime;
		var totalElapsedTime;
		if (typeof this.data.StartTime == "number") {
			startTime = new Date(this.data.StartTime);
			totalElapsedTime = _formatTime(_timeSince(this.data.StartTime));
		} else {
			startTime = "NA";
			totalElapsedTime = "NA";
		}
		
		var runTime = (typeof this.data["RunTime"] != "number") ? "NA" : _formatTime(this.data["RunTime"]);
	
		var executionStart;
		var executionElapsedTime;
		
		if (typeof this.data["ExecutionStart"] == "number") {
			executionStart = new Date(this.data["ExecutionStart"]);
			executionElapsedTime = _formatTime(_timeSince(this.data["ExecutionStart"]));
		} else {
			executionStart = "NA";
			executionElapsedTime = "NA";
		}
		var executionCount = this.getCounter("ExecutionCount");
		
		var testStart;
		var testElapsedTime;
		if (typeof this.data.TestStart == "number") {
			testStart = new Date(this.data.TestStart);
			testElapsedTime = _formatTime(_timeSince(this.data.TestStart));
		} else {
			testStart = "NA";
			testElapsedTime = "NA";
		}		
		
		switch (format) {
			case "StressTestFormat":
				if ((typeof this.data[testArea] == "object") && (typeof this.data[testArea][testName] == "object")) {
					var testPassCount = (typeof this.data[testArea][testName]["PassCount"] != "number") ? 0 : this.data[testArea][testName]["PassCount"];
					var testFailCount = (typeof this.data[testArea][testName]["FailCount"] != "number") ? 0 : this.data[testArea][testName]["FailCount"];
					var testCount = testPassCount + testFailCount;
					var percentTestPass = (testPassCount/testCount)*100;
					system.println("(test has been run " + testCount + " time(s) and passed " + percentTestPass.toFixed(2) + "% of the time)");
					system.println("");
				}
				system.println("Current Time: " + now);
				system.println("Execution " + executionCount + " started " + executionStart);
				system.println("(" + executionElapsedTime + " minutes since we restarted the script)");
				system.println("Testing started " + startTime);
				// this should be total runtime not total time since the beginning of testing
				system.println("Total Test Time: " + totalElapsedTime);
				system.println("Drops:\t" + dropCount + " out of " + callCount);				
				system.println("Pass:\t" + totalPassCount + " (" + percentPass.toFixed(2) + "%)");
				system.println("Fail:\t" + totalFailCount + " (" + percentFail.toFixed(2) + "%)");
				system.println("Total:\t" + totalCount + " (" + sleepCount + " sleepcycles) " );
				break;
			case "AppExerciserFormat":
				system.println(divider);
				system.println("");				
				system.println("Tesing on application '" + testArea + "' started " + testStart);
				system.println("(" + testElapsedTime + " of testing this application)");
				if (typeof this.data[testArea] == "object") {
					var initialMem = gAppExerciserData.dataForKey([testArea, "InitialPrivateMemory"])/(1024*1024);
					var finalMem = gAppExerciserData.dataForKey([testArea, "FinalPrivateMemory"])/(1024*1024);
					system.println("Memory Regions/Resident Size (Private): initial=" + initialMem.toFixed(2) + "MB, final=" + finalMem.toFixed(2) + "MB");
					var actionCount = this.data[testArea]["ActionCount"];
					if (!actionCount) actionCount = 0;
					system.println(actionCount + " action(s) performed on " + testArea);
					if (this.data[testArea]["UISwitchCount"]) system.println("The UI was switched " + this.data[testArea]["UISwitchCount"] + " times.");
					if (this.data[testArea]["CrashCount"]) {
						system.println(divider);
						system.println("");
						var crashLogs = this.data[testArea]["CrashLogs"];
						system.println(crashLogs.length + " crash(es) occurred while testing " + testArea + ".");
						for (var crashIndex = 0; crashIndex < crashLogs.length; crashIndex++) {
							UIALogger.logMessage("\t" + _harness_processNameFromCrashLogPath(crashLogs[crashIndex]) + " crash", crashLogs[crashIndex], 1);
						}
					}
				}
				system.println(divider);
				system.println("");			
				system.println("Current Time: " + now);
				system.println("Testing started " + startTime);
				system.println("Total Testing Time: " + totalElapsedTime);
				system.println("");							
			default:
				if ((typeof this.data[testArea] == "object") && (typeof this.data[testArea][testName] != "undefined")) {
					system.println(testArea + "->" + testName + ": " + this.data[testArea][testName]);
				}
		}
	}
	
	// write the data object out to disk
	this.archive = function(dataPath) {
		if (dataPath) this.dataPath = dataPath;
		
		if (!this.data) {
			UIALogger.logMessage("No data to write");
			return null;
		}

		if( !system.writeObjectToDisk(this.dataPath, this.data) ){
			UIALogger.logError("Failed to write " + this.dataPath);
		}
	}
	
	// reset that data to an init state	
	this.reset = function() {
		var now = new Date();	
		this.data = new Object();
		this.data["StartTime"] = now.getTime();
		this.data["Version"] = 1;
	}
	
	var data = system.readObjectFromDisk(dataPath);
	if (!data) {
		this.reset();
	} else {
		this.data = _fixData(data);
	}
}

// warnings

//--------------------------------------------------------------------------------
//	Warnings Support
//
//	Warnings are cases in which we want to do specific warnings on.  The runner
//	of the script can choose to halt the script if a warning occurs.  The warnings 
//	system ensures that a given "trigger" is only logged once (if SpringBoard warns
//	above 10 MB and continues to leak, we don't want 100 warnings).  It is designed
//	to warn similar to:
//	"SpringBoard: Private Memory Above 10 MB (11 MB) - After 3 hours 2 minutes"
//	if multiple warnings trigger, it will read the range of the warnings, and specify 
//	only the time the warnings started to kick in:
//	"SpringBoard: Private Memory Above 10 MB (11 MB - 25 MB) - After 3 hours 2 minutes"
//--------------------------------------------------------------------------------
function ValueTimePair(value,time)
{
	this.value = value;
	this.time = time;
}

function Warning(message,value,process,pid)
{	
	this.message = message;
	this.initialValue = this.lastValue = this.lowValue = this.highWatermark = new ValueTimePair(value,(new Date().getTime()));	
	this.processName = process;
	this.pid = pid;
	
	this.appendValue = function(value){		
		var valuePair = new ValueTimePair(value,(new Date().getTime()));
		
		// Save as high water mark if appropriate
		if( value > this.highWatermark.value )
			this.highWatermark = valuePair;
		
		if( value < this.lowValue.value )
			this.lowValue = valuePair;
		
		// Save as last value
		this.lastValue = valuePair;
		
		return true;
	}
	
	this.messageString = function(startDate){
		var message = this.processName + " (" + this.pid + "): " + this.message;
		
		if( this.lowValue.value == this.highWatermark.value){
			message += " ( " + this.lowValue.value.toFixed(2) + " ) ";
		}else{
			message += " ( " + this.lowValue.value.toFixed(2) + " - " + this.highWatermark.value.toFixed(2) + " ) ";			
		}
				
		if( startDate ){
			message = message + " " + UIAUtility.getFormattedTime((this.initialValue.time - startDate)/1000);			
		}
	
		message += " first at " + new Date(this.initialValue.time);
		
		
		return message;
	}
}

function loadWarningsFromDictionaries(warningsFromDisk)
{	
	for( var warn in warningsFromDisk ){
		var warnings = warningsFromDisk[warn];
				
		for( var index in warnings ){
			var warning = warnings[index];
			
			var realWarning = new Warning(warning.warn,warning.value,warning.processName,warning.pid);
			
			realWarning.message = warning.message;
			realWarning.initialValue = new ValueTimePair(warning.initialValue.value,warning.initialValue.time);
			realWarning.lastValue = new ValueTimePair(warning.lastValue.value,warning.lastValue.time);
			realWarning.lowValue = new ValueTimePair(warning.lowValue.value,warning.lowValue.time);
			realWarning.highWatermark = new ValueTimePair(warning.highWatermark.value,warning.highWatermark.time);
			
			if( !gWarnings[warn] )
				gWarnings[warn] = new Array();
			
			gWarnings[warn].push(realWarning);			
		}
	}
	
	return true;
}


function markWarning(message,value,process,pid)
{
	// Load an array of warnings
	var warnings = gWarnings[process + ":" + message];
	var warning;
		
	// If there is no warning array, make one
	if( !warnings ){
		warnings = new Array();
		gWarnings[process + ":" + message] = warnings;
	}
	
	if( warnings.length ){
		warning = warnings[warnings.length - 1];
		
		// If the pid does not match with our current warning
		// we don't want to use it
		if( warning.pid == pid )
			warning.appendValue(value);
		else
			warning = undefined;

	}
	
	// If we don't have a valid warning, create a new one
	// and put it into our array
	if( !warning ){
		warning = new Warning(message,value,process,pid);
		warnings.push(warning);
	}
	
	
	return warning;
}


function warnOnAppMemoryUsage(processID,memoryInMB)
{
	// process object is not implemented for simulator
	if (system.isOnSimulator()) return false;
	
	var proc = system.process[processID];
	var memory;
	
	if(!proc){
		return false;
	}
	
	//return false on -1 memoryInMB
	if (memoryInMB < 0) {
		return false;
	};
	
	memory = proc["Memory Regions/Resident Size (Private)"];
	
	// temp workaround for <rdar://problem/5787512>
	// try to resample the process if the result was greater than 250MB on N88 or 100MB on all earlier devcies (obviously a bogus value)
	var sampleAttempts = 1;
	var bogusMemoryLevel = 250;
		
	while (memory && ( memory > (bogusMemoryLevel * 1024 * 1024) )) {
		if (sampleAttempts++ > 10) {
			UIALogger.logWarning("Got bad data from libtop too many times.  Skipping.")
			return false;
		}
		
		system.sleep(0.25);
		proc = system.process[processID];
		if (!proc) return;
		memory = proc["Memory Regions/Resident Size (Private)"];
	}

	if( !memory )
		return false;
	
	//if we get here, it means that we have the RPRVT value for the process
	//If the value is bigger than the limit that was passed in, get the purgeable memory value
	//and subtract it from the RPRVT value to get our actual memory usage
	//Compare that new value to our limit value and only warn if that value is bigger.
	if( memory > (memoryInMB * 1024 * 1024) ){
		var result;
		var vmmapOutput = "";
		try {
			UIALogger.logMessage("Running vmmap on " + proc["Command"]);
			result = system.run("/usr/bin/vmmap -purge -dirty " + proc["Command"], 300);
			vmmapOutput = result.stdout;
			vmmapOutput = vmmapOutput.match(/^PURGEABLE.*/m).toString();
		} catch(error) {
			UIALogger.logError("Error running vmmap.  Setting output to null.");
			vmmapOutput = null;
		}
				
		if (vmmapOutput) {
			var purgeableOutputArray = vmmapOutput.split(/\s+/);
			
			//get the value in the 2 slot and chomp off the last char which is a slash
			//ex output: 1123K/
			var purgeableString = purgeableOutputArray[2].substring(0, purgeableOutputArray[2].length-1);

			var purgeableValue = Number(purgeableString.substring(0, purgeableString.length-1));
			
			//adjust for Kilobytes and Megabytes
			if (purgeableString.charAt(purgeableString.length-1) == "K") {
				purgeableValue = purgeableValue * 1024;
			} 
			else if (purgeableString.charAt(purgeableString.length-1) == "M") {
				purgeableValue = purgeableValue * 1024 * 1024;
			}
			else{
				UIALogger.logWarning("Invalid character found in vmmap output.  Not adjusting for purgeable memory.");
				UIALogger.logWarning(purgeableOutputArray[2].toString());
				purgeableValue = 0;
			}
		}
		else{
			var purgeableValue = 0;
		}
			
		//check again with the adjusted value.  Warn if we're still bigger.
		if (memory - purgeableValue > (memoryInMB * 1024 * 1024) ) {
			var message = "Private Memory above " + memoryInMB + " MB";
			
			UIALogger.logWarning(proc["Command"] + "(" + proc["pid"] + ") " + message + "  RPRVT: " + memory + "  Purgeable: " + purgeableValue);
			
			markWarning(message,(memory - purgeableValue)/(1024*1024),proc["Command"],proc["pid"] );

			return true;
		}
		
	}
	
	return false;
}

//NOTE: checkForWarnings makes calls (getSystemInfo and process) that are not supported on the Simulator
function checkForWarnings(startDate, startSeed, haltOnWarnings)
{
	var halts = 0;
	var warning;
	var portWatchPoints = new Object();
	var rprvtWatchPoints = new Object();
	var mediaApps = ["MobileMusicPlaye", "YouTube", "Nike", "mediaserverd"];
	var procWhiteList = ["kernel_task", "heap", "leaks", "ports", "portleakwatch", "dtrace", "sample", "shark"];
		
	var WARNING_LEVELS_CONFIG_FILE = "com.apple.AppStressWarningLevels";
	
	// Check system level warnings
	var	sysWarnings = system.getSystemInfo();
	
	//check wired memory
	var wiredLevels = system.getDefault(WARNING_LEVELS_CONFIG_FILE, "Wired");
	//if we have a wired memory value, check the wired memory levels
	if (wiredLevels) {
		var wiredMemLevel =wiredLevels.warningLevel;
		var wiredHaltLevel = wiredLevels.overrideHaltOnWarningLevel;
		//wiredHaltLevel is only different when a value for wiredHaltLevel is read from the plist.  If wiredHaltLevel is NULL, set wiredHaltLevel to wiredMemLevel
		if (!wiredHaltLevel) {
			wiredHaltLevel = wiredMemLevel;
		};
		
		var wiredLevelInMB = sysWarnings["Physical Memory/Wired"]/1048576;
		if(wiredLevelInMB > wiredMemLevel){
			var message = "Wired Memory above " + wiredMemLevel + " MB";
			UIALogger.logWarning("Warning", message + "(" + wiredLevelInMB + ").");
			markWarning(message,wiredLevelInMB, "System", 0 );
			//if we are halting on warnings, wiredHaltLevel is not set to -1 (turns off halt on warning for specific processes), and wired memory is above the wiredHaltLevel value
			//stop offending app and SpringBoard.  If it's mediaserverd, also stop all media apps
			if ((haltOnWarnings && (wiredHaltLevel >= 0) && (wiredLevelInMB > wiredHaltLevel))) {
				message = "Halting.  Wired Memory above " + wiredMemLevel + " MB";
				markWarning(message,wiredLevelInMB, "System", 0 );
				stopProc("configd");
				stopProc("SpringBoard");
				for(var proc in mediaApps) {
					stopProc(mediaApps[proc])
				};
				halts++;
			};		
		}
	};

	portWatchPoints = system.getDefault(WARNING_LEVELS_CONFIG_FILE, "Port Levels");
	rprvtWatchPoints = system.getDefault(WARNING_LEVELS_CONFIG_FILE, "Memory Levels");
	
	//if we didn't get anything for the portWatchPoints or the rprvtWatchPoints, we likely don't have a plist installed and can't do any warnings.
	if (!portWatchPoints || !rprvtWatchPoints) {
		UIALogger.logWarning("checkForWarnings", "Error.  Cannot find watch points.  Not logging warnings.");
		return false;
	};
	
	//memory warnings loop
	for( var procID in system.process ){
		var proc = system.process[procID];
		if (!proc) continue;  // process may have ended (ignore it)
		var procName = proc["Command"];
		var warningProc = null;
		
		//get the warnings data for the process
		//libtop gives us the proc name chopped at 17 chars.  This for loop allows the warnings plist to not care about that.
		for (var warnProcID in rprvtWatchPoints) {
			var finalWarnID = warnProcID.substr(0, 16);
			
			if (procName == finalWarnID) {
				warningProc = rprvtWatchPoints[warnProcID];
				break;
			}
		}
		
		//skip any procs on the white list
		var skipThisOne = false;
		for (var i=0; i < procWhiteList.length; i++) {
			if (procName == procWhiteList[i].substr(0, 16)) {
				skipThisOne = true;
				break;
			}
		}//end for
		if (skipThisOne) {
			continue;
		}
		
		//set the memoryWarningLevel and the memoryHaltLevel.  If no value is found, use the defaults.
		if (warningProc) {
			var memoryWarningLevel = warningProc.warningLevel;
			var memoryHaltLevel = warningProc.overrideHaltOnWarningLevel;
		} else{
			// If we don't have a specific warning point, then
			// we use 4 MB for lowercase (deamons), 12 MB Upper Case
			var firstChar = procName.charAt(0);
			
			if( (firstChar > "a") && (firstChar <= "z" ) ){
				var memoryWarningLevel = rprvtWatchPoints["Default Small"].warningLevel;
				var memoryHaltLevel = rprvtWatchPoints["Default Small"].overrideHaltOnWarningLevel;
			}
			else {
				var memoryWarningLevel = rprvtWatchPoints["Default Big"].warningLevel;
				var memoryHaltLevel = rprvtWatchPoints["Default Big"].overrideHaltOnWarningLevel;
			};
		};
		
		//memoryHaltLevel is only different when a value for memoryHaltLevel is read from the plist.  If memoryHaltLevel is NULL, set memoryHaltLevel to memoryWarningLevel
		if (!memoryHaltLevel) {
			memoryHaltLevel = memoryWarningLevel;
		};
		
		//check to see if we hit a warning level
		if(warnOnAppMemoryUsage(procID,memoryWarningLevel)){
			
			//if the memoryHaltLevel and the memoryWarningLevel are the same, then you don't need to check the memoryHaltLevel again; you know you need to halt
			var haltTest = false;
			if (haltOnWarnings && (memoryHaltLevel == memoryWarningLevel)) {
				haltTest = true;
			}
			else {
				//since the values of memoryHaltLevel and memoryWarningLevel are different
				//check if we are halting on warnings, portHaltLevel is not -1 (turns off halt on warning for specific processes), and ports is bigger than the portHaltLevel
				if (haltOnWarnings && (memoryHaltLevel >= 0) && warnOnAppMemoryUsage(procID, memoryHaltLevel)) {
					haltTest = true;
				};
			};
			
			if (haltTest) {
				//stop offending app and SpringBoard.  If it's mediaserverd, also stop all media apps
				stopProc("SpringBoard");
				if (procName == "mediaserverd") {
					for(var proc in mediaApps) {
						stopProc(mediaApps[proc]);
					};
				}
				else {
					stopProc(proc["Command"], proc["pid"]);
				};
				halts++;
			};
		}
	}
	
	//port warnings loop
	for( var procID in system.process ){
		var proc = system.process[procID];
		if (!proc) continue;  // process may have ended (ignore it)
		var procName = proc["Command"];

		//skip any procs on the white list
		var skipThisOne = false;
		for (var i=0; i < procWhiteList.length; i++) {
			if (procName == procWhiteList[i].substr(0, 16)) {
				skipThisOne = true;
				break;
			}
		}//end for
		if (skipThisOne) {
			continue;
		}
		
		var ports = proc["Kernel Resources/Mach Ports"];
		var portProc = null;
		
		//get the warnings data for the process
		//libtop gives us the proc name chopped at 17 chars.  This for loop allows the warnings plist to not care about that.
		for (var portProcID in portWatchPoints) {
			var finalPortID = portProcID.substr(0, 16);
			
			if (procName == finalPortID) {
				portProc = portWatchPoints[portProcID];
				break;
			}
		}
		
		//set the portWarningLevel and the portHaltLevel.  If no value is found, use the defaults.
		if (portProc) {
			var portWarningLevel = portProc.warningLevel;
			var portHaltLevel = portProc.overrideHaltOnWarningLevel;
		}
		else {
			var portWarningLevel = portWatchPoints["Default"].warningLevel;
			var portHaltLevel = portWatchPoints["Default"].overrideHaltOnWarningLevel;
		};
		
		//portHaltLevel is only different when a value for portHaltLevel is read from the plist.  If portHaltLevel is NULL, set portHaltLevel to portWarningLevel
		if (!portHaltLevel) {
			portHaltLevel = portWarningLevel;
		};
		
		//check for warnings
		if( ports > portWarningLevel ){
			var message = "mach ports above " + portWarningLevel;
			UIALogger.logWarning(proc["Command"] + "(" + proc["pid"] + ") " + message + "(" + ports + ").");
			markWarning(message,ports,procName,proc["pid"]);
			
			//if we are halting on warnings, portHaltLevel is not -1 (turns off halt on warning for specific processes), and ports is bigger than the portHaltLevel
			//stop offending app and SpringBoard.  If it's mediaserverd, also stop all media apps
			if (haltOnWarnings && (portHaltLevel >= 0) && (ports > portHaltLevel)) {
				stopProc("SpringBoard");
				if (procName == "mediaserverd") {
					for(var proc in mediaApps) {
						stopProc(mediaApps[proc]);
					};
				}
				else {
					stopProc(proc["Command"], proc["pid"]);
				};
				halts++;
			};
		}
	}
	
	//Log Warnings
	var objectToWrite = new Object();
	
	objectToWrite["warnings"] = gWarnings;
	objectToWrite["originalseed"] = startSeed;
	objectToWrite["startTime"] = startDate.getTime();
	objectToWrite["version"] = 3;
	
	if( !system.writeObjectToDisk(gAppStressWarningPath,objectToWrite) ){
		system.println("***Failed to write " + gAppStressWarningPath );
	}

	return (0 != halts);
}


//NOTE: checkForWarnings makes calls (getSystemInfo and process) that are not supported on the Simulator
//function checkForWarnings(startDate, startSeed, haltOnWarnings)
//{
//	var halts = 0;
//	var warning;
//	var warningProc;
//	var portWatchPoints = new Object();
//	var rprvtWatchPoints = new Object();
//	var mediaApps = ["MobileMusicPlaye", "YouTube", "Nike", "mediaserverd"];
//	var procWhiteList = ["kernel_task", "heap", "leaks", "ports", "portleakwatch", "dtrace", "sample", "shark"];
//		
//	var WARNING_LEVELS_CONFIG_FILE = "com.apple.AppStressWarningLevels";
//	
//	// Check system level warnings
//	var	sysWarnings = system.getSystemInfo();
//	
//	//check wired memory
//	var wiredLevels = system.getDefault(WARNING_LEVELS_CONFIG_FILE, "Wired");
//	//if we have a wired memory value, check the wired memory levels
//	if (wiredLevels) {
//		var wiredMemLevel =wiredLevels.warningLevel;
//		var wiredHaltLevel = wiredLevels.overrideHaltOnWarningLevel;
//		//wiredHaltLevel is only different when a value for wiredHaltLevel is read from the plist.  If wiredHaltLevel is NULL, set wiredHaltLevel to wiredMemLevel
//		if (!wiredHaltLevel) {
//			wiredHaltLevel = wiredMemLevel;
//		};
//		
//		var wiredLevelInMB = sysWarnings["Physical Memory/Wired"]/1048576;
//		if(wiredLevelInMB > wiredMemLevel){
//			var message = "Wired Memory above " + wiredMemLevel + " MB";
//			UIALogger.logWarning(message + "(" + wiredLevelInMB + ").");
//			markWarning(message,wiredLevelInMB, "System", 0 );
//			//if we are halting on warnings, wiredHaltLevel is not set to -1 (turns off halt on warning for specific processes), and wired memory is above the wiredHaltLevel value
//			//stop offending app and SpringBoard.  If it's mediaserverd, also stop all media apps
//			if ((haltOnWarnings && (wiredHaltLevel >= 0) && (wiredLevelInMB > wiredHaltLevel))) {
//				message = "Halting.  Wired Memory above " + wiredMemLevel + " MB";
//				markWarning(message,wiredLevelInMB, "System", 0 );
//				stopProc("configd");
//				stopProc("SpringBoard");
//				for(var proc in mediaApps) {
//					stopProc(mediaApps[proc])
//				};
//				halts++;
//			};		
//		}
//	};
//
//	portWatchPoints = system.getDefault(WARNING_LEVELS_CONFIG_FILE, "Port Levels");
//	rprvtWatchPoints = system.getDefault(WARNING_LEVELS_CONFIG_FILE, "Memory Levels");
//	
//	// if we didn't get anything for the portWatchPoints or the rprvtWatchPoints, 
//	// we likely don't have a plist installed and can't do any warnings.
//	if (!portWatchPoints || !rprvtWatchPoints) {
//		UIALogger.logError("Error.  Cannot find watch points.  Not logging warnings.");
//		return false;
//	};
//	
//	for( var procID in system.process ){
//		var proc = system.process[procID];
//		if (!proc) continue;  // process may have ended (ignore it)
//		var procName = proc["Command"];
//	
//		//skip any procs on the white list
//		var skipThisOne = false;
//		for (var i=0; i < procWhiteList.length; i++) {
//			if (procName == procWhiteList[i].substr(0, 16)) {
//				skipThisOne = true;
//				break;
//			}
//		}//end for
//		if (skipThisOne) {
//			continue;
//		}
//		
//		// check memory warnings
//		for (var warnProcID in rprvtWatchPoints) {
//			var finalWarnID = warnProcID.substr(0, 16);
//			
//			if (procName == finalWarnID) {
//				warningProc = rprvtWatchPoints[warnProcID];
//				break;
//			}
//		}
//		
//		// set the memoryWarningLevel and the memoryHaltLevel.  If no value is found, use the defaults.
//		if (warningProc) {
//			var memoryWarningLevel = warningProc.warningLevel;
//			var memoryHaltLevel = warningProc.overrideHaltOnWarningLevel;
//		} else{
//			// If we don't have a specific warning point, then
//			// we use 4 MB for lowercase (deamons), 12 MB Upper Case
//			var firstChar = procName.charAt(0);
//			
//			if( (firstChar > "a") && (firstChar <= "z" ) ){
//				var memoryWarningLevel = rprvtWatchPoints["Default Small"].warningLevel;
//				var memoryHaltLevel = rprvtWatchPoints["Default Small"].overrideHaltOnWarningLevel;
//			}
//			else {
//				var memoryWarningLevel = rprvtWatchPoints["Default Big"].warningLevel;
//				var memoryHaltLevel = rprvtWatchPoints["Default Big"].overrideHaltOnWarningLevel;
//			};
//		};
//		
//		// memoryHaltLevel is only different when a value for memoryHaltLevel is read from the plist.  
//		// If memoryHaltLevel is NULL, set memoryHaltLevel to memoryWarningLevel
//		if (!memoryHaltLevel) {
//			memoryHaltLevel = memoryWarningLevel;
//		};
//		
//		// check to see if we hit a warning level
//		if(warnOnAppMemoryUsage(procID,memoryWarningLevel)){
//			
//			// if the memoryHaltLevel and the memoryWarningLevel are the same, 
//			// then you don't need to check the memoryHaltLevel again; you know you need to halt
//			var haltTest = false;
//			if (haltOnWarnings && (memoryHaltLevel == memoryWarningLevel)) {
//				haltTest = true;
//			}
//			else {
//				// since the values of memoryHaltLevel and memoryWarningLevel are different
//				// check if we are halting on warnings, portHaltLevel is not -1 
//				// (turns off halt on warning for specific processes), and ports is bigger than the portHaltLevel
//				if (haltOnWarnings && (memoryHaltLevel >= 0) && warnOnAppMemoryUsage(procID, memoryHaltLevel)) {
//					haltTest = true;
//				};
//			};
//			
//			if (haltTest) {
//				// stop offending app and SpringBoard.  If it's mediaserverd, also stop all media apps
//				stopProc("SpringBoard");
//				if (procName == "mediaserverd") {
//					for(var proc in mediaApps) {
//						stopProc(mediaApps[proc]);
//					};
//				}
//				else {
//					stopProc(proc["Command"], proc["pid"]);
//				};
//				halts++;
//			};
//		}
//		
//		// check port warnings
//		var ports = proc["Kernel Resources/Mach Ports"];
//		var portProc = null;
//		
//		// set the portWarningLevel and the portHaltLevel.  If no value is found, use the defaults.
//		if (portProc) {
//			var portWarningLevel = portProc.warningLevel;
//			var portHaltLevel = portProc.overrideHaltOnWarningLevel;
//		}
//		else {
//			var portWarningLevel = portWatchPoints["Default"].warningLevel;
//			var portHaltLevel = portWatchPoints["Default"].overrideHaltOnWarningLevel;
//		};
//		
//		// portHaltLevel is only different when a value for portHaltLevel is read from the plist.  
//		// If portHaltLevel is NULL, set portHaltLevel to portWarningLevel
//		if (!portHaltLevel) {
//			portHaltLevel = portWarningLevel;
//		};
//		
//		//check for warnings
//		if( ports > portWarningLevel ){
//			var message = "mach ports above " + portWarningLevel;
//			UIALogger.logWarning(proc["Command"] + "(" + proc["pid"] + ") " + message + "(" + ports + ").");
//			markWarning(message,ports,procName,proc["pid"]);
//			
//			// if we are halting on warnings, portHaltLevel is not -1 
//			// (turns off halt on warning for specific processes), and ports is bigger than the portHaltLevel
//			// stop offending app and SpringBoard.  If it's mediaserverd, also stop all media apps
//			if (haltOnWarnings && (portHaltLevel >= 0) && (ports > portHaltLevel)) {
//				stopProc("SpringBoard");
//				if (procName == "mediaserverd") {
//					for(var proc in mediaApps) {
//						stopProc(mediaApps[proc]);
//					};
//				}
//				else {
//					stopProc(proc["Command"], proc["pid"]);
//				};
//				halts++;
//			};
//		}
//	}
//	
//	//Log Warnings
//	var objectToWrite = new Object();
//	
//	objectToWrite["warnings"] = gWarnings;
//	objectToWrite["originalseed"] = startSeed;
//	objectToWrite["startTime"] = startDate.getTime();
//	objectToWrite["version"] = 3;
//	
//	if( !system.writeObjectToDisk(gAppStressWarningPath,objectToWrite) ){
//		UIALogger.logError("Failed to write " + gAppStressWarningPath );
//	}
//
//	return (0 != halts);
//}


//----------------------------------------------------------------------------------------
//AudioObject - Object that handles keeping track of variables involved with playing
//	a playlist of songs while running other tests.
//----------------------------------------------------------------------------------------
function AudioObject() { }

AudioObject.prototype.shouldBePlayingMusic = false;
AudioObject.prototype.numberOfTimesMusicHasBeenStarted = 0;
AudioObject.prototype.numberOfTimesMusicHasQuit = 0;

AudioObject.prototype.checkIfAudioIsPlayingAndUpdateObject = function () {
	if (this.shouldBePlayingMusic) {
		try {
			var audioIsPlaying = audio.verifyMusicIsPlaying(5);
		} catch (e) {
			var audioIsPlaying = false;
			UIALogger.logError("Encountered error: " + e.message);
		}
		
		if (audioIsPlaying) {
			UIALogger.logMessage("Playing music as expected.");
			return true;
		}
		else if (telephony.getCallCount() > 0) {
			// on a call -- we were playing music, but don't really know if it's still going...
			UIALogger.logMessage("Should be playing music, but we're on a call now.");
			return true;
		}
		else {
			// something went wrong and we are no longer playing music.
			this.numberOfTimesMusicHasQuit++;
			this.shouldBePlayingMusic = false;
			UIALogger.logError("No longer playing music, but we should be.");
			return false;
		}
	}
	
	UIALogger.logMessage("We are not supposed to be playing music.");
	return false;
}

AudioObject.prototype.startPlayingMusic = function () {
	if (this.shouldBePlayingMusic) {
		try{
			var audioIsPlaying = audio.verifyMusicIsPlaying(5);
		} catch (e){
			var audioIsPlaying = false;
			UIALogger.logError("Encountered error: " + e.message);
		}
		
		if (audioIsPlaying) {
			UIALogger.logMessage("Already playing music.");
			return true;
		}
		else if (telephony.getCallCount() > 0) {
			// on a call -- we were playing music, but don't really know if it's still going...
			UIALogger.logMessage("Should be playing music, but we're on a call now.  Will count this as a 'pass'");
			// not sure what we should do here!
			return false;
		}
		else {
			// something went wrong and we are no longer playing music.  We'll restart it
			this.numberOfTimesMusicHasQuit++;
			this.shouldBePlayingMusic = true;
			this.numberOfTimesMusicHasBeenStarted++;
			UIALogger.logError("No longer playing music--restarting it.");
			return true;
		}
	}
	this.shouldBePlayingMusic = true;
	this.numberOfTimesMusicHasBeenStarted++;
	UIALogger.logMessage( "shouldBePlayingMusic = " + this.shouldBePlayingMusic + 
						  " , numberOfTimesMusicHasBeenStarted = " + this.numberOfTimesMusicHasBeenStarted );
	return true;
}

AudioObject.prototype.stopPlayingMusic = function () {
	if (this.shouldBePlayingMusic) {
		try {
			var audioIsPlaying = audio.verifyMusicIsPlaying(5);
		} catch (e) {
			var audioIsPlaying = false;
			UIALogger.logError("Encountered error: " + e.message);
		}
		
		if (audioIsPlaying) {
			UIALogger.logMessage("Stopping active music.");
			this.shouldBePlayingMusic = false;
			return true;
		}
		else if (telephony.getCallCount() > 0) {
			// on a call -- we were playing music, but don't really know if it's still going...
			UIALogger.logMessage("On A Call -- Stopping Active music.");
			this.shouldBePlayingMusic = false;
			return true;
		}
		else {
			// something went wrong and we are no longer playing music. 
			this.numberOfTimesMusicHasQuit++;
			this.shouldBePlayingMusic = false;
			UIALogger.logMessage("No longer playing music--counting it as stopped.");
			return true;
		}
	}
	
	this.shouldBePlayingMusic = false;
	UIALogger.logMessage( "shouldBePlayingMusic = " + this.shouldBePlayingMusic + 
						  " , numberOfTimesMusicHasBeenStarted = " + this.numberOfTimesMusicHasBeenStarted );
	return true;
} 


AudioObject.prototype.printTotals = function () {
	system.println("**********************************************");
	system.println("Number of Times Music has been Started: " + this.numberOfTimesMusicHasBeenStarted);
	system.println("Number of Times Music has been Quit: " + this.numberOfTimesMusicHasQuit);
	if (this.shouldBePlayingMusic) {
		system.println("Should currently be playing audio.")
	}
	else {
		system.println("Should NOT be playing audio.")
	}
	system.println("**********************************************");
}


// helper functions

//--------------------------------------------------------------------------------
//	stopProc - Will send a SIGSTOP signal to a given process.  If only the name is passed, all instances of that process will be stopped
//					If only the pid, or the name and the pid are passed in, then it will only stop that specific process
//
//	Arguments: 
//		name - The name of the process you want to stop
//		pid  (Optional) - pid of the process you want to stop
//
//	Returns:
// 		None
//--------------------------------------------------------------------------------
function stopProc (name, pid) {
	var timeout = 10;
	var stopCommand = "/bin/kill -STOP ";
	
	if (pid) {
		stopCommand = stopCommand + pid;
		UIALogger.logMessage(stopCommand + " (" + name + ")");
		system.run(stopCommand, timeout);
	}
	else{
		for( var procID in system.process ) {
			var proc = system.process[procID];
			var procName = proc["Command"];
			if (procName == name) {
				var currentStopCommand = stopCommand + proc["pid"];
				UIALogger.logMessage(currentStopCommand + " (" + name + ")");
				system.run(currentStopCommand, timeout);
			}//end if
		}//end for
	}//end else
}

// quickie 'keys' function
function keys(hash) {
	var keyList = new Array();
	
	for (key in hash) { keyList.push(key) }

	return keyList;
}

// generate random city data (for maps, clock, etc)
function randomCityData() {
	var path = "/System/Library/PrivateFrameworks/AppSupport.framework/all_cities_adj.plist";
	var data = system.plistData(path);
	var count = data.length;
	var cityData = data[system.randomInteger(0, count-1)];
	var cityObj = new Object();
	cityObj.name = cityData[5];
	cityObj.country = cityData[6].replace(/\./g, "");
	return cityObj;
}

//A word (in this context) is any set of characters without a space. 
//It would be really cool if we could make these real words!
//Check into using /usr/share/dict/  There are words and proper names!
function getRandomWord(minLength, maxLength, textOnly) {
	if (!minLength) minLength = 1;
	if (!maxLength) maxLength = 20;	

	var numberOfChars = system.randomInteger(minLength,maxLength);
	// var charSet = "1234567890-=!@#$%^&*()_+qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM[]{};:',./<>?\|~";
	// removed '=' and ';' chars so that it doesn't interfere with checking for strings with UIElements
	// see <rdar://problem/6211220> We can't use random strings that contain '=' or ';' in stress tests
	var charSet;
	var word = "";
	
	charSet = textOnly ? "1234567890qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM" : 
						 "1234567890-!@#$%^&*()_+qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM[]{}:',./<>?\|~";
	
	for( var j = 0; j < numberOfChars; j++ ){
		var c = charSet[system.randomInteger(0,charSet.length-1)];
		word += c;
	}

	return word
}

//A message (in this context) is any set of words (see above) with spaces between them. 
function getRandomMessage(minWords, maxWords, minWordLength, maxWordLength, textOnly) {
	if (!minWords) minWords = 1;
	if (!maxWords) maxWords = 20;	

	var numberOfWords = system.randomInteger(minWords,maxWords);
	var message = "";
	
	for( var j = 0; j < numberOfWords; j++ ){
		var word = getRandomWord(minWordLength, maxWordLength, textOnly);
		message = message + " " + word;
	}

	return message;
}

// clear alerts
function clearAlerts () {
	try {
		var alert = UIATarget.localTarget().frontMostApp().alert();
		if (alert.isValid()) {
			UIALogger.logError("UNEXPECTED ALERT -- this should have been dismissed earlier");
			alert.logElementTree();
			try {
				UIATarget.onAlert(alert);
			} catch(e) {
				UIALogger.logError(e);
			}
			
			if (!alert.waitForInvalid()) {
				alert.buttons()[0].tap(); //default handler type behavior
				if (!alert.waitForInvalid()) UIALogger.logError("Alert did not go away");
			}
		} 
		else {
			UIATarget.localTarget().pushTimeout(0);
			var alert = UIATarget.localTarget().frontMostApp().mainWindow().elements().firstWithPredicate("className == 'UIAAlert' and ANY buttons.isVisible == 1");
			UIATarget.localTarget().popTimeout();
			if (alert.isValid()) {
				UIALogger.logDebug("Found an alert");
				alert.logElementTree();
				alert.buttons()[0].tap();
			}
		}
	} catch(e) {
		UIALogger.logError("Encountered error while checking for alerts: " + e);
		return false;
	}
	
	return true;
}

// set up wifi
function setWifi(wifiName, wifiPassword, wifiBackupName, wifiBackupPassword) {
	var wifiCount = 6;
	var tmp;
	
	while (wifiCount--) {
		wlText = UIAUtility.logToolOutput('/usr/local/bin/wl status');
		if (wlText.match(/Not associated/)) {
			// swap networks halfway through count
			if (wifiCount == 3) {
				tmp = wifiName; wifiName = wifiBackupName; wifiBackupName = tmp;
				tmp = wifiPassword; wifiPassword = wifiBackupPassword; wifiBackupPassword = tmp;
			}
			
			try {
				settings.setWifi(1, wifiName, wifiPassword, {backupNetwork:wifiBackupName, backupPassword:wifiBackupPassword});
			} catch(e) {
				UIALogger.logError("Could not connect to wifi -- " + e);
				if (wifiCount) {
					UIALogger.logError("Will try to connect " + wifiCount + " more time(s).");
				}
			}
		}
		else { break }
	}
	
	return wifiCount ? true : false;
}

