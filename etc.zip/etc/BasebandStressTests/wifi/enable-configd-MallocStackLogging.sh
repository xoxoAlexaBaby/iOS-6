#!/bin/sh
#Previous wifi manager leaks testing QA used wifijefe which is a standalone wifi manager binary to check for leaks in wifi manager. 
#This required a wifi manager root a.k.a wifijefe from development team. Previously we had to move the wifi manager bundle
#out of the way, reboot, and run wifijefe. The process didn’t allow for necessary symbolication of the leaks output. 
#It was determined that enable-configd-MallocStackLogging script modifies start up parameters of configd telling the
#leaks detector to start tracing memory allocations. After running wifisleepwake stress for some time (100 plus cycles)
#we get leaks info for configd without having to run the wifijefe separate root. This eliminates a few test steps plus 
#we don’t need a separate root from development. We can run leaks against the normal wifi manager bundle.
#
#To use script ./enable-configd-MallocStackLogging <ON>
#Reboot device
#Start sleepwake script on device in same location:
#usr/local/etc/BasebandStressTests/wifi/wifisleepake_Router_URL.sh AppleWiFi
#Get leaks for configd on device after running wifisleepwake for few hundred cycles:
#ps -A | grep configd 
#leaks <PID # for configd> > output_file_name

ROOT="${ROOT:=/}"

usage()
{
	echo "usage: $0 (off|on)"
	exit 1
}

if [ ${EUID} -ne 0 ]; then
        echo "must run as root"
        exit 1
fi

if [ $# -ne 1 ]; then
	usage
fi

if [ ! -d ${ROOT}/System/Library/LaunchDaemons-ORIG ]; then
	mkdir ${ROOT}/System/Library/LaunchDaemons-ORIG
fi

#----------

if [ ! -f ${ROOT}/System/Library/LaunchDaemons-ORIG/com.apple.configd.plist ]; then
	cp -p ${ROOT}/System/Library/LaunchDaemons/com.apple.configd.plist			\
		${ROOT}/System/Library/LaunchDaemons-ORIG/com.apple.configd.plist
fi

case "${1}" in
	"on"  | "On"  | "y" | "yes" | "Yes" )
		defaults write									\
			 ${ROOT}/System/Library/LaunchDaemons/com.apple.configd			\
			 EnvironmentVariables							\
			 -dict-add MallocStackLogging Yes
#		defaults write									\
#			 ${ROOT}/System/Library/LaunchDaemons/com.apple.configd			\
#			 EnvironmentVariables							\
#			 -dict-add MallocStackLoggingNoCompact Yes
#		defaults write									\
#			 ${ROOT}/System/Library/LaunchDaemons/com.apple.configd			\
#			 EnvironmentVariables							\
#			 -dict-add MallocBadFreeAbort Yes
		;;
	"off" | "Off" | "n" | "no"  | "No"  )
		if [ -f ${ROOT}/System/Library/LaunchDaemons-ORIG/com.apple.configd.plist ]; then
			cp -p ${ROOT}/System/Library/LaunchDaemons-ORIG/com.apple.configd.plist	\
				${ROOT}/System/Library/LaunchDaemons/com.apple.configd.plist
		fi
		;;
	* )
		usage
esac

plutil -convert xml1 ${ROOT}/System/Library/LaunchDaemons/com.apple.configd.plist
chmod 644 ${ROOT}/System/Library/LaunchDaemons/com.apple.configd.plist

#----------

HELPER="com.apple.SCHelper"
if [ -f ${ROOT}/System/Library/LaunchDaemons/com.apple.SCHelper-embedded.plist ]; then
	HELPER="com.apple.SCHelper-embedded"
fi

if [ ! -f ${ROOT}/System/Library/LaunchDaemons-ORIG/${HELPER}.plist ]; then
	cp -p ${ROOT}/System/Library/LaunchDaemons/${HELPER}.plist				\
		${ROOT}/System/Library/LaunchDaemons-ORIG/${HELPER}.plist
fi

case "${1}" in
	"on"  | "On"  | "y" | "yes" | "Yes" )
		defaults write									\
			 ${ROOT}/System/Library/LaunchDaemons/${HELPER}				\
			 EnvironmentVariables							\
			 -dict-add MallocStackLogging Yes
#		defaults write									\
#			 ${ROOT}/System/Library/LaunchDaemons/${HELPER}				\
#			 EnvironmentVariables							\
#			 -dict-add MallocStackLoggingNoCompact Yes
#		defaults write									\
#			 ${ROOT}/System/Library/LaunchDaemons/${HELPER}				\
#			 EnvironmentVariables							\
#			 -dict-add MallocBadFreeAbort Yes
		;;
	"off" | "Off" | "n" | "no"  | "No"  )
		if [ ! -f ${ROOT}/System/Library/LaunchDaemons-ORIG/${HELPER}.plist ]; then
			cp -p ${ROOT}/System/Library/LaunchDaemons-ORIG/${HELPER}.plist		\
				${ROOT}/System/Library/LaunchDaemons/${HELPER}.plist
		fi
		;;
	* )
		usage
esac

plutil -convert xml1 ${ROOT}/System/Library/LaunchDaemons/${HELPER}.plist
chmod 644 ${ROOT}/System/Library/LaunchDaemons/${HELPER}.plist

#----------

echo "*** com.apple.configd.plist updated, reboot required."

