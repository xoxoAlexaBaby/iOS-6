//Safari Acceptance Test Catalogue.


if (typeof safari.acceptanceTests == 'undefined') {
	safari.acceptanceTests = new Array();
}
	
	//	SAMPLE
    //  var date = new Date();
	//	var timestamp = "" + date.getHours() + date.getMinutes() + date.getSeconds();
	//	safari.acceptanceTests.push(phtCreateTest("Safari_Test001", ["Arg-1" + timestamp, "Arg-2"], Safari_doSomeTest, "Test description..."));



