#!/bin/sh
#################################################################################################
#                                                                                               #
#   ScriptName: TestCases.sh                                                                    #
#                                                                                               #
#   Usage:      <path_to_Script>/TestCases.sh                                                   #
#                                                                                               #
#   Purpose:    This Scripts helps in printing the Statistics for Stress Tests                  #
#                                                                                               #
#   Author:     Jerome Jesu                                                                     #
#   Contact:    jesu@apple.com                                                                  #
#                                                                                               #
#################################################################################################



###########################################################################
# FUNCTION to Send/Receive (MO/MT) SMS
# USAGE: sendSMS DEVICE_PHONE_NUMBER COUNT SMS_STRING -- count is optional
###########################################################################
sendSMS()
{
	echo `date` ": _____SENDING SMS START - $dcount,$2 ____"  >> $LOGSFILE
	echo "${TESTCT} -s $1 \"$2 $3\""
	${TESTCT} -s $1 "$2 $3" >& /tmp/dummy.txt
	echo `date` ": _____SENDING SMS END - $dcount,$2 ____" >> $LOGSFILE
	
	grep "SMSSent PASS" /tmp/dummy.txt; resultSms=$?; rm /tmp/dummy.txt;
	if [ $resultSms -eq 0 ]; then
		((spass++)); 
		echo `date` ": SMS ($2) Sent Passed.	Pass: $spass\tFail: $sfail." >> SmsStressTest.txt
	else
		((sfail++)); echo `date` ": SMS ($2) FAILED. Iteration: $dcount.";
		echo `date` ": SMS ($2) Sent FAILED.	Pass: $spass\tFail: $sfail." >> SmsStressTest.txt
	fi
	sleep 5;
}

###########################################################################
# FUNCTION to Send/Receive (MO/MT) MMS
# USAGE: sendSMS DEVICE_PHONE_NUMBER COUNT MMS_FILE -- count is optional
###########################################################################
sendMMS()
{
	echo `date` ": _____SENDING MMS - $3 - START - $dcount,$2 ____"  >> $LOGSFILE
	echo "${TESTCT} -m $1 \"$3\""
	${TESTCT} -m $1 "$3" > /tmp/dummy.txt
	echo `date` ": _____SENDING MMS END - $dcount,$2 ____" >> $LOGSFILE
	
	grep "MSSent PASS" /tmp/dummy.txt; resultmms=$?; rm /tmp/dummy.txt;
	if [ $resultmms -eq 0 ]; then
		((mpass++)); 
		echo `date` ": MMS ($2) Sent Passed.	Pass: $mpass\tFail: $mfail." >> SmsStressTest.txt
	else
		((mfail++)); echo `date` ": MMS ($2) FAILED. Iteration: $dcount.";
		echo `date` ": MMS ($2) Sent FAILED.	Pass: $mpass\tFail: $mfail." >> SmsStressTest.txt
		if [ $smsFailureLogs ]; then takeK00lState "Sending_MMS--$2--FAILED."; fi
	fi
	sleep 5;
}

###########################################################################
# FUNCTION to Make a MO Call
# USAGE: makeCall LOOPBACKNUMBER CALL_INTERVAL COUNT (optional)
###########################################################################
checkForExistingCall()
{
	${TESTCT} -x | grep status
	if [ $? -eq 0 ]; then 
		${CT_MONITOR} -q 2> CT.txt
		echo "**** Iteration $dcount" >> CallsStressTest.txt;
		date  >> CallsStressTest.txt;
		grep "Call to " CT.txt >> CallsStressTest.txt
		echo `date` ": ***** Ongoing Call before Dialing Call ($1).... Ending it now" >> CallsStressTest.txt;
		echo "***** Calls are still active... even though they should be ended by now. Ending them now"
		/usr/local/etc/scripterUIA/general/ExecuteTest.js phoneTest_endCall
		eventer c "End"    #end all active calls
		echo "Checking Call Status again"
		${TESTCT} -x
	else
		echo " There are no active calls to end."
	fi
}

makeCALL()
{	
	echo `date` ": _____MOCALL $2 START - $dcount ____" >> $LOGSFILE
	checkForExistingCall $3
	${TESTCT} -c $1 >& /tmp/dummy.txt
	sleep $2; 
	grep "CallStatusActive PASS" /tmp/dummy.txt; resultCall=$?; rm /tmp/dummy.txt;
	
	if [ $resultCall -eq 0 ]; then
		((pass++))
		echo `date` ": Call ($3) passed.  Passed: $pass\tFailed: $fail." >> CallsStressTest.txt;
		${TESTCT} -e
	else
		((fail++)); echo `date` ": Call ($3) FAILED. Iteration: $dcount.";
		echo `date` ": Call ($3) FAILED.  Passed: $pass\tFailed: $fail." >> CallsStressTest.txt;
		echo `date` ": _____MOCALL $2 FAILED - $dcount ____"	>> $LOGSFILE
	fi

	echo `date` ": _____MOCALL $2 END $pass,$fail - $dcount ____"	>> $LOGSFILE
	sleep 7
} 


###########################################################################
# FUNCTION to Check if WiFi is enabled.
###########################################################################
checkWiFiEnabled()
{
	WiFiEnabled=
	WiFiEnabled=`ifconfig -a | perl -lne ' if ( !/pdp/) { print;} else {exit};' | perl -lne ' if ( /inet / && ! /127.0.0.1/ ){ print 1; exit 0}'`
	echo "******WiFiEnabled = $WiFiEnabled;"
	if [ "$WiFiEnabled" ]; then echo "Disabling WiFi since it is enabled..."; disableWifi; fi
}

printDownloadRates()
{
	FOUND=`grep Average /tmp/DownloadDummy.txt`
	echo `date` ": _____DOWNLOAD - Attempt = $DataAttempts, Rate = $FOUND _____" >> $LOGSFILE
}

printUploadRates()
{
	FOUND=`grep Average /tmp/UploadStressTest.txt`
	echo `date` ": _____UPLOAD - Attempt = $uploadAttempts, Rate = $FOUND _____" >> $LOGSFILE
}

getPingParameters()
{		
		length=${#PING_PACKET_SIZE[@]}
		index=$((RANDOM % $length))
		packetSize=${PING_PACKET_SIZE[$index]}
		maxPings=$((RANDOM % 10 +  5))
		
		pingCount=$((10 - $index))
		
		length=${#PING_INTERVALS[@]}
		index=$((RANDOM % $length))
		pingInterval=${PING_INTERVALS[$index]}
}

stopKillingProcess()
{
	stopKilling=`ps -A | grep killHungProcess | grep -v grep | awk '{print $1}'`
	kill -9 $stopKilling
}

###########################################################################
# FUNCTION to Make a Multi Call
# USAGE: MultiCall $LOOP_BACK_NUMBER $Repetition URL callCount 
# countForLogs(optional) waitUploadDownload(optional)
###########################################################################
MultiCalls()
{	
	echo `date` ": _____MULTICALLS START - $dcount ____" >> $LOGSFILE
	wAttempts=$2		
	webpage=$3
	waitUploadDownload=120
	maxTimeForDownload=300
	pdpid=0
	echo "checking whether WiFi is enabled..."
	checkWiFiEnabled
	
	# Making MO Call.
	${TESTCT} -c $1 >& /tmp/dummy.txt
	echo `date` ": _____MULTICALLS MOCALL START - $4 ____" >> $LOGSFILE
	sleep 30; 
	grep "CallStatusActive PASS" /tmp/dummy.txt; resultCall=$?; rm /tmp/dummy.txt;
	if [ $resultCall -eq 0 ]; then
		((pass++))
		echo `date` ": Call ($4) passed.  Passed: $pass\tFailed: $fail." >> CallsStressTest.txt;		
	else
		((fail++)); echo `date` ": Call ($4) FAILED. Iteration: $dcount.";
		echo `date` ": Call ($4) FAILED.  Passed: $pass\tFailed: $fail." >> CallsStressTest.txt;
	fi

	activatePDPContext $pdpid
		
	if [ $EnableMultiRAB -eq 1 ] && [ $proceedDataTransfer -eq 1 ]; then 
		
		((DataAttempts++))
		((uploadAttempts++));
		uploadSize=`expr ${FILE_MULTIPLIER} \* ${UPLOAD_BYTES} `


		echo "\n #####  $5. Dowloading $webpage  $wAttempts time(s)."; date;
		echo `date` "\n #####  $5. Dowloading $webpage  $wAttempts time(s). #####" >> DownloadStressTest.txt
		echo `date` ": _____MULTICALLS - Downloading Data $webpage START - $dcount ____" >> $LOGSFILE
		${STREAMPERF} HTTP -MT ${MAX_TIME_FOR_DOWNLOADS} -c $pdpid -x $wAttempts $webpage > /tmp/DownloadDummy.txt &
		
	
		date; echo;
		nohup $SCRIPTS_DIR/killHungProcess.sh "StreamPerf" 330 &


		echo `date` ": _____MULTICALLS - Uploading START - $dcount _____"  >> $LOGSFILE
		echo `date` "\n #####  $dcount. Uploading Data to ${UPLOAD_SERVER} #####\n"
		echo `date` "\n #####  $dcount. Uploading Data to ${UPLOAD_SERVER} #####" >> UploadStressTest.txt 
		${STREAMPERF} FTP -c $pdpid -MT ${MAX_TIME_FOR_DOWNLOADS} -e -w -N 1048576  ${UPLOAD_SERVER} >& /tmp/UploadStressTest.txt
		cat /tmp/UploadStressTest.txt;
		
		ps -A | grep StreamPerf
		echo `date` ": Sleeping for $waitUploadDownload seconds..."
		sleep $waitUploadDownload
		
		echo `date` ": PING TEST START: "
		echo `date` ": _____MULTICALLS - PING TEST START - $dcount ____" >> $LOGSFILE
		echo "ping -s 1024 -c 10 -i 2 apple.com"
		ping -s 1024 -c 10 -i 2 apple.com
		echo `date` ": _____MULTICALLS - PING TEST END - $dcount ____" >> $LOGSFILE
		
		${TESTCT} -x | grep "status"
		if [ $? -eq 0 ]; then  ${TESTCT} -e; fi
		echo `date` ": _____MULTICALLS MOCALL END $pass,$fail - $4____" >> $LOGSFILE
		
	else
		echo `date` ": Sleeping for $waitUploadDownload seconds..."
		echo `date` ": _____MULTICALLS: NO MULTI-RAB SLEEP FOR $waitUploadDownload s____" >> $LOGSFILE
		sleep $waitUploadDownload
		
		${TESTCT} -x | grep "status"
		if [ $? -eq 0 ]; then  ${TESTCT} -e; fi
		sleep 5;

	fi
	
	cat /tmp/DownloadDummy.txt >> DownloadStressTest.txt
	cat /tmp/UploadStressTest.txt >> UploadStressTest.txt	
	logDataDownloadFailures $dcount $5 $wAttempts
	logDataUploadFailures
	printDownloadRates
	printUploadRates
	stopKillingProcess
	
	#echo `date` ": _____DEACTIVATE PDP - $dcount _____"  >> $LOGSFILE
	#${TOOLS_DIR}/DataContext down
	sleep 10;

	echo `date` ": _____MULTICALLS END - $dcount ____"  >> $LOGSFILE

}


###########################################################################
# FUNCTION to do simultaneous uploads and downloads
# USAGE: uploadDownloadData 
# PARAMS: 1.$Repetition  2.$URL  3.$waitUploadDownload 
# PARAMS: 4.countForLogs(optional)  5. uploadFileSize (optional)
###########################################################################
uploadDownloadData()
{
	echo `date` ": _____UPLOADDOWNLOAD START - $dcount _____"  >> $LOGSFILE
	wAttempts=$1
	webpage=$2
	waitUploadDownload=$3
	date;
	pdpid=0
	echo "checking whether WiFi is enabled..."
	checkWiFiEnabled
	activatePDPContext $pdpid

	if  [ $proceedDataTransfer -eq 1 ]; then
	
		stopKillingProcess
		((DataAttempts++))
		((uploadAttempts++));
		uploadSize=`expr ${FILE_MULTIPLIER} \* ${UPLOAD_BYTES}`
		

		## DOWNLOAD
		echo `date` ": _____UPLOADDOWNLOAD-Downloading  $2 START - $dcount,$4 _____"  >> $LOGSFILE
		echo " #####  $4. Dowloading $2  $wAttempts time(s).";date;
		echo `date` ": #####  $4. Dowloading $2  $wAttempts time(s). #####" >> DownloadStressTest.txt 
		${STREAMPERF} HTTP -MT ${MAX_TIME_FOR_DOWNLOADS} -c $pdpid -x $wAttempts $webpage > /tmp/DownloadDummy.txt  &
		ps -A | grep StreamPerf


		# Kill Hung Process
		date; echo;
		nohup $SCRIPTS_DIR/killHungProcess.sh "StreamPerf" 330 &

		
		## UPLOAD
		echo `date` ": _____UPLOADDOWNLOAD - Uploading START - $dcount _____"  >> $LOGSFILE
		echo " #####  $dcount. Uploading Data to ${UPLOAD_SERVER}";date;
		echo `date` "\n #####  $dcount. Uploading $uploadSize MB to ${UPLOAD_SERVER} #####" >> UploadStressTest.txt 
		${STREAMPERF} FTP -c $pdpid -MT ${MAX_TIME_FOR_DOWNLOADS} -e -w -N $uploadSize ${UPLOAD_SERVER} > /tmp/UploadStressTest.txt
		cat /tmp/UploadStressTest.txt
		
		echo `date` ": Sleeping for $waitUploadDownload seconds..."
		sleep $waitUploadDownload

		UploadData1
		
		cat /tmp/UploadStressTest.txt >> UploadStressTest.txt
		cat /tmp/DownloadDummy.txt >> DownloadStressTest.txt
		logDataDownloadFailures $dcount $4 $wAttempts
		logDataUploadFailures
		printDownloadRates
		printUploadRates
		stopKillingProcess
		#$TOOLS_DIR/DataContext down

	fi

}


###########################################################################
# Function to Download Data using StreamPerf
# USAGE: DownloadData URL TIMES_to_REPEAT COUNT (optional)
###########################################################################
DownloadData() 
{
	webpage=$2
	wAttempts=$1
	echo "checking whether WiFi is enabled..."
	checkWiFiEnabled
	pdpid=0
	activatePDPContext $pdpid

	if [ $proceedDataTransfer -eq 1 ]; 
	then
	
		((DataAttempts++))
		echo "\n #####  $3. Dowloading $webpage  $wAttempts time(s)."; date;
		echo `date` "\n #####  $3. Dowloading $webpage  $wAttempts time(s). #####" >> DownloadStressTest.txt
		echo `date` ": _____DOWNLOADDATA $webpage START - $dcount,$3 _____"  >> $LOGSFILE
		nohup $SCRIPTS_DIR/killHungProcess.sh "StreamPerf" 300 &
		${STREAMPERF} HTTP -MT ${MAX_TIME_FOR_DOWNLOADS} -c $pdpid -x $wAttempts $webpage > /tmp/DownloadDummy.txt
		cat /tmp/DownloadDummy.txt
		cat /tmp/DownloadDummy.txt >> DownloadStressTest.txt
		logDataDownloadFailures $dcount $3 $wAttempts
		echo "Downloading $2 $1 time(s) finished.";
		
		printDownloadRates
		stopKillingProcess
		echo `date` ": _____DOWNLOADDATA $webpage END - $dcount,$3 _____"  >> $LOGSFILE
		
	fi
	
	#echo `date` ": _____DEACTIVATE PDP - $dcount _____"  >> $LOGSFILE
	#${TOOLS_DIR}/DataContext down;
	sleep 5;
}

###########################################################################
# FUNCTION to do uploads
# USAGE: uploadData  $fileSize in MB ex: uploadData 1  (for 1 MB file)
###########################################################################
UploadData()
{
	echo `date` ": _____UPLOADDOWNLOAD START - $dcount _____"  >> $LOGSFILE
	if [ "$1" ]; then fileSize=$1;
	else fileSize=1; fi
	
	#uploadServer=$iPERFURL
	uploadServer="ftp://testftp:tftp95014*@pttest.apple.com/Bandwidth/iceTest.txt"
	date
	pdpid=0
	activatePDPContext $pdpid
	
	if [ $proceedDataTransfer -eq 1 ]; then
		((uploadAttempts++));
		uploadSize=`expr $fileSize \* 1048576 `
		
		echo `date` "\n #####  $dcount. Uploading $uploadSize to $uploadServer #####"
		echo `date` ": _____UPLOAD - Uploading $uploadSize to $uploadServer START - $dcount _____"  >> $LOGSFILE
		echo `date` "\n #####  $dcount. Uploading $uploadSize to $uploadServer #####" >> UploadStressTest.txt 
		nohup $SCRIPTS_DIR/killHungProcess.sh "StreamPerf" 180 &
		ps -A | grep StreamPerf
		
		${STREAMPERF} FTP -c $pdpid -MT ${MAX_TIME_FOR_DOWNLOADS} -e -w -N $uploadSize $uploadServer >& /tmp/UploadStressTest.txt
		cat /tmp/UploadStressTest.txt >> UploadStressTest.txt
		cat /tmp/UploadStressTest.txt

		printUploadRates
		logDataUploadFailures
		stopKillingProcess
		
	fi
	echo `date` ": _____UPLOAD END - $dcount _____"  >> $LOGSFILE
	sleep 5;
}


UploadData1()
{
	pdpid=0
	activatePDPContext $pdpid	
	echo `date` ": PING TEST START: "
	echo `date` ": _____UPLOADDATA1 - PING TEST START - $dcount ____" >> $LOGSFILE
	getPingParameters

	echo `date` ": _____UPLOADDATA1 - ping -s $packetSize -c $pingCount -i $pingInterval google.com ____" >> $LOGSFILE

	echo `date` ": ping -s $packetSize  -c $pingCount  -i $pingInterval google.com"
	ping -b pdp_ip0 -s $packetSize  -c $pingCount  -i $pingInterval google.com	

	echo `date` ": _____UPLOADDATA1 - PING TEST END - $dcount ____" >> $LOGSFILE
}


#########################################################
# Activate PDP Context and check for Failures
#########################################################
activatePDPContext()
{
	if [ "$1" ]; then pdpid=$1;
	else pdpid=0; fi
	((pdpAttempts++))
	((activationCount++))
	proceedDataTransfer=1
	
	echo `date` ": _____ACTIVATE PDP START - $dcount _____"  >> $LOGSFILE
	${TOOLS_DIR}/DataContext -c $pdpid up >& /tmp/DataContextStatus
	cat /tmp/DataContextStatus  >> DataContextStatus.txt
	
	grep -c -i  "Fail" /tmp/DataContextStatus
	result=`grep -c -i "Fail" /tmp/DataContextStatus`
	echo "**** Data Context search Result = $result..."
	
	if [ $result -ne 0 ]; then
		((pdpFails++)); 
		if [ $dataFailureLogs -eq 1 ]; then		
			${TESTCT} -l "Dump state : PDP_$pdpid Activation FAILED - ${dcount}-${activationCount} ";
			sleep 10
		fi
		echo `date` ": **** PDP Context $pdp_id Activation FAILED for ${dcount}-${activationCount}";
		#proceedDataTransfer=0
	fi
	
	date
	commUpdate=`grep -c "t get updated status from CommCenter" /tmp/DataContextStatus`
	if [ $commUpdate -gt 0 ]; then
		echo " **** ERROR:  Didn't get updated status from CommCenter..."
		((pdpFails++))
	fi
	date
	
	echo `date` ": _____ACTIVATE PDP END - $dcount, result=$result, proceed=$proceedDataTransfer_____"  >> $LOGSFILE
}


#########################################################
# STOP and START LOCMON on the background every 25 iterations
#########################################################
startLocmon()
{
	echo `date` ": _____startLocmon: LOCMON START - $count _____"  >> $LOGSFILE
	echo "*** STARTING GPS IN THE BACKGROUND"
	echo " ${LOCMON} -l -m ${LOCMON_RUNTIME} -z ${LOCMON_SLEEPTIME}"
	${LOCMON} -l -m ${LOCMON_RUNTIME} -z ${LOCMON_SLEEPTIME}  2> locmonStressTest_${dcount}.txt  &
}

restartLocmonIfStopped()
{
	echo "Finding Locmon Process.."
	PIDS=`ps -A | grep locmon | perl -lne ' if ( !/grep/ ) { @L = split; $L[0] =~ s/\s*//g; print $L[0];} ' `
	
	if [ "$PIDS" ]; then 
		echo "Locmon is still running so not doing anything"; 
	else 
		echo `date` ": _____restartLocmonIfStopped: RESTARTING LOCMON - $dcount _____"  >> $LOGSFILE
		echo `date` ": Restarting Locmon since it is not running."
		${LOCMON} -l -m ${LOCMON_RUNTIME} -z ${LOCMON_SLEEPTIME}  2> locmonStressTest_${dcount}.txt  &
	fi
	
	echo `date` ": _____restartLocmonIfStopped: Locmon Started - $dcount _____"  >> $LOGSFILE
}

stopStartLocmon()
{
	echo "Entering Function to check whether GPS is running... "
	echo "Starting Locmon to stress the GPS and Baseband..."
	echo "Finding Process.."
	PIDS=`ps -A | grep locmon | perl -lne ' if ( !/grep/ ) { @L = split; $L[0] =~ s/\s*//g; print $L[0];} ' `
	echo "Killing Processes  --- $PIDS.\n"
	echo `date` ": _____Locmon Process IDs-> $PIDS - $dcount _____"  >> $LOGSFILE
	kill $PIDS
	echo `date` ": _____Locmon STO - $dcount _____"  >> $LOGSFILE
	sleep 30
	${LOCMON} -l -i 2> locmonStressTest.txt &
	echo `date` ": _____Locmon START - $dcount _____"  >> $LOGSFILE
}

getRegistrationStatus()
{
		echo "Dumping CoreTelephonyMonitorStats: "
		${CT_MONITOR} -q 2> CT.txt
		echo "**** Iteration $dcount" >> RegistrationStatus.txt
		date  >> RegistrationStatus.txt
		egrep "Data Indicator:|Operator:|Registration Status:|Data 0 " CT.txt >> RegistrationStatus.txt
}


#########################################################
# Functions to check whether Baseband is in reset state
# before entering Sleep Cycler.
#########################################################
checkResetState()
{
	${CT_GET_RESET_STATE} | grep "CommCenter in reset state";
	
	if [ $? -eq 0 ]; then isBBReset=1;
	else isBBReset=0;
	fi
	
	echo `date` ": CheckResetState: isBBReset = $isBBReset."
}

checkPowerAssertion()
{
	isPowerAsserted=1
	powerCount=0
	assertion=
	#assertion=`${TOOLS_DIR}/powerstat  | head -n 2 | tail -n 1 | tr -d ' '`

	while [ $isPowerAsserted -eq 1 ]; do
		assertion=`${TOOLS_DIR}/powerstat -a | grep PreventUserIdleSystemSleep | grep -v -i springboard`
		echo `date` ": Assertions: $assertion"
		
		if [ "$assertion" ]; then
			((powerCount++))
			echo `date` ": PowerCount = $powerCount, assertion= $assertion"
			isPowerAsserted=1
		else
			isPowerAsserted=0
			echo `date` ": No Power Assertion.. Assertion=$assertion, isPowerAsserted=$isPowerAsserted."
			break;
		fi
		
		if [ $powerCount -gt 2 ]; then 
			echo `date` ": PowerCount = $powerCount, assertion= $isPowerAsserted"
			break; 
		fi
		sleep 2

	done
}

readyToRunSleepCycler()
{
	timeToSleep=0
	maxTimeToWait=210
	isBBReset=0
	isPowerAsserted=0
	
	checkResetState
	
	while [ $isBBReset -eq 1 ]; 
	do
		echo `date` ": Sleeping for 30 seconds before checking again."
		sleep 30;
		timeToSleep=$(($timeToSleep + 30));
		
		if [ $timeToSleep -ge $maxTimeToWait ]; then 
			echo `date` ": Max Timer exceeded $maxTimeToWait seconds wait period."
			break; 
		fi
		echo `date` ": checking again after $timeToSleep seconds... since isBBReset = $isBBReset."
		checkResetState
		
	done
	checkPowerAssertion
	echo "readyToRunSleepCycler: isBBReset = $isBBReset. isPowerAsserted = $isPowerAsserted.\n\n"
	#echo "readyToRunSleepCycler: isBBReset = $isBBReset."
}


#########################################################
# run SleepCycler for 1 iteration $2=sleepTime $1=Count
#########################################################
runSleepCycler()
{
	# Checking for Power Assertions on WildCat+
	#checkPowerCapping; #proximitySensor=1
	sleepInterval=$2
	echo `date` ": Check if we are READY to run SleepCycler..."
	readyToRunSleepCycler
	
	#if [ $isBBReset -eq 0 ] && [ $isPowerAsserted -eq 0 ]; then
	if [ $isBBReset -eq 0 ]; then
		${SEND_AT_COMMAND} -v -d ${DLCI_DEV_NODE}
		sleep 2
		nohup $SCRIPTS_DIR/killHungProcess.sh "SleepCycler" 90 &
		echo `date` ": _____DEVICE ENTERING SLEEP for $sleepInterval seconds - $dcount,$1 _____"  >> $LOGSFILE
		echo `date` ":$1. Sleepcycling 1 time -n 1 -s $sleepInterval";
		${RUN_SC} -n 1 -s $sleepInterval;
		echo `date` ": _____WAKE UP FROM SLEEP - $dcount,$1 _____"  >> $LOGSFILE
	else 
		echo `date` ": Skipping SleepCycler is Baseband is resetting..."
		echo `date` ": _____NO SLEEPCYCLING -- Reset=isBBReset,Assertion=$assertion - $dcount,$1 _____"  >> $LOGSFILE
	fi
	
}


#########################################################
# check whether Power Capping is enabled
#########################################################
checkPowerCapping()
{
	powerchecktimer=0;
	date
	powerCap=`${SEND_AT_COMMAND}  -d ${DLCI_DEV_NODE} +XTXPWRLIMIT? `
	echo "POWER CAP -- $powerCap."
	proximity=`echo $powerCap  | awk '{print $2}' | sed 's/,//' `
	if [ $proximity ] &&  [ $proximity -eq 1 ]; then 
		proximitySensor=0;
		echo "PROXIMITY SET -- $proximity, Sensor=$proximitySensor."; 
	else
		proximitySensor=1;
		echo "PROXIMITY NOT SET -- $proximity, Sensor=$proximitySensor."; 
		return;
	fi
	
	while [ $proximity -eq 1 ]; do
		echo "********* Power Assertion=$proximity set. Will check for the Power Assertion after 5 seconds....";
		sleep 5;
		powerchecktimer=$(($powerchecktimer + 5));
		date
		powerCap=`${SEND_AT_COMMAND} -d ${DLCI_DEV_NODE} +XTXPWRLIMIT? `
		echo "POWER CAP -- $powerCap."
		proximity=`echo $powerCap  | awk '{print $2}' | sed 's/,//' `
		echo "Power Assertion = $proximity. Checking....";
		if  [ $powerchecktimer -ge 60 ]; then 
			echo " **** Gave up after 60 seconds.... Power Assertion=$proximity is still set"; 
			break; 
		fi
	done
	
	if  [ $proximity -eq 1 ] && [ $powerchecktimer -ge 60 ]; then
		proximitySensor=0
		echo "Power Assertion = $proximity is still asserted. Skipping SleepCycler this time. SENSOR=$proximitySensor.";
	else  
		proximitySensor=1
		echo `date` ": Power Assertion = $proximity is Released now. SENSOR=$proximitySensor.";
		sleep 5;
		powerCap=`${SEND_AT_COMMAND} -d ${DLCI_DEV_NODE} +XTXPWRLIMIT? `
		echo "AFTER 5s LOOP: POWER CAP -- $powerCap."
		proximity=`echo $powerCap  | awk '{print $2}' | sed 's/,//' `
		if  [ $proximity -eq 1 ]; then proximitySensor=0; fi
	fi 
}


collectTopOutput()
{
	echo `date` ": _____COLLECTING TOP OUTPUT & LEAKS - $dcount _____"  >> $LOGSFILE
	echo " ******  Capturing output of TOP to look for issues that we don't know" >> top_output_${DEVICENAME}.log
	date >> top_output_$DEVICENAME.log
	top -o -cpu -s 5 -l 10 >> top_output_${DEVICENAME}_${dcount}.txt  &
	echo `date` "\n\n ######## LEAKS output" >> LEAKS_${DEVICENAME}_${dcount}.txt  &
	leaks -exclude _dyld_start CommCenter >> LEAKS_${DEVICENAME}_${dcount}.txt  &
	sleep 2
	echo `date` ": \n\n ######## VMMAP output" >> LEAKS_${DEVICENAME}_${dcount}.txt  &
	vmmap -resident -dirty CommCenter >> LEAKS_${DEVICENAME}_${dcount}.txt  &
	sleep 2
	echo `date` ": \n\n ######## HEAP output" >> LEAKS_${DEVICENAME}_${dcount}.txt  &			
	heap -showSizes CommCenter >> LEAKS_${DEVICENAME}_${dcount}.txt  &
}


logDataDownloadFailures()
{
	echo `date` ": _____LOGGING DATA DOWNLOAD FAILURES - $dcount _____"  >> $LOGSFILE
	echo `date` ": _____LOGGING DATA DOWNLOAD FAILURES - $dcount _____"
	isLowThroughput=0; lowThroughputTracker=0;
	
	isDataPASS=`perl -lne 'BEGIN {$count = 0; }  END { print "$count"; }  
				if (/Mean Throughput|Average Throughput/) { @w = split; $count++ if ( $w[4] =~ /^\d{1,3}[.]\d{1,4}/ & $w[4] !~ /^[0]{1,3}[.][0]{3,}/ ); } 
				' /tmp/DownloadDummy.txt`
	
	throughput=`cat /tmp/DownloadDummy.txt | egrep "Mean Throughput|Average Throughput" |  perl -lne ' 
						BEGIN {$rate = 0; }   END { print "$rate"; }  
						@w = split; if ( $w[4] =~ /^\d{1,3}[.]\d{1,5}/ & $w[4] !~ /^[0]{1,3}[.][0]{3,}/ ) { $rate = $w[4] } ' `

	isLowThroughput=`echo "$throughput,${MIN_DATA_RATE}" | perl -lne '($r,$t)= (split /,/);  if ($r <= $t) { print "1"} else {print "0"}' `
	
	if [ $isDataPASS -gt 0 ]; then
		((dataPassCount++))
		if [ $dataFailTracker -ge 5 ]; then killall -9 tcpdump; fi
		dataFailTracker=0
		startTcpDump=0
	else
		((dataFailCount++))
		((dataFailTracker++))
	fi

	

	if [ $isLowThroughput -gt 0 ]; then
		maxLowThptAttempts=$(($lastlowThroughput + 5));
		if [ $DataAttempts -gt $lastlowThroughput ] && [ $DataAttempts -le $maxLowThptAttempts ]; then 
			echo `date` ": LowThroughput hit"
			((lowThroughputTracker++));	
		else
			echo `date` ": LowThroughput hit but resetting to zero"
			lowThroughputTracker=0;
			killall -9 tcpdump;
			startTcpDump=0
			lastlowThroughput=$DataAttempts;
		fi
	fi
	
	
	if [ $startTcpDump -eq 0 ]; then
		if [ $dataFailTracker -ge ${MIN_DATA_FAIL_ATTEMPTS} ] || [ $lowThroughputTracker -ge ${MIN_DATA_FAIL_ATTEMPTS} ]; then 
			startTcpDump=1
			echo `date` ": LowThroughput or Data Download Failure hit"
			${TESTCT} -l "DataDownloadFailed on PDP-$pdpid ${MIN_DATA_FAIL_ATTEMPTS} times - $dcount : $DEVICENAME"
			nohup /usr/sbin/tcpdump -i pdp_ip0 -s 65000 -w /var/wireless/Library/Logs/CrashReporter/DataDownloadError_${dcount}.dump  &
		fi
	fi
	
	if [ $dataFailureLogs -eq 1 ]; then 
		if [ $dataFailTracker -ge ${MAX_DATA_FAIL_ATTEMPTS} ]  ||  [ $lowThroughputTracker -ge ${MAX_DATA_FAIL_ATTEMPTS} ];  then
			sleep 2
			#ping -c 100 -f 74.125.224.116
			date
			DataContext up
			DataContext -c 2 up
			echo "Running ping test for Data Download issue...."
			ping -c 25 -b pdp_ip0 google.com &
			ping -c 25 -b pdp_ip2 apple.com
			sleep 2
			#((smsCount++))
			#failureMessage="$DEVICENAME - $BB_Build - $APBUILD - $dcount: $SMS_NUMBER - $dcount. Data Download Fail or Low Throughput 10 times continuously ";
			#echo "MESSAGE ==> $failureMessage. Sending SMS now to $MYPHONE"
			#sendSMS $MYPHONE $smsCount "$failureMessage"
			echo "Dumping logs for Download Failures"
			if [ $lowThroughputTracker -ge ${MAX_DATA_FAIL_ATTEMPTS} ];  then
				${TESTCT} -l "LowThroughput on PDP-$pdpid ${MAX_DATA_FAIL_ATTEMPTS} times - $dcount : $DEVICENAME";
				lowThroughputTracker=0;
			else
				${TESTCT} -l "DataDownloadFailed on PDP-$pdpid ${MAX_DATA_FAIL_ATTEMPTS} times - $dcount : $DEVICENAME";
				dataFailTracker=0
			fi
			sleep 10;
			startTcpDump=0
			killall -9 tcpdump
		fi
	fi
	
	dataFailCount1=$(($DataAttempts - $dataPassCount))
	echo `date` ": ******** Download Attempts -> $DataAttempts; Data Fail Count -> $dataFailCount; FailCount1 -> $dataFailCount1, Data Pass Count -> $dataPassCount---$isDataPASS - $throughput" >> DownloadStressTest.txt	
	echo `date` ": ******** lowThroughputTracker - $lowThroughputTracker; lastlowThroughput - $lastlowThroughput;  dataFailTracker - $dataFailTracker." >> DownloadStressTest.txt	
		
	#isDataFAIL=`perl -lne ' BEGIN {$count = 0; }  END { print "$count" }  if (/Mean Throughput|Average Throughput/) { @w = split; $count++ if ( $w[4] =~ /^[0][.][0]{3,}/ | $w[4] =~ /\d{3,}[.]\d{3,}/ | $w[4] =~ /inf/); } ' /tmp/DownloadDummy.txt
	#isLowThroughput=`perl -lne ' END { if ($rate < .200) { print "1" } else { print "0"} }  
	#	if (/Mean Throughput|Average Throughput/) { @w = split; 
	#		if ( $w[4] =~ /^\d{1,3}[.]\d{1,4}/ & $w[4] !~ /^[0]{1,3}[.][0]{3,}/ ) { $rate = $w[4] } else { $rate = 0 } 
	#	} ' /tmp/DownloadDummy.txt `

}

logDataUploadFailures()
{
	echo `date` ": _____LOGGING DATA UPLOAD FAILURES - $dcount _____"
	
	isUploadPASS=`perl -lne 'BEGIN {$count = 0; }  END { print "$count"; }  
			if (/Mean Throughput|Average Throughput/) { @w = split; $count++ 
			if ( $w[4] =~ /^\d{1,3}[.]\d{1,4}/ & $w[4] !~ /^[0]{1,3}[.][0]{3,}/ ); } ' /tmp/UploadStressTest.txt `
	upThroughput=`cat /tmp/UploadStressTest.txt | egrep "Mean Throughput|Average Throughput" | perl -lne ' 
					BEGIN {$rate = 0; }   END { print "$rate"; }  
					@w = split; if ( $w[4] =~ /^\d{1,3}[.]\d{1,5}/ & $w[4] !~ /^[0]{1,3}[.][0]{3,}/ ) { $rate = $w[4] } ' `
		
	if [ $isUploadPASS -gt 0 ]; then ((uploadPassCount++)); else  ((uploadFailCount++)); fi

	echo "******** Upload Attempts -> $uploadAttempts; Upload Fail Count -> $uploadFailCount; Upload Pass Count -> $uploadPassCount---$isUploadPASS - $upThroughput" >> UploadStressTest.txt	
		
}


killHungProcess()
{
		sleep $2
		echo "********** $1 is hung for more $2 seconds. So killing $1."
		GREP="grep $1"
		PIDS=`ps -A | $GREP | perl -lne ' if ( !/grep/ ) { @L = split; $L[0] =~ s/\s*//g; print $L[0];} ' `
		echo "KILLING Processes -- $PIDS for $1.\n"
		kill -9 $PIDS
}
