#!/usr/local/bin/scripter -uiautomation YES -f

#import "../libs/PHTesting.js"
#import "../libs/HarnessUtility.js"
#import "../clock/ClockTests.js"
#import "../settings/SettingsTests.js"

var kReportPath = "/var/mobile/Library/Logs/Testing/";
var start = new Date();
var timeString = start.getTime() + "";  // turn this into a string
var runID = "AlarmTests " + start.toDateString() + " - " + timeString.substr(-6);

// Basic alarm test constants
var kBasicAlarmTime = "00:01";
var kBasicAlarmStartDate = "2011:01:03";
var kBasicAlarmEndDate = "2011:01:04"; // test end date

//var kBasicAlarmEndDate = "December 31, 2016";
var kBasicAlarmSystemTime = "23:58";

// Leap year alarm test constants
var kTimeZones = new Array();
var kDSTTranstionDates = ["2011:03:13:03:00", "2011:11:06:01:00", "2012:03:11:03:00", "2012:11:04:01:00", "2013:03:10:03:00", "2013:11:03:01:00", 
						  "2014:03:09:03:00", "2014:11:02:01:00", "2015:03:08:03:00", "2015:11:01:01:00", "2016:03:13:03:00", "2016:11:06:01:00"];
kTimeZones[0] = {name:"Cupertino", id:"America/Los_Angeles", transitionDates:kDSTTranstionDates};
kTimeZones[1] = {name:"Phoenix", id:"America/Phoenix", transitionDates:kDSTTranstionDates};

var kDefaultTimeZone = kTimeZones[0];
var kDSTSystemTimeOffset = ":::-5";
var kDSTAlarmTimeOffset = ":::+5";

var kLeapYears = ["2012", "2016", "2020", "2024", "2028", "2032", "2036"];
var kLeapYearSystemTime = "02:28:23:57";
var kLeapYearAlarmTime = "00:01";
var kLeapYearDelay = "4";
var kLeapYearDateString = "02:29";

function _getDayForDate(date, timeZone) {
	if (typeof date == 'string') date = UIADate.dateWithDateStringInTimeZone(date, timeZone);
	return date.getDay();
	
}
function _getRepeatChoicesForDays(days) {
	if (typeof days == 'string') days = [days];
	var resultArray = new Array();
	for (var i=0; i<days.length; i++) {
		resultArray.push("repeat:" + clock.repeatChoices[(days[i]-1+clock.repeatChoices.length)%clock.repeatChoices.length]);
	}
	return resultArray;
}

function _getValidationDates(dateFrom, numberOfDays) {
	var validationDates = new Array();
	currentDate = UIADate.dateWithDateStringInTimeZone(dateFrom.getDateString(), this.timeZone); 
	for (var j=0; j<numberOfDays; j++) {
		currentDate.setWithOptions({date:"+1"});
		validationDates.push("validationDate:" + currentDate.getFullYear() + ":" + (currentDate.getMonth()+1) + ":" + currentDate.getDate());
	}
	return validationDates;
}

function addTestsToArray(tests) {
	// Clock
	if ((typeof clock != 'undefined') && springboard.displaysApp(clock)) {
		
		//Basic Alarm Testing
		tests.push("Basic Alarm Testing");
			
		var currentDate = UIADate.dateWithDateString(kBasicAlarmStartDate + ":" + kBasicAlarmSystemTime);
		var endDate = UIADate.dateWithDateString(kBasicAlarmEndDate);
		do {
			var label = "BasicNonRecurringAlarmTest set on " + currentDate.toString();
			formattedSystemDate = currentDate.getFullYear() + ":" + (currentDate.getMonth() + 1) + ":" + currentDate.getDate() + ":" + currentDate.getHours() + ":" + currentDate.getMinutes();
			tests.push(phtCreateTest("BasicNonRecurringAlarmTest", ["systemDate:"+formattedSystemDate, "time:"+kBasicAlarmTime, "waitInterval:3", "label:"+label],															
									 clockTest_addAndWaitForAlarm, "Add a new, non-recurring alarm for " + currentDate.toString() + " and wait for it to go off"));
			
			currentDate.setWithOptions({date:"+1"});
		} while (currentDate.getTime() < endDate.getTime());

		

		
		currentDate = UIADate.dateWithDateString(kBasicAlarmStartDate + ":" + kBasicAlarmSystemTime);
		do {
			var label = "BasicSomeRecurringAlarmTest set on " + currentDate.toString();
			formattedSystemDate = currentDate.getFullYear() + ":" + (currentDate.getMonth() + 1) + ":" + currentDate.getDate() + ":" + currentDate.getHours() + ":" + currentDate.getMinutes();
			var alarmDate = UIADate.dateWithDateString(formattedSystemDate);
			alarmDate.setWithOptions({date:"+1"});
			var repeatChoices = _getRepeatChoicesForDays([_getDayForDate(alarmDate)]);
			UIALogger.logDebug("Setting repeat day to: " + repeatChoices);
			tests.push(phtCreateTest("BasicSomeRecurringAlarmTest", ["systemDate:"+formattedSystemDate, "time:"+kBasicAlarmTime, "waitInterval:3", "label:"+label].concat(repeatChoices), 
									 clockTest_addAndWaitForAlarm, "Add a new, current-day-only recurring alarm for " + currentDate.toString() + " and wait for it to go off"));
			
			currentDate.setWithOptions({date:"+1"});
		} while (currentDate.getTime() < endDate.getTime());



		
		currentDate = UIADate.dateWithDateString(kBasicAlarmStartDate + ":" + kBasicAlarmSystemTime);
		do {
			var label = "BasicAllRecurringAlarmTest set on " + currentDate.toString();
			formattedSystemDate = currentDate.getFullYear() + ":" + (currentDate.getMonth() + 1) + ":" + currentDate.getDate() + ":" + currentDate.getHours() + ":" + currentDate.getMinutes();
			var repeatChoices = _getRepeatChoicesForDays([0,1,2,3,4,5,6]);
			var validationDates = _getValidationDates(currentDate, 7);
			
			tests.push(phtCreateTest("BasicAllRecurringAlarmTest", ["systemDate:"+formattedSystemDate, "time:"+kBasicAlarmTime, "delay:3", "label:"+label].concat(repeatChoices).concat(validationDates),
									 clockTest_addAndWaitForAlarm, "Add a new, every-day recurring alarm starting on " + currentDate.toString() + " and wait for it to go off"));

			currentDate.setWithOptions({date:"+1"});
		} while (currentDate.getTime() < endDate.getTime());

		
		//DST Tests
		tests.push("DST Testing");
		for (var j=0; j<kTimeZones.length; j++) {
			//Non Recurring Alarms
			for (var i=0; i<kTimeZones[j].transitionDates.length; i++) {
				var dstDate = UIADate.dateWithDateStringInTimeZone(kTimeZones[j].transitionDates[i], kTimeZones[j].id);
				var systemDate = UIADate.dateWithDateStringInTimeZone(kTimeZones[j].transitionDates[i], kTimeZones[j].id);
				systemDate.setWithOptions({dateString:kDSTSystemTimeOffset});
				var alarmDate = UIADate.dateWithDateStringInTimeZone(kTimeZones[j].transitionDates[i], kTimeZones[j].id);
				alarmDate.setWithOptions({dateString:kDSTAlarmTimeOffset});
				var alarmTime = alarmDate.getHours() + ":" + alarmDate.getMinutes();
				var validationDate = alarmDate.getFullYear() + ":" + alarmDate.getAdjustedMonth() + ":" + alarmDate.getDate();
				
				dstDate.setWithOptions({date:"-1"});
				var label = "DSTNonRecurring" + dstDate.getFullYear() + "For" + kTimeZones[j].name;
				var testDescription = "Add a new, non-recurring alarm on " + systemDate.toString() + " for " + alarmDate.toString() + " in " + kTimeZones[j].name + " and wait for it to go off";
				tests.push(phtCreateTest(label, 
										 ["systemDate:" + systemDate.getDateString(), 
										  "timezone:" + kTimeZones[j].name,
										  "label:" + label,
										  "time:" + alarmTime, "validationDate:" + validationDate], 
										 clockTest_addAndWaitForAlarm, testDescription));
			}
			
			
			//Some recurring alarms
			for (var i=0; i<kTimeZones[j].transitionDates.length; i++) {
				var dstDate = UIADate.dateWithDateStringInTimeZone(kTimeZones[j].transitionDates[i], kTimeZones[j].id);
				var systemDate = UIADate.dateWithDateStringInTimeZone(kTimeZones[j].transitionDates[i], kTimeZones[j].id);
				systemDate.setWithOptions({dateString:kDSTSystemTimeOffset});
				var alarmDate = UIADate.dateWithDateStringInTimeZone(kTimeZones[j].transitionDates[i], kTimeZones[j].id);
				alarmDate.setWithOptions({dateString:kDSTAlarmTimeOffset});
				var alarmTime = alarmDate.getHours() + ":" + alarmDate.getMinutes();
				var validationDate = alarmDate.getFullYear() + ":" + alarmDate.getAdjustedMonth() + ":" + alarmDate.getDate();
				
				var repeatChoices = _getRepeatChoicesForDays([alarmDate.getDay()]);
				var label = "DSTSomeRecurring" + dstDate.getFullYear() + "For" + kTimeZones[j].name;
				var testDescription = "Add a new, current-day-only alarm on " + systemDate.toString() + " for " + alarmDate.toString() + " in " + kTimeZones[j].name + " and wait for it to go off";
				tests.push(phtCreateTest(label, 
										 ["systemDate:" + systemDate.getDateString(), 
										  "label:" + label,
										  "timezone:" + kTimeZones[j].name,
										  "time:" + alarmTime, "validationDate:" + validationDate].concat(repeatChoices), 
										 clockTest_addAndWaitForAlarm, testDescription));
			}
						
			//All recurring alarms
			for (var i=0; i<kTimeZones[j].transitionDates.length; i++) {
				var dstDate = UIADate.dateWithDateStringInTimeZone(kTimeZones[j].transitionDates[i], kTimeZones[j].id);
				var systemDate = UIADate.dateWithDateStringInTimeZone(kTimeZones[j].transitionDates[i], kTimeZones[j].id);
				systemDate.setWithOptions({dateString:kDSTSystemTimeOffset});
				var alarmDate = UIADate.dateWithDateStringInTimeZone(kTimeZones[j].transitionDates[i], kTimeZones[j].id);
				alarmDate.setWithOptions({dateString:kDSTAlarmTimeOffset});
				var alarmTime = alarmDate.getHours() + ":" + alarmDate.getMinutes();
				var validationDate = alarmDate.getFullYear() + ":" + alarmDate.getAdjustedMonth() + ":" + alarmDate.getDate();
				
				var repeatChoices = _getRepeatChoicesForDays([0,1,2,3,4,5,6]);
				var validationDates = _getValidationDates(alarmDate, 7);

				var label = "DSTAllRecurring" + dstDate.getFullYear() + "For" + kTimeZones[j].name;
				var testDescription = "Add a new, every-day alarm on " + systemDate.toString() + " for " + alarmDate.toString() + " in " + kTimeZones[j].name + " and wait for it to go off";
				tests.push(phtCreateTest(label, 
										 ["systemDate:" + systemDate.getDateString(), 
										  "timezone:" + kTimeZones[j].name,
										  "label:" + label,
										  "time:" + alarmTime, "validationDate:" + validationDate].concat(repeatChoices).concat(validationDates), 
										 clockTest_addAndWaitForAlarm, testDescription));
			}
		}

		
		
		//Leap-Year Tests
		tests.push("Leap-Year Tests");
		//non-recurring
		for (var i=0; i<kLeapYears.length; i++) {
			var testDescription = "Add a new, non-recurring alarm on " + kLeapYears[i] + ":" + kLeapYearSystemTime + " for " + kLeapYearAlarmTime + " and wait for it to go off";
			tests.push(phtCreateTest("LeapYearNonRecurring"+kLeapYears[i], ["systemDate:" + kLeapYears[i] + ":" + kLeapYearSystemTime, 
																			"time:" + kLeapYearAlarmTime, "waitInterval:" + kLeapYearDelay], 
									 clockTest_addAndWaitForAlarm, testDescription));
		}

		//some recurring
		for (var i=0; i<kLeapYears.length; i++) {
			var dateString = kLeapYears[i] + ":" + kLeapYearDateString;
			var repeatChoices = _getRepeatChoicesForDays([_getDayForDate(dateString)]);
			var testDescription = "Add a new, current-day-only alarm on " + kLeapYears[i] + ":" + kLeapYearSystemTime + " for " + kLeapYearAlarmTime + " and wait for it to go off";
			tests.push(phtCreateTest("LeapYearSomeRecurring"+kLeapYears[i], ["systemDate:" + kLeapYears[i] + ":" + kLeapYearSystemTime, 
																			 "time:" + kLeapYearAlarmTime, "waitInterval:" + kLeapYearDelay].concat(repeatChoices), 
									 clockTest_addAndWaitForAlarm, testDescription));
		}

		//all recurring
		for (var i=0; i<kLeapYears.length; i++) {
			var dateString = kLeapYears[i] + ":" + kLeapYearDateString;
			var date = UIADate.dateWithDateString(dateString);
			var repeatChoices = _getRepeatChoicesForDays([0,1,2,3,4,5,6]);
			var validationDates = _getValidationDates(date, 7);
			var testDescription = "Add a new, every-day alarm on " + kLeapYears[i] + ":" + kLeapYearSystemTime + " for " + kLeapYearAlarmTime + " and wait for it to go off";
			tests.push(phtCreateTest("LeapYearAllRecurring"+kLeapYears[i], ["systemDate:" + kLeapYears[i] + ":" + kLeapYearSystemTime, 
																		   "time:" + kLeapYearAlarmTime, "waitInterval:" + kLeapYearDelay].concat(repeatChoices).concat(validationDates), 
									 clockTest_addAndWaitForAlarm, testDescription));
		}
	}	
}

function usage() {
	system.println("usage: AlarmTests.js [--enable <string>] [--disable <string>] [-o <path> | -filepath <path> | --filename <string>] [-l | --list]");
	system.println("	--basicAlarmStartDate	a string in the format YYYY:MM:DD to specify the start date for basic alarm tests");
	system.println("	--basicAlarmEndDate	a string in the format YYYY:MM:DD to specify the end date for basic alarm tests");
	system.println("	--timezone <name> <tz id> <number of transition dates> <transition date> timezones to run the DST tests for");
	system.println("	--disable	tests to skip (may use regex to describe tests)");
	system.println("	--enable	tests to run (may use regex to describe tests)");
	system.println("	--filepath	full path for the results file");
	system.println("	--filename	name to use for the results file");
	system.println("	--wifiname	name to use for the wifi basestation");
	system.println("	--wifipassword	password to use for the wifi basestation");
	system.println("	--nosetup	skip the setup phase of the AlarmTests")
	system.println("	--list		list the available tests");
	system.println("	--writecrashes	write out crashes to the results file")
	system.println("	--help | -h	usage description");
}

function main() {
	var tests = new Array();
	var version = harness_getBuildVersion();
	var filename = "AlarmTests_" + version + ".txt";
	var filepath;
	var wifiname;
	var wifipassword;
	var writeCrashes = false;
	var enableSetup = true;
	
	// seed the generator, so that any random events are the same for every run
	system.setRandomSeed(1);
	UIATarget.localTarget().unlockScreenIfNecessary();	// screen must be unlocked to check for springboard app icons
	
	// process command line arguments
	var options = new Options();
	if (options.help || options.h) {
		usage();
		return;
	}
	if (options.list || options.l) {
		addTestsToArray(tests);
		harness_listTests(tests);
		return;
	}
	if (options.filename) filename = options.filename;
	if (options.nosetup) enableSetup = false;
	if (options.writecrashes) writeCrashes = true;
	if (options.o) filepath = options.o;
	else if (options.filepath) filepath = options.filepath;
	else {
		harness_makeDirectory(kReportPath);
		filepath = kReportPath + filename;
	}
	if (options.basicAlarmStartDate && options.basicAlarmEndDate) {
		kBasicAlarmStartDate = options.basicAlarmStartDate;
		kBasicAlarmEndDate = options.basicAlarmEndDate;
	}
	if (options.timezone) {
		kTimeZones = new Array();
		while (options.timezone.length > 0) {
			var timezone = {name:options.timezone.shift(), id:options.timezone.shift()};
			var dstDatesCount = options.timezone.shift();
			timezone.transitionDates = new Array();
			for (var i=0; i<parseInt(dstDatesCount,10); i++) {
				timezone.transitionDates.push(options.timezone.shift());
			}
			kTimeZones.push(timezone);
		}
	}
	
	addTestsToArray(tests); // add all of the normal tests to the array
	
	// uncomment this line if you want top data added to the output
	system.setDefault("com.apple.harness", "utilities", ["/usr/bin/top -o -cpu -l 1"]);
	
	harness_removeFile(filepath);

	if (system.hasCapability('telephony')) {
		tests.push(phtCreateTest("TurnSetTimeAndDateAutomaticallyOff", ["General", "Date & Time", "Set Automatically", 0], settingsTest_changeSingleSwitch, "Set the 'Set Automatically' Date & Time switch to off"));		
	}
	tests.push(phtCreateTest("SetAutoLockToNever", ["General", "Auto-Lock", "Never"], settingsTest_chooseCheckmarkedItem, "Set Auto-Lock to Never"));
	
	system.run("/usr/local/bin/thermtune --disable", 5);
	harness_runTestsFromArray(tests, filepath, options.disable, options.enable, false, writeCrashes);
	system.run("/usr/local/bin/thermtune --enable", 5)
	
	system.println("Done Running Alarm tests.");
}

main();
