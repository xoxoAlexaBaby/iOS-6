#!/usr/bin/perl -w

######################################################################################
# SCRIPT to PACKAGE the BASEBAND LOGS and Compress them
# AUTHOR: JEROME JESU
######################################################################################
use Time::Local;   ######  For timelocal function ONLY!
use File::Copy;
use Sys::Hostname;
use Cwd;

$logsDir = "/var/wireless/Library/Logs/CrashReporter/Baseband/";
print "Changed to $logsDir\n" if (chdir($logsDir));
$cwd = cwd();
print "Current Working Dir: $cwd\n";

my $deviceName = hostname;
#my $deviceName =( grep {chomp;} system ("hostname -s") )[0];
print "******* DEVICE = $deviceName;\n";
$deviceName =~ s/_|[-]//g;
$deviceName =~ s/\s/\\ /g;
my @zipFiles;

opendir ( D, $logsDir) || die "Cannot open folder $logsDir. $!\n";

### Processing the Parent directory containing all Devices
foreach (readdir D)
{
	next if (/^[.]|^[.][.]$/ );
	next if ! /\Q-csi.\E/;
	next if ! /\Qlog-bb-\E/;
	my $csiFile = "$_";
	$count++;
	
	print "\n\n CSI FILE $count: $csiFile\n";
	pkgBasebandLogs($deviceName, $csiFile);	
}

print "\nZipFiles:\n", join ("\n", @zipFiles), "\n";
foreach $z (sort @zipFiles)
{
	print "\n### Working on $z:\n";
	CompressFiles($z);
}
print " \nCurrent Working Dir: $cwd\n";


print "\n****** compressLogs.pl DONE...\n\n";




#### SUBS for packaging Baseband LOGS

sub pkgBasebandLogs
{
	my ($deviceName, $csi) = @_;
	my $tempCSI = $csi;
		
		
	# getting the Timestamp from the CSI File
	$csi =~ s/(.*\Qlog-bb-\E)(.*)(\Q-csi.\E.*)/$1$2/;
	my $timestamp = $2;
	my $moveFiles = "$1$2-*";


	# Opening the CSI file to get the TimeStamp and the Crash Reason
	open (F, "$tempCSI") || print " Cannot open $csi for reading... $!\n";
	my $reason = <F>;
	chomp $reason;
	$reason =~ s/^(.*Reason: )//;
	if ( $reason =~ /baseband crash/) {
			@crashAT = grep { /\QCrash at\E/ } <F>;
			print join (";\n", @crashAT),"\n";
			if ( (scalar @crashAT) == 0 ) {
				$reason = "BasebandCrash";
			} else {
				$reason = $crashAT[-1];
				$reason =~ s/^(\d+[.]\d{3}\srm:\s)(.*)$/$2/;
				$reason =~ s/(\QCrash at\E)//g;
				$reason =~ s/(Reason )//;
			}
	}
	close F;
	$reason = getReasonTrimmed($reason);

	push (@zipFiles, "$deviceName-$reason-$timestamp");	
	my $csiFile = "$deviceName-$reason-$timestamp-csi.txt";
	my $reasonDir = "$deviceName-$reason-$timestamp/";
	$reasonDir =~ s/\s/\\ /g;
		
	# Creating Directories for zipping.
	umask(0);
	system `mkdir "$reasonDir"`;

	print  " CSI - $csiFile;\n reason1 - $reasonDir;\n moveFiles - $moveFiles\n";
	print  " cp $tempCSI $reasonDir\n";
	system `cp "$tempCSI" "$reasonDir"`;
	print  " mv $tempCSI $csiFile\n";
	system `mv "$tempCSI" "$csiFile"`;
	
	print  " mv \"$moveFiles\" $reasonDir\n";
	system `mv $moveFiles $reasonDir/`;
	
	print  " mv $csiFile $tempCSI\n";
	system `mv "$csiFile" "$tempCSI"`;
	 
	print  " Done with $tempCSI\n";
}




sub CompressFiles
{
	my ($z) = shift;
	my $tarFile = "$z.tar";
	print "tar -czvf \"$tarFile\" \"$z\"\n";
	system ("tar -czvf \"$tarFile\" \"$z\"");
	
	print "Zipping Files -> bzip2 -z $tarFile\n";
	system ("bzip2 -z \"$tarFile\"");
	
	print "$z zipped.\n Removing unzipped Folder -> rm -r $z\n";
	system ("rm -r \"$z\"");
	print " Removing tar files -> rm $tarFile\n";
	system ("rm \"$tarFile\"");

}


sub getReasonTrimmed
{
	my ($reason) = shift;
	$reason =~ s/--|[+]//g; 
	$reason =~ s/:|[']|[,]//g; 
	my @dummy  = (split /\s+/, $reason);
	if ( scalar @dummy > 4 ) { ($reason) = join "", (splice(@dummy,0,3)); } 
	else {  $reason = join "", (split /\s+/, $reason);	}
	return $reason;
}