#This script will check the WiFi connection between Wireless Router and the Internet for each sleep/wake
#Two argument: SSID and URL (URL is optional, default is www.google.com)
#Script will check the SSID, ping the router IP address, and ping internet URL address

#!/bin/sh -x

CONTINUE=true
SLEEP=15
WAKETIME=40
URL="www.google.com"
HOST=""
COUNT=1
LOGERR="/var/log/sleepwaketesterror.log"
LOGRUN="/var/log/sleepwaketestrun.log"
ERRCOUNT="/var/log/sleepwaketestresult.log"
TMP="/var/log/tmp.txt"

pushd /usr/local/bin/


rm $LOGRUN
rm $TMP

H=$(echo "show State:/Network/Global/IPv4" | scutil | grep Router)
HOST=$(echo $H | sed 's/Router : //g')

en0=$(echo "show State:/Network/Global/IPv4" | scutil | grep en0)

if [ "$HOST" = "" ]||[ "en0" = "" ]; then
	echo "***********************************"
	echo "Springboard reports not using en0 or can not get Router DHCP IP address"
	echo "***********************************"

else 
	if [ "$1" = "" ]; then
		echo "***********************************"
		echo "Please input AP SSID"
		echo "***********************************"
		echo ""
	else
		AP=$1
		#echo "Router IP is $HOST"
	
		if [ "$2" != "" ]; then
			URL=$2
		fi
	
		echo ""
		echo "***********************************"
		echo "Test with $AP; Router IP is $HOST; URL is $URL"
		echo ""
		while($CONTINUE); do
		      LEAKS=$(leaks configd | grep "0 leaks for 0 total leaked bytes.")
		      echo $LEAKS

		      if [ "$LEAKS" = "" ]; then
		      	cp /Library/Logs/wifi.log /Library/Logs/problemwifi.log
		      	leaks configd > /Library/Logs/leaks.txt
		      	echo "Found leak. Data saved"
		      	CONTINUE=false
		      	exit
                      else
                      	echo "No leaks found"
                      fi

		      echo
		      echo "Calling SleepCycler"
		     ./SleepCycler -n 1 -s $SLEEP -w $WAKETIME
		     echo
			/usr/local/bin/eventer x
			#sleep 1
			/usr/local/bin/interact unlockScreenIfNecessary >> $TMP
			#/usr/local/bin/eventer h
			#sleep 1
			#/usr/local/bin/eventer t 20 400 drag 300 400
 	
		 	PING_AGAIN=true
			#The initial delay of the first ping after screen unlocked, and the ping timeout
			PING_COUNT=2
		 	TIME_COUNT=$PING_COUNT
			#The delay between each tries is the time of ping Rount delay plug ping URL delay
			TIME_DELAY=`expr $PING_COUNT + 1`
			
			END_TIME_COUNT=$(((TIME_DELAY * 3) + PING_COUNT))
			
			autojoin_result="FAIL"
			ping_result="FAIL"
			pingURL_result="FAIL"
			test_result="FAIL"
			autojoin_passtime=0
			ping_passtime=0	
	
		    while [ "$TIME_COUNT" -le "$END_TIME_COUNT" -a $PING_AGAIN = true ]; do
		        
				echo "ping -c $PING_COUNT -t $PING_COUNT $HOST"
				ping -c 2 -t $PING_COUNT $HOST
				
				#if ping URL did not pass
			    if [ 0 -ne $? ]; then
					./apple80211 -ssid
				    SSID=`./apple80211 -ssid`
					if echo $SSID | grep -qv "$AP"; then
						autojoin_result="FAIL"
						ping_result="FAIL"
						autojoin_passtime=0
						echo "Auto join with $AP Fail"
			        else
						autojoin_result="PASS"
						#If auto join passed before ping pass
						if [ "$autojoin_passtime" -le 1 ] ; then
							autojoin_passtime=$TIME_COUNT
						fi
						ping_result="FAIL"
					fi
					# if ping URL did not pass, add 1 second delay because it wont try to ping URL
					sleep 1
		       	else 
					ping -t 1 -c 1 $URL
					if [ 0 -ne $? ]; then
						pingURL_result="FAIL"
					else
						en0=$(echo "show State:/Network/Global/IPv4" | scutil | grep en0)
						if [ "$en0" != "" ]; then
							pingURL_result="PASS"
							PING_AGAIN=false
						fi
					fi
					
					autojoin_result="PASS"
					# If autojoin time did not set then set it because Ping URL Passed
					# Or if this is the first loop, also need to set autojoin_passtime
					if [ "$autojoin_passtime" -le 1 -o "$TIME_COUNT" -eq "$PING_COUNT" ]; then
						autojoin_passtime=$TIME_COUNT
					fi
					
					if [ "$ping_result" = "FAIL" ]; then
						ping_passtime=$TIME_COUNT
						ping_result="PASS"
					fi
					
								
		        fi
				echo "$COUNT : Now, TIME_COUNT is: $TIME_COUNT; ping_passtime is $ping_passtime; autojoin_passtime is $autojoin_passtime";
		        TIME_COUNT=`expr $TIME_COUNT + $TIME_DELAY`;
				#sleep $SLEEP_DELAY;
				echo "$COUNT : Next, TIME_COUNT will be: $TIME_COUNT; ";
		     done
        
						
			if [ "$pingURL_result" = "PASS" ]&&[ "$ping_result" = "PASS" ]; then
				test_result="PASS"
			fi
			#echo test results
			echo "$COUNT : Test Result with $AP: $test_result; Auto Join $autojoin_result within $autojoin_passtime; Ping $HOST $ping_result within $ping_passtime; Ping $URL: $pingURL_result" 
			echo "$COUNT : Test Result with $AP: $test_result; Auto Join $autojoin_result within $autojoin_passtime; Ping $HOST $ping_result within $ping_passtime; Ping $URL: $pingURL_result" >> $LOGRUN 
		    echo "Completed cycle $COUNT"
			date
			echo "Completed cycle $COUNT" >> $LOGRUN
			date >> $LOGRUN
	
		    ((COUNT++))
			sleep 10
		done
	fi
fi
popd