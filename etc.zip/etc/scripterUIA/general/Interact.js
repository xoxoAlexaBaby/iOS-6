#!/usr/local/bin/scripter -uiautomation YES -f

#import "../libs/SpringBoard.js"

function usage() {
	system.println("usage: Interact.js [-i] [--donotunlock] [--donotdismissalerts] [<command> | <keyword>...]");
	system.println("'interact' allows direct manipulation and queries of the current view\n");
	system.println("Optional flags to interact:");
	system.println("-i <path>	path to script library to load before running commands");
	system.println("--donotunlock	does not unlock screen before running the commands");
	system.println("--donotdismissalerts	disables auto dismissing of alerts");
	system.println("\nView information keywords:");
	system.println("   info [\"<predicate string>\"] [\"<format string>\"] print out UIA element info. Default format is \"Level: %l | %r | %c | %t | %n | %v\"");
	system.println("   query [\"<predicate string>\"] [\"<format string>\"] print out UIA element info (the first element that matches the query).  Default format is \"Level: %l | %r | %c | %t | %n | %v | %e\"");
	system.println("   tree [\"<predicate string>\"] [\"<format string>\"] print out UI element info (indented).  Default format is \"%c [name:%n]\"");
	system.println("      <format string> options:");
	system.println("         %l - element heirarchy level");
	system.println("         %n - element name");
	system.println("         %c - element class Name");	
	system.println("         %t - element UIAElement class");
	system.println("         %v - element value");
	system.println("         %r - element rect coord");
	system.println("         %e - expression to access the element");
	system.println("      <predicate string> see NSPredicate documentation");
	system.println("\nView manipulation keywords:");		
	system.println("   menu\t\t\t\t\tclick the menu button");		
	system.println("   tap <query>\t\t\t\ttap the element returned by <query>");			
	system.println("   tap <x>,<y>\t\t\t\ttap at the specified location using the format \"x,y\"");		
	system.println("   drag <x1>,<y1>,<x2>,<y2>\t\tdrag from location x1,y1 to x2,y2");
	system.println("   flick <x1>,<y1>,<x2>,<y2>\t\tflick from location x1,y1 to x2,y2");	
	system.println("   type <string>\t\t\ttype <string> using the keyboard");
	system.println("   delay <seconds>\t\t\tsleep the script for <seconds> seconds");
	system.println("   lock \t\t\t\tlock the device if it is not already locked");
	system.println("   unlock \t\t\t\tunlock the device if it is not already unlocked");
	system.println("\nMore other:");
	system.println("   properties\t prints out the properties for an object");
	system.println("   command\ta line of scripter javascript to run");
	system.println("   For more information on the syntax, please look up http://eightball.apple.com/wiki/index.php/UIAutomation\n");
	system.println("\nExamples:");
	system.println("   interact query \"name contains 'Search'\"\t#Returns all the elements whose names contain 'Search'");
	system.println("   interact tap \"name == 'Featured' and isVisible == 1\"\t#Taps a visible button with name 'Featured'");
	system.println("   interact info\t\t#prints UI element info using default format:");
	system.println("   interact tree \"{ className: %c }{ typeString: %t }{ name: %n }{ value: %v}\"\t#Displays view heirarchy with a user-specified format");
	system.println("   interact drag 100,100,200,200\t\t#Drag the view from coordinates: (100, 100 ) to (200, 200)");
	system.println("   interact \'app.search( \"Amazon\" );\'\t#Execute search function ");
	system.println("   interact \'app.mainWindow().tableViews()[0].scrollToElementWithName(\"Test\");\'\t#Scrolls to the UIATableCell object with name \'Test\'");
	system.println("   interact -i /usr/local/etc/scripterUIA/phone/Phone.js \'phone.makeCall([\"4087773456\"]);\'\t#Imports the Phone.js library file, and calls the the makeCall library function");
	system.println("   interact \"var addButton = app.navigationBar().buttons().firstWithPredicate(\\\"name contains 'Add'\\\")\" \"if (addButton.isValid()) addButton.tap()\"\t#Finds the add button using a predicate, and taps it");
	
	system.println("");
	system.exit(-1);
}

function _query(element, predicate) {

	target.pushTimeout(0);
	
	var matchingElements = element.elements().withPredicate(predicate).toArray();

	var childElements = element.elements().toArray();
	for (var index in childElements) {
		matchingElements = matchingElements.concat(_query(childElements[index], predicate));
	}
	
	return matchingElements;
}

function _logElementsInfo(elements, indent, options) {
	for (var index in elements) _logElementInfo(elements[index], indent, options)
}

function _logElementInfo(element, indent, options) {
	target.pushTimeout(0);
	
	if (!element || typeof element == 'undefined') return;
	
	if (element instanceof UIAElementArray) {
		var childElements = element.toArray();
		for (var childElement in childElements) _logElementInfo(childElements[childElement], indent, options);
	} else if (element instanceof UIAElement) {
		var attributes = element.attributes();
		var ancestryCount = element.ancestry().length;
		if (ancestryCount == 1) system.println("___________________________________");
		var output = "%l | %r | %c | %n | %v";
		if (typeof options == 'object') {
			if (typeof options.formatString != 'undefined') {
				output = options.formatString;
			}
			if (typeof indent != 'undefined' && indent) {
				for (var counter = 1; counter < indent; counter++) output = "     " + output;
				output = indent++ + ") " + output;
			}
		}
		
		// replace format characters with info
		if ( output.match( /%r/ ) ) {
			var rect = element.rect();
			// adding x:, y:, w:, and h: to make it more clear what values are shown between the brackets (x: x origin, y: y origin, w: width of element, h: height of element)
			var rectStr = "{x:" + parseInt(rect.origin.x) + ", y:" + parseInt(rect.origin.y) 
			+ ", w:" + parseInt(rect.size.width) + ", h:" + parseInt(rect.size.height) + "}";
			output = output.replace( /%r/g, rectStr );	
		}
		output = output.replace( /%l/g, "Level: " + ancestryCount);
		output = output.replace( /%c|%t/g, attributes["class"]);
		output = output.replace( /%n/g, element.name());	
		output = output.replace( /%v/g, element.value());
		output = output.replace( /%u/g, attributes["url"]);
		if (output.indexOf("%e") >= 0) {
			//only evaluate the full expression string if needed, it is very expensive otherwise
			output = output.replace( /%e/g, element.scriptingSynonymFullExpressionString());
		}
		
		system.println(output);
		if (!options || !options.shouldOnlyLogElement) _logElementInfo(element.elements(), indent, options);
	}
	target.popTimeout();
}

function expandKeyword(command) {
	switch (command) {
		case 'info':
			var arg1 = ARGV.shift();
			var arg2 = ARGV.shift();
			if ( typeof arg1 == 'undefined' && typeof arg2 == 'undefined' ) return "_logElementInfo(target)";
			else if ( typeof arg1 != 'undefined' && typeof arg2 != 'undefined' ) return "_logElementsInfo(_query(target, \"" + UIAUtility.escapeQuotes(arg1) + "\"), null, {formatString: '" + arg2 + "'} )";
			else if ( typeof arg2 == 'undefined' && arg1.match( /%c|%n|%l|%r|%t|%v/g ) ) return "_logElementInfo(target, null, {formatString: \"" + arg1 + "\"})";
			else if ( typeof arg2 == 'undefined' && !arg1.match( /%c|%n|%l|%r|%t|%v/g ) ) return "_logElementsInfo(_query(target, \"" + UIAUtility.escapeQuotes(arg1) + "\"))";
		case 'query':
			var arg1 = ARGV.shift();
			var arg2 = ARGV.shift();
			var defaultFormat = "%l | %r | %c | %n | %v | %e";
			if ( typeof arg1 == 'undefined' && typeof arg2 == 'undefined' ) return "_logElementInfo(target, null, {formatString: '" + defaultFormat + "'})";
			else if ( typeof arg1 != 'undefined' && typeof arg2 != 'undefined' ) return "_logElementsInfo(_query(target, \"" + UIAUtility.escapeQuotes(arg1) + "\"), null, {formatString: '" + arg2 + "', shouldOnlyLogElement:1} )";
			else if ( typeof arg2 == 'undefined' && arg1.match( /%c|%n|%l|%r|%t|%v|%e/g ) ) return "_logElementInfo(target, null, {formatString: '" + arg1 + "', shouldOnlyLogElement:1})";
			else if ( typeof arg2 == 'undefined' && !arg1.match( /%c|%n|%l|%r|%t|%v|%e/g ) ) return "_logElementsInfo(_query(target, \"" + UIAUtility.escapeQuotes(arg1) + "\"), null, {shouldOnlyLogElement:1, formatString: '" + defaultFormat + "'})";
		case 'menu':
		case 'home':
			return "target.clickMenu()"
		case 'tap':
			var parameters = ARGV.shift().split(",");
			if (parameters.length < 1) throw "no arguments provided to 'tap'";
			if (parameters.length == 1) return "var queryResults = _query(target, \"" + UIAUtility.escapeQuotes(parameters[0]) + "\"); if(queryResults.length > 0) queryResults[0].tap(); else system.println('Could not find element');";
			return "target.tap({x:" + parameters[0].toString() + ", y:" + parameters[1].toString() + "})";
		case 'drag':
			var parameters = ARGV.shift().split(",");
			if (parameters.length < 4) throw "not enough arguments provided to 'drag'";
			var duration = (parameters.length = 4) ? (1) : parameters[4];
			return "target.dragFromToForDuration({x:" + parameters[0] + ", y:" + parameters[1] + "}, {x:" + parameters[2] + ", y:" + parameters[3] + "}, " + duration + ")";
		case 'flick':
			var parameters = ARGV.shift().split(",");
			if (parameters.length < 4) throw "not enough arguments provided to 'flick'";
			return "target.flickFromTo({x:" + parameters[0] + ", y:" + parameters[1] + "}, {x:" + parameters[2] + ", y:" + parameters[3] + "})";
		case 'type':
			var text = ARGV.shift().replace(/\n/g, "\\n");
			return "asApp.typeStringWithKeyboard('" + text + "')";
		case 'delay':
			return "target.delay(" + parseInt(ARGV.shift()) + ")";
		case 'lock':
			return "target.lock()";
		case 'unlock':
			return "target.unlock()";
		case 'tree':
			// Print out intented list of current view class heirarchy
			var arg1 = ARGV.shift();
			var arg2 = ARGV.shift();
			if ( typeof arg1 == 'undefined' && typeof arg2 == 'undefined' ) return "_logElementInfo(target, 1, {formatString: '%c [name: %n]'} )";
			else if ( typeof arg1 != 'undefined' && typeof arg2 != 'undefined' ) return "_logElementsInfo(_query(target,\"" + UIAUtility.escapeQuotes(arg1) + "\"), 1, {formatString: '" + arg2 + "'} )";
			else if ( typeof arg2 == 'undefined' && arg1.match( /%c|%n|%l|%r|%t|%v/g ) ) return "_logElementInfo(target, 1, {formatString: '" + arg1 + "'} )";
			else if ( typeof arg2 == 'undefined' && !arg1.match( /%c|%n|%l|%r|%t|%v/g ) ) return "_logElementsInfo(_query(target,\"" + UIAUtility.escapeQuotes(arg1) + "\"), 1, {formatString: '%c [name: %n]'} )";

		case 'properties':
			var object = eval(ARGV.shift());
			system.println(typeof topic);
			if (typeof object != 'undefined') {
				for (var key in object) system.println(key + " (" + typeof object[key] + ")");
			}
			return;
		case '--help':
		case '-h':
		case 'help':
			usage();
		case '--donotunlock':
			return;
		case '--donotdismissalerts':
			return "UIATarget.disableOnAlert=1";
		default:
			return command;
	}
}

if (ARGV.length < 1 || ARGV.indexOf('--help') >=0 || ARGV.indexOf('-h') >=0 || ARGV.indexOf('help') >=0) usage();

var target = UIATarget.localTarget();
if (ARGV.indexOf('--donotunlock') < 0) target.unlockScreenIfNecessary();

var events = new SyntheticEvents();
var id = UIAApp.bundleIDForFrontmostApp();
var asApp = new Application(id);

var frontMostApp = target.frontMostApp();
var app = UIAApp.application(id);

var command;
var result;

while (ARGV.length > 0) {
	var command = expandKeyword(ARGV.shift());
	result = eval(command);	
}

if (typeof result != 'undefined') {
	system.println(String(result));
}
