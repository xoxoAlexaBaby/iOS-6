#!/bin/sh

#########################
##	ScriptName:	3GVoiceCallsTest.sh
##	Usage:		./3GCallsOnly.sh {iterations to run} {Max_Length_of_Calls_in_minutes,0=NO LIMT}
##	Purpose: 	To make calls on 3G and keep them active till either a call drop happens or 
##				the device hands over to 2G, keep call active for 30 seconds after HO to ensure that 
##				the HO succeeded.
##				Length of call can be user specified in minutes or 2 hours if given as 0 minutes
##				After every iteration check whether the device is still on 3G or not, otherwise 
##				try forcing 3G by going in/out of Airplane mode.
##	Author:		Puneet Mishra
##	Revision History
VERSION=v23
##
##  VERSION		23
##	06/22/2008		pmishra@apple.com	First Version	
##	07/13/2010		Jerome Jesu jesu@apple.com. V21 -- Time Synced
##################################################

echo "Running Version $VERSION of the scripts..."
SCRIPTS_DIR="/usr/local/etc/BasebandStressTests/"
source $SCRIPTS_DIR/config.sh

WAIT_TIME=60     # Interval between calls.
NUMBER="4089619342"

## PROCESS COMMAND-LINE ARGUMENTS
startTime=0
loops=0
interval=0
ratSelection=0   # default is 3G

while getopts 'i:t:r:h' OPTION; 
do
	case "$OPTION" in
		i )	loops=1; 
			TOTAL_CALLS="$OPTARG";;
		t )	interval="$OPTARG";;
		r )	ratSelection="$OPTARG";;
		h ) echo "Usage: ./VoiceCallsTest--AudioFeedback.sh -i <number of calls> -t <minutes per call> -r <0 | 1>"; exit 1;;
		/?)	echo "INVALID OPTIONS.\n"; exit 1;;
	esac
done
shift $(($OPTIND - 1))


## PARAMETERS VALIDATION
if [ $loops -ne 1 ]; then
	echo "\nUSAGE: $0    -i <iterations>   -t <Call Length in minutes>  "
	echo "		example to run on 3G: $0   -i 100    -t 10 -r 0 (for 3G)\n"
	echo "		example to run on 2G: $0   -i 100    -t 10 -r 1 (for 2G or C2K)\n"
	exit 1
fi

if  [ $interval -eq 0 ]; then 
	MaxCallLength=10					  # in seconds
elif  [ $interval -gt 0 ]; then 
	MaxCallLength=`expr $interval \* 60`  # in minutes 
else
	MaxCallLength=`expr 2 \* 60 \* 60`	  # max length of 2 hours
	# two hours call
fi

Hardware=`/usr/local/bin/lockdown_query get NULL HardwareModel 2>&1 | cut -c1-3`
if [ $Hardware == "N92" ]; then ratSelection=1; fi

DEVICE_NAME=`hostname`
SUFFIX1=`echo $DEVICE_NAME | perl -lne '($s,$m,$H,$d,$M,$Y,$D) = localtime(); $Y += 1900; $M++; printf ("%s_%02d%02d-%02d%02d",$_,$M,$d,$H,$m); ' `


##############################################################################
##### HELPER FUNCTIONS 

getBuildVersions()
{
	/usr/local/bin/CoreTelephonyMonitor -q 2> BBVersion.txt &
	sleep 2; killall -9 CoreTelephonyMonitor; sleep 1;
	#BB_Build=`perl -lne 'if (/\QFirmware Version\E/ ) { @vers = split; $vers[2] =~ s/\[|\]//g;  print "$vers[2]" }' BBVersion.txt`
	#IMEI=`perl -lne 'if (/\QIMEI:\E/ ) { @imei = split; $imei[1] =~ s/\[|\]//g;  print "$imei[1]"; last; }' BBVersion.txt`
	#SERIAL=`/usr/local/bin/lockdown_query get NULL SerialNumber 2>&1`
	if [ $DEVICE_NAME == "iPhone" ]; then  DEVICE_NAME=$SERIAL; fi
	#APBuild=`sw_vers | perl -lne 'if (/\QBuildVersion\E/ ) { @vers = split; print "$vers[1]" }'`
}

initialize()
{
	iterations=0
	HandOverInCurrentCall=NO
	# kill any stray CTM processes from previous iterations/runs
	killall -9 CoreTelephonyMonitor					

	dismissAlerts	
	/usr/local/bin/testCT -x | grep status
	#grep "Call to $NUMBER"  CT.txt
	if [ $? -eq 0 ]; then 
		echo "Calls are active... so ending them."
		/usr/local/bin/testCT -e    #end all active calls
	else
		echo " There are no active calls to end."
	fi
	
	#Go to home scren
	/usr/local/bin/eventer h

	# kill any stray CTM processes from previous iterations/runs
	killall -9 CoreTelephonyMonitor	
	isCallDropped=1
}

generateReport()
{  	
    	echo "\n #################### Processing Logs ##########################"
		echo; ls -rlt $logsDir/log-bb-*;
		sleep 5;
		processCsiLogs
		echo " #################### Processing Completed ##########################\n"
		echo "Device_Name, Baseband Build, Iteration, Pass, Drop, Fail, Total Hand Overs in Test, HandOver In This Call, Call Start Time, Call End Time, Length Of Current Call, CallDrops(CSI_logs), CallFailures(CSI_Logs), Modem Resets, AP_Build, IMEI, SERIAL, 3G Drop, 2G within 15s, 2G after 15s, CALL DROP DURING" 
		echo "$DEVICE_NAME,$BB_Build,$COUNT,$PASS,$DROP,$FAIL,$HandOver,$HandOverInCurrentCall,$callStarted,$callEnded,$currentCallLength,$totalCallDrops,$totalCallFailures,$modemReset,$APBuild,$IMEI,$SERIAL,$umts,$umtsgsm,$gsm,$CALLDROPDURING,"
		echo "$DEVICE_NAME,$BB_Build,$COUNT,$PASS,$DROP,$FAIL,$HandOver,$HandOverInCurrentCall,$callStarted,$callEnded,$currentCallLength,$totalCallDrops,$totalCallFailures,$modemReset,$APBuild,$IMEI,$SERIAL,$umts,$umtsgsm,$gsm,$CALLDROPDURING,"  >> $resultFile.csv
		
		cp 	$resultFile.csv /var/mobile/Library/Logs/CrashReporter/
		cp  callended_${SUFFIX1}.txt /var/mobile/Library/Logs/CrashReporter/
}

dismissAlerts()
{
	echo "Dismissing Alerts.."
	/usr/local/bin/scripter -f /usr/local/etc/scripter/general/Interact.js com.apple.springboard "dismissAlerts(app)"
}

#prints the date in a CFAbsoluteTime format , used for syncing call drops with locations from GPS
logCallEndedDate()
{
	callEnded=`date`
	i=`date +%s`
	dateInCFAbsoluteSeconds=`expr $i - 0`
	echo $dateInCFAbsoluteSeconds >> callended_${SUFFIX1}.txt
	echo " CALL Ended at $dateInCFAbsoluteSeconds -- Playing OLD CAR HORN Sound.\n" 
	killHungProcess  figplayAV 10 &
	/usr/local/bin/figplayAV -a /Library/Ringtones/Old\ Car\ Horn.m4r 
	musicPlayed=$?
	if [ $musicPlayed -eq 0 ]; then echo "OLD CAR HORN was played. Check your ENT specialist if you dont hear."; fi
}	

checkIfCallDropped()
{
		/usr/local/bin/testCT -x | grep status
		#grep -i "There are currently no calls." CT.txt
		isCallDropped=$?
}

logCallPASS()
{
		PASS=`expr $PASS + 1`
		CALLDROPDURING=""
		dismissAlerts
}

# takes 1 parameter the call number
takeK00lState()
{
		dismissAlerts
		/usr/local/bin/testCT -c *5005*78283#
        sleep 1
        #touch the Reply Button
        eventer t "Reply"
        eventer w "Call Number "
        eventer w $1
        #touch the Send button
        eventer c "Reply"
}

processCsiLogs()
{
	cp  $logFiles  $csiLogsDir/
	ls $csiLogsDir/*csi* | perl -lne '$f = $_; open (F, $f); $f =~ s/(.*\Qlog-bb-\E)(.*)(\Q-csi.\E(.*))/$2/; foreach (<F>) { chomp; if (/\QReason: \E/) { s/^(.*Reason: )//; $i=$_; print "$i,$f"; last; } } close F; '  > /tmp/crashReasons
	
	totalCsiLogs=`ls $csiLogsDir/*csi* | wc -l | perl -lne ' s/\s*//; print'`
	totalModemResets=`cat /tmp/crashReasons | grep "modem reset" | wc -l | perl -lne ' s/\s*//; print'`
	totalBasebandCrashes=`cat /tmp/crashReasons | grep "baseband crash"| wc -l | perl -lne ' s/\s*//; print'`
	totalCallFailures=`cat /tmp/crashReasons | grep -i "call fail" | wc -l | perl -lne ' s/\s*//; print'`
	totalCallDrops=`cat /tmp/crashReasons | grep -i "call drop"| wc -l | perl -lne ' s/\s*//; print'`
	totalFTO=`cat /tmp/crashReasons | grep "FTO" | wc -l | perl -lne ' s/\s*//; print' `
	totalBBResets=$(($totalModemResets + $totalBasebandCrashes))
	totalBBResets=`echo $totalBBResets | perl -lne ' if (/^\s*$/) { print "0";} else { print;} ' `
	cp /tmp/crashReasons CrashReasons.csv
	
	echo "\n ****************  LOG DETAILS:  *********************"
	echo "  RESETS-$totalModemResets  CRASHES-$totalBasebandCrashes   TOTAL-$totalBBResets"
	echo "  FAIL-$totalCallFailures,  DROPS-$totalCallDrops,  FTO-$totalFTO,"
	echo "  TOTAL-$totalCsiLogs\n"
	echo "\n ****************  REASONS FOR CSI LOGS:  *********************"
	head -1 $logFiles
	cp  $logFiles  $csiLogsDir/
} 

killHungProcess()
{
		echo "Sleeping $2 seconds..."
		sleep $2
		echo "Killing $1"
		GREP="grep $1"
		PIDS=`ps -A | $GREP | perl -lne ' if ( !/grep/ && !/killHungProcess/ ) { $p = (split)[0]; $p =~ s/\s*//g; print $p;} ' `
		echo " Showing Process.."
		ps -A | $GREP
		echo "KILLING Processes -- $PIDS.\n"
		kill -9 $PIDS
}

generateHoToneAndWaitFor15s()
{
	HandOverInCurrentCall=YES
	killHungProcess  figplayAV 5 &
	/usr/local/bin/figplayAV /Library/Ringtones/Doorbell.m4r &
	echo "HO Happened"
    HandOver=`expr $HandOver + 1`
	# wait for 15 seconds to ensure HO was successful and the call is still going
	# on 2G
	sleep_afterHO=0
	CALLDROPDURING="Within 10 seconds after HO"
						
	while [ $sleep_afterHO -lt 10 ]; do
		sleep 1;
		grep -i "There are currently no calls." CT.txt
		if [ $? -eq 0 ]; then break;  fi
		if [  $sleep_afterHO -gt 15 ]; then  CALLDROPDURING="On 2G 15 seconds after HO"; fi
		CALLDROPDURING="On 2G 15 seconds after HO"
		sleep_afterHO=`expr $sleep_afterHO + 1`; 
	done	
                		
}

reselectTo3G()
{
		echo "Checking for 3G indication"
		checkFor3G_seconds=0
		
		while [ 1 ]; 
		do
                grep -i kCTRegistrationDataIndicator3 CT.txt
                if [ $? -eq 0 ]; then
                	killall -9 CoreTelephonyMonitor				
					echo "On 3G"
                	break;
                fi
				echo "No 3G yet, waiting for 3G or 3.XG indication"
				sleep 2;	
				checkFor3G_seconds=`expr $checkFor3G_seconds + 2`
		done
		echo "Waited for reselection: $checkFor3G_seconds seconds"
		CALLDROPDURING="On 3G"
}

handleIRATHandover()
{
		generateHoToneAndWaitFor15s
		#check if the call is still active
		checkIfCallDropped
		
		if [ $isCallDropped -eq 0 ]; then
			echo "CALL PASSED: HO Successful"
			logCallPASS
			testCT -l " Call Ending after IRAT Handover."
		else
			echo "CALL DROPPED AFTER IRAT HO"
			DROP=`expr $DROP + 1`
			if [  $sleep_afterHO -ge 10 ]; then ((gsm++));
			else ((umtsgsm++)); fi
			echo " #### Call dropped - $DROP - after IRAT\n #### Logging the Call Ended time."
			logCallEndedDate
		fi	
}


##############################################################################

# start counter
COUNT=0
PASS=0
FAIL=0
DROP=0
HandOver=0
HandOverInCurrentCall=NO
umts=0
gsm=0
umtsgsm=0
CALLDROPDURING=""
modemReset=0
totalCallDrops=0
totalCallFailures=0
modemReset=0
iterations=0

logsDir="/private/var/wireless/Library/Logs/CrashReporter/Baseband/"
logFiles="$logsDir/*csi*"
csiLogsDir="CsiLogs_Temp"
getBuildVersions
resultFile=`echo $DEVICE_NAME | perl -lne '($s,$m,$H,$d,$M,$Y,$D) = localtime(); $Y += 1900; $M++; printf ("Results_%s_%02d%02d-%02d%02d",$_,$M,$d,$H,$m); ' `
echo "Device_Name, Baseband Build, Iteration, Pass, Drop, Fail, Total Hand Overs in Test, HandOver In This Call, Call Start Time, Call End Time, Call Length in s, CallDrops(CSI_logs), CallFailures(CSI_Logs), Modem Resets, AP_Build, IMEI, SERIAL, 3G Drop, 2G within 15s, 2G after 15s, CALL DROP DURING" >> $resultFile.csv
mv $csiLogsDir $csiLogsDir-$SUFFIX1/
mkdir $csiLogsDir/

getBuildVersions
echo 


# Starting the Drive Tests
while [ $COUNT -lt $TOTAL_CALLS ]
do
		COUNT=`expr $COUNT + 1`;
		echo "\n\n******************* Beginnning Iteration: $COUNT ********************"
		initialize

		# Wait for registration on 3G
        /usr/local/bin/CoreTelephonyMonitor 2>CT.txt &
		
		if [ $ratSelection -eq 0 ]; then
			echo "Wait for the Device to Reselect to 3G"
			reselectTo3G
			echo "Time to Reselect to 3G: $checkFor3G_seconds seconds"
		fi
		dismissAlerts
        

		##### MAKING VOICE CALL		
		callStarted=`date`
 		callStartTimeSeconds=`date "+%s"`
        /usr/local/bin/testCT -c $NUMBER
        
        if [ $? -eq 0 ];  
        then   #call succeeded
        
       			killall -9 CoreTelephonyMonitor
        		/usr/local/bin/CoreTelephonyMonitor 2>CT.txt &
			
				## Waiting till the Call Drops or Hands over or Call length reached...
	        	while [ 1 ]
    	    	do
						echo "Call status processing..."
						sleep 5
                		
                		echo "Checking for RAT Selection"
                		if [ $ratSelection -eq 0 ]; then
                			grep -i kCTRegistrationDataIndicatorNone CT.txt
                			hoHappened=$?
                			if [ $hoHappened -eq 0 ]; then
								handleIRATHandover
								break;
							fi

                		fi
                
       					#check if the call is still active
       					echo "Checking for Call Drop..."
						checkIfCallDropped
						
						if [ $isCallDropped -eq 0 ]; 
						then
                				iterations=`expr $iterations + 1`
                				callLength=`expr $iterations \* 5`
                				echo "Call still going"
                				echo "Approximate time since call is up: $callLength seconds" 
                		
                				if [ $callLength -ge $MaxCallLength ]
                				then
									echo "CALL PASSED: Call Length limit specified by user has been reached"
                					PASS=`expr $PASS + 1`
                					CALLDROPDURING=""
									#end the call
									echo "Ending call after reaching Max Call Time - $MaxCallLength."
									break;
								fi                		
               			else
               					echo "CALL DROPPED ON 3G"
    	    					callEnded=`date`                		
        	        			DROP=`expr $DROP + 1`
        	        			((umts++))
        	        			echo " #### Call dropped on 3G -- Drop = $DROP\n #### Logging the Call Ended time."
        	        			logCallEndedDate
                        		break;                
                		fi  
                             
				done
			
		else	
				#call failed
				echo "CALL SETUP FAILED"
        		callEnded=`date`                
				CALLDROPDURING="Call Setup Failure"
               	FAIL=`expr $FAIL + 1`
               	date
               	echo " #### Call Failed - $FAIL - during ORIGINATION\n ####  Call Ended time is not logged."
               	endFlag=0
               	#logCallEndedDate
    	fi 
    	
		now=`date "+%s"`
    	/usr/local/bin/testCT -x | grep status
		#grep "Call to $NUMBER"  CT.txt
		if [ $? -eq 0 ]; then
				echo "Ending the Call... $COUNT"
				/usr/local/bin/testCT -e    #end all active calls
				callEnded=`date`;
		fi
		
		currentCallLength=$(($now - $callStartTimeSeconds))
    	generateReport
done

killall -9 CoreTelphonyMonitor
sleep 5
echo "Done with the Voice Call Testing for $COUNT calls... Processing the logs again."
generateReport
echo "Done..."

