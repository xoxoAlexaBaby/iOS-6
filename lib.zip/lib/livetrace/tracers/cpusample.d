#pragma D option quiet
#pragma D option strsize=16
#pragma D option bufsize=512k
#pragma D option dynvarsize=64k
#pragma D option aggsize=64k

/* @description Sample current CPU process and thread, and some other counters, every 5 ms */

profile:::profile-5ms
{
    printf("%d %s.%08x %08x %d %c %d %d\n", timestamp, execname, (uint32_t) curthread, uregs[15],
        mach_kernel`master_processor->runq.count + mach_kernel`rt_runq.count,
        mach_kernel`master_processor->state == 4 ? 'I' : 'R',
        mach_kernel`bufstats.bufs_iobufinuse,
        mach_kernel`master_processor->processor_data.vm_stat.pageins);
}
