// GameKitTesterAutomation.js
// -----------------------------------------------------------------------------
//  $Date: 2010-09-14 19:17:42 -0700 (Tue, 14 Sep 2010) $
//  $Author: heard $
//  $Rev: 252643 $
// -----------------------------------------------------------------------------


#import "/usr/local/etc/scripterUIA/libs/SpringBoard.js" 
//for the UIAFileLogger
new UIAFileLogger('/var/mobile/Library/Logs/GKTAutomation.txt'); //log to the filesystem


//UIA logs global variable. (used by the log() and logResult() methods. )
var uiaLogs = "";


//Define basic settings here so they are global.
var ssid = "";
var wifiPassword = "";
var wifiType = "";
var playerAppleID = "";
var playerPassword = "";


//create a system object if available.
try {
   if (typeof system == 'undefined') system = new System();	
} catch (e) {
   UIALogger.logMessage("Couldn't create the system object. This is expected if you're running from the Instrument.");
   
}
   
//----------- SYSTEM FUNCTIONS -----------
   
function launchApp(bundleID) {
   if (typeof system != 'undefined') {
      log("Launching: " + bundleID);
      system.run("/usr/local/bin/LaunchApp " + bundleID, 5);
   
   } else {
      log("Failed to launch app: " + bundleID);
   }
}

//this function checks to see if the bundleID is frontmost. 
// if its not, it waits and retries a few more times. 
// (to allow alerts hosted by springboard to not cause a false result)
function appIsRunning(bundleID) {
   
      //old school way
      var count = 6;
   while (count-- > 0){
      if (UIATarget.localTarget().frontMostApp().bundleID() == bundleID) {
         return true;
      }
      log("appIsRunning() : '" + bundleID + "' is not currently frontmost. Trying " + count + " more times." );
      delay(1);
   }


   //hack for UIAlerts getting wedged on screen. <rdar://problem/8257507>
   if (typeof system != 'undefined') {
      //we have system ability, lets check to see if we are still running using top
      
      var result = system.run("/usr/bin/top -l 1", 5);

      if (result.stdout.indexOf("GameKitTester") != -1){
         log("The Top command says GKTester App is running! We are likely wedged by multiple UIAlerts on screen. <rdar://problem/8257507> ");
         
         log("Lets try and dismiss any alerts.");
         dismissAllAlerts();    
         
         //we should now be unwedged and are still running.
         return true;
      }
      
      log("system: The top command says GKTester app is not running!");
   }
   
   
   log("App '" + bundleID + "' is still not frontmost. Assuming App is not running!");
   return false;
}



function joinWiFi() {

   //if we are currently on wifi, log and return. 
   if (ssid == currentSSID()){
      log('Asked to join Wifi, however we are already on "' + ssid + '". No need to re-join. Ignoring.');
      return;
   }

   if (typeof system != 'undefined') {
      log("Attempting to join WiFi");
      
      //special case the Settings for our fake 3G mode in the lab. 
      if (ssid == "3G"){
         system.run("/usr/local/bin/wifitool -r 10 -s -j gktest3 -e wpa2 -p thunderdome", 5);
      } else if (ssid == "3G-spiderpigdeux"){
         system.run("/usr/local/bin/wifitool -r 10 -s -j spiderpigdeux -e wpa2 -p n45iscool", 5);
      } else {
         system.run("/usr/local/bin/wifitool -r 10 -s -j " + ssid + " -e " + wifiType + " -p " + wifiPassword, 5);
      }
      
      delay(5); // to let the connection happen.
      
   }
   
}

function leaveWiFi() {
   if (typeof system != 'undefined') {
      log("Attempting to leave WiFi");
      system.run("/usr/local/bin/wifitool -L", 5);
      delay(1); // to let the disconnect happen.
   }
}


function ifTesting3GLeaveWiFi() {
   //only leave WiFi if we are testing using the 3G SSID
   if (ssid == "3G" || ssid == "3G-spiderpigdeux") {
      leaveWiFi();
   }
}


//use Wifi Tool to get the SSID for the current network connection. 
function currentSSID(){
   if (typeof system != 'undefined') {
      var result = system.run("/usr/local/bin/wifitool --currentnet", 5);
      var info = result.stdout;
      var re = /^[\s]*ssid: "([\w-]*)"[\s]*$/m;
      var match = re.exec(info);
      if (match == null) {
         return 'NOT_ASSOCIATED';
      } else {
         return match[1];
      }
   }
   
   return 'NO_SYSTEM_OBJECT';
}


function logInDevice() {

   returnToMainMenu();

   ifTesting3GLeaveWiFi();

	// Login player account
   log("logInDevice()");
   log("Logging in player account");

	var mainWindow = UIATarget.localTarget().frontMostApp().mainWindow();
	var mainTableView = mainWindow.tableViews()[0];

	mainTableView.scrollToElementWithName("Local Player APIs");
	mainTableView.cells()["Local Player APIs"].tap();
	delay(1);
	
	mainWindow.tableViews()[0].cells()["Authenticate"].tap();
	delay(2);
	
	//Login with username and password is handled via the alert handler, if necessary.
   
   joinWiFi();
   
   returnToMainMenu();
   
}


//----------- UTILITY FUNCTIONS -----------

function log(message) {
   UIALogger.logDebug(message);
   //append our latest message to the log global
   uiaLogs += (message + "\n");
}


function syslog(message) {
   //append our message to the syslog
   if (typeof system != 'undefined') {
      var result = system.run("/usr/bin/syslog -s -l warning \"" + message + "\"", 5);
   } else {
      log('syslog() failed. Unable to get a system.run() instance.');
   }

}

function getSyslog(){
      // if we can, set the console to the current syslog.
      if (typeof system != 'undefined') {
         log("getSyslog()");
         var result = system.run("/usr/bin/syslog");
         var syslog = result.stdout;
         // trim anything before the last occurrence of "--------START GAMEKIT AUTOMATION RUN--------"
         var position = syslog.lastIndexOf("--------START GAMEKIT AUTOMATION RUN--------");
         if(position > 0)
            syslog = syslog.substr(position);
         
         //clean up memory faster.
         result = null;
         system.drain();
         return String(syslog);
      }
      
      return "no system object; therefore syslog not available";
}

function appendLatestCrashLog() {
   log("appendLatestCrashLog()");
   if (typeof system != 'undefined') {
      var result = system.run("/bin/cat /var/mobile/Library/Logs/CrashReporter/LatestCrash-GameKitTester.plist", 5);
      if (result.stdout == "") return;
      uiaLogs = "CRASHED:" + uiaLogs;
      uiaLogs += "----------------START CRASH LOG----------------\n";
      uiaLogs += result.stdout;
      uiaLogs += "\n-----------------END CRASH LOG-----------------\n";
   } else {
      log("appendLatestCrashLog() failed. Unable to get a system.run() instance.");
   }
}

function appendMemoryUsage() {
   log("appendMemoryUsage()");
   if (typeof system != 'undefined') {
      //var result = system.run("/usr/bin/top -l1 | /usr/bin/grep '\(MemRegions\|PhysMem\|PID\|GameKitTester\|apsd\|gamed\|scripter\|SpringBoard\|VM\)'", 10);
      var result = system.run("/usr/bin/top -l1 -stats PID,COMMAND,TIME,PORTS,RPRVT,RSHRD,RSIZE,VPRVT,VSIZE,STATE,FAULTS,PAGEINS", 10);
      
      
      //define a filter so we only collect lines we want.
      var wanted = function(x) {
         // returns true if we want the specific line.
         var RegExp = /(MemRegions|PhysMem|PID|GameKitTester|apsd|gamed|scripter|SpringBoard|VM)/; 
         return String(x).match(RegExp);
      }

      var memUsage=result.stdout.split('\n').filter(wanted);

      uiaLogs += "----------------START MEMORY USAGE----------------\n";
      uiaLogs += memUsage.join('\n');
      uiaLogs += "\n---------------END MEMORY USAGE-----------------\n";
   } else {
      log("appendMemoryUsage() failed. Unable to get a system.run() instance.");
   }
}       
     

function delay(timeInterval) {
	UIATarget.localTarget().delay(timeInterval);
}

function shrinkTextOutputView() {
   returnToMainMenu();
   var tv = UIATarget.localTarget().frontMostApp().mainWindow().tableViews()[0];
   tv.scrollToElementWithName('Shrink Text Output View');
   
   if (tv.cells()['Shrink Text Output View'].checkIsValid())
      tv.cells()['Shrink Text Output View'].tap()
}

function dismissAllAlerts(){
   log("dismissAllAlerts()");

   //workaround for UIAlerts getting wedged on screen. <rdar://problem/8257507>                  
   log("Lets try and dismiss any alerts.");
   UIATarget.localTarget().pushTimeout(0);
   var alert = UIATarget.localTarget().frontMostApp().mainWindow().elements().firstWithPredicate("className == 'UIAAlert' and ANY buttons.isVisible == 1");
   while (alert.checkIsValid()) {
      log("Found an alert:");
      for (var i in alert.staticTexts()){
         log('Alert Text: "' + alert.staticTexts()[i].name() + '"');
      }
      
      //attempt to dismiss
      log("Tapping button 0 to dismiss");
      alert.buttons()[0].tap();
      alert = UIATarget.localTarget().frontMostApp().mainWindow().elements().firstWithPredicate("className == 'UIAAlert' and ANY buttons.isVisible == 1");
   }
   
   UIATarget.localTarget().popTimeout();
   
   //we should now be unwedged and are still running.
}




//----------- EXECUTION FLOW FUNCTIONS -----------

function logResult(result) {
   log('logResult (' + result + ')');
   
   while (true){
      log("Attempting to log result...");
      //we join the wifi here, so that we can log the results to the internal server.
      joinWiFi();
      
      delay(1);
      
      //logs either a pass or a fail result.
      returnToMainMenu();
      
      var mainWindow = UIATarget.localTarget().frontMostApp().mainWindow();
      var mainTableView = mainWindow.tableViews()[0];
      
      // Report results to server
      mainTableView.scrollToElementWithName("Log Results");
      mainTableView.scrollDown(); // scrollToElementWithName() does not appear to work!
      mainTableView.cells()["Log Results"].tap();
      
      delay(2);
      
      //set the pass / issue / fail result
      if (result == 'fail'){
         mainWindow.segmentedControls()[0].buttons().firstWithPredicate("name BEGINSWITH 'fail'").tap();
      }else if (result == 'issue'){
         mainWindow.segmentedControls()[0].buttons().firstWithPredicate("name BEGINSWITH 'issue'").tap();
      }else{
         //mainWindow.segmentedControls()[0].buttons().firstWithPredicate("name BEGINSWITH 'pass'").tap();
         //this is implied, as its default, but we are still interested in seeing if the button is not available so log it.
         if (! mainWindow.segmentedControls()[0].buttons().firstWithPredicate("name BEGINSWITH 'pass'").checkIsValid()){
            log("Pass segmentedControl is not Valid!");
         }
      }
      
      // if we can, set the console to the current syslog.
      mainWindow.textViews()["consoleLogs_tv"].setValue(getSyslog());
      
      //set the uiaLogs field
      mainWindow.textViews()["uiaLogs_tv"].setValue(uiaLogs);
      
      var submitButton = mainWindow.buttons()["Log Results"];
      submitButton.tap();
      
      //wait for submit to complete
      while (true){
         delay(1);
         var status = submitButton.name();
         log('Submit Result status: ' + status);
         if (status != 'Submitting\u2026'){
            break;
         }
      }
      
      if ( submitButton.name() == "Submission Successful"){
         break;
      }
      
   }
   
   //clean up
   	
	returnToMainMenu();
   ifTesting3GLeaveWiFi();
   
   uiaLogs = ""; //reset the logs store

}



function returnToMainMenu() {
   log("returnToMainMenu");
	var app = UIATarget.localTarget().frontMostApp();
   
   //add this so that we can dismiss the game sheet if we need to.
   if (app.mainWindow().buttons()['Leave Game'].checkIsValid() ){
      app.mainWindow().buttons()['Leave Game'].tap();
   }
	
   for (var i = 0; i < 10; i++) {
		if (app.navigationBar().leftButton().checkIsValid()) {
			app.navigationBar().leftButton().tap();
			delay(1);
		} else {
			break;
		}
	}
}

//we need a way to see if a failure actually occured during game play or if it occured before or after the test started or ended.
var gamePlayState = 'before'; //before / during / after


function getPersonaAndMakeMatch() {
   log("getPersonaAndMakeMatch");
   gamePlayState = 'before';

	var mainWindow = UIATarget.localTarget().frontMostApp().mainWindow();
	var mainTableView = mainWindow.tableViews()[0];
	      
	while (true) {
      log("Fetching Persona");

      returnToMainMenu();

      //we join the wifi here, so that we can download the persona from the internal server.
      joinWiFi();
      
		mainTableView.scrollToElementWithName("Retrieve Persona");
		mainTableView.cells()["Retrieve Persona"].tap();
		delay(1);
		
      var retrieveButton = mainWindow.scrollViews()[0].buttons()["Retrieve Next Persona"];
      retrieveButton.tap();
      
      //wait for download to complete
      while (true){
         delay(1);
         var status = retrieveButton.name();
         log('Persona download status: ' + status);
         if (status != 'Retrieving\u2026'){
            break;
         }
      }
         
		if (mainWindow.scrollViews()[0].textFields()["pleasehold_tf"].value() == "HOLDING") {
			log("Persona has told us to to HOLD. Try again in 5 seconds...");
			returnToMainMenu();
			delay(5); // retry every 5 seconds
		} else if (mainWindow.scrollViews()[0].textFields()["pleasehold_tf"].value() == "" || 
                 mainWindow.scrollViews()[0].textFields()["pleasehold_tf"].value() == null) {
			log("Persona failed to download. Try again in 5 seconds...");
			returnToMainMenu();
			delay(5); // retry every 5 seconds
		} else {
			break;
		}
      if (typeof system == 'undefined') system.drain();
	}
	
   //we are now inside an actual game atm. so any excpetions thrown are game play failures.
   gamePlayState = 'during';

   
   //leave WiFi if we are testing using the 3G SSID
   ifTesting3GLeaveWiFi();
   
	var textFields = mainWindow.scrollViews()[0].textFields();
	
	var invitee = false;
	if (textFields["invitee_tf"].value() == "YES") {
		invitee = true;
	}
	var playerAliasesToInvite = textFields["playerids_tf"].value();
   if (playerAliasesToInvite == null){
      playerAliasesToInvite = "";
      log("playerAliasesToInvite was = to null, making it = ' '.");
   }
	playerAliasesToInvite = playerAliasesToInvite.split('/');

   

	var totalPlayers = parseInt(textFields["totalplayers_tf"].value());
	var gameScript = textFields["gamescript_tf"].value();
	gameScript = gameScript == null ? array() : gameScript.split(",");
	var minPlayers = parseInt(textFields["minplayers_tf"].value());
	
	log("Invitee: " + invitee);
	log("Player Aliases To Invite: " + playerAliasesToInvite);
	log("Total Players: " + totalPlayers);
	log("Game Script: " + gameScript);
	log("Min Players: " + minPlayers);
	
	if (invitee) {
      log("We are an Invitee! (We set the invite handler then sit back and wait!)");
      
		// Return to the main menu and set the invite handler
		returnToMainMenu();
      
      log("Set Invite Handler");
		mainTableView.scrollToElementWithName("Set Invite Handler");
		mainTableView.cells()["Set Invite Handler"].tap();
		delay(2);
	}
	
	// invitee == False
	else {
      log("We are the Inviter! (Lets invite some people!)");
      
      log("Tap Make Match");
      mainWindow.scrollViews()[0].buttons()["Make Match"].tap();
      
		delay(14); // give all the devices enough time to re-request their personas 
                   //(worst case scenario the inviter is the last to get its persona 
                   // and immediately tries to invite the 3 devices, before they are ready)
                   // (invitee takes  5s + 1s + 3s + 3s to re-request persona)
		
      if(mainTableView.cells().firstWithPredicate("name BEGINSWITH 'Waiting for authentication'").checkIsValid()){
         log("Player appears to not be authenticated. Attempting to log in now...");
         logInDevice();
         //now attempt to return back to this point (ie re-show the matchmaking view.)
         joinWiFi();
         returnToMainMenu();

         mainTableView.scrollToElementWithName("Retrieve Persona");
         mainTableView.cells()["Retrieve Persona"].tap();
         delay(1);
         
         mainWindow.scrollViews()[0].buttons()["Retrieve Next Persona"].tap();
         delay(3);
         ifTesting3GLeaveWiFi();
         delay(3);
         mainWindow.scrollViews()[0].buttons()["Make Match"].tap();
         delay(3);
         
         log("Log in process complete.");

      }
      
		var playersTableView = mainWindow.tableViews()[0];
		var cell;
		
		// Add auto-matching players until there are totalPlayers players
		var currentPlayerSlots = minPlayers;
		while (currentPlayerSlots < totalPlayers) {
			cell = playersTableView.cells()["Remove Player"];
			cell.buttons()["Add Player"].tap();
			delay(2);
			currentPlayerSlots++;
		}
		
		// Invite the players to invite, until that array is empty
		log("Players to invite: " + playerAliasesToInvite.length);
		while (playerAliasesToInvite.length > 0) {
			var inviteeAlias = playerAliasesToInvite.shift();
			if (inviteeAlias.length == 0) {
				continue;
			}
			log("Sending invite to player: " + inviteeAlias);
			playersTableView.scrollToElementWithPredicate("name BEGINSWITH 'Auto-Match'");
			cell = playersTableView.cells().firstWithPredicate("name BEGINSWITH 'Auto-Match'");
			cell.buttons()["Invite Friend"].tap();
			delay(2);

         //we need to do use the search bar as the invite list as its lazy loaded.
         UIATarget.localTarget().frontMostApp().mainWindow().tableViews()[0].scrollUp();
         UIATarget.localTarget().frontMostApp().mainWindow().tableViews()[0].searchBars()[0].tap();
         UIATarget.localTarget().frontMostApp().mainWindow().tableViews()[0].searchBars()[0].setValue(inviteeAlias);
         
         if ( ! mainWindow.tableViews()[0].cells().firstWithPredicate("name CONTAINS '" + inviteeAlias + "'").checkIsValid()){
            log("We were unable to invite alias " + inviteeAlias + " because they are not a friend.");
            throw("We were unable to invite alias " + inviteeAlias + " because they are not a friend.");
         }
         
         delay(1);
			mainWindow.tableViews()[0].scrollToElementWithPredicate("name CONTAINS '" + inviteeAlias + "'");
			mainWindow.tableViews()[0].cells().firstWithPredicate("name CONTAINS '" + inviteeAlias + "'").tap();
			delay(2);
			mainWindow.navigationBar().buttons()["Next"].tap();
			delay(2);
			mainWindow.navigationBar().buttons()["Send"].tap();
			delay(2);
		}
		
		// Hold until all invites have been accepted
      log("Waiting for all invites to be accepted.");
      var timeout = 180 // 3 minute timeout
		while (true) {
			if (playersTableView.cells().firstWithPredicate("name BEGINSWITH 'Waiting'").checkIsValid() && timeout > 0) {
				log("Waiting for invites to be accepted for " + timeout + " more seconds...");
            
            if (! appIsRunning("com.apple.sample.gamekittester")){
               log("GameKitTester.app appears to no longer be running. (We are never going to see out invites be accepted!)");
               log("Frontmost Bundle ID: " + UIATarget.localTarget().frontMostApp().bundleID());
               throw("GameKitTester.app appears to no longer be running. (We are never going to see out invites be accepted!)");
            }
            timeout = timeout - 2; // only print out a message every 2 seconds
            delay(2);
            
			} else {
            if (timeout <= 0) {
               log("Timed out waiting for all invities to accept the game.");
               		//TODO: Log details re which devices failed to accept. 
                     mainWindow.tableViews()[0].logElementTree();

               throw("Timed out waiting for all invities to accept the game.");
            }
				break;
			}
		}
		
      log("Waiting for 'Play Now' button.");
      var timeout = 100 // 100 second timeout (for connecting period)
		while (true) {
			if ( (! mainWindow.navigationBar().buttons()["Play Now"].isEnabled()) && timeout > 0) {
				log("Waiting for 'Play Now' button to become enabled for " + timeout + " more seconds...");
            
            if (! appIsRunning("com.apple.sample.gamekittester")){
               log("GameKitTester.app appears to no longer be running. ('Play Now' button is never going to become enabled now!)");
               log("Frontmost Bundle ID: " + UIATarget.localTarget().frontMostApp().bundleID());
               throw("GameKitTester.app appears to no longer be running. ('Play Now' button is never going to become enabled now!)");
            }
            timeout = timeout - 2; // only print out a message every 2 seconds
            delay(2);
            
			} else {
            if (timeout <= 0) {
               log("Timed out waiting for 'Play Now' button to become enabled.");
               throw("Timed out waiting for 'Play Now' button to become enabled.");
            }
				break;
			}
		}

      
      log("'Play Now' button is enabled!");
      
		// Begin the game
      delay(3);
      log("Tapping 'Play Now' to begin the game!");
		mainWindow.navigationBar().buttons()["Play Now"].tap();
	}
	
   
	// Wait for the game to start
   if (invitee) {
      // 5 min timeout.
      var timeout = 300 // 300 second timeout (to wait for game sheet to appear)
      
   } else {
      //2:20 min:sec timeout. 
      var timeout = 140 // 140 second timeout (to wait for game sheet to appear)
   }
   
   log("Waiting for Game Sheet to appear! (The Leave Game button lets us know that the game sheet has appeared)");
   while (true) {
      if ( (! mainWindow.buttons()["Leave Game"].checkIsValid() ) && timeout > 0) {
         log("Waiting for 'Leave Game' button to become visible for " + timeout + " more seconds.");

         if (! appIsRunning("com.apple.sample.gamekittester")){
            log("GameKitTester.app appears to no longer be running. ('Leave Game' button is never going to show up now!)");
            log("Frontmost Bundle ID: " + UIATarget.localTarget().frontMostApp().bundleID());
            throw("GameKitTester.app appears to no longer be running. ('Leave Game' button is never going to show up now!)");
         }
         timeout = timeout - 2; // only print out a message every 2 seconds
         delay(2);

      } else {
         if (timeout <= 0) {
            log("Timed out waiting for 'Leave Game' button to become visible.");
            throw("Timed out waiting for 'Leave Game' button to become visible.");
         }
         break;
      }
   }
   
   log("The Game Sheet is visible.");
   delay(1); //to make sure the sheet has time to come on screen..

   
   log("Running the Game Script.");
	// Run the game script
	while (gameScript.length > 0) {
		var gameCommand = gameScript.shift();
		if (gameCommand.match(/^\d+$/)) {
			var commandDelayTime = parseInt(gameCommand);
			delay(commandDelayTime);
		} else {
         log("Tapping button '" + gameCommand + "'");
			mainWindow.buttons()[gameCommand].tap();
		}
	}
	
	// End the game and return to the main menu
   log("Game successfully completed.");
   log("Cleanly leaving the game via the 'Leave Game' button.");
	mainWindow.buttons()["Leave Game"].tap();

   //end the actual test failure boundary, any failures after here are automation failures only.
   gamePlayState = 'after';

	delay(5);
	returnToMainMenu();

}

function main() {
	UIATarget.onAlert = function onAlert(alert) {
		log("Attempting to handle alert:");
		//alert.logElementTree();
      
		UIATarget.localTarget().pushTimeout(2);
		
		// Wi-Fi Selection
		if (alert.staticTexts()["Select a Wi-Fi Network"].checkIsValid()) {
         
			log("Dismissing Wi-Fi selection alert.");
			alert.buttons()["Cancel"].tap();
			UIATarget.localTarget().popTimeout();
			return true;
		}
		
		// Invitation Alert
		else if (alert.buttons()["Accept"].checkIsValid()) {
         
			log("Accepting invite from invite alert.");
         log(alert.staticTexts()[0].name());
			log("Tapping Accept.");
			alert.buttons()["Accept"].tap();
			UIATarget.localTarget().popTimeout();
			return true;
		}
		
		// GK Login 1st Alert
		else if (alert.buttons()["Use Existing Account"].checkIsValid()) {
         
			log("GK Login 1st Alert: using existing account.");
			alert.buttons()["Use Existing Account"].tap();
			UIATarget.localTarget().popTimeout();
			return true;
		}
		
		// GK Login 2nd Alert
		else if (alert.staticTexts()["Apple ID Password"].checkIsValid()) {
         
			log("GK Login 2nd Alert: logging in with retrieved credentials.");
			alert.textFields()[0].setValue(playerAppleID);
			alert.secureTextFields()[0].setValue(playerPassword);
         	delay(3);
			alert.buttons()["OK"].tap();
			UIATarget.localTarget().popTimeout();
			return true;
		}
      
		log("Unknown alert encountered. Deferring to default handler.");
		for (var i in alert.staticTexts()){
         log('Alert Text: "' + alert.staticTexts()[i].name() + '"');
      }
      
		UIATarget.localTarget().popTimeout();
		return false;
	}
	
   
   //don't join wifi here, as this might disconnect us before we can fetch our basic settings.
   log("GameKitTesterAutomation.js started");

   log('Current SSID: ' + currentSSID());

      
   if (UIATarget.localTarget().frontMostApp().bundleID() != "com.apple.sample.gamekittester"){
      log("GameKitTester.app is not currently running. Attempting to launch GKTester.");
      launchApp("com.apple.sample.gamekittester");
   }

	returnToMainMenu();
	
	var mainWindow = UIATarget.localTarget().frontMostApp().mainWindow();
	var mainTableView = mainWindow.tableViews()[0];
	
	// Get the settings for this device and player account
	while ((playerAppleID == "" || playerAppleID == null ) || (playerPassword == "" || playerPassword == null )) {
      log("Fetching Basic Settings");
		mainTableView.scrollToElementWithName("Retrieve Basic Settings");
		mainTableView.cells()["Retrieve Basic Settings"].tap();
		delay(1);
				
      var retrieveButton = mainWindow.buttons()["Retrieve Basic Settings"];
      retrieveButton.tap();
      
      //wait for download to complete
      while (true){
         delay(1);
         var status = retrieveButton.name();
         log('Basic Settings download status: ' + status);
         if (status != 'Retrieving\u2026'){
            break;
         }
      
      }


		var basicTextFields = mainWindow.textFields();
		ssid = basicTextFields["ssid_tf"].value();
		wifiPassword = basicTextFields["wifiPassword_tf"].value();
		wifiType = basicTextFields["wifiType_tf"].value();

		playerAppleID = basicTextFields["playerAppleID_tf"].value();
		playerPassword = basicTextFields["playerPassword_tf"].value();
		
      
		returnToMainMenu();
	}

	//join wifi so that we auth over the correct wifi.
	joinWiFi();

   //leave WiFi if we are testing using the 3G SSID
   ifTesting3GLeaveWiFi();
   
	// Login player account
   logInDevice();

	
   log("Starting Run Loop");

	while (true) {
      try{
         try{
            if (typeof system == 'undefined') system.drain();
            syslog("--------START GAMEKIT AUTOMATION RUN--------"); //used to trim the syslog before uploading in logResult()
            appendMemoryUsage();
            getPersonaAndMakeMatch();
            log("Automation run successfully completed. Lets do it again!");
            syslog("---------END GAMEKIT AUTOMATION RUN---------");
            appendMemoryUsage();
            logResult('pass');
         } catch (e) {
            log('Current SSID: ' + currentSSID());
                        
            //Test to make sure the app is still running.If not we need to relaunch
            if (! appIsRunning("com.apple.sample.gamekittester")){
               e = "GameKitTester.app appears to no longer be running.";
               log("GameKitTester.app appears to no longer be running.");
               log("Frontmost Bundle ID: " + UIATarget.localTarget().frontMostApp().bundleID());
                              
               log("Attempting to relaunch GameKitTester.");
               launchApp("com.apple.sample.gamekittester");
               logInDevice();
               
               //lets try and refine the reason for the app no longer being running.
               var syslogs = getSyslog();

               var jRegExp = /^(.*jetsam:.*GameKitTester.*memory_status_level.*)$/m;
               if (syslogs.match(jRegExp)){ //jetsam  jetsam: killing pid 95 [GameKitTester] - memory_status_level: 4
                  e = "GameKitTester.app was killed. System jetsam.";
               }
               var cRegExp = /^(.*launchd.*gamekittester.*Job appears to have crashed.*)$/m;
               if (syslogs.match(cRegExp)) { //crash
                  e = "GameKitTester.app crashed.";
                  appendLatestCrashLog();
               }
            }
            
            if (gamePlayState == 'before'){
               //exception thrown before game has started, we can safely ignore this as an automation only failure.
               log("An exception was thrown before game play. Not a big deal, continuing.");
               log('Exception Text: ' + e );

            } else if (gamePlayState == 'during') {
               log("An exception was thrown during game play. Logging a fail result.");
               log('Exception Text: ' + e );
               log('Current SSID: ' + currentSSID());
               syslog("---------END GAMEKIT AUTOMATION RUN---------");
               appendMemoryUsage();
               logResult('fail');
            } else {
               //after or initial setup error.
               log("An exception was thrown after game play. Logging an issue result.");
               log('Exception Text: ' + e );
               log('Current SSID: ' + currentSSID());
               syslog("---------END GAMEKIT AUTOMATION RUN---------");
               appendMemoryUsage();
               logResult('issue');
            }
            
            //better to be safe than sorry, lets force a re-login, just in case our login timed out on the server side.
            logInDevice();
            
         }
      } catch (e){
         log("WARNING: AN EXCEPTION WAS THROWN INSIDE THE RUNLOOP CATCH BLOCK. THIS WOULD HAVE STOPPED THE AUTOMATION ON THIS DEVICE!!! ");
         log('Run Loop Exception Text: ' + e );
         //work around for UIAlerts getting wedged on screen. <rdar://problem/8257507>                  
         dismissAllAlerts();

      }
   }
}

main();
