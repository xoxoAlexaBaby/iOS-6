#!/usr/bin/perl
$success = 0;
for ($n = 0; ($n < 3) && !$success; $n++)
{
	system ("/bin/launchctl unload /System/Library/LaunchDaemons/com.apple.CommCenter.plist");
	system ("/usr/local/bin/bbctl powercycle");
	system ("/bin/sleep 9");
	system ("/usr/local/bin/bbctl reset");
	system ("/bin/sleep 9");
	system ("/usr/local/bin/bbctl radio on");
	system ("/bin/sleep 9");
	system ("/usr/local/bin/bbctl usb on");
	system ("/bin/sleep 9");
	system ("/usr/local/bin/bbusbctl on");
	system ("/bin/sleep 15");
	open (CT, "ls /usr/standalone/firmware/Maverick/Mav5-*.Release.bbfw |");
	while (<CT>)
	{
		s/[\r\n]//g;
		$filename = $_;
		printf ("$filename\n");
	}
	close (CT);
	$cmd = '/usr/local/bin/BBUpdaterSupreme uf -z ' . $filename . ' -a -w |';
	#Read the latest firmware name from the file
	open (PS, $cmd);
	open (FP, "> /var/logs/WiPASmini/WiPASmini.d.log");
	$oldh = select (FP);
	$| = 1;
	select ($oldh);
	$loadaborted = 0;
	while (<PS>)# && $loadaborted == 0)
	{
		$line = $_;
		printf ("#%s", $line);
		printf (FP "%s", $line);
	}
	close (PS);
	$success = 0;
	printf (FP "sleep 4...\n");
	system ("sleep 4");
	for ($m = 0; ($m < 20) && !$success; $m++)
	{
		open (PS, "/usr/local/bin/ETLTool ping|");
		while (<PS>)
		{
			$line = $_;
			printf ("#%s", $line);
			printf (FP "%s", $line);
			if ($line =~ /Software Version Strings/)
			{
				$success = 1;
				#system ("sleep 1");
			}
		}
		close (PS);
	}
	close (FP);
}