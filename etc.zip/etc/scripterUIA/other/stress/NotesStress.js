#import "UIAAppStressLibrary.js"

if (typeof notes != 'undefined') {
	notesStress = AppStressBase.stressTest('Notes');
	
	if (typeof notesStress != 'undefined') {
		
		notesStress.setup = function setup() {
			notesStress.addTest(notesStress._createNewNote);
			notesStress.addTest(notesStress._deleteNote);
			notesStress.addTest(notesStress._selectPreviousNote);
			notesStress.addTest(notesStress._copyNote);
			
			if (STRESS_MAIL_ACCOUNT && STRESS_MAIL_PASSWORD) {
				notesStress.addTest(notesStress._emailNote);
			}
		}
		
		notesStress.run = function run() {
			notesStress.executeRandomTests(3);
		}
		
		// create new note
		notesStress._createNewNote = function _createNewNote() {
			var body = getRandomMessage(1, 20, 1, 20);
			notesStress.executeTest('CreateNewNote', ['Stress Test', body], notesTest_createNote, "Create a new note.");
		}
		
		// create & delete a note
		notesStress._deleteNote = function _deleteNote() {
			var body = getRandomMessage(1, 20, 1, 20);
			notesStress.executeTest('CreateAndDeleteNote', ['Stress Test', body], notesTest_deleteNote, "Create and delete a note.");
		}
		
		// create several notes and select between them
		notesStress._selectPreviousNote = function _selectPreviousNote() {
			notesStress.executeTest('SelectPreviousNextNote', [], notesTest_selectPreviousNextNote, "Create several notes and select between them.");
		}
		
		// copy a note 
		notesStress._copyNote = function _copyNote() {
			var body = getRandomMessage(1, 20, 1, 20);
			notesStress.executeTest('CopyNote', ['Stress Test', body], notesTest_copyNote, "Copy a note.");
		}
		
		// email a note
		notesStress._emailNote = function _emailNote() {
			var body = getRandomMessage(1, 20, 1, 20);
			notesStress.executeTest( 'EmailNote', [ STRESS_MAIL_ACCOUNT, 'Stress Test', body ], 
									 notesTest_emailNote, "Email a note." );
		}
	}
}