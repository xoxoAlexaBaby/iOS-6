
//UIA logs global variable. (used by the log() and logResult() methods. )
var uiaLogs = "";


//Define basic settings here so they are global.
var ssid = "";
var wifiPassword = "";
var wifiType = "";
var playerAppleID = "";
var playerPassword = "";


//create a system object if available.
try {
   if (typeof system == 'undefined') system = new System();	
} catch (e) {
   UIALogger.logMessage("Couldn't create the system object. This is expected if you're running from the Instrument.");
   
}
   
//----------- SYSTEM FUNCTIONS -----------
   
function launchApp(bundleID) {
   if (typeof system != 'undefined') {
      log("Launching: " + bundleID);
      system.run("/usr/local/bin/LaunchApp " + bundleID, 5);
   
   } else {
      log("Failed to launch app: " + bundleID);
   }
}

function joinWiFi() {
   if (typeof system != 'undefined') {
      log("Attempting to join WiFi");
      
      //special case the Settings for our fake 3G mode in the lab. 
      if (ssid == "3G"){
         system.run("/usr/local/bin/wifitool -r 10 -s -j gktest3 -e wpa2 -p thunderdome", 5);
      } else if (ssid == "3G-spiderpigdeux"){
         system.run("/usr/local/bin/wifitool -r 10 -s -j spiderpigdeux -e wpa2 -p n45iscool", 5);
      } else {
         system.run("/usr/local/bin/wifitool -r 10 -s -j " + ssid + " -e " + wifiType + " -p " + wifiPassword, 5);
      }
      
      delay(4); // to let the connection happen.
      
   }
   
}

function leaveWiFi() {
   if (typeof system != 'undefined') {
      log("Attempting to leave WiFi");
      system.run("/usr/local/bin/wifitool -L", 5);
      delay(1); // to let the disconnect happen.
   }
}

function ifTesting3GLeaveWiFi() {
   //only leave WiFi if we are testing using the 3G SSID
   if (ssid == "3G" || ssid == "3G-spiderpigdeux") {
      leaveWiFi();
   }
}



function logInDevice() {

   returnToMainMenu();

   ifTesting3GLeaveWiFi();

	// Login player account
   log("logInDevice()");
   log("Logging in player account");

	var mainWindow = UIATarget.localTarget().frontMostApp().mainWindow();
	var mainTableView = mainWindow.tableViews()[0];

	mainTableView.scrollToElementWithName("Local Player APIs");
	mainTableView.cells()["Local Player APIs"].tap();
	delay(1);
	
	mainWindow.tableViews()[0].cells()["Authenticate"].tap();
	delay(2);
	
	//Login with username and password is handled via the alert handler, if necessary.
   
   joinWiFi();
   
   returnToMainMenu();
   
}


//----------- UTILITY FUNCTIONS -----------

function log(message) {
      UIALogger.logDebug(message);
      //append our latest message to the log global
      uiaLogs += (message + "\n");
}

function appendLatestCrashLog() {
   if (typeof system != 'undefined') {
      var result = system.run("/bin/cat /var/mobile/Library/Logs/CrashReporter/LatestCrash-GameKitTester.plist", 5);
      uiaLogs = "CRASHED:" + uiaLogs;
      uiaLogs += "----------------START CRASH LOG----------------\n";
      uiaLogs += result.stdout;
      uiaLogs += "\n-----------------END CRASH LOG-----------------\n";
   } else {
      log("appendLatestCrashLog() failed. Unable to get a system.run() instance.");
   }
}            

function delay(timeInterval) {
	UIATarget.localTarget().delay(timeInterval);
}


//----------- EXECUTION FLOW FUNCTIONS -----------

function logResult(result) {
   //we join the wifi here, so that we can log the results to the internal server.
   joinWiFi();

   delay(1);
   
   //logs either a pass or a fail result.
   returnToMainMenu();
	
	var mainWindow = UIATarget.localTarget().frontMostApp().mainWindow();
	var mainTableView = mainWindow.tableViews()[0];

	// Report results to server
	mainTableView.scrollToElementWithName("Log Results");
	mainTableView.cells()["Log Results"].tap();
	delay(2);
   
   //set the pass / fail result
   if (result == 'fail'){
      mainWindow.segmentedControls()[0].buttons()[0].tap();
	}else{ 
      mainWindow.segmentedControls()[0].buttons()[1].tap();
	}

// if we can, set the console to the current syslog.
   if (typeof system != 'undefined') {
      log("Adding the syslog to the result submission");
      var result = system.run("/usr/bin/syslog");
      mainWindow.textViews()["consoleLogs_tv"].setValue(result.stdout);
   }
   
   //set the uiaLogs field
   mainWindow.textViews()["uiaLogs_tv"].setValue(uiaLogs);
   uiaLogs = ""; //reset the logs store
   //TODO: this is dangerous (ie if we run logResult while not connected to wifi) We should make sure the result is submitted by looping a la basicSettings / persona etc

	mainWindow.buttons()["Log Results"].tap();
	delay(3);
	
	returnToMainMenu();
   ifTesting3GLeaveWiFi();
}



function returnToMainMenu() {
   log("returnToMainMenu");
	var app = UIATarget.localTarget().frontMostApp();
	for (var i = 0; i < 10; i++) {
		if (app.navigationBar().leftButton().checkIsValid()) {
			app.navigationBar().leftButton().tap();
			delay(1);
		} else {
			break;
		}
	}
}

function getPersonaAndMakeMatch() {
   log("getPersonaAndMakeMatch");

	var mainWindow = UIATarget.localTarget().frontMostApp().mainWindow();
	var mainTableView = mainWindow.tableViews()[0];
	
   returnToMainMenu();

	while (true) {
      log("Fetching Persona");

      //we join the wifi here, so that we can download the persona from the internal server.
      joinWiFi();

		mainTableView.scrollToElementWithName("Retrieve Persona");
		mainTableView.cells()["Retrieve Persona"].tap();
		delay(1);
		
		mainWindow.scrollViews()[0].buttons()["Retrieve Next Persona"].tap();
		delay(3);
		
		if (mainWindow.scrollViews()[0].textFields()["pleasehold_tf"].value() == "HOLDING" ||
          mainWindow.scrollViews()[0].textFields()["pleasehold_tf"].value() == "") {
			log("Persona has told us to to HOLD. (Or failed to download) Try again in 5 seconds");
			returnToMainMenu();
			delay(5); // retry every 5 seconds
		} else {
			break;
		}
	}
	
   //leave WiFi if we are testing using the 3G SSID
      ifTesting3GLeaveWiFi();
   
	var textFields = mainWindow.scrollViews()[0].textFields();
	
	var invitee = false;
	if (textFields["invitee_tf"].value() == "YES") {
		invitee = true;
	}
	var playerAliasesToInvite = textFields["playerids_tf"].value();
	playerAliasesToInvite = playerAliasesToInvite.split(" ");
	var totalPlayers = parseInt(textFields["totalplayers_tf"].value());
	var gameScript = textFields["gamescript_tf"].value();
	gameScript = gameScript.split(",");
	var minPlayers = parseInt(textFields["minplayers_tf"].value());
	
	log("Invitee: " + invitee);
	log("Player Aliases To Invite: " + playerAliasesToInvite);
	log("Total Players: " + totalPlayers);
	log("Game Script: " + gameScript);
	log("Min Players: " + minPlayers);
	
	if (invitee) {
      log("We are the Invitee! (We set the invite handler then sit back and wait!)");

		// Return to the main menu and set the invite handler
		returnToMainMenu();
      
      log("Set Invite Handler");
		mainTableView.scrollToElementWithName("Set Invite Handler");
		mainTableView.cells()["Set Invite Handler"].tap();
		delay(2);
	}
	
	// invitee == False
	else {
      log("We are the Inviter! (Lets invite some people!)");
      
      log("Tap Make Match");
      mainWindow.scrollViews()[0].buttons()["Make Match"].tap();
      
		delay(14); // give all the devices enough time to re-request their personas 
                 //(worst case scenario the inviter is the last to get its persona 
                 // and immediately tries to invite the 3 devices, before they are ready)
                 // (invitee takes  5s + 1s + 3s + 3s to re-request persona)
		
      if(mainTableView.cells().firstWithPredicate("name BEGINSWITH 'Waiting for authentication'").checkIsValid()){
         log("Player appears to not be authenticated. Attempting to log in now...");
         logInDevice();
         //now attempt to return back to this point (ie re-show the matchmaking view.)
         joinWiFi();
         returnToMainMenu();

         mainTableView.scrollToElementWithName("Retrieve Persona");
         mainTableView.cells()["Retrieve Persona"].tap();
         delay(1);
         
         mainWindow.scrollViews()[0].buttons()["Retrieve Next Persona"].tap();
         delay(3);
         ifTesting3GLeaveWiFi();
         delay(3);
         mainWindow.scrollViews()[0].buttons()["Make Match"].tap();
         delay(3);
         
         log("Log in proess complete.");

      }
      
		var playersTableView = mainWindow.tableViews()[0];
		var cell;
		
		// Add auto-matching players until there are totalPlayers players
		var currentPlayerSlots = minPlayers;
		while (currentPlayerSlots < totalPlayers) {
			cell = playersTableView.cells()["Remove Player"];
			cell.buttons()["Add Player"].tap();
			delay(2);
			currentPlayerSlots++;
		}
		
		// Invite the players to invite, until that array is empty
		log("Players to invite: " + playerAliasesToInvite.length);
		while (playerAliasesToInvite.length > 0) {
			var inviteeAlias = playerAliasesToInvite.shift();
			if (inviteeAlias.length == 0) {
				continue;
			}
			log("Sending invite to player: " + inviteeAlias);
			playersTableView.scrollToElementWithPredicate("name BEGINSWITH 'Auto-Match'");
			cell = playersTableView.cells().firstWithPredicate("name BEGINSWITH 'Auto-Match'");
			cell.buttons()["Invite Friend"].tap();
			delay(2);

         //we need to do use the search bar as the invite list as its lazy loaded.
         UIATarget.localTarget().frontMostApp().mainWindow().tableViews()[0].scrollUp();
         UIATarget.localTarget().frontMostApp().mainWindow().tableViews()[0].searchBars()[0].tap();
         UIATarget.localTarget().frontMostApp().mainWindow().tableViews()[0].searchBars()[0].setValue(inviteeAlias);
         
         if ( ! mainWindow.tableViews()[0].cells().firstWithPredicate("name CONTAINS '" + inviteeAlias + "'").checkIsValid()){
            log("We were unable to invite alias " + inviteeAlias + " because they are not a friend.");
            throw("We were unable to invite alias " + inviteeAlias + " because they are not a friend.");
         }
         
         delay(1);
			mainWindow.tableViews()[0].scrollToElementWithPredicate("name CONTAINS '" + inviteeAlias + "'");
			mainWindow.tableViews()[0].cells().firstWithPredicate("name CONTAINS '" + inviteeAlias + "'").tap();
			delay(2);
			mainWindow.navigationBar().buttons()["Next"].tap();
			delay(2);
			mainWindow.navigationBar().buttons()["Send"].tap();
			delay(2);
		}
		
		// Hold until all invites have been accepted
      var timeout = 60 // 2 minute timeout
		while (true) {
			if (playersTableView.cells().firstWithPredicate("name BEGINSWITH 'Waiting'").checkIsValid() && timeout-- > 0) {
				log("Waiting for invites to be accepted...");
				delay(2);
			} else {
            if (timeout <= 0) {
               log("Timed out waiting for all invities to accept the game.");
               throw("Timed out waiting for all invities to accept the game.");
            }
				break;
			}
		}
		
      var timeout = 100 // 100 second timeout (for connecting period)
		while (true) {
			if ( (! mainWindow.navigationBar().buttons()["Play Now"].isEnabled()) && timeout-- > 0) {
				log("Waiting for 'Play Now' button to become enabled...");
				delay(1);
			} else {
            if (timeout <= 0) {
               log("Timed out waiting for 'Play Now' button to become enabled.");
               throw("Timed out waiting for 'Play Now' button to become enabled.");
            }
				break;
			}
		}

      
		// Begin the game
      delay(3);
      log("Tapping 'Play Now' to begin the game!");
		mainWindow.navigationBar().buttons()["Play Now"].tap();
	}
	
	// Wait for the game to start
   if (invitee) {
      UIATarget.localTarget().pushTimeout(300); // 5 min timeout. (try and keep the timeout comparable to the inviter side (2m + 40s + 15s + (10s * devices to invite)))
	} else {
      UIATarget.localTarget().pushTimeout(140); //2:20 min:sec timeout. (try and keep the timeout comparable to the inviter side (2m + 100s + 15s + (10s * devices to invite)))
   }
   log("Waiting for 'Leave Game' button to become visible. (This lets us know that the game sheet has appeared!)");
   mainWindow.buttons()["Leave Game"];
	delay(2);
	UIATarget.localTarget().popTimeout();
	   
   log("Running the Game Script.");
	// Run the game script
	while (gameScript.length > 0) {
		var gameCommand = gameScript.shift();
		if (gameCommand.match(/^\d+$/)) {
			var commandDelayTime = parseInt(gameCommand);
			delay(commandDelayTime);
		} else {
			mainWindow.buttons()[gameCommand].tap();
		}
	}
	
	// End the game and return to the main menu
   UIALogger.logDebug("Game successfully completed. Cleanly leaving the game via the 'Leave Game' button.");
	mainWindow.buttons()["Leave Game"].tap();
	delay(5);
	returnToMainMenu();
}

function main() {
	UIATarget.onAlert = function onAlert(alert) {
		log("Attempting to handle alert:");
		//alert.logElementTree();
		
		UIATarget.localTarget().pushTimeout(0.5);
		
		// Wi-Fi Selection
		if (alert.staticTexts()["Select a Wi-Fi Network"].checkIsValid()) {
			log("Dismissing Wi-Fi selection alert.");
			alert.buttons()["Cancel"].tap();
			UIATarget.localTarget().popTimeout();
			return true;
		}
		
		// Invitation Alert
		else if (alert.buttons()["Accept"].checkIsValid()) {
			UIALogger.logDebug("Accepting invite from invite alert.");
			alert.buttons()["Accept"].tap();
			UIATarget.localTarget().popTimeout();
			return true;
		}
		
		// GK Login 1st Alert
		else if (alert.buttons()["Use Existing Account"].checkIsValid()) {
			log("GK Login 1st Alert: using existing account.");
			alert.buttons()["Use Existing Account"].tap();
			UIATarget.localTarget().popTimeout();
			return true;
		}
		
		// GK Login 2nd Alert
		else if (alert.staticTexts()["Apple ID Password"].checkIsValid()) {
			log("GK Login 2nd Alert: logging in with retrieved credentials.");
			alert.textFields()[0].setValue(playerAppleID);
			alert.secureTextFields()[0].setValue(playerPassword);
         	delay(3);
			alert.buttons()["OK"].tap();
			UIATarget.localTarget().popTimeout();
			return true;
		}
		
		log("Unknown alert encountered. Deferring to default handler.");
		
		UIATarget.localTarget().popTimeout();
		return false;
	}
	
   //don't join wifi here, as this might disconnect us before we can fetch our basic settings.
   log("GameKitTesterAutomation.js started");

   
   if (UIATarget.localTarget().frontMostApp().bundleID() != "com.apple.sample.gamekittester"){
      log("GameKitTester.app is not currently running. Attempting to launch GKTester.");
      launchApp("com.apple.sample.gamekittester");
   }

	returnToMainMenu();
	
	var mainWindow = UIATarget.localTarget().frontMostApp().mainWindow();
	var mainTableView = mainWindow.tableViews()[0];
	
	// Get the settings for this device and player account
	while (playerAppleID == "" || playerPassword == "") {
      log("Fetching Basic Settings");
		mainTableView.scrollToElementWithName("Retrieve Basic Settings");
		mainTableView.cells()["Retrieve Basic Settings"].tap();
		delay(1);
		
		mainWindow.buttons()["Retrieve Basic Settings"].tap();
		delay(6);
		
		var basicTextFields = mainWindow.textFields();
		ssid = basicTextFields["ssid_tf"].value();
		wifiPassword = basicTextFields["wifiPassword_tf"].value();
		wifiType = basicTextFields["wifiType_tf"].value();

		playerAppleID = basicTextFields["playerAppleID_tf"].value();
		playerPassword = basicTextFields["playerPassword_tf"].value();
		
      
		returnToMainMenu();
	}

	//join wifi so that we auth over the correct wifi.
	joinWiFi();

   //leave WiFi if we are testing using the 3G SSID
   ifTesting3GLeaveWiFi();
   
	// Login player account
   logInDevice();

	
   log("Starting Run Loop");

	while (true) {
      try{
         getPersonaAndMakeMatch();
         log("Automation run successfully completed. Lets do it again!");
         logResult('pass');
      } catch (e) {
         //Test to make sure the app is still running.If not we need to relaunch
         if (UIATarget.localTarget().frontMostApp().bundleID() != "com.apple.sample.gamekittester"){
            log("GameKitTester.app appears to no longer be running. Attempting to relaunch GKTester.");
            launchApp("com.apple.sample.gamekittester");
            
            //append the latestCrashLog to the uiaLogs variable.
            appendLatestCrashLog();
            logInDevice();

         }
         
         log("An exception was thrown in getPersonaAndMakeMatch(). Logging a fail result.");
         logResult('fail');
         
         //better to be safe than sorry, lets force a re-login, just in case our login timed out on the server side.
         logInDevice();

      }
	}
}

main();
