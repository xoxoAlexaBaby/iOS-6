#import "Weather.js"
#import "../safari/Safari.js"
#import "../libs/PHTesting.js"

//----------------------------------------------------------------------------------------
//	Function: weatherTest_slideToCity 
//		Slides weather right to a named city
//
//	Parameters: 
//		cityName (string) - name of the city to slide to.
//
//	Returns: 
//		1 if the city was found sliding to the right, 0 if not.
//----------------------------------------------------------------------------------------
function weatherTest_slideToCity() {
		
	weather.launchIfNotActive();
	try {
		weather.getToFrontsideView();
	} catch (e) {
		UIALogger.logError(e.message);
		this.testError = "Could not return to frontside card view.";
		return this.testResult = 0;
	}
	
	var cityName;
	if (this.argv.length > 0) {
		cityName = this.argv[0];
	} else {
		cityName = "New York";
	}
	
	UIALogger.logMessage("Sliding to " + cityName +".");

	try {
		weather.getToCardWithCityName(cityName);
	} catch (e) {
        weather.logElementTree();
		UIALogger.logError(e.message);
		this.testError = "Could not find " + cityName + " in the list of cards";
		return this.testResult = 0;
	}
	
	UIALogger.logMessage("Found " + cityName);
	return this.testResult = 1;

}

//----------------------------------------------------------------------------------------
//	Function: weatherTest_deleteCity 
//		Remove a city from the Weather Widget
//
//	Parameters: 
//		cityName (string) - Name of the city that you want delete
//
//	Returns: 
//		1 if city was successfully removed; 0 otherwise
//----------------------------------------------------------------------------------------
function weatherTest_deleteCity(){
	var cityName;

	if (this.argv.length < 1) {
		UIALogger.logError("The city to remove was not specified.");
		return 64;		
	} else {
		cityName = this.argv[0];
	}
		
	weather.launchIfNotActive();
	try {
		weather.getToFrontsideView();
	} catch (e) {
        weather.logElementTree();        
		UIALogger.logError(e.message);
		this.testError = "Could not return to frontside card view.";
		return this.testResult = 0;
	}
	
	try {
		weather.addItem(cityName);
	} catch (e) {
        weather.logElementTree();
		UIALogger.logError(e.message);
		this.testError = "Unable to add city";
		return this.testResult = 0;
	}
	
	
	try {
		weather.deleteItem(cityName);
	} catch (e) {
        weather.logElementTree();        
		UIALogger.logError(e.message);
		this.testError = "Unable to delete city";
		return this.testResult = 0;
	}
	
	
	return this.testResult = 1;
}

//----------------------------------------------------------------------------------------
//	Function: weatherTest_addCity
//		Add a city to the Weather Widget
//
//	Parameters: 
//		cityName (string) - Name of the city and state that you want added, e.g., Denver, CO or Atlanta, GA
//
//	Returns: 
//		1 if city was successfully added; 0 otherwise
//----------------------------------------------------------------------------------------
function weatherTest_addCity() {
	var cityName;

	if (this.argv.length < 1) {
		var cityData = randomCityData();
		cityName = city.name;
	} else {
		//separate the city from the state
		fullName = this.argv[0];
		cityName = fullName.split( /,/ )[0];
		
	}
	
	weather.launchIfNotActive();
	try {
		weather.getToFrontsideView();
	} catch (e) {
        weather.logElementTree();        
		UIALogger.logError(e.message);
		this.testError = "Could not return to frontside card view.";
		return this.testResult = 0;
	}
	
	// check for city and remove it first if its there
	UIALogger.logMessage( "Checking for existing city: " + cityName );
	
	try {
		weather.deleteItem(cityName);
	} catch(e) {
		UIALogger.logMessage("City does not exist: " + cityName );
	}
	
	try {
		weather.addItem(fullName);
	} catch (e) {
        weather.logElementTree();        
		UIALogger.logError(e.message);
		this.testError = "Unable to add city '" + cityName + "'";
        if (e.message) this.testError += ": " + e.message;
		return this.testResult = 0;
	}
	
	UIATarget.localTarget().delay(3);
	try {
		weather.itemInBacksideList(cityName);
	} catch (e) {
        weather.logElementTree();        
		UIALogger.logError(e.message);
		this.testError = "Unable to verifiy the city '" + cityName + "' in backside view.";
		return this.testResult = 0;
	}
	
	return this.testResult = 1;
}

//----------------------------------------------------------------------------------------
//	Function: weatherTest_goToYahooPage 
//		Go to Yahoo Page
//
//	Parameters: 
//		None
//
//	Returns: 
//		1 if success; 0 if not
//----------------------------------------------------------------------------------------
function weatherTest_goToYahooPage()
{	
	weather.launchIfNotActive();
	try {
		weather.getToFrontsideView();
	} catch (e) {
		UIALogger.logError(e.message);
		this.testError = "Could not return to frontside card view.";
		return this.testResult = 0;
	}
	
	try {
		weather.getToYahooWebPage();
	 } catch (e) {
		UIALogger.logError(e.message);
		this.testError = "Unable to locate Y! Button";
		return this.testResult = 0;
	}
		
	UIATarget.localTarget().delay(10);  // safari may think its active, but its not ready to listen to scripter yet
	if(!safari.isActive()) {
		this.testError = "Safari is not the active application after clicking the Y! button.";
		return this.testResult = 0;
	} 

	UIALogger.logMessage(arguments.callee.name + ": Safari is active.");
	UIATarget.localTarget().delay(2);	

	
	try {
		safari.waitForPageToLoad(240);
		var alert = UIATarget.localTarget().frontMostApp().alert();
		UIALogger.logMessage(alert.logElementTree());

	} catch (e) {
		UIALogger.logError(e.message);
		this.testError = "Timed out or problem occurred while waiting for Yahoo Weather page to load.";
		return this.testResult = 0;
	}	
	
	currentURL = safari.activeURL();
	if(!currentURL.match(/^http:\/\/m.yahoo.com\/.*/)) {
		this.testError = "Not the expected URL; URL found: "+ currentURL;
		return this.testResult = 0;
	}
	
	return this.testResult = 1;
}

// Create self tests -- this is an unnamed function, just to make sure any local variables stay in the correct context
(function() {	
	if ((typeof weather != 'undefined') && springboard.displaysApp(weather)) {
		
		if (typeof weather.selfTests == 'undefined') {
			weather.selfTests = new Array();
		}

		weather.selfTests.push(phtCreateTest("SlideWeatherToCity", null, weatherTest_slideToCity, "Slide Weather"));
		weather.selfTests.push(phtCreateTest("AddCityWeather", ["Denver, CO"], weatherTest_addCity, "Add City"));
		weather.selfTests.push(phtCreateTest("DeleteCityWeather", ["Denver"], weatherTest_deleteCity, "Remove City"));
		weather.selfTests.push(phtCreateTest("GoToYahooWeatherPage", null, weatherTest_goToYahooPage, "Go to Yahoo Page"));
	}
}())