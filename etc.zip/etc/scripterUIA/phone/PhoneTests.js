#import "./Phone.js"
#import "../facetime/FaceTime.js"
#import "../libs/PHTesting.js"

//----------------------------------------------------------------------------------------
//	Function: phoneTest_makeCall 
//		Makes a call to given phone number.
//
//	Parameters: 
//		phoneNumber (string) - phone number to call
//		shouldWaitForAnswer (boolean) - Wait until Active if true.  Wait until Sending if false. default: true
// 
//	Returns:
//		1 if test passes, 0 or 64 if test fails.
//----------------------------------------------------------------------------------------
function phoneTest_makeCall() {
	
	if (this.argv.length > 0) { 
		var phoneNumber = this.argv[0];
		var callStatusToVerify = ((this.argv.length > 1) && (!parseInt(this.argv[1]) || this.argv[1] == 'false')) ? "Sending" : "Active";
	} else {
		UIALogger.logError("No phone number specified.");
		return 64;		
	}
	
	phone.getToContactsList();
	
    UIALogger.logMessage("Calling " + phoneNumber);
	try {
		phone.makeCall([phoneNumber], {shouldReset:false, desiredCallStatus:callStatusToVerify});
	} catch(e) {
		this.testError = e.message;
		UIALogger.logError(this.testError);
		UIALogger.logMessage("Now resetting...");
		phone.getToKeypadView();
		return this.testResult = 0;
	}
	
	return this.testResult = 1;	
}


//----------------------------------------------------------------------------------------
//	Function: phoneTest_addCall 
//		If already on a call, use this function to make another call.
//
//	Parameters: 
//		phoneNumber (string) - phone number to call
// 
//	Returns:
//		1 if test passes, 0 or 64 if test fails.
//----------------------------------------------------------------------------------------
function phoneTest_addCall() {
	
	phone.launchIfNotActive();
	
	if (this.argv.length > 0) { 
		var phoneNumber = this.argv[0];
	} else {
		UIALogger.logError("No phone number specified.");
		return 64;
	}	
	
	UIALogger.logMessage("Adding call...");
	phone.makeCall([phoneNumber], {shouldReset:false, shouldMerge:false});

	UIALogger.logMessage("Successfully added the call to " + phoneNumber);
	return this.testResult = 1;
}


//----------------------------------------------------------------------------------------
//	Function: phoneTest_mergeCalls 
//		Merges calls and checks each entered phone number to make sure 
//		that the call is active on that particular phone number.
//
//	Optional Parameters: 
//		optional - as many telephone numbers as desired.
// 
//	Returns:
//		1 if test passes, 0 if test fails.
//----------------------------------------------------------------------------------------
function phoneTest_mergeCalls() {
	
	phone.launchIfNotActive();
	
	startingCallCount = telephony.getCallCount();
	if (startingCallCount < 2) {
		this.testError = "There were not two calls to merge."
		UIALogger.logError(this.testError);
		return this.testResult = 0;
	}
	
	phone.mainWindow().buttons()["merge calls"].tap();
	UIATarget.localTarget().delay(3); //TODO: do we need this?
	
	// make sure we have not dropped a call and we have a Multi-Party line that is active
	if ((startingCallCount == telephony.getCallCount()) && (telephony.callExists(null, "Multi-Party") == true)) {
		for (var i=0; i<this.argv.length; i++) {
			// If phone numbers are entered as parameters, check to make sure they are listed as "Active."
			if (telephony.callExists(this.argv[i], "Active") != true) {
				this.testError = "Call to '" + this.argv[i] + "' is not Active."
				return;
			}
			UIALogger.logMessage("Call to '" + this.argv[i] + "' is Active.")
		}
		UIALogger.logMessage("Calls merged.");	
		return this.testResult = 1;
	} 
}

//----------------------------------------------------------------------------------------
//	Function: phoneTest_endCall
//		Ends a call from the specified number
//
//	Parameters: 
//		[phoneNumber (string)] - phone number of incoming call. If no number is specified, 
//          then all calls are ended.
// 
//	Returns:
//		1 if test passes, 0 or 64 if test fails.
//----------------------------------------------------------------------------------------
function phoneTest_endCall() {
	var phoneNumber = (this.argv.length > 0) ? this.argv[0] : null;
	phone.launchIfNotActive();
	
	if (telephony.callExists(phoneNumber, "Active", 5) == false) {
		if (telephony.callExists(phoneNumber, "Held", 5)) {
			UIALogger.logMessage("Call to end is currently on hold.");
			phone.mainWindow().buttons().firstWithPredicate("name == 'hold' or name == 'swap'").tap();
			if (telephony.callExists(phoneNumber, "Active", 5) == false) {
				this.testError = "Call to end was on hold and we failed to take it off hold.";
				return this.testResult = 0;	
			}
		} else {
			this.testError = "No call to end.";
			return this.testResult = 0;
		}
	}
	
    var noOfCalls = 1;
    if (phoneNumber == null) {
        UIALogger.logDebug("Need to end all the calls");
        var noOfCalls = telephony.getCallCount(); 
        UIALogger.logDebug(noOfCalls + " are active");
    } 
	
    for (var i=0; i<noOfCalls; i++) { 
        var endButton = phone.mainWindow().buttons()["End"];
        if (endButton.isValid()) {
            UIALogger.logMessage("Selecting button 'End'.");
            endButton.tap();
            //endButton.waitForInvalid();
        }
        //need to minimize delay here... otherwise we will not pick the disconnected status
        UIALogger.logMessage("Waiting for call to end.");
        if (telephony.callExists(phoneNumber, "Disconnected", 5) == false) {
            UIALogger.logError("Call has not been disconnected.");
            return this.testResult = 0;		
        }
        UIATarget.localTarget().delay(3);
        if (telephony.getCallCount() == 0) break; //need this because the merged calls still count as seperate calls
    }
    
	if (telephony.callExists(phoneNumber, "Active") == true) {
		phone.getToKeypadView();
		this.testError = "Call still active.";
		UIALogger.logError(this.testError);
		return this.testResult = 0;
	} else {
		UIALogger.logMessage("Call not active.");	
		return this.testResult = 1;
	}	
}

//----------------------------------------------------------------------------------------
//	Function: phoneTest_makeVideoCall
//		Makes a video call to given phone number.
//
//	Parameters: 
//		phoneNumber (string) - phone number to call
//		logFailureData (boolean) - Takes screenshots of failure if true, nothing if false. Defaults to false.
//		time (number) - optional - if a time value is specified, the test will wait for the 
//			specified number of seconds, and then verify that the call still exists at the 
//			end of the specified time period. If no value is specified, the test does 
//			not wait. 
// 
//	Returns:
//		1 if test passes, 0 or 64 if test fails.
//----------------------------------------------------------------------------------------
function phoneTest_makeVideoCall() {
	
	if (this.argv.length > 0) { 
		var phoneNumber = this.argv[0];
	} else {
		UIALogger.logError("No phone number specified.");
		return 64;		
	}
	
	var logFailureData;
	if (this.argv.length > 1) {
		logFailureData = (this.argv[1] == true || this.argv[1] == "true");
	} else {
		logFailureData = false;
	}
	
	var time; 
	if (this.argv.length > 2 && !isNaN(parseInt(this.argv[2]))) time = parseInt(this.argv[2]);
	
	phone.getToKeypadView();
	
	try {
		UIALogger.logDebug("Calling " + phoneNumber);
		phone.makeCall([phoneNumber], {shouldReset:false, desiredCallStatus:"Active"});
	} catch(e) {
		this.testError = e.message;
		UIALogger.logError(this.testError);
		UIALogger.logDebug("Now resetting...");
		phone.getToKeypadView();
		return this.testResult = 0;
	}
	
	var videoButton = phone.mainWindow().buttons().firstWithPredicate("name == 'FaceTime' and isEnabled == 1");
	if(!videoButton.isValid()) {
		this.testError = "video button not present"; 
		return this.testResult = 0;
	}
	var alertDate = new Date(); //date object for alert checking purposes
	videoButton.tap();
	
	//Connect and check for call presence
	var connected = false;
	try {
		if (phone.waitForVideo()) connected = true;
	} catch(e) {
		UIALogger.logError(e.message);
	}
	
	if (connected) {
		if (time != null) {
			UIALogger.logDebug("Will wait for " + time + " seconds now...");
			UIATarget.localTarget().delay(time);
			UIALogger.logDebug("Checking if the call is still active now");
			if (phone.isFaceTimeCallActive()) {
				return this.testResult = 1;
			}
		} else
			return this.testResult = 1;
	}
	
	var failureData = phone.getVideoCallFailureData({takeScreenshot:logFailureData, alertDate:alertDate});
	this.testError = failureData.failureText;
	return this.testResult = 0;
	
}

//----------------------------------------------------------------------------------------
//	Function: phoneTest_changeButtonStateDuringCall
//		Pushes the button specified.
//
//	Parameters: 
//		theButton (string) - button to push
// 
//	Returns:
//		1 if test passes, 0 if test fails.
//
//	Notes:
//		test assumes a call is happening.
//----------------------------------------------------------------------------------------
function phoneTest_changeButtonStateDuringCall() {	
	
	phone.launchIfNotActive();
	
	if (this.argv.length != 1) {
		this.testError = "Usage: <Button Name>";
		return this.testResult = 0;
	}
	
	var theButton = this.argv[0];
	
	phone.getToCallPage();
	phone.mainWindow().buttons()[theButton].tap();
	
	return this.testResult = 1;
}

//----------------------------------------------------------------------------------------
//	Function: phoneTest_holdCall 
//		Holds an already active phone call.
//
//	Parameters:
//		[phoneNumber (string)] - phone number of incoming call
// 
//	Returns:
//		1 if test passes, 0 if test fails.
//----------------------------------------------------------------------------------------
function phoneTest_holdCall() {
	var phoneNumber = (this.argv.length > 0) ? this.argv[0] : null;
	phone.launchIfNotActive();
	if (telephony.callExists(phoneNumber, "Active", 30) == false) {		
		this.testError = "There was no active call to hold.";
		this.testResult = 0;		
	}
	
	var holdButton = phone.mainWindow().buttons()["hold"];
	if (holdButton.isValid())
		phone.mainWindow().buttons()["hold"].tap();
	else {
		UIALogger.logDebug("No hold button -- tapping and holding 'Add' button instead");
		phone.mainWindow().buttons()["mute"].touchAndHold(3);
	}
	
	UIALogger.logMessage("Waiting for held call.");
	if (telephony.callExists(phoneNumber, "Held", 30) == true) {
		UIALogger.logMessage("Call is on hold.");
		this.testResult = 1;
	} else {
		this.testError = "Timed out waiting for held call.";
		this.testResult = 0;		
	}
	
	return this.testResult;
}


//----------------------------------------------------------------------------------------
//	Function: phoneTest_unholdCall
//		Unholds a call that is on hold.
//
//	Parameters:
//		[phoneNumber (string)] - phone number of incoming call
// 
//	Returns:
//		1 if test passes, 0 if test fails.
//----------------------------------------------------------------------------------------
function phoneTest_unholdCall() {
	phone.launchIfNotActive();
	
	var phoneNumber = (this.argv.length > 0) ? this.argv[0] : null;
	
	if (telephony.callExists(phoneNumber, "Held", 30) == false) {		
		this.testError = "There was no held call to resume.";
		this.testResult = 0;		
	}
	
	phone.mainWindow().buttons()["hold"].tap();
	
	UIALogger.logMessage("Waiting for held call.");
	if (telephony.callExists(phoneNumber, "Active", 30) == true) {
		UIALogger.logMessage("Call is active.");
		this.testResult = 1;
	} else {
		this.testError = "Timed out waiting for active call.";
		this.testResult = 0;		
	}
	
	return this.testResult;
}

//----------------------------------------------------------------------------------------
//	Function: phoneTest_makeCallFromRecents 
//		Makes a call to the given recent call.
//
//	Parameters: 
//		recentCall (string) - Name of the person or number to call
// 
//	Returns:
//		1 if test passes, 0 or 64 if test fails.
//----------------------------------------------------------------------------------------
function phoneTest_makeCallFromRecents() {
	if (this.argv.length > 0) { 
		var recentCall = this.argv[0];
	} else {
		this.logError(arguments.callee.name + ": No phone number specified.");
		return 64;		
	}
	
	phone.makeCallToRecent(new UIAPredicateString("name contains '" + recentCall + "'"));
	
	UIALogger.logMessage("Initiated call to " + recentCall + ".");
	if (telephony.callExists(null, "Active", 30) == true) {
		UIALogger.logMessage("Call has been made.");
		this.testResult = 1;
	} else {
		phone.getToKeypadView();
		this.testError = "Call was not made.";
		this.testResult = 0;		
	}
	
	return this.testResult;	
}

//----------------------------------------------------------------------------------------
//	Function: phoneTest_makeCallToContact
//		Makes a call to the given contact.
//
//	Parameters: 
//		contactName (string) - Name of the person to call
//		numberType (string) - Type of the number (mobile/home/work...etc) default: mobile
// 
//	Returns:
//		1 if test passes, 0 or 64 if test fails.
//----------------------------------------------------------------------------------------
function phoneTest_makeCallToContact() {
	
	var numberType = "mobile";
	
	if (this.argv.length > 0) { 
		var contactName = this.argv[0];
	} else {
		UIALogger.logError("No phone number specified.");
		return 64;		
	}
	
	if (this.argv.length > 1) { 
		numberType = this.argv[1];
	} 
	
	phone.getToContactsList();
	var contactElement = phone.searchForContact(contactName);
	if (!contactElement.isValid()) {
		this.testError = "Contact '" + contactName + "' not found";
		UIALogger.logError(this.testError);
		return this.testResult = 0;
	}
	
	contactElement.tap();
	if (!phone.navigationBar().withName("Info").isValid()) 
		UIALogger.logWarning("Tapped the contact, but the 'Info' nav bar did not show up");
	
	// 'numberType' may also match an email address, but currently phone numbers are listed first.  Since
	//  we're starting at the top and scrolling down, this shouldn't be a problem...
	var phoneNumberElement = phone.mainWindow().tableViews()[0].scrollToElementWithName(numberType);
	if (!phoneNumberElement.isValid()) {
		this.testError = "Number type " + numberType + " not found.";
		UIALogger.logError(this.testError);
		return this.testResult = 0;
	}
	var phoneNumber = phoneNumberElement.value();
	UIALogger.logMessage("Phone number is " + phoneNumber);
	phoneNumberElement.tap();
	
	phoneNumber = phone.returnCleanedNumber(phoneNumber);
	UIALogger.logMessage("Initiated call to '" + phoneNumber + "'.");
	
	if (telephony.callExists(phoneNumber, "Active", 30) == true) {
		UIALogger.logMessage("Call has been answered.");
		this.testResult = 1;
	} else {
		phone.getToKeypadView();
		this.testError = "Timed out waiting for answer.";
		this.testResult = 0;		
	}
	
	return this.testResult;
}

//----------------------------------------------------------------------------------------
//	Function: phoneTest_addContactToFavorites 
//		Adds a contact from the contact list to the favorites list
//
//	Parameters: 
//		contactName (string) - the name of the contact to add
//		phoneNumber (string) - which of the contacts phone numbers to add (optional - only use
//			if more than one phone number exists for that contact)
//		favoriteType (string) - optional - "Voice" or "FaceTime". If an action sheet comes 
//			up to choose betweent the two, the specified option will be chosen. Note that 
//			this parameter is used only if the action sheet to choose between "Voice" or 
//			"FaceTime" comes up. 
// 
//	Returns:
//		1 if test passes, 0 if test fails.
//----------------------------------------------------------------------------------------
function phoneTest_addContactToFavorites() {
	
	if (this.argv.length > 0) { 
		var contactName = this.argv[0];
	} else {
		UIALogger.logError("No contact specified.");
		return 64;		
	}
	
	if (this.argv.length > 1) { 
		var phoneNumber = this.argv[1];
	} 
	
	var favoriteType = "Voice Call";
	if (this.argv.length > 2) {
		if (this.argv[2].toLowerCase() == 'facetime') favoriteType = "FaceTime";
	}

	phone.getToContactsList();	
	phone.addFavoriteUsingAddButton(contactName, {favoriteType:favoriteType, phoneNumber:phoneNumber});
	
	// go to favorites and verify that contact was added.
	phone.getToContactsList();
	phone.getToView("Favorites");

	var favoriteElement = phone.mainWindow().tableViews()[0].cells().firstWithPredicate("name contains '" + contactName + "'");
	if (!favoriteElement.isValid()) {
		this.testError = "Contact " + contactName + " not found";
		UIALogger.logError(this.testError);
		return this.testResult = 0;
	}
	
	return this.testResult = 1;
}

//----------------------------------------------------------------------------------------
//	Function: phoneTest_removeContactFromFavorites
//		Removes the contact from the favorites list
//
//	Parameters: 
//		contactName (string) - the name of the contact to add
// 
//	Returns:
//		1 if test passes, 0 if test fails.
//----------------------------------------------------------------------------------------
function phoneTest_removeContactFromFavorites() {
	
	if (this.argv.length > 0) { 
		var contactName = this.argv[0];
	} else {
		UIALogger.logMessage("No contact specified.");
		return 64;		
	}
    
	phone.getToView("Favorites");
	var contactCells = phone.mainWindow().tableViews()[0].cells().withPredicate("name contains '" + contactName + "'");
	UIALogger.logMessage("Found " + contactCells.length + " instance of the favorite '" + contactName + "'.");
	phone.removeContactFromFavorites(contactName);
	
	var updatedContactCells = phone.mainWindow().tableViews()[0].cells().withPredicate("name contains '" + contactName + "'");
	UIALogger.logMessage("Found " + updatedContactCells.length + " instance of the favorite '" + contactName + "' after deleting.");
	if (updatedContactCells.length != contactCells.length-1) {
		this.testError = "Could not verify the favorite was deleted";
		UIALogger.logError(this.testError);
		return this.testResult = 0;
	}
	
	return this.testResult = 1;
}

//----------------------------------------------------------------------------------------
//	Function: phoneTest_makeCallInAirplaneMode
//		Makes a call while in Airplane Mode
//
//	Parameters: 
//		phone number (string) - phone number to dial to
//		output(string) -   compare against the expected output
// 
//	Returns:
//		1 if test passes, 0 or 64 if test fails.
//----------------------------------------------------------------------------------------
function phoneTest_makeCallInAirplaneMode() {
	
	if (this.argv.length > 0) { 
		var phoneNumber = this.argv[0];
	} else {
		UIALogger.logError("No phone number specified.");
		return 64;		
	}
	
	var output = (this.argv.length > 1) ? this.argv[1] : "You must disable airplane mode to place a call";
	phone.getToKeypadView();
	phone.dialNumber(phoneNumber);
	
	var date = new Date();
	phone.mainWindow().buttons()["Call"].tap();
	UIATarget.localTarget().delay(1);
	
	var alert = phone.alertSinceDate(date);
	if (!alert) {
		this.testError = "Disable airplane mode alert did not come up";
		UIALogger.logError(this.testError);
		return this.testResult = 0;
	}
	
	if (alert.alertMessageArray[0].indexOf(output) < 0) {
		this.testError = "Expected alert did not show up";
		UIALogger.logError(this.testError);
		return this.testResult = 0;
	}
	return this.testResult = 1;
}

//----------------------------------------------------------------------------------------
//	Function: phoneTest_playVoicemail 
//		Selects a voicemail from the specified caller and plays it.
//
//	Parameters: 
//		caller (string) - person from which the voicemail originated.
// 
//	Returns:
//		1 if test passes, 0 or 64 if test fails.
//
//	Notes:
//		test assumes that the voicemail exists and visual voicemail is available on this phone
//----------------------------------------------------------------------------------------
function phoneTest_playVoicemail() {
	
	if (this.argv.length > 0) { 
		var caller = this.argv[0];
	} else {
		this.testError = "No caller specified.";
		UIALogger.logError(this.testError);
		return 64;		
	}

	phone.getToKeypadView();
	
	UIALogger.logDebug("Selecting button 'Voicemail'.");
	phone.tabBar().buttons().firstWithPredicate("name contains 'Voicemail'").tap();
	
	if (!phone.navigationBar().withPredicate("name contains 'Voicemail'").isValid()) {
		this.testError = "Tapped the 'Voicemail' button but the nav bar title did not change to Voicemail";
		UIALogger.logError(this.testError);
		return this.testResult = 0;
	}
	
	UIALogger.logDebug("Finding voicemail from caller '" + caller + "'.");
	UIATarget.localTarget().pushTimeout(10);
	var voicemailElement = phone.mainWindow().tableViews()[0].scrollToElementWithPredicate("name contains '" + caller + "'");
	UIATarget.localTarget().popTimeout();
	if (!voicemailElement.isValid()) {
		this.testError = "Could not find caller " + caller;
		return this.testResult = 0;
	}
	
	var voicemailPosition = phone.mainWindow().elements()["Voicemail position"];
	if (!voicemailPosition.isValid())  {
		this.testError = "Did not find the voicemail position scrubber";
		return this.testResult = 0;
	}
	
	// if voicemail isn't already selected, tap it to select it.
	if (voicemailElement.name().indexOf("Playing") >= 0) {
		UIALogger.logDebug("Voicemail should already by playing");
	} else {
		if (voicemailElement.name().indexOf("Paused") < 0) {
			UIALogger.logDebug("Need to select the voicemail first");
			voicemailElement.tap();
			UIATarget.localTarget().delay(1);
		}
		
		if (voicemailElement.withPredicate("name contains 'Paused'").isValid()) { 
			UIALogger.logDebug("Voicemail is paused. Should tap it to get it playing");
			voicemailElement.tap();
			if (!voicemailElement.withPredicate("name contains 'Playing'").isValid()) {
				this.testError = "Tapped the paused voicemail from " + caller + " but the voicemail did not start playing";
				return this.testResult = 0;
			}
		}
		
		if (!voicemailElement.withPredicate("name contains 'Playing'").isValid()) {
			this.testError = "Voicemail is not playing";
			return this.testResult = 0;
		}
	}
	
	var originalPosition = voicemailPosition.value();
	UIATarget.localTarget().delay(5); //delay for five seconds to verify the voicemail progressed
	if (originalPosition != "100%" & originalPosition == voicemailElement.value()) {
		UIALogger.logError("Original position = " + originalPosition);
		this.testError = "Voicemail position did not progress";
		return this.testResult = 0;
	}
	
	UIALogger.logDebug("Message should be playing.");
	return this.testResult = 1;
}

//----------------------------------------------------------------------------------------
//	Function: phoneTest_pauseVoicemail 
//		Selects a voicemail from the specified caller and pauses it.
//
//	Parameters: None
// 
//	Returns:
//		1 if test passes, 0 or 64 if test fails.
//
//	Notes:
//		test assumes that the voicemail exists and visual voicemail is available on this phone 
//		and that a voicemail message is playing in mobilephone app
//----------------------------------------------------------------------------------------
function phoneTest_pauseVoicemail() {
	
	phone.launchIfNotActive();
	UIALogger.logDebug("Finding the selected voicemail...");
	UIATarget.localTarget().pushTimeout(10);
	var voicemailElement = phone.mainWindow().tableViews()[0].scrollToElementWithPredicate("name contains 'Paused' or name contains 'Playing'");
	UIATarget.localTarget().popTimeout();
	if (!voicemailElement.isValid()) {
		this.testError = "No voicemail element is selected";
		return this.testResult = 0;
	}
	voicemailElement.logElement();
	
	if (voicemailElement.name().indexOf("Paused") >= 0) {
		UIALogger.logDebug("The voicemail is paused -- tapping it to start it again");
		voicemailElement.tap();
		if (!voicemailElement.withPredicate("name contains 'Playing'").isValid()) {
			this.testError = "Tapped a paused voicemail, but it did not start playing";
			return this.testResult = 0;
		}
		UIATarget.localTarget().delay(3); //let it play for a few seonds before we pause it... 
	}
	
	UIALogger.logDebug("Tapping the voicemail to pause it");
	voicemailElement.tap();
	
	if (!voicemailElement.withPredicate("name contains 'Paused'").isValid()) {
		this.testError = "Tapped a playing voicemail, but it not get paused";
		return this.testResult = 0;
	}
	
	//verify the scrubber is not progressing...
	var voicemailPosition = phone.mainWindow().elements()["Voicemail position"];
	if (!voicemailPosition.isValid())  {
		this.testError = "Did not find the voicemail position scrubber";
		return this.testResult = 0;
	}
	var originalPosition = voicemailPosition.value();
	
	//delay for a few seconds...
	UIATarget.localTarget().delay(5);
	if (originalPosition != voicemailPosition.value()) {
		UIALogger.logDebug("Voicemail position changed: original position = " + originalPosition + " new position=" + voicemailPosition.value());
		return this.testResult = 0;
	}
	
	return this.testResult = 1;
}

//----------------------------------------------------------------------------------------
//	Function: phoneTest_deleteVoicemail 
//		Deletes a voicemail from the specified caller.
//
//	Parameters: 
//		caller (string) - person from which the voicemail originated.
// 
//	Returns:
//		1 if test passes, 0 or 64 if test fails.
//
//	Notes:
//		test assumes that the voicemail exists and visual voicemail is available on this phone 
//----------------------------------------------------------------------------------------
function phoneTest_deleteVoicemail() {
	
	if (this.argv.length > 0) { 
		var caller = this.argv[0];
	} else {
		UIALogger.logError("No caller specified.");
		return 64;		
	}
	
	phone.getToKeypadView();
	
	UIALogger.logDebug("Selecting button 'Voicemail'.");
	phone.tabBar().buttons().firstWithPredicate("name contains 'Voicemail'").tap();
	
	if (!phone.navigationBar().withPredicate("name contains 'Voicemail'").isValid()) {
		this.testError = "Tapped the 'Voicemail' button but the nav bar title did not change to Voicemail";
		UIALogger.logError(this.testError);
		return this.testResult = 0;
	}

	var voicemailTable = phone.mainWindow().tableViews()[0];
	var voicemails = voicemailTable.cells().withPredicate("name contains '" + caller + "'");
	if (voicemails.length == 0) {
		this.testError = "Did not find any voicemails from '" + caller + "'";
		UIALogger.logError(this.testError);
		return this.testResult = 0;
	}
	
	var originalNumber = voicemails.length;
	UIALogger.logDebug("Found " + originalNumber + " voicemail from caller '" + caller + "'");
	
	var voicemailElement = voicemails[0];
	voicemailElement.scrollToVisible();
	voicemailElement.logElement();
	
	UIALogger.logDebug("Selecting voicemail table cell: "  + voicemailElement.name());
	voicemailElement.tap();
	UIATarget.localTarget().delay(1);
	
	UIALogger.logDebug("Tapping delete now...");
	phone.mainWindow().buttons().firstWithPredicate("name == 'Delete' and isEnabled == 1").tap();
	if (!voicemailElement.waitForInvalid()) {
		UIALogger.logWarning("The voicemail table cell did not become invalid");
		voicemailElement.logElement();
	}
	
	voicemails = voicemailTable.cells().withPredicate("name contains '" + caller + "'");
	if (voicemails.length != originalNumber-1) {
		this.testError = "Unexpected number of cells after deleting voicemail";
		UIALogger.logError(this.testError + ": actual number = " + voicemails.length + " expected number = " + originalNumber-1);
		return this.testResult = 0;
	}
	return this.testResult = 1;
}

//----------------------------------------------------------------------------------------
//	Function: phoneTest_addDialedNumberToContact 
//		Uses the + button on the keypad dialer view to add the dialed number to a 
//		contact
//
//	Parameters: 
//		number (string) - the number to dial
//		contactName (string) - the contact (new or existing) to add the number to
//		addToExistingContact (boolean) - optional - if set to true, the displayed phone 
//		    number is added to an existing contact. It is set to false by default. 
// 
//	Returns:
//		1 if test passes, 0 or 64 if test fails.
//----------------------------------------------------------------------------------------
function phoneTest_addDialedNumberToContact() {
    if (this.argv.length < 2) {
        UIALogger.logError("number and contact info not specified");
        return 64;
    }
    
    var number = this.argv[0];
    var contactName = this.argv[1];
    var addToExistingContact = false;
    if (this.argv[2] && (this.argv[2] == true || this.argv[2] == "true")) 
        addToExistingContact = true;
    
    phone.getToKeypadView();
    phone.dialNumber(number);
    phone.addDialedNumberToContact(contactName, {addToExistingContact:addToExistingContact});
    
    //verification -- check that the name of the contact is not displayed
    phone.getToView("Keypad"); //make sure we are on the keypad view
    if (!phone.mainWindow().elements().firstWithPredicate("name beginswith '" + contactName + "'").isValid()) {
        this.testError = "Added the phone number to the contact, but the keypad dialer does not show the associated contact";
        UIALogger.logError(this.testError);
        return this.testResult = 0;
    }
    
    return this.testResult = 1;
}

//----------------------------------------------------------------------------------------
//	Function: phoneTest_pastePhoneNumber 
//		Pastes the number in the pasteboard into the number field
//
//	Parameters: 
//		number (string) - the expected number that will be pasted
// 
//	Returns:
//		1 if test passes, 0 or 64 if test fails.
//
//	Notes:
//		test assumes that a phone number has copied
//----------------------------------------------------------------------------------------
function phoneTest_pastePhoneNumber() {
    if (this.argv.length < 1) {
        UIALogger.logError("expected phone number not specified");
        return 64;
    }
    
    var number = this.argv[0];
    
    phone.getToKeypadView();
    
    var numberFieldElement = phone.numberField();
    UIALogger.logDebug("Going to paste into the number field. Expect the " + number + " to be pasted");
    phone.pasteWithOptions(numberFieldElement);
    
    //Verification
    var formattedNumber = phone.formatUSANumber(number);
    if (!numberFieldElement.withValueForKey(formattedNumber, "value").isValid()) {
        this.testError = "The number field did not change to expected phone number";
        numberFieldElement.logElement();
        UIALogger.logError(this.testError);
        UIALogger.logDebug("The expected number was:" + formattedNumber);
        return this.testResult = 0;
    }
    
    return this.testResult = 1;
}

//APPS ACCEPTANCE TESTS

//----------------------------------------------------------------------------------------
//	Function: phoneAT_preTestSetup
//		Make a call and then add another call with a free line.
//
//	Parameters: 
//		None
// 
//	Returns:
//		1 if test pass, 0 if fail.
//----------------------------------------------------------------------------------------
function phoneAT_preTestSetup() {
	
	UIALogger.logDebug("Phone Pretest Setup START");
	
	//Check to see if any calls are active, if so end them prior to running test.
	if (telephony.getCallCount() > 0) {
		try {
			UIALogger.logDebug("Found active calls, ending...");
			phone.endAllCalls();
		} catch(e) {
			this.testError = e.message;
			UIALogger.logError(this.testError);
			UIALogger.logDebug("Failer in PRETEST setup, calls may be active!");
			phone.getToKeypadView();
			return this.testResult = 0;
		}
	}
	UIALogger.logDebug("Phone Pretest Setup END");
	return 1;
} //phoneAT_endCurrentCalls()

//----------------------------------------------------------------------------------------
//	Function: phoneAT_callLengths 
//		Takes the passed in number and calls using 11,10, and 7 digits.
//
//	Parameters: 
//		phoneNumber (string) - 11 digit phone number to call  (+1##########)
// 
//	Returns:
//		1 if test passes, 0.
//	Note:
//		Will fail if number is not 11 digits, not have a leading +, and not in the 408 area code.
//----------------------------------------------------------------------------------------
function phoneAT_callLengths() {
	
	//PRETEST:  Check to see if any calls are active and end them.
	
	if (phoneAT_preTestSetup() != 1) {
		UIALogger.logError("Failed PRE-TEST");
		return this.testResult = 0;
	}
	//END-PRETEST
	
	//Check to see if we have a number to call.
	if (this.argv.length == 1) { 
		var phoneNumber = this.argv[0];
		UIALogger.logDebug("Running test with phone Number:  " + phoneNumber);
	} else {
		UIALogger.logError("Not enough or too many numbers passed in, found " + argv.length + " entries!");
		return this.TestResult = 0;
	}
	
	//Check to see if we got a 11 digit number along with
	if ((phoneNumber.length != 12) || (phoneNumber.substring(0,5) != "+1408")) {
		UIALogger.logError("Invalid phone number passed in:  " + phoneNumber);
		this.TestResult = 0;
		return this.TestResult;
	}
	
	//Make Calls
	var phoneArray = [ phoneNumber, phoneNumber.substring(2,12), phoneNumber.substring(5,12) ];
	UIALogger.logDebug("Length:  " + phoneArray.length);
	for (var i=0; i < phoneArray.length; i++)
	{
		UIALogger.logMessage("Calling phone number:  " + phoneArray[i]);
		try {
			phone.makeCall([phoneArray[i]], {shouldReset:false, shouldMerge:false});
		} catch(e) {
			this.testError = e.message;
			UIALogger.logError(this.testError);
			UIALogger.logDebug("Failure calling:  " + phoneArray[i] + " with error: " +  this.testError);
			phone.getToKeypadView();
			return this.testResult = 0;
		}
		
		//Three second sleep to simulate longer phone call...
		system.sleep(3);
		
		UIALogger.logMessage("Hanging up call:  " + phoneArray[i]);
		try {
			phone.endCall(phoneArray[i]);
		} catch(e) {
			this.testError = e.message;
			UIALogger.logError(this.testError);
			UIALogger.logDebug("Failure ending call:  " + e.message);
			phone.getToKeypadView();
			return this.testResult = 0;
		}
	}
	return this.testResult = 1;
} //phoneAT_callLengths()	

//----------------------------------------------------------------------------------------
//	Function: phoneAT_addCallwithfreeline 
//		Make a call and then add another call with a free line.
//
//	Parameters: 
//		phoneNumber (string) - phone number to call
//		phoneNumber (string) - phone number to call
// 
//	Returns:
//		1 if test passes, 0.
//----------------------------------------------------------------------------------------
function phoneAT_addCallWithFreeLine() {
		
	//PRETEST:  Check to see if any calls are active and end them.
	
	if (phoneAT_preTestSetup() != 1) {
		UIALogger.logError("Failed PRE-TEST");
		return this.testResult = 0;
	}
	
	phone.launchIfNotActive();
	
	//END-PRETEST
			
	//Check to see if we have at least 2 numbers to call.
	if (this.argv.length = 2) { 
		var phoneNumber = this.argv[0];
		var phoneNumber2 = this.argv[1];
	} else {
		UIALogger.logError("Not enough numbers passed in");
		return this.TestResult = 0;
	}	
	
	UIALogger.logMessage("Calling first number...");
	phone.makeCall([phoneNumber], {shouldReset:false, shouldMerge:false});
	
	UIALogger.logMessage("Successfully called first number" + phoneNumber);

	UIALogger.logMessage("Calling second number...");
	phone.makeCall([phoneNumber2], {shouldReset:false, shouldMerge:false});
	
	UIALogger.logMessage("Successfully called second number" + phoneNumber2);

	//End each call, set return code to testResult incase if fails to hang up.
	UIALogger.logMessage("Hanging up call:  " + phoneNumber);
	try {
		phone.endCall(phoneNumber);
	} catch(e) {
		this.testError = e.message;
		UIALogger.logError(this.testError);
		UIALogger.logDebug("Failure ending call:  " + e.message);
		phone.getToKeypadView();
		return this.testResult = 0;
	}
	
	UIALogger.logMessage("Hanging up call:  " + phoneNumber2);
	try {
		phone.endCall(phoneNumber2);
	} catch(e) {
		this.testError = e.message;
		UIALogger.logError(this.testError);
		UIALogger.logDebug("Failure ending call:  " + e.message);
		phone.getToKeypadView();
		return this.testResult = 0;
	}	
	return this.testResult = 1;
} //phoneAT_addCallwithfreeline()

//----------------------------------------------------------------------------------------
//	Function: phoneAT_mergeAndEndCalls 
//		Merges 2 calls and checks each entered phone number to make sure 
//		that the call is active on that particular phone number.
//		Then ends each call individually
//
//	Parameters: 
//		phoneNumber (string) - phone number to call
//		phoneNumber (string) - phone number to call
// 
//	Returns:
//		1 if test passes, 0 if test fails.
//----------------------------------------------------------------------------------------
function phoneAT_mergeAndEndCalls() {
	
	//PRETEST:  Check to see if any calls are active and end them.
	
	if (phoneAT_preTestSetup() != 1) {
		UIALogger.logError("Failed PRE-TEST");
		return this.testResult = 0;
	}
	
	phone.launchIfNotActive();

	//END-PRETEST
	
	//Check to see if we have at least 2 numbers to call.
	if (this.argv.length = 2) { 
		var phoneNumber = this.argv[0];
		var phoneNumber2 = this.argv[1];
	} else {
		UIALogger.logError("Not enough numbers passed in");
		return this.TestResult = 0;
	}	
	
	UIALogger.logMessage("Calling first number...");
	phone.makeCall([phoneNumber], {shouldReset:false, shouldMerge:false});
	
	UIALogger.logMessage("Successfully called first number" + phoneNumber);
	
	UIALogger.logMessage("Calling second number...");
	phone.makeCall([phoneNumber2], {shouldReset:false, shouldMerge:false});
	
	UIALogger.logMessage("Successfully called second number" + phoneNumber2);

	UIALogger.logDebug("Sleep for 5 seconds and then merge calls.");
	//Is this long enough for all devices?
	system.sleep(5);

	//Merge calls, should make into a function....
	startingCallCount = telephony.getCallCount();
	if (startingCallCount < 2) {
		this.testError = "There were not two calls to merge."
		UIALogger.logError(this.testError);
		return this.testResult = 0;
	}
	
	phone.mainWindow().buttons()["merge calls"].tap();
	UIATarget.localTarget().delay(3); //TODO: do we need this?
	
	// make sure we have not dropped a call and we have a Multi-Party line that is active
	if ((startingCallCount == telephony.getCallCount()) && (telephony.callExists(null, "Multi-Party") == true)) {
		for (var i=0; i<this.argv.length; i++) {
			// If phone numbers are entered as parameters, check to make sure they are listed as "Active."
			if (telephony.callExists(this.argv[i], "Active") != true) {
				this.testError = "Call to '" + this.argv[i] + "' is not Active."
				return;
			}
			UIALogger.logMessage("Call to '" + this.argv[i] + "' is Active.")
		}
		UIALogger.logMessage("Calls merged.");	
	}
	
	
	//TODO:  Make function to make a call private....
	
	system.sleep(2);
	//interact "app.mainWindow().elements().firstWithPredicate(\"name contains 'Conference'\").tap()"
	//			phone.mainWindow().buttons().firstWithPredicate("name == 'hold' or name == 'swap'").tap();

	UIALogger.logDebug("Tapping the Conference element to get the list of phone calls");
	phone.mainWindow().elements().firstWithPredicate("name contains 'Conference' or name contains '\&'").tap();
	
	//Check to see if we got to the right page
	system.sleep(2);
	//UIANavigationBar [name:Conference value:(null) rect:{{x:0, y:20}, {width:320, height:44}}]
	//		this.mainWindow().buttons()["End"].tap();
	//  this.mainWindow().buttons().firstWithPredicate("name == 'hold' or name == 'swap'").tap();
	//				this.mainWindow().buttons()["keypad"].isValid());


	if(phone.mainWindow().navigationBars().firstWithPredicate("name == 'Conference'").isValid()) {
		
		UIALogger.logDebug("On the Conference page!!!");
		
	}
	
	//Use to get UIA Element tree
	//interact 'UIATarget.localTarget().frontMostApp().mainWindow().logElementTree()'
	return this.TestResult = 1;
}


//SELF TEST DEFINITIONS:

// Create self tests -- this is an unnamed function, just to make sure any local variables stay in the correct context
(function() {
	if ((typeof phone != 'undefined') && springboard.displaysApp(phone)) {

		if (typeof phone.selfTests == 'undefined') {
			phone.selfTests = new Array();
		}
		
		// Don't run phone tests on any version of the iPod Touch
		phone.selfTests.push(phtCreateTest("MakeCall", ["+14089619343"], phoneTest_makeCall, "Call Loopback Number"));
		phone.selfTests.push(phtCreateTest("HoldCall", null, phoneTest_holdCall, "Hold Call"));
		phone.selfTests.push(phtCreateTest("UnholdCall", null, phoneTest_unholdCall, "Unhold Call"));
		//phone.selfTests.push(phtCreateTest("AnswerCall", [ipaddress], phoneTest_answerCall, "Answer a Call"));  // Cannot be tested currently
		//phone.selfTests.push(phtCreateTest("DeclineCall", [ipaddress], phoneTest_declineCall, "Decline a Call"));  // Cannot be tested currently
		//phone.selfTests.push(phtCreateTest("HoldCallAndAnswer", [ipaddress], phoneTest_HoldCallAndAnswer, "Hold Call and Answer"));  // Cannot be tested currently
		//phone.selfTests.push(phtCreateTest("phoneTest_ignoreCall", [ipaddress], phoneTest_ignoreCall, "Ignore Incoming Call"));  // Cannot be tested currently
		phone.selfTests.push(phtCreateTest("AddCall", ["4087773456"], phoneTest_addCall, "Add a phone call using keypad")); // Movie Phone
		//phone.selfTests.push(phtCreateTest("PushSpeakerButton", ["speaker"], phoneTest_changeButtonStateDuringCall, "Push speaker button")); 
		phone.selfTests.push(phtCreateTest("MergeCalls", null, phoneTest_mergeCalls, "Merge two calls")); 
		phone.selfTests.push(phtCreateTest("EndCall", ["4087773456"], phoneTest_endCall, "End calls")); // Both
		phone.selfTests.push(phtCreateTest("MakeCallToContact", ["Bob Dylan", "home"], phoneTest_makeCallToContact, "Make call using contact name"));
		phone.selfTests.push(phtCreateTest("EndCall", [null], phoneTest_endCall, "End calls")); // Both
		phone.selfTests.push(phtCreateTest("MakeCallFromRecents", ["Bob Dylan"], phoneTest_makeCallFromRecents, "Make call from recents call list"));
		phone.selfTests.push(phtCreateTest("EndCall", [null], phoneTest_endCall, "End calls")); // Both
		phone.selfTests.push(phtCreateTest("AddContactToFavorites", ["Bob Dylan"], phoneTest_addContactToFavorites, "Add contact to favorites"));
		phone.selfTests.push(phtCreateTest("RemoveContactFromFavorites", ["Bob Dylan"], phoneTest_removeContactFromFavorites, "Remove contact from favorites"));
		//phone.selfTests.push(phtCreateTest("AudioSourceChange", ["Built-in speaker", "Speaker"], phoneTest_changeAudioSource, "Changing Audio Source when BT Connected"));
		//phone.selfTests.push(phtCreateTest("PlayVoicemail", ["Caller Name"], phoneTest_playVoicemail, "Play a Voicemail")); // Cannot be tested currently
		//phone.selfTests.push(phtCreateTest("PauseVoicemail", ["Caller Name"], phoneTest_pauseVoicemail, "Pause a Voicemail")); // Cannot be tested currently
		//phone.selfTests.push(phtCreateTest("DeleteVoicemail", ["Caller Name"], phoneTest_deleteVoicemail, "Delete a Voicemail")); // Cannot be tested currently
	}
}())
