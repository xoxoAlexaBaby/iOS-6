#import "StressUtils.js"

//imports for all the test areas
#import "../../appstore/AppStore.js"
#import "../../calculator/Calculator.js"
#import "../../calendar/Calendar.js"
#import "../../camera/Camera.js"
#import "../../clock/Clock.js"
#import "../../contacts/Contacts.js"
#import "../../facetime/FaceTime.js"
#import "../../ipod/iPod.js"
#import "../../mail/Mail.js"
#import "../../maps/Maps.js"
#import "../../messages/Messages.js"
#import "../../notes/Notes.js"
#import "../../photos/Photos.js"
#import "../../photobooth/PhotoBooth.js"
#import "../../safari/Safari.js"
#import "../../settings/Settings.js"
#import "../../stocks/Stocks.js"
#import "../../weather/Weather.js"
#import "../../youtube/YouTube.js"

START_TAG = "--- Start ---";
END_TAG = "--- End ---";

function listApps() {
	system.println(START_TAG)

	if (typeof appstore != 'undefined' && springboard.displaysApp(appstore)) { system.println("AppStore") }
	if (typeof audio != 'undefined' && springboard.displaysApp(audio)) { system.println("Audio") }
	if (typeof calculator != 'undefined' && springboard.displaysApp(calculator)) { system.println("Calculator") }
	if (typeof calendar != 'undefined' && springboard.displaysApp(calendar)) { system.println("Calendar") }
	if (typeof camera != 'undefined' && springboard.displaysApp(camera)) { system.println("Camera") }
	if (typeof clock != 'undefined' && springboard.displaysApp(clock)) { system.println("Clock") }
	if (typeof addressbook != 'undefined' && springboard.displaysApp(addressbook)) { system.println("Contacts") }
	if (typeof facetime != 'undefined' && springboard.displaysApp(facetime)) { system.println("FaceTime") }
	if (typeof mail != 'undefined' && springboard.displaysApp(mail)) { system.println("Mail") }
	if (typeof maps != 'undefined' && springboard.displaysApp(maps)) { system.println("Maps") }
	if (typeof messages != 'undefined' && springboard.displaysApp(messages)) { system.println("Messages") }
	if (typeof notes != 'undefined' && springboard.displaysApp(notes)) { system.println("Notes") }
	if (typeof phone != 'undefined' && springboard.displaysApp(phone)) { system.println("Phone") }
	if (typeof photos != 'undefined' && springboard.displaysApp(photos)) { system.println("Photos") }
	if (typeof photobooth != 'undefined' && springboard.displaysApp(photobooth)) { system.println("PhotoBooth") }
	if (typeof safari != 'undefined' && springboard.displaysApp(safari)) { system.println("Safari") }
	if (typeof settings != 'undefined' && springboard.displaysApp(settings)) { system.println("Settings") }
	if (typeof stocks != 'undefined' && springboard.displaysApp(stocks)) { system.println("Stocks") }
	if (typeof video != 'undefined' && springboard.displaysApp(video)) { system.println("Video") }
	if (typeof weather != 'undefined' && springboard.displaysApp(weather)) { system.println("Weather") }
	if (typeof youtube != 'undefined' && springboard.displaysApp(youtube)) { system.println("YouTube") }
	
	system.println(END_TAG)
}