#!/bin/sh

if [ $# -ne 1 ]; then
    echo "$0 path_to_directory";
    exit 1
fi

if [ ! -d "$1" ]; then
    mkdir "$1";
fi

if [ ! -d "$1" ]; then
    echo "Not a directory: $1";
    exit 1
fi

IOSDebug | sort | uniq | awk '{ print $2; }' | tail -n +6 | while read sid; do
    OUTPUT_PATH="$1/0x$sid.png";
    
    /bin/echo "Dumping surface 0x$sid to $OUTPUT_PATH";
    IOSurfaceDump $sid "$OUTPUT_PATH";
done
