#import "Stocks.js"
#import "../libs/PHTesting.js"

//----------------------------------------------------------------------------------------
//	Function: stocksTest_removeAndAddStock 
//			Removes and then adds an existing stock from the list
//			and then adds it back
//
//	Parameters: 
//		stock (string) -  Name of stock that should be removed and added.  The name should not be
//						   the stock symbol - instead, use the name under the stock symbol on 
//						   the backside of the card, i.e., use "Yahoo", not "YHOO" 
//						   If a stock is not specified a random stock from the list is chosen.
//
//	Returns: 
//		1 if the stock was successfully removed and then added to the list of stocks, 0 if not.
//----------------------------------------------------------------------------------------
function stocksTest_removeAndAddStock() {
	var stockName = "";

	if (this.argv.length > 0) {
		stockName = this.argv[0];
	}

	stocks.launchIfNotActive();

	//This getToFrontsideView call is primarily to 
	//dismiss the search view before attempting to 
	//proceed
	stocks.getToFrontsideView();
	//Allow the flip animation to settle
	UIATarget.localTarget().delay(2);

	stocks.getToBacksideView();
	//Allow the flip animation to settle
	UIATarget.localTarget().delay(2);

	if (stockName == "") {
		var stocksTable = stocks.mainWindow().tableViews().firstWithPredicate("isVisible == 1");
		var numberOfStocks = parseInt(stocksTable.cells().length);
		var randomIndex = system.randomInteger(0,numberOfStocks - 1);
        // Split the stock name at the comma (if present) to workaround <rdar://problem/9212094> english search brings up non-english results
		var stockName = stocksTable.cells()[randomIndex].name().split(",")[0];
        UIALogger.logMessage("Searching for stock '" + stockName + "'");
        
		if (!stockName || stockName == "") {
			this.testError = "Could not find a stock to remove from the list.";
			return this.testResult = 0;
		}
	}

	UIALogger.logMessage("Attempting to remove stock: " + stockName);
	
	try {
		stocks.deleteItem(stockName);
	} catch (e) {
		this.testError = e.message;
		return this.testResult = 0;
	}

	try {
		stocks.addItem(stockName);
	} catch (e) {
		this.testError = e.message;
		return this.testResult = 0;
	}
	

	this.testResult = 1;
	return 1;
	
}

//----------------------------------------------------------------------------------------
//	Function: stocksTest_addStock 
//		Adds the specified stock to the list.  If the stock is already 
//		present, it will be deleted and added.
//
//	Parameters: 
//		stockName (string) - Name (not symbol) of the stock to be added.
//
//	Returns: 
//		1 if the stock was successfully added, 0 otherwise
//----------------------------------------------------------------------------------------
function stocksTest_addStock() {
	var stockName;

	if (this.argv.length > 0) {
		stockName = this.argv[0];
	} else {
		this.testError = "Must pass in a stock name";
		return this.testResult = 0;
	}

	stocks.launchIfNotActive();
	stocks.getToFrontsideView();
	
	try {
		stocks.itemInBacksideList(stockName);
		UIALogger.logMessage("Found " + stockName);
		try {
			stocks.deleteItem(stockName);
		} catch (e) {
			this.testError = e.message;
			return this.testResult;
		}
	} catch (e) {
		UIALogger.logMessage(e.message);
	}


	
	try {
		stocks.addItem(stockName);
	} catch (e) {
		this.testError = e.message;
		return this.testResult = 0;
	}		

	this.testResult = 1;
	return 1;
	
}

//----------------------------------------------------------------------------------------
//	Function: stocksTest_getToYahooPage 
//		Go to Yahoo Page
//
//	Parameters: 
//		None
//
//	Returns: 
//		1 if success; 0 if not
//----------------------------------------------------------------------------------------
function stocksTest_getToYahooPage()
{	

	stocks.launchIfNotActive();
	try {
		stocks.getToYahooWebPage();
	} catch (e) {
		this.testError = e.message;
		return this.testResult = 0;
	}

	return this.testResult = 1;
	
}

// Create self tests -- this is an unnamed function, just to make sure any local variables stay in the correct context
(function() {	
	if ((typeof stocks != 'undefined') && springboard.displaysApp(stocks)) {
		if (typeof stocks.selfTests == 'undefined') {
			stocks.selfTests = new Array();
		}
		
		stocks.selfTests.push(phtCreateTest("AddStock", ["Google"], stocksTest_addStock, "Add Stock AAPL to List, if it's not already there"));
		stocks.selfTests.push(phtCreateTest("RemoveAndAddStock", null, stocksTest_removeAndAddStock, "Remove and then Add Stock AAPL"));
		stocks.selfTests.push(phtCreateTest("GoToYahooStocksPage", null, stocksTest_getToYahooPage, "Go to Yahoo Page"));
	}
}())
