#import "../../libs/SpringBoard.js"
#import "../../phone/Phone.js"
#import "StressLogger.js"

START_TAG = "--- Start ---";
END_TAG = "--- End ---";

function randomCityData() {
	var path = "/System/Library/PrivateFrameworks/AppSupport.framework/all_cities_adj.plist";
	var data = system.plistData(path);
	var count = data.length;
	var cityData = data[system.randomInteger(0, count-1)];
	
	system.println(START_TAG)
	system.println(cityData[5])
	system.println(cityData[6].replace(/\./g, ""))
	system.println(END_TAG)
}


function cameraInfo() {
	system.println(START_TAG)
	
	if (system.hasCapability("video-camera")) {
		system.println("VideoCamera")
	}
	
	var picCmd = "/usr/bin/find /var/mobile/Media/DCIM -name \*.JPG -not -regex .\*.MISC.\* -print";
	var picResult = system.run(picCmd);
	var picOutput = picResult.stdout;
	if (picOutput != "") {
		system.println("Photos")
	}
	
	var vidCmd = "/usr/bin/find /var/mobile/Media/DCIM -name \"*.MOV\" -print";
	var vidResult = system.run(vidCmd);
	var vidOutput = vidResult.stdout;
	if (vidOutput != "") {
		system.println("Videos")
	}
	
	system.println(END_TAG)
}


function callExists(number, state, timeout) {
	if (number == 'null') { number = null }
	
	system.println(START_TAG);
	if (telephony.callExists(number, state, timeout)) {
		system.println('True');
	}
	else {
		system.println('False');
	}
	system.println(END_TAG);
}


function isSIMReady() {
	system.println(START_TAG);
	if (telephony.isSIMReady()) {
		system.println('True');
	}
	else {
		system.println('False');
	}
	system.println(END_TAG);
}


function randomContactItem(item) {
	system.println(START_TAG);
	switch (item) {
	case "ringtone":
		system.println(UIAUtility.randomFromArray(addressbook.ringtones()));
		break;
	case "numberType":
		system.println(UIAUtility.randomFromArray(addressbook.numberTypes()));
		break;
	case "emailType":
		system.println(UIAUtility.randomFromArray(addressbook.emailTypes()));
		break;
	}
	system.println(END_TAG);
}

function clearAlerts() {
	var actionSheet = UIATarget.localTarget().frontMostApp().actionSheet();
	var result = "True"
	
	if (actionSheet.isValid()) {
		var cancelButton = actionSheet.buttons()["Delete Draft"];
		if (cancelButton.isValid()) {
			cancelButton.tap();
		}
		else {
			cancelButton = actionSheet.buttons()["Cancel"];
			if (cancelButton.isValid()) { cancelButton.tap() }
			else { result = "False" }
		}
	}
	
	try {
		var alert = UIATarget.localTarget().frontMostApp().alert();
		if (alert.isValid()) {
			alert.logElementTree();
			try {
				UIATarget.onAlert(alert);
			} catch(e) {
				UIALogger.logError(e);
			}
			
			if (!alert.waitForInvalid()) {
				alert.buttons()[0].tap(); //default handler type behavior
				if (!alert.waitForInvalid()) { result = "False" }
			}
		} 
		else {
			UIATarget.localTarget().pushTimeout(0);
			var alert = UIATarget.localTarget().frontMostApp().mainWindow().elements().firstWithPredicate("className == 'UIAAlert' and ANY buttons.isVisible == 1");
			UIATarget.localTarget().popTimeout();
			if (alert.isValid()) {
				UIALogger.logDebug("Found an alert");
				alert.logElementTree();
				alert.buttons()[0].tap();
			}
		}
	} catch(e) {
		result = "False";
	}
	
	system.println(START_TAG)
	system.println(result)
	system.println(END_TAG)
}
