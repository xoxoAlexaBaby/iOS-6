#!/bin/sh

sleep $2
echo "********** Entering Killing $1 process if hung."
GREP="grep $1"
PIDS=`ps -A | grep $1 | perl -lne 'chomp; if ( !/grep/ && !/killHungProcess/ ) { $p = (split)[0]; $p =~ s/\s*//g; print $p;} ' `;
ps -A
echo "KILLING Processes -- $PIDS for $1.\n"
ps -A | grep $1
kill -9 $PIDS
echo "Exiting killHungProcess after killing $1"

