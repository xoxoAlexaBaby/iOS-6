/*
 Class: UIApp (maps)
 Maps object
 */
#import "../libs/SpringBoard.js"
#import "../libs/UIAAppMailAdditions.js"

maps = UIAApp.application("Maps", "com.apple.Maps");

if (typeof maps != 'undefined') {

	maps.MORE_INFO_BUTTON_NAME = "More info"; 
	maps.DRIVING_BUTTON_NAME = (UIATarget.localTarget().model() == 'iPad') ? "Driving, 1 of 3" : "Directions by car";
	maps.TRANSIT_BUTTON_NAME = (UIATarget.localTarget().model() == 'iPad') ? "Transit, 2 of 3" : "Directions by bus";
	maps.WALKING_BUTTON_NAME = (UIATarget.localTarget().model() == 'iPad') ? "Walking, 3 of 3" : "Directions by walking";
	maps.DIRECTIONS_FORWARD_BUTTON_NAME = "Forward";
	
	//	----------------------------------------------------------------------------------------------------------------------
	//	Function: getCurrentView 
	//		returns a name for the current page you are on within maps
	//
	//	Parameters:
	//		none
	//
	//	Returns:
	//		(string) - returns a string of the name of the view. If no matching view is found, it returns null.
	//
	//	Notes:
	//		Here are the possible results returned:
	//			- "EditDirectionsView" - the view with the directions text field selected
	//			- "EditSearchView" - the view with the search bar selected
	//			- "BookmarksListEditView" - the list of bookmarks in edit mode
	//			- "BookmarksListView" - the list of bookmarks
	//			- "InfoView" - the info view of a selected pin
	//			- "AddBookmarkView" - the view that comes up after tapping 'Add to Bookmarks' 
	//			- "EditBookmarkView"
	//			- "StreetView" - the street view
	//			- "DirectionsStartView" - the route start view (with the 'Start' button at the top)
	//			- "MailComposeView" - the email compose view (for sending the location)
	//			- "MMSComposeView" - the MMS compose view (for composing a MMS)
	//			- "DirectionsListView" - list of directions
	//			- "FoldView" - the view with the map curled
	//			- "MapView"
	//			- "ShareLocationActionSheetView" - the action sheet that comes up when you tap 'Share Location'
	//			- "RecentsListView" - the recents list in the bookmark view
	//			- "ContactsListView" - the contacts list in the bookmark view
	//	----------------------------------------------------------------------------------------------------------------------
	maps.getCurrentView = function getCurrentView() {
		
		//helper function to wrap the timeouts around
		var currentViewHelper = function() {
			var keyboard = maps.keyboard();
			if (keyboard.isValid()) {
				if (UIATarget.localTarget().model() == 'iPad') {
					if (maps.mainWindow().popover().navigationBar().withPredicate("name == 'Suggestions' or name == 'Recents'").isValid()) {
						//will be able to use toolbar() when this <rdar://problem/8251273> gets fixed
						var toolbar = maps.mainWindow().toolbars()[0];
						if (toolbar.buttons()["Swap directions"].isValid()) {
							return "EditDirectionsView";
						} else {
							return "EditSearchView";
						}
					} 
				} else {
					if (maps.mainWindow().buttons()["Route"].isValid()) {
						return "EditDirectionsView";
					} else if (maps.mainWindow().staticTexts()["Search"].isValid()) {
						return "EditSearchView";
					} 
				}
			}
			
			var navBar = (UIATarget.localTarget().model() == 'iPad') ? maps.mainWindow().popover().navigationBar() : maps.navigationBar();
			if (navBar.isValid()) {
				if (navBar.name() == "Bookmarks") {
					if (!navBar.leftButton().withName("Edit").isValid()) {
						return "BookmarksListEditView";
					}
					return "BookmarksListView";
				} else if (navBar.name() == "Info") {
					return "InfoView";
				} else if (navBar.name() == "Add Bookmark") {
					return "AddBookmarkView";
				} else if (navBar.name() == "Edit Bookmark") {
					return "EditBookmarkView";
				} else if (navBar.name() == "Recents") {
					return "RecentsListView";
				} else if (navBar.name() == "All Contacts") {
					return "ContactsListView";
				} else if (navBar.name() == "New MMS" || 
						   navBar.name().indexOf("Message") >= 0) {
					return "MMSComposeView";
				}
			}
			
			//this needs to special cased because of <rdar://problem/8040194>
			navBar = maps.windows()[0].navigationBar()
			if (navBar.isValid()) {
				if (navBar.name() == "New MMS" || 
					navBar.name().indexOf("Message") >= 0) {
					return "MMSComposeView";
				}
			}
			
			if (UIATarget.localTarget().model() == 'iPad' && 
				maps.mainWindow().scrollViews()[0].popover().tableViews()[0].buttons()["Directions To Here"].isVisible()) {
				return "InfoView";
			}
			
			if (maps.mainWindow().images()["Street view"].isValid()) {
				return "StreetView";
			}
			
			if (maps.isDisplayingEmailComposeSheet()) {
				return "MailComposeView";
			}
			
			if (maps.shareLocationActionSheet().staticTexts()["Share Location Using:"].isValid()) {
				return "ShareLocationActionSheetView";
			}
			
			//will not be needed once <rdar://problem/8131066> gets fixed
			if (UIATarget.localTarget().model() == 'iPad' && 
				maps.mainWindow().tableViews()[0].cells().firstWithPredicate("name == '" + maps.getAvailableViews()[0] + "' and isVisible == 1").isValid()) {
				return "FoldView";
			}
			
			if (UIATarget.localTarget().model() == 'iPad') 
				var toolbar = maps.toolbar().withPredicate("isVisible == 1 and ANY buttons.name == 'Bookmarks'");
			else
				var toolbar = maps.toolbar().withPredicate("isVisible == 1 and ANY buttons.name == 'Settings'");
			
			if (toolbar.isValid()) {
				if (UIATarget.localTarget().model() == 'iPad')
					var isInFoldView = maps.mainWindow().tableViews()[0].cells().firstWithPredicate("name == '" + maps.getAvailableViews()[0] + "' and isVisible == 1").isValid();
				else 
					var isInFoldView = maps.mainWindow().segmentedControls().firstWithPredicate("isVisible == 1").buttons().firstWithPredicate("name contains '" + maps.getAvailableViews()[0] + "' and isVisible == 1").isVisible();
				
				if (isInFoldView) {
					return "FoldView";
				}
				
				if (maps.mainWindow().buttons()["Start"].isVisible()) {
					return "DirectionsStartView";
				}
				
				if (maps.mainWindow().staticTexts()["Directions"].isVisible()) {
					return "DirectionsListView";
				}
				
				var isInRouteView = maps.mainWindow().segmentedControls().firstWithPredicate("isVisible == 1").buttons().firstWithPredicate("name contains 'Forward'").isValid();
				if (isInRouteView) {
					return "DirectionsStepView";
				}
				
				return "MapView";
			}
			
		}
		
		UIATarget.localTarget().pushTimeout(0);
		var currentView = currentViewHelper();
		UIATarget.localTarget().popTimeout();
		
		if (!currentView) return null;
		UIALogger.logDebug("In '" + currentView + "'");
		return currentView;
	}
	
	//helper function to toggle between folded/unfolded view
	maps._toggleFoldView = function _toggleFoldView() {
		if (UIATarget.localTarget().model() == 'iPad') {
			UIATarget.localTarget().pushTimeout(0);
			var settingsButton = this.mainWindow().buttons()["Settings"];
			UIATarget.localTarget().popTimeout();
			if (settingsButton.isVisible()) {
				settingsButton.tap();
			} else {
				this.mainWindow().tapWithOptions({tapOffset:{x:0.95,y:0.95}}) 
			}
		} else {
			var settingsButton = this.toolbar().buttons()["Settings"];
			settingsButton.tap();
		}
	}
	
	maps.shareLocationActionSheet = function() {
		if (UIATarget.localTarget().model() == 'iPad') {
			return maps.mainWindow().scrollViews()[0].popover().actionSheet();
		} else {
			return maps.actionSheet();
		}
	}
	//	----------------------------------------------------------------------------------------------------------------------
	//	Function: getToMapView 
	//		Goes to the map view
	//
	//	Parameters:
	//		None
	//
	//	Returns:
	//		true, if it was able to navigate to the map view; throws Error otherwise.
	//
	//	Throws: 
	//		Error
	//	----------------------------------------------------------------------------------------------------------------------
	maps.getToMapView = function getToMapView() {
		
		//helper function for use on iPad, to find a clickable area when the info popover is up
		var dismissPopover = function (elementToTap, popoverElement) {			
			if (!elementToTap.isValid()) {
				throw new Error("Could not find the element to tap to dismiss the popover");
			}
			
			if (!popoverElement.isValid()) {
				UIALogger.logWarning("Could not find the popover");
				return ;
			}
			
			var preferredOffsets = [0.75, 0.25, 0.87, 0.12, 0.75, 0.25, 0.52];
			var found;
			for (var i=0; i<preferredOffsets.length; i++) {
				for (var j=0; j<preferredOffsets.length; j++) {
					var offset = {x:preferredOffsets[i],y:preferredOffsets[j]};
					var rect = elementToTap.rect();
					var xLoc = rect.origin.x + Math.ceil(offset.x * rect.size.width);
					var yLoc = rect.origin.y + Math.ceil(offset.y * rect.size.height);
					var elementToAvoidRect = popoverElement.rect();
					UIALogger.logDebug("Checking whether safe to click x:" + xLoc + " y:" + yLoc);
					if (xLoc <= (elementToAvoidRect.origin.x + elementToAvoidRect.size.width) && xLoc >= elementToAvoidRect.origin.x && 
						yLoc <= (elementToAvoidRect.origin.y + elementToAvoidRect.size.height) && yLoc >= elementToAvoidRect.origin.y) {
						UIALogger.logDebug("Skipping.");
					} else {
						UIALogger.logDebug("Found offset x:" + offset.x + " y:" + offset.y);
						UIATarget.localTarget().tap({x:xLoc, y:yLoc});
						if (maps.waitForInvisible(popoverElement)) return;
						if (popoverElement.isVisible()) UIALogger.logDebug("Still visible?");
					}
				}
			}
			
			elementToTap.logElementTree();
			popoverElement.logElementTree();
			throw new Error("Did not find an area to click");
		};
		
		maps.launchIfNotActive();
		UIALogger.logMessage("Getting to map view");
		
		//sometimes the views can be nested, so we need to try multiple times
		for (var i=0; i<5; i++) {
			var currentView = this.getCurrentView();
			
			switch(currentView) {
				case 'MapView':
					UIALogger.logMessage("Already in map view");
					return true;
					break;	
				case 'StreetView':
					this.mainWindow().tap();
					var doneButton = this.navigationBar().buttons()["Done"];
					if (!doneButton.isVisible()) {
						UIALogger.logMessage("Could not find 'Done', probably because the first tap hit an arrow. Trying again...");
						this.mainWindow().tapWithOptions({tapOffset:{x:0.1, y:0.1}});
						doneButton = this.navigationBar().buttons()["Done"];
						if (!doneButton.isVisible()) throw new Error("Could not find 'Done' button in street view"); 
					}
					doneButton.tap();
					UIATarget.localTarget().delay(3);
					break;
				case 'DirectionsStartView':;
					break;
				case 'MailComposeView':
					this.navigationBar().buttons()["Cancel"].tap();
					var actionSheet = (UIATarget.localTarget().model() == 'iPad') ? this.mainWindow().popover().actionSheet() : this.actionSheet();
					var deleteButton = actionSheet.buttons().firstWithPredicate("name contains 'Delete'");
					UIATarget.localTarget().delay(1); //time for the action sheet to settle down
					deleteButton.tap();
					UIATarget.localTarget().delay(1);
					if (UIATarget.localTarget().model() != 'iPad') this.navigationBar().leftButton().tap();
					break;
				case 'MMSComposeView':
					//need to use windows()[0] because of <rdar://problem/8040194>
					this.windows()[0].navigationBar().buttons()["Cancel"].tap();
					UIATarget.localTarget().delay(1);
					this.navigationBar().leftButton().tap();
					break;
				case 'DirectionsListView':
					break;
				case 'DirectionsStepView':
					break;
				case 'ShareLocationActionSheetView':
					var actionSheet = this.shareLocationActionSheet();
					actionSheet.buttons()["Cancel"].tap();
					UIATarget.localTarget().delay(1);
					if (UIATarget.localTarget().model() != 'iPad') this.navigationBar().leftButton().tap();					
					break;
				default: 
					if (UIATarget.localTarget().model() == 'iPad') {
						switch (currentView) {
							case 'FoldView':
								this._toggleFoldView(); //get out of curled view
								break;
							case 'EditDirectionsView':
								this.keyboard().buttons()["Hide keyboard"].tap();
								break;
							case 'EditSearchView':
								this.keyboard().buttons()["Hide keyboard"].tap();
								break;	
							case 'BookmarksListEditView':
								var popover = this.mainWindow().popover();
								var doneWithEditButton = popover.navigationBar().buttons()["Done"];
								doneWithEditButton.tap();
								UIATarget.localTarget().delay(1);
								popover.dismiss();
								break;
							case 'BookmarksListView':
							case 'RecentsListView':
							case 'ContactsListView':
								this.mainWindow().popover().dismiss();
								break;
							case 'InfoView':
								var popover = this.mainWindow().scrollViews()[0].popover();
								popover.dismiss();
								if (popover.checkIsValid() && popover.isVisible()) {
									UIALogger.logWarning("popover.dismiss() could not dismiss the popover");
									dismissPopover(this.mainWindow().scrollViews()[0], popover);
								}
								break;
							case 'AddBookmarkView':
								var popover = this.mainWindow().popover();
								popover.navigationBar().buttons()["Cancel"].tap();
								UIATarget.localTarget().delay(1);
								popover.dismiss();
								break;
							case 'EditBookmarkView':
								var popover = this.mainWindow().popover();
								var backButton = popover.navigationBar().leftButton();
								backButton.tap();
								UIATarget.localTarget().delay(1);
								popover.dismiss();
								break;
						}
					} else {
						switch (currentView) {
							case 'FoldView':
								this._toggleFoldView();
								break;
							case 'EditDirectionsView':
								var cancelButton = this.mainWindow().buttons()["Cancel"];
								cancelButton.tap();
								break;
							case 'EditSearchView':
								var doneButton = this.mainWindow().buttons().firstWithPredicate("name == 'Done' or name == 'Cancel'");
								doneButton.tap();
								break;
							case 'BookmarksListEditView':
								var doneWithEditButton = this.navigationBar().buttons()["Done"];
								doneWithEditButton.tap();
								UIATarget.localTarget().delay(1);
								var doneButton = this.navigationBar().buttons()["Done"];
								doneButton.tap();
								break;
							case 'BookmarksListView':
								var doneButton = this.navigationBar().buttons()["Done"];
								doneButton.tap();
								break;
							case 'RecentsListView':
								this.navigationBar().buttons()["Done"].tap();
								break;
							case 'ContactsListView':
								this.navigationBar().buttons()["Done"].tap();
								break;
							case 'InfoView':
								var backButton = this.navigationBar().leftButton();
								backButton.tap();
								break;
							case 'AddBookmarkView':
								var cancelButton = this.navigationBar().buttons()["Cancel"];
								cancelButton.tap();
								UIATarget.localTarget().delay(1);
								var backButton = this.navigationBar().leftButton();
								backButton.tap();
								break;
							case 'EditBookmarkView':
								var backButton = this.navigationBar().leftButton();
								backButton.tap();
								UIATarget.localTarget().delay(1);
								var doneWithEditButton = this.navigationBar().buttons()["Done"];
								doneWithEditButton.tap();
								UIATarget.localTarget().delay(1);
								var doneButton = this.navigationBar().buttons()["Done"];
								doneButton.tap();
								break;
						}
					}
			}
			UIATarget.localTarget().delay(1);
			
			var searchButton = this.toolbar().segmentedControls()[0].buttons().firstWithPredicate("name matches 'Search.*'");
			if (searchButton.isValid()) {
				UIALogger.logDebug("Tapping the 'Search' segmented control button");
				searchButton.tap();
			}
			UIATarget.localTarget().delay(1);
			
			currentView = this.getCurrentView();
			if (currentView == 'MapView') {
				return ;
			}
		}//end for loop
		throw new Error("Could not get to MapView. Still in " + currentView);	
	}
	
	maps.bookmarksTable = function bookmarksTable() {
		if (UIATarget.localTarget().model() == 'iPad')
			return this.mainWindow().popover().tableViews()[0];
		else
			return this.mainWindow().tableViews()[0];
	}
	
	// --------------------------------------------------------------------------------
	//	Function: getToFoldView 
	//		Shows the folded screen view
	//
	//	Parameters:	
	//		None 
	//
	//	Returns: 
	//		None
	//
	//	Throws: 
	//		Error
	// --------------------------------------------------------------------------------
	maps.getToFoldView = function getToFoldView() {	
				
		if (this.getCurrentView() == "FoldView") return ;
		
		this._toggleFoldView();

		UIATarget.localTarget().delay(2); //TODO: find something better here...

		if (this.getCurrentView() != "FoldView")  {
			throw new Error("Fold view did not come up");
		}
	}
	
	// --------------------------------------------------------------------------------
	//	Function: getToDirectionsView
	//		Gets to the view with edit directions text fields
	//
	//	Parameters:	
	//		None
	//
	//	Throws: 
	//		Error
	//
	//	Returns:
	//		true - if the edit directions view is being displayed; throws error otherwise. 
	// --------------------------------------------------------------------------------
	maps.getToDirectionsView = function getToDirectionsView() {
		
		try {
			this.getToMapView();
		} catch(e) {
			UIALogger.logError(e.message);
			throw new Error("Could not get to map view");
		}
		
		UIALogger.logMessage("Going to the directions page...");
		var directionsSegmentButton = this.toolbar().segmentedControls()[0].buttons().firstWithPredicate("name matches 'Directions.*'");
		if (!directionsSegmentButton.isVisible()) throw new Error("Could not find the 'Directions' button");
		directionsSegmentButton.tap();

		
		UIALogger.logMessage("Now trying to tap the Edit button...");
		var editButton = this.mainWindow().buttons()["Edit"];
		if (editButton.isValid()) this.mainWindow().buttons()["Edit"].tap();
		
		//for the case where it's not selected
		if (UIATarget.localTarget().model() == 'iPad') {
			//update once <rdar://problem/8131862>, <rdar://problem/8131066> get fixed
			UIATarget.localTarget().pushTimeout(0);
			var startTextField = this.mainWindow().elements().firstWithPredicate("ANY buttons.name == 'Bookmarks'").textFields()[0];
			UIATarget.localTarget().popTimeout();
			if (!startTextField.hasKeyboardFocus()) startTextField.tap();
		} else
			this.mainWindow().textFields()[0].tap();

		var currentView = this.getCurrentView();
		if (currentView != 'EditDirectionsView') throw new Error("Still not in EditDirectionsView view");
		return true;
	}
	
	// --------------------------------------------------------------------------------
	//	Function: getToBookmarksView 
	//		Goes to the Bookmarks/Recents/Contacts option page
	//		
	//	Assumes:
	//		The bookmark icon is visible
	//
	//	Parameters:	
	//		None
	//
	//	Optional Parameters:
	//		toolbarButton (string) - the name of the toolbar button on the 
	//			bookmarks page that needs to be tapped. If no value is assigned, no element 
	//			is tapped. e.g. "Recents", "Contacts", "Bookmarks"
	//	
	//	Returns:
	//		true - if the bookmarks page was displayed; throws error otherwise. 
	//
	//	Throws: 
	//		Error
	// --------------------------------------------------------------------------------
	maps.getToBookmarksView = function getToBookmarksView(options) {
		
		try {
			this.getToMapView();
		} catch(e) {
			UIALogger.logError(e.message);
			throw new Error("Could not get to map view");
		}
		if (!options) options = new Object();
		
		UIALogger.logMessage("Going to the bookmarks view page...");
		if (UIATarget.localTarget().model() == 'iPad')
			var bookmarkIconButton = this.toolbar().buttons()["Bookmarks"];
		else
			var bookmarkIconButton = maps.mainWindow().searchBars()[0].buttons()["Address Book"];
		if (!bookmarkIconButton.isVisible()) throw new Error("Could not find the bookmark icon");
		bookmarkIconButton.tap();
		
		if (options.toolbarButton) {
			UIALogger.logMessage("Tapping '" + options.toolbarButton + "' bookmark type");
			if (UIATarget.localTarget().model() == 'iPad')
				var toolbarButton = this.mainWindow().popover().toolbar().segmentedControls()[0].buttons().firstWithPredicate("name contains '" + options.toolbarButton + "'");
			else
				var toolbarButton = this.toolbar().segmentedControls()[0].buttons().firstWithPredicate("name contains '" + options.toolbarButton + "'");
			if (!toolbarButton.isVisible()) throw new Error("Could not find the toolbar button");
			UIATarget.localTarget().delay(1); //animation delay
			toolbarButton.tap();
			UIATarget.localTarget().delay(1);
			
		}
		
		return true;
	}
	
	// --------------------------------------------------------------------------------
	//	Function: putPinMarker 
	//		Puts a pin marker on the map, and selects it. By default, 
	//		it uses the drop/replace pin option, but other ways of putting a pin marker 
	//		(e.g. search) are also supported through optional parameters
	//
	//	Parameters:	
	//		None
	//
	//	Optional Parameters:
	//		location (string) - if this parameter is assigned a value, a search is 
	//			performed for the specified location, and the result is selected. 
	//			If no location is specified, a pin is dropped and selected.
	//	
	//	Throws: 
	//		Error
	//	
	//	Returns:
	//		true, if the pin was put on the map; throws error otherwise. 
	// --------------------------------------------------------------------------------
	maps.putPinMarker = function putPinMarker(options) {
		var errorMsg;
		this.getToMapView();
		if (!options) options = new Object();		
		
		//search or not
		if (options.location) {
			try {
				this.searchLocation(options.location);
			} catch(e) {
				UIALogger.logError(e.message);
				throw new Error("Could not search for " + options.location);
			}
		} else {
			//put a pin first. 
			UIALogger.logMessage("Dropping a pin on the map...");
			try {
				this.getToFoldView();
			} catch(e) {
				UIALogger.logError(e.message);
				throw new Error("Could not get to fold view");
			}
			UIATarget.localTarget().delay(1);
			
			var pinPredicate = "(name == 'Replace Pin' or name == 'Drop Pin') and isVisible == 1";
			if (UIATarget.localTarget().model() == 'iPad')
				var pinButton = this.mainWindow().tableViews()[0].cells().firstWithPredicate(pinPredicate);
			else 
				var pinButton = this.mainWindow().buttons().firstWithPredicate(pinPredicate);
			if (!pinButton.isValid()) throw new Error("Could not find the replace/drop pin button");
			pinButton.tap();
		}
		
		UIATarget.localTarget().delay(2);
		UIALogger.logMessage("Checking if the pin came up...");
		
		UIATarget.localTarget().pushTimeout(30); //being conservative here... in case network delays come up
		var popover = maps.mainWindow().scrollViews()[0].popover();
		var pin = this.visibleElementsWithName(popover, maps.MORE_INFO_BUTTON_NAME)[0];
		UIATarget.localTarget().popTimeout();
		
		if (!pin.isValid()) throw new Error("No pin found");
		return true;
	}
	
	// --------------------------------------------------------------------------------
	//	Function: getToInfoView 
	//		Goes to the Info page of a pin
	//
	//	Parameters:	
	//		None
	//
	//	Optional Parameters:
	//		location (string) - if this parameter is assigned a value, a search is 
	//			performed for the specified location, and the result is selected. 
	//			If no location is specified, a pin is dropped and selected.
	//		infoButtonName (string) - the name of a button on the 
	//			info page that needs to be tapped. If no value is assigned, no element 
	//			is tapped
	//
	//	Throws:
	//		Error
	//	
	//	Returns:
	//		true - if the Info page was displayed; throws error otherwise. 
	// --------------------------------------------------------------------------------
	maps.getToInfoView = function getToInfoView(options) {
		
		if (!options) options = new Object();		
		
		try { 
			this.putPinMarker(options); 
		} catch(e) {
			UIALogger.logError(e.message);
			throw new Error("Could not put the pin on the map");
		}		
		
		var popover = maps.mainWindow().scrollViews()[0].popover();
		var pin = this.visibleElementsWithName(popover, maps.MORE_INFO_BUTTON_NAME)[0];
		if (!pin.isVisible()) throw new Error("Could find the chevron");
		pin.tap();		
		UIATarget.localTarget().delay(1);
		
		UIALogger.logMessage("Waiting for the info view page to appear...");
		var isInInfoView = false;
		UIATarget.localTarget().pushTimeout(10);
		if (UIATarget.localTarget().model() == 'iPad')
			isInInfoView = this.mainWindow().scrollViews()[0].popover().tableViews()[0].buttons()["Directions To Here"].isVisible();
		else 
			isInInfoView = this.navigationBar().withName("Info").isValid();
		UIATarget.localTarget().popTimeout();
		if (!isInInfoView) throw new Error("The info view page did not appear after tapping the next button");
		
		if (options.infoButtonName) {
			UIALogger.logMessage("Tapping the info button '" + options.infoButtonName + "'");
			if (UIATarget.localTarget().model() == 'iPad')
				var table = this.mainWindow().scrollViews()[0].popover().tableViews()[0];
			else 
				var table = this.mainWindow().tableViews()[0];
			if (!table.isValid()) throw new Error("Could not find a table in the info view");
			var tableCell = this.cellsContainingElementsWithPredicate(table, "name contains '" + options.infoButtonName + "'")[0];
			var infoButton = tableCell.elements().firstWithPredicate("name contains '" + options.infoButtonName + "'");
			if (!infoButton.isVisible()) {
				maps.logElementTree();
				throw new Error("Could not find the button in info view");
			}
			infoButton.scrollToVisible();
			infoButton.tap();
			UIATarget.localTarget().delay(1);
		}
		return true;
	}
	
	// --------------------------------------------------------------------------------
	//	Function: addBoomark 
	//		Drops a pin, and adds it as a bookmark
	//
	//	Parameters:	
	//		None
	//
	//	Throws: 
	//		Error
	//	
	//	Returns:
	//		The name of the bookmark that was added; throws error otherwise. 
	// --------------------------------------------------------------------------------
	maps.addBookmark = function addBookmark() {
		
		UIALogger.logMessage("Adding the bookmark...");

		this.getToInfoView({infoButtonName:"Add to Bookmarks"});
		if (UIATarget.localTarget().model() == 'iPad')
			var textField = this.mainWindow().scrollViews()[0].popover().tableViews()[0].cells()[0].textFields()[0];
		else 
			var textField = this.mainWindow().tableViews()[0].cells()[0].textFields()[0];
		
		if (!textField.isValid()) {
			throw new Error("Could not select the text field");
		}
		//get the bookmark name
		var bookmarkName = textField.value();

		if (UIATarget.localTarget().model() == 'iPad') {
			var saveButton = this.mainWindow().scrollViews()[0].popover().navigationBar().buttons()["Save"];
		} else 
			var saveButton = this.mainWindow().navigationBar().buttons()["Save"];
		if (!saveButton.isValid()) {
			throw new Error("Could not press the Save button");
		}
		saveButton.tap();
		UIATarget.localTarget().delay(1);
		
		return bookmarkName;
	}
	
	// --------------------------------------------------------------------------------
	//	Function: deleteBookmark 
	//		Goes to the list of bookmarks, and deletes a bookmark
	//
	//	Parameters:	
	//		None
	//
	//	Throws: 
	//		Error
	//	
	//	Returns:
	//		The name of the bookmark that was deleted; throws error otherwise. 
	// --------------------------------------------------------------------------------
	maps.deleteBookmark = function deleteBookmark() {
		
		UIALogger.logMessage("Deleting bookmark...");
		
		try {
			this.getToBookmarksView({toolbarButton:"Bookmarks"});
		} catch(e) {
			UIALogger.logError(e.message);
			throw new Error("Could not get to the bookmarks view page");
		}
		
		UIALogger.logMessage("Editing the bookmark...");
		
		var navBar = (UIATarget.localTarget().model() == 'iPad') ? this.mainWindow().popover().navigationBar() : this.navigationBar();
		var editButton = navBar.buttons()["Edit"];
		if (!editButton.isValid()) {
			throw new Error("Could not find the 'Edit' button");
		}
		editButton.tap();
		UIATarget.localTarget().delay(1); //for <rdar://problem/9539877>
		var bookmarksTable = maps.bookmarksTable();
		if (!bookmarksTable.isValid()) {
			throw new Error("Bookmarks table not found");
		}
		var numOfCells = bookmarksTable.cells().length;
		
		var tableCells = this.cellsContainingElementsWithPredicate(bookmarksTable, "name matches 'Delete .*'");
		if(tableCells.length == 0) {
			throw new Error("No bookmarks to delete");
		}
		var tableCell = tableCells[0];
		var bookmarkName = tableCell.name();
		
		UIALogger.logMessage("Deleting " + bookmarkName);
		try {
			this.deleteTableCell(tableCell);
		} catch(e) {
			UIALogger.logError(e.message);
			throw new Error("Could not choose the Delete button");
		}
		
		UIATarget.localTarget().delay(1);
		return bookmarkName;
	}
	
	// --------------------------------------------------------------------------------
	//	Function: searchLocation 
	//		Searches for the location
	//
	//	Parameters:	
	//		location (string) - the location that needs to be searched for 
	//
	//	Throws: 
	//		Error
	//
	//	Returns:
	//		None
	// --------------------------------------------------------------------------------
	maps.searchLocation = function searchLocation(location) {		
		
		var toolbar = this.toolbar();
		
		// Click Search Button
		UIALogger.logMessage("Clicking the search button...");
		toolbar.segmentedControls()[0].buttons().firstWithPredicate("name matches 'Search.*'").tap();
		
		// Enter the location into the search field
		var date = new Date();
		
		UIALogger.logMessage("Entering '" + location + "' in search field.");
		if (UIATarget.localTarget().model() == 'iPad')
			this.search(location, {searchBarEvalString:toolbar.searchBars()[0]})
		else
			this.search(location);
	
		var result = maps.waitForNetworkLoadingToFinish();
		if (!result) UIALogger.logError("The network loading apparently did not finish");

		var searchResultAlert = this.alertSinceDate(date);
		if (searchResultAlert) {
			throw new Error("Found an error dialog after tapping the Search button: " + searchResultAlert.alertMessageArray[0]);
		}
	}
	
	maps.randomX = function randomX() {
		var xMin = 5;
		var xMax = 315
		return system.randomInteger(xMin, xMax);
	}
	
	maps.randomY = function randomY() {
		var yMin = 90;
		var yMax = 325;
		return system.randomInteger(yMin, yMax);
	}
	
	maps.getAvailableViews = function getAvailableViews() {
		if (UIATarget.localTarget().model() == 'iPad')
			return ["Standard", "Satellite", "Hybrid", "Terrain"];
		else
			return ["Standard", "Satellite", "Hybrid"];			
	}
	
	//----------------------------------------------------------------------------------------
	//	Function: viewAs
	//		Folds back the map to reveal the view buttons and selects the correct one. 
	//
	//	Parameters: 
	//		view (string) - name of the view 
	//
	//	Returns: 
	//		true if the correct map was selected; throws error otherwise. 
	//
	//	Throws: 
	//		Error
	//----------------------------------------------------------------------------------------
	
	maps.viewAs = function viewAs(view) {
		UIALogger.logMessage("Required view is: " + view);

		var segmentedControls = this.mainWindow().segmentedControls()[0];
		var selectedView = segmentedControls.selectedButton().name();
		
		// return true if we are already in that view
		if (selectedView && selectedView.indexOf(view)>=0) {
			UIALogger.logMessage("Button '" + view + "' is ON.  Already in requested view.");
			return true;
		}
		
		try {
			this.getToFoldView();
		} catch(e) {
			UIALogger.logError(e.message);
			throw new Error("Could not get to the fold view");
		}
		UIATarget.localTarget().delay(1);
		
		if (UIATarget.localTarget().model() == 'iPad')
			var viewButton = this.mainWindow().tableViews()[0].cells()[view];
		else
			var viewButton = this.mainWindow().segmentedControls().firstWithPredicate("isVisible == 1").buttons().firstWithPredicate("name beginswith '" + view + "'");
		if (!viewButton.isValid()) { 
			this.logElementTree();
			throw new Error("Could not find the button for view '" + view + "'");
		}
		
		if (viewButton.value() == 1) {
			UIALogger.logDebug("View '" + view + "' is already selected");
			this._toggleFoldView();
			return ;
		}
		viewButton.tap();
		UIATarget.localTarget().delay(1);

		//if (!viewButton.withValueForKey(1, "value").isValid()) throw new Error("Selected the button, but the value did not change to 1");
		
		UIALogger.logMessage("Button '" + view + "' is selected.  View has been changed.");
		//maps.getToMapView(); //if the button is already selected then tapping it does not get out of fold view
		return true;
	}
	
	// --------------------------------------------------------------------------------
	//	Function: changeTrafficView
	//		Toggles between Show/Hide traffic
	//
	//	Parameters:	
	//		options 
	//	
	//	Optional Parameters:
	//		showTraffic (String) - if set to "on", the Show Traffic option will be 
	//			enabled (if not already enabled). If set to "off", the Hide Traffic 
	//			will be enabled. If no parameter is specified, the function toggles
	//			the view i.e. Hide Traffic -> Show Traffic or Show Traffic -> Hide 
	//			Traffic
	//
	//	Returns:
	//		true - if the desired traffic view option was chosen; throws error otherwise
	//
	//	Throws: 
	//		Error
	// --------------------------------------------------------------------------------
	maps.changeTrafficView = function changeTrafficView(options) {
		if (!options) options = new Object();
		this.getToMapView();

		UIALogger.logMessage("Changing the traffic view");

		this.getToFoldView();
		
		if (UIATarget.localTarget().model() == 'iPad')
			var trafficElement = this.mainWindow().tableViews()[0].cells()["Traffic"].switches()[0];
		else
			var trafficElement = this.mainWindow().buttons().firstWithPredicate("name matches '.* Traffic'");		
		if (!trafficElement.isValid()) {
			throw new Error("No traffic button available");
		}
		
		var shouldToggle = false; 
		
		//the name check is for iPhone/iPod devices where the element is a button, and the value check is for the switch on iPad
		if (trafficElement.name() == "Hide Traffic" || trafficElement.value() == 1) {
			if (!options.showTraffic || options.showTraffic == "off") {
				UIALogger.logMessage("Hiding traffic...");
				shouldToggle = true; 
			}
			else {
				UIALogger.logMessage("Show Traffic was already on");
			}
		}
		else if (trafficElement.name() == "Traffic Unavailable In This Area") {
			this.getToMapView();
			throw new Error("Traffic is unavailable in the current view");
		} else if (trafficElement.name() == "Show Traffic" || trafficElement.value() == 0) {
			if (!options.showTraffic || options.showTraffic == "on") {
				UIALogger.logMessage("Showing traffic...");
				shouldToggle = true;
			}
			else {
				UIALogger.logMessage("Hide Traffic was already on");
			}
		} else {
			throw new Error("Some strange combination");
		}
		
		if (shouldToggle) {
			trafficElement.tap();
		}
		this.getToMapView();
		return true;
	}
	
	// --------------------------------------------------------------------------------
	//	Function: showsTraffic
	//		Checks to see if the Show Traffic option is enabled. 
	//
	//	Parameters:	
	//		None 
	//	
	//	Returns:
	//		true - if the Show Traffic option is enabled, and false if it is not. Throws 
	//		error if it is unable to determine.
	//
	//	Throws: 
	//		Error
	// --------------------------------------------------------------------------------
	maps.showsTraffic = function showsTraffic() {
		
		UIALogger.logMessage("Now verifying that 'Hide Traffic' button exists...");

		this.getToFoldView();

		if (UIATarget.localTarget().model() == 'iPad')
			var trafficElement = this.mainWindow().tableViews()[0].cells()["Traffic"].switches()[0];
		else
			var trafficElement = this.mainWindow().buttons().firstWithPredicate("name matches '.* Traffic'");
		if (!trafficElement.isValid()) {
			throw new Error("No traffic button available");
		}
		
		var showingTraffic = (UIATarget.localTarget().model() == 'iPad') ? (trafficElement.value() == 1) : (trafficElement.name() == "Hide Traffic");
		if (!showingTraffic) {
			UIALogger.logError("Show traffic does not seem to be enabled.");
			trafficElement.logElement();
		}

		this.getToMapView();
		return showingTraffic;
	}
	
	//----------------------------------------------------------------------------------------
	//	Function: getCurrentLocation
	//		Gets the current location in maps.  No validation is performed,
	//		only the Current Location value is printed
	//
	//	Parameters: 
	//		None
	//
	//	Returns: 
	//		(boolean) - true if the current location was found; throws error otherwise. 
	//
	//	Throws: 
	//		Error
	//----------------------------------------------------------------------------------------
	maps.getCurrentLocation = function getCurrentLocation() {
		
		var trackingButton = this.toolbar().buttons().firstWithPredicate("name contains[cd] 'tracking'");
		if (!trackingButton.isValid()) {
			throw new Error("Could not find the tracking button");
		}
		trackingButton.logElement();
		
		var date = new Date();
		if (trackingButton.name() == "Tracking off") {
			UIALogger.logMessage("Tapping the start tracking button");
			trackingButton.tap();
			if (!trackingButton.withPredicate("name != 'Tracking off'").isValid())
				UIALogger.logWarning("Tapped 'Start tracking, but the name did not change'");
		}
		
		UIATarget.localTarget().delay(2);
		
		maps.waitForNetworkLoadingToFinish();
		
		var currentLocationAlert = maps.alertSinceDate(date);
		if (currentLocationAlert) {
			UIALogger.logError(currentLocationAlert.alertMessageArray[0]);
			throw new Error("Got an alert while trying to get the current location");
		}
		
		UIALogger.logMessage("Looking for the blue tracker...");
	
		UIATarget.localTarget().pushTimeout(60);
		var currentLocationButton = this.mainWindow().scrollViews()[0].elements().firstWithPredicate("name contains 'Current Location' and isVisible == 1");
		UIATarget.localTarget().popTimeout();
		if (!currentLocationButton.isValid()) {
			//check to see if the popover is up already
			if (!this.mainWindow().scrollViews()[0].popover().staticTexts()["Current Location"].isVisible())
				throw new Error("Could not find the blue tracker");
		}
		
		var popover = maps.mainWindow().scrollViews()[0].popover();
		var moreInfoButton = maps.visibleElementsWithName(popover, maps.MORE_INFO_BUTTON_NAME)[0];
		if (!moreInfoButton.isValid()) {
			UIALogger.logMessage("Need to tap the tracker to bring up the callout");
			currentLocationButton.tap();
			UIATarget.localTarget().delay(1);
			
			var popover = maps.mainWindow().scrollViews()[0].popover();
			moreInfoButton = maps.visibleElementsWithName(popover, maps.MORE_INFO_BUTTON_NAME)[0];
			if (!moreInfoButton.isValid()) throw new Error("Tapped the tracker, but the callout did not come up");
		}
		
		var calloutTitle = this.mainWindow().scrollViews()[0].popover().staticTexts()["Current Location"];
		if (!calloutTitle.isValid()) throw new Error("Callout does not have a 'Current Location' title");
		
		UIALogger.logMessage("Current Location: " + this.mainWindow().scrollViews()[0].staticTexts()[1].name());
		return true;		
	}
	
	//----------------------------------------------------------------------------------------
	//	Function: showStreetView
	//		Selects the street view button to show street view. Assumes that the 
	//		desired pin is already selected. 
	//
	//	Parameters: 
	//		None
	//
	//	Throws: 
	//		Error
	//
	//	Returns: 
	//		(boolean) - true if the street view is being displayed. Throws error otherwise.
	//----------------------------------------------------------------------------------------	
	maps.showStreetView = function showStreetView() {
		
		UIATarget.localTarget().pushTimeout(60);
		var streetViewButton = this.mainWindow().scrollViews()[0].popover().buttons()["Street view"];
		UIATarget.localTarget().popTimeout();
		
		if (!streetViewButton.isVisible()) throw new Error("No street view button available");
		if (!streetViewButton.isEnabled()) throw new Error("Street view not available for this location");
		
		streetViewButton.tap();
		
		UIATarget.localTarget().pushTimeout(6);
		var streetViewElement = this.mainWindow().images()["Street view"];
		UIATarget.localTarget().popTimeout();		
		if (!streetViewElement.isValid()) throw new Error("Street view did not appear after selecting the button");
		
		UIATarget.localTarget().delay(3); //wait for some time here, so that the animation stops
		
		UIALogger.logMessage("Dragging around a bit...");
		for (var i=0; i < 5; i++) maps.dragLeftInsideElement(maps.mainWindow());
		return true;
	}

	//----------------------------------------------------------------------------------------
	//	Function: getDirections
	//		Brings up the edit directions view, enters the specified start and end location, 
	//		and selects the route button
	//
	//	Parameters: 
	//		startLocation (string) - the start location
	//		endLocation (string) - the end location
	//		options (Object) - a dictionary of optional arguments
	//
	//	Optional parameters:
	//		directionsType (string) - the type of directions to be provided - driving, transit or 
	//			walking. It is set to driving by default. 
	//
	//	Returns: 
	//		None
	//
	//	Throws: 
	//		Error
	//----------------------------------------------------------------------------------------
	maps.getDirections = function getDirections(startLocation, endLocation, options) {
		if (!options) options = new Object();
		
		this.getToDirectionsView();
		
		UIALogger.logMessage("Typing in 'Start' textfield...");
		if (UIATarget.localTarget().model() == 'iPad') {
			this.enterTextInTextField(this.toolbar().textFields()["Start location"], startLocation);
		} else
			this.enterTextInTextField(this.mainWindow().textFields()["Start location"], startLocation);
		UIATarget.localTarget().delay(2);
		
		UIALogger.logMessage("Typing in 'End' textfield...");
		if (UIATarget.localTarget().model() == 'iPad') {
			this.enterTextInTextField(this.toolbar().textFields()["End location"], endLocation);
		} else
			this.enterTextInTextField(this.mainWindow().textFields()["End location"], endLocation);
		UIATarget.localTarget().delay(2);
		
		var date = new Date();
		var routeButton;
		if (UIATarget.localTarget().model() == 'iPad') {
			routeButton = this.keyboard().buttons().firstWithPredicate("name == 'search' or name == 'SEARCH'");
		} else {
			routeButton = this.mainWindow().buttons()["Route"];
		}
		if (!routeButton.isValid()) {
			throw new Error("Could not find the 'Route' button");
		}
		routeButton.tap();
		
		UIALogger.logMessage("Waiting for loading to finish");
		var loadingElement = this.mainWindow().staticTexts().firstWithPredicate("name beginswith 'Loading'");
		UIATarget.localTarget().pushTimeout(15);
		var loaded = this.waitForInvisible(loadingElement);
		UIATarget.localTarget().popTimeout();
		
		if (!loaded) {
			UIALogger.logError("Did not finish loading");
		}
		
		var directionCouldNotBeFoundErrorString = "Directions could not be found";
		var noResultsFoundErrorString = "No results found";
		var alert = this.alertSinceDate(date);
		if (alert && (alert.alertMessageArray[0].indexOf(directionCouldNotBeFoundErrorString) >= 0 || 
					  alert.alertMessageArray[0].indexOf(noResultsFoundErrorString) >= 0)) {
			throw new Error("Alert Encountered: " + alert.alertMessageArray[0]);
		}
		
		if (options.directionType) {
			UIALogger.logMessage("Choosing the direction type: " + options.directionsType);
			var directionsTypeButtonName;
			if (options.directionsType == "driving") directionsTypeButtonName = this.DRIVING_BUTTON_NAME;
			else if (options.directionsType == "transit") directionsTypeButtonName = this.TRANSIT_BUTTON_NAME;
			else if (options.directionsType == "walking") directionsTypeButtonName = this.WALKING_BUTTON_NAME;
			else {
				throw new Error("Invalid direction type: " + options.directionsType);
			}
			
			var directionsTypeElement = this.mainWindow().segmentedControls().firstWithPredicate("isVisible == 1").buttons()[directionsTypeButtonName];
			if (!directionsTypeElement.isValid()) {
				throw new Error("Did not find the directions button " + directionsTypeButtonName);
			}
			if (directionsTypeElement.value() == 0) {
				UIALogger.logMessage("Setting " + directionsTypeElement.name() + " to 1");
				directionsTypeElement.tap();
				
				if (directionsTypeElement.withValueFoKey(1, "value")) {
					throw new Error("Value of " + directionsTypeElement. name() + "is still 0");
				}
				
				UIALogger.logMessage("Waiting for loading to finish");
				loadingElement = this.mainWindow().staticTexts().firstWithPredicate("name beginswith 'Loading'");
				
				UIATarget.localTarget().pushTimeout(15);
				loaded = this.waitForInvisible(loadingElement);
				UIATarget.localTarget().popTimeout();
				
				if (!loaded) {
					UIALogger.logError("Did not finish loading");
				}
				
				alert = this.alertSinceDate(date);
				if (alert && alert.alertMessageArray[0].indexOf(directionCouldNotBeFoundErrorString) >= 0) {
					throw new Error("Alert Encountered: " + alert.alertMessageArray[0]);
				}
			}
		}
	}
	
	//----------------------------------------------------------------------------------------
	//	Function: stepThroughDirections
	//		Taps the Start button, and steps through all directions. Assumes 
	//		that the route start view (with the Start button) is being displayed.
	//
	//	Parameters: 
	//		None
	//
	//	Returns: 
	//		(boolean) - true if all the steps can be navigates through. Throws error otherwise.
	//
	//	Throws: 
	//		Error
	//----------------------------------------------------------------------------------------
	maps.stepThroughDirections = function stepThroughDirections() {
		
		//helper function to toggle list view.
		var toggleListView = function (setToOn) {
			UIALogger.logMessage("Toggling the list view to " + setToOn);
			if (setToOn == "ON") {
				if (UIATarget.localTarget().model() == 'iPad')
					maps.mainWindow().buttons()["View as list"].tap();
				else
					maps.viewAs("List");
			}
			else {
				if (UIATarget.localTarget().model() == 'iPad')
					maps.mainWindow().buttons()["Minimize list"].tap();
				else	
					maps.viewAs(maps.getAvailableViews()[0]);
			}
		};
		
		UIALogger.logMessage("Starting the stepwise direction view now...");
		var startButton = this.mainWindow().buttons()["Start"];
		if (!startButton.withPredicate("isVisible == 1 and isEnabled == 1").isValid()) {
			if (startButton.isVisible()) UIALogger.logDebug("Start button is visible");
			if (startButton.isEnabled()) UIALogger.logDebug("Start button is enabled");
			throw new Error("Could not press the 'Start' button to start the route view"); 
        }
		startButton.tap();
		UIATarget.localTarget().delay(1);
			
		if (!maps.waitForInvisible(startButton)) throw new Error("Tapped the start button but it did not become invisible");
		
		//getting the total number of steps from the list view
		UIALogger.logMessage("Getting the total number of steps");
		try {
			toggleListView("ON");
		} catch(e) {
			UIALogger.logError(e.message);
			throw new Error("Could not get to the list view");
		}
		
		UIATarget.localTarget().delay(1); //let the animation settle down
        
		var directionsTable = this.mainWindow().tableViews().firstWithPredicate("isVisible == 1");
		if (!directionsTable.isValid()) throw new Error("The directions table did not appear");
		
		var totalNo = directionsTable.cells().length - 3;
		try {
			toggleListView("OFF");
		} catch(e) {
			UIALogger.logError(e.message);
			throw new Error("Could not switch out of directions list view");
		}		
		UIATarget.localTarget().delay(1);
		
		UIALogger.logMessage("The total number of steps are " + totalNo);
		
		//need to tap the forward button an extra time in iPad to get out of the route overview step
		if (UIATarget.localTarget().model() == 'iPad') 
			this.mainWindow().segmentedControls().firstWithPredicate("isVisible == 1").buttons()[maps.DIRECTIONS_FORWARD_BUTTON_NAME].tap();
		var directionStepElement, previousDirectionStepText; //only used for verification in iPad
		var forwardButton = this.mainWindow().segmentedControls().firstWithPredicate("isVisible == 1").buttons()[maps.DIRECTIONS_FORWARD_BUTTON_NAME];
		for (var i=1; i <= totalNo; i++) {
			if (UIATarget.localTarget().model() == 'iPad') {
				if (i > 1) {
					//make sure the direction text changes
					directionStepElement = this.mainWindow().staticTexts().withPredicate("isVisible == 1 and (not name contains 'Google')")[1];
					if (!directionStepElement.withPredicate("name != '" + previousDirectionStepText+ "'").isValid())
						throw new Error("Direction text did not change after tapping the forward button");
					previousDirectionStepText = directionStepElement.name();
					UIALogger.logDebug(previousDirectionStepText);
				} else {
					directionStepElement = this.mainWindow().staticTexts().withPredicate("isVisible == 1 and (not name contains 'Google')")[0];
					previousDirectionStepText = directionStepElement.name();
				}
			} else {
				//make sure expected n of m shows up
				UIATarget.localTarget().pushTimeout(10);
				var routeStepText = this.mainWindow().staticTexts().firstWithName(i + " of " + totalNo);
				UIATarget.localTarget().popTimeout();
				if (!routeStepText.isValid()) throw new Error("Timed out waiting for: " + i + " of " + totalNo);
			}		
			if (!forwardButton.checkIsValid()) throw new Error("Could not press the forward button at step " + i);
			forwardButton.tap();
			this.waitForNetworkLoadingToFinish();
			
			UIATarget.localTarget().delay(1);
		}
		
		//press the next till the end
		UIATarget.localTarget().pushTimeout(10);
		var routeStepText = this.mainWindow().staticTexts().firstWithPredicate("name matches '.*arrive at.*'");
		UIATarget.localTarget().popTimeout();
	
		return true;
	}
	
}