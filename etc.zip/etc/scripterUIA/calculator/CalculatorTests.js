#import "./Calculator.js"
#import "../libs/PHTesting.js"

// --------------------------------------------------------------------------------
//	Function: calcTest_calculate 
//		The main function for a test that performs a calculation in 
//		the calculator app
//
//	Parameters:
//		(string) - the calculation to be performed.  i.e. "1+1" or "1+2-3*4"
//		(string) - the expected result of the calculation.
//
//	Returns:
//		none
//
//	Notes:
//		When using this tests without a specified result there are some edge cases
//		that fail because the format of the calculated validation result does not
//		match precisely the actual displayed result.
// --------------------------------------------------------------------------------
function calcTest_calculate() {
	
	if (this.argv.length < 1) {
		UIALogger.logError(arguments.callee.name + ": No equation specified.");
		return 64;
	}
	
	var equation = this.argv[0];
	var expectedValue;
	var precision;
	
	calculator.launchIfNotActive();
	UIALogger.logMessage("Typing equation '" + equation + "='.");
	calculator.typeString(equation + "=");
	
	var displayValue = calculator.displayedNumber();
	precision = calculator.precisionOfDisplayedNumber();
	UIALogger.logDebug("Precision is " + precision);
	
	UIALogger.logMessage("Value before conversion = " + displayValue + ".");
	displayValue = parseFloat(displayValue);
	UIALogger.logMessage("Value before precision = " + displayValue + ".");
	displayValue = displayValue.toPrecision(precision);
	
	if (this.argv.length > 1) {
		expectedValue = parseFloat(this.argv[1]);
	} else {
		var temp = "expectedValue = " + equation;		
		eval(temp);
		UIALogger.logMessage("Expected before precision = " + expectedValue + ".");	
		expectedValue = expectedValue.toPrecision(precision);
	}
	
	UIALogger.logMessage("Value =" + displayValue + "; Expected=" + expectedValue + ".");
	
	if (expectedValue == displayValue) {
		UIALogger.logMessage("Calculation performed correctly.");
		return this.testResult = 1;
	} else {
		this.testError = "Failed verifification (Expected:" + expectedValue + ", Calculated:" + displayValue + ").";
		UIALogger.logError(this.testError);
		return this.testResult = 0;
	}
}

// --------------------------------------------------------------------------------
//	Function: calcTest_continueCalculation 
//		The main function for a test that performs a calculation in 
//		the calculator app by continuing from the result of the last calculation
//
//	Parameters:
//		(string) - the calculation to be performed.  i.e. "+1" or "+2-3*4"
//		(string) - the expected result of the calculation.
//
//	Returns:
//		none
//
//	Notes:
//		When using this tests without a specified result there are some edge cases
//		that fail because the format of the calculated validation result does not
//		match precisely the actual displayed result.
// --------------------------------------------------------------------------------
function calcTest_continueCalculation() {
	
	if (this.argv.length < 1) {
		UIALogger.logError(arguments.callee.name + ": No equation specified.");
		return 64;		
	}
	
	var equation = this.argv[0];
	
	calculator.launchIfNotActive();
	var displayValue = calculator.displayedNumber();
	var precision = calculator.precisionOfDisplayedNumber();
	UIALogger.logDebug("Precision is " + precision);
	
	UIALogger.logMessage("Value before conversion = " + displayValue + ".");
	displayValue = parseFloat(displayValue);
	UIALogger.logMessage("Value before precision = " + displayValue + ".");
	displayValue = displayValue.toPrecision(precision);
	UIALogger.logMessage("Existing value is '" + displayValue + "'.");
	var originalValue = displayValue;
	
	UIALogger.logMessage("Typing '" + equation + "='.");
	calculator.typeString(equation + "=");
	
	displayValue = calculator.displayedNumber();
	var precision = calculator.precisionOfDisplayedNumber();
	UIALogger.logDebug("Precision is " + precision);
	UIALogger.logMessage("Value before conversion = " + displayValue + ".");
	displayValue = parseFloat(displayValue);
	UIALogger.logMessage("Value before precision = " + displayValue + ".");
	displayValue = displayValue.toPrecision(precision);
	
	var expectedValue;
	if (this.argv.length > 1) {
		expectedValue = parseFloat(this.argv[1]);
	} else {
		var temp = "expectedValue = " + originalValue + "" + equation;	
		eval(temp);
		UIALogger.logMessage("Expected before precision = " + expectedValue + ".");	
		expectedValue = expectedValue.toPrecision(precision);
	}
	
	UIALogger.logMessage("Value =" + displayValue + "; Expected=" + expectedValue + ".");
	if (expectedValue == displayValue) {
		UIALogger.logMessage("Calculation performed correctly.");
		return this.testResult = 1;
	} else {
		this.testError = "Failed verifification (Expected:" + expectedValue + ", Calculated:" + displayValue + ").";
		UIALogger.logError(this.testError);
		return this.testResult = 0;
	}
}

// --------------------------------------------------------------------------------
//	Function: calcTest_clear 
//		The main function for a test that clears the calculator display
//
//	Parameters:
//		none
//
//	Returns:
//		none
// --------------------------------------------------------------------------------
function calcTest_clear() {
	
	calculator.launchIfNotActive();
	calculator.typeString("c");

	if (!calculator.mainWindow().staticTexts().firstWithValueForKey("0","value").isValid()) {
		this.testError = "The value of the text field is not 0, instead it is " + calculator.displayedNumber();
		UIALogger.logError(this.testError);
		return this.testResult = 0;
	}
	UIALogger.logMessage("Display value cleared.");
	return this.testResult = 1;
}

// Create self tests -- this is an unnamed function, just to make sure any local variables stay in the correct context
(function() {	
	if (typeof calculator.selfTests == 'undefined') {
		calculator.selfTests = new Array();
	}
	
	calculator.selfTests.push(phtCreateTest("Calculate", ["c584+3098", "3682.000000"], calcTest_calculate, "Enter a calculation"));
	calculator.selfTests.push(phtCreateTest("ContinueCalculation", ["/2", "1841.000000"], calcTest_continueCalculation, "Continue a calculation"));
	calculator.selfTests.push(phtCreateTest("ClearCalculator", null, calcTest_clear, "Clear the calculator"));
}())