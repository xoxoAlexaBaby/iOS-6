/*
 Class: UIApp (weather)
 Weather object
 */
#import "../libs/SpringBoard.js"
#import "../libs/UIAAppWidgetAdditions.js"

weather = UIAApp.application("Weather", "com.apple.weather");

if (typeof weather != 'undefined') {

	// --------------------------------------------------------------------------------
	//	Function: getMainViewElement 
	//		Gets the main view of the "widget".  This method
	//		is primarily used by UIAAppWidgetAdditions.js to 
	//		get the containing view of all the other view elements,
	//		such as buttons, table views, etc.
	//
	//	Parameters: 
	//		None
	//				
	//	Returns: 
	//		Main scrollView element
	//			
	// --------------------------------------------------------------------------------
	weather.getMainViewElement = function getMainViewElement() {
		return this.mainWindow().scrollViews()[0];
	} // end weather.getMainViewElement

	// --------------------------------------------------------------------------------
	//	Function: getToCardWithCityName 
	//		Attempts to swipe to the named city
	//
	//	Parameters:  
	//		cityName (string) - name of the city to swipe to
	//				
	//	Returns: 
	//		None
	//
	//	Throws:
	//		An error if the city could not be reached
	// --------------------------------------------------------------------------------
	weather.getToCardWithCityName = function getToCardWithCityName(cityName) {
		
		try {
			this.getToFrontsideView();
		} catch (e) {
			throw new Error(arguments.callee.name + ": Could not get to frontside card ");
		}
		
		UIATarget.localTarget().pushTimeout(0.5);
		var pageIndicator = this.mainWindow().pageIndicators()[0];
		if (!pageIndicator.isValid()) {
			UIATarget.localTarget().popTimeout();
			throw new Error(arguments.callee.name + ": Could not find the page indicator");
		}

		// More than one card is in the list
		if (pageIndicator.isVisible()) {
			
			var totalNumber = pageIndicator.pageCount();
			
			// Return to the first page
			pageIndicator.selectPage(0);

			// Now, start looking for the city
			var weatherScrollView = this.getMainViewElement();
			for (var i = 1; i < totalNumber && !weatherScrollView.elements().firstWithPredicate("name beginswith '" + cityName + "'").isValid(); i++) {
				pageIndicator.goToNextPage();
				UIALogger.logMessage(arguments.callee.name + ": The current page is: " + pageIndicator.pageIndex());
			}
		}
		
		if (!this.mainWindow().elements()[0].elements().firstWithPredicate("name beginswith '" + cityName + "'").isValid()) {
			UIATarget.localTarget().popTimeout();
			throw new Error(arguments.callee.name + ": Could not find the " + cityName + " card");
		}
		UIATarget.localTarget().popTimeout();
		
	} // end weather.getToCardWithCityName

} // end if