#This script will check the WiFi connection between Wireless Router and the Internet for each sleep/wake
#TThree argument: SSID, WoW (1/0, default is 0, which means test with WoW disabled) and URL (URL is optional, default is www.google.com
#Script will check the SSID, ping the router IP address, and ping internet URL address

#!/bin/sh -x

WOW=0
START_TEST=true
CONTINUE=true
SLEEP=300
WAKETIME=100
AUTOJOIN_WAITTIME=60
URL="www.google.com"
HOST=""
COUNT=1
LOGERR="/var/log/sleepwaketesterror.log"
LOGRUN="/var/log/sleepwaketestrun.log"
ERRCOUNT="/var/log/sleepwaketestresult.log"
TMP="/var/log/tmp.txt"
SYSLOG="/var/log/sleepwakesyslog.log"

pushd /usr/local/bin/


rm $LOGRUN
#rm $TMP
rm $SYSLOG

hardware_model=`/usr/sbin/sysctl hw.model`
echo "$hardware_model"

H=$(echo "show State:/Network/Global/IPv4" | scutil | grep Router)
HOST=$(echo $H | sed 's/Router : //g')

if [ "$hardware_model" = "hw.model: K66AP" ]; then
	echo "This is a K66"
	en0=$(echo "show State:/Network/Global/IPv4" | scutil | grep en1)
else
	en0=$(echo "show State:/Network/Global/IPv4" | scutil | grep en0)
fi

if [ "$2" != "" ]; then
	WOW=$2
	if [ "$WOW" != 0 ]; then
		WOW=1
	fi
fi

wow_status=`mobilewifitool -- wow`
if [ "$wow_status" = "WoW is supported but disabled" ]||[ "$wow_status" = "WoW not supported" ]; then
	if [ "$WOW" = 1 ]; then
		echo "This test should run with WoW enabled, but device reports: $wow_status, so stop the tests"
		START_TEST=false
	else
		echo "This test should run with WoW disabled, the device report wow status is: $wow_status, continue the tests"
	fi
else
	if [ "$WOW" = 1 ]; then
		echo "This test should run with WoW enabled, device reports: $wow_status, continue tests"
	else
		echo "This test should run with WoW disabled. The device report wow status is: $wow_status, stop the tests"
		START_TEST=false
	fi
fi

if [ "$HOST" = "" ]||[ "$en0" = "" ]; then
	echo "***********************************"
	echo "Springboard reports not using en0 or can not get Router DHCP IP address"
	START_TEST=false
fi

if [ "$START_TEST" = true ]; then
	if [ "$1" = "" ]; then
		echo "***********************************"
		echo "Please input AP SSID"
		echo "***********************************"
		echo ""
	else
		AP=$1
		#echo "Router IP is $HOST"
	
		if [ "$2" != "" ]; then
			URL=$2
		fi
	
		echo ""
		echo "***********************************"
		echo "Test with $AP; Router IP is $HOST; URL is $URL"
		echo ""
		
		
		#Make sure the display is on before running the test
		if [ "$hardware_model" != "hw.model: K66AP" ]; then
			echo "Unlock display"
			scripter -i SpringBoard.js -c 'UIATarget.localTarget().unlockScreenIfNecessary()'
		fi
		
		while($CONTINUE); do
			START=$(date +%s)
			#echo $START
		    echo 
			if [ "$hardware_model" != "hw.model: K66AP" ]; then
				echo "Turn off display before calling SleepCycler"
				scripter -i SpringBoard.js -c "UIATarget.localTarget().lock()"
 				sleep 2
			fi
		    echo "Calling SleepCycler"
		     ./SleepCycler -n 1 -s $SLEEP -w $WAKETIME
		     echo
			
			if [ "$hardware_model" != "hw.model: K66AP" ]; then
				echo "Unlock display"
				scripter -i SpringBoard.js -c 'UIATarget.localTarget().unlockScreenIfNecessary()'
			fi
			 	
		 	PING_AGAIN=true
			#The initial delay of the first ping after screen unlocked, and the ping timeout
			PING_COUNT=2
		 	TIME_COUNT=$PING_COUNT
			#The delay between each tries is the time of ping Rount delay plug ping URL delay
			TIME_DELAY=`expr $TIME_COUNT + 1`
			#TIME_DELAY=`expr $TIME_COUNT + $PING_COUNT`
			#TIME_DELAY=2
			
			END_TIME_COUNT=$(((TIME_DELAY * 3) + PING_COUNT))
			
			autojoin_result="FAIL"
			ping_result="FAIL"
			pingURL_result="FAIL"
			test_result="FAIL"
			
			en0_Interface="PASS"
			check169IP="PASS"
			#start_Ping="PASS"
			
			autojoin_passtime=0
			ping_passtime=0	
	
		    while [ "$TIME_COUNT" -le "$END_TIME_COUNT" -a $PING_AGAIN = true ]; do
				#Wait for TIME_DELAY seconds to check the en0 and IP
				#sleep $TIME_COUNT
				start_Ping="PASS"
		        router=$(echo "show State:/Network/Global/IPv4" | scutil | grep Router)
				if [ "$hardware_model" = "hw.model: K66AP" ]; then
					en0_tmp=$(echo "show State:/Network/Global/IPv4" | scutil | grep en1)
				else
					en0_tmp=$(echo "show State:/Network/Global/IPv4" | scutil | grep en0)
				fi

				if [ "$router" = "" ]||[ "$en0_tmp" = "" ]; then
					echo "***********************************"
					echo "Springboard reports not using en0 or can not get Router DHCP IP address"
					echo "***********************************"
					en0_Interface="FAIL"
					start_Ping="FAIL"
					# Sleep for 3 seconds, because ping URL and ping Host got skipped
					sleep 3
				else
					if echo $router | grep "Router : 169."; then
						echo "We got an 169 IP address"
						check169IP="FAIL"
						start_Ping="FAIL"
						# Sleep for 3 seconds, because ping URL and ping Host got skipped
						sleep 3
					fi
				fi
				
				#start ping if en0 is primary interface and we have a vlid IP
				if	[ "$start_Ping" = "PASS" ]; then	
					echo "ping -c $PING_COUNT -t $PING_COUNT $HOST"
					ping -c 2 -t $PING_COUNT $HOST
				
					#if ping HOST did not pass
			    	if [ 0 -ne $? ]; then
						ping_result="FAIL"
						#sleep for 1 sec because ping URL got skipped
						sleep 1
					else
						ping -t 1 -c 1 $URL
						if [ 0 -ne $? ]; then
							pingURL_result="FAIL"
						else
							pingURL_result="PASS"
						fi
						
						autojoin_result="PASS"
						# If autojoin time did not set then set it because Ping HOST Passed
						# Or if this is the first loop, also need to set autojoin_passtime
						if [ "$autojoin_passtime" -le 1 -o "$TIME_COUNT" -eq "$PING_COUNT" ]; then
							autojoin_passtime=$TIME_COUNT
						fi

						if [ "$ping_result" = "FAIL" ]; then
							ping_passtime=$TIME_COUNT
							ping_result="PASS"
						fi
					fi
				fi
				
				#check auto join if en0 is not primary interface or get a 169 IP or ping HOST did not pass
				if [ "$start_Ping" = "FAIL" ]||[ "$autojoin_result" = "FAIL" ]; then
					./apple80211 -ssid
				    SSID=`./apple80211 -ssid`
					if echo $SSID | grep -qv "$AP"; then
						autojoin_result="FAIL"
						autojoin_passtime=0
						echo "Auto join with $AP Fail"
			        else
						autojoin_result="PASS"
						#If auto join passed before ping pass
						if [ "$autojoin_passtime" -le 1 ] ; then
							autojoin_passtime=$TIME_COUNT
						fi
					
					fi
				fi
								
		        
				echo "$COUNT : Now, TIME_COUNT is: $TIME_COUNT; ping_passtime is $ping_passtime; autojoin_passtime is $autojoin_passtime"
		        TIME_COUNT=`expr $TIME_COUNT + $TIME_DELAY`
				#sleep $SLEEP_DELAY;
				echo "$COUNT : Next, TIME_COUNT will be: $TIME_COUNT; "
				
				if [ "$pingURL_result" = "PASS" ]&&[ "$ping_result" = "PASS" ]; then
					test_result="PASS"
					PING_AGAIN=false
				fi
			done
        
			
			#if auto join fails, wait for 30 seconds and see whether auto join passes
			autojoin_finalresult=$autojoin_result
			ping_finalresult=$ping_result
			pingURL_finalresult=$pingURL_result
			
			echo "auto join result is $autojoin_result, ping $HOST result is $ping_result, ping $URL result is $pingURL_result"
			
		#	if [ "$autojoin_result" = "FAIL" ]||[ "$ping_result" = "FAIL" ]; then
			if [ "$test_result" = "FAIL" ]; then
				echo "Test did not pass, wait for $AUTOJOIN_WAITTIME seconds, and check auto join and ping again"
				sleep $AUTOJOIN_WAITTIME
				./apple80211 -ssid
			    SSID=`./apple80211 -ssid`
				if echo $SSID | grep -qv "$AP"; then
					autojoin_finalresult="FAIL"
		        else
					autojoin_finalresult="PASS"
					en0_Interface_finalresult="PASS"
					check169IP_finalresult="PASS"
					ping_finalresult="PASS"
					start_Ping="PASS"
					
					router=$(echo "show State:/Network/Global/IPv4" | scutil | grep Router)
					if [ "$hardware_model" = "hw.model: K66AP" ]; then
						en0_tmp=$(echo "show State:/Network/Global/IPv4" | scutil | grep en1)
					else
						en0_tmp=$(echo "show State:/Network/Global/IPv4" | scutil | grep en0)
					fi

					if [ "$router" = "" ]||[ "$en0_tmp" = "" ]; then
						echo "***********************************"
						echo "Springboard reports not using en0 or can not get Router DHCP IP address"
						echo "***********************************"
						en0_Interface_finalresult="FAIL"
						check169IP_finalresult="FAIL"
						start_Ping="FAIL"
						ping_finalresult="FAIL"
						pingURL_finalresult="FAIL"
					else
						if echo $router | grep "Router : 169."; then
							echo "We got an 169 IP address"
							check169IP_finalresult="FAIL"
							start_Ping="FAIL"
							ping_finalresult="FAIL"
							pingURL_finalresult="FAIL"
						fi
					fi

					#start ping if en0 is primary interface and we have a vlid IP
					if	[ "$start_Ping" = "PASS" ]; then	
						echo "router is $router"
						echo "en0_tmp is $en0_tmp"
						echo "ping -c $PING_COUNT -t $PING_COUNT $HOST"
						ping -c $PING_COUNT -t $PING_COUNT $HOST

						#if ping HOST did not pass
					   	if [ 0 -ne $? ]; then
							ping_finalresult="FAIL"
						else
							ping_finalresult="PASS"
							ping -t 1 -c 1 $URL
							if [ 0 -ne $? ]; then
								pingURL_finalresult="FAIL"
							else
								pingURL_finalresult="PASS"
							fi
						fi
					fi	
				fi
			fi
			
			#echo test results
			
			if [ "$test_result" = "FAIL" ]; then
			#	echo "FAIL: auto join result is $autojoin_result, ping $HOST result is $ping_result"
				if [ "$autojoin_result" = "FAIL" ]; then
			#		echo "auto join result is $autojoin_result, ping $HOST result is $ping_result"
					echo "$COUNT : Test Result with $AP: $test_result (auto join fail, after $AUTOJOIN_WAITTIME, result is: $autojoin_finalresult); Auto Join $autojoin_result within $autojoin_passtime; Ping $HOST $ping_result within $ping_passtime (Ping after $AUTOJOIN_WAITTIME seconds: $ping_finalresult); Ping $URL: $pingURL_result (Ping after $AUTOJOIN_WAITTIME seconds: $pingURL_finalresult)" 
					echo "$COUNT : Test Result with $AP: $test_result (auto join fail, after $AUTOJOIN_WAITTIME, result is: $autojoin_finalresult); Auto Join $autojoin_result within $autojoin_passtime; Ping $HOST $ping_result within $ping_passtime (Ping after $AUTOJOIN_WAITTIME seconds: $ping_finalresult); Ping $URL: $pingURL_result (Ping after $AUTOJOIN_WAITTIME seconds: $pingURL_finalresult)" >> $LOGRUN 
				elif [ "$en0_Interface" = "FAIL" ]; then
					echo "$COUNT : Test Result with $AP: $test_result (en0 is not primary interface or no valid IP address, after $AUTOJOIN_WAITTIME, result is: $en0_Interface_finalresult; 169 IP Check is: $check169IP_finalresult); Auto Join $autojoin_result within $autojoin_passtime; Ping $HOST $ping_result within $ping_passtime (Ping after $AUTOJOIN_WAITTIME seconds: $ping_finalresult); Ping $URL: $pingURL_result (Ping after $AUTOJOIN_WAITTIME seconds: $pingURL_finalresult)" 
					echo "$COUNT : Test Result with $AP: $test_result (en0 is not primary interface or no valid IP address, after $AUTOJOIN_WAITTIME, result is: $en0_Interface_finalresult; 169 IP Check is: $check169IP_finalresult); Auto Join $autojoin_result within $autojoin_passtime; Ping $HOST $ping_result within $ping_passtime (Ping after $AUTOJOIN_WAITTIME seconds: $ping_finalresult); Ping $URL: $pingURL_result (Ping after $AUTOJOIN_WAITTIME seconds: $pingURL_finalresult)" >> $LOGRUN 
				elif [ "$check169IP" = "FAIL" ]; then	
					echo "$COUNT : Test Result with $AP: $test_result (169 IP, after $AUTOJOIN_WAITTIME, this is: $check169IP_finalresult); Auto Join $autojoin_result within $autojoin_passtime; Ping $HOST $ping_result within $ping_passtime (Ping after $AUTOJOIN_WAITTIME seconds: $ping_finalresult); Ping $URL: $pingURL_result (Ping after $AUTOJOIN_WAITTIME seconds: $pingURL_finalresult)" 
					echo "$COUNT : Test Result with $AP: $test_result (169 IP, after $AUTOJOIN_WAITTIME, this is: $check169IP_finalresult); Auto Join $autojoin_result within $autojoin_passtime; Ping $HOST $ping_result within $ping_passtime (Ping after $AUTOJOIN_WAITTIME seconds: $ping_finalresult); Ping $URL: $pingURL_result (Ping after $AUTOJOIN_WAITTIME seconds: $pingURL_finalresult)" >> $LOGRUN 
				elif [ "$ping_result" = "FAIL" ]; then
					echo "$COUNT : Test Result with $AP: $test_result (ping $HOST fail, after $AUTOJOIN_WAITTIME, result is: $ping_finalresult); Auto Join $autojoin_result within $autojoin_passtime; Ping $HOST $ping_result within $ping_passtime (Ping after $AUTOJOIN_WAITTIME seconds: $ping_finalresult); Ping $URL: $pingURL_result (Ping after $AUTOJOIN_WAITTIME seconds: $pingURL_finalresult)" 
					echo "$COUNT : Test Result with $AP: $test_result (ping $HOST fail, after $AUTOJOIN_WAITTIME, result is: $ping_finalresult); Auto Join $autojoin_result within $autojoin_passtime; Ping $HOST $ping_result within $ping_passtime (Ping after $AUTOJOIN_WAITTIME seconds: $ping_finalresult); Ping $URL: $pingURL_result (Ping after $AUTOJOIN_WAITTIME seconds: $pingURL_finalresult)" >> $LOGRUN 
				else 
					echo "$COUNT : Test Result with $AP: $test_result (ping $URL fail, after $AUTOJOIN_WAITTIME, result is: $pingURL_finalresult); Auto Join $autojoin_result within $autojoin_passtime; Ping $HOST $ping_result within $ping_passtime (Ping after $AUTOJOIN_WAITTIME seconds: $ping_finalresult); Ping $URL: $pingURL_result (Ping after $AUTOJOIN_WAITTIME seconds: $pingURL_finalresult)" 
					echo "$COUNT : Test Result with $AP: $test_result (ping $URL fail, after $AUTOJOIN_WAITTIME, result is: $pingURL_finalresult); Auto Join $autojoin_result within $autojoin_passtime; Ping $HOST $ping_result within $ping_passtime (Ping after $AUTOJOIN_WAITTIME seconds: $ping_finalresult); Ping $URL: $pingURL_result (Ping after $AUTOJOIN_WAITTIME seconds: $pingURL_finalresult)" >> $LOGRUN 
				fi
				
			else
				echo "$COUNT : Test Result with $AP: $test_result; Auto Join $autojoin_result within $autojoin_passtime; Ping $HOST $ping_result within $ping_passtime; Ping $URL: $pingURL_result" 
				echo "$COUNT : Test Result with $AP: $test_result; Auto Join $autojoin_result within $autojoin_passtime; Ping $HOST $ping_result within $ping_passtime; Ping $URL: $pingURL_result" >> $LOGRUN 
			fi			
			
			echo "Completed cycle $COUNT"
			date
			echo "Completed cycle $COUNT" >> $LOGRUN
			date >> $LOGRUN
			
			echo "$COUNT : syslog for this cycle"
			echo "" >> $SYSLOG
			echo "" >> $SYSLOG
			echo "#########################################################" >> $SYSLOG
			
			echo "$COUNT : syslog for this cycle" >> $SYSLOG
			echo "" >> $SYSLOG
			
			END=$(date +%s)
			DIFF=$(( $END - $START ))
			echo "It took $DIFF seconds"
			echo "/usr/bin/syslog -k Time ge -$DIFF"
			/usr/bin/syslog -k Time ge -$DIFF >> $SYSLOG
			/usr/bin/syslog -k Time ge -$DIFF
			echo
			wow_status_current=`mobilewifitool -- wow`
			echo "WoW status is: $wow_status_current"
			if [ "$wow_status_current" != "$wow_status" ]; then
				echo "WoW status changed after sleep/wake, it should be $wow_status, now it reported: $wow_status_current. Stop the tests"
				break;
			fi
			((COUNT++))
			#sleep 10
			
		done
	fi
fi
popd
