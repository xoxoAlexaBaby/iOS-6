

TOOLS_DIR="/usr/local/bin"

# GET THE BASEBAND VERSION LOADED ON THE DEVICE
${TOOLS_DIR}/CoreTelephonyMonitor -q 2> BBVersion.txt &
sleep 2; 
#(killall -9 CoreTelephonyMonitor 2>&1 /dev/null &)
#sleep 2
DEVICENAME=`/usr/local/bin/lockdown_query get NULL DeviceName 2>&1`
CHECK=`grep -c "Firmware Baseline Version" BBVersion.txt`

if [ $CHECK -ne 0 ]; then 
	Baseband=`perl -lne 'if (/\QFirmware Baseline Version\E/ ) { $vers = (split /\s+/)[-1]; $vers =~ s/\[|\]//g;  print "$vers" }' BBVersion.txt`
else
	Baseband=`perl -lne 'if (/\QFirmware Version\E/ ) { $vers = (split /\s+/)[-1]; $vers =~ s/\[|\]//g;  print "$vers" }' BBVersion.txt`
fi

echo "BASEBAND, $DEVICENAME, $Baseband"
