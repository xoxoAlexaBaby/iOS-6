#!/bin/sh

#################################################################################################
#                                                                                               #
#   ScriptName: PhoenixStress.sh                                                                #
#                                                                                               #
#   Usage:      nohup <path_to_Script>/PhoenixStress.sh [-Option <optarg>] [ ... ] &            #
#                                                                                               #
#   Purpose:    To run stress tests on the device stressing the IPC. The script keeps running   #
#               Data downloads, make calls, Send/Receive SMS continuously until the Iterations  #
#               specified.                                                                      #
#               The purpose of the script is to ensure the stability of the Baseband/AP builds  #
#                                                                                               #
#   Author:     Jerome Jesu                                                                     #
#   Contact:    jesu@apple.com                                                                  #
VERSION="v24"
#   Version:    v24                                                                             #
#                                                                                               #
#   Copyright   2010 Apple. All rights reserved.                                                #
#################################################################################################

source /usr/local/etc/BasebandStressTests/config.sh
SCRIPTS_DIR="/usr/local/etc/"
OTHERS_DIR="/usr/local/etc/BasebandStressTests/"


usage()
{
	echo "\nUSAGE:   $0 [ -option <option_arg> ] [ -option ] [ ... ] &"
	echo " \t\t <DevicePhNumber>  --  Phone number of the Stress Test DUT."
	echo "\n $0 -OPTIONS <option arg>: Short info"
	echo "  -h <HOLD TIME in seconds> :  Call interval time, \tDefault - 15s"
	echo "  -i <number of Iterations> :  Total Iterations, \tDefault - 1500"
	echo "  -n <Loop Back Number>     :  Loopback Phone number, \tDefault - +14089748874"
	echo "  -l <sms Loop Back Number> :  SMS Phone Number, \tDefault - +11111111111"
	echo "  -w                        :  Disable Sleep Cycling,\tDefault - Enabled"
	echo "  -d                        :  Data Download Failure Logging \tDefault -  DISABLED"
	echo "  -r                        :  To have multiple runs of same diff configs on the same day."
}


scriptname=`basename $0`
DEVICENAME=`hostname`
flag=0
source $SCRIPTS_DIR/Defaults.sh

## PRINT ALL THE DEFAULTS TAKEN EFFECT
echo "\n *** Phoenix Stress Test Version = $VERSION."
scriptname="${scriptname}_$VERSION"
echo " ****** ITERATIONS  -- $LOOPS."
echo " ****** NUMBER -- $LOOP_BACK_NUMBER."
echo " ****** HOLD   -- $CALL_INTERVAL."
echo " ****** SMS_NUMBER --- $SMS_NUMBER ####\n Done with defaults.\n"


if [ -e ${SCRIPTS_DIR}/printIPCStatistics.sh ]; then
	echo "printIPCStatistics.sh file is present.";
	source ${SCRIPTS_DIR}/printIPCStatistics.sh;
	logDataFailure=1
	generateFileNames
else
	echo " Going with printStatistics.sh"
	source ${SCRIPTS_DIR}/printStatistics.sh
	logDataFailure=0
	SUFFIX1=`date | cut -c5-7 -c9-10 -c12-13 -c15-16 -c18-19 -c 25-28`
	ResultsFile="/var/root/STATS_$DEVICENAME-$SUFFIX1.csv"
	LOGSFILE="/var/root/LOGS_$DEVICENAME-$SUFFIX1.log"
fi

if [ -e ${SCRIPTS_DIR}/TestCases_Maverick.sh ]; then
	echo "DataTestCases.sh file is present.";
	source ${SCRIPTS_DIR}/TestCases_Maverick.sh;
else
	source ${SCRIPTS_DIR}/TestCases.sh
fi

if [ "$noIdleSleep" ]; then 	
	nohup /usr/bin/pmset noidle &
fi


rm -r $csiLogsDir/ Upload* Download* Data* Call* Sms*
mkdir $csiLogsDir/
mkdir RemovedLogs/

#echo "START_TIME, CURRENT_TIME, MEID, DEVICE_NAME, AP_BUILD, BB_BUILD, ITERATIONS, Total BB RESETS, Total_CALLS, Total_SMS, CALL_DROPS, CALL_FAILURES, FTOs, Download_Attempts, Download Pass, Download Fails, DataFailPercent, AvgDownloadDataRate, Upload_Attempts, AvgUploadDataRate, CallFails_CT, SMSFails_CT, START_TIME(s), CURRENT_TIME(s), RUN_TIME(s), FirstResetTime(s), D3, PDPActAttempts, PDPActFAIL, UDID, RUN_TIME (Hours), ScriptName, Hardware, SERIAL, Target, MinDataRate, Max DataRate, Crash Summary, " >> $ResultsFile
echo "START_TIME, CURRENT_TIME, MEID, DEVICE_NAME, AP_BUILD, BB_BUILD, ITERATIONS, Total BB RESETS, Total_CALLS, Total_SMS, CALL_DROPS, CALL_FAILURES, FTOs, Download_Attempts, Download Pass, Download Fails, DataFailPercent, DownloadDataRate, Upload_Attempts, UploadDataRate, CallFails_CT, SMSFails_CT, START_TIME(s), CURRENT_TIME(s), RUN_TIME(s), FirstResetTime(s), D3, PDPActAttempts, PDPActFAIL, UDID, RUN_TIME (Hours), SCRIPT, Hardware, SERIAL, TARGET, Min Data Rates, Max Data Rates, MDN, SNUM, MMS, MMS Fail, CRASHES, " >> $ResultsFile

startTime=`date "+%s"`
firstResetTime=$startTime
tStartTime=`date -r $startTime | cut -c5-19`
lastStatsUploadTime=`date "+%s"`
lastLogsUploadTime=$lastStatsUploadTime


##########################################################################
#################### START EXECUTING STRESS TESTS  #######################
##########################################################################

###### 1a.  START LOCMON IN THE BACKGROUND
if [ "$EnableLocmon" ]; then startLocmon; fi


while [ $dcount -lt $LOOPS ]
do
		((dcount++)) 
		((count++))
		((callCount++))
		((smsCount++))
		loopStartTime=`date "+%s"`
		
		echo "\n\n  ################### Beginning Iteration - $dcount ####################\n"
		echo "\n\n  ################### Beginning Iteration - $dcount ####################\n" >> DownloadStressTest.txt
		date
		getRegistrationStatus

		# 1a.  RE-START locmon after 25 iterations ONLY IF locmon is NOT running
		if [ "$EnableLocmon" ] && [ $(($dcount % 25)) -eq 1 ]; then  
			echo `date` ": Restarting Locmon if not running"
			restartLocmonIfStopped; 
		fi
		

		# 1b. Data Downloading http://17.254.20.251/1MB.txt 3 times
		date >> DownloadStressTest.txt
		Repetition=2;
		uploadDownloadData   $Repetition   $weblink1   30   1
		sleepInterval=$((RANDOM % 5 + $SLEEPOFFSET))
		if [ $DoSleep -eq 1 ]; then 
			runSleepCycler 1 $sleepInterval; 
		else 	
			sleep $sleepInterval; 
		fi


	    # 1c. MOMT Loopback SMS-1 600+ chars
		echo `date` ": 	####	Sending 600+ chars MO SMS(1) - $smsCount..."
		sendSMS $SMS_NUMBER $smsCount $SMSSTRING2					
		sleepInterval=$((RANDOM % 30 + $SLEEPOFFSET))
		if [ $DoSleep -eq 1 ]; then 
			runSleepCycler 2 $sleepInterval; 
		else 	
			sleep $sleepInterval; 
		fi
	
	
		# 1d. MAKING MO call 1
		echo `date` ": 	####	MAKING MO CALL 1 - $callCount."
		rand=$((RANDOM % 15))
		callTimer=$(($rand + $CALL_INTERVAL))
		makeCALL $LOOP_BACK_NUMBER $callTimer $callCount			
		sleepInterval=$((RANDOM % 10 + $SLEEPOFFSET))
		if [ $DoSleep -eq 1 ]; then 
			runSleepCycler 3 $sleepInterval; 
		else 	
			sleep $sleepInterval; 
		fi
		
		
		# 1e.  Adding Idle time if required.
		if [ $(($dcount % 10)) -eq 0 ]; then  
			sleepInterval=$((RANDOM % 300 + 300));
			echo `date` ": IDLE TIME:  Sleeping for $sleepInterval."
			sleep $sleepInterval;
		fi
		
		((count++)); ((callCount++)); ((smsCount++));			


		if [ $(($dcount % 50)) -eq 0 ]; then  
			echo `date` ": _____COLLECTING LEAKS - $dcount _____"  >> $LOGSFILE
			echo " ******  Leaks Capturing for Certain Processes" >> LEAKS_${DEVICENAME}_${dcount}.txt 
			date >> top_output_$DEVICENAME.txt
			top -o -cpu -s 5 -l 10 >> top_output_$DEVICENAME.txt  &
			echo "\n\n ######## LEAKS output" >> LEAKS_${DEVICENAME}_${dcount}.txt  &
			leaks -exclude _dyld_start CommCenter >> LEAKS_${DEVICENAME}_${dcount}.txt  &
			echo "\n\n ######## VMMAP output" >> LEAKS_${DEVICENAME}_${dcount}.txt  &
			vmmap -resident -dirty CommCenter >> LEAKS_${DEVICENAME}_${dcount}.txt  &
			echo "\n\n ######## HEAP output" >> LEAKS_${DEVICENAME}_${dcount}.txt  &			
			heap -showSizes CommCenter >> LEAKS_${DEVICENAME}_${dcount}.txt  &
			tail -10000 /var/root/Library/Caches/locationd/locationd.log >> /var/wireless/Library/Logs/CrashReporter/locationd_${$dcount}.log &
			sleep 30
		fi
		
		
		
		

		# 2a.  Data Downloading & Uploading -- http://17.254.20.251/5MB  and 1MB Upload
		Repetition=2;
		echo `date` ": 	#### UPLOAD DOWNLOAD DATA "
		uploadDownloadData   $Repetition   $URL2   120   2
		#DownloadData $Repetition $URL2  1
		#UploadData 2
		sleepInterval=$((RANDOM % 20 + $SLEEPOFFSET + 30))
		if [ $DoSleep -eq 1 ]; then 
			runSleepCycler 4 $sleepInterval; 
		else 	
			sleep $sleepInterval; 
		fi
		

		# 2b.  MOMT Loopback SMS 2
		echo `date` ": 	####	Sending SMS(2) - $smsCount..."
		if [ $smsCount -ge 200 ] && [ $((dcount % 2)) -eq 0 ]; then  message=$SMSSTRING1;
		else	message=$SMSSTRING2; fi
		sendSMS $SMS_NUMBER $smsCount $message
		sleep 8
		
		
		# 2c.  MAKING MO call 2
		echo `date` ": 	####	MAKING MO CALL 1 - $callCount."
		rand=$((RANDOM % 15))
		callTimer=$(($rand + $CALL_INTERVAL))
		makeCALL $LOOP_BACK_NUMBER $callTimer $callCount			
		sleepInterval=$((RANDOM % 5 + $SLEEPOFFSET))
		if [ $DoSleep -eq 1 ]; then
			runSleepCycler 5 $sleepInterval; 
		else 	
			sleep $sleepInterval; 
		fi
	
			
			
			
			
		# 3a.  Downloading http://17.254.20.251/2MB.txt  2 times & 1MB Upload
		Repetition=1;
		echo `date` ": 	#### UPLOAD DOWNLOAD DATA "
		#uploadDownloadData   $Repetition   $URL2   30   3
		DownloadData $Repetition $URL3 3
		UploadData1
		sleepInterval=$((RANDOM % 30 + $SLEEPOFFSET))
		if [ $DoSleep -eq 1 ]; then 
			runSleepCycler 6 $sleepInterval; 
		else 	
			sleep $sleepInterval; 
		fi
		
		
		# 3b.  DataContext Up/Down
		echo `date` ": Bringing datacontext up." ;
		((pdpAttempts++)) 
		echo `date` ": ***** PDP Iteration - $dcount." >> DataContextStatus.txt
		activatePDPContext 0
		sleep 5;
		#echo "Bringing datacontext down."; 
		#$TOOLSDIR/DataContext -c 0 down;
		sleepInterval=$((RANDOM % 5 + $SLEEPOFFSET))
		if [ $DoSleep -eq 1 ]; then 
			runSleepCycler 7 $sleepInterval; 
		else 	
			sleep $sleepInterval; 
		fi
		
		
		
				
		# 4a.  Log the Current System time in seconds	 	
		curTime=`date "+%s"`
		tcurTime=`date -r $curTime | cut -c5-19`
		# Time take for the current loop


		# 4b. Check if the timer expired to start printing/Dumping out the logs.
		curLoopTimeTaken=$(($curTime - $loopStartTime))
		checkTimeForUploadingStats=$(($curTime - $lastStatsUploadTime))		
		checkTimeForUploadingLogs=$(($curTime - $lastLogsUploadTime))
		echo "\n ********* Current Time = $tcurTime, $curTime;"
		echo " Loop Time = $curLoopTimeTaken; Loop StartTime = $loopStartTime\n\n"		
		echo " Last UpLoad Time: STATS = $lastStatsUploadTime, LOGS = $lastLogsUploadTime;"
		echo " Time since last Stats upload = $checkTimeForUploadingStats;"
		echo " Time since last Logs upload  = $checkTimeForUploadingLogs;\n"
		
		# Get Registration Status from CT Monitor
		getRegistrationStatus

		
		# 4c.  Generate Stats and upload stats if necessary
		if [ $checkTimeForUploadingStats -ge $STATS_INTERVAL ] || [ $dcount -eq $LOOPS ]; then
			
			if [ -e /$SCRIPTS_DIR/config_maverick.sh ]; then
				echo `date` ": config_maverick.sh file is present. Getting the Defaults."
				source $SCRIPTS_DIR/config_maverick.sh
			fi

			#dumpLogs $dcount; # print Statistics to the Results file
			echo `date` ": Printing Stats:"
			printIPCStatistics $startTime $curTime $dcount
			cp "$LOGSFILE" /Library/Logs/CrashReporter/
			
			if [ "$UPLOAD" ] && [ -e /$SCRIPTS_DIR/printIPCStatistics.sh ];  then 
				echo `date` ": ******** Uploading Stats to the Server: ( $checkTimeForUploadingStats -- LastLogTime - $lastStatsUploadTime.)\n"
				echo `date` ": _____$dcount UPLOADING STATS_____"  >> $LOGSFILE
				uploadStats			
			fi			
			lastStatsUploadTime=`date "+%s"`

		fi
		
		
		# 4d. Upload LOGS if necessary
		if [ $checkTimeForUploadingLogs -ge $LOG_INTERVAL ] || [ $dcount -eq $LOOPS ]; then
			
			# Zip logs
			echo `date` ": _____$dcount COMPRESS BASEBAND LOGS_____"  >> $LOGSFILE
			echo `date` ":  perl $SCRIPTS_DIR/compressLogs.pl"
			perl $SCRIPTS_DIR/compressLogs.pl
			
			
			if [ "$UPLOAD" ]  &&  [ $disableLogsUpload -eq 0 ] && [ -e /$SCRIPTS_DIR/printIPCStatistics.sh ]; then 
				echo `date` ": ******** Uploading LOGS to the Server: ( $checkTimeForUploadingStats -- LastLogTime - $lastStatsUploadTime.)\n"
				echo `date` ": _____$dcount UPLOADING LOGS_____"  >> $LOGSFILE
				uploadLogs;
				lastLogsUploadTime=`date "+%s"`
			fi	
		fi

		
done
