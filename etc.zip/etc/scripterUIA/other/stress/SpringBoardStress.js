#import "UIAAppStressLibrary.js"

var searchStrings = new Array (
		"Notes", "Stocks", "Clock", "Safari", "Mail",
		"Abbott", "Derek", "Elmer", "Brandy", "Bobby",
		"Bowie", "The Eagles", "Fleetwood Mac", "Modest Mouse", "Sting",
		"Zero", "Candle in the Wind", "Chop Suey", "Under Pressure", "One"
		);

springboardStress = AppStressBase.stressTest('SpringBoard');

if (typeof springboardStress != 'undefined') {
	
	springboardStress.setup = function setup() {
		springboardStress.addTest(springboardStress._search);
		springboardStress.addTest(springboardStress._reorderHomeScreen);
	}
	
	springboardStress.run = function run() {
		springboardStress.executeRandomTests(3);
	}
	
	// search
	springboardStress._search = function _search() {
		var searchString = UIAUtility.randomFromArray(searchStrings);
		springboardStress.executeTest("Search", [searchString], springboardTest_search, "Search for a string in SpringBoard.");
		system.sleep(5);
	}
	
	// reorder home screen
	springboardStress._reorderHomeScreen = function _reorderHomeScreen() {
		springboard.getToSpringBoard();
		springboardStress.executeTest("ReorderHomeScreen", [], springboardTest_reorderHomeScreen, "Move an app icon on the home screen.");
	}
	
	// add a test for folders?
}
