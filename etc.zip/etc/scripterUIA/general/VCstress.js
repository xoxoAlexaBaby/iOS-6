#!/usr/local/bin/scripter -uiautomation YES -f

#import "../libs/PHTesting.js"
#import "../libs/HarnessUtility.js"
#import "../settings/SettingsTests.js"

#import "../springboard/SpringboardTests.js"
#import "../facetime/FaceTimeTests.js"
#import "../phone/PhoneTests.js"
#import "../system/SystemTests.js"

var kReportPath = "/var/mobile/Library/Logs/CrashReporter/";
var hasWifi = system.hasCapability('wifi');
var hasTelephony = system.hasCapability("telephony");

var start = new Date();
var timeString = start.getTime() + "";  // turn this into a string
var runID = "VC Stress " + start.toDateString() + " - " + timeString.substr(-6);

/*
This is the Standard iOS Apps QA Automation Script for FaceTime 
It will make Back to Backs calls up to 1000 each for 5 mins and then end them
*/
function addTestsToArray(tests) {	//VC
	for(var i=0; i <= 1000; i=i+1) {
		tests.push(phtCreateTest("VCContact"+i, ["AUTOMATION",true,"All Contacts"], facetimeTest_makeVideoCallToContact, i+"VC Contact"));
		tests.push(phtCreateTest("Sleep", [300], systemTest_doNothing, "Let The Call Continue For 5 Mins"));
		tests.push(phtCreateTest("VCEnd"+i, true, facetimeTest_endVideoCall, "End VC"));
		tests.push(phtCreateTest("Sleep", [80], systemTest_doNothing, "Sleep for 80 seconds, Let the device Lock"));
	}
}

function usage() {
	system.println("usage: VC.js [--enable <string>] [--disable <string>] [-o <path> | -filepath <path> | --filename <string>] [-l | --list]");
	system.println("	--disable	tests to skip (may use regex to describe tests)");
	system.println("	--enable	tests to run (may use regex to describe tests)");
	system.println("	--filepath	full path for the results file");
	system.println("	--filename	name to use for the results file");
	system.println("	--wifiname	name to use for the wifi basestation");
	system.println("	--wifipassword	password to use for the wifi basestation");
	system.println("	--nosetup	skip the setup phase of the QuickLook")
	system.println("	--list		list the available tests");
	system.println("	--writecrashes	write out crashes to the results file")
	system.println("	--help | -h	usage description");
}

function main() {
	var tests = new Array();
	var version = harness_getBuildVersion();
	var filename = "VC_" + version + ".txt";
	var filepath;
	var wifiname;
	var wifipassword;
	var writeCrashes = false;
	var enableSetup = false;
	
	// seed the generator, so that any random events are the same for every run
	system.setRandomSeed(1);
	UIATarget.localTarget().unlockScreenIfNecessary();	// screen must be unlocked to check for springboard app icons
	
	// process command line arguments
	var options = new Options();
	if (options.help || options.h) {
		usage();
		return;
	}
	if (options.list || options.l) {
		addTestsToArray(tests);
		harness_listTests(tests);
		return;
	}
	if (options.filename) filename = options.filename;
	if (options.nosetup) enableSetup = false;
	if (options.writecrashes) writeCrashes = true;
	if (options.o) filepath = options.o;
	else if (options.filepath) filepath = options.filepath;
	else {
		harness_makeDirectory(kReportPath);
		filepath = kReportPath + filename;
	}
	
	// if setup is enabled, add the setup tests to the test array.
	if (enableSetup) {
		
		// Unlock the device
		tests.push("Setup");
		tests.push(phtCreateTest("Launch Settings", [settings, 10], springboardTest_launchApp, "Launch Settings"));
		//tests.push(phtCreateTest("UnlockDevice", ["0"], systemTest_lockAndUnlockDevice, "Unlock the device")); 
		
		// Set auto-lock to never
		tests.push(phtCreateTest("SetAutoLockToNever", ["General", "Auto-Lock", "Never"], settingsTest_chooseCheckmarkedItem, "Set Auto-Lock to Never"));
	  	tests.push(phtCreateTest("EnableBatteryLifeLogging", ["Internal Settings", "Power", "Battery Life Logging", "1"], settingsTest_changeSingleSwitch, "Enable Battery Life Logging"));
		tests.push(phtCreateTest("EnableWifiLogging", ["Internal Settings", "Settings", "WiFi Logging", "1"], settingsTest_changeSingleSwitch, "Enable Wifi Logging"));
		tests.push(phtCreateTest("EnableWifiManagerLogging", ["Internal Settings", "Radios", "WiFiManager", "Logging", "1"], settingsTest_changeSingleSwitch, "Enable WifiManager Logging"));
		tests.push(phtCreateTest("EnableWifiManagerFileLogging", ["Internal Settings", "Radios", "WiFiManager", "File Logging", "1"], settingsTest_changeSingleSwitch, "Enable WifiManager File Logging"));
		
		// Setup proper Wi-Fi
		if (hasWifi) {
			if (options.wifiname) {
				wifiname = options.wifiname;
				if (options.wifipassword) {
					wifipassword = options.wifipassword;
				}
			}
			else {
				wifiname = "Automation";
				wifipassword = "wireless";
				
			}
			tests.push(phtCreateTest("SetWifi", ["1", wifiname, wifipassword, "backupNetwork:AppleWiFi"], settingsTest_setWifi, "Set Wifi to " + wifiname));
			//tests.push(phtCreateTest("SetWifiOn", ["1", "AppleWiFi"], settingsTest_setWifi, "Turn wifi on and set it to AppleWiFi"));
		}
				
		// Turn MALogs on if the device has a phone -- disabled because this seems to have a large impact on memory
		//if ((typeof phone != 'undefined') && springboard.displaysApp(phone)) {
		//	tests.push(phtCreateTest("BasebandLoggingOn", null, settingsTest_turnOnBasebandLogging, "Turn on Baseband Logging"));
		//}
	}
	
	addTestsToArray(tests); // add all of the normal tests to the array
	
	// uncomment this line if you want top data added to the output
	system.setDefault("com.apple.harness", "utilities", ["/usr/bin/top -o -cpu -c a -l 2"]);
	
	harness_removeFile(filepath);
	harness_runTestsFromArray(tests, filepath, options.disable, options.enable, false, writeCrashes);
	
	system.println("Done Running VC.");
}

main();
