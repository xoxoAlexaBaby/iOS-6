/*
 Class: UIApp (calendar)
 Calendar object
 */

#import "../libs/SpringBoard.js"

calendar = UIAApp.application("Calendar", "com.apple.mobilecal");

if (typeof calendar != 'undefined') {

	//Helper methods for iPad vs non-iPad
	
	// _getSegmentedControlContainerElement returns the view which contains the 
	// segmented controls for selecting Month, List, Day (and Week for iPad) buttons
	calendar._getSegmentedControlContainerElement = function _getSegmentedControlContainerElement() {
		if (UIATarget.localTarget().model() == 'iPad') return this.mainWindow();
		else return this.toolbar();
	}

	// _getElementContainingButtonWithName returns the view which contains the specified button
	calendar._getElementContainingButtonWithName = function _getElementContainingButtonWithName(buttonName) {
		if (UIATarget.localTarget().model() == 'iPad') { 
			if (this.mainWindow().buttons().firstWithPredicate("name contains '" + buttonName + "'").isValid()) return this.mainWindow();
			else throw new Error("Cannot find view containing button: " + buttonName);
		}

		UIATarget.localTarget().pushTimeout(0);
		var buttonContainerElement = this.mainWindow().elements().firstWithPredicate("ANY buttons.name contains '" + buttonName + "'");
		UIATarget.localTarget().popTimeout();

		if (!buttonContainerElement.isValid()) throw new Error("Could not find view containing the '" + buttonName + "' button.");
		return buttonContainerElement;
	}
	
	// _getAddEventElement returns the view which contains the main view to add an event.  
	// On non-ipad devices, this would simply be mainWindow and in the case of iPads,
	// this would be a popover.
	calendar._getAddEventElement = function _getAddEventElement() {

		if (UIATarget.localTarget().model() != 'iPad') {
			return this.mainWindow();
		} else {
			return this.mainWindow().popover();
		}
	}
	
	
	// --------------------------------------------------------------------------------
	//	Function: getToAddEventView 
	//		Navigate to the Add Event View.  If the current view
	//		is a detail view of "Add Event", i.e., "Title & Location",
	//		"Starts & Ends", etc., the event details will not be saved.
	//
	//	Parameters: 
	//		None
	//
	//  Throws:  
	//		an exception if the view was not successfully navigated to.
	//
	// --------------------------------------------------------------------------------
	calendar.getToAddEventView = function getToAddEventView() {
		
		this.launchIfNotActive();
		var navBar;
		if (this._getAddEventElement().isValid()) {
			navBar = this._getAddEventElement().navigationBar();
			if(navBar.staticTexts().firstWithName("Add Event").isValid())
				return ;
		}

		try {
			this.getToMainCalendarView();
		} catch (e) {
			UIALogger.logError(e.message);
			throw new Error("Could not get to a main calendar view.  Cannot proceed to 'Add Event' view");
		}
		
		var addEventButton = this._getElementContainingButtonWithName("Add").buttons().firstWithPredicate("name beginswith 'Add'");
		
		UIALogger.logMessage("Navigating to 'Add Event' View.  Tapping the 'Add' button" );

		if (!addEventButton.isValid()) throw new Error("Could not find 'Add' button");
		addEventButton.tap();

		var addEventNavBar = this._getAddEventElement().navigationBar().staticTexts().firstWithName("Add Event");

		if (addEventNavBar.isValid()) {
			UIALogger.logMessage("Successfully navigated to 'Add Event' view");
			return ;
		} 
		
		throw new Error("Could not get to 'Add Event' view. Currently in " + this._getAddEventElement().navigationBar().name());

	} // end cal_getToAddEventView



	// --------------------------------------------------------------------------------
	//	Function: getToAddEventDetailView()
	//		Navigate to a detail view of the Add Event view.
	//		Detail Views:
	//			Title & Location
	//			Start & End
	//			Repeat Event
	//			Event Alert
	//			Notes
	//
	//	Parameters:	
	//		detailView ( String ) - The 'Add Event' detail view to navigate to.
	//
	//  Throws
	//		An exception if the view was not successfully navigated to.
	// --------------------------------------------------------------------------------
	calendar.getToAddEventDetailView = function getToAddEventDetailView( detailView ) {

		this.launchIfNotActive();
		
		var navBarElements = this._getAddEventElement().navigationBar().elements();

		if (navBarElements.firstWithPredicate("name CONTAINS '" + detailView + "'").isValid()) {
			UIALogger.logMessage("Already in " + detailView + " view");
			return ;
		}

		try {
			this.getToAddEventView();
		} catch (e) {
			UIALogger.logError(e.message);
			throw new Error("Could not get to '" + detailView + "'");
		}

		// Using the full path to the table cell because assigning it to a variable doesn't seem to work as reliably as it should
		if (this._getAddEventElement().tableViews().firstWithPredicate("isVisible == 1").cells().firstWithPredicate("name contains '" + detailView + "'").isValid()){
			UIALogger.logMessage( "Navigating to " + detailView + " view");
			
			this._getAddEventElement().tableViews().firstWithPredicate("isVisible == 1").cells().firstWithPredicate("name contains '" + detailView + "'").tap();

		} else {
			throw new Error("Cannot find table cell to tap to navigate to " + detailView + " view");
		}

		if (this._getAddEventElement().navigationBar().staticTexts().firstWithPredicate("name MATCHES '.*" + detailView + ".*'").isValid()) {
			UIALogger.logMessage("Navigated to " + detailView + " view");
			return ;
		} else {
			throw new Error("Did not get to " + detailView + " view");
		}

	} // cal_getToAddEventDetailView( detailView )



	// --------------------------------------------------------------------------------
	//	Function: eventCountFromListView
	//		Get total number of events in the List view
	//								
	//	Parameters:	
	//		None
	//
	//  Returns: 
	//		Returns the number of events in the List view
	//
	//	Throws:
	//		 An exception if the number of events could not be determined
	//
	// --------------------------------------------------------------------------------
	calendar.eventCountFromListView = function eventCountFromListView() {
	
		try {
			this.getToCalendarView("List");
		} catch (e) {
			throw new error ("Could not switch to List View");
		}
		var listTable = this.mainWindow().tableViews()[0];
		
		if (listTable.withName("No events").isValid()) {
			return 0;
		} else {
			var count = listTable.cells().length;
			UIALogger.logMessage( count + " events found in list table" );
			return count;
		}
		
	} // end eventCountFromListView


	// --------------------------------------------------------------------------------
	//	Function: getToMainCalendarView
	//		Tap left navigation view button to return to the main calendar view.  This function will
	//		also try to exit the search view
	//
	//	Parameters: 
	//		None
	//
	//	Throws:
	//	 	throws an exception if we cannot reach main calendar view
	// --------------------------------------------------------------------------------
	calendar.getToMainCalendarView = function getToMainCalendarView() {
		this.launchIfNotActive();
		var maxAttempts = 5;
		var todayButton;
		var navBar;
		UIATarget.localTarget().pushTimeout(1);
		
		//Try tapping the left navigation bar until we can't anymore
		for (var attempt = 0; attempt < maxAttempts; attempt++) {
			if (UIATarget.localTarget().model() != 'iPad') {
				var navBar = this.mainWindow().navigationBar();
				if (navBar.isValid()) {
					if (navBar.buttons().firstWithName("Calendars").isValid()) break;
					else {
                        var doneButton = navBar.buttons()["Done"];
                        if (doneButton.isValid()) doneButton.tap();
                        else navBar.leftButton().tap();
                    }
				}
			} else {
				// iPad-specific dismissal of popovers
				var popoverView = this._getAddEventElement();
				if (!popoverView.isValid()) { 
					break;
				} else if (popoverView.navigationBar().isValid() && popoverView.navigationBar().leftButton().isValid()) {
					popoverView.navigationBar().leftButton().tap();
				} else {
					popoverView.dismiss();
				}
			}
		}

		if (UIATarget.localTarget().model() != 'iPad') {
			//Make sure we're out of the search mode, too
			var cancelButton = this.mainWindow().buttons()["Cancel"];
			if (cancelButton.isValid()) cancelButton.tap();
				
		}
		
		if (UIATarget.localTarget().model() == 'iPad') {
			//Dismiss the keyboard if it's onscreen for some reason
			var dismissKeyboardButton = this.keyboard().buttons()["Hide keyboard"];
			UIATarget.localTarget().delay(1); //give it a second to settle down
			if (dismissKeyboardButton.isValid()) dismissKeyboardButton.tap();
		}
		
		//Give the keyboard time to animate offscreen
		UIATarget.localTarget().delay(1);

		//if the today Button is visible, then we are back at the main calendar view.
		todayButton = this._getSegmentedControlContainerElement().buttons()["Today"];
		if (!todayButton.isVisible()) throw new Error("Could not reach main Calendar view");
		UIATarget.localTarget().popTimeout();
		return ;
		
	} // calendar.getToMainCalendarView

	// --------------------------------------------------------------------------------
	//	Function: selectMonth
	//		Navigate to the month and year
	//
	//	Parameters:
	//		month (string) - month number
	//		year (string) - four digit year
	//
	//	Throws:
	//	 	 an exception if the month and year could not be navigated to
	// --------------------------------------------------------------------------------
	calendar.selectMonth = function selectMonth(month, year) {

		year = parseInt(year);
		// Validate input 
		if (isNaN(year) || year < 1933 || year > 2068) {
			throw new Error("Not a valid year - should be between 1933 and 2068");
		}
		month = parseInt(month);
		if (isNaN(month) || month < 1 || month > 12) {
			throw new Error( "Not a valid month - should be between 1 and 12");
		}
	
		var months = ["", "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];	
		var monthAndYearToSelect = months[month] + " " + year;
	
		// Ensure that month view is selected
		UIALogger.logMessage("Ensuring that we're on the Month calendar view");

		try {
			this.getToCalendarView("Month");
		} catch (e) {
			UIALogger.logError(e.message);
			throw new Error("Did not navigate to month: " + month + " and year: " + year);
		}
		
		//Parse the year and month
		var currYear = this.mainWindow().staticTexts()[0].name().split(" ")[1];
		var currMonthName = this.mainWindow().staticTexts()[0].name().split(" ")[0];
		var currMonth = months.indexOf(currMonthName);
		
		//Find the month and year by tapping the previous and next month buttons
		while (currYear != year || currMonthName != months[month]) {
			UIALogger.logMessage("Navigating to year: " + year + " - Currently on year: " + currYear + " and month: " + currMonthName);		
			var viewButtons = this.mainWindow().buttons();
			if ((currYear <= year && currMonth < month) || (currYear < year && currMonth >= month)) viewButtons["Next month"].tap();
			else if ((currYear >= year && currMonth > month) || (currYear > year && currMonth <= month)) viewButtons["Previous month"].tap();
			currYear = this.mainWindow().staticTexts()[0].name().split(" ")[1];
			currMonthName = this.mainWindow().staticTexts()[0].name().split(" ")[0];
			currMonth = months.indexOf(currMonthName);
		}
		
		//Check to make sure we're really on the specified month and year
		if ((currYear == year) && (currMonth == month)) {
			UIALogger.logMessage( "Successfully navigated to year: " + currYear + " and month: " + currMonthName);		
			return ;
		} else {
			throw new Error("Did not navigate to year: " + year + " and month: " + month);
		}

	} //end calendar.selectMonth

	// --------------------------------------------------------------------------------
	//	Function: goToDay()
	//		Navigate to the month and year and select that day
	//
	//	Parameters:
	//		day (string) - day of month
	//		month (string) - month name
	//		year (string) - four digit year
	//
	//	Throws:
	//	 	An exception if the day was not successfully selected
	// --------------------------------------------------------------------------------
	calendar.goToDay = function goToDay(day, month, year) {
		var months = ["","January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];	
		var buttonName = months[month] + " " + day;

		if (!month || month < 1 || month > 12) throw new Error(month + " is not valid - please use a valid month, from 1 to 12");
		
		try {
			this.selectMonth(month, year);
		} catch (e) {
			UIALogger.logError(e.message);
			throw new Error("Did not navigate to date: " + month + "/" + day + "/" + year);
		}

	
		if (UIATarget.localTarget().model() != 'iPad') {
			UIALogger.logMessage("Choosing date: " + buttonName);
			var dateButton = this.mainWindow().images()[1].buttons().firstWithPredicate("name MATCHES '.*" + buttonName + ".*'");
			if (!dateButton.isValid()) throw new Error("Could not choose: " + buttonName);

			UIATarget.localTarget().delay(1);
			dateButton.tap();
			if (dateButton.withValueForKey(1,"value")) {
				UIALogger.logMessage("Successfully chose date: " + buttonName);				
			} else {
				throw new Error("Could not choose date: " + buttonName);
			}
		} else {
			// Due to <rdar://problem/8895930> Days in iPad Calendar month view are incorrectly named after adding an event
			// this bit of code is left commented out.  At this point, the month should be correct and scrolling to
			// the correct date shouldn't be a problem.
 			
			
/*			var dateElement = this.mainWindow().elements().firstWithPredicate("name endswith '" + buttonName + "'");
			if (!dateElement.isValid()) throw new Error("Could not choose: " + buttonName);
			UIATarget.localTarget().delay(1);

			// Select the date and double tap to go to day view
			dateElement.doubleTap();
			
			// Look for the date string to verify that we're on the right day
			if (this.mainWindow().staticTexts().firstWithPredicate("name endswith '" + buttonName + "'").isValid()) {
				UIALogger.logMessage("Successfully chose date: " + buttonName);	
			} else {
				throw new Error("Could not choose date: " + buttonName);
			}
 */
		}
		return;
	} // end calendar.goToDay 

	// --------------------------------------------------------------------------------
	//	Function: validateCurrentCalendarView () 
	//		Validates that the current view is the same as the expected view.
	//
	//	Parameters:	
	//		expectedView (string) - expected view name
	//
	//	Returns:
	//	 	True if the current view is the expected view, false if not
	//
	//	Throws:
	// 		Throws an error if the expected view could not be reached
	// --------------------------------------------------------------------------------
	calendar.validateCurrentCalendarView = function validateCurrentCalendarView(expectedView)
	{
		var toolbarButton = this._getSegmentedControlContainerElement().segmentedControls()[0].buttons().firstWithPredicate("name beginswith '" + expectedView + "'");
		if (toolbarButton.isValid()) {
			if (toolbarButton.withValueForKey(1, "value").isValid()) {
				UIALogger.logMessage("In expected view" );
				return true;
			} else {
				UIALogger.logError("Not in expected view. Expected view is " + expectedView );
				return false;
			}
		} else {
				throw new Error("Could not find segmented controls.")
		}
	
	} // end calendar.validateCurrentCalendarView 


	// --------------------------------------------------------------------------------
	//	Function: getToCalendarView 
	//		Switches the calendar to the specified view
	//
	//	Parameters:	
	//		viewName (string) - name of the view to switch to:
	//						"Month", "Day" or "List"
	//
	//	Throws:
	//		Throws an error if the calendar view could not be reached
	// --------------------------------------------------------------------------------
	calendar.getToCalendarView = function getToCalendarView(viewName)
	{
		
		this.getToMainCalendarView();
		
		var element = this._getSegmentedControlContainerElement().segmentedControls()[0].buttons().firstWithPredicate("name beginswith '" + viewName + "'");
		
		if (element.isValid()){
			UIALogger.logMessage( "Button for view '" + viewName + "' found");
			element.tap();
		} else {
			throw new Error( "Button for view '" + viewName + "' not found");
		}
	
		if (this.validateCurrentCalendarView(viewName)) {
			return ;
		} else {
			throw new Error( "Could not get to specified calendar view '" + viewName + "'");
		}
	} // end calendar.getToCalendarView


	// --------------------------------------------------------------------------------
	//	Function: useCalendarListSearchToSearchForEvent()
	//		Use the calendar list Search to find event
	//
	//	Parameters:
	//		identifier (String) - title of the event to search for
	//
	//	Returns:
	//		The first event element found
	//
	//	Throws:
	//		An exception if the search was unsuccessful 
	// --------------------------------------------------------------------------------
	calendar.useCalendarListSearchToSearchForEvent = function useCalendarListSearchToSearchForEvent(identifier) {

		UIALogger.logMessage( "Searching for event named " + identifier + " to delete with List Search Bar");
		
		// Switch to List view
		try {
			this.getToCalendarView("List");
		} catch (e) {
			UIALogger.logError(e.message);
			throw new Error("Could not get to list view");
		}

		if (this.eventCountFromListView() == 0) throw new Error("No events in list view");

		var searchBar = this.mainWindow().searchBars()[0];

		this.search(identifier, {searchBarEvalString:searchBar});
		
		// Get the cells in the search results table - need to use isVisible due to the 
		// fact that the search results table is a separate tableView that overlays the list table view
		var searchResults;
		if (UIATarget.localTarget().model() != 'iPad') {
			searchResults = this.mainWindow().tableViews().firstWithPredicate("isVisible == 1").cells();
		} else {
			searchResults = this.mainWindow().popover().tableViews()[0].cells();
		}
			
		if (!searchResults.length){
			//Make sure we're out of the search mode
			var cancelButton = this.mainWindow().buttons()["Cancel"];
			if (!cancelButton.isValid()){
				cancelButton.tap();
			}
			throw new Error("Search for " + identifier + " returned 0 results");
		} else {
			UIALogger.logMessage( "Found event with : '" + identifier + ". Event name: '" + searchResults[0].name() + "'");
			return searchResults[0];		
		}
		
	} // END calendar.useCalendarListSearchToSearchForEvent


	// --------------------------------------------------------------------------------
	//	Function: addNewEvent
	//		Add an event
	//
	//	Parameters:	
	//		eventTitle - title of event.  If none is specifield, the default Calendar title will be used
	//
	//  Options:
	//		location (String) - location of event. If none is specified, the default Calendar location will be used
	//
	//		repeat (String) - # of times event is repeated.  If this is null or an incorrect value, the default value for repeat will be used 
	//				None
	//				Every Day
	//				Every Week
	//				Every 2 Weeks
	//				Every Month
	//				Every Year
	//
	//		alert (String) - If and when to fire an event reminder alert.  If nothing is specified, 'None' will be used
	//				5 minutes before
	//				15 minutes before
	//				30 minutes before
	//				1 hour before
	//				2 hours before
	//
	//		notes (String) - A string that will be added to an event as notes
	//
	//		startEndOptions (object) - a hash of options to pass to calendar.addEventStartAndEndTime
	//
	//	Throws:
	//		Throws an exception if the event could not be created
	// --------------------------------------------------------------------------------
	calendar.addNewEvent = function addNewEvent( eventTitle, options ) {
		var title = ( typeof eventTitle != 'undefined' ) ? eventTitle : "Event";
		if ( !options ) options = new Object();
		var location = ( typeof options.location != 'undefined' ) ? options.location : null;

		var repeat = ( typeof options.repeat != 'undefined' ) ? options.repeat : null;
		var alert = ( typeof options.alert != 'undefined' ) ? options.alert : null;
		var notes = ( typeof options.notes != 'undefined' ) ? options.notes : null;
		
		var startEndOptions = ( typeof options.startEndOptions != 'undefined' ) ? options.startEndOptions : null;
		var titleElement = this.mainWindow().tableViews().firstWithPredicate("isVisible == 1");

		//use goToDay() to get to the date before trying to create an event
		if (startEndOptions) {
			this.goToDay(startEndOptions.starts.getDate(), startEndOptions.starts.getMonth() + 1, startEndOptions.starts.getFullYear());
		}			

		UIATarget.localTarget().delay(2);
//		try {
//			this.getToAddEventDetailView("Title");
//		} catch (e) {
//			if (UIATarget.localTarget().model() != 'iPad') {
//				UIALogger.logError(e.message);
//				throw new Error("Could not add a new event - could not get to the 'Title' detail view");
//			}
//		}	
		
		try {
			this.getToAddEventView();
		} catch (e) {
			UIALogger.logError(e.message);
			throw new Error("Could not get to '" + detailView + "'");
		}
		
		UIATarget.localTarget().pushTimeout(0.5);
		
		UIATarget.localTarget().delay(2); 
		// make sure we don't run the following search on a huge list of calendar objects: <rdar://8242227>
		
		var titleLocationTable = this._getAddEventElement().tableViews()[0];		
		UIALogger.logMessage("Setting title to: " + eventTitle);
		titleLocationTable.cells().firstWithPredicate("ANY textFields.value == 'Title'").textFields()[0].tap();
		titleLocationTable.cells().firstWithPredicate("ANY textFields.value == 'Title'").textFields()[0].setValue(eventTitle);

		
		//Until we get synthetic typing, need to move focus away from the title textfield in order to enable the done button
		var locationCell = titleLocationTable.cells().firstWithPredicate("ANY textFields.value == 'Location'");
		locationCell.tap()
		
		// Set the event location
		if (location) {
				UIALogger.logMessage("Setting location to: " + location);
			locationCell.textFields()[0].setValue(location);
		}

//		if (UIATarget.localTarget().model() != 'iPad') this.mainWindow().navigationBar().buttons().firstWithName("Done").tap();
		UIATarget.localTarget().delay(2);
		UIATarget.localTarget().popTimeout();
		
		// Add start and end times
		try {
			if (startEndOptions) this.addEventStartAndEndTime(startEndOptions);
		} catch (e) {
			UIALogger.logError(e.message);
			UIALogger.logMessage("Could not set the event start and end time.  Continuing on...");
		}

		// Set repetition of an event
		try {
			if (repeat){
				UIALogger.logMessage("Setting repetition to: " + repeat);
				this.setEventRepeat(repeat);
			} 
		} catch (e) {
			UIALogger.logError(e.message);
			UIALogger.logMessage("Could not set the event repetition.  Continuing on...");
		}

		// Set reminder alert for an event
		try {
			if (alert){
				UIALogger.logMessage("Setting alert to: " + alert);
				this.setEventReminderAlert(alert);
			} 
		} catch (e) {
			UIALogger.logError(e.message);
			UIALogger.logMessage("Could not set the event alert.  Continuing on...");
		}
				
		
		// Add notes to an event
		try {
			if (notes){
				UIALogger.logMessage("Settings notes to: " + notes);
				this.addEventNotes(notes);
			}
		} catch (e) {
			UIALogger.logError(e.message);
			UIALogger.logMessage("Could not set the event notes.  Continuing on...");
		}
		
		UIALogger.logMessage("Tapping 'Done' button to save event.");
		var doneButton = this._getAddEventElement().navigationBar().buttons()["Done"];
		if (doneButton.isValid()) {
			UIATarget.localTarget().delay(1); //wait for animation
			doneButton.tap();
			// Wait a bit for animations to settle down
			UIATarget.localTarget().delay(2);
		}		
		//doneButton.tap();		
		return ;

	} // end cal_addNewEvent
	

	// --------------------------------------------------------------------------------
	//	Function: addEventStartAndEndTime 
	//		Add an event start and end time.  
	//
	//	Parameters:	
	//		starts ( UIADate|Date object)  - a Date object representing the date and time the event should start. 
	//						by default, the event will be added on today's date
	//
	//		ends ( UIADate|Date object) - a Date object representing the date and time the event should end
	//						by default, the event will be added on today's date
	//
	//		allDay ( boolean ) - true if the event is all day.  by default, this is false.
	//
	// Throws:
	//		Throws an error if the start and end time could not be set
	// --------------------------------------------------------------------------------
	calendar.addEventStartAndEndTime = function addEventStartAndEndTime( startEndOptions ) {
		var starts = ( typeof startEndOptions.starts != 'undefined' ) ? startEndOptions.starts : null;
		var ends = ( typeof startEndOptions.ends != 'undefined' ) ? startEndOptions.ends : null;
		var allDay = ( typeof startEndOptions.allDay != 'undefined' ) ? startEndOptions.allDay : null;

		try {
			this.getToAddEventDetailView("Start")
		} catch (e) {
			UIALogger.logError(e.message);
			throw new Error("Could not navigate to start and end time detail view");
		}

		try {
			if (starts) {
				this._setEventDatePicker(starts);
			} 
		} catch (e) {
			UIALogger.logError(e.message);
			throw new Error("Could not set the start time date picker");
		}

		if (allDay) {
			UIALogger.logMessage("Setting switch for All-day Event.");
			var allDaySwitch = this._getAddEventElement().tableViews().firstWithPredicate("isVisible == 1").cells().firstWithName("All-day").switches()[0];
			allDaySwitch.setValue(1);
		} else {
			UIALogger.logMessage("Setting end time for Event.");

			try {
				if (ends) this._setEventDatePicker(ends);
			} catch (e) {
				UIALogger.logError(e.message);
				throw new Error("Could not set the end time date picker");			
			}
			
		}
		
		UIALogger.logMessage("Tapping 'Done' button to save event times.");

		var doneButton = this._getAddEventElement().navigationBar().buttons()["Done"];
		if (doneButton.isValid()) {
			doneButton.tap();
			// Wait a bit for animations to settle down
			UIATarget.localTarget().delay(2);
		}
		return ;

	} // end calendar.addEventStartAndEndTime



	// --------------------------------------------------------------------------------
	//	calendar._convertHours( hour ) - convert hour in 0-23 format returned from Date object to 1-12 to use 
	//								when scrolling through the hour picker when adding an event start 
	//								and end time in mobile calendar
	//
	//	Parameters:	
	//		hour ( integer )
	//
	//  Returns: 
	//		( integer ) - value from 1-12
	// --------------------------------------------------------------------------------
	calendar._convertHours = function _convertHours( hour ) {
	
		return ( hour % 12 ) ? hour % 12 : 12;
	
	} // end _convertHours



	// --------------------------------------------------------------------------------
	//	calendar._roundMinutes( minutes ) - round minutes to nearest 5 minutes to use when scrolling through
	//									minutes picker when adding an event start and end time in mobile calendar
	//								
	//
	//	Parameters:	
	//		minutes ( integer ) - minutes to scroll the picker
	//
	//  Returns: 
	//		( String ) - value from 00-55 in 5 minute increments
	// --------------------------------------------------------------------------------
	calendar._roundMinutes = function _roundMinutes( minutes ) {
		var roundedMinutes = ( minutes % 5 >= 3 ) ? minutes + ( 5 - ( minutes % 5 ) ) : minutes - ( minutes % 5 ) ;
		if ( roundedMinutes < 10 ) roundedMinutes = "0" + roundedMinutes;
		if ( roundedMinutes > 55 ) roundedMinutes = '00';
		return roundedMinutes;
	} // end _roundMinutes



	// --------------------------------------------------------------------------------
	//	calendar._convertMonth( month ) - given a month number (0-11), return the 3-letter month abbreviation 
	//								
	//
	//	Parameters:	
	//		month ( integer ) - number of month (0-11)
	//
	//  Returns: 
	//		( String ) - 3-letter month abbreviation
	// --------------------------------------------------------------------------------
	calendar._convertMonth = function _convertMonth( month ) {
		var months = [ "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" ];
		return months[ month ];
	} // end _convertMonth


	// --------------------------------------------------------------------------------
	//	calendar._setEventDatePicker( date ) - given a Date object, scroll the picker to the correct date
	//								
	//
	//	Parameters:	
	//		date ( Date|UIADate object ) - date to set the pickers to
	//
	//  Throws:  
	//		Throws an exception if the event date could not be set for any reason
	//
	// --------------------------------------------------------------------------------
	calendar._setEventDatePicker = function _setEventDatePicker( date ) {
		UIATarget.localTarget().delay(5);
		//Get the date currently in the Starts field
		var currentPickerDateElement = this._getAddEventElement().tableViews()[0].elements().firstWithPredicate('name beginswith "Starts"');
		var currentPickerDate;
		var today = (date instanceof UIADate) ? new UIADate() : new Date();
		var dateArray = [];
		var scrollUP = true;
		var day;
		var dayEnum = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
		if ( !currentPickerDateElement.isValid() ) throw new Error("Could not find the date picker");
		
		currentPickerDate = new Date( currentPickerDateElement.name() );
		UIALogger.logMessage( "Current picker date: " + currentPickerDate + ", scrolling to " + date );
	
		if (!date) throw new Error( "Invalid date object");

		if (currentPickerDate.getTime() > date.getTime()) {
			UIALogger.logMessage( "Current start date is in the past. Scrolling picker wheels down." );
			scrollUP = false;
		} else {
			UIALogger.logMessage( "Current start date is in the future.  Scrolling picker wheels up." );
		}

		if (today.getMonth() == date.getMonth() && today.getDate() == date.getDate()) {
			day = "Today";
		} else {
			day = this._convertMonth( date.getMonth() ) + " " + date.getDate() + ", " + dayEnum[date.getDay()];
		}
		dateArray.push(day);
	
		//Convert the date hour value (0-23 to 1-12) and push it into our array
		var hour = this._convertHours( date.getHours() );
		dateArray.push(hour);
	
		//Round the minutes to the nearest interval of 5 and push it into our array
		var min = this._roundMinutes( date.getMinutes() );
		dateArray.push(min);
	
		//Figure out what if the time is PM or AM
		if (date.getHours() > 11) dateArray.push("PM");
		else dateArray.push("AM"); 
	
	
		var picker = this._getAddEventElement().pickers()[0];
		UIATarget.localTarget().delay(5);
		try {
			// Iterate through the Picker tables and scroll them to the correct values
			for (var i = 0; i < dateArray.length - 1; i++) {
				UIALogger.logMessage("Scrolling picker wheel to " + dateArray[i]);
				UIAUtility.scrollWheelToValueWithOptions(picker.wheels()[i], dateArray[i], {direction:scrollUP});
			} // end for loop
		
			UIALogger.logMessage("Scrolling picker wheel to " + dateArray[i]);
			if (dateArray[i] == "AM" && picker.wheels()[i].value() != "AM") {
				UIAUtility.scrollWheelToValueWithOptions(picker.wheels()[i], dateArray[i], {direction:0});
				return ;
			} else if (dateArray[i] == "PM" && picker.wheels()[i].value() != "PM") {
				UIAUtility.scrollWheelToValueWithOptions(picker.wheels()[i], dateArray[i], {direction:1});
				return ;
			} else {
				return ;			
			}
		} catch (e) {
			UIALogger.logError(e.message);
			throw new error("Could not scroll picker wheels to select date and time");
		}
	} // end calendar._setPickerDate( date )


	// --------------------------------------------------------------------------------
	//	Function: setEventRepeat
	//		Given a value for repeat, set the frequency of the Event
	//							
	//								
	//	Parameters:	
	//		repeat ( String ) - the frequency of the event
	//
	//  Throws: 
	//		Throws an exception if the value could not be set for any reason
	//	
	//
	// --------------------------------------------------------------------------------
	calendar.setEventRepeat = function setEventRepeat( repeat ) {
	
		var repeatArray = { "None":"Never",
			"Every Day":"Daily",
			"Every Week":"Weekly",
			"Every 2 Weeks":"Biweekly",
			"Every Month":"Monthly",
			"Every Year":"Yearly" };
	
		if (!repeatArray[repeat]) {
			UIALogger.logError("Repetition: " + repeat + " is not a valid option");
			throw new Error("Repetition: " + repeat + " is not a valid option");
		}
		
		try {
			this.getToAddEventDetailView("Repeat");
		} catch(e) {
			UIALogger.logError(e.message);
			throw new Error("Could not set event repetition");
		}

		var repetitionTable = this._getAddEventElement().tableViews()[0];
		var repetitionTableCell = repetitionTable.elements().firstWithPredicate("name contains '" + repeat + "'");

		if (!repetitionTableCell.isValid()) {
			UIALogger.logError( "Repeat: " + repeat + " not valid for repeat. Repeat set to 'None'");
			repetitionTable.elements().firstWithPredicate("name contains 'None'").tap();
			this._getAddEventElement().navigationBar().buttons()["Done"].tap();	
			return ;
		}

		UIALogger.logMessage( "Setting repeat to " + repeat );
		repetitionTableCell.tap();			
	
		// Get out of the Repeat Event view
		var doneButton = this._getAddEventElement().navigationBar().buttons()["Done"];
		if (doneButton.isValid()) {
			doneButton.tap();
			// Wait a bit for animations to settle down
			UIATarget.localTarget().delay(2);
		}
		
		// Verify the change has been made
		UIALogger.logMessage( "Verifying " + repeatArray[ repeat ] + " event repetition." );
		
		var repeatTableCell = this._getAddEventElement().tableViews()[0].cells().firstWithPredicate("name contains 'Repeat, " + repeatArray[repeat] + "'");
		
		if (!repeatTableCell){
			throw new Error( "Could not set the event repetition");
		} else {
			UIALogger.logMessage( "Verified " + repeatArray[ repeat ] + " event repetition." );
			return ;
		}	
	
	} // calendar.setEventRepeat


	// --------------------------------------------------------------------------------
	//	Function: setEventReminderAlert	
	//		Given a value for an alert fire, set the alert interval
	//							
	//								
	//	Parameters:	
	//		alert ( String ) - a time interval before the event to fire the alert
	//
	//  Throws: 
	//		Throws an exception if the value could not be set for any reason
	//	
	//
	// --------------------------------------------------------------------------------
	calendar.setEventReminderAlert = function setEventReminderAlert( alert ) {
			
		if (!alert) {
			UIALogger.logError("Alert: " + alert + " is not a valid option");
			throw new Error("Alert: " + repeat + " is not a valid option");
		}
		
		try {
			this.getToAddEventDetailView("Alert");
		} catch(e) {
			UIALogger.logError(e.message);
			throw new Error("Could not set alert fire interval");
		}
		UIATarget.localTarget().delay(3);
		var alertTable = this._getAddEventElement().tableViews()[0];
		var alertTableCell = alertTable.cells().firstWithPredicate("name contains '" + alert + "'");
		
		alertTable.logElementTree();
		if (!alertTableCell.isValid()) {
			UIALogger.logError( "Alert: " + alert + " not valid for alert interval. Alert set to 'None'");
			alertTable.elements().firstWithPredicate("name contains 'None'").tap();
			this._getAddEventElement().navigationBar().buttons()["Done"].tap();	
			return ;
		}
		
		UIALogger.logMessage( "Setting alert to " + alert );
		alertTableCell.tap();			
		
		// Get out of the Repeat Event view
		var doneButton = this._getAddEventElement().navigationBar().buttons()["Done"];
		if (doneButton.isValid()) {
			doneButton.tap();
			// Wait a bit for animations to settle down
			UIATarget.localTarget().delay(2);
		}
		
		// Verify the change has been made
		UIALogger.logMessage( "Verifying '" + alert + "' reminder alert ." );
		
		var alertTableCell = this._getAddEventElement().tableViews()[0].cells().firstWithPredicate("name contains 'Alert, " + alert + "'");
		
		if (!alertTableCell){
			throw new Error( "Could not set the alert");
		} else {
			UIALogger.logMessage( "Verified " + alert + " alert." );
			return ;
		}	
		
	} // calendar.setEventAlert
	
	

	// --------------------------------------------------------------------------------
	//	calendar.addEventNotes( notes ) - given a value for notes, add notes to the event
	//								Assumes that the view is already in "Add Event" 
	//								
	//
	//	Parameters:	
	//		notes ( String ) - Notes to add to the event
	//
	//  Throws: 
	//		throws an exception if the notes could not be added for any reason
	//
	// --------------------------------------------------------------------------------
	calendar.addEventNotes = function addEventNotes( notes ) {
//		if (UIATarget.localTarget().model() != 'iPad') this.getToAddEventDetailView("Notes");
		UIATarget.localTarget().delay(2);
		var notesTextField;
		if (UIATarget.localTarget().model() == 'iPad') 
			notesTextField = this._getAddEventElement().tableViews()[0].cells().firstWithName("Notes");
		else 
			notesTextField = this.mainWindow().tableViews()[0].cells()[0];
		if (!notesTextField.isValid()) {
			throw new Error( "Could not enter notes for the event." );			
		}

		// Add notes to the text field
		UIALogger.logMessage( "Setting notes for event: " + notes + "." );			
		notesTextField.setValue(notes);
		if (UIATarget.localTarget().model() == 'iPad') return;

		var doneButton = this._getAddEventElement().navigationBar().buttons()["Done"];
		if (doneButton.isValid()) {
			UIALogger.logMessage( "Tapping Done button to return to Add Event view." );
			doneButton.tap();
			// Wait a bit for animations to settle down
			UIATarget.localTarget().delay(2);
		} else {
			throw new Error( "Could not find the Done button." );
		}

		return;
		
	} // end calendar.addEventNotes

	// --------------------------------------------------------------------------------
	//	Function: deleteCalendarEvent 
	//		Deletes a calendar event.  No validation is performed.
	//
	//	Optional Parameters:
	//		eventTitle (String ) - event name
	//		deleteAllEvents (boolean) - delete All events
	//		deleteRecurringEvents ( boolean ) - if the event is a repeating event, if 
	//									deleteAllEvents is true, all future events
	//									will be deleted.  NOTE: this will be false
	//									by default, so only one event will be deleted
	//
	//  Throws: 
	//		Throws an exception if the event could not be deleted for any reason
	//
	// --------------------------------------------------------------------------------
	calendar.deleteCalendarEvent = function deleteCalendarEvent(options) {
		if (!options) options = new Object();
		var eventTitle = (typeof options.eventTitle != 'undefined') ? options.eventTitle : null;
		var deleteAllEvents = (typeof options.deleteAllEvents != 'undefined') ? options.deleteAllEvents : false;
		var deleteRecurringEvents = (typeof options.deleteRecurringEvents != 'undefined') ? options.deleteRecurringEvents : false;
		
		if (deleteAllEvents) deleteRecurringEvents = true;
		
		//This should be on the calendar list view 
		this.getToCalendarView("List");

		function deleteEvent(event, deleteAllOccurrancesOfEvent) {

			if (!event.isValid()) {
				event.logElementTree();
				throw new Error("Event element is not valid.");
			} 
			
			// Wait for animation to finish
			UIATarget.localTarget().delay(2);
			
			event.tap();
			
			// Tap Edit
			UIALogger.logMessage( "Tapping on Edit to navigate to event edit view");	
			// Wait for animation to finish
			UIATarget.localTarget().delay(2);
			
			var editButton = calendar._getElementContainingButtonWithName("Edit").buttons().firstWithName("Edit");	
			if (!editButton.isValid()){
				throw new Error( "Could not find the Edit button.");
			}
			editButton.tap();
			
			// Wait for animation to finish
			UIATarget.localTarget().delay(2);
			
			// Find and tap the Delete Event button
			var deleteButton = calendar._getAddEventElement().tableViews()[0].scrollToElementWithName("Delete Event");
			if (!deleteButton.isValid()) {
				UIALogger.logError( "Could not find Delete Event Button.");
			}
			
			deleteButton.tap();
			UIATarget.localTarget().delay(2);
			
			var actionSheet;
			if (UIATarget.localTarget().model() == 'iPad')
				actionSheet = calendar.mainWindow().popover().actionSheet();
			else
				actionSheet = calendar.actionSheet();
			
			// If the event is non-repeating, tap the "Delete Event" button in the action sheet
			if (actionSheet.isValid()) {
				if (actionSheet.buttons().firstWithName("Delete Event").isValid()) {
					actionSheet.buttons().firstWithName("Delete Event").tap();
				} else {
					if (!deleteAllOccurrancesOfEvent) {
						actionSheet.buttons().firstWithName("Delete This Event Only").tap();
					} else {
						actionSheet.buttons().firstWithName("Delete All Future Events").tap();
					}
				}
				
			} else {
				throw new Error("Could not find the action sheet to confirm event deletion");
			}
		} // end deleteElement
		
		var eventElement;

		if (!deleteAllEvents) {
			eventElement = calendar.useCalendarListSearchToSearchForEvent(eventTitle);
			deleteEvent(eventElement, deleteRecurringEvents);
		} else {
			var numberOfElements = calendar.mainWindow().tableViews()[0].cells().length;

			//Prevent an infinite loop, in case numberOfElements never gets smaller in the loop
			var boundaryCondition = numberOfElements + 1;
			for (var i = 0; (numberOfElements > 0) && (i < boundaryCondition); i++) {
				eventElement = calendar.mainWindow().tableViews()[0].cells()[0];
				eventElement.scrollToVisible();
				UIALogger.logMessage("Deleting element with name: " + eventElement.name());
				deleteEvent(eventElement, deleteRecurringEvents);
				UIATarget.localTarget().delay(2);
				numberOfElements = calendar.mainWindow().tableViews()[0].cells().length;
				UIALogger.logMessage("Number of elements left to delete: " + numberOfElements);
			} 
			if (i == boundaryCondition) {
				this.logElementTree();
				throw new Error("Reached the max number of attempts to delete all calendar events");
			}
		}
		
		return ;
	} // end calendar.deleteCalendarEvent

    
    // --------------------------------------------------------------------------------
	//	Function: selectCalendars 
	//		select calendars to show or hide from the available calendars
	//
	//	Optional Parameters:
	//		calendarSettings (String or Array ) - To hide or show all calendars, 
    //                          pass in the string "Show All" or "Hide All"
    //                      
    //                          Otherwise, to set the visibility of individual 
    //                          calendars, pass in an associative array with each element in the 
    //                           having the format:
    //                          <calendar_name_strimg:<numberic_boolean_value>
    //
    //                          For example:
    //                          selectCalendars({"Birthdays":1, "Calendar":0})
	//
	//  Throws: 
	//		Throws an exception if the visibility of any calendar(s) could not be successfully 
    //      be set or if the calendar does not exist in the list
	//
	// --------------------------------------------------------------------------------
    calendar.selectCalendars = function selectCalendars(calendarSettings) {

        // Return to the main calendar view
        this.getToMainCalendarView();
        
        // Call the _getElementContainingButtonWithName convenience function to get the parent element of the "Calendars" button
        var calendarButton = this._getElementContainingButtonWithName("Calendars");
        
        // Tap the "Calendars button to access the available calendars 
        calendarButton.buttons()["Calendars"].tap();

        //Let animation complete        
        UIATarget.localTarget().delay(2);

        var calendarList;
        
        // Get the list of calendars
        if (UIATarget.localTarget().model() == 'iPad') {
            calendarList = this.mainWindow().popover().tableViews()[0];
        } else {
            calendarList = this.mainWindow().tableViews()[0];
        }
        
        // This branch is to set toggle between "Hide All Calendars" and "Show All Calendars"
        if (typeof calendarSettings == 'string') {
            
            var allCalendarsButton = calendarList.cells().firstWithPredicate("name contains 'All Calendars'");

            // Check to see if the argument is already set
            if (!allCalendarsButton.name().match(calendarSettings))  {
                UIALogger.logMessage(calendarSettings + " Calendars already set");
                return;
            } else {
                allCalendarsButton.tap();
                
                //If there are a lot of calendars to turn on, give the checkmark animation a chance to complete
                UIATarget.localTarget().delay(2);
            }
            allCalendarsButton = calendarList.cells().firstWithPredicate("name contains 'All Calendars'");
            
            // Verify that the setting was toggled
            if (allCalendarsButton.name().match(calendarSettings)) throw new Error("Did not set '" + calendarSettings + " Calendars'");
            else UIALogger.logMessage("Successfully set '" + calendarSettings + " Calendars'");

        
        // This branch is to set individual calendars in the list
        } else {
        
            var calendarCell;
            var calendarSettingBool;

            // Lower the timeout to 1 second to speed things up a bit if an element can't be found in the view hierarchy
            UIATarget.localTarget().pushTimeout(1);
            
            // Loop through the calendarsAndSettingsHash and set the values accordingly
            for (cal in calendarSettings) {
                
                // Convert the calendar setting (0 or 1) to a log-friendly string
                UIALogger.logDebug(calendarSettings[cal]);
                calendarSettingBool = ((parseInt(calendarSettings[cal], 10)) ? "On" : "Off");
                UIALogger.logDebug(calendarSettingBool);
                calendarCell = calendarList.cells().firstWithName(cal);
                
                // Log an error if the calendar does not exist
                if (!calendarCell.isValid()) throw new Error("Calendar " + cal + " does not exist in this list");
                
                // Else, Try to hide/show the calendar 
                else {

                    // Is the calendar currently hidden or showing?
                    var calendarIsShowingBool = calendarCell.withValueForKey(1, "value").isValid();

                    // Check if the current visibility does not equal the argument setting
                    if (!calendarIsShowingBool == calendarSettings[cal]) {
                        UIALogger.logMessage("Setting the '" + cal + "' calender to '" + calendarSettingBool + "'");
                        calendarCell.tap();   
                        
                        //Let checkmark animation complete                                
                        UIATarget.localTarget().delay(1);

                        // Verify that the value was successfully set
                        if (calendarCell.withValueForKey(1, "value").isValid() && calendarSettings[cal]) {
                            throw new Error("Could not successfully set the '" + cal + "' calender to '" + calendarSettingBool + "'");
                            calendar.logElementTree();
                        }
                        else UIALogger.logMessage("Successfully set the '" + cal + "' calender to '" + calendarSettingBool + "'");

                    } else 
                        UIALogger.logMessage("The '" + cal + "' calender is already set to '" + calendarSettingBool + "'");     
                }
                
            }
            UIATarget.localTarget().popTimeout();

        }

        return;

    } // end calendar.selectCalendars
    
    
    // --------------------------------------------------------------------------------
	//	Function: addCalendars 
	//		add new calendars to the device's available calendars
	//
	//	Optional Parameters:
	//		calendars (Array ) - Pass in an associative array with each element in the 
    //                           array having the format:
    //                          "<calendar_name_strimg>":"<calendar_color_string>"
    //
    //                          If no color is needed, an empty string is required.
    //
    //                          For example:
    //                          {"Work":"Orange", "Home":"Green", "Birthdays":""}
	//
	//  Throws: 
	//		Throws an exception if a calendar could not be added to the list for any
    //      reason
	// --------------------------------------------------------------------------------
    calendar.addCalendars = function addCalendars(calendars) {
        this.getToMainCalendarView();
        var calendarButton = this._getElementContainingButtonWithName("Calendars");
        var errorMsg;
        
        calendarButton.buttons()["Calendars"].tap();

        
        //Let animation complete        
        UIATarget.localTarget().delay(2);
        
        
        var calendarView;
        if (UIATarget.localTarget().model() == 'iPad') {
            calendarView = this.mainWindow().popover();
        } else {
            calendarView = this.mainWindow();
        }
        
        // Check for the view's navigation bar
        var navBar = calendarView.navigationBar();
        if (!navBar.isValid()) throw new Error("Could not find the calendar view navigation bar");
        
        // Check for the 'Edit' button and tap it
        var editButton = navBar.buttons()["Edit"];
        if (!editButton.isValid()) throw new Error("Could not find the 'Edit' button");
        editButton.tap()
        
        // Allow any animations to cease
        UIATarget.localTarget().delay(2);

        var addCalendarButton;
        var table;
        var calendarNameField;
        var calendarColor;
     

        UIATarget.localTarget().pushTimeout(1);

        // Iterate through the array of calendar names and colors
        for(cal in calendars) {

            // Check for the 'Add Calendar...' button in the table
            addCalendarButton = calendarView.tableViews()[0].cells().firstWithPredicate("name beginswith 'Add Calendar'");
            if (!addCalendarButton.isValid()) {
                
                // If the 'Add Calendar...' button could not be found, set the exception message and break out of the loop
                errorMsg = "Could not find the 'Add Calendar...' button";   
                break;
            }
            
            // Scroll the table to the 'Add Calendar...' button 
            addCalendarButton.scrollToVisible();

            // Give the animation a chance to settle
            UIATarget.localTarget().delay(1);
            
            // Tap the 'Add Calendar...' button
            addCalendarButton.tap();
            UIATarget.localTarget().delay(1);
        
            
            var table = calendarView.tableViews()[0];

            // Find 
            var calendarNameField = table.cells().firstWithPredicate("ANY textFields.value == 'Calendar Name'").textFields()[0];
            if (!calendarNameField.isValid()) {
                
                // If the 'Calendar Name' button could not be found, set the exception message and break out of the loop                
                errorMsg = "Could not find the 'Calendar Name' text field";
                break;
            }
            calendarNameField.tap();
            this.enterTextInTextField(calendarNameField, cal);
            this.keyboard().buttons().firstWithPredicate("name beginswith[c] 'return'").tap();
            calendarColor = calendars[cal];
            
            //If a color was specified for the calendar, then choose the color
            if (calendarColor) {
                var calendarColorCell = table.cells().firstWithName(calendarColor);
                if (!calendarColorCell.isValid()) { 
                    
                    // If the color specified could not be found, set the exception message and break out of the loop                                    
                    errorMsg = "Could not find a calendar color with the name '" + calendars[cal] + "'";
                    break;
                }
                calendarColorCell.scrollToVisible();
                calendarColorCell.tap();
            }

            
            navBar.buttons()["Done"].tap();

            //Give the animation to settle
            UIATarget.localTarget().delay(2);

            // Verify that the calendar was added
            var calendarCell = calendarView.tableViews()[0].cells().firstWithName(cal);
            if (!calendarCell.isValid()) {
                errorMsg = "Could not verify that the calendar '" + cal + "' was added";
                break;
            }            

        }
        
        UIATarget.localTarget().popTimeout();
        
        if (errorMsg) throw new Error(errorMsg);

        return;
                                                            
    } // end calendar.addCalendars
    
    
    
    // --------------------------------------------------------------------------------
	//	Function: addCalendars 
	//		add new calendars to the device's available calendars
	//
	//	Optional Parameters:
	//		calendars (Array ) - Pass in an associative array with each element in the 
    //                           array having the format:
    //                          "<calendar_name_strimg>":"<calendar_color_string>"
    //
    //                          If no color is needed, an empty string is required.
    //
    //                          For example:
    //                          {"Work":"Orange", "Home":"Green", "Birthdays":""}
	//
	//  Throws: 
	//		Throws an exception if a calendar could not be added to the list for any
    //      reason
	// --------------------------------------------------------------------------------
    calendar.deleteCalendars = function deleteCalendars(calendars) {
    //Development on this is blocked by <rdar://problem/9237466> Cannot delete calendars (regardless of there being multiple calendars)    
        
    } // end calendar.deleteCalendars
     
    
    
    
} // end if