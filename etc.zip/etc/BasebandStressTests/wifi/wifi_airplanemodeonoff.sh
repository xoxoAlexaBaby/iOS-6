# This script will put device at Settings Pane, then turn on/off Airplane Mode, and check the WiFi status

#!/bin/sh -x

i=1
s=0
TMP="/var/log/tmp.txt"

pushd /usr/local/bin/

echo "Navigate to Settings Pane first, it is OK if you see something like: 'ERROR: Unable to find application bundle!'"
/usr/local/etc/scripter/general/ExecuteTest.js settingsTest_setAirplaneMode off >> $TMP

while true
do
echo "Running Airplane Test $i Cycle"
interact -uiautomation YES "s = app.mainWindow().tableViews()[0].cells()[\"Airplane Mode\"].switches()[0]; s.setValue(parseInt(1))"

wifi_state=`mobilewifitool -- device power -i en0`

if [ "$wifi_state" = "WiFiDevice Power: ON" ]; then
	echo "WiFi power is on after airplane mode turned on, stop the test"
	echo "$wifi_state"
	break;
else
	echo "WiFi power is off after airplane mode turned on"
fi

interact -uiautomation YES "s = app.mainWindow().tableViews()[0].cells()[\"Airplane Mode\"].switches()[0]; s.setValue(parseInt(0))"

wifi_state=`mobilewifitool -- device power -i en0`

if [ "$wifi_state" = "WiFiDevice Power: ON" ]; then
	echo "WiFi power is on after airplane mode turned off"
else
	echo "WiFi power is off, stop the test"
	echo "$wifi_state"
	break;
fi
i=`expr $i + 1`
done
