/*
 Class: UIApp (notes)
 Notes object
 */
#import "../libs/SpringBoard.js"
#import "../libs/UIAAppMailAdditions.js"

notes = UIAApp.application("Notes", "com.apple.mobilenotes");

if (typeof notes != 'undefined') {

	notes.NOTE_SHARING_OPTION_EMAIL = "Email";
	notes.NOTE_SHARING_OPTION_PRINT = "Print";
    
	notes.views = {};
	notes.views.NOTE_EDIT = 1;
	notes.views.NOTE_VIEW = 2;
	notes.views.NOTES_LIST = 4;
	notes.views.NOTE_DELETE = 8;
	notes.views.NOTES_SEARCH = 16;
	notes.views.NOTES_ADDRESS_ACTION_SHEET = 32;
	notes.views.NOTE_EMAIL = 64;
	
	notes.stringForView = function (view) {
		switch(view) {
			case notes.views.NOTE_EDIT : return "NoteEdit";
			case notes.views.NOTE_VIEW : return "NoteView";
			case notes.views.NOTES_LIST : return "NotesList";
			case notes.views.NOTE_DELETE : return "NoteDelete";
			case notes.views.NOTES_SEARCH : return "NotesSearch";
			case notes.views.NOTES_ADDRESS_ACTION_SHEET : return "NotesAddressActionSheet";
			case notes.views.NOTE_EMAIL : return "NoteEmail";
		}
		
		return view;
	}
	
	notes.notesListTable = function notesListTable() {
		if (UIATarget.localTarget().model() == 'iPad') {
			if (this.isLandscape()) 
				return this.mainWindow().images().firstWithValueForKey(1, "isVisible").tableViews()[0];
			else
				return this.mainWindow().popover().tableViews()[0];
		} else
			return this.mainWindow().tableViews()[0];
	}
	
	//	-------------------------------------------------------------------------------------------------
	//	Function: isInSplitView
	//		Returns true if the app is in the split view
	//
	//	Parameters: 
	//		None
	//
	//	Returns: 
	//		true if the app is in the split view
	//
	//	Throws: 
	//		Error
	//	-------------------------------------------------------------------------------------------------
	notes.isInSplitView = function isInSplitView() {
		return (UIATarget.localTarget().model() == 'iPad' && this.isLandscape());
	}
	
	//	-------------------------------------------------------------------------------------------------
	//	Function: getCurrentView
	//		Returns a mask representing the current view. 
	//
	//	Parameters:
	//		None
	//
	//	Notes:
	//		Here are the possible values the mask value can be used with:
	//			- notes.views.NOTE_EDIT
	//			- notes.views.NOTE_VIEW
	//			- notes.views.NOTES_LIST
	//			- notes.views.NOTE_DELETE
	//			- notes.views.NOTES_SEARCH
	//			- notes.views.NOTES_ADDRESS_ACTION_SHEET
	//			- notes.views.NOTE_EMAIL
	//
	//	Returns:
	//		(string) - returns a mask representing the current view. 
	//
	//	Throws: Error
	//	-------------------------------------------------------------------------------------------------
	notes.getCurrentView = function getCurrentView() {

		var navBar = notes.navigationBar().withPredicate("isVisible == 1"); //give the nav bar a longer timeout to account for launch delays
		
		//helper function we can wrap the push and pop timeouts around
		var currentViewHelper = function () {
			
			if (UIATarget.localTarget().model() == 'iPad') {
				if (navBar.isVisible()) {
					var searchBarContainer = (notes.isInSplitView()) ? notes.mainWindow().images().firstWithValueForKey(1, "isVisible") : notes.mainWindow().popover();
					var searchBar = searchBarContainer.searchBars()[0];
					if (searchBar.hasKeyboardFocus()) {
						return notes.views.NOTES_SEARCH;
					}
					
					var textView = notes.mainWindow().textViews()[0];
					if (textView.isVisible()) {
						var currentTextView = (textView.hasKeyboardFocus()) ? notes.views.NOTE_EDIT : notes.views.NOTE_VIEW;
						if (notes.isInSplitView()) 
							return (currentTextView | notes.views.NOTES_LIST);
						else 
							return currentTextView;
					}
				}
				
				if (notes.mainWindow().popover().tableViews().firstWithPredicate("name == 'Notes list' or name == 'No Notes'").isVisible()) {
					return notes.views.NOTES_LIST;
				}
			} else {
				if (navBar.isVisible()) {
					if (navBar.withPredicate("name beginswith 'Notes'").isValid() && 
						notes.mainWindow().tableViews()[0].isValid()) {
						return notes.views.NOTES_LIST;
					} 
					
					var textView = notes.mainWindow().textViews()[0];
					if (textView.isVisible()) {
						if (textView.hasKeyboardFocus()) {
							return notes.views.NOTE_EDIT;
						} else {
							return notes.views.NOTE_VIEW;
						}
					}
				} 
				
				var searchBar = notes.mainWindow().tableViews()[0].searchBars()[0];
				if (searchBar.hasKeyboardFocus()) {
					return notes.views.NOTES_SEARCH;
				}
			}
	
			if (notes.isDisplayingEmailComposeSheet()) {
				return notes.views.NOTE_EMAIL;
			}
			
			if (UIATarget.localTarget().model() == 'iPad') 
				var actionSheet = notes.mainWindow().popover().actionSheet();
			else 
				var actionSheet = notes.actionSheet();
			if (actionSheet.buttons()["Delete Note"].isValid()) {
				return notes.views.NOTE_DELETE;
			}
			
			if (actionSheet.buttons()["Open in Maps"].isValid()) {
				return notes.views.NOTES_ADDRESS_ACTION_SHEET;
			}
		}
		
		UIATarget.localTarget().pushTimeout(0.01);
		var displayName = currentViewHelper();
		UIATarget.localTarget().popTimeout();
		
		if (displayName) {
			UIALogger.logMessage("In '" + notes.stringForView(displayName) + "'");
			return displayName;
		}
		
		throw new Error("Could not determine where we are in notes")
	}

	//	-------------------------------------------------------------------------------------------------
	//	Function: gotoListView
	//		Go to the Notes List view from any view within notes.
	//
	//	Parameters: 
	//		None
	//
	//	Returns: 
	//		None
	//
	//	Throws: 
	//		Error
	//
	//	Notes: 
	//		Might need to add something to catch when none of the views match for some reason.
	//	-------------------------------------------------------------------------------------------------
	notes.gotoListView = function gotoListView() {
		
		UIALogger.logMessage("entering gotoListView");
		this.launchIfNotActive();

		var currentView = this.getCurrentView();
		if (currentView & notes.views.NOTES_LIST) return ;
		
		switch (currentView) {
			case notes.views.NOTE_EDIT:
			case notes.views.NOTE_VIEW:
				this.navigationBar().leftButton().tap();
				break;
			case notes.views.NOTES_LIST:
				break;
			case notes.views.NOTE_EMAIL:
				this.navigationBar().buttons()["Cancel"].tap();
				UIATarget.localTarget().delay(1);
				if (UIATarget.localTarget().model() == 'iPad')
						this.mainWindow().popover().actionSheet().buttons().firstWithPredicate("name contains 'Delete'").tap();
					else
						this.actionSheet().buttons().firstWithPredicate("name contains 'Delete'").tap();
				UIATarget.localTarget().delay(1);
				if (!this.isInSplitView()) this.navigationBar().leftButton().tap();
				break;
			default: 
				if (UIATarget.localTarget().model() == 'iPad') {
					switch (currentView) {
						case notes.views.NOTES_SEARCH:
							var container = (this.isInSplitView()) ? this.mainWindow().images().firstWithValueForKey(1, "isVisible") : this.mainWindow().popover();
							var searchBar = container.searchBars()[0];
							if (searchBar.value() != "Search") searchBar.buttons()["Clear text"].tap();
							UIATarget.localTarget().delay(1);
							this.keyboard().buttons()["Hide keyboard"].tap();
							break;
						case notes.views.NOTE_DELETE:
						case notes.views.NOTES_ADDRESS_ACTION_SHEET:
							UIATarget.localTarget().tapWithOptions(this.mainWindow().buttons()["Delete"].rect()); //dismiss the popover
							UIATarget.localTarget().delay(1); //account for animation delay
							if (!this.isInSplitView()) this.navigationBar().leftButton().tap();
							break;	
					}
				} else {
					switch (currentView) {
						case notes.views.NOTES_SEARCH:
							this.mainWindow().tableViews()[0].elements()["Cancel"].tap();
							break;
						case notes.views.NOTE_DELETE:
						case notes.views.NOTES_ADDRESS_ACTION_SHEET:
							this.actionSheet().buttons()["Cancel"].tap();
							UIATarget.localTarget().delay(1); //account for animation delay
							this.navigationBar().leftButton().tap();
							break;	
					}
				}			
		}
		
		currentView = this.getCurrentView();
		if (!(currentView & notes.views.NOTES_LIST)) throw new Error("Could not get to the notes list view. Still in '" + currentView + "'");
		UIATarget.localTarget().delay(1); //give one second for animations, etc. to end <rdar://problem/9385105>
        
		UIALogger.logMessage("leaving gotoListView");
	}
	
	//	-------------------------------------------------------------------------------------------------
	//	Function: createNewNote
	//		Creates a new note.
	//
	//	Parameters:
	//		title (string) - title will be the first line of the note, followed by a return
	//		body (string) - the body of the note
	//		keyboardVisible (bool) - false if you want the keyboard to be dismissed afterwards, otherwise true is assumed
	//
	//	Returns: 
	//		None
	//
	//	Throws: 
	//		Error
	//	-------------------------------------------------------------------------------------------------
	notes.createNewNote = function createNewNote(title, body, keyboardVisible) {
		
		UIALogger.logMessage("Creating Note with title '" + title + "'");
		
		var currentView = this.getCurrentView();
		if (currentView & notes.views.NOTE_VIEW) {
			var navBar = this.navigationBar();
			navBar.buttons()["Add"].tap();
		} else {
			this.gotoListView();
			if (UIATarget.localTarget().model() == 'iPad') {
				this.mainWindow().popover().dismiss();
			}
			
			var navBar = this.navigationBar();
			navBar.buttons()["Add"].tap();
			
			if (!navBar.withName("New Note").isValid()) {
				throw new Error("Failed to create the new note.  No 'New Note' nav bar title found.");
			}
		}
		UIATarget.localTarget().delay(3); 
		
		//enter text
		this.enterTextInTextField(this.mainWindow().textViews()[0], title + "\n" + body);
		//this.mainWindow().textViews()[0].setValue(title + "\n" + body);
		
		if (keyboardVisible == false) {
			if (UIATarget.localTarget().model() == 'iPad')
				this.keyboard().buttons()["Hide keyboard"].tap();
			else
				navBar.buttons()["Done"].tap();
		}
		
		UIALogger.logMessage("leaving createNewNote");
	}
	
	//	-------------------------------------------------------------------------------------------------
	//	Function: deleteNote - 
	//		deletes the current note
	//
	//	Parameters:
	//	 confirm (bool) - true to confirm the delete dialog, false to cancel out of it.
	//
	//	Returns: 
	//		None
	//
	//	Notes: 
	//		False is assumed if confirm isn't specified.
	//	-------------------------------------------------------------------------------------------------
	notes.deleteNote = function deleteNote(confirm) {
		UIALogger.logMessage("entering deleteNote");
		
		var theView = this.getCurrentView();
		if (!(theView & notes.views.NOTE_VIEW)) {
			throw new Error("Need to be in 'NoteView' to click delete button");
		} else {
			var navBarName = this.navigationBar().name();
			this.mainWindow().buttons()["Delete"].tap();
			UIALogger.logMessage("Tapped the delete button");
			
			if (UIATarget.localTarget().model() == 'iPad') 
				var actionSheet = this.mainWindow().popover().actionSheet();
			else 
				var actionSheet = this.actionSheet();
			if (!actionSheet.isValid()) throw new Error("Tapped the delete icon, but the action sheet did not show up");
			UIATarget.localTarget().delay(1); //animation delay
			
			if (confirm == true) {
				actionSheet.buttons()["Delete Note"].tap();
				// If there are no single quotes in the title, perform a comparison.  If there are single quote(s), the comparison will fail: <rdar://problem/9686443>
				if (navBarName.indexOf("'") < 0) {
				    if (!this.navigationBar().withPredicate("name != '" + navBarName + "'").isValid()) UIALogger.logMessage("Nav bar name did not change: " + navBarName);
				}
				else {
				    UIALogger.logDebug("Single quote detected in title of note -- not doing a final check");
				}
				UIATarget.localTarget().delay(1); //account for the animation delay
			} else {
				if (UIATarget.localTarget().model() == 'iPad')
					UIATarget.localTarget().tap(this.mainWindow().buttons()["Delete"].rect()); //dismiss the popover
				else
					actionSheet.cancelButton().tap();
				actionSheet.waitForInvalid();
			}
		}
		
		UIALogger.logMessage("leaving deleteNote");
	}
	
	//	-------------------------------------------------------------------------------------------------
	//	Function: deleteALLNotes
	//		deletes all notes in the notes list
	//
	//	Parameters: 
	//		None
	//
	//	Returns: 
	//		None
	//
	//	Throws: 
	//		Error
	//	-------------------------------------------------------------------------------------------------
	notes.deleteALLNotes = function deleteALLNotes() {

		this.gotoListView();

		var notesLeft = UIAUtility.tableInfoFromValue(this.notesListTable().value()).noOfElements;
		UIALogger.logMessage("There are " + notesLeft + " notes.");
		if (notesLeft <= 0) return ;
				
		var note = this.notesListTable().visibleCells()[0];
		if(!note.isValid()) {
			throw new Error("Could not find the note to tap");
		}
		
		//check whether it is 'New Note' which can't be deleted -- only applicable for iPad
		if (UIATarget.localTarget().model() == 'iPad' && note.name().indexOf("New Note") >= 0) {
			UIALogger.logDebug("Found 'New Note'");
			if (notesLeft == 1) return ;
			notesLeft--;
			note = this.notesListTable().visibleCells()[1];
		}
		note.tap();
		UIATarget.localTarget().delay(1);  // give time for the tap to take place.
		
		for (var i=0; i<notesLeft; i++) {
			UIALogger.logMessage(i + " notes deleted");
			if (!(this.getCurrentView() & notes.views.NOTE_VIEW)) {
				throw new Error("No note being displayed");
			}
			this.deleteNote(true);
		}
		
		this.gotoListView();
		
		var noteNumber = UIAUtility.tableInfoFromValue(this.notesListTable().value()).noOfElements;
		if (noteNumber != 0) {
			if (noteNumber == 1 && this.notesListTable().visibleCells()[0].name().indexOf("New Note") >= 0) return ;
			throw new Error("Still " + noteNumber + " notes left.");
		}
	}
    
	//	-------------------------------------------------------------------------------------------------
	//	Function: selectSharingOption 
	//		Select the notes "action" button, and select the specified sharing option (email or print)
	//
	//	Parameters:
	//		notesSharingOption (string) - notes.NOTE_SHARING_OPTION_EMAIL or notes.NOTE_SHARING_OPTION_PRINT 
	//
	//	Returns: 
	//		None
	//	-------------------------------------------------------------------------------------------------
	notes.selectSharingOption = function selectSharingOption(notesSharingOption) {
		UIALogger.logDebug("Selecting " + notesSharingOption + " sharing option");
		this.mainWindow().buttons()["Share"].tap();
        
		var sharingButton;
		if (UIATarget.localTarget().model() == 'iPad') {
			sharingButton = this.mainWindow().popover().actionSheet().buttons()[notesSharingOption];
		} else {
			sharingButton = this.actionSheet().buttons()[notesSharingOption];
		}
		UIATarget.localTarget().delay(1); //account for the animation
		sharingButton.tap();
	}   
	//	-------------------------------------------------------------------------------------------------
	//	Function: emailNote 
	//		Emails the current note
	//
	//	Parameters:
	//		toField (string) - enters the string into the to field...should probably be an array and loop through it
	//		ccField (string) - enters the string into the cc fielt...should probably be an array and loop through it
	//
	//	Returns: 
	//		None
	//	-------------------------------------------------------------------------------------------------
	notes.emailNote = function emailNote(toField, ccfield) {
		
		var theView = this.getCurrentView();
		if (!(theView & notes.views.NOTE_VIEW)) {
			throw new Error("Incorrect View (in " + theView + ") : No email created");
		} 
		else {
			this.selectSharingOption(notes.NOTE_SHARING_OPTION_EMAIL);
			UIALogger.logMessage("Tapped the Email button. Will type up the email now");
			if (!this.isDisplayingEmailComposeSheet()) {
				throw new Error("Selected email note, but email compose sheet did not come up");
			}
			var email = new Object();
			email.to = toField;
			if (ccfield) email.cc = ccfield;
			this.composeEmail(email);
			
			UIALogger.logMessage("Sending email to '" + email.to + "'.");
			this.mainWindow().navigationBar().buttons()["Send"].withValueForKey(1, "isVisible").tap();
		}
	}
	
	//	-------------------------------------------------------------------------------------------------
	//	Function: getToNoteFromList 
	//		Select a note from a list by matching titles 
	//
	//	Parameters:
	//		noteName (string) - title of the note
	//		pressTheButton (bool) - true to select the note
	//
	//  Parameter:
	//      partialMatch (bool) - set to true if you're willing to do a partial match.  This is false by default
	//
	//	Returns:
	//		the name of the note that was selected
	//
	//	Throws: 
	//		Error
	//	-------------------------------------------------------------------------------------------------
	notes.getToNoteFromList = function getToNoteFromList(noteName, pressTheButton, options) {
		if (!options) options = new Object();
		
		UIALogger.logMessage("entering getToNoteFromList");
		
		var currentView = this.getCurrentView();
		if (!(currentView & notes.views.NOTES_LIST)) {
			this.gotoListView();
		}
		
		this.notesListTable().cells()[0]; //might serve as a workaround for <rdar://problem/8197437>
		
		UIALogger.logMessage("Looking for note: " + noteName);
		
		//because of <rdar://problem/8197437>, we are only going to query directly if the table is small
		var noOfElements = UIAUtility.tableInfoFromValue(this.notesListTable().value()).noOfElements;
		var notePredicate = "name beginswith '"+ noteName +". '";
		if ((options.partialMatch == 1) || (options.partialMatch == true)) {
		    var notePredicate = "name beginswith '"+ noteName +"'";
		}
		if (noOfElements < 500) {
			var noteElement = this.notesListTable().scrollToElementWithPredicate(notePredicate); //the period makes sure its not a partial name match
			if (!noteElement.isValid()) {
				throw new Error("Could not find the note: " + noteName); //this error message is important since some tests match off it
			}
		} else {
			UIALogger.logDebug("Too many notes. Will scroll through the cells. ");
			try {
				var noteElement = this.notesListTable().nonAXScrollToCell(new UIAPredicateString(notePredicate));
			} catch (e) {
				throw new Error("Could not find the note: " + noteName); //this error message is important since some tests match off it
			}
		}
		
		noteName = noteElement.name();
		if (pressTheButton == true) {
			UIALogger.logMessage("Selecting the note now: " + noteName);
			noteElement.tap();
			if (!noteElement.waitForInvalid()) UIALogger.logError("Element still around"); //will not work because of <rdar://problem/7739689>
		}
		
		return noteName;
	}
	
	//	-------------------------------------------------------------------------------------------------
	//	Function: selectNoteUsingArrow 
	//		Select the previous or next note using the arrow icons
	//
	//	Parameters:
	//		direction (string) - "previous" or "next" are the only acceptable strings, everything else will be ignored.
	//
	//	Returns: 
	//		None
	//
	//	Throws: 
	//		Error
	//	-------------------------------------------------------------------------------------------------
	notes.selectNoteUsingArrow = function selectNoteUsingArrow(direction) {		
		if (!this.mainWindow().textViews()[0].withPredicate("isVisible == 1").isValid()) UIALogger.logWarning("Text view not found");
		var theView = this.getCurrentView();
		
		if (!(theView & notes.views.NOTE_VIEW)) {
			throw new Error("Incorrect View : Note view not found");
		} else {

			var dateElement = this.mainWindow().elements().firstWithPredicate("name matches '.* [0-9]+:[0-9]+ ((AM)|(PM))'");
			if (!dateElement.isValid()) throw new Error("Could not find the date element");
			dateElement.logElement();
			var date = dateElement.name();
			
			var buttonName;
			if (direction == "previous") buttonName = "Previous note";
			else if (direction == "next") buttonName = "Next note";
			else throw new Error("Unknown direction type '" + direction + "'");
			
			var arrowButton = this.mainWindow().buttons()[buttonName];
			if (!arrowButton.isValid()) throw new Error("Could not find the button '" + buttonName + "'");
			if (!arrowButton.isVisible()) throw new Error("Found button '" + buttonName + "', but it is not visible");
			if (!arrowButton.isEnabled()) throw new Error("Found button '" + buttonName + "', but it is not enabled");
			arrowButton.tap();

			if (!dateElement.waitForInvalid()) {
				UIALogger.logError("The date " + dateElement.name() + " did not go away after tapping the arrow button");
			}
		} 
	}
	
	//	-------------------------------------------------------------------------------------------------
	//	Function: noteTitleFromTableCell 
	//		Returns the note title
	//
	//	Parameters:
	//		tableCell (UIATableCell) - the note table cell (from notes list) whose title needs to be returned
	//
	//	Returns: 
	//		The title of the note
	//	-------------------------------------------------------------------------------------------------
	notes.noteTitleFromTableCell = function noteTitleFromTableCell(tableCell) {
		if (!tableCell.withPredicate("name != null").isValid()) {
			tableCell.logElement();
			throw new Error("Unexpected name for a note table cell");
		}
		return tableCell.name().split('.')[0];
	}
}
