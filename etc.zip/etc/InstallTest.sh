#! /bin/sh

errors=0;

processExists() {
	grepValue=`ps auxwww | grep ${1} | grep -v grep`;
	returnVal=$?;
	if [ ${returnVal} -eq 1 ]
	then
		echo "FAIL: $1 does NOT exist";
		errors=`expr $errors + 1`;
	else
		echo "PASS: $1 exists";
	fi
	return ${returnVal};
}

SpringBoardOrSwitchBoardExists() {
	grepValue=`ps auxwww | grep SpringBoard | grep -v grep`;
	returnVal=$?;
	if [ ${returnVal} -eq 1 ]
	then
		grepValue=`ps auxwww | grep SwitchBoard | grep -v grep`;
		returnVal=$?;
		if [ ${returnVal} -eq 1 ]
		then
			echo "FAIL: SpringBoard/SwitchBoard do not exist";
			errors=`expr $errors + 1`;
		else
			echo "PASS: SwitchBoard exists";
		fi
	else
		echo "PASS: SpringBoard exists";
	fi
	return ${returnVal};
}

checkSyslog() {
	if [ "$2" = "" ] 
	then
		syslogOut=`syslog ${1}`
	else
		syslogOut=`syslog ${1} | grep "${2}"`;
	fi
	
	if [ "$syslogOut" = "" ]
	then
		echo "PASS: syslog ${1}";
	else
		echo "FAIL: syslog ${1}: \n$syslogOut";
		errors=`expr $errors + 1`;
	fi
	return ${returnVal};
}


# main() starts here
echo "Starting Install Test";

# Check for SpringBoard, if it does not exist, check for SwitchBoard.
SpringBoardOrSwitchBoardExists;

# Check to be sure other important processes are running
processExists "lockdownd";
processExists "mediaserverd";
processExists "sbin/launchd";  # look for sbin/launchd, because there are other commands that have launchd in the path.
processExists "CommCenter";

# Check the syslog for Errors.
checkSyslog "-k Level le 2";  	# levels less than or equal to 2
checkSyslog "-k Sender ReportCrash -k Level Nle 3"; # Crash Reports
checkSyslog "-k Sender CommCenter -k Level Nle 5" "CSI state dump requested"  # Baseband Crash Reports

echo "\nTotal Errors Found = $errors\n";

if [ $errors -eq 0 ]
then
	echo "Install Test Successful: No Errors Found";
else
	echo "Install Test Failed: Errors Found = $errors";
fi

exit $errors;