#!/usr/bin/perl -w
use IO::Socket;

die "USAGE: ./tcpClient.pl <Server IP Address> <SuffixForDirName> <Results_FileToBe_Uploaded>\n" if ( @ARGV != 3);

$addr = shift;
$outputdir = shift;
$file = shift;

$socket = IO::Socket::INET->new(PeerAddr => $addr,
                                PeerPort => 12001,
                                Proto    => 'tcp',
                                Type     => SOCK_STREAM)
                      or
die "Cannot open socket!\n";

$fname = (split /\//,$file)[-1];
$outputdir = "DIR:$outputdir";
$fname = "FILE:$fname";
@L = ($outputdir,$fname);
#print join ("###",@L);

$SIG{PIPE} = 'handler';    #  SIGPIPE if server end of socket is gone when we try to write to it.
$SIG{INT}  = 'handler';  
$SIG{QUIT} = 'handler'; 

print "\nOutputDir = $outputdir...File = $file.\n";

foreach (@L)
{
	print $socket "$_\n";
	$in = <$socket>;
	chomp $in;
	print " \"$in\" from server!\n\n";
	if ($in =~ /FAILED/g) { 
		print " ****** UPLOADING LOGS TO SERVER FAILED !!!!!    WILL TRY NEXT TIME...\n";
		close ($socket);
		exit (1);
	}
}

open (F, "$file") || print " Cannot open $file for reading!!!!!\n";
foreach (<F>)
{
	print $socket $_;
	$inbuf = <$socket>;
}
print $socket "QUIT\n";   #######  Send QUIT packet to server.
chomp ($inbuf = <$socket>);
#chomp $inbuf;
print "***** \"$inbuf\" from server!\n\n";
close F;

#  Send that quit packet to terminate the session

close($socket);


sub handler
{
    my ($signo) = shift;

    if ($signo eq "INT" || $signo eq "QUIT")
    {
#  Send the quit packet on a terminal interrupt!
         print $socket "QUIT\n"; 
         close($socket);
         exit(1);
    }
    else  ############  SIGPIPE!!
    {
         print "Server died\n";
         exit(2);
    }
}
