#import "UIAAppStressLibrary.js"

var operators = new Array("+", "*", "/", "-");

if (typeof calculator != 'undefined') {
	calculatorStress = AppStressBase.stressTest("Calculator");
	
	if (typeof calculatorStress != 'undefined') {

		calculatorStress.setup = function setup () {
			calculatorStress.addTest(calculatorStress._calculate);
			calculatorStress.addTest(calculatorStress._continueCalculation);
			calculatorStress.addTest(calculatorStress._clear);
			
			return true;
		}
		
		calculatorStress.run = function run () {
			calculatorStress.executeRandomTests(3);
		}
		
		// calculate
		calculatorStress._calculate = function _calculate() {
			var argument = system.randomReal(0, 999999).toPrecision(9) + UIAUtility.randomFromArray(operators) + system.randomReal(0, 999999).toPrecision(9);
			
			calculatorStress.executeTest("Calculate", new Array(argument), calcTest_calculate, "Calculating '" + argument + "'.");
		}
		
		// continue calculation
		calculatorStress._continueCalculation = function _continueCalculation() {
			var argument = UIAUtility.randomFromArray(operators) + system.randomReal(0, 999999).toPrecision(9);
			
			calculatorStress.executeTest( "Continue Calculation", 
										  new Array(argument), 
										  calcTest_continueCalculation, 
										  "Continuing calculation with '" + argument + "'." );
		}
		
		// clear
		calculatorStress._clear = function _clear() {
			calculatorStress.executeTest("Clear Calculator", new Array(), calcTest_clear, "Clearing calculator display.");
		}
	}
}
