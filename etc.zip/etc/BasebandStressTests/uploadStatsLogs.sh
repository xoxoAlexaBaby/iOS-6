#!/bin/sh


###########################################################################
# Helper Functions
###########################################################################
enableWifi()
{
	#echo "${TOOLS_DIR}/mobilewifitool -- device power -i en0 1"
	#${TOOLS_DIR}/mobilewifitool -- device power -i en0 1
	echo "/usr/local/etc/scripterUIA/general/ExecuteTest.js settingsTest_setWifi 1" 
	#/usr/local/etc/scripterUIA/general/ExecuteTest.js settingsTest_setWifi 1  > WiFiOn.txt
	/usr/local/bin/WirelessTester -command "wifi.on"  >  WiFiOn.txt;
}

disableWifi()
{
	#echo "${TOOLS_DIR}/mobilewifitool -- device power -i en0 0"  
	#${TOOLS_DIR}/mobilewifitool -- device power -i en0 0  > WiFiOff.txt
	echo "/usr/local/etc/scripterUIA/general/ExecuteTest.js settingsTest_setWifi 0"
	#/usr/local/etc/scripterUIA/general/ExecuteTest.js settingsTest_setWifi 0  > WiFiOff.txt
	/usr/local/bin/WirelessTester -command "wifi.off" > WiFiOff.txt;
}

getSSID()
{
	echo "Checking again for SSID - $SSID."
	${TOOLS_DIR}/apple80211 -ssid > /tmp/currentssid
	grep "$SSID" /tmp/currentssid
	isCorrectSSID=$?
}

stopKilling()
{
	GREP="grep killHungProcess"
	PIDS=`ps -A | $GREP | grep -v grep | awk '{print $1}'`;
	PidsSleep=`ps -A | grep "sleep [1-6]" | grep -v grep | perl -lne 'chomp; $p = (split /\s+/)[0]; $p =~ s/\s*//g; print $p;' `;
	kill -9 $PIDS
	kill -9 $PidsSleep
}

uploadIQMetrics()
{
	if [ $EnableAWD -eq 1 ]; then
		echo `date` ": AWD Agent Uploading is enabled. Upload stats to the AWD server."
		${TESTCT} -c "#*362253293#"
		${TESTCT} -c "#*782648#"
		sleep 60
	fi
}


###########################################################################
# Function to join WIFI n/w repeatedly until it succeeds in MAX_JOIN_ATTEMPTS
###########################################################################
joinWifiNetwork()
{
	attempt=0
	doUpload=0
	if [ -e /$SCRIPTS_DIR/WiFiSettings.sh ]; then
		echo `date` ": 1. WiFiSettings.sh file is present. Getting the values.";
		source $SCRIPTS_DIR/WiFiSettings.sh;
		SSID=$DEFAULT_SSID; 	
		WEPKEY=$DEFAULT_WEP_KEY;
		SECURITY=$DEFAULT_SECURITY;
		if [ $changeSSID -eq 1 ]; then 
			SSID="DejaVu";
			WEPKEY="csin92qa";
		elif [ $changeSSID -eq 2 ]; then 
			SSID="CAPSULE";
			WEPKEY="123456789b";
		elif [ $changeSSID -eq 3 ]; then 
			SSID="ANDROMEDA1";
			WEPKEY="777711112b";
		elif [ $changeSSID -eq 4 ]; then 
			SSID="STARBURST";
			WEPKEY="7777whirlpool1B";
		fi

	else
		echo `date` ":WiFiSettings.sh file is not present... Going with Default Settings.";
		if [ $changeSSID -eq 1 ]; then 
			SSID="DejaVu";
			WEPKEY="csin92qa";
		elif [ $changeSSID -eq 2 ]; then 
			SSID="CAPSULE";
			WEPKEY="123456789b";
		elif [ $changeSSID -eq 3 ]; then 
			SSID="ANDROMEDA1";
			WEPKEY="777711112b";
		elif [ $changeSSID -eq 4 ]; then 
			SSID="STARBURST";
			WEPKEY="7777whirlpool1B";
		fi

	fi

	echo `date` ": _____JOINING WIFI NETWORK $SSID - $dcount_____"  >> $LOGSFILE
	echo "Powering on radio."
	enableWifi
	sleep 2
	
	
	while [ $attempt -lt $MAX_JOIN_ATTEMPTS ]
	do
		echo "${TOOLS_DIR}/wifitool -s -j $SSID -e $SECURITY -p $WEPKEY -d 20"
		${TOOLS_DIR}/wifitool -s -j $SSID -e $SECURITY -p $WEPKEY -d 20  > /tmp/reg_dump.txt
		sleep 3
		grep "error 0" /tmp/reg_dump.txt; success=$?; rm /tmp/reg_dump.txt;
	
		if [ $success -ne 0 ]; then 
			((attempt++))
			doUpload=0
		else
			sleep 5
			doUpload=1
			echo `date` ": **** Successfully Joined - $SSID - network. DoUpload - $doUpload****"
			break
		fi
		
		if [ $attempt -eq $MAX_JOIN_ATTEMPTS ]; then 
			doUpload=0;
			((wifiFailCount++))
			echo " Cannot Join WiFi Network. Joining $SSID Failed after $attempts attempts."
			echo `date` ":  UPLOADING FAILED !!!!!!!!";
			echo " Powering down WiFi"
			echo " Resetting WiFi chip as a workaround !!!!!!!!!!!"
			#if [ $SSID != "CSIQA" ] &&  [ ${wifiFailCount} -ge 10 ]; then
			#	echo " Resetting WiFi chip as a workaround !!!!!!!!!!!"
			#	/usr/local/bin/apple80211 -ssid=w
			#	wifiFailCount=0
			#fi
			disableWifi
			echo `date` ": _____UPLOADING FAILED - $dcount_____"  >> $LOGSFILE
		fi
		
	done
}

###########################################################################
# Function to upload Stats to the Server using SSID - CSIQA
###########################################################################
uploadStats()
{
	echo `date` ": _____UPLOADING STATS START - $dcount_____"  >> $LOGSFILE
	joinWifiNetwork
	isCorrectSSID=0
	echo `date` ": _____Wifi Associated Uploading Stats - $dcount____"  >> $LOGSFILE
	
	if [ $doUpload -eq 1 ]; then
		#getSSID
		if [ $isCorrectSSID -eq 0 ]; then 
			nohup $SCRIPTS_DIR/killHungProcess.sh "tcpClient.pl" 60 &
			echo "$SCRIPTS_DIR/tcpClient.pl $SERVER_ADDR $serverDir $ResultsFile"
			perl $SCRIPTS_DIR/tcpClient.pl $SERVER_ADDR $serverDir $ResultsFile 
			sleep 2
		fi
		#getSSID
		if [ $isCorrectSSID -eq 0 ]; then 
			nohup $SCRIPTS_DIR/killHungProcess.sh "tcpClient.pl" 60 &
			echo "$SCRIPTS_DIR/tcpClient.pl $SERVER_ADDR $serverDir $CsiLogsFile"
			perl $SCRIPTS_DIR/tcpClient.pl $SERVER_ADDR $serverDir $CsiLogsFile 
			sleep 2			
		else
			echo "Cannot get SSID, so not uploading this time -- $dcount."
		fi
		
		sleep 15
		echo `date` ": Powering down WiFi"
		disableWifi
	fi

	stopKilling
	doUpload=0
	echo `date` ": _____UPLOADING STATS END - $dcount_____"  >> $LOGSFILE
}


###########################################################################
# Function to upload logs to the Server using SSID - CSIQA
###########################################################################
uploadLogs()
{
	echo `date` ": Entering function UploadLogs to upload Logs to $SSID."
	echo `date` ": _____UPLOADING LOGS START - $dcount_____"  >> $LOGSFILE
	joinWifiNetwork
	echo `date` ": _____UPLOADING IQ METRICS USING WIFI - $dcount_____"  >> $LOGSFILE
	uploadIQMetrics

	if [ $doUpload -eq 1 ]; then
		fileCount=0
		totalUploaded=0
		totNonCSILogs=0
		uploadFailCount=0
		isBBLog=1; isCsiFile=1;
		if [ $dcount -eq $LOOPS ]; then MAX_FILES_TO_UPLOAD=50000; fi
		
		totFilesToUpload=`ls $logsDir/log-bb-* | wc -l | perl -lne ' s/\s*//; print'`
		echo `date` ": _____Wifi Associated Uploading Logs - $dcount____"  >> $LOGSFILE
		
		for fname in $logsDir/*; do
			
			((fileCount++))
			echo "\n\n$fileCount. $fname"
			isCorrectSSID=1
			success=1
			
			isCsiFile=`echo $fname | perl -lne 'if (/csi/g) { print "0" } elsif (/diag|mal|art|cd/g) { print "1" } else {print "2"}' `
			if [ $isCsiFile -eq 0 ]; then  uploadSleep=90; 
			else uploadSleep=240; fi
			#elif [ $isCsiFile -eq 2 ]; then  uploadSleep=60;
			
			echo "UploadSleep = $uploadSleep."
			nohup $SCRIPTS_DIR/killHungProcess.sh "tcpClientBin.pl" $uploadSleep &
			date
			
			if [ $totFilesToUpload -gt 0 ] && [ $fileCount -le $MAX_FILES_TO_UPLOAD ]; then
			
				if [ $isCsiFile -eq 0 ]; then  
					((fileCount--));
					echo `date` ": $SCRIPTS_DIR/tcpClientBin.pl $SERVER_ADDR $serverDir $DEVICENAME/ $fname"
					perl $SCRIPTS_DIR/tcpClientBin.pl $SERVER_ADDR $serverDir $DEVICENAME/ $fname  
					success=$?
					
				elif [ $isCsiFile -eq 1 ]; then
					((totNonCSILogs++)); 

					if [ ! -d $fname ]; then
						echo `date` ": $SCRIPTS_DIR/tcpClientBin.pl $SERVER_ADDR $serverDir $DEVICENAME/ $fname"
						perl $SCRIPTS_DIR/tcpClientBin.pl $SERVER_ADDR $serverDir $DEVICENAME/ $fname
						success=$?
						if [ $success -eq 10 ]; then rm $fname; fi	
						
					else
						bbLogFilesCount=0
						bbUploaded=0
						for indexFiles in $fname/* ; do
							logFileDir=`echo $fname | perl -lne ' $f = (split/\//)[-1]; print $f; ' `
							((bbLogFilesCount++))
							bbSuccess=0
							echo "**** $fname ----- $logFileDir."
							echo `date` ": Starting Upload of diag/art/ma/cd...."
							echo `date` ": $SCRIPTS_DIR/tcpClientBin.pl $SERVER_ADDR $serverDir $DEVICENAME/$logFileDir/ $indexFiles"
							perl $SCRIPTS_DIR/tcpClientBin.pl $SERVER_ADDR $serverDir $DEVICENAME/$logFileDir/ $indexFiles
							bbSuccess=$?
							date
							if [ $bbSuccess -eq 10 ]; then ((bbUploaded++));
							else  break; fi
						done
						
						if [ $bbUploaded -eq $bbLogFilesCount ]; then 
							echo "rm -r $fname/ \n";
							mv $fname $UploadedLogs/
							#rm -r $fname/
							success=10;
						fi
					fi
					
				else
					((totNonCSILogs++))
					echo `date` ": Starting Upload of other logs...."
					echo `date` ": $SCRIPTS_DIR/tcpClientBin.pl $SERVER_ADDR $serverDir $DEVICENAME/ $fname"
					perl $SCRIPTS_DIR/tcpClientBin.pl $SERVER_ADDR $serverDir $DEVICENAME/ $fname 
					success=$?
					#if [ $success -eq 10 ]; then rm $fname; fi	
				fi
				
				stopKilling
				ps -A
				
				if [ $success -eq 10 ]; then 
					echo "$fname -- Uploaded Successfully.";
					((totalUploaded++)); success=0;
				else
					((uploadFailCount++));
					if [ $uploadFailCount -ge 5 ]; then  break; fi
				fi
						
			else
				stopKilling
				break;			
			fi
						
		done
		
		crashCount=0
		totCrashesToUpload=`ls $crashDir/*log $wirelessDir/*log $wirelessDir/*.plist $crashDir/*.plist $mobileDir/Retired/*plist $mobileLogs | wc -l | perl -lne ' s/\s*//; print'`
		
		for fname in $wirelessDir/*.plist  $wirelessDir/*log $crashDir/*log $crashDir/*.plist $mobileLogs $mobileDir/Retired/*plist; do
			((crashCount++))
			echo "\n\n Crash logs.. $fileCount. $fname"
			uploadSleep=210
					
			nohup $SCRIPTS_DIR/killHungProcess.sh "tcpClientBin.pl" $uploadSleep &
			
			if [ $totCrashesToUpload -gt 0 ] && [ $fileCount -le $MAX_FILES_TO_UPLOAD ]; then
				((totNonCSILogs++))
				echo `date` ": $SCRIPTS_DIR/tcpClientBin.pl $SERVER_ADDR $serverDir $DEVICENAME/ $fname"
				perl $SCRIPTS_DIR/tcpClientBin.pl $SERVER_ADDR $serverDir $DEVICENAME/ $fname 
				success=$?
					
				if [ $success -eq 10 ]; then 
					echo "$fname -- Uploaded Successfully.";
					((totalUploaded++)); success=0;
				else
					((uploadFailCount++));
					if [ $uploadFailCount -ge 8 ]; then  break; fi
				fi
				fi
				stopKilling
			fi			
		done
		
		#${TOOLS_DIR}/bin/wifitool -L
		echo `date` ": Powering down WiFi..."
		disableWifi
		date
		filesUploadedSoFar=$(($filesUploadedSoFar + $totalUploaded));
		date
		echo "\n  ******* Total Files Waiting for Upload - $totFilesToUpload.\n\tFiles Uploaded on this run - $totalUploaded."
		echo "\t Total Crashes to upload - $totCrashesToUpload, crashCount = $crashCount."
		echo "\t Total Non-CSI Logs - $totNonCSILogs."
		echo "  ******* Total Uploaded So Far from the Device - $filesUploadedSoFar.\n"
	fi
	
	doUpload=0
	sleep 60
	echo `date` ": _____UPLOADING LOGS END - $dcount____"  >> $LOGSFILE
	
}

###############################################################
#perl /usr/local/etc/BasebandStressTests/tcpClient.pl $SERVER_ADDR $serverDir $ResultsFile
#perl /usr/local/etc/BasebandStressTests/tcpClient.pl $SERVER_ADDR $serverDir $CsiLogsFile
#echo "/usr/local/etc/BasebandStressTests/tcpClientBin.pl $SERVER_ADDR $serverDir $DEVICENAME $fname"
#perl /usr/local/etc/BasebandStressTests/tcpClientBin.pl $SERVER_ADDR $serverDir $DEVICENAME/ $fname  > File_$fileCount.txt