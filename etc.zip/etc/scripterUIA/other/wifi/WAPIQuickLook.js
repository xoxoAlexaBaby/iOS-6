#!/usr/local/bin/scripter -uiautomation YES -f

#import "/usr/local/etc/scripterUIA/libs/PHTesting.js"
#import "/usr/local/etc/scripterUIA/libs/HarnessUtility.js"
#import "/usr/local/etc/scripterUIA/settings/SettingsTests.js"
#import "/usr/local/etc/scripterUIA/safari/SafariTests.js"
#import "/usr/local/etc/scripterUIA/mail/MailTests.js"
#import "/usr/local/etc/scripterUIA/springboard/SpringboardTests.js"
#import "/usr/local/etc/scripterUIA/system/SystemTests.js"
#import "/usr/local/etc/scripterUIA/other/wifi/WiFiTests.js"
#import "/usr/local/etc/scripterUIA/youtube/YouTubeTests.js"
#import "/usr/local/etc/scripterUIA/facetime/FaceTimeTests.js"

var kReportPath = "/var/mobile/Library/Logs/Testing/";
var hasWifi = system.hasCapability('wifi');

var start = new Date();
var timeString = start.getTime() + "";  // turn this into a string
var runID = "WiFiQuickLook " + start.toDateString() + " - " + timeString.substr(-6);

function addTestsToArray(tests) {
	var defaultNetwork = "AppleWiFi";
	var hiddenNetwork = "123";
	var wpa2Network = "1WPA2";
	var leapNetwork = "MW_Cisco_ACS";
	var hiddenPeapNetwork = "mw ias";
	var iperfNetwork = "abdiperf"
	var iperfServer = "192.168.1.66"
	var hiddenTtlsNetwork = "MW-M48-Odyssey"
	var legacyNetwork = "ABD DLINK G ONLY"
	var beaconNetwork = "WRT54G beacon alignment"
	var WAPIPSKNetwork = "haiwapipsk"
	var WAPIHEXNetwork = "haiwapiHEX"
	var WAPICertNetwork = "haiwapicert"
	
	var beaconServer = "192.168.1.1"

	var hiddenPassword = "1234567890";
	var wpa2Password = "12345678";
	var leapUsername = "wirelessuser";
	var leapPassword = "wireless@1234567890";
	var legacyPassword = "1234567890";
	var WAPIPSKPassword = "12345678"
	var WAPIHEXPassword = "1234abcd"

	var tempUsername = "abc";
	var tempPassword = "1234567";

	var AbandNetwork = "BH_M52_5N_Only";
	var AbandPassword = "wireless";

	var folder = "ABD";
	var emailTitle = "EAP-TLS MW_Cisco_ACS wirelessuser pre-populated.mobileconfig";
	var profileName = "EAP-TLS MW_Cisco_ACS wirelessuser pre-populated.mobileconfig";
	var download_verification_string_Tls = "EAP-TLS MW_Cisco_ACS wirelessuser pre-populated";
	var emailAccount = "wifiabd@gmail.com";
	var timeout = 60;
	var profilePassword = "wireless";

	var folder_EAPFast = "ABD";
	var emailTitle_EAPFast = "MW_Cisco_ACS_EAP_FAST_Anon3_WPA-WPA2_iPCUv2_121";
	var profileName_EAPFast = "MW_Cisco_ACS_eap_fast wpa-wpa2 anon 3.mobileconfig";
	var download_verification_string_EAPFast = "MW_Cisco_ACS_eap_fast wpa/wpa2 anon 3"

	var emailTitle_Ttls = "MW-M48-Odyssey_hidden_root_eap_ttls_pap_iPCUv2_122"
	var profileName_Ttls = "MW-M48-Odyssey_hidden_root_eap_ttls_pap_iPCUv2_122.mobileconfig"
	var download_verification_string_Ttls = "MW-M48-Odyssey_hidden_root_eap_ttls_pap_iPCUv2_122"
	
	var emailTitle_WAPI = "WAPI new cert"
	var profileName_WAPI = "as.cer"
	var profileName_WAPIUser = "ASUE.cer"

	var URL1 = "http://www.yahoo.com";
	var URL2 = "http://www.google.com"
	var ping_destination = "www.google.com"

	var iperf_time = 30;
	var iperf_pass = 1;
	var delay = 25;
	var personalHotspotPassword = "wireless"

	var wifiplistPath = kReportPath + "wifi"
	var wifiplistAfterAutoJoinPath = kReportPath + "wifiAfterWiFiOnOff"
	
	var isChinaDevice = system.hasWiFiCapability("WAPI")

	//WiFi

	if (isChinaDevice) {
		tests.push("Test with China devices for using WLAN on UI");
		tests.push(phtCreateTest("WAPIUI", null, settingsTest_checkWAPIUI, "Check China devices use WLAN on UI"));
		
		tests.push("Test with China devices for WAPI PSK");
		tests.push(phtCreateTest("WAPIPSK", [1, WAPIPSKNetwork, WAPIPSKPassword, "WAPI"], settingsTest_setWifiPro, "Associated with WAPI PSK network "+WAPIPSKNetwork));
		tests.push(phtCreateTest("LoadSafariPage", [URL1], safariTest_loadSafariPage, "Load web page in Safari"));
		tests.push(phtCreateTest("WiFiInterfaceActiveTest", null, systemTest_isWiFiInterfaceActive, "Check if WiFi Interface is active"));
		tests.push(phtCreateTest("PingTests", [ping_destination], systemTest_ping, "Ping " + ping_destination));
		
		tests.push("Test China devices for iperf: " + WAPIPSKNetwork);
		tests.push(phtCreateTest("Ping iperf server " + iperfServer, [iperfServer], systemTest_ping, "Ping to " + iperfServer));
		tests.push(phtCreateTest("Run iperf to " + iperfServer, [iperfServer, iperf_time, iperf_pass], wifiTest_iperf, "Run iperf to " + WAPIPSKNetwork + " (reports fail if get less than "+iperf_pass+"Mbps)"));
		
		tests.push("Test with China devices for WiFi On Off");
		tests.push(phtCreateTest("Turn Off WiFi", [0], settingsTest_setWifi, "Turn Off WiFi"));
		tests.push(phtCreateTest("Turn On WiFi", [1], settingsTest_setWifi, "Turn On WiFi"));
		tests.push(phtCreateTest("LoadSafariPage2", [URL2], safariTest_loadSafariPage, "Load web page in Safari"));
		tests.push(phtCreateTest("Auto Join with " + WAPIPSKNetwork, [WAPIPSKNetwork], settingsTest_checkSSID, "Auto Join with " + WAPIPSKNetwork));
		tests.push(phtCreateTest("WiFiInterfaceActiveTest", null, systemTest_isWiFiInterfaceActive, "Check if WiFi Interface is active"));
		tests.push(phtCreateTest("Forget " + WAPIPSKNetwork, [WAPIPSKNetwork], settingsTest_forgetWifi, "Forget " + WAPIPSKNetwork));
		
		tests.push("Test with China devices for WAPI HEX");
		tests.push(phtCreateTest("WAPIHEX", [1, WAPIHEXNetwork, WAPIHEXPassword, "WAPI"], settingsTest_setWifiPro, "Associated with WAPI HEX network "+WAPIHEXNetwork));
		tests.push(phtCreateTest("LoadSafariPage", [URL1], safariTest_loadSafariPage, "Load web page in Safari"));
		tests.push(phtCreateTest("WiFiInterfaceActiveTest", null, systemTest_isWiFiInterfaceActive, "Check if WiFi Interface is active"));
		tests.push(phtCreateTest("PingTests", [ping_destination], systemTest_ping, "Ping " + ping_destination));
		tests.push(phtCreateTest("Forget " + WAPIHEXNetwork, [WAPIHEXNetwork], settingsTest_forgetWifi, "Forget " + WAPIHEXNetwork));
		
		tests.push("Test with China devices for enterprise WAPI network " + WAPICertNetwork);
		//Associate with default WiFi network to download profile
		tests.push(phtCreateTest("Associate with default " + defaultNetwork, [1, defaultNetwork], settingsTest_setWifiPro, "Associate with " + defaultNetwork));
		tests.push(phtCreateTest("PingTests", [ping_destination], systemTest_ping, "Ping " + ping_destination));
		tests.push(phtCreateTest("downloadWAPIProfileFromMail", [emailTitle_WAPI, profileName_WAPI, "account:" + emailAccount, "folder:" + folder, "timeout:" + timeout, "noVerification:true", "waitForMailTimeout:" + timeout], mailTest_downloadMailAttachment, "Download WAPI Root Cert from mail attachment"));
		tests.push(phtCreateTest("installWAPIProfile", null, settingsTest_installProfile, "Install the WAPI Root Cert"));
		tests.push(phtCreateTest("downloadWAPIProfileFromMail", [emailTitle_WAPI, profileName_WAPIUser, "account:" + emailAccount, "folder:" + folder, "timeout:" + timeout, "noVerification:true", "waitForMailTimeout:" + timeout], mailTest_downloadMailAttachment, "Download WAPI User Cert from mail attachment"));
		tests.push(phtCreateTest("installWAPIUserProfile", null, settingsTest_installProfile, "Install the WAPI User Cert"));
		tests.push(phtCreateTest("Associate with WAPI enterprise network using certs " + WAPICertNetwork, [1, WAPICertNetwork, "0", "WAPI enterprise"], settingsTest_setWifiPro, "Associate with WAPI enterprise network use certs " + WAPICertNetwork));
		tests.push(phtCreateTest("LoadSafariPage", [URL1], safariTest_loadSafariPage, "Load web page in Safari"));
		tests.push(phtCreateTest("WiFiInterfaceActiveTest", null, systemTest_isWiFiInterfaceActive, "Check if WiFi Interface is active"));
		tests.push(phtCreateTest("PingTests", [ping_destination], systemTest_ping, "Ping " + ping_destination));
		//Forget the default WiFi network
		tests.push(phtCreateTest("Forget default " + defaultNetwork, [defaultNetwork], settingsTest_forgetWifi, "Forget " + defaultNetwork));
		tests.push(phtCreateTest("Forget " + WAPICertNetwork, [WAPICertNetwork], settingsTest_forgetWifi, "Forget " + WAPICertNetwork));
		tests.push(phtCreateTest("deleteAllProfiles", null, settingsTest_deleteProfile, "Delete All the Profiles"));
	}
	
	tests.push("Test with hidden bg network " + hiddenNetwork + " WEP 40bit");
	tests.push(phtCreateTest("Associate with hidden network " + hiddenNetwork, [1, hiddenNetwork, hiddenPassword, "hidden", "WEP"], settingsTest_setWifiPro, "Associate with hidden network " + hiddenNetwork));
	tests.push(phtCreateTest("LoadSafariPage", [URL1], safariTest_loadSafariPage, "Load web page in Safari"));
	tests.push(phtCreateTest("WiFiInterfaceActiveTest", null, systemTest_isWiFiInterfaceActive, "Check if WiFi Interface is active"));
	tests.push(phtCreateTest("SaveWiFiPlistTest", [wifiplistPath + hiddenNetwork + ".plist"], wifiTest_wifiplist, "Save the plist"));
	tests.push(phtCreateTest("PingTests", [ping_destination], systemTest_ping, "Ping " + ping_destination));
	tests.push(phtCreateTest("Turn Off WiFi", [0], settingsTest_setWifi, "Turn Off WiFi"));
	tests.push(phtCreateTest("Turn On WiFi", [1], settingsTest_setWifi, "Turn On WiFi"));
	tests.push(phtCreateTest("LoadSafariPage2", [URL2], safariTest_loadSafariPage, "Load web page in Safari"));
	tests.push(phtCreateTest("Auto Join with " + hiddenNetwork, [hiddenNetwork], settingsTest_checkSSID, "Auto Join with " + hiddenNetwork));
	tests.push(phtCreateTest("WiFiInterfaceActiveTest", null, systemTest_isWiFiInterfaceActive, "Check if WiFi Interface is active"));
	tests.push(phtCreateTest("SaveWiFiPlistTestAfterWiFiOnOff", [wifiplistAfterAutoJoinPath + hiddenNetwork + ".plist"], wifiTest_wifiplist, "Save the plist after WiFi On Off"));
	tests.push(phtCreateTest("PingTests", [ping_destination], systemTest_ping, "Ping " + ping_destination));

	tests.push("Test with bg WPA2 network " + wpa2Network);
	tests.push(phtCreateTest("Associate with WPA2 network " + wpa2Network, [1, wpa2Network, wpa2Password], settingsTest_setWifiPro, "Associate with WPA2 network " + wpa2Network));
	tests.push(phtCreateTest("LoadSafariPage", [URL1], safariTest_loadSafariPage, "Load web page in Safari"));
	tests.push(phtCreateTest("WiFiInterfaceActiveTest", null, systemTest_isWiFiInterfaceActive, "Check if WiFi Interface is active"));
	tests.push(phtCreateTest("PingTests", [ping_destination], systemTest_ping, "Ping " + ping_destination));

	tests.push("Test with default network " + defaultNetwork);
	tests.push(phtCreateTest("Associate with " + defaultNetwork, [1, defaultNetwork], settingsTest_setWifiPro, "Associate with " + defaultNetwork));
	tests.push(phtCreateTest("LoadSafariPage", [URL1], safariTest_loadSafariPage, "Load web page in Safari"));
	tests.push(phtCreateTest("WiFiInterfaceActiveTest", null, systemTest_isWiFiInterfaceActive, "Check if WiFi Interface is active"));
	tests.push(phtCreateTest("PingTests", [ping_destination], systemTest_ping, "Ping " + ping_destination));

	//add airplane mode test 
	tests.push("Test with default network " + defaultNetwork + " with Airplane Mode On Off");
	tests.push(phtCreateTest("TurnAirplaneModeOn", ["Airplane Mode", 1], settingsTest_changeSingleSwitch, "Turn Airplane Mode ON")); 
	tests.push(phtCreateTest("TurnAirplaneModeOff", ["Airplane Mode", 0], settingsTest_changeSingleSwitch, "Turn Airplane Mode OFF"));
	tests.push(phtCreateTest("Auto Join with " + defaultNetwork, [defaultNetwork], settingsTest_checkSSID, "Auto Join with " + defaultNetwork));
	tests.push(phtCreateTest("LoadSafariPage", [URL1], safariTest_loadSafariPage, "Load web page in Safari"));
	tests.push(phtCreateTest("WiFiInterfaceActiveTest", null, systemTest_isWiFiInterfaceActive, "Check if WiFi Interface is active"));
	tests.push(phtCreateTest("PingTests", [ping_destination], systemTest_ping, "Ping " + ping_destination));

	//Forget the hidden network
	tests.push(phtCreateTest("Forget " + hiddenNetwork, [hiddenNetwork], settingsTest_forgetWifi, "Forget " + hiddenNetwork));
	//Forget the wpa2 network
	tests.push(phtCreateTest("Forget " + wpa2Network, [wpa2Network], settingsTest_forgetWifi, "Forget " + wpa2Network));

	tests.push(phtCreateTest("Turn Off WiFi", [0], settingsTest_setWifi, "Turn Off WiFi"));
	tests.push(phtCreateTest("Turn On WiFi", [1], settingsTest_setWifi, "Turn On WiFi"));
	tests.push(phtCreateTest("LoadSafariPage2", [URL2], safariTest_loadSafariPage, "Load web page in Safari"));
	tests.push(phtCreateTest("Auto Join with " + defaultNetwork, [defaultNetwork], settingsTest_checkSSID, "Auto Join with " + defaultNetwork));
	tests.push(phtCreateTest("WiFiInterfaceActiveTest", null, systemTest_isWiFiInterfaceActive, "Check if WiFi Interface is active"));
	tests.push(phtCreateTest("PingTests", [ping_destination], systemTest_ping, "Ping " + ping_destination));	
	tests.push(phtCreateTest("Forget " + defaultNetwork, [defaultNetwork], settingsTest_forgetWifi, "Forget " + defaultNetwork));
	
}

function usage() {
	
	system.println("usage: QuickLook.js [--enable <string>] [--disable <string>] [-o <path> | -filepath <path> | --filename <string>] [-l | --list]");
	system.println("	--disable	tests to skip (may use regex to describe tests)");
	system.println("	--enable	tests to run (may use regex to describe tests)");
	system.println("	--filepath	full path for the results file");
	system.println("	--filename	name to use for the results file");
	system.println("	--nosetup	skip the setup phase of the QuickLook")
	system.println("	--noemailsetup	skip the setup email account of the QuickLook")
	system.println("	--writecrashes	write out crashes to the results file")
	system.println("	--list		list the available tests");
	system.println("	--help | -h	usage description");
}

function main() {
	
	var tests = new Array();
	var version = harness_getBuildVersion();
	var filename = "WiFiQuickLook_" + version + ".txt";
	var writeCrashes = false;
	var filepath;
	var enableSetup = true;
	var enableEmailSetup = true;
	var defaultNetwork = "AppleWiFi";
	
	// seed the generator, so that any random events are the same for every run
	system.setRandomSeed(1);
	UIATarget.localTarget().unlockScreenIfNecessary();	// screen must be unlocked to check for springboard app icons
	
	// process command line arguments
	var options = new Options();
	if (options.help || options.h) {
		usage();
		return;
	}
	if (options.list || options.l) {
		addTestsToArray(tests);
		harness_listTests(tests);
		return;
	}
	if (options.filename) filename = options.filename;
	if (options.nosetup) enableSetup = false;
	if (options.writecrashes) writeCrashes = true;
	if (options.noemailsetup) enableEmailSetup = false;
	if (options.o) filepath = options.o;
	else if (options.filepath) filepath = options.filepath;
	else {
		harness_makeDirectory(kReportPath);
		filepath = kReportPath + filename;
	}
	
	// if setup is enabled, add the setup tests to the test array.
	if (enableSetup) {
		
		// Unlock the device
		tests.push("Setup");
		//tests.push(phtCreateTest("UnlockDevice", ["0"], systemTest_lockAndUnlockDevice, "Unlock the device")); 
		// Set auto-lock to never
		tests.push(phtCreateTest("SetAutoLockToNever", ["General", "Auto-Lock", "Never"], settingsTest_chooseCheckmarkedItem, "Set Auto-Lock to Never"));	
			
		// Associate with default network and create email account used for profile
		if(enableEmailSetup) {
					
			// Enabled Known Network UI from Internal Settings
			//tests.push(phtCreateTest("enabledWiFiKnownNetowrkUI", ["Internal Settings", "Settings", "Known Networks UI", 1], settingsTest_changeSingleSwitch, "Enable WiFi Known Network UI from Internal Settings"));
			tests.push(phtCreateTest("EnableWifiLogging", ["Internal Settings", "WiFi", "Logging", "UI Logging", 1], settingsTest_changeSingleSwitch, "Enable Wifi Logging"));
			tests.push(phtCreateTest("EnableWifiManagerLogging", ["Internal Settings", "WiFi", "Logging", "WiFi Manager", "Logging", 1], settingsTest_changeSingleSwitch, "Enable WifiManager Logging"));
			
			tests.push("Configure Email address, Associate with" + defaultNetwork);
			tests.push(phtCreateTest("Configure Email address, Associate with " + defaultNetwork, [1, defaultNetwork], settingsTest_setWifiPro, "Associate with " + defaultNetwork));
			tests.push(phtCreateTest("CreateGmailAccount", ["gmail","wifiabd","wifiabd@gmail.com", "wireless"], settingsTest_createEmailAccount, "Create a wifiabd@gmail.com email account"));
		}
		
		// Delete all the profiles
		tests.push(phtCreateTest("deleteAllProfiles", null, settingsTest_deleteProfile, "Delete All the Profiles"));
		
		//Remove all the preferred WiFi network (Enterprise Netowrk using profiles not included) from Known Network UI
		//tests.push(phtCreateTest("deletePrefferedWiFiNetwork", [], settingsTest_deletePreferredNetwork, "Delete Preferred WiFi Netowrk"));
		tests.push(phtCreateTest("deletePrefferedWiFiNetwork", ["wifi.removeAllPreferredNetworks"], wifiTest_wirelessTester, "Delete Preferred WiFi Netowrk use WirelessTester"));
		
	}
	
	addTestsToArray(tests); // add all of the normal tests to the array
	
	// uncomment this line if you want top data added to the output
	//system.setDefault("com.apple.harness", "utilities", ["/usr/bin/top -o -cpu -l 1"]);
	
	harness_removeFile(filepath);
	harness_runTestsFromArray(tests, filepath, options.disable, options.enable, false, writeCrashes);
	
	system.println("Done Running QuickLook.");
}

main();
