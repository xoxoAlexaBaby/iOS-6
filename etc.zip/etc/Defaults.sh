#!/bin/sh

#################################################################################################
#                                                                                               #
#   ScriptName: Defaults.sh                                                                     #
#                                                                                               #
#   Purpose:    Carries all the default Configs                                                 #
#   Author:     Jerome Jesu                                                                     #
#   Contact:    jesu@apple.com                                                                  #
#   Version:    v22                                                                             #
#                                                                                               #
#   Copyright   2010 Apple. All rights reserved.                                                #
#################################################################################################


############### DEFAULTS if NO OPTIONS specified ###############
SMS_NUMBER=11111111111

# Defaults for Uploading Stats and Logs
STATS_INTERVAL=900
LOG_INTERVAL=14400
MAX_JOIN_ATTEMPTS=5
MAX_FILES_TO_UPLOAD=100
DEFAULT_ITERATIONS=1500

TOOLSDIR="/usr/local/bin"
DEVICENAME=`hostname`
CALL_INTERVAL=15
SMSSTRING1="Stress...12345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"
SMSSTRING2="Stress..."
SMSSTRING3="S"
SLEEPOFFSET=15
MMS_PATH1="$SCRIPTS_DIR/MMS_IMAGE_1.JPG"
MMS_PATH2="$SCRIPTS_DIR/MMS_IMAGE_2.JPG"
MMS_PATH3="$SCRIPTS_DIR/MMS_IMAGE_3.JPG"


######## Other Defaults
RATS=( C2K  UMTS  GSM  LTE )
SLEEPOFFSET=15
LOCMON_RUNTIME=30
LOCMON_SLEEPTIME=600

#### DATA DOWNLOAD DEFAULTS
MAX_DATA_FAIL_ATTEMPTS=7
MIN_DATA_FAIL_ATTEMPTS=5
MAX_TIME_FOR_DOWNLOADS=300
MIN_DATA_RATE_UMTS=0.200
MIN_DATA_RATE_LTE=0.500
MIN_DATA_RATE_GSM=0.050
MIN_DATA_RATE_C2K=0.200
URL0="http://pttest.apple.com/200KB.txt"
URL1="http://pttest.apple.com/1MB.txt"
URL2="http://pttest.apple.com/2MB.txt"
URL3="http://pttest.apple.com/5MB.txt"
URL4="http://pttest.apple.com/10MB.txt"
URL5="http://pttest.apple.com/50MB.txt"
URL6="http://pttest.apple.com/100KB.txt"
iPERFURL="pttest.apple.com"
PING_PACKET_SIZE=( 64  256  512  1024  2048  4096  8192  65536 )
PING_INTERVALS=( .200  0.250  .300  .500  0.750  1   2   3   4  )



if [ -e /$SCRIPTS_DIR/config_maverick.sh ]; then
	echo "config_maverick.sh file is present. Getting the Defaults."
	source $SCRIPTS_DIR/config_maverick.sh

elif [ -e /$SCRIPTS_DIR/config_eureka.sh ]; then
	echo "config_eureka.sh file is present. Getting the Defaults."
	source $SCRIPTS_DIR/config_eureka.sh
fi


# Default Directory for Baseband logs.
crashDir="/Library/Logs/CrashReporter/"
wirelessDir="/private/var/wireless/Library/Logs/CrashReporter/"
logsDir="/private/var/wireless/Library/Logs/CrashReporter/Baseband/"
logFiles="$logsDir/*csi.txt"
mobileLogs="/var/mobile/Library/Logs/CrashReporter/*.plist"
mobileDir="/var/mobile/Library/Logs/CrashReporter/"
csiLogsDir="CsiLogs"
DEVICENAME=`hostname`


##############################
dcount=0
count=0
callCount=0
smsCount=0
pass=0
fail=0

pdpFails=0
pdpAttempts=0
minUpTime=0
filesUploadedSoFar=0
uploadFlag=0
uploadAttempts=0
uploadPassCount=0
uploadFailCount=0
DataAttempts=0
dataFailCount=0
dataPassCount=0
dataFailCount3=0
dataFailCount5=0
dataFailTracker=0
lastlowThroughput=1
proceedDataTransfer=0

dontSendSMS=0
spass=0
sfail=0
mmsAudioCount=0
mmsVideoCount=0
mmsImageCount=0
mmscount=0
mmsPass=0
mmsFail=0

proximitySensor=0
startTcpDump=0
wifiFailCount=0

###################################################################

# Processing the Command Line Arguments with Options.

iterations=0; number=0;interval=0;
DoSleep=1

EnableLocmon=
noIdleSleep=
dataFailureLogs=0
round=0
EnableUpDown=
sNumber=0
UPLOAD=
disableLogsUpload=0
additionalLoggging=0
changeSSID=0
EnableAWD=0

while getopts 'ch:i:n:l:wuksdar:gmx:ob:' OPTION
do
	case "$OPTION" in
	
		h )	interval=1
			CALL_INTERVAL="$OPTARG";;

		i )	iterations=1
			LOOPS="$OPTARG"
			echo "#### $OPTION -- $OPTIND $OPTARG.\n";;
			
		n )	number=1
			LOOP_BACK_NUMBER="$OPTARG";;
		
		l )	sNumber=1
			smsNumber="$OPTARG";;
				
		w )	DoSleep=0
			echo " #### SLEEP DISABLED --  $OPTION, $OPTIND, $OPTARG.";;
		
		u )	UPLOAD=1
			echo " #### UPLOAD ENABLED.";;
		
		k )	disableLogsUpload=1
			echo " #### Disabling Logs Upload.";;
				
		d ) dataFailureLogs=1
			echo " #### Enabling Data Failures Logging --  $OPTION, $OPTIND, $OPTARG.";;
		
		a ) additionalLoggging=1
			echo " #### Additional Logging Enabled --  $OPTION, $OPTIND, $OPTARG.";;

		r ) round=1
			ROUNDINFO="$OPTARG"
			echo " #### RUNNING AGAIN on the same day - $ROUNDINFO -- $OPTION, $OPTIND, $OPTARG.- ROUNDINFO=$ROUNDINFO";;
		
		g )	EnableLocmon=1
			echo " #### GPS ENABLED -- $OPTION, $OPTIND, $OPTARG. EnableLocmon = $EnableLocmon.";;

		m )	EnableUpDown=1
			echo " #### Simultaneous Upload and Downloads -- $OPTION, $OPTIND, $OPTARG.";;

		o )	noIdleSleep=1
			echo " #### NO IDLE SLEEP Enabled -- $OPTION, $OPTIND";;

		c )	EnableAWD=1
			echo " #### AWD Agent Enabled -- $OPTION, $OPTIND";;

		b )	SLEEPOFFSET="$OPTARG"
			echo " #### SLEEP OFFSET = $SLEEPOFFSET -- $OPTION, $OPTIND";;

		x )	changeSSID=$OPTARG
			DEFAULT_SSID="Dejavu"; 
			echo " #### Changing SSID to $DEFAULT_SSID";;

		/?)	echo "INVALID OPTIONS.\n"; 
			usage;
			exit 2;;
	esac
	
done

shift $(($OPTIND - 1))

RAT=${RATS[$technology]}
echo "### RAT chosen : $RAT"
weblink0=$URL0; weblink1=$URL2; weblink2=$URL2; weblink3=$URL3;  
MIN_DATA_RATE=${MIN_DATA_RATE_C2K};


## SET THE NUMBER OF ITERATIONS
if [ $iterations -eq 1 ]; then  echo "\n Number of iterations -i \"$LOOPS\" specified";  
else	LOOPS=$DEFAULT_ITERATIONS; fi


## SET THE CALL INTERVAL
if [ $interval -eq 1 ] ; then  printf 'Option -h "%s" specified\n' "$CALL_INTERVAL";
else	CALL_INTERVAL=15; fi


## SET THE LOOP_BACK_NUMBER
if [ $number -eq 1 ] ;  then  
	echo "Loop-Back Number -n \"$calledNumber\" specified";
	LOOP_BACK_NUMBER=$calledNumber;
else
	LOOP_BACK_NUMBER=$LOOP_BACK; 
fi

# GETTING THE VERSION INFOs
$TOOLSDIR/CoreTelephonyMonitor -q 2> BBVersion.txt &

if [ -e /$SCRIPTS_DIR/getInfo.sh ]; then
	echo "getInfo.sh file is present. Getting the values."
	source $SCRIPTS_DIR/getInfo.sh
	getBuildVersions
else
	DEVICENAME=`hostname`
	Baseband=`grep "Firmware Version" BBVersion.txt | cut -c29-36`
	APBuild=`sw_vers -buildVersion`	
fi
echo "Final: Baseband -- $BB_Build\n"
