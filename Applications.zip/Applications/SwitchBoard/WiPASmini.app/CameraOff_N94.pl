#!/usr/bin/perl

open (PS, "| /usr/local/bin/h4isp");
printf (PS "off\n");
printf (PS "quit\n");
printf (PS "\n\r");
close (PS);