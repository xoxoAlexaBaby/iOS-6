while [ 1 ]
do
	/usr/local/bin/DataContext up
	/usr/local/bin/StreamPerf HTTP -e -x 1 http://17.254.17.224/2MB.txt
	sleep 15
done

