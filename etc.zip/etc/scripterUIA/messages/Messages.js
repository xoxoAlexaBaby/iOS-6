/*
 Class: UIApp (messages)
 Messages object
 */
#import "../libs/SpringBoard.js"
#import "../libs/UIAAppCameraAdditions.js"
#import "../libs/UIAAppMessagesAdditions.js"

messages = UIAApp.application("Messages", "com.apple.MobileSMS");

if (typeof telephony == 'undefined') telephony = new Telephony();

if (typeof messages != 'undefined') {
	
	//----------------------------------------------------------------------------------------
	//	Function: tapComposeButton 
	//		Taps the compose button to start a new message.
	//
	//	Parameters: 
	//		None
	//
	//	Returns: 
	//		None
	//
	//	Throws:
	//		An error if the "Compose" button can't be tapped.
	//----------------------------------------------------------------------------------------
	messages.tapComposeButton = function tapComposeButton() {	
		try {
			UIALogger.logMessage("Tapping 'Compose' button");
			var composeButton = this.navigationBar().buttons()["Compose"];
			if (!composeButton.isValid()) {
				throw new Error("Could not tap 'Compose' button");
			}
			composeButton.tap();
		
		} catch (e) { 
			if (typeof e.message == "string") UIALogger.logError("Caught error: " + e.message);
			throw new Error ("Could not tap Compose Button to create a new message"); 
		}
	}
	
	//----------------------------------------------------------------------------------------
	//	Function: getToMessagesList 
	//		Goes to the main list of message threads.
	//
	//	Parameters: 
	//		None
	//
	//	Returns: 
	//		None
	//
	//	Throws:
	//		An error if the function cannot get to the list of messages
	//----------------------------------------------------------------------------------------
	messages.getToMessagesList = function getToMessagesList() {
		this.launchIfNotActive(); 
		
		UIATarget.localTarget().pushTimeout(0.1);
		
		// Look for a 'Cancel' button in an Action Sheet.
		var cancelButton = this.actionSheet().buttons()["Cancel"];
		if (cancelButton.isValid() && cancelButton.isVisible()) {
			UIALogger.logDebug("Tapping 'Cancel' button in the action sheet");
			cancelButton.tap();
		}
		
		// Look for the 'Retake' button that shows up after you've taken a picture.
		var retakeButton = this.mainWindow().images().firstWithPredicate("ANY buttons.name == 'Retake'").buttons()["Retake"]
		if (retakeButton.isValid() && retakeButton.isVisible()) {
			UIALogger.logDebug("Tapping 'Retake' button in camera view");
			retakeButton.tap();
			UIATarget.localTarget().delay(2); // give a bit of time here for things to reset...
		}
		
		// Look for the 'Cancel' button that shows up when trying to take a picture.
		var cancelButton = this.mainWindow().images().firstWithPredicate("ANY buttons.name == 'Cancel'").buttons()["Cancel"]
		if (cancelButton.isValid() && cancelButton.isVisible()) {
			UIALogger.logDebug("Tapping 'Cancel' button in camera view");
			cancelButton.tap();
			UIATarget.localTarget().delay(2); // give a bit of time here for things to reset...
		}
		
		// Hit the cancel button nav bar button if it exists.  (i.e. if someone tries to Edit the list of text message threads)
		// There can be a couple of nav bar 'Cancel' buttons in a row.
		for (var i=0; i<5; i++) {
			var cancelButton = this.navigationBar().buttons()['Cancel']; 
			if (!cancelButton.isValid()) { 
				// if you are editing an sms, the nav bar is not in the mainWindow but is the first window in the array.
				cancelButton = this.windows()[0].navigationBar().buttons()['Cancel'];
			}	
			if (cancelButton.isValid()) {
				UIALogger.logDebug("Tapping 'Cancel' button in navigation bar");
				cancelButton.tap();
				UIATarget.localTarget().delay(1); // give a bit of time here for things to reset...
			}
			else break;
		}
		
		// Look for an action sheet and hit the correct button -- separated this out, in case there are other action sheet buttons we want to look for later
		var theActionSheet = this.actionSheet();
		if (theActionSheet.isValid()) {
			var actionSheetCancel = theActionSheet.buttons()["Cancel"];
			if (actionSheetCancel.isValid()) {
				UIALogger.logDebug("Tapping 'Cancel' button in the action sheet");
				actionSheetCancel.tap();
				UIATarget.localTarget().delay(1); // give a bit of time here for things to reset..
			}
		}
		
		// If the leftButton exists, but it is not valid, or if the 'Play' button exists we should tap the screen once to bring the controls up.
		// We are either viewing a photo or video here.
		if (!this.navigationBar().leftButton().isValid() || this.toolbar().buttons()["Play"].isValid()) {
			UIALogger.logDebug("Tapping the screen to bring controls up");
			UIATarget.localTarget().tap({x:50, y:50});
			UIATarget.localTarget().pushTimeout(10);  // wait for controls to come up
			leftButton = this.navigationBar().leftButton();
			if (leftButton.isValid() && leftButton.name() != "Edit") {
				// tap the left button right away, before controls go away again.
				UIATarget.localTarget().delay(0.3); // give animation time to finish
				UIALogger.logMessage("Tapping left button before controls go away");
				leftButton.tap();
			}
			UIATarget.localTarget().popTimeout();
		}
		
		UIATarget.localTarget().popTimeout();

		this.returnToTopLevel();
		
		if (this.navigationBar().staticTexts().firstWithPredicate("name beginswith 'Messages'").isValid()) {
			UIALogger.logMessage("Successfully got to list of Messages");
		} 
		else {
			this.logElementTree(); // try to figure out what's causing <rdar://problem/8017449>
			throw new Error("Could not get to messages list.");
		}	
	}
	
	//----------------------------------------------------------------------------------------
	//	Function: viewIncomingMessage 
	//		Clicks on the alert to view the messsage.  Needs to have alerts disabled in
	//		order for this to work.
	//
	//	Parameters: 
	//		None
	//	
	//	Returns: 
	//		Returns false if there isn't an alert.  Returns true if there is an alert.  
	//
	//	Throws:
	//		An error 
	//----------------------------------------------------------------------------------------
	
	messages.viewIncomingMessage = function viewIncomingMessage() {
		UIALogger.logMessage("Trying to find incoming message");
		
		var viewButton = this.alert().buttons()["View"];
		if (viewButton.isValid()) {
			UIALogger.logMessage("Tapping the View button");
			viewButton.tap();
			return true;
		}		
		else {
			return false;
		}
	}
	
	//----------------------------------------------------------------------------------------
	//	Function: tapMostRecentMMSImage 
	//		Clicks on the most recent MMS message.
	//
	//	Parameters: 
	//		None
	//	
	//	Returns: 
	//		None
	//
	//	Throws:
	//		Throws an error if it can't tap the message.
	//----------------------------------------------------------------------------------------
	
	messages.tapMostRecentMMSImage = function tapMostRecentMMSImage() {	
		UIALogger.logMessage("Tapping the most recent MMS");
		
		var theWindow = this.getMessageViewWindow();
		if (!theWindow) {
			throw new Error("Could not find the message view window.");
		}
		
		var allBuddyMessages = theWindow.tableViews()[0].cells().withPredicate("name beginswith 'Buddy Message: Contains media'");
		
		if (allBuddyMessages.length <= 0) {
			
			throw new Error("No 'Buddy Messages' found.");
		}
		
		var lastMessageIndex = allBuddyMessages.length - 1;
		var mostRecentMessage = allBuddyMessages[lastMessageIndex];
		mostRecentMessage.scrollToVisible();
		UIATarget.localTarget().delay(3);
		try {
			mostRecentMessage.buttons()[0].tap();
			UIATarget.localTarget().delay(5);
		} catch (e) {
			UIALogger.logError("Caught Error: " + e.message);
			throw new Error("The last buddy message found is not valid.");
		}
	}

	//----------------------------------------------------------------------------------------
	//	Function: isDisplayedMMSExpectedType 
	//		Checks to see if the displayed MMS has the expected media type (Photo or Video)
	//
	//	Parameters: 
	//		expectedType (string) - type of image that we expect, i.e. "photo" or "video"
	//	
	//	Returns: 
	//		None
	//	
	//	Throws:
	//		An error if it can't tap the message.
	//----------------------------------------------------------------------------------------
	
	messages.isDisplayedMMSExpectedType = function isDisplayedMMSExpectedType(expectedType) {			
		// case of photo
		if (expectedType.toLowerCase().match("photo")) {
			if (!this.mainWindow().scrollViews()[0].scrollViews()[0].images().firstWithPredicate("name beginswith 'Photo'").isValid()) {
				UIALogger.logMessage("Displayed MMS media is not a photo.");
				return false;
			}
			else {
				UIALogger.logMessage("Displayed MMS media is a photo, as expected.");
				return true;
			}
			
		}
		
		// case of video
		if (expectedType.toLowerCase().match("video")) {
			if (!this.mainWindow().scrollViews()[0].elements().firstWithPredicate("name beginswith 'Video'").isValid()) {
				UIALogger.logMessage("Displayed MMS media is not a video.");
				return false;
			}
			else {
				UIALogger.logMessage("Displayed MMS media is a video, as expected.");
				return true;
			}
		}
	}
	
	//----------------------------------------------------------------------------------------
	//	Function: waitForSendToComplete 
	//		After sending an SMS or MMS, waits for the send to finish
	//
	//	Optional Parameters: 
	//		timeout (number) - number of seconds to wait. If not provided, we
	//			wait 60 seconds.
	//	
	//	Returns: 
	//		1 if the 'Sending' notice went away or wasn't there at all, 0 if we
	//		reached the timeout and it was still there.
	//
	//  WARNING: 
	//		This currently doesn't work because of this bug: 
	//		<rdar://problem/7739689> Calling waitForInvalid on a table cell element that has moved offscreen times out and returns false
	//----------------------------------------------------------------------------------------
	
	messages.waitForSendToComplete = function waitForSendToComplete(timeout) {
		if (!timeout) timeout = 60;
		var finished = 1;
		UIATarget.localTarget().pushTimeout(1);
		
		// the nav bar is sometimes in the mainWindow and sometimes not...
		var sendingElement = this.windows().firstWithPredicate("navigationBar != UIAElementNil").navigationBar().elements().firstWithPredicate("name beginswith 'Sending'");
		if (sendingElement.isValid()) {
			UIATarget.localTarget().pushTimeout(timeout);
			UIALogger.logMessage("Waiting " + timeout + " seconds for 'Sending' to go away.");
			finished = sendingElement.waitForInvalid();
			UIATarget.localTarget().popTimeout();
		}
		else {
			UIALogger.logMessage("Did not find 'Sending' message on-screen");
		}
		
		if (!finished) {
			UIALogger.logWarning("Sending element is still onscreen.");
		}
		UIATarget.localTarget().popTimeout();
		return finished;
	}
	
	//----------------------------------------------------------------------------------------
	//	Function: getMessageViewWindow 
	//		Returns the message entry area UIAElement.
	//
	//	Parameters: 
	//		None
	//	
	//	Returns: 
	//		Returns null if we cannot find the MessageViewWindow.  Otherwise, it returns
	//		the MessageViewWindow.  (i.e. where messages are displayed)
	//----------------------------------------------------------------------------------------
	messages.getMessageViewWindow = function getMessageViewWindow() {	
		var theWindows = this.windows();
		var messageViewWindow;
		var found = 0;
		for (var i=0; i<theWindows.length; i++) {
			messageViewWindow = theWindows[i];
			if (messageViewWindow.tableViews()[0].buttons()["Call"].isValid()) {
				found = 1;
				break;
			}
		}
		if (!found) {
			return null;
		}
		return messageViewWindow;
	}
		
	//----------------------------------------------------------------------------------------
	//	Function: sendTextMessage 
	//		Sends a text message to the phone number(s) specified.
	//
	//	Parameters: 
	//		textToSend (string) - the message to send
	//		phoneNumbers (string or array of strings) - the phone number(s) to send the message to. 
	//			(optional) If not specified, the function sends the message to ourselves.  
	//	
	//	Returns: 
	//		None
	//
	//	Throws:
	//		An error if not successful
	//----------------------------------------------------------------------------------------
	messages.sendTextMessage = function sendTextMessage(textToSend, phoneNumbers) {	
		if (!phoneNumbers) phoneNumbers = telephony.myPhoneNumber;
		
		// make phoneNumbers into an array, if it isn't already (note that typeof an array is 'object')
		if (typeof phoneNumbers != "object") phoneNumbers = new Array(phoneNumbers);
		
		// Get to list of messages
		try {
			messages.getToMessagesList();
		}
		catch (e) {
			if (typeof e.message == "string") UIALogger.logError("Caught error: " + e.message);
			throw new Error("Could not get to list of messages.");
		}
		
		// Create a new message.
		this.tapComposeButton();
		
		// Fill in the text message fields and click send.
		this.composeTextMessage(textToSend, phoneNumbers);
	}

	//----------------------------------------------------------------------------------------
	//	Function: waitForTextMessage
	//		Waits for one a specified message to be received.  If nothing is
	//		filled out it will return with a 'true' 
	//
	//	Options: 
	//		message (string) - the message to wait for (optional).  Must be an exact match.
	//		sender (string) - the sender the message should be from (optional)
	//		mediaType (string) - the type of media to wait for (i.e. "video", "audio", "stillImage", etc)
	//		timeout (string) - max number of seconds to wait before giving up. 
	//	
	//	Returns: 
	//		True if the the text message was received. False if it wasn't.  
	//----------------------------------------------------------------------------------------
	messages.waitForTextMessage = function waitForTextMessage(options) {
		if (typeof options == 'undefined') options = new Object(); 
		
		if (!options.timeout) options.timeout = 120;
		
		var start = new Date().getTime();
		var elapsedTime = 0;
		var lastReceived = null;
		var received;
		var messageMatch = 1;

		// wait for the message, until we have a match on the send and/or message
		while (elapsedTime < options.timeout) {
			UIALogger.logMessage("Waiting " + options.timeout + " seconds for message");
			received = telephony.waitForSMS(options.timeout);
			if (received && typeof received == "object") {
				UIALogger.logMessage("Received message from sender " + received.address + " with text '" + received.text + "'.");
				if (options.sender && received.address.indexOf(options.sender) < 0) messageMatch = 0;
				if (options.message && received.text != options.message) messageMatch = 0;
				if (options.mediaType) {
					UIATarget.localTarget().delay(5); // make sure we wait long enough for message to appear
					this.tapMostRecentMMSImage();
					if (!this.isDisplayedMMSExpectedType(options.mediaType)) {
						messageMatch = 0;
					}
				}
				if (messageMatch == 1) { 
					UIALogger.logMessage("Message received matched given parameters.");
					break;
				}
				messageMatch = 1;	
				lastReceived = received;
			}
			elapsedTime = ((new Date().getTime()) - start)/1000;
			options.timeout = options.timeout - elapsedTime;
			UIALogger.logMessage("Message received (if any) was not the expected message.");
		}

		if (!received || typeof received != "object") {
			// use the last message we found if the most recent isn't valid--this is just for error tracking purposes.
			received = lastReceived;  
		} 

		// second chance to check the lastReceived SMS -- this will tell us if we received an SMS at all, although we know it won't be the right one
		if (!received || typeof received != "object") {
			UIALogger.logMessage("Did not receive a text message.");
			return false;
		}

		// Check to see if sender and/or message match up to what we're expecting.
		if (options.sender && (received.address.indexOf(options.sender) < 0)) {
			UIALogger.logMessage("Was looking for message from \"" + options.sender + "\" but received message from \"" + received.address + "\".");
			return false;
		} 
		if (options.message && received.text != options.message) {
			UIALogger.logMessage("Was looking for message \"" + options.message + "\" but received message \"" + received.text + "\".");
			return false;
		}

		return true;
	}
	
	//----------------------------------------------------------------------------------------
	//	Function: waitForMultipleTextMessages
	//		Waits for one or more text messages to be received.	
	//
	//  Parameters: 
	//		messageArray (array of message objects) - this array contains objects with these two
	//			items: sender and message.  This describes the message we expect
	//			and the phone number we expect it from.
	//
	//  Optional Parameters: 
	//		timeout (string) - max number of seconds to wait before giving up.  120 is default
	//		expectedPercentage (number) - number from 0 to 1 indicating the expected percentage of
	//			messages we should get.
	//
	//	Usage:
	//		messages.waitForMultipleTextMessages(messageArray:[{sender:"5555555555", message:"Hi."}]) 
	//	
	//	Returns: True if the the text message was received. False if it wasn't.  
	//----------------------------------------------------------------------------------------
	messages.waitForMultipleTextMessages = function waitForMultipleTextMessages(messageArray, options) {
		if (!options) options = new Object();
		var timeout = (typeof options.timeout != 'undefined') ? options.timeout : 120;
		var expectedPercentage = (typeof options.expectedPercentage != 'undefined') ? options.expectedPercentage : 1;
		if (typeof messageArray != 'object') throw new Error ("Must supply an array of phone numbers and messages to " + arguments.callee.name);

		var start = new Date().getTime();
		var elapsedTime = 0;
		var lastReceived = null;
		var received;
		var numMatched = 0;
		var numExpectedMessages = messageArray.length;

		// wait for the messages, until we have the expected number of matches or until we time out
		while ((elapsedTime < timeout) && (numMatched < numExpectedMessages)) {
			messageMatch = 1;
			UIALogger.logMessage("Waiting " + timeout + " seconds for message(s)");
			received = telephony.waitForSMS(timeout);
			if (received && typeof received == "object") {
				UIALogger.logMessage("Received message from sender " + received.address + " with text '" + received.text + "'.");
				for (var i=0; i<messageArray.length; i++) {
					var messageMatch = 1; // assume we have a match until proven otherwise.
					UIALogger.logMessage("Checking if message received matched expected message [" + i + "], with message of '" + messageArray[i].message + "' and sender '" + messageArray[i].sender + "'");
					if (messageArray[i].sender && !received.address.indexOf(messageArray[i].sender) < 0) messageMatch = 0; // don't use 'match'  because the '+1' is intrepreted as a reg exp.
					if (messageArray[i].message && received.text != messageArray[i].message) messageMatch = 0;
					if (messageMatch == 1) {
						UIALogger.logMessage("Message '" + received.text + "' matched expected message [" + i + "]");
						break;
					}
					else {
						UIALogger.logMessage("Expected message [" + i + "] did not match the received message")
					}
				}
				if (messageMatch) {
					numMatched++;
				}
				lastReceived = received;
			}
			elapsedTime = ((new Date().getTime()) - start)/1000;
			timeout = timeout - elapsedTime;
		}

		if (!received || typeof received != "object") {
			// use the last message we found if the most recent isn't valid--this is just for error tracking purposes.
			received = lastReceived;  
		} 

		// second chance to check the lastReceived SMS -- this will tell us if we received an SMS at all, although we know it won't be the right one
		if (!received || typeof received != "object") {
			UIALogger.logMessage("Did not receive a text message.");
			return false;
		}
		
		var actualPercent = numMatched/numExpectedMessages;		
		
		if (actualPercent < expectedPercentage) {
			UIALogger.logMessage("Expected " + numExpectedMessages + " message(s), but got " + numMatched + " matching message(s).  Needed to get a percentage of " + expectedPercentage*100);
			return false;
		}
		UIALogger.logMessage("Got expected message(s).  Expected " + expectedPercentage*100 + " percent and got " + actualPercent*100 + " percent of the messages");

		return true;
	}
	
	// --------------------------------------------------------------------------------
	//	Function: chooseMMSToSend
	//		Sends a photo via MMS to the phone number specified. 
	//		Depending on the parameters, it may retry if the first message is not received 
	//		within the given timeout.
	//
	//	Parameters: 
	//		None
	//
	//  Optional Arguments 
	//		from (string) -  Specifies where to get the photo from. "Choose Existing",
	//			"Take Photo", or "Take Video" are the options.  If nothing is specified, it will 
	//			take a photo.
	//		photoAlbum (string) - If from specifies that an existing photo is to be used,
	//			this setting specifies which photo album to use.  If nothing is specified, we
	//			choose one at random.  (This parameter does nothing if "Take Photo" is specified.)
	//	
	//	WARNING: 
	//		Doesn't work due to <rdar://problem/6956480> photos: Photo Album Names are no longer shows up in scripter
	//
	//	Returns:
	//		true if successful, false if not
	// --------------------------------------------------------------------------------
	messages.chooseMMSToSend = function chooseMMSToSend(options) {
		if (typeof options == 'undefined') options = new Object;
		
		var messageEntryWindow = this.getMessageEntryWindow();
		if (!messageEntryWindow || !messageEntryWindow.isValid()) {
			throw new Error("Could not find message entry window");
		}
		
		var attachMediaButton = messageEntryWindow.images()[0].buttons()["photoButton"];
		if (!attachMediaButton.isValid()) {
			UIALogger.logMessage("Trying to tap first button in hopes that it's the camera icon");
			//<rdar://problem/7990856> The MMS "Attach Media" button is not named on N90s
			attachMediaButton = messageEntryWindow.images()[0].buttons()[0];
			if (!attachMediaButton.isValid()) {
				throw new Error("Could not find Camera Icon");
			}
		}
		UIALogger.logMessage("Tapping the Camera icon");
		attachMediaButton.tap();
		UIATarget.localTarget().delay(3);
		
		// Take a photo or video
		if (!options.from || (options.from.toLowerCase().match("take"))) {
			UIALogger.logMessage("Taking a new photo or video");
			try {
				this.actionSheet().buttons().firstWithPredicate("name beginswith 'Take'").tap();
			} catch (e) {
				UIALogger.logMessage("Caught Error: " + e.message);
				throw new Error ("Could not tap the 'Take Photo or Video' button");
			}
			
			// take the picture or video
			if (!options.from || (options.from.toLowerCase().match("photo"))) {
				this.takePicture();
			}
			else {
				this.captureVideo(5);
			}
			UIATarget.localTarget().delay(10);  // give us a little time to get to the next page.
			
			try {
				UIALogger.logMessage("Tapping the 'Use' button");
				this.mainWindow().images().firstWithPredicate("ANY buttons.name == 'Use'").buttons()["Use"].tap();
			}
			catch(e) {
				UIALogger.logMessage("Caught Error: " + e.message);
				throw new Error("Could not tap the 'Use' button");
			}
			return;
			
		}
		// Choose existing photo
		else {
			UIALogger.logMessage("Choosing an existing photo");
			try {
				this.actionSheet().buttons()["Choose Existing"].tap();
			} catch (e) {
				UIALogger.logMessage("Caught Error: " + e.message);
				throw new Error ("Could not tap the 'Choose Existing' button");
			}
			
			// Check for "No Photos or Videos" message
			if (this.mainWindow().staticTexts().firstWithPredicate("name beginswith 'No Photos'").isValid()) {
				throw new Error("No photos or videos are present on the device.");
			}
			
			// if a photo album was specified choose it, otherwise, choose first item in list
			var photoAlbumElement;
			if (options.photoAlbum) {
				UIALogger.logMessage("Choosing photo album '" + options.photoAlbum + "'");
				photoAlbumElement = this.mainWindow().tableViews()[0].cells().firstWithPredicate("name beginswith '" + options.photoAlbum + "'");
				
			}
			else {
				var theAlbums = this.mainWindow().tableViews()[0].cells();
				var photoAlbumElement = null;
				for (var i=0; i<theAlbums.length; i++) {
					if (theAlbums[i].name().indexOf("(") > 0) {
						// If a album has parenthesis in the title, it means there are photos there, i.e. "Camera Roll  (4)"
						photoAlbumElement = theAlbums[i];
						break;
					}
				}
				if (photoAlbumElement && photoAlbumElement.isValid())
					UIALogger.logMessage("Choosing photo album '" + photoAlbumElement.name() + "'");
			}
			if (!photoAlbumElement || !photoAlbumElement.isValid()) {
				throw new Error("Could not find the appropriate photo album");
			}
			photoAlbumElement.tap();
			UIATarget.localTarget().delay(2);  // delay for a bit to allow for the photo album to be brought up (otherwise we use old one)
			
			// Choose a photo and tap it.
			try {
				UIALogger.logMessage("Choosing a photo");
				var theCell = this.mainWindow().tableViews()[0].cells()[0];
				theCell.scrollToVisible();
				UIATarget.localTarget().delay(2);  // wait for scroll to finish
				var thePhoto = theCell.elements()[0];
				if (!thePhoto.isValid()) {
					throw new Error("Could not find a photo to click on.");
				} 
				thePhoto.tap();
				UIATarget.localTarget().delay(10);  // wait for photo to display, 'Choose' button seems to display much before it is tappable
			}
			catch (e) {
				UIALogger.logMessage("Caught error: " + e.message);
				throw new Error("Could not tap 'Choose' button");
			}
			
			// Tap the 'Choose' Button.
			try {
				UIALogger.logMessage("Tapping the 'Choose' button");
				this.mainWindow().images().firstWithPredicate("ANY buttons.name == 'Choose'").buttons()["Choose"].tap();
			}
			catch (e) {
				UIALogger.logMessage("Caught error: " + e.message);
				throw new Error("Could not tap 'Choose' button");
			}
			
		}

	}
	
	// --------------------------------------------------------------------------------
	//	Function: sendPhotoOrVideoMMS 
	//		Sends a photo via MMS to the phone number specified. 
	//		Depending on the parameters, it may retry if the first message is not received 
	//		within the given timeout.
	//
	//	Parameters: 
	//		None
	//
	//  Optional Arguments 
	//		phoneNumbers (string) - Phone number to send the MMS to.  If no phone number
	//			is specified, the MMS will be sent to the phone itself.
	//		from (string) -  Specifies where to get the photo from. "Choose Existing",
	//			"Take Photo", or "Take Video" are the options.  If nothing is specified, it will 
	//			take a photo.
	//		photoAlbum (string) - If from specifies that an existing photo is to be used,
	//			this setting specifies which photo album to use.  If nothing is specified, we
	//			choose one at random.  (This parameter does nothing if "Take Photo" is specified.)
	//		
	//		textToSend (string) - a string indicating any text to send. (If not specified, no
	//			text is sent with the photo.)
	//		timeout (number) - Amount of time (in seconds) to wait for SMS to send/receive.
	//		contactNames (string) - Name of contact to send to.
	//
	//	WARNING: 
	//		photoAlbum argument is not available due to
	//		<rdar://problem/6956480> photos: Photo Album Names are no longer shows up in scripter
	//
	//	Returns:
	//		true if successful, false if not
	// --------------------------------------------------------------------------------
	messages.sendPhotoOrVideoMMS = function sendPhotoOrVideoMMS(options) {
		
		// set phoneNumber if specified. if not, use own phone number
		if (!options.phoneNumbers) {
			if (!options.contactNames) {
				options.phoneNumbers = new Array(telephony.myPhoneNumber);
				if (!options.phoneNumbers) {
					throw new Error("Failed to get device's phone number.");
				}
			}
		}
		else if (typeof options.phoneNumbers == 'string') {
			// if we only have one phoneNumber, make it into an array.
			options.phoneNumbers = new Array(options.phoneNumbers);
		}
		
		// set contactNames if specified
		if (typeof options.contactNames == 'string') {
			options.contactNames = new Array(options.contactNames);			
		}
		
		messages.getToMessagesList();
		
		// Create a new message.
		this.tapComposeButton();
		
		// enter the phone numbers
		if (options.phoneNumbers) {
			this.enterPhoneNumbers(options.phoneNumbers);
		}
		
		// enter contact names
		if (options.contactNames) {
			this.enterContactNames(options.contactNames);
		}
		
		// enter text
		if (options.textToSend) {
			this.enterMessageText(options.textToSend);
		}
		
		// choose (or create) the photo or video
		this.chooseMMSToSend(options);
		UIATarget.localTarget().delay(2); // give time for animation to take place.
		
		// if any text is specfied, enter it here.  then tap the send button.
		this.tapSend();
		
	}
	
	
	//----------------------------------------------------------------------------------------
	//	Function: deleteThreadByNumber 
	//		Deletes the specified thread.
	//
	//	Parameters: 
	//		None needed.  If no arguments are given, the first thread is deleted.
	//
	//	Optional Parameters:
	//		threadIndex (integer) - thread number to delete.  
	//		threadName (string) - thread name to delete.  This is a wildcard match, i.e. 
	//			name matches '(408) 555-5555'
	//
	//  	Note: 
	//		If both 'number' and 'title' are provided, only the number will be used
	//	
	//	Returns: 
	//		None
	//
	//	Throws:
	//		An error if not successful
	//----------------------------------------------------------------------------------------
	messages.deleteThreadByNumber = function deleteThread(options) {	
		if (typeof options == 'undefined' || !options) options = new Object();
		if (typeof options.threadIndex == 'undefined') options.threadIndex = null;
		if (typeof options.threadName == 'undefined') options.threadName = null;
		
		//if (!threadIndex) threadIndex = 0;
		
		// Get to list of messages
		try {
			this.getToMessagesList();
		}
		catch (e) {
			if (typeof e.message == "string") UIALogger.logError("Caught error: " + e.message);
			throw new Error("Could not get to list of messages.");
		}
		
		// check to make sure there are threads in the list.
		var allThreads = this.mainWindow().tableViews()[0].cells();
		if (allThreads.length < 0) {
			throw new Error ("Could not find any valid message threads in the list.");
		}
		var startNumberOfThreads = allThreads.length;
		
		// Find the thread we want to delete
		var theThread;
		if (options.threadIndex) {
			// delete thread by index
			UIALogger.logMessage("Getting ready to delete thread with index " + options.threadIndex);
			theThread = allThreads[options.threadIndex];
			if (!theThread.isValid()) {
				throw new Error ("Not enough threads in list--requested thread " + options.threadIndex + ", but there are only " + allThreads.length + " thread(s).");
			}
		}
		else if (options.threadName) {
			// delete thread by name
			UIALogger.logMessage("Getting ready to delete thread with name " + options.threadName);
			theThread = allThreads.firstWithPredicate("name contains '" + options.threadName + "'");
			if (!theThread.isValid()) {
				throw new Error ("Could not find thread with name matching " + options.threadName);
			}
		}
		else {
			// thread to delete not specified--delete the first thread
			UIALogger.logMessage("Getting ready to delete thread at index 0");
			theThread = allThreads[0];
			if (!theThread.isValid()) {
				throw new Error ("Not enough threads in list--requested thread " + options.threadIndex + ", but there are only " + allThreads.length + " thread(s).");
			}
		}
		
		theThread.scrollToVisible();
		UIATarget.localTarget().delay(0.5); // wait for scroll to take place
		
		
		// tap the "Edit" button
		UIALogger.logMessage("Tapping the 'Edit' button");
		var editButton = this.navigationBar().buttons()["Edit"];
		if (!editButton.isValid) {
			throw new Error ("Can't find the edit button.");
		}
		editButton.tap();
		
		this.deleteTableCell(theThread);
		
		var endNumberOfThreads = this.mainWindow().tableViews()[0].cells().length;
		var expectedNumberOfThreads = startNumberOfThreads - 1;
		
		if (expectedNumberOfThreads == endNumberOfThreads) {
			UIALogger.logMessage("Successfully deleted one thread.");
		}
		else {
			throw new Error("Ended up with " + endNumberOfThreads + ", but expected " + expectedNumberOfThreads + " at end of run.")
		}
		
		return;
	}
		
}
