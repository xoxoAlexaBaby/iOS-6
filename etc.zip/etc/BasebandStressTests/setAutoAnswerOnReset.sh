SCRIPTS_DIR="/usr/local/etc/BasebandStressTests/"
$SCRIPTS_DIR/setupAutoAnswer.sh
/usr/local/bin/DoOnBBReset "sleep 5; $SCRIPTS_DIR/setupAutoAnswer.sh" 
