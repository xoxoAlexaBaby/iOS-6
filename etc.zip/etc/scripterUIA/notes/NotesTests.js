#import "./Notes.js"
#import "../mail/Mail.js"
#import "../libs/PHTesting.js"

//----------------------------------------------------------------------------------------
//	Function: notesTest_createNote 
//		Creates a note with given title and body
//
//	Parameters: 
//		noteTitle (string) - title of the note (required)
//		noteBody (real) - body of the note (optional) 
//----------------------------------------------------------------------------------------
function notesTest_createNote() {
	if (this.argv.length < 2) {
		UIALogger.logError(arguments.callee.name + ": Not enough args being passed.");
		return 64;		
	}
	var date = new Date();
	var randomNumber = "" + date.getHours() + date.getMinutes() + date.getSeconds(); // the quotes make this into a string.
	UIALogger.logMessage("The number = " + randomNumber);
	var noteTitle = this.argv[0] + " " + randomNumber;
	var noteBody = this.argv[1] + " " + randomNumber;
	
	notes.gotoListView();
	notes.createNewNote(noteTitle, noteBody, false);
	notes.gotoListView();
	notes.getToNoteFromList(noteTitle, false);
	UIALogger.logMessage(arguments.callee.name + ": New note created.");
	return this.testResult = 1;
}

//----------------------------------------------------------------------------------------
//	Function: notesTest_deleteNote 
//		Creates a note with given title and body and then deletes it.
//
//	Parameters: 
//		noteTitle (string) - title of the note (required)
//		noteBody (real) - body of the note (optional) 
//----------------------------------------------------------------------------------------
function notesTest_deleteNote() {
	if (this.argv.length < 2) {
		UIALogger.logError(arguments.callee.name + ": Not enough args being passed.");
		return 64;		
	}
	
	var date = new Date();
	var randomNumber = "" + date.getHours() + date.getMinutes() + date.getSeconds(); // the quotes make this into a string.
	var noteTitle = this.argv[0] + " " + randomNumber;
	var noteBody = this.argv[1] + " " + randomNumber;
	
	notes.gotoListView();	
	notes.createNewNote(noteTitle, noteBody, false);
	notes.gotoListView();
	var originalNumberOfNotes = UIAUtility.tableInfoFromValue(notes.notesListTable().value()).noOfElements;
	UIALogger.logDebug("Original number of notes: " + originalNumberOfNotes);
	var noteTitle = notes.getToNoteFromList(noteTitle, true);
	notes.deleteNote(true);		

	UIALogger.logMessage("Verifying the note was deleted");
	notes.gotoListView();
	var newNumberOfNotes = UIAUtility.tableInfoFromValue(notes.notesListTable().value()).noOfElements;
	if (newNumberOfNotes != (originalNumberOfNotes-1)) {
		this.testError = "Unexpected number of notes found after deleting";
		UIALogger.logError(this.testError + ": " + newNumberOfNotes);
		return this.testResult = 0;
	}
	
	if (notes.notesListTable().visibleCells()[noteTitle].isValid()) {
		//found the note which is no good
		this.testError = "Failed to delete the note";
		return this.testResult = 0;
	}

	return this.testResult = 1;
}

//----------------------------------------------------------------------------------------
//	Function: notesTest_deleteAllNotes 
//		Deletes all of the notes on the device.
//
//	Parameters: 
//		none
//----------------------------------------------------------------------------------------
function notesTest_deleteAllNotes() {
    this.testResult = 0;
	notes.deleteALLNotes();
    return this.testResult = 1;
}

//----------------------------------------------------------------------------------------
//	Function: noteTest_verifyNoteTitle 
//		Verifies that the given note exists.
//
//	Parameters: 
//		noteTitle (string) - title of the note (required)
//		
//  Optional Paramaters:
//      partialMatch (bool) - set to '1' if you are willing to do a 'beginswith' match
//          on the title.  If this is left off, an exact match is done.
//----------------------------------------------------------------------------------------
function noteTest_verifyNoteTitle() {
    this.testResult = 0;
    
    if (this.argv.length < 1) {
		UIALogger.logError(arguments.callee.name + ": Not enough args being passed.");
		return 64;		
	}
	
	var noteTitle = this.argv[0];
	
	var options = new Object();
	options.partialMatch = UIAUtility.valuesForKey("partialMatch", this.argv, 1);

	notes.launchIfNotActive();
	notes.getToNoteFromList(noteTitle, true, options);
    
    return this.testResult = 1;
}

//----------------------------------------------------------------------------------------
//	Function: notesTest_emailNote 
//		Creates a note with given title and body and then emails it.
//
//  Requires: 
//      Mail account must be configured on the device
//
//	Parameters: 
//      toAddress (string) - address to which the note has to be sent
//		noteTitle (string) - title of the note
//		noteBody (string) - body of the note
//		shouldValidate (bool - optional) - if true, looks for email in toAddress's inbox
//			(this assumes that the account is on the device).  If not present, this value
//			is set to false.
//      
//  Returns: 1 if the note was emailed
//           0 if the note wasn't emailed 
//----------------------------------------------------------------------------------------
function notesTest_emailNote() {
	if (this.argv.length < 3) {
        this.testError = "Not enough args being passed.";
        UIALogger.logError(this.testError);
		return 64;		
	}
	
	this.testResult = 0;
	
    var toAddress = this.argv[0];
	var noteTitle = this.argv[1];
	var noteBody = this.argv[2];
	var shouldValidate = false;
	if (this.argv.length > 3) {
		shouldValidate = this.argv[3];
	}
    
	notes.gotoListView();
	
	UIALogger.logMessage("Sending an email titled '" + noteTitle + "' to '" + toAddress + "', validation = " + shouldValidate);
	notes.createNewNote(noteTitle, noteBody, false);
	notes.emailNote(toAddress, null, true);
	
	if (shouldValidate) {
		
		UIALogger.logMessage("Verifying the mail exists now");

		UIALogger.logDebug("Verifying email with subject '" + noteTitle + "' was received");
		if (!mail.verifyEmailExists(noteTitle, toAddress, "Inbox", 120)) {
			this.testError = "The email was not received.";
			return this.testResult = 0;
		}
		else {
			UIALogger.logDebug("Note was composed and emailed");
			return this.testResult = 1;
		}
	}
	
	return this.testResult = 1;
}

//----------------------------------------------------------------------------------------
//	Function: notesTest_selectPreviousNextNote 
//		Creates several notes, if needed, and then uses the 
//		arrows to select the next and previous notes.
//
//	Parameters: 
//		None
//----------------------------------------------------------------------------------------
function notesTest_selectPreviousNextNote() {

	notes.gotoListView();
	UIATarget.localTarget().delay(1);
	
	//create three unique notes, if needed
	var requiredNotesNumber = 0;
	var noteTitles = new Array(); //store the note titles -- will be used for verification
	var noteCells = notes.notesListTable().visibleCells();
	if (noteCells.length == 1) noteCells = notes.notesListTable().visibleCells().withPredicate("not name contains 'New Note'");
	for (var i=0; i<Math.min(noteCells.length,3); i++) 
		noteTitles[i] = notes.noteTitleFromTableCell(noteCells[i]);
	
	if (noteCells.length < 3) {
		var requiredNotesNumber = 3 - noteCells.length;
		if (requiredNotesNumber == 1) {
			var hasSameTitle = noteTitles[0] == noteTitles[1];
			if (hasSameTitle) requiredNotesNumber = 2;
		}
	} else {
		var hasSameTitle = (noteTitles[0] == noteTitles[1] || 
							noteTitles[1] == noteTitles[2]);
		if (hasSameTitle) requiredNotesNumber = 2;
	}
	
	if (requiredNotesNumber > 0) {
		UIALogger.logMessage("Need to create " + requiredNotesNumber + " notes");
		for (var i=0; i<requiredNotesNumber; i++) {
			UIALogger.logMessage("Creating note " + (i+1));
			phtRunSilent("CreateNote", ["Testing Notes " + (new Date()).toString(), "Entering some text as the body of the note."], notesTest_createNote).execute();
		}
		
		notes.gotoListView();
		UIATarget.localTarget().delay(1);
		noteCells = notes.notesListTable().visibleCells();
		for (var i=0; i<Math.min(noteCells.length,3); i++) 
			noteTitles[i] = notes.noteTitleFromTableCell(noteCells[i]);
		
		if (noteCells.length < 3) {
			this.testError = "Failed to create three notes for testing.";
			UIALogger.logError(this.testError);
			return this.testResult = 0;
		}
		var hasSameTitle = (noteTitles[0] == noteTitles[1] || 
							noteTitles[1] == noteTitles[2]);
		if (hasSameTitle) {
			this.testError = "Notes with same titles created";
			UIALogger.logError(this.testError);
			return this.testResult = 0;
		}
	}
	
	
	var secondNote = noteCells[1];
	UIALogger.logMessage("Selecting the second note '" + secondNote.name() + "'");
	secondNote.scrollToVisible();
	secondNote.tap();
	UIATarget.localTarget().delay(1);
	
	var actions = ["previous", "next", "next", "previous"];
	var currentIndex = 1;
	var noteTextInfo = new Array();
	noteTextInfo[1] = notes.mainWindow().textViews()[0].value();
	var currentText = noteTextInfo[1]; //for verification purposes
	
	for (var i=0; i<actions.length; i++) {
		UIALogger.logMessage("Executing action " + (i+1) + " '" + actions[i] + "'");
		notes.selectNoteUsingArrow(actions[i]);
		
		if (actions[i] == "previous") currentIndex--; else currentIndex++;
		var prevText = currentText;
		
		UIALogger.logMessage("Expect to be on note " + currentIndex); 
		
		//checking if the value contains the title from the list
		var noteTitle = noteTitles[currentIndex];
		var textView = notes.mainWindow().textViews().firstWithPredicate("value contains '" + noteTitle + "'");
		if (!textView.isValid()) {
			UIALogger.logMessage("Expected title is '" + noteTitle + "'");
			this.testError = "Note text does not have the expected title";
			UIALogger.logError(this.testError);
			return this.testResult = 0;
		}
		currentText = textView.value();
		
		//checking if the text of the note changed
		if (currentText == prevText) {
			this.testError = "Note text did not change";
			UIALogger.logError("Note text did not change");
			return this.testResult = 0;
		}
		
		//checking if the text is expected
		if (noteTextInfo[currentIndex] == null) {
			noteTextInfo[currentIndex] = currentText;
		} else {
			UIALogger.logMessage("Verifying the text matches the expected text");
			if (currentText != noteTextInfo[currentIndex]) {
				this.testError = "Note text is not expected";
				UIALogger.logError(this.testError);
				return this.testResult = 0;
			}
		}
	}
			
	return this.testResult = 1;
}

//----------------------------------------------------------------------------------------
//	Function: notesTest_copyNote
//		Creates a note with the text of another using copy / paste
//
//	Parameters: 
//		noteTitle (string) - title of the note to copy (required)
//		noteBody (real) - body of the note to copy (optional) 
//----------------------------------------------------------------------------------------
function notesTest_copyNote() {
	if (this.argv.length < 1) {
		UIALogger.logError(arguments.callee.name + ": Not enough args being passed.");
		return 64;		
	}
	var noteTitle = this.argv[0];
	var noteBody = (this.argv.length > 1) ? this.argv[1] : noteTitle;
	
	notes.gotoListView();
	notes.createNewNote(noteTitle, noteBody, false);
	notes.copyWithOptions(notes.mainWindow(), {shouldSelectAll:true});
	
	UIALogger.logMessage("Copied note. Tapping the Add button to create a new note");
	notes.navigationBar().buttons()["Add"].tap();
	
	var textView = notes.mainWindow().textViews().firstWithPredicate("not value contains '" + noteBody + "'");
	if (!textView.isValid()) { 
		this.testError = "New note never came up";
		UIALogger.logError(this.testError);
		return this.testResult = 0;
	}
	UIATarget.localTarget().delay(1);
	
	notes.pasteWithOptions(notes.mainWindow().textViews()[0]);
	if (textView.withPredicate("value contains '" + noteBody + "'").isValid()) {
		this.testResult = 1;
	} else {
		this.testError = "Text of note does not match expected text.";
		this.testResult = 0;
	}
	
	if (UIATarget.localTarget().model() == 'iPad') 
		notes.keyboard().buttons()["Hide keyboard"].tap();
	else
		notes.navigationBar().buttons()["Done"].tap();
	
	return this.testResult;
}

//----------------------------------------------------------------------------------------
//	Function: notesTest_pasteIntoNote 
//		Creates a note with whatever is on the pasteboard and validates
//		using the textToValidate string.
//
//	Parameters: 
//		textToValidate (string) - notes content to validate (required)
//----------------------------------------------------------------------------------------
function notesTest_pasteIntoNote() {
	if (this.argv.length < 1) {
		UIALogger.logError(arguments.callee.name + ": Not enough args being passed.");
		return 64;		
	}
	var textToValidate = UIAUtility.escapeString(this.argv[0]);	
	var shouldCloseNote = false;
	
	notes.launchIfNotActive();

	UIALogger.logMessage("Need to create a note... ");
	shouldCloseNote = true;		
	notes.gotoListView();
	notes.createNewNote("", "", true);
	textView = notes.mainWindow().textViews()[0];
	if (!textView.withPredicate("not value contains '" + textToValidate + "'").isValid()) { 
		this.testError = "New note did not get created";
		UIALogger.logError(this.testError);
		return this.testResult = 0;
	}
	UIATarget.localTarget().delay(1); //just making sure no animations are on

	
	var textView = notes.mainWindow().textViews()[0];
	var currentView = notes.getCurrentView();
	if (!(currentView & notes.views.NOTE_EDIT)) {
		UIALogger.logDebug("Tapping to get in 'NoteEdit' view");
		textView.tap();
		UIATarget.localTarget().delay(1);
		currentView = notes.getCurrentView();
		if (!(currentView & notes.views.NOTE_EDIT)) {
			UIALogger.logWarning("Tapped the text view, but still in '" + currentView + "'");
		}
	}
	
	notes.pasteWithOptions(textView);
	if (!textView.withPredicate("value contains '" + textToValidate + "'").isValid()) {
		textView.logElementTree();
		this.testError = "Text of note does not match expected text.";
		UIALogger.logError(this.testError);
		return this.testResult = 0;
	}
	
	if (shouldCloseNote) { 
		if (UIATarget.localTarget().model() == 'iPad') 
			notes.keyboard().buttons()["Hide keyboard"].tap();
		else
			notes.navigationBar().buttons()["Done"].tap();
	}
	
	return this.testResult = 1;
}

//----------------------------------------------------------------------------------------
//	notesTest_undoAction - Generates a shake event to undo the action.
//
//	Arguments: 
//		action (string) - the action to undo: "type", "paste" or "cut". If "paste" is 
//			selected, the test assumes that there is something on the pasteboard.
//
//	Optional Arguments:
//		textToType (string) - This parameter is required only if the action is set to "type" 
//			or "cut". If the action parameter is set to type, the noteText string will be typed, 
//			and then the typing will be undone. If the action parameter is set to "cut", 
//			the text will be typed, then cut, and then the action will be undone.
//		title (string) - title will be the first line of the note, followed by a return. If not set,
//			"" is used (still follwed by a return) -- only impacts "cut" and "type" actions.		
//		shouldRedo (boolean) - if set to true, the undo action will be redone. It is set to 
//			false by default (optional)
//
//	e.g. notesTest_undoAction "type" "textToType:I like being a note" "shouldRedo:true"
//----------------------------------------------------------------------------------------
function notesTest_undoAction() {
	if (this.argv.length < 1) {
		UIALogger.logError(arguments.callee.name + ": Not enough args being passed.");
		return 64;		
	}
	
	var action = this.argv[0];
	var optionsArray = new Array();
	var date = new Date();
	
	// push options onto optionsArray;
	for (var i=1; i<this.argv.length; i++) {
		optionsArray.push(this.argv[i]);
	}
	var options = new Object();
	options.text = UIAUtility.valuesForKey("textToType", optionsArray, 1); 
	options.redo = UIAUtility.valuesForKey("shouldRedo", optionsArray, 1);
	options.title = UIAUtility.valuesForKey("title", optionsArray, 1);
	if (!options.title)
		options.title = "";
	
	// argument checking
	if ((action == "type" || action == "cut") && !options.text) {
		UIALogger.logError(arguments.callee.name + ": Need text for type/cut actions");
		return 64;
	}
	
	// create a new note
	var shouldCloseNote = false;
	UIALogger.logMessage("Need to create a note... ");
	shouldCloseNote = true;		
	notes.gotoListView();
	notes.createNewNote(options.title, (action == "cut" ? options.text : ""), true);
	textView = notes.mainWindow().textViews()[0];
	
	// carry out desired action
	var textView = notes.mainWindow().textViews()[0];
	var verificationText = textView.value();
	if (action == "type") {
		UIALogger.logDebug("Typing text on keyboard");
		if (!UIATarget.localTarget().frontMostApp().keyboard().isValid()) {
			UIALogger.logError("Keyboard not visible. Cannot type note.");
			return (this.testResult = 0);
		}
		UIATarget.localTarget().frontMostApp().keyboard().typeString(options.text);
	}
	else if (action == "cut") {
		UIALogger.logDebug("Cutting text");
		notes.copyWithOptions(notes.mainWindow(), {shouldSelectAll:true, withCut:true});
	}
	else if (action == "paste") {
		UIALogger.logDebug("Pasting text");
		notes.pasteWithOptions(textView);
	}
	var redoVerificationText = textView.value();
	
	// Make ourselves an alert handler for the expected undo/redo alerts
	var undoRedoAlertHandler = function(alert) {
		var expectedButtonText = "Undo ";
		var button = alert.buttons().firstWithPredicate("name BEGINSWITH 'Undo'");
		if (!button.isValid()) {
			button = alert.buttons().firstWithPredicate("name BEGINSWITH 'Redo'");
			expectedButtonText = "Redo ";
		}
		if (action == "type")
			expectedButtonText += "Typing";
		else if (action == "cut")
			expectedButtonText += "Cut";
		else if (action == "paste")
			expectedButtonText += "Paste";
		var button = alert.buttons()[expectedButtonText];
		if (!button.isValid()) {
			UIALogger.logError("Alert present but expected undo button text is not.")
			return false;
		}
		UIALogger.logDebug("Tapping button titled " + button.name());
		button.tap();
		return true;
	};	
	UIATarget.pushAlertHandler(undoRedoAlertHandler);

	// undo action
	UIATarget.localTarget().shake();
	UIATarget.localTarget().delay(20); // give the poor alert handler some time
	
	var afterUndoText = textView.value();
	
	if (afterUndoText != verificationText) {
		UIALogger.logDebug("Undo does not verify.");
		UIALogger.logDebug("afterUndoText = " + afterUndoText);
		UIALogger.logDebug("verificationText = " + verificationText);
		UIALogger.logDebug("Undo does not verify.");
		UIATarget.popAlertHandler();
		return (this.testResult = 0);
	}
	
	// redo action
	if (options.redo && options.redo == true) {
		UIATarget.localTarget().shake();
		UIATarget.localTarget().delay(20);
		
		var afterRedoText = textView.value();
		
		if (afterRedoText != redoVerificationText) {
			UIALogger.logDebug("Undo does not verify.");
			UIALogger.logDebug("afterRedoText = " + afterRedoText);
			UIALogger.logDebug("redoVerificationText = " + redoVerificationText);
			UIALogger.logDebug("Redo does not verify.");
			UIATarget.popAlertHandler();
			return (this.testResult = 0);
		}
	}
	
	UIATarget.popAlertHandler();
	
	if (UIATarget.localTarget().model() == 'iPad') 
		notes.keyboard().buttons()["Hide keyboard"].tap();
	else
		notes.navigationBar().buttons()["Done"].tap();
	
	return (this.testResult = 1);
}

// Create self tests -- this is an unnamed function, just to make sure any local variables stay in the correct context
(function() {	
	if (typeof notes.selfTests == 'undefined') {
		notes.selfTests = new Array();
	}
	
    var date = new Date();
	var timestamp = "" + date.getHours() + date.getMinutes() + date.getSeconds();
	notes.selfTests.push(phtCreateTest("CreateNote", ["UnitTest Note 1", "Hi!  I like being a note.  How about you?"], 
									   notesTest_createNote, "Create a Note"));
	notes.selfTests.push(phtCreateTest("SelectPreviousNextNote", null, notesTest_selectPreviousNextNote, "Switch Between Notes"));
    notes.selfTests.push(phtCreateTest("CopyNote", ["Note to copy " + timestamp, "Hi!  I like being copied.  How about you?"], notesTest_copyNote, "Copy text from one note and paste it into another."));
    notes.selfTests.push(phtCreateTest("PasteIntoNote", ["I like being copied"], notesTest_pasteIntoNote, "Paste text from the pasteboard into a new note."));
	notes.selfTests.push(phtCreateTest("DeleteNote", ["UnitTest Note 1", "Hi!  I like being a note.  How about you?"], 
									   notesTest_deleteNote, "Delete a Note"));
    notes.selfTests.push(phtCreateTest("EmailNote", ["weliketesting@me.com", "UnitTest Note " + timestamp, "Hi!, I like being a note.  How about you? " + timestamp, true],
									   notesTest_emailNote, "Email a Note"));
	notes.selfTests.push(phtCreateTest("UndoAction", ["type", "textToType:Someday I will run away to the circus", "shouldRedo:true"], 
									   notesTest_undoAction, "Undo typing"));
}())