#import "../libs/UIATesting.js"
#import "../settings/SettingsTests.js"
#import "../safari/SafariTests.js"
#import "../maps/MapsTests.js"
#import "../ipod/iPodTests.js"
#import "../notes/NotesTests.js"
#import "../mail/MailTests.js"
#import "../contacts/ContactsTests.js"
#import "../clock/ClockTests.js"
#import "../calculator/CalculatorTests.js"
#import "../phone/PhoneTests.js"
#import "../appstore/AppStoreTests.js"
#import "../3rdparty/FacebookTests.js"
#import "../calendar/CalendarTests.js"
#import "../weather/WeatherTests.js"
#import "../camera/CameraTests.js"
#import "../springboard/SpringboardTests.js"
#import "../stocks/StocksTests.js"
#import "../youtube/YouTubeTests.js"
#import "../messages/MessagesTests.js"
#import "../system/SystemTests.js"
#import "../photos/PhotoTests.js"
#import "../facetime/FaceTimeTests.js"

//Example Test Objects -- still need some work before they can be used

var hasWifi = system.hasCapability('wifi');
var hasTelephony = system.hasCapability("telephony");

// requires these specific bits of content be on the test device
var kSongName = "Yesterday";
var kMovieName = "Trailer H"
var kMovieSublist = "The Simpsons Movie";
var kMP4MovieName = "TikiBarTV10-DrinkbotMP4V";
var kDRMedSongName = "Delerium DRM";
var kDRMedMovieName = "Nasa DRM";

var start = new Date();
var timeString = start.getTime() + "";  // turn this into a string
var runID = "QuickLook " + start.toDateString() + " - " + timeString.substr(-6);

var kSMSBuddy1 = "4083321896";
var kSMSBuddy2 = "4083323272";

kStoreUsername = "jsmith.purple@gmail.com";
kStorePassword = "telluride";
  
// this is some setup that is required for the sms tests
globalSMSNumber = telephony.myPhoneNumber;

if (UIATarget.localTarget().model() == 'iPad') {
	var openWebPageInTabParameters = ["http://pttest.apple.com/perfmarketing-power/testcontent/smithsonian.html", "http://pttest.apple.com/perfmarketing-power/testcontent/google.html", "pttest.apple.com"];
	var openWebPageFromPreviousTabParameters = ["http://pttest.apple.com/perfmarketing-power/testcontent/smithsonian.html", "http://pttest.apple.com/perfmarketing-power/testcontent/google.html", "pttest.apple.com", "pttest.apple.com"];
	var movieListParameters = [kMovieName, 15, "Podcasts", kMovieSublist];
} else {
	var openWebPageInTabParameters = ["http://pttest.apple.com/perfmarketing-power/testcontent/smithsonian.html", "http://pttest.apple.com/perfmarketing-power/testcontent/google.html", "Google"];
	var openWebPageFromPreviousTabParameters = ["http://pttest.apple.com/perfmarketing-power/testcontent/smithsonian.html", "http://pttest.apple.com/perfmarketing-power/testcontent/google.html", "Smithsonian Institution", "Google"];
	var movieListParameters = [kMovieName, 15, kMovieSublist];
}

function createTest(name, args, func, description) {
	return new UIATesting.Test(name, args, func, description);
}
LaunchSettings = createTest("LaunchSettings", [settings, 10], springboardTest_launchApp, "Launch Settings");
//createTest("UnlockDevice", ["0"], systemTest_lockAndUnlockDevice, "Unlock the device")); 

// Set auto-lock to never
SetAutoLockToNever = createTest("SetAutoLockToNever", ["General", "Auto-Lock", "Never"], settingsTest_chooseCheckmarkedItem, "Set Auto-Lock to Never");
EnableBatteryLifeLogging = createTest("EnableBatteryLifeLogging", ["Internal Settings", "Power", "Battery Life Logging", "1"], settingsTest_changeSingleSwitch, "Enable Battery Life Logging");
EnableWifiLogging = createTest("EnableWifiLogging", ["Internal Settings", "WiFi", "Logging", "UI Logging", 1], settingsTest_changeSingleSwitch, "Enable Wifi Logging");
EnableWifiManagerLogging = createTest("EnableWifiManagerLogging", ["Internal Settings", "Radios", "WiFiManager", "Logging", "1"], settingsTest_changeSingleSwitch, "Enable WifiManager Logging");
EnableWifiManagerFileLogging = createTest("EnableWifiManagerFileLogging", ["Internal Settings", "Radios", "WiFiManager", "File Logging", "1"], settingsTest_changeSingleSwitch, "Enable WifiManager File Logging");
EnableiTunesStoreLogging = createTest("EnableiTunesStoreLogging", ["Internal Settings","iTunes Store","Level","Verbose Status + Errors"], settingsTest_chooseCheckmarkedItem, "Enable iTunes store Logging");

if (typeof addressbook != 'undefined') { 
	LaunchContacts = createTest("LaunchContacts", [addressbook, 10], springboardTest_launchApp, "Launch Contacts")
	FlickContactList = createTest("FlickContactList", [0.026, 0.80, 0.1], contactsTest_flickContactsList, "Flick contact list");
	DragContactList = createTest("DragContactList", [0.80, 0.026, 1], contactsTest_dragContactsList, "Drag contact list");
	NewContact = createTest("NewContact", ["Robert", "Zimmerman"], contactsTest_newContact, "Add a new contact to the addressbook");
	SelectContact = createTest("SelectContact", ["Robert Zimmerman"], contactsTest_selectContact, "Select the added contact");
	AddNewPhoneNumber = createTest("AddNewPhoneNumber", ["4089619343", "home"], contactsTest_addNewPhone, "Add a phone number to the selected contact");
	AddNewEmail = createTest("AddNewEmail", ["zimmer@something.com", "work"], contactsTest_addNewEmail, "Add an email address to the selected contact");
	AssignRingtone = createTest("AssignRingtone", ["Crickets"], contactsTest_assignRingtone, "Assign a ringtone to the selected contact");	
	DeleteContact = createTest("DeleteContact", ["Robert", "Zimmerman"], contactsTest_deleteContact, "Delete a contact from the addressbook");
}

if (typeof phone != 'undefined') {
	LaunchPhone = createTest("LaunchPhone", [phone, 10], springboardTest_launchApp, "Launch Phone");
	MakeCall = createTest("MakeCall", ["+4089619343"], phoneTest_makeCall, "Make a call using the keypad"); // Apple Loopback
	AddCall = createTest("AddCall", ["+14087773456"], phoneTest_addCall, "Add a phone call using keypad"); // Movie Phone
	MergeCalls = createTest("MergeCalls", null, phoneTest_mergeCalls, "Merge two calls"); // Movie Phone
	EndCall = createTest("EndCall", ["+14087773456"], phoneTest_endCall, "End calls"); // Both
}

if (typeof facetime != 'undefined') {
	MakeFacetimeCallToContact = createTest("MakeFacetimeCallToContact", ["autoanswer fun", false], facetimeTest_makeVideoCallToContact, "Make a facetime call to a contact using a phone number");
	EndFacetimeCall = createTest("EndFacetimeCall", [false], facetimeTest_endVideoCall, "End the facetime call");
	MakeFacetimeCallToContactUsingAddress = createTest("MakeFacetimeCallToContactUsingAddress", ["autoanswer fun", false, null, null, "weliketesting@me.com"], facetimeTest_makeVideoCallToContact, "Make a facetime call to a contact using an email address");
	EndFacetimeCall = createTest("EndFacetimeCall", [false], facetimeTest_endVideoCall, "End the facetime call");
}

if (typeof mail != 'undefined') {
	var emailTitle = runID;
	CreateMobileMeAccount = createTest("CreateMobileMeAccount", ["me", "Testing Tester", "weliketesting@me.com", "testtest", "contactsSync:0", "bookmarksSync:0", "calendarsSync:0", "notesSync:0"], 
							 settingsTest_createEmailAccount, "Setup mail account on the device"); // expected to fail, if this account is already there
	LaunchMail = createTest("LaunchMail", [mail, 10], springboardTest_launchApp, "Launch Mail");
	ComposeAndSendEmail = createTest("ComposeAndSendEmail", ["weliketesting@me.com", emailTitle, "This is testing body text."], mailTest_composeAndSendEmail, "Compose and send a mail");
	FetchNewMail = createTest("FetchNewMail", [emailTitle, "weliketesting@me.com", "Inbox", 60], mailTest_verifyEmailInFolder, "Fetch new mail");
	SearchMailLocally = createTest("SearchMailLocally", [emailTitle.split(' ').pop(), "weliketesting@me.com", "Subject"], mailTest_search, "Search for mail locally");
	SearchMailOnServer = createTest("SearchMailOnServer", ["Hello", "weliketesting@me.com", "Subject", "shouldSearchServer:true"], mailTest_search, "Search mail on server");
	DeleteMail = createTest("DeleteMail", [emailTitle, "weliketesting@me.com", "Inbox"], mailTest_deleteEmail, "Delete mail");
}

if (typeof audio != 'undefined') {
	LaunchiPod = createTest("LaunchiPod", [video, 20], springboardTest_launchApp, "Launch iPod");
	PlaySongFromSongList = createTest("PlaySongFromSongList", [kSongName, 15], iPodTest_playSongFromSongList, "Play an AAC-encoded song");
	PlaySongFromSongList = createTest("PlaySongFromSongList", [kDRMedSongName, 15], iPodTest_playSongFromSongList, "Play a DRMed AAC song");
	UseCoverFlow = createTest("UseCoverFlow", ["songName:Yesterday", "action:Back", "action:Back", "action:Forward"], iPodTest_flipThroughCoverFlow, "Use cover flow");
	PlayMovieH264 = createTest("PlayMovieH264", movieListParameters, iPodTest_playMovieFromVideoList, "Play an H.264 movie");
	PlayMovieMPEG = createTest("PlayMovieMPEG",	 [kMP4MovieName, 15], iPodTest_playMovieFromVideoList, "Play an MPEG-4 movie");
	PlayMovieFromVideoList = createTest("PlayMovieFromVideoList", [kDRMedMovieName, 15], iPodTest_playMovieFromVideoList, "Play a DRMed H.264 movie");
}

ScrollThroughAPhotoAlbum = createTest("ScrollThroughAPhotoAlbum", null, photosTest_scrollThroughAPhotoAlbum, "Scroll through a photo album");
ViewSomePicturesFromAPhotoAlbum = createTest("ViewSomePicturesFromAPhotoAlbum", null, photosTest_viewSomePicturesFromAPhotoAlbum, "View some pictures from a photo album");
PlayPhotoAlbumSlideshow = createTest("PlayPhotoAlbumSlideshow", [null, 30], photosTest_playPhotoAlbumSlideshow, "Play slideshow for 30 seconds"); 
EmailPhoto = createTest("EmailPhoto", ["weliketesting@me.com", "Camera Email:" + runID], photosTest_emailPhoto, "Send an image from Photos through mail");

if (typeof camera != 'undefined') {
	LaunchCamera = createTest("LaunchCamera", [camera, 10], springboardTest_launchApp, "Launch Camera");
	TakePicture = createTest("TakePicture", null, cameraTest_takePicture, "Take a Picture, make sure it appears in the Camera Roll");
	DeletePhoto = createTest("DeletePhoto", null, cameraTest_deletePhoto, "Delete a Photo");
	CaptureVideo = createTest("CaptureVideo", [15, true], cameraTest_captureVideo, "Capture a video");
	PlayCapturedVideo = createTest("PlayCapturedVideo", [10], cameraTest_playCapturedVideo, "Play Captured video");
}

if (typeof calendar != 'undefined') {
	var eventText = runID;
	LaunchCalendar = createTest("LaunchCalendar", [calendar, 10], springboardTest_launchApp, "Launch Calendar");
	if (UIATarget.localTarget().model() != "iPad") {
		NavigateCalendarViews = createTest("NavigateCalendarViews", null, calTest_navigateBetweenViews, "Navigate to each calendar view");		
	} else {
		NavigateCalendarViews = createTest("NavigateCalendarViews", null, calTest_navigateBetweenViews, "View events in Day, Week, Month and List views");		
	}
	AddCalendarEvent = createTest("AddCalendarEvent", [eventText, "Area 51", null, null, true], calTest_addEvent, "Add an event to the calendar");
	SearchCalendarEvent = createTest("SearchCalendarEvent", [eventText, null], calTest_searchForEventUsingSearchBar, "Search for an event");		
	DeleteCalendarEvent = createTest("DeleteCalendarEvent", [eventText + "_deleteTest"], calTest_deleteCalendarEvent, "Delete an event");
}

if (typeof maps != 'undefined') {
	// use Beijing instead of Seattle for phones with restricted Wifi (China) <rdar://problem/6780293> N82c only: no coffee in Seattle, Wa
	var citySearch = (hasWifi) ? "Seattle, WA" : "Beijing, China";
	// cannot verify location details in N82c
	var locationDetailsParameters = (hasWifi) ? ["searchLocation:London", "addressToVerify:London"] : ["searchLocation:London"];
	LaunchMaps = createTest("LaunchMaps", [maps, 10], springboardTest_launchApp, "Launch Maps");
	MapAddress = createTest("MapAddress", [citySearch], mapsTest_search, "Search for city");
	MapSearch = createTest("MapSearch", ["Coffee"], mapsTest_search, "Search for keyword");
	ZoomOutMaps = createTest("ZoomOutMaps", [maps.getAvailableViews()[0], 150, 150], mapsTest_zoomOut, "Zoom out in map view (no validation)");
	ZoomInMaps = createTest("ZoomInMaps", ["Satellite", 150, 150], mapsTest_zoomIn, "Zoom in in map view (no validation)");
	DragSatelliteView = createTest("DragSatelliteView", ["Satellite", 1, 170, 315, 425, 1], mapsTest_drag, "Drag map in satellite view (no validation)");
	FlickMapView = createTest("FlickMapView", [maps.getAvailableViews()[0], 1, 170, 315, 425, 0.1], mapsTest_flick, "Flick map in map view (no validation)");
	GetCurrentLocation = createTest("GetCurrentLocation", null, mapsTest_getCurrentLocation, "Get your current location");
	AddBookmark = createTest("AddBookmark", null, mapsTest_addBookmark, "Add a bookmark");
	DeleteBookmark = createTest("DeleteBookmark", null, mapsTest_deleteBookmark, "Delete a bookmark");
	ShareLocation = createTest("ShareLocation", ["sendThru:Email", "emailSubject:Share Location:" + runID,
											   "mailRecipient:weliketesting@me.com", "searchLocation:Boston,MA", "shouldValidate:true"], mapsTest_shareLocation, "Share a location");
	GetDirections = createTest("GetDirections", ["New York, NY","Boston, MA"], mapsTest_getDirections, "Get driving directions");
	ShowTraffic = createTest("ShowTraffic", ["searchLocation:New York, NY"], mapsTest_showTraffic, "Turn on Show Traffic (no validation)");
	ViewLocationDetails = createTest("ViewLocationDetails", locationDetailsParameters, mapsTest_viewLocationDetail, "View a location's details"); 
	ShowStreetView = createTest("ShowStreetView", ["searchLocation:Boston, MA"], mapsTest_showStreetView, "Find Boston MA and load multiple views in Streetview");
}

if (typeof notes != 'undefined') {
	LaunchNotes = createTest("LaunchNotes", [notes, 10], springboardTest_launchApp, "Launch Notes");
	CreateNote = createTest("CreateNote", ["Testing Notes", "Entering some text as the body of the note."], notesTest_createNote, "Create a new note and enter some text");
	DeleteNote = createTest("DeleteNote", ["Testing Notes", "Entering some text as the body of the note."], notesTest_deleteNote, "Delete an existing note");
	SelectPreviousNextNote = createTest("SelectPreviousNextNote", null, notesTest_selectPreviousNextNote, "Use Previous and Next controls");
	EmailNote = createTest("EmailNote", ["weliketesting@me.com", "Note:" + runID, "Hi!, I like being a note.  How about you? ", true], notesTest_emailNote, "Email a note");
}

if (typeof clock != 'undefined') {
	LaunchClock = createTest("LaunchClock", [clock, 10], springboardTest_launchApp, "Launch Clock");
	AddAndWaitForAlarm = createTest("AddAndWaitForAlarm", [], clockTest_addAndWaitForAlarm, "Add an alarm");
	AddWorldClock = createTest("AddWorldClock", ["Paris", "Paris, France"], clockTest_addWorldClock, "Add a new world clock");
	RemoveWorldClock = createTest("RemoveWorldClock", ["Paris"], clockTest_removeWorldClock, "Remove world clock");		
	StartStopwatch = createTest("StartStopwatch", [], clockTest_startStopwatch, "Start the stopwatch");
	StopStopwatch = createTest("StopStopwatch", [], clockTest_stopStopwatch, "Stop the stopwatch");
	ResetStopwatch = createTest("ResetStopwatch", [], clockTest_resetStopwatch, "Reset the stopwatch");
	GetStopwatchLaptime = createTest("GetStopwatchLaptime", [], clockTest_getStopwatchLaptime, "Check the stopwatch laptime");
}

if (typeof weather != 'undefined') {
	LaunchWeather = createTest("LaunchWeather", [weather, 10], springboardTest_launchApp, "Launch Weather");
	SlideWeatherToCity = createTest("SlideWeatherToCity", null, weatherTest_slideToCity, "Slide Weather to New York");
	AddCityWeather = createTest("AddCityWeather", ["Denver, CO"], weatherTest_addCity, "Add a city");
	RemoveCityWeather = createTest("RemoveCityWeather", ["Denver"], weatherTest_deleteCity, "Remove a city");
}

if (typeof youtube != 'undefined') {
	LaunchYouTube = createTest("LaunchYouTube", [youtube, 10], springboardTest_launchApp, "Launch YouTube");
	SearchForMovie = createTest("SearchForMovie", ["The Real Bruce Lee"], youtubeTest_searchForMovie, "Search for a movie");
	AddYouTubeBookmark = createTest("AddYouTubeBookmark", [], youtubeTest_addBookmarkFromMovie, "Add movie to bookmarks");
	LoginToYoutubeAccount = createTest("LoginToYoutubeAccount", [], youtubeTest_loginToYoutubeAccount, "Login to Youtube Account");	
	EmailYoutubeVideo = createTest("EmailYoutubeVideo", ["weliketesting@me.com"], youtubeTest_emailYoutubeVideo, "Email Video");
}

if (typeof calculator != 'undefined') {
	LaunchCalculator = createTest("LaunchCalculator", [calculator, 10], springboardTest_launchApp, "Launch Calculator");
	ClearCalculator = createTest("ClearCalculator", null, calcTest_clear, "Clear the calculator");
	Calculate = createTest("Calculate", ["987+654", "1641.000000"], calcTest_calculate, "Enter a calculation");
	ContinueCalculation = createTest("ContinueCalculation", ["-321"], calcTest_continueCalculation, "Continue a calculation");
}

if (typeof appstore != 'undefined') {
	LaunchAppStore = createTest("LaunchAppStore", [appstore, 10], springboardTest_launchApp, "Launch AppStore");
	PurchaseFacebook = createTest("PurchaseFacebook", ["Facebook", kStorePassword, null, "Facebook", kStoreUsername], appStoreTest_purchaseAppThroughSearching, "Search for 3rd party app and purchase it");
	LaunchFacebook = createTest("LaunchFacebook", null, facebookTest_launch, "Launch a purchased 3rd party app");
}

if (typeof stocks != 'undefined') {
	LaunchStocks = createTest("LaunchStocks", [stocks, 10], springboardTest_launchApp, "Launch Stocks");
	AddStock = createTest("AddStock", ["Google"], stocksTest_addStock, "Add Stock AAPL to List, if it's not already there");
	RemoveAndAddStock = createTest("RemoveAndAddStock", null, stocksTest_removeAndAddStock, "Remove and then Add Stock AAPL");
}

if (typeof safari != 'undefined') {
	LaunchSafari = createTest("LaunchSafari", [safari, 10], springboardTest_launchApp, "Launch Safari");
	LoadSafariPage = createTest("LoadSafariPage", ["http://pttest.apple.com/perfmarketing-power/testcontent/digg.html"], safariTest_loadSafariPage, "Load web page in Safari");
	PerformGoogleSearch = createTest("PerformGoogleSearch", ["amazon", "www.amazon.com", false], safariTest_performGoogleSearch, "Perform a Google search");
	SelectItemFromSuggestionList = createTest("SelectItemFromSuggestionList", ["www.appl", "www.apple.com/", "http://www.apple.com/"], safariTest_selectItemFromSuggestionList, "Select an item from the Suggestion List");
	RefreshPage = createTest("RefreshPage", ["http://pttest.apple.com/perfmarketing-power/testcontent/smithsonian.html"], safariTest_refreshPage, "Refresh page");
	ClickOnURL = createTest("ClickOnURL", ["http://pttest.apple.com/perfmarketing-power/", "flickr.html"], safariTest_clickOnURL, "Click on URL");
	OpenWebPageInTab = createTest("OpenWebPageInTab", openWebPageInTabParameters, safariTest_openWebPageInTab, "Open a web page in a Tab");
	OpenWebPageFromPreviousTab = createTest("OpenWebPageFromPreviousTab", openWebPageFromPreviousTabParameters, safariTest_openWebPageFromPreviousTab, "Open a web page from a previous tab");
	NavigateBackForward = createTest("NavigateBackForward", 
								["url:http://pttest.apple.com/perfmarketing-power/testcontent/smithsonian.html", "url:http://pttest.apple.com/perfmarketing-power/testcontent/caltrain.html",
							  "action:Back", "action:Forward"], 
							 safariTest_navigateWebPagesWithPreviousNextButtons, "Navigate with the Back / Forward buttons");
	LoadBookmark = createTest("LoadBookmark", [], safariTest_loadRandomBookmark, "Load Bookmark");
	AddBookmark = createTest("AddBookmark", 
							 ["http://pttest.apple.com/perfmarketing-power"], safariTest_addBookmark, "Add a bookmark");
	AddWebClip = createTest("AddWebClip", ["http://pttest.apple.com/perfmarketing-power"], safariTest_addBookmarkToHomeScreen, "Add a webclip");
}

var musicApp = "com.apple.mobileipod-VideoPlayer";
if (hasTelephony) {
	musicApp = "com.apple.mobileipod-MediaPlayer";
}
SearchForVideoUsingSpotlight = createTest("SearchForVideoUsingSpotlight", ["Nasa", "app:" + musicApp], springboardTest_search, "Search for video by title"); // will fail w/o QL content
SearchForCalculatorUsingSpotlight = createTest("SearchForCalculatorUsingSpotlight", ["Calculator", "app:com.apple.calculator", "query:name contains 'Calculator'"], springboardTest_search, "Search for calculator app"); 
SearchForSafariUsingSpotlight = createTest("SearchForSafariUsingSpotlight", ["Safari", "app:com.apple.mobilesafari", "query:name contains 'Safari'"], springboardTest_search, "Search for the Safari app");

var noteTitle = "CopyNote: " + runID;
CopyNote = createTest("CopyNote", [noteTitle, "Hi!  I like being copied.  How about you?"], notesTest_copyNote, "Copy text from one note and paste it into another");
CopyFromWebPage	= createTest("CopyFromWebPage", ["http://pttest.apple.com/perfmarketing-power/testcontent/disney.html", "name contains 'Tigger & Pooh'"], safariTest_copyFromWebPage, "Copy text from a web page onto the pasteboard");
PasteIntoNote =	createTest("PasteIntoNote", ["Tigger & Pooh"], notesTest_pasteIntoNote, "Paste text from web page into a new note");	

if (typeof messages != 'undefined') {
	var bulkSMSText = "Bulk SMS, " + runID;
	LaunchMessages = createTest("Launch Messages", [messages, 10], springboardTest_launchApp, "Launch Messages");
	SendReceiveSMS = createTest("SendReceiveSMS", ["1234567890_abcdefghijklmnopABCDEFGHIJKLMNOP.", "timeout:60", "minPercentForPass:0.75", "numberOfAdditionalTextMessagesToSend:5"], 
			messagesTest_sendReceiveTextMessage, "Send and receive an SMS");
	DeleteSMSThread = createTest("DeleteSMSThread", ["0"], messagesTest_deleteThread, "Delete an SMS thread");
	SendBulkSMS = createTest("SendBulkSMS", [bulkSMSText, "timeout:60", "expectedPercentage:0.5", "phoneNumber:" + telephony.myPhoneNumber, "phoneNumber:" + kSMSBuddy1, "phoneNumber:" + kSMSBuddy2], messagesTest_sendReceiveBulkSMS, "Send and receive bulk SMS");	
	TakePhotoAndSendMMS = createTest("TakePhotoAndSendMMS", ["from:Take Photo"], messagesTest_sendReceivePhotoOrVideoMMS, "Take a photo and send it using MMS");
	SendExistingPhotoMMS = createTest("SendExistingPhotoMMS", ["from:Choose Photo", "textToSend:Hello There."], messagesTest_sendReceivePhotoOrVideoMMS, "Send an existing photo using MMS");
	SendVideoMMS = createTest("SendVideoMMS", ["from:Take Video", "timeout:300"], messagesTest_sendReceivePhotoOrVideoMMS, "Send a video using MMS");
}

SetWallpaper = createTest("SetWallpaper", [], settingsTest_setWallpaper, "Set wallpaper to something from wallpaper");
LockUnlock = createTest("LockUnlock", ["0"], systemTest_lockAndUnlockDevice, "Lock and unlock the device");
SetPasscode = createTest("SetPasscode", ["1111"], settingsTest_setPasscode, "Set a passcode for the device");
LockUnlockWithPasscode = createTest("LockUnlockWithPasscode", ["0", "1111"], systemTest_lockAndUnlockDevice, "Lock and unlock the device with passcode set");
ChangePasscode = createTest("ChangePasscode", ["2222"], settingsTest_setPasscode, "Change the passcode on the device");
TurnPasscodeOff = createTest("TurnPasscodeOff", ["2222"], settingsTest_turnPasscodeOff, "Turn passcode for the device off");