#import "UIAAppStressLibrary.js"

if (typeof clock != 'undefined') {
	clockStress = AppStressBase.stressTest("Clock");
	
	if (typeof clockStress != 'undefined') {
		clockStress._worldClockList = new Array();
		
		clockStress.setup = function setup() {
			clockStress.addTest(clockStress._addWorldClock);
			clockStress.addTest(clockStress._removeWorldClock);
//			clockStress.addTest(clockStress._addAndWaitForAlarm);
//			clockStress.addTest(clockStress._createAndEditAlarms);
			clockStress.addTest(clockStress._startStopwatch);
			clockStress.addTest(clockStress._stopStopwatch);
			clockStress.addTest(clockStress._resetStopwatch);
		}
		
		clockStress.run = function run() {
			clockStress.executeRandomTests(2);
			clockStress.executeTest("RemoveAllAlarms", [], clockTest_removeAllAlarms, "Remove all alarms.");
		}
		
		
		clockStress._addWorldClock = function _addWorldClock() {
			var city = randomCityData();
			var result = clockStress.executeTest ( "AddWorldClock",
												   [ city.name, city.name + ", " + city.country ],
												   clockTest_addWorldClock,
												   "Add a world clock" );
			
			if (result) {
				clockStress._worldClockList.push(city.name);
			}
			
			return result;
		}
		
		
		clockStress._removeWorldClock = function _removeWorldClock() {
			var city;
			
			// add a clock if none exist
			if (clockStress._worldClockList.length == 0) {
				if (!clockStress._addWorldClock()) {
					UIALogger.logError("No clocks exist and not able to add one -- skipping test.");
					return;
				}
			}
			
			city = UIAUtility.randomFromArray(clockStress._worldClockList);
			
			result = clockStress.executeTest("RemoveWorldClock", [city], clockTest_removeWorldClock, "Remove a world clock.");
			
			if (result) {
				clockStress._worldClockList.splice(clockStress._worldClockList.indexOf(city));
			}
			
			return result;
		}
		
		
		clockStress._addAndWaitForAlarm = function _addAndWaitForAlarm() {
			var sound = UIAUtility.randomFromArray(clock.soundChoices);
			
			clockStress.executeTest( "AddAndWaitForAlarm", ["delay:3", "sound:" + sound],
									 clockTest_addAndWaitForAlarm, "Add an alarm and wait for it to go off." );
		}
		
		
		clockStress._createAndEditAlarms = function _createAndEditAlarms() {
			var count = system.randomInteger(1, 3);
			var edits = system.randomInteger(1, 2);
			
			clockStress.executeTest( "CreateAndEditAlarms", [count, edits], 
									 clockTest_createAndEditAlarms, "Create and edit multiple alarms." );
		}
		
		
		clockStress._startStopwatch = function _startStopwatch() {
			clockStress.executeTest("StartStopwatch", [], clockTest_startStopwatch, "Start the stopwatch.");
		}
		
		
		clockStress._stopStopwatch = function _stopStopwatch() {
			clockStress.executeTest("StopStopwatch", [], clockTest_stopStopwatch, "Stop the stopwatch.");
		}
		
		
		clockStress._resetStopwatch = function _resetStopwatch() {
			clockStress.executeTest("ResetStopwatch", [], clockTest_resetStopwatch, "Reset the stopwatch.");
		}
	}
}