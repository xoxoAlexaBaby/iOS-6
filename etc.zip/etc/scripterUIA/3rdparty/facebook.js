function waitForNavBarButtons() {
	UIALogger.logMessage("Waiting for nav bar buttons to show up...");
    UIATarget.localTarget().pushTimeout(15);
    var navBarButton = UIATarget.localTarget().frontMostApp().navigationBar().buttons()[0];
    UIATarget.localTarget().popTimeout();
    if (!navBarButton.isValid()) throw new Error("The nav bar buttons did not show up");
}


function getToMainPage() {
	UIALogger.logMessage("Going to the main screen...");
    
	for (var i=0; i<6; i++) {
        var backButton = UIATarget.localTarget().frontMostApp().navigationBar().leftButton();
        if (backButton.isValid()) {
            UIALogger.logMessage("Back button found.");
            if (backButton.name() == "Logout") {
                UIALogger.logMessage("On main screen.");
                return ;
            }
            backButton.tap();	
			UIATarget.localTarget().delay(1);
        } else {
			UIATarget.localTarget().frontMostApp().mainWindow().buttons()["Cancel"].tap();
		}
	}
	throw new Error("Could not get to the main screen");
}

function goToSection(sectionName) {
	UIALogger.logMessage("Going to the " + sectionName + " page...");
	UIATarget.localTarget().frontMostApp().mainWindow().scrollViews()[0].buttons()[sectionName].tap();	
}

function printFacebookTable(table, numOfCells) {
    if (table.cells().length < numOfCells) numOfCells = table.cells().length;
	UIALogger.logMessage("Printing " + numOfCells + " cells...");
	for (var i=0; i<numOfCells; i++) {
		var fromElement = table.cells()[i];
        UIALogger.logMessage("The " + (i+1) + "th item contains '" + fromElement.name() + "'");
	}
}


function navigateWithinProfile() {
	UIALogger.logMessage("Navigating within the profile");
        
	var segmentedControl = UIATarget.localTarget().frontMostApp().toolbar().segmentedControls()[0];
	if (!segmentedControl.isValid()) throw new Error("Could not find the segmented control in the profile");
	var profileTable;
    
	//screenshot
	//UIALogger.captureScreen("Profile screenshot");
		
	//wall section
	UIALogger.logMessage("Going to the wall...");
	segmentedControl.buttons().firstWithPredicate("name matches 'Wall, .*'").tap();
	UIATarget.localTarget().delay(1);
	
	profileTable = UIATarget.localTarget().frontMostApp().mainWindow().tableViews()[0];
	if (!profileTable.isValid()) throw new Error("Could not find the wall table");
	printFacebookTable(profileTable, 5);
	UIALogger.logMessage("Done with the wall");
	
	//info section
	UIALogger.logMessage("Going to Info...");
	segmentedControl.buttons().firstWithPredicate("name matches 'Info, .*'").tap();
    UIATarget.localTarget().delay(1);

	if (!profileTable.checkIsValid()) throw new Error("Could not find the info table");
	printFacebookTable(profileTable, 5);
	UIALogger.logMessage("Done with the info page");
	
	//photos section
	UIALogger.logMessage("Going to Photos...");
	segmentedControl.buttons().firstWithPredicate("name matches 'Photos, .*'").tap();
    UIATarget.localTarget().delay(1);

	if (!profileTable.checkIsValid()) throw new Error("Could not find the photos table");
	UIALogger.logMessage("Looking for a photos album...");
	var photoAlbum = profileTable.cells()[0];
	UIALogger.logMessage("Going to '" + photoAlbum.name() + "' album");
	photoAlbum.tap();
    UIATarget.localTarget().delay(1);

	var photosTable = UIATarget.localTarget().frontMostApp().mainWindow().tableViews()[0];
	if (!photosTable.isValid()) throw new Error("Could not find the photos table");
    
	UIALogger.logMessage("Tapping on a photo");
	photosTable.cells()[0].buttons()[0].tap();
	UIATarget.localTarget().delay(1);
	
	var nextButton = UIATarget.localTarget().frontMostApp().toolbar().buttons()[2];
	for (var i=0; i<10; i++) {
		UIALogger.logMessage("Going to the next photo...");
		nextButton.tap();
		UIATarget.localTarget().delay(1);
	}
	UIALogger.logMessage("Done looking at photos");
}

function search(searchTerm, searchType) {

    UIALogger.logMessage("Searching...");
    var searchBar = UIATarget.localTarget().frontMostApp().mainWindow().searchBars()[0];
    searchBar.tap();
	UIATarget.localTarget().delay(1);
	
    if (searchType) {
        UIALogger.logMessage("Setting the search type to be '" + searchType + "'");
        var segmentedControls = UIATarget.localTarget().frontMostApp().mainWindow().segmentedControls()[0];
        if (!segmentedControls.isValid()) throw new Error("Could not find the segmented controls");
        
        segmentedControls.buttons().firstWithPredicate("name matches '" + searchType + ",.*'").tap();
		UIATarget.localTarget().delay(1);
    }
    searchBar.setValue(searchTerm); 

    var resultsTable = UIATarget.localTarget().frontMostApp().mainWindow().tableViews()[0];
    if (!resultsTable.isValid()) {
        UIALogger.logMessage("Did not find a results table. Cancelling search");
        UIATarget.localTarget().frontMostApp().mainWindow().buttons()["Cancel"].tap();
        UIALogger.logMessage("Done with search");
    }
    
    var firstResultCell = resultsTable.cells()[0];
    if (!firstResultCell.isValid()) throw new Error("Could not find a search result to select");
    UIALogger.logMessage("Selecting the first search result '" + firstResultCell.name() + "'");
    firstResultCell.tap();
}

function selectFriend(name) {
    UIALogger.logMessage("Selecting a friend ");
	goToSection("Friends");
    
	var friendsTable = UIATarget.localTarget().frontMostApp().mainWindow().tableViews()[0];
	if (!friendsTable.isValid()) throw new Error("Could not find the friends table");
    
	var friend = (name == null)? friendsTable.cells()[0] : friendsTable.cells()[name];
    if (!friend.isValid()) throw new Error("Could not find a friend in the friends table");
	friend.scrollToVisible();
	var friendName = friend.name();
    
	UIALogger.logMessage("Selecting '" + friendName + "'");
	friend.tap();
    UIATarget.localTarget().delay(1);
    return friendName;
}

function editFavorite(shouldRemove) {
    
	UIALogger.logMessage("Tapping the action button");
    UIATarget.localTarget().frontMostApp().navigationBar().buttons()["Action"].tap();
	UIATarget.localTarget().delay(1);
	
	var alert = UIATarget.localTarget().frontMostApp().actionSheet();
	if (!alert.isValid()) throw new Error("Could not find the alert");
    
	var favoriteButtonName = (shouldRemove == true)? "Remove Favorite" : "Add Favorite";
	var favoriteButton = alert.buttons().firstWithPredicate("name matches '.* Favorite'");
    if (!favoriteButton.isValid()) throw new Error("Could not find the favorites button");
	if (favoriteButtonName != favoriteButton.name()) {
		UIALogger.logError("The desired action is not supported. Instead, '" + favoriteButton.name() + "' is available");
		UIALogger.logMessage("Hitting the other favorite button regardless");
        favoriteButton.tap();
		throw new Error(favoriteButtonName + " is not available");
	}
    favoriteButton.tap();
}


function test_search(searchTerm, searchType) {
    var testName = "Search test";
	UIALogger.logStart(testName);
	try {
		getToMainPage();
        search(searchTerm, searchType);
        
        UIALogger.logMessage("Navigating profile of the selected search result now");
        navigateWithinProfile();
    
	} catch(e) {
		UIALogger.logError(e.message);
		UIALogger.logFail(testName);
		return ;
	}
	UIALogger.logPass(testName);
}

function test_viewMyProfile() {
    var testName = "View my profile test";
	UIALogger.logStart(testName);
	try {
		getToMainPage();
		goToSection("Profile");
		navigateWithinProfile();
	} catch(e) {
		UIALogger.logError(e.message);
		UIALogger.logFail(testName);
		return ;
	}
	UIALogger.logPass(testName);
}

function test_viewNewsFeed() {
    var testName = "News feed test";
	UIALogger.logStart(testName);
	try {
		getToMainPage();
		goToSection("News Feed");
		var newsFeedTable = UIATarget.localTarget().frontMostApp().mainWindow().tableViews()[0];
		if (!newsFeedTable.isValid()) throw new Error("Could not find the news feed table");
		printFacebookTable(newsFeedTable, 5);
	} catch(e) {
		UIALogger.logError(e.message);
		UIALogger.logFail(testName);
		return ;
	}
	UIALogger.logPass(testName);
}

function test_addToFavorite() {
    var testName = "Add to favorites test";
	UIALogger.logStart(testName);
	var friendName;
	try {
        getToMainPage();
        var friendName = selectFriend();
		editFavorite();
	} catch(e) {
		UIALogger.logError(e.message);
		UIALogger.logFail(testName);
		return null;
	}
	UIALogger.logPass(testName);
	return friendName;
}

function test_removeFromFavorites(friendName) {
    var testName = "Remove from favorites test";
	UIALogger.logStart(testName);
	try {
        getToMainPage();
        selectFriend(friendName);
		editFavorite(friendName, true);
	} catch(e) {
		UIALogger.logError(e.message);
		UIALogger.logFail(testName);
		return null;
	}
	UIALogger.logPass(testName);
}

waitForNavBarButtons();
test_viewNewsFeed();
test_viewMyProfile();
var friendName = test_addToFavorite();
if (friendName != null) test_removeFromFavorites(friendName);
test_search("Green Peace", "Pages");
test_search("A", "Friends");