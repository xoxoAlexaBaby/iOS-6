#import "./Mail.js"
#import "../libs/PHTesting.js"

//----------------------------------------------------------------------------------------
//	mailTest_createEmailAccount - use settingsTest_createEmailAccount()
//	mailTest_deleteEmailAccount - use settingsTest_deleteEmailAccount()
//----------------------------------------------------------------------------------------


//----------------------------------------------------------------------------------------
//	Function: mailTest_composeAndSendEmail
//		Composes and sends a user defined mail message from the mail account that's open.  
//
//	Parameters: 
//		toAddress (string) - address to which the email has to be sent. (not optional)
//		subject (string) - subject of the email (optional, if not specified a message subject will be
//			random characters)
//		body (string) - body of the email (optional, if not specified a message of random characters is sent)
//
//  Optional Parameters:  Optional arguments passed in as: "to:weliketesting@me.com" "bcc:who@why.com"
//		from (string) - (optional)  Address from which the email should be sent
//			if left blank, it picks a "random" inbox.  Make sure this account is 
//			configured on the device.
//		to (string) - additional "to" addresses (besides the original one above)
//		bcc (string) - "bcc" addresses for email to be sent
//		cc (string) - "cc" addresses for email to be sent
//		validateSent (bool) - indicates whether or not we should validate that the 
//			email is in the sent folder.  Default is to not validate
//	
//	Returns:
//		0 if test failed, 1 if it succeeded.  Uses the PHTesting object.
//----------------------------------------------------------------------------------------
function mailTest_composeAndSendEmail() {
	this.testResult = 0;
	if (this.argv.length < 3) {
		UIALogger.logMessage("Not enough args being passed.  Randomness has not be added in yet.");
		// TODO add randomess in for subject and body, if they are not specified
		return 0;		
	}

	var toAddress = this.argv[0];
	var subject = this.argv[1];
	var body = this.argv[2];
	var optionsArray = new Array();
	
	// Push options onto optionsArray;
	for (var i=3; i<this.argv.length; i++) {
		optionsArray.push(this.argv[i]);
	}
	var fromAddress = UIAUtility.valuesForKey("from", optionsArray, 1);  // only expect one 'fromAddress'
	var toArray = UIAUtility.valuesForKey("to", optionsArray);
	var ccArray = UIAUtility.valuesForKey("cc", optionsArray);
	var bccArray = UIAUtility.valuesForKey("bcc", optionsArray);
	var validateSent = UIAUtility.valuesForKey("validateSent", optionsArray, 1);  // only expect one validateSent value
		
	if (!toArray)  toArray = new Array();
 	toArray.push(toAddress); // Add the passed in subject to the toArray
	UIALogger.logMessage("Sending email to [" + toArray + "], with subject '" + subject + "'");
	
	// Launch mail and get to the correct folder
	if (fromAddress) {
		mail.getToEmailFolder(fromAddress, "Inbox");
	}
	else {
		mail.getToEmailFolder();
	}
	
	var composeEmailOptions = new Object();
	composeEmailOptions.to = toArray;
	
	composeEmailOptions.cc = ccArray;
	composeEmailOptions.bcc = bccArray;
	composeEmailOptions.subject = subject;
	composeEmailOptions.body = body;
	
	try {
		var composeButton = mail.mainWindow().toolbars().firstWithPredicate("ANY elements.name == 'Compose'").elements()["Compose"];
		UIALogger.logMessage("Tapping 'Compose' button to start a new email message.");
		if (!composeButton.isVisible() && (UIATarget.localTarget().model() == "iPad")) {
		    // If the compose button isn't valid, a popover is probably up.  Tap the middle of the screen to get rid of it: <rdar://problem/9725566>
		    mail.mainWindow().tap();
		    UIATarget.localTarget().delay(1); // the button itself isn't animating, so we have to wait.
		    composeButton = mail.mainWindow().toolbars().firstWithPredicate("ANY elements.name == 'Compose'").elements()["Compose"];
		}
		composeButton.tap();
		UIATarget.localTarget().delay(1); // give animation time to take place.
		if ((UIATarget.localTarget().model() == 'iPad') && (!mail.mainWindow().scrollViews()[0].elements().firstWithPredicate("name contains 'To'").isValid())) {
			// If the mail navigator is up, tapping the 'Compose' button will only dismiss it.  Tap it again to compose a new email.  (Using 'contains', because of <rdar://problem/9327413>)
			UIALogger.logMessage("Trying to tap the 'Compose' button again.");
			mail.mainWindow().toolbars().firstWithPredicate("ANY elements.name == 'Compose'").elements()["Compose"].tap();
			UIATarget.localTarget().delay(1);
		}
	}
	catch(e) {
		UIALogger.logMessage("Caught error: " + e.message);
		throw new Error("Could not tap the 'Compose' button");
	}
	
	// fill in the to, subject, bcc, cc, bod
	mail.composeEmail(composeEmailOptions);
	
	UIATarget.localTarget().delay(1);
	
	// Hit the send button
	UIALogger.logMessage("Hitting the 'Send' button");
	try {
		mail.mainWindow().navigationBar().buttons()["Send"].tap();
	}
	catch(e) {
		UIALogger.logMessage("Caught error: " + e.message);
		throw new Error("Could not tap the 'Send' button");
	}
	
	
	// check sent folder to see if email was actually sent  
	if ((validateSent == 1) || (validateSent == "true") || (validateSent == true)) {
		if (!fromAddress) {
			UIALogger.logError("Must enter a valid 'fromAddress' in order to check if the email exists in 'sent' folder--this will return an error if there is more than one email account on device.")
		}
		UIALogger.logMessage("Validating that email was successfully sent");
		if (!mail.verifyEmailExists(subject, fromAddress, "Sent", 120)) {
			this.testError = "Could not verify that email exists in 'Sent' folder"
			return 0;
		}			
	}	
	UIALogger.logMessage("Successfully composed and sent the email message");
	return (this.testResult = 1);
}

//----------------------------------------------------------------------------------------
//	Function: mailTest_verifyEmailInFolder 
//		Fetches mail and verifies specified new mail has arrived or has been sent or is in trash
//
//	Assumes: 
//		Assumes mail is already set up.  Uses the PHTesting object.
//
//	Parameters: 
//		subject (string) - title of the email to look for (required).  We do a partial
//			match on the subject (i.e. .*subject.*)
//		account (string) - address or account description in which the email should be located
//			If not specified, it looks in the first folder it can find.  (optional)
//		folder (string) - folder in which the email should be located.  If not specified,
//			we look in the inbox. (optional)
//		timeout (string) - number of seconds to wait for new mail to arrive. (optional--
///			default is 5 minutes)
//
//	Returns:
//		0 if test failed, 1 if it succeeded.  
//----------------------------------------------------------------------------------------
function mailTest_verifyEmailInFolder() {
	this.testResult = 0;
	
	if (this.argv.length < 1) {
		this.testError = "Not enough args were passed"
		UIALogger.logMessage(this.testError);
		return 0;		
	}
	var subject = this.argv[0];
	var account = null;
	var folder = null;
	var timeout = 300;  // default is 5 minutes.
	
	if (this.argv.length > 1) {
		account = this.argv[1];
	}	
	if (this.argv.length > 2) {
		folder = this.argv[2];
	}	
	if (this.argv.length > 3) {
		timeout = this.argv[3];
	}	
	if (!mail.verifyEmailExists(subject, account, folder, timeout)) {
		this.testError = "Could not find email with subject '" + subject + "'";
		UIALogger.logError(this.testError);
		return (this.testResult = 0);
	}
	else {
		UIALogger.logMessage("Found email with subject '" + subject + "'");
		return (this.testResult = 1);
	}
}

//----------------------------------------------------------------------------------------
//	Function: mailTest_deleteEmail
//		Deletes specified email.
//
//	Assumes: 
//		Assumes mail is already set up.  Uses the PHTesting object.
//
//	Parameters: 
//		subject (string) - title of the email to look for (required).  We do a partial
//			match on the subject (i.e. .*subject.*).  If subject is set as "RANDOM" (must
//			be all caps, we will delete a random email.)
//		account (string) - address or account description in which the email should be located
//			If not specified, it looks in the first folder it can find.  (optional)
//		folder (string) - folder in which the email should be located.  If not specified,
//			we look in the inbox. (optional)
//
//	Returns:
//		0 if test failed, 1 if it succeeded.
//----------------------------------------------------------------------------------------
function mailTest_deleteEmail() {
	this.testResult = 0;
	
	if (this.argv.length < 1) {
		this.testError = "Not enough args were passed"
		UIALogger.logMessage(this.testError);
		return 0;		
	}
	var subject = this.argv[0];
	var account = null;
	var folder = null;
	
	if (this.argv.length > 1) {
		account = this.argv[1];
	}
	if (this.argv.length > 2) {
		folder = this.argv[2];
	}	
	
	if (!mail.deleteEmail(subject, account, folder)) {		
		UIALogger.logMessage("Could not delete email with subject '" + subject + "'");
		return (this.testResult = 0);
	}
	return this.testResult = 1;
	
}

//----------------------------------------------------------------------------------------
//	Function: mailTest_search 
//		Searches for a string value in the email account and taps on first
//		found element (if there is one).  Passes if match is found for value.
//
//	Requires:
//		The account exists.  The item to be searched for exists (if you want a pass).
//
//	Parameters: 
//		searchString (string) - the string to be searched for
//		account (string) - the address or description of the account to be searched
//		searchType (string) - value to choose.  Should be "From", "To," "Subject," or "All"
//
//  Optional Parameters:
//		shouldSearchServer (bool) - 1/0 or true/false to indicate if a server search should be
//			done. If not specified, we assume local search only.
//		folder (string) - folder to search
//		shouldTap (bool) - boolean indicating whether or not the email searched for should be
//			opened (i.e. tapped).  If not specified, the email is not opened.
//		timeout (integer) - amount of time to wait for results to show up.  Set to 60 by
//			default.
//
//	Returns:
//		0 if test failed, 1 if it succeeded.  Uses the PHTesting object.
//----------------------------------------------------------------------------------------
function mailTest_search() {
	if (this.argv.length < 3) {
		this.testError = "Please pass in at least 3 arguments."
		UIALogger.logError(this.testError);
		return this.testResult=0;		
	}
	
	this.testResult = 0;
	var options = new Object();
	var searchString = this.argv[0];
	options.account = this.argv[1];
	options.searchType = this.argv[2];
	
	// Push options onto optionsArray;
	var optionsArray = new Array(); 
	for (var i=3; i<this.argv.length; i++) {
		optionsArray.push(this.argv[i]);
	}
	
	options.shouldSearchServer = UIAUtility.valuesForKey("shouldSearchServer", optionsArray, 1);  // only expect one 'searchServer' value
	options.folder = UIAUtility.valuesForKey("folder", optionsArray, 1); // only expect one 'folder' value
	options.shouldTap = UIAUtility.valuesForKey("shouldTap", optionsArray, 1); // only expect one 'shouldTap' value
	options.timeout = UIAUtility.valuesForKey("timeout", optionsArray, 1); // only expect one 'timeout' value
		
	mail.search(searchString, options);
	return this.testResult = 1;
	
}

//----------------------------------------------------------------------------------------
//	mailTest_downloadMailAttachment - navigates to the proper email account folder (if
//		not specified, we go to the first inbox we navigate to), taps the specified
//		email and opens the attachment.  It then checks the title of the current page
//		page to make sure it matches what we expect.
//
//	Parameters: 
//	    emailTitle (string) - title of the email to look for (required)	
//		attachmentName (string) - name of the attachment
//		
//	Optional Parameters:
//		account (string) - mail account in which the email should be
//		folder (string) - folder in which the email should reside
//		timeout (number) - number of seconds to wait for attachment to download (optional--
//			default is 2 minutes)
//		waitForMailTimeout (number) - number of seconds to wait for mail to be present in
//			inbox.  If set to 0, we bypass checking in mail list completely and just do
//			a search
//		exactMatch (bool) - set to 'true' if you want an exact match of the attachment name, 
//			false if you want a partial match (i.e. "name contains 'attachmentName'").  This is false by default.
//		noVerification (bool) - set to true if verification that the attachment was downloaded
//			is not desired.  This is assumed to be false by default (i.e. verification is done
//			by default)
//		elementToValidate (bool) - This is separate from noVerification.  If an elementToValidate is
//			passed in, we ensure, at the end, that the element exists 
//			(i.e. elementToValidate:UIATarget.localTarget().frontMostApp().mainWindow().navigationBar().buttons()['Cancel'])
// 			If this is left blank, this verification does not occur.
//
//	Returns:
//	 0 if test failed, 1 if it succeeded.  Assumes mail is already set up.  Uses the PHTesting object.
//----------------------------------------------------------------------------------------
function mailTest_downloadMailAttachment() {
	if (this.argv.length < 2) {
		this.testError = "Please pass in at least 2 arguments."
		UIALogger.logError(this.testError);
		return this.testResult=0;		
	}
	var emailTitle = this.argv[0];
	var attachmentName = this.argv[1];
	
	this.testResult = 0;
	
	// Push options onto optionsArray;
	var optionsArray = new Array(); 
	for (var i=2; i<this.argv.length; i++) {
		optionsArray.push(this.argv[i]);
	}
	
	// get optional parameter values
	var options = new Object();
	options.account = UIAUtility.valuesForKey("account", optionsArray, 1);  
	options.folder = UIAUtility.valuesForKey("folder", optionsArray, 1); 
	options.timeout = UIAUtility.valuesForKey("timeout", optionsArray, 1); 
	options.waitForMailTimeout = UIAUtility.valuesForKey("waitForMailTimeout", optionsArray, 1); 
	options.noVerification = UIAUtility.valuesForKey("noVerification", optionsArray, 1); 
	options.exactMatch = UIAUtility.valuesForKey("exactMatch", optionsArray, 1); 
	options.elementToValidate = UIAUtility.valuesForKey("elementToValidate", optionsArray, 1);
	
	if (!options.timeout) options.timeout = 120;  // default download timeout is 2 minutes
	if (!options.waitForMailTimeout) options.waitForMailTimeout = 10;  // default timeout to check the inbox for the email is 10 seconds.
	
	mail.downloadAttachment(emailTitle, attachmentName, options);
	
	UIALogger.logMessage("Successfully downloaded the attachment.  Finished test.");
	return this.testResult = 1;
	
}

//----------------------------------------------------------------------------------------
//	mailTest_deleteBulk - deletes the emails in bulk, choosing random ones if none are specified
//
//	Requires:
//		There must be an account setup and there must be some emails to delete from that account.
//
//	Optional Parameters:
//		account (string) - mail account in which the email should be.  If not specified, chooses
//			the first account.
//		folder (string) - folder from which the email(s) should be deleted.  If not specified,
//			choose "Inbox"
//		title (string) - title of the email to look for.  If not specified, chooses a random
//			one
//		numMessages (integer) - number of emails to delete.  If one or more titles are speicfied,
//			this preference is ignored.  Otherwise, this preference indicates the number of 
//			random emails to delete.  Chooses 1 by default.
//
//	Returns:
//	 0 if test failed, 1 if it succeeded.  Uses the PHTesting object.
//----------------------------------------------------------------------------------------
function mailTest_deleteBulk() {	
	this.testResult = 0;
	
	// Push options onto optionsArray;
	var optionsArray = new Array(); 
	for (var i=0; i<this.argv.length; i++) {
		optionsArray.push(this.argv[i]);
	}
	
	// get optional parameter values
	var options = new Object();
	options.account = UIAUtility.valuesForKey("account", optionsArray, 1);  
	options.folder = UIAUtility.valuesForKey("folder", optionsArray, 1); 
	options.emailTitles = UIAUtility.valuesForKey("title", optionsArray); 
	options.numMessages = UIAUtility.valuesForKey("numMessages", optionsArray, 1); 
	
	if (!options.numMessages) numMessages = 1;  // default number of random messages to delete is 2.
	
	mail.deleteBulk(options);
	
	UIALogger.logMessage("Successfully deleted the items.  Finished test.");
	return this.testResult = 1;
}

//----------------------------------------------------------------------------------------
//	Function: mailTest_printEmail
//		Searches for email, taps it, and prints that email.
//
//	Requires:
//		The account exists and the item to be searched for exists.
//
//	Parameters: 
//		searchString (string) - the string to be searched for.  If you want to print
//			a random email, pass in "RANDOM"
//
//	Optional Parameters:
//		account (string) - the address or description of the account to be searched
//		shouldSearchServer (bool) - 1/0 or true/false to indicate if a server search should be
//			done. If not specified, we do a search on the server.
//		folder (string) - folder to search
//		searchType (string) - value to choose.  Should be "From", "To," "Subject," or "All"
//		printerName (string) - the name of the printer. If no value is specified, 
//			a random printer is selected
//		numberOfCopies (number) - the number of print copies. If no value is 
//			specified, the default value is not changed.
//
//	Returns:
//		0 if test failed, 1 if it succeeded.  Uses the PHTesting object.
//----------------------------------------------------------------------------------------
function mailTest_printEmail() {
	if (this.argv.length < 1) {
		this.testError = "Please pass in at least one argument."
		UIALogger.logError(this.testError);
		return this.testResult=0;		
	}
	
	this.testResult = 0;
	var options = new Object();
	var searchString = this.argv[0];
	
	// Push options onto optionsArray;
	var optionsArray = new Array(); 
	for (var i=1; i<this.argv.length; i++) {
		optionsArray.push(this.argv[i]);
	}
	
	options.account = UIAUtility.valuesForKey("account", optionsArray, 1);  
	options.shouldSearchServer = UIAUtility.valuesForKey("shouldSearchServer", optionsArray, 1); 
	options.folder = UIAUtility.valuesForKey("folder", optionsArray, 1); 
	options.shouldTap = true;
	options.searchType = UIAUtility.valuesForKey("searchType", optionsArray, 1); 
	options.printerName = UIAUtility.valuesForKey("printerName", optionsArray, 1); 
	options.numberOfCopies = UIAUtility.valuesForKey("numberOfCopies", optionsArray, 1); 
	
	if (!options.shouldSearchServer) options.shouldSearchServer = 1;
	
	if (searchString == "RANDOM") {
		// Find a random email and tap it, for loop is used to navigate through threads
		for (var i=0; i<3; i++) {
			mail.getToEmailFolder(options.account, options.folder);
			UIATarget.localTarget().delay(1);
			var theEmail = mail.chooseRandomEmail();
			UIATarget.localTarget().delay(1);
			theEmail.scrollToVisible();
			theEmail.tap();
			UIATarget.localTarget().delay(1); // let animations take place.
			if (mail.isInEmailView()) break;
		}
	}
	else {	
		// Search for an email
		mail.search(searchString, options);
	}
	UIATarget.localTarget().delay(2); // give page time to finish loading and animations time to finish.
	
	mail.printEmail(options);
	
	return this.testResult = 1;
	
}

//----------------------------------------------------------------------------------------
//	Function: mailTest_checkDataDetection
//      Loads a sample e-mail with and check the detected results.
//
//	Assumes: 
//		Assumes mail is already set up.  Uses the PHTesting object.
//
//	Parameters:
//      subject (string) - Subject of the mail to check
//		account (string) - address or account description in which the email should be located
//			If not specified, it looks in the first folder it can find.
//		folder (string) - folder in which the email should be located.
//		timeout (string) - Optional - number of seconds to wait for new mail to arrive. (
//			default is 5 minutes)
//		data (string) - Optional - the string that will hold an url
//		url (string) - Optional - the target url of the string above
//          there must be one url per data option
//          the url and data options must be correctly ordered
//----------------------------------------------------------------------------------------
function mailTest_checkDataDetection() {
    this.testResult = 0;
	
	if (this.argv.length < 2) {
		this.testError = "Not enough args were passed"
		UIALogger.logMessage(this.testError);
		return 0;
	}
	
	var subject = this.argv[0];
    
	var options = new Object();
    
	options.account = this.argv[1];
	if (typeof options.account == 'undefined') options.account = null;

	options.folder = this.argv[2];
	if (typeof options.folder == 'undefined') options.folder = null;

	// Push options onto optionsArray;
	var optionsArray = new Array();
	for (var i=3; i<this.argv.length; i++) {
		optionsArray.push(this.argv[i]);
	}
	
	// Build the expected urls array 
	var nameArray = UIAUtility.valuesForKey("data", optionsArray);
	var urlArray = UIAUtility.valuesForKey("url", optionsArray);
	if (nameArray.length != urlArray.length) {
		this.testError = "Results count (" + nameArray.length + ") doesn't match urls count (" + urlArray.length + ")";
		UIALogger.logError(this.testError);
		return 0;
	}
	expectedURLs = new Array();
	for (var i=0; i<nameArray.length; i++) {
		expectedURLs.push({
			name: nameArray[i],
			url: urlArray[i],
		});
	}

	// Setup optional timeout
	if (this.argv.length == 4) {
		options.timeout = UIAUtility.valuesForKey("timeout", optionsArray, 1); // only expect one 'timeout'
	}
	if (typeof options.timeout == 'undefined') options.timeout = 300; // default is 5 minutes.

	var success = mail.checkDataDetection(subject, options.account, options.folder, expectedURLs, options);
	
	if (success) this.testResult = 1;
}


// Create self tests -- this is an unnamed function, just to make sure any local variables stay in the correct context
(function() {
	if (typeof mail.selfTests == 'undefined') {
		mail.selfTests = new Array();
	}
	
	var date = new Date();
	var testSuffix = "" + date.getHours() + date.getMinutes() + date.getSeconds();
	var title1 = "This is a Unit Test Email: " + testSuffix;
	
	mail.selfTests.push(phtCreateTest("ComposeAndSendEmail", ["weliketesting@me.com", title1, "Hi.  How are you today?  I am a unit test", "from:weliketesting@me.com"], 
			mailTest_composeAndSendEmail, "Compose and Send Predefined Message"));
	mail.selfTests.push(phtCreateTest("FetchNewMail", [title1, "weliketesting@me.com", "Inbox", 60], mailTest_verifyEmailInFolder, "Fetch New Mail"));
	mail.selfTests.push(phtCreateTest("SearchMailLocally", [testSuffix, "weliketesting@me.com", "Subject"], mailTest_search, "Search mail locally"));
	mail.selfTests.push(phtCreateTest("SearchMailOnServer", ["Hello", "weliketesting@me.com", "Subject", "shouldSearchServer:true"], mailTest_search, "Search mail on server"));
	mail.selfTests.push(phtCreateTest("DeleteMail", [title1, "weliketesting@me.com", "Inbox"], mailTest_deleteEmail, "Delete a Mail Message"));
	mail.selfTests.push(phtCreateTest("DownloadAttachment", ["I want a pony", "pony.pdf", "account:weliketesting@me.com", "folder:Inbox"], mailTest_downloadMailAttachment, "Download a pdf in mail"));
	mail.selfTests.push(phtCreateTest("DeleteBulkEmails", ["account:weliketesting@me.com", "folder:Trash", "numMessages:3"], mailTest_deleteBulk, "Delete emails with bulk delete"));
	mail.selfTests.push(phtCreateTest("PrintEmail", ["I want a pony", "account:weliketesting@me.com", "folder:Inbox", "printerName:dailyQLAutomation"], mailTest_printEmail, "Print an email"));
	mail.selfTests.push(phtCreateTest("PrintRandomEmail", ["RANDOM", "printerName:dailyQLAutomation"], mailTest_printEmail, "Print a random email"));

	// DataDetection Tests
	mail.selfTests.push(phtCreateTest("checkDataDetection", ["Misc Types", "weliketesting@me.com", "DataDetection", "timeout:30",
			"data:http://www.apple.com/francestore",
			"url:http://www.apple.com/francestore",
			"data:contactus.fr@euro.apple.com",
			"url:mailto:contactus.fr@euro.apple.com",
			"data:1Z50T0536891664106",
			"url:x-apple-data-detectors://2",
			"data:1 Infinite Loop",
			"url:x-apple-data-detectors://3",
			"data:Cupertino, CA 95014",
			"url:x-apple-data-detectors://3",
			"data:408.996.1010",
			"url:tel:408.996.1010",
			"data:Tuesday 31th december, 2019 at 9 PM",
			"url:x-apple-data-detectors://5",
			"data:9 rue de l'Etoile - 31000 Toulouse",
			"url:x-apple-data-detectors://6/0",
			"data:05 61 25 43 65",
			"url:tel:05%2061%2025%2043%2065",
			"data:http://lesvideophages.free.fr",
			"url:http://lesvideophages.free.fr/",
			"data:lesvideophages@free.fr",
			"url:mailto:lesvideophages@free.fr"
			], mailTest_checkDataDetection, "Check data detection for the base languages"));

	// Mobile Me Tests
	var title2 = "Hi from me: " + testSuffix;
	mail.selfTests.push(phtCreateTest("SendEmailWithBccCcUsingMobileMe", ["weliketesting@gmail.com", title2, "Here's the body.", "from:weliketesting@me.com",
		"to:weliketesting@aol.com", "bcc:weliketesting@me.com", "bcc:weliketesting@gmail.com", "validateSent:1"], mailTest_composeAndSendEmail, 
		"Compose and Send Message in mobile me with bcc and cc"));

}())
