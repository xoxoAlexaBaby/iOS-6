#!/bin/sh

echo "Call $1 $2 $3"  >  /var/mobile/CallsStats.txt
echo "Call $1 $2 $3"  >> /var/mobile/MOCalls_Log.txt
