#import "./Camera.js"
#import "../mail/Mail.js"
#import "../libs/PHTesting.js"

//----------------------------------------------------------------------------------------
//	Function: cameraTest_takePicture
//		Go to camera view and push the camera button to take a photo.
//
//	Parameters: 
//		clearCameraRoll (boolean) - should the script start by deleting existing photos?
//
//	Optional Parameters:
//		cameraMode (string) - choose the front or rear facing camera to take the picture
//							"Front" or "Back" are valid.  Defaults to Back 
//		torchMode (string) - choose a flash mode:
//							"On", "Off" or "Automatic"
//		hdrMode (boolean) - turn HDR on or off
//							0: Off
//							1: On
//		
//	Returns: 
//		1 if the test passes, 0 otherwise. 
//----------------------------------------------------------------------------------------
function cameraTest_takePicture() {
	var clearCameraRoll = (this.argv.length > 0) ? (parseInt(this.argv[0]) || this.argv[0] == 'true') : false;
	
	this.testResult = 0;
	
	var optionsArray;
	
	// push options onto optionsArray;
	var optionsArray = new Array();
	for (var i=1; i<this.argv.length; i++) {
		optionsArray.push(this.argv[i]);
	}
	
	var cameraMode = UIAUtility.valuesForKey("cameraMode", optionsArray, 1);
	if (!cameraMode) cameraMode = "Back";
	var torchMode = UIAUtility.valuesForKey("torchMode", optionsArray, 1);
	var hdrMode = parseInt(UIAUtility.valuesForKey("hdrMode", optionsArray, 1));
	
	camera.getToCameraRoll({view:"Photos"});
	
	if (clearCameraRoll) {
		UIALogger.logDebug("Clearing all photos first");
		camera.deleteAllPhotos();
	}
	
	var originalPhotosNumber = camera.numberOfThumbnails();
	UIALogger.logDebug("Number of photos before taking pictures are " + originalPhotosNumber);
	
	camera.getToCamera();
	
	// Let any animations settle down
	UIATarget.localTarget().delay(3);
		
	camera.takePicture(torchMode, cameraMode, hdrMode);
	//THIS IS AN UNREASONABLE DELAY - CHANGE SOON
	UIATarget.localTarget().delay(10);
	
	camera.getToCameraRoll({view:"Photos"});
	var updatedPhotosNumber = camera.numberOfThumbnails();
	
	if (updatedPhotosNumber != originalPhotosNumber+1) {
		this.testError = "Unexpected number of photos in the camera roll after taking picture";
		UIALogger.logError(this.testError + " : " + updatedPhotosNumber);
		return this.testResult = 0;
	}
	
	return this.testResult = 1;
}

//----------------------------------------------------------------------------------------
//	Function: cameraTest_captureVideo 
//		Go to camera view and tap the camera button to record
//		some video and then tap the camera button again to end recording after <length>.
//
//	Parameters: 
//		length (number) - how long should the video be in seconds (default is 5 sec)
//		clearCameraRoll (boolean) - should the script start by deleting existing videos?
//
//	Optional Parameters:
//		cameraMode (string) - choose the front or rear facing camera to take the picture
//							"Front" or "Back" are valid. Defaults to Back 
//		torchMode (string) - choose a flash mode:
//							"On", "Off" or "Automatic"
//
//	Returns: 
//		1 if the test passes, 0 otherwise. 
//----------------------------------------------------------------------------------------
function cameraTest_captureVideo() {
	var length = (this.argv.length > 0) ? parseFloat(this.argv[0]) : 5.0;  // default length is 5 seconds	
	var clearCameraRoll = (this.argv.length > 1) ? (parseInt(this.argv[1]) || this.argv[1] == 'true') : false;
	
	var optionsArray;
	
	// push options onto optionsArray;
	var optionsArray = new Array();
	for (var i=2; i<this.argv.length; i++) {
		optionsArray.push(this.argv[i]);
	}
	
	var torchMode = UIAUtility.valuesForKey("torchMode", optionsArray, 1);
	var cameraMode = UIAUtility.valuesForKey("cameraMode", optionsArray, 1);	
	
    
	if (!camera.supportsVideo()) {
		this.testError = "Camera does not support video capture.";
		return this.testResult = 0;
	}
	
	camera.getToCameraRoll({view:"Videos"});
	
	if (clearCameraRoll) {
		UIALogger.logDebug("Clearing all photos first");
		camera.deleteAllPhotos();
	}
	
	var originalVideosNumber = camera.numberOfThumbnails();
	UIALogger.logDebug("Number of videos before capturing videos are " + originalVideosNumber);
	
	camera.getToCamera();
	
	camera.captureVideo(length, {torchMode:torchMode, cameraMode:cameraMode});
	
	camera.getToCameraRoll({view:"Videos"});
	var updatedVideosNumber = camera.numberOfThumbnails();
	
	if (updatedVideosNumber != originalVideosNumber+1) {
		this.testError = "Unexpected number of videos in the camera roll after recording video";
		UIALogger.logError(this.testError + " : " + updatedVideosNumber);
		return this.testResult = 0;
	}
	
	return this.testResult = 1;
}

//----------------------------------------------------------------------------------------
//	Function: cameraTest_playCapturedVideo
//		Go to camera roll and play the first video in the camera roll
//
//	Parameters: 
//		argv[0] - playbackDuration - optional - duration of playback in seconds. It is set to 
//			3, by default. 
//
//	Returns: 
//		1 if the test passes, 0 otherwise. 
//----------------------------------------------------------------------------------------
function cameraTest_playCapturedVideo() {
	
	this.testResult = 0;
	
	var playbackDuration;
	var currentDuration;
	var videoButtonElement;
	
	if( !this.argv[0] ) {
		// Set default playbackDuration to half of the total play time
		playbackDuration = 3;
	} else {
		playbackDuration = this.argv[0];
	}
	
	// Fail the test if the device does not support video. 
	if (!camera.supportsVideo()) {
		this.testError = "Camera does not support video capture.";
		return this.testResult = 0;
		
	}
	
	camera.getToCameraRoll({view:"Videos"});
	
	if (!camera.checkForPhotosOrVideos()) {
		this.testError = "No videos to play";
		return this.testResult = 0;
	}
	
	// Select the first thumbnail to play
	UIALogger.logDebug("Selecting a video to play");
	camera.selectThumbnailWithOptions();
	
	//TODO: this should somehow be a wait...
//	if (camera.getCurrentView() != camera.views.VIDEO_VIEW) {
	if (!camera.mainContainerView().scrollViews()[0].buttons().firstWithPredicate("name == 'Play video' and isVisible == 1").isValid()) {
		this.testError = "Selected a video thumnail, but video did not come up";
		UIALogger.logError(this.testError);
		return this.testResult = 0;
	}
	
	var videoScrollView = camera.mainContainerView().scrollViews()[0];
	
	var videoScrubber = (UIATarget.localTarget().model() != 'iPad') ? camera.mainContainerView().scrollViews()[0].elements()["Current position"] : camera.mainWindow().navigationBar().elements()["Current position"];

	if (!videoScrubber.isValid()) {
		this.testError = "Could not find Movie Scrubber.";
		UIALogger.logError(this.testError);
		return this.testResult = 0;
	}
	videoScrubber.logElement();
	var originalPosition = videoScrubber.value();
	
	UIALogger.logDebug("Tapping the play button");
	videoScrollView.buttons().firstWithPredicate("name == 'Play video' and isVisible == 1").tap();
	
	UIALogger.logDebug("Tapped the play button, now will let the video play for " + playbackDuration + " seconds");
	UIATarget.localTarget().delay(playbackDuration);
	
	videoScrubber.logElement();
	if (videoScrubber.value() == originalPosition) {
		this.testError = "Scrubber position did not change";
		UIALogger.logError(this.testError);
		return this.testResult = 0;
	}
	
	return this.testResult = 1;
	
	
} // end cameraTest_playCapturedVideo


//----------------------------------------------------------------------------------------
//	Function: cameraTest_deletePhoto 
//		This test deletes a single photo from the camera roll, if 
//		there is one there.  
//
//	Parameters: 
//		randomize (int) - 0 or 1, choose the first photo or a random photo to delete
//
//	Returns: 
//		1 if test passes, 0 if it fails
//
//	Notes:  
//		THIS TEST IS DESTRUCTIVE
//----------------------------------------------------------------------------------------
function cameraTest_deletePhoto() {
	
	this.testResult = 0;

	var randomize = 0;
	if (this.argv.length > 0) randomize = parseInt(this.argv[0], 10);
	
	camera.getToCameraRoll({view:"Photos"});
	
	if (!camera.checkForPhotosOrVideos()) {
		this.testError = "No photos to delete";
		UIALogger.logError(this.testError);
		return this.testResult = 0;
	}
	
	var originalPhotosNumber = camera.numberOfThumbnails();
	UIALogger.logDebug("Number of images before deleting are " + originalPhotosNumber);
	
	camera.selectThumbnailWithOptions({randomize:randomize});
	camera.deletePhoto();
	camera.getToCameraRoll({view:"Photos"});
	
	var updatedPhotosNumber = camera.numberOfThumbnails();
	if (updatedPhotosNumber != originalPhotosNumber-1) {
		this.testError = "Unexpected number of photos found after deleting the photo";
		UIALogger.logError(this.testError + " : " + updatedPhotosNumber);
		return this.testResult = 0;
	}
	
	return this.testResult = 1;
}

//----------------------------------------------------------------------------------------
//	Function: cameraTest_deleteVideo 
//		This test deletes a single Video from the camera roll, if 
//		there is one there. By default this will delete the first 
//
//	Parameters: 
//		randomize (int) - 0 or 1, choose the first photo or a random photo to delete
//
//	Returns: 
//		1 if test passes, 0 if it fails
//
//	Notes:  
//		THIS TEST IS DESTRUCTIVE
//----------------------------------------------------------------------------------------
function cameraTest_deleteVideo() {
	
	this.testResult = 0;

	var randomize = 0;
	if (this.argv.length > 0) randomize = parseInt(this.argv[0], 10);

	camera.getToCameraRoll({view:"Videos"});
	
	if (!camera.checkForPhotosOrVideos()) {
		this.testError = "No videos to delete";
		UIALogger.logError(this.testError);
		return this.testResult = 0;
	}
	
	var originalVideosNumber = camera.numberOfThumbnails();
	UIALogger.logDebug("Number of videos before deleting are " + originalVideosNumber);
	
	camera.selectThumbnailWithOptions({randomize:randomize});
	camera.deletePhoto();
	camera.getToCameraRoll({view:"Videos"});
	
	var updatedVideosNumber = camera.numberOfThumbnails();
	if (updatedVideosNumber != originalVideosNumber-1) {
		this.testError = "Unexpected number of videos found after deleting the photo";
		UIALogger.logError(this.testError + " : " + updatedVideosNumber);
		return this.testResult = 0;
	}
	
	return this.testResult = 1;
}


//----------------------------------------------------------------------------------------
//	Function: cameraTest_deleteAll 
//		This test deletes all photos from the camera 
// 		roll, if there are any there.  
//
//	Parameters: 
//		type (string) - indicates whether to delete "All", "Photos" or "Video."  If nothing
//			is passed in, assumes "Photos"
//
//	Returns: 
//		Test passes if there are no photos on camera roll after the pictures have been 
//		deleted.  If there are no photos on the device, test will fail...
//
//	Note:  
//		THIS TEST IS DESTRUCTIVE
//----------------------------------------------------------------------------------------
function cameraTest_deleteAll() {
	this.testResult = 0;
	var type = (this.argv.length > 0) ? this.argv[0] : "Photos";
	
	camera.getToCameraRoll({view:type});
	
	if (!camera.checkForPhotosOrVideos()) {
		this.testError = "No photos to delete";
		UIALogger.logError(this.testError);
		return this.testResult = 0;
	}
	
	camera.deleteAllPhotos();
	
	if (!camera.checkForPhotosOrVideos()) {
		return this.testResult = 1;
	} else {		
		this.testError = camera.numberOfThumbnails() + " photos remain after deleting all";
		UIALogger.logError(this.testError);
		return this.testResult = 0;
	}
}

//----------------------------------------------------------------------------------------
//	Function: cameraTest_emailPhoto 
//		This test emails a photo from the camera roll 
//
//	Parameters: 
//		to (string) - recipient of the email.
//		subject (string) - subject of the email.
//		shouldValidate (bool) - optional parameter that specifies whether or not to
//			look in the recipient's inbox to see if the email is there
//
//	Returns: 
//		1 if test passes, 0 if it fails and sets testResult appropriately.
//----------------------------------------------------------------------------------------
function cameraTest_emailPhoto()
{
	var email = new Object();
	email.to = (this.argv.length > 0) ? this.argv[0] : "weliketesting@me.com";
	email.subject = (this.argv.length > 1) ? this.argv[1] : "Where's Chuck?";
	var shouldValidate = false;
	if (this.argv.length > 2) {
		shouldValidate = this.argv[2];
		if (shouldValidate == "false") shouldValidate = false;
	}
	
    camera.getToCameraRoll({view:"Photos"});
    if (!camera.checkForPhotosOrVideos()) {
        UIALogger.logMessage("Taking a photo to send");
        camera.getToCamera();
        camera.takePicture();
        camera.getToCameraRoll({view:"Photos"});
    }

	camera.selectThumbnailWithOptions();
	camera.selectPhotoAction("Email Photo");
	
	UIALogger.logMessage("'Email Photo' selected.  Entering recipient and subject.");
	if (!camera.isDisplayingEmailComposeSheet()) {
		this.testError = "Selected email photo, but email compose sheet did not come up";
		UIALogger.logError(this.testError);
		return this.testResult = 0;
	}
	camera.mainWindow().scrollViews()[0].textFields()["toField"].tap(); //maybe put this in compose email?
	camera.composeEmail(email);
	
	UIALogger.logMessage("Sending email with subject '" + email.subject + "'.");
	camera.mainWindow().navigationBar().buttons()["Send"].tap();
	
    //Check for the image scaling actionsheet
    var actionsheet = camera.actionSheet();
    if (actionsheet.isVisible()) {
		UIATarget.localTarget().delay(1); //some delay for animation
		var actionSheetButton = actionsheet.buttons()[0];
  		UIALogger.logDebug("ActionSheet popped up -- selecting '" + actionSheetButton.name() + "'");
        actionSheetButton.tap();
    }
    
	//Check for an image scaling alert
	var alert = camera.alert(); 
	if (alert.isValid()) {
		UIATarget.localTarget().delay(1); //some delay for animation
		var alertButton = alert.buttons()[0];
		UIALogger.logDebug("Alert popped up -- selecting '" + alertButton.name() + "'");
		alertButton.tap();
	}
	
	if (shouldValidate) {
		UIALogger.logDebug("Verifying email with subject '" + email.subject + "' was received");
		
		if(!mail.verifyEmailExists(email.subject, email.to, "Inbox", 120)) {
			this.testError = "The email wasn't received by all recipients";
			return this.testResult = 0;
		} 
		else {
			UIALogger.logMessage("Email was composed and sent");
			return this.testResult = 1;
		}
	}
	
	UIALogger.logDebug("No verification done -- email may or may not have been sent");
	return this.testResult = 1;
}


// --------------------------------------------------------------------------------
//	Function: cameraTest_scrollThroughCameraRoll
//		Scrolls randomly through a the camera roll.  Does not select any pictures, 
//		just scrolls up and down through list of photos or videos.
//
//  Optional Parameters:
//		cameraRollView (string) - "Photos", "Videos", "All".  Defaults to "All"
//
//	Returns: 
//		1 if test passes, 0 if test fails. 
// --------------------------------------------------------------------------------
function cameraTest_scrollThroughCameraRoll() {
		
	var cameraRollView = "All";
	
	if (this.argv.length > 0 && (this.argv[0] != null && this.argv[0] != "null")) cameraRollView = this.argv[0];
	
	camera.launchIfNotActive();

	camera.getToCameraRoll({view:cameraRollView});

	// Check to see if there are indeed photos on the device
	if (!camera.checkForPhotosOrVideos()) {
		camera.mainWindow().logElementTree();
		this.testError = "No photos or videos on the device";
		return this.testResult = 0;
	}
	
	// Delay for animations
	UIATarget.localTarget().delay(2);
	
	var rowCount = camera.mainWindow().tableViews()[0].cells().length;
	UIALogger.logDebug("Number of rows: " + rowCount);
	if (rowCount < 6) {
		this.testError = "Not enough rows validate a scroll";
		return this.testResult = 0;
	}
		
	camera.scrollPhotoCollection();
	
	return this.testResult = 1;
	
} // end photosTest_scrollThroughCameraRoll

// Create self tests -- this is an unnamed function, just to make sure any local variables stay in the correct context
(function() {	
	if (typeof camera != 'undefined') {
		if (typeof camera.selfTests == 'undefined') {
			camera.selfTests = new Array();
		}
		camera.selfTests.push(phtCreateTest("TakePicture", null, cameraTest_takePicture, "Take a Picture, no verification"));
		camera.selfTests.push(phtCreateTest("ScrollThroughCameraRoll", null, cameraTest_scrollThroughCameraRoll, "Scroll Through Camera Roll"));
		if (system.hasCapability('video-camera')) {
			camera.selfTests.push(phtCreateTest("CaptureVideo", [5, true], cameraTest_captureVideo, "Capture a video"));
			camera.selfTests.push(phtCreateTest("PlayCapturedVideo", [3], cameraTest_playCapturedVideo, "Play Captured video"));
		}	
		var date = new Date();
		var title = "Self Test Camera Email: " + date.getHours() + date.getMinutes() + date.getSeconds();
		//SELF_TEST_ARRAY.push(phtCreateTest("EmailCameraPhoto", ["weliketesting@me.com", title, true], cameraTest_emailPhoto, "Send an image from Camera through mail"));
		camera.selfTests.push(phtCreateTest("DeleteAllPhotos", ["Photos"], cameraTest_deleteAll, "Delete all Photos"));
		camera.selfTests.push(phtCreateTest("TakePicture", null, cameraTest_takePicture, "Take second picture"));
		camera.selfTests.push(phtCreateTest("DeletePhoto", null, cameraTest_deletePhoto, "Delete a Photo"));
	}
}())
