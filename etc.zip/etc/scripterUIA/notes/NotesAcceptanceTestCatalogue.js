//Notes Acceptance Test Catalogue.


if (typeof notes.acceptanceTests == 'undefined') {
	notes.acceptanceTests = new Array();
}
notes.acceptanceTests.push(phtCreateTest("Notes_CreateNote", ["UnitTest Note 1", "Hi!  I like being a note.  How about you?"], notesTest_createNote, "Create a Note"));
	notes.acceptanceTests.push(phtCreateTest("Notes_SelectPreviousNextNote", null, notesTest_selectPreviousNextNote, "Switch Between Notes"));

	var date = new Date();
	var timestamp = "" + date.getHours() + date.getMinutes() + date.getSeconds();
	notes.acceptanceTests.push(phtCreateTest("Notes_CopyNote", ["Note to copy " + timestamp, "Hi!  I like being copied.  How about you?"], notesTest_copyNote, "Copy text from one note and paste it into another."));

	notes.acceptanceTests.push(phtCreateTest("Notes_PasteIntoNote", ["I like being copied"], notesTest_pasteIntoNote, "Paste text from the pasteboard into a new note."));
	notes.acceptanceTests.push(phtCreateTest("Notes_DeleteNote", ["UnitTest Note 1", "Hi!  I like being a note.  How about you?"], notesTest_deleteNote, "Delete a Note"));
	notes.acceptanceTests.push(phtCreateTest("Notes_EmailNote", ["weliketesting@me.com", "UnitTest Note " + timestamp, "Hi!, I like being a note.  How about you? " + timestamp, true], notesTest_emailNote, "Email a Note"));
	notes.selfTests.push(phtCreateTest("UndoAction", ["type", "textToType:Someday I will run away to the circus", "shouldRedo:true"], notesTest_undoAction, "Undo typing"));

	//Debugging to see numbner of tests added.
	//UIALogger.logDebug("YES we really did add tests notes.acceptanceTests.length = " + notes.acceptanceTests.length);


