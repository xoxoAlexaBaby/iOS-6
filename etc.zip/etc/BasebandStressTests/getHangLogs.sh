#!/bin/bash

DEVICENAME=`hostname`
myDate=`perl -e '($s,$m,$H,$d,$M) = localtime(); $Y += 1900; $M++; printf ("%02d%02d-%02d%02d",$M,$d,$H,$m); ' `

FILE="/var/root/log-hang-$DEVICENAME-$myDate.txt"

rm /tmp/CommCenter* /tmp/SpringBoard*
APBuild=`/usr/local/bin/lockdown_query get NULL BuildVersion 2>&1`
BB_Build=`/usr/local/bin/lockdown_query get NULL BasebandVersion 2>&1`

echo "Sampling CommCenter and SpringBoard..."
sample CommCenter
sleep 1
echo
sample SpringBoard
sleep 1
echo
cp /tmp/CommCenter* /tmp/SpringBoard* /Library/Logs/CrashReporter/

PIDS=`ps -A | grep CommCenter | perl -lne 'chomp; if ( !/grep/  ) { $p = (split)[0]; $p =~ s/\s*//g; print $p;} ' `;
simulatecrash -k $PIDS

echo "\nAP_BUILD = $APBuild; BASEBAND BUILD = $BB_Build;\n"  >> $FILE
echo "\nAP_BUILD = $APBuild; BASEBAND BUILD = $BB_Build;\n" 
echo "Saving Baseband Logs..."
killall -USR2 CommCenter


echo "\n***************************************************************** " >> $FILE
echo "		   LIST OF CURRENT PROCESS RUNNING ON THE DEVICE			" >> $FILE
echo "***************************************************************** " >> $FILE
echo "Getting All Process list..."
ps -A >> $FILE 

echo "\n***************************************************************** " >> $FILE
echo "		  			 OUTPUT OF CONSOLE LOGS							" >> $FILE
echo "***************************************************************** " >> $FILE
echo "Getting Syslog..."
syslog >> /Library/Logs/CrashReporter/SYSLOG-$DEVICENAME-$myDate.txt
cat /Library/Logs/CrashReporter/SYSLOG-$DEVICENAME-$myDate.txt >> $FILE 

echo "\n***************************************************************** " >> $FILE
echo "		  				 OUTPUT OF TOP								" >> $FILE
echo "***************************************************************** " >> $FILE
echo "Getting Top output..."
top -o -cpu -l 10 -s 2 >> $FILE 

echo "\n***************************************************************** " >> $FILE
echo "		  				OUTPUT OF SAMPLES							" >> $FILE
echo "***************************************************************** " >> $FILE
echo "Copying logs..."
cat /tmp/CommCenter* /tmp/SpringBoard* >> $FILE

echo "***************************************************************** " >> $FILE
sleep 2
cp $FILE  /Library/Logs/CrashReporter/
echo "\n\n DONE WITH ALL LOGGING " >> $FILE
echo "DONE."
