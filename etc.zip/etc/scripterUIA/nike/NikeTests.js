#import "./Nike.js"
#import "../libs/PHTesting.js"


//----------------------------------------------------------------------------------------
//	Function: nikeTest_startWorkout 
//			Start a specific workout.  All options are optional - a default "Basic" workout
//			with no music and a weight of "150.0 lbs"
//
//	Optional Parameters:
//		workoutType (string) - the workout category (Default, Time, Distance or Calories)
//		workoutGoal (string) - the specific workout within that category (Currently, custom workouts 
//						are not supported)
//		workoutMusic (string) - music to play (playlistname, shuffle or none)
//		weight (string) - if promted, weight of the runner
//
//	Returns: 
//		1 if we can verify that the workout was started and 0 if not
//----------------------------------------------------------------------------------------
function nikeTest_startWorkout() {
	
	var workoutType = "Basic";
	if (this.argv[0]) {
		workoutType = this.argv[0];
	}
	
	var workoutGoal = "None";
	if (this.argv[1]) {
		workoutGoal = this.argv[1];
	}
	
	var workoutMusic = "None";
	if (this.argv[2]) {
		workoutMusic = this.argv[2];
	}
	
	var weight = "150.0 lbs";
	if (this.argv[3]) {
		weight = this.argv[3];
	}
	
	// Launch the Nike+ application if it is not active
	nike.launchIfNotActive();
	
	// Try to start the workout with the supplied arguments
	try {
		nike.startWorkout(workoutType, workoutGoal, {workoutPlaylist:workoutMusic,weight:weight});
	} catch(e) {
		UIALogger.logMessage(e.message);
		this.testError = "Could not successfully start a workout";
		return this.testResult = 0;
	}

	return this.testResult = 1;

} // end nikeTest_startWorkout() 




//----------------------------------------------------------------------------------------
//	Function: nikeTest_endWorkout 
//			End the current workout
//
//	Parameters: 
//		None
//
//	Returns: 
//		1 if we can verify that the workout was started and 0 if not
//----------------------------------------------------------------------------------------
function nikeTest_endWorkout() {
		
	try {
		nike.endWorkout();
	} catch(e) {
		UIALogger.logMessage(e.message);
		this.testError = "Did not end the current workout";
		return this.testResult = 0;
	}

	try {
		var summary = nike.asApplication().latestWorkoutSummary();
		if (!summary) throw new Error("Failed to retrieve the latest workout summary from latestWorkoutSummary()");
		
		for (var summaryKey in summary) {
			UIALogger.logMessage(summaryKey + " = " + summary[summaryKey]);
		}			
	} catch(e) {
		UIALogger.logMessage(e.message);
		this.testError = "Failed to retrieve latest workout summary";
		return this.testResult = 0;
	}
	
	return this.testResult = 1;

} // end nike_stopWorkout




//----------------------------------------------------------------------------------------
//	Function: nikeTest_workoutUntilGoalIsReached 
//			Start a workout and wait until the specified goal is reached.  A "Basic" workout
//			is not a valid workout for this test.  No parameters are required and defaults
//			will be provided if none are specified 
//
//	Parameters: 
//		workoutType (string) - The type of workout (Distance, Time or Calorie) 
//		workoutGoal (string) - The goal for the workout
//		workoutMusic (string) - the music to play during the workout
//		weight (string) - use this value if prompted for the user's weight
//	 	notificationTimeout (string) - this is an upper bound on how long to wait for the 
//										goal to complete. If no value is specified,
//										an upper bound will be calculated based on the 
//										current workout.  If not specifying a timeout,
//										please allow the test to run for a minimum of 5 minutes
//
//	Returns: 
//		1 if we can verify that the workout was started and 0 if not
//----------------------------------------------------------------------------------------
function nikeTest_workoutUntilGoalIsReached() {
		
	var workoutType = "Distance";
	if (this.argv.length > 0) {
		workoutType = this.argv[0];
	}
	
	if (workoutType == "Basic") {
		this.testError = "Basic workout selected - this is not a valid option";
		return this.testResult = 0;
	}
	
	var workoutGoal = "2 mile workout";
	if (this.argv.length > 1) {
		workoutGoal = this.argv[1];
	}
	
	
	var workoutMusic = "None";
	if (this.argv.length > 2) {
		workoutMusic = this.argv[2];
	}
		
	var weight = "150.0 lbs";
	if (this.argv.length > 3) {
		weight = this.argv[3];
	}
	
	
	var notificationTimeout;
	if (this.argv[4]) {
		notificationTimeout = parseInt(this.argv[4]);
	}
	
	// Launch the Nike+ application if it is not active
	nike.launchIfNotActive();
	
	// Try to start the workout with the supplied arguments
	try {
		nike.startWorkout(workoutType, workoutGoal, {workoutPlaylist:workoutMusic,weight:weight});
	} catch(e) {
		UIALogger.logMessage(e.message);
		this.testError = "Could not successfully start a workout";
		return this.testResult = 0;
	}

	// If a timeout has not been specified, calculate the timeout based on the current workout
	if (!notificationTimeout) notificationTimeout = nike.determineTimeoutValue(workoutType, workoutGoal);
	
	// Wait for the notification that the goal has been reached
	try {
		nike.waitForWorkoutNotification("STSportsWorkoutGoalCompletedNotification", notificationTimeout);
	} catch(e) {
		UIALogger.logMessage(e.message);
		this.testError = "Did not receive the STSportsWorkoutGoalCompletedNotification notification after " + notificationTimeout + " seconds";
		return this.testResult = 0;
	}
	
	try {
		nike.endWorkout();
	} catch(e) {
		UIALogger.logMessage(e.message);
		UIALogger.logMessage("The notification was received, but we could not end the workout and return to the main workout selection");
	}
	
	try {
		var summary = nike.asApplication().latestWorkoutSummary();
		if (!summary) throw new Error("Failed to retrieve the latest workout summary from latestWorkoutSummary()");
		
//		for (var summaryKey in summary) {
//			UIALogger.logMessage(summaryKey + " = " + summary[summaryKey]);
//		}			
	} catch(e) {
		UIALogger.logMessage(e.message);
		this.testError = "Failed to retrieve latest workout summary";
		return this.testResult = 0;
	}
	
	
	return this.testResult = 1;

} // nikeTest_workoutUntilGoalReached


// Create self tests -- this is an unnamed function, just to make sure any local variables stay in the correct context
(function() {	
	if ((typeof nike != 'undefined') && system.hasCapability("nike-ipod") && springboard.displaysApp(nike)) {
 

		nike.selfTests = new Array();
		
		nike.selfTests.push(phtCreateTest("StartCustom5minuteWorkout", ["Time", "5 minutes"], nikeTest_workoutUntilGoalIsReached, "Starting a Custom 1 minute workout with music 'None'"));
		nike.selfTests.push(phtCreateTest("WaitForCustom15minuteWorkout", ["Time", "15 minutes"], nikeTest_workoutUntilGoalIsReached, "Starting Custom 15 minute workout with music 'None'"));
	 
		nike.selfTests.push(phtCreateTest("StartAndWaitForA45minuteWorkout", ["Time", "45 minutes", "Shuffle Songs"], nikeTest_workoutUntilGoalIsReached, "Starting '45 minutes' workout with music 'Shuffle Songs'"));
		nike.selfTests.push(phtCreateTest("StartAndWaitForACustom15minuteWorkout", ["Time", "15 minutes", "None"], nikeTest_workoutUntilGoalIsReached, "Starting Custom 15 minute workout with music 'None'"));
	 
		nike.selfTests.push(phtCreateTest("StartAndWaitForA3kWorkout", ["Distance", "3K workout", "Shuffle Songs"], nikeTest_workoutUntilGoalIsReached, "Starting '3k workout' with music 'Shuffle Songs'"));
		nike.selfTests.push(phtCreateTest("StartAndWaitForACustom2.0kmWorkout", ["Distance", "2.00 km"], nikeTest_workoutUntilGoalIsReached, "Starting Custom 2km workout with music 'None'"));
		nike.selfTests.push(phtCreateTest("StartAndWaitForA100CaloriesWorkout", ["Calorie", "100 calories", "Shuffle Songs"], nikeTest_workoutUntilGoalIsReached, "Wait for a '100 calories' workout with music 'Shuffle Songs' to complete"));
		nike.selfTests.push(phtCreateTest("StartAndWaitForACustom75CaloriesWorkout", ["Calorie", "75 calories", "None"], nikeTest_workoutUntilGoalIsReached, "Wait for a 10 calorie workout with music 'None' to complete"));
	} 
}())
