#SCRIPTS_DIR="/var/root/IPCStressTestScripts/"
SCRIPTS_DIR="/usr/local/etc/BasebandStressTests/"
$SCRIPTS_DIR/setupCommands.sh
/usr/local/bin/DoOnBBReset "sleep 5; $SCRIPTS_DIR/setupCommands.sh"
