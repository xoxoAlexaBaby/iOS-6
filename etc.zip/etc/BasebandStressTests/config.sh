#!/bin/sh


SCRIPTS_DIR="/usr/local/etc/BasebandStressTests/"


# PATHS
TOOLS_DIR="/usr/local/bin"
SEND_AT_COMMAND=`which SendATCommand`
CT_GET_RESET_STATE=`which CTGetResetState`
TESTCT=`which testCT`
LOCKDOWN_QUERY=`which lockdown_query`
CT_MONITOR=`which CoreTelephonyMonitor`
STREAMPERF=`which StreamPerf`
LOCMON=`which locmon`
RUN_SC=`which SleepCycler`

LOOP_BACK="4089619342"


# DEVICE INFO
APBUILD=`${LOCKDOWN_QUERY} get NULL BuildVersion 2>&1`
DEVICENAME=`hostname`
UDID=`${LOCKDOWN_QUERY} get NULL UniqueDeviceID 2>&1`
HARDWARE=`${LOCKDOWN_QUERY} get NULL HardwareModel 2>&1 | cut -c1-3`
IMEI=`${LOCKDOWN_QUERY} get NULL InternationalMobileEquipmentIdentity 2>&1`
MEID=`${LOCKDOWN_QUERY} get NULL MobileEquipmentIdentifier 2>&1`
SNUM=`${LOCKDOWN_QUERY} get NULL BasebandSerialNumber 2>&1 | perl -lne 's/^(.*)(bytes = )(.*)$/$1$2$3/; $chip = $3; $chip =~ s/\}|\]//g; print $chip;'`
SERIAL=`${LOCKDOWN_QUERY} get NULL SerialNumber 2>&1`
PHONE_NUMBER=`${LOCKDOWN_QUERY} get NULL PhoneNumber 2>&1`
BB=`${LOCKDOWN_QUERY} get NULL BasebandVersion 2>&1`


# OTHERS
DLCI_DEV_NODE="/dev/dlci.spi-baseband.extra_0"

lockdown_query get NULL MobileEquipmentIdentifier
lockdown_query get NULL SerialNumber


echo "Device Name: $DEVICENAME"
echo "Phone Number: $PHONE_NUMBER"
echo "AP: $APBUILD"
echo "Baseband: $BB"
echo "UDID: $UDID"
echo "SERIAL: $SERIAL"
echo "IMEI: $IMEI"
echo "MEID: $MEID"
echo "BB SNUM: $SNUM"
