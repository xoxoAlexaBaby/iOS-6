/*
 Class: UIApp (facetime)
 Contacts object
 */

#import "../libs/SpringBoard.js"
#import "../libs/UIAAppContactsAdditions.js"

if (system.hasCapability("venice")) {
	if (UIATarget.localTarget().model() == "iPhone") {
		facetime = UIAApp.application("Phone", "com.apple.mobilephone");
	} else {
		facetime = UIAApp.application("FaceTime", "com.apple.mobilephone");
	}
	if (typeof telephony == 'undefined') telephony = new Telephony();
};

if (typeof facetime != 'undefined') {
		
	// --------------------------------------------------------------------------------
	//	Function: signIn 
	//		Signs into a FaceTime account in the FaceTime app (if an account is not 
	//		already set up) 
	//
	//	Parameters: 
	//		options (object) - a dictionary of optional paramters
	//
	//	Optional Parameters:
	//		appleIDUsername (string) - the Apple ID username 
	//		appleIDPassword (string) - the Apple ID password
	//		emailAddress (string) - the email address that will be used by other devices 
	//			to contact the device. If no value is specified, the value in the text 
	//			field is not changed. 
	//
	//	Returns: 
	//		None
	//
	//	Throws: 
	//		Error
	// --------------------------------------------------------------------------------
	facetime.signIn = function signIn(options) {
		
		var username = (options.appleIDUsername != undefined)? options.appleIDUsername : springboard.iTunesUsername;
		var password = (options.appleIDPassword != undefined)? options.appleIDPassword : springboard.iTunesPassword;
		
		if (UIATarget.localTarget().model() != 'iPad') {
			var getStartedButton = facetime.mainWindow().buttons()["Get Started"];
			if (!getStartedButton.isValid()) {
				UIALogger.logDebug("Did not find the 'Get Started' button -- the account is probably already setup");
				return ;
			}
			getStartedButton.tap();
			if (!getStartedButton.withValueForKey(0, "isVisible").isValid()) UIALogger.logWarning("Get Started button did not become invisible");
			UIATarget.localTarget().delay(1); //animation 
		} 
		var table = this.mainWindow().tableViews()[0];
		

		var signInButton = table.cells()["Sign In"]; //iPad has no button inside the cell.
		var usernameTextField = this.mainWindow().tableViews()[0].cells()[0].textFields()[0];
		var passwordSecureTextField = this.mainWindow().tableViews()[0].cells()[1].secureTextFields()[0];
		
		if (!signInButton.isValid()) throw new Error("The sign in view did not come up");
		
		UIALogger.logDebug("Entering Apple ID credentials");
		this.enterTextInTextField(usernameTextField, username);
		this.enterTextInTextField(passwordSecureTextField, password);
		signInButton.tap();
		
		if (!this.waitForActivityIndicatorToFinish(60)) throw new Error("'Signing In...' did not go away after tapping 'Sign In'");
		

		var addressTextField = this.mainWindow().tableViews()[0].cells()['Address'].textFields()['Address'];
		if (!addressTextField.isValid()) throw new Error("'Address' text field did not come up");
		
		if (options.emailAddress) {
			this.enterTextInTextField(addressTextField, options.emailAddress);
		} else {
			UIALogger.logDebug("Using " + addressTextField.value() + " as the email address");
		}
		this.navigationBar().buttons()["Next"].tap();
		if (!this.waitForActivityIndicatorToFinish(60)) throw new Error("'Verifying...' did not go away after tapping 'Next'");
		
		if (this.tabBar().withValueForKey(1, "isVisible").isValid()) {
			return ;
		} else {
			UIALogger.logWarning("Tab bar did not come up after verification");
		}
		
		//some error checking 
		if (this.mainWindow().tableViews()[0].cells()["Check Mail"].isValid())
			throw new Error("Unable to verify email address");
		else 
			throw new Error("Tab bar did not come up after verification");
	}
	
	// --------------------------------------------------------------------------------
	//	Function: isFaceTimeCallActive 
	//		Returns true if a facetime call is active
	//
	//	Parameters: 
	//		None
	//
	//	Returns: 
	//		True, if a face time call is active
	//
	//	Throws: 
	//		Error
	// --------------------------------------------------------------------------------
	facetime.isFaceTimeCallActive = function isFaceTimeCallActive() {
		//workaround for <rdar://problem/9608545>
		return this.mainWindow().elements().firstWithPredicate("isVisible == 1 and name == 'End call'").isValid();
		//return (telephony.callExists({type:"VideoConference"}));
	}
	

	// --------------------------------------------------------------------------------
	//	Function: waitForVideo 
	//		Waits for the video of a video call to come up
	//
	//	Parameters: 
	//		timeout (int) - the number of seconds to wait for the video to come up. The 
	//			default value is set to 120
	//
	//	Returns: 
	//		True, if the video came up; false otherwise.
	//
	//	Throws: 
	//		Error
	// --------------------------------------------------------------------------------
	facetime.waitForVideo = function waitForVideo(timeout) {
		var date = new Date();
		if (!timeout) timeout = 120;
		
		UIALogger.logDebug("Looking for connecting text..");
		UIATarget.localTarget().pushTimeout(30);
		var connectingText = this.mainWindow().elements().firstWithPredicate("isVisible == 1 and (name contains 'connecting' or name contains 'Connecting')");
		UIATarget.localTarget().popTimeout();
		
		if (connectingText.isValid()) {
			UIALogger.logDebug("Found connecting text");
			connectingText.logElement();
		} else {
			UIALogger.logWarning("Did not find connecting text");
		}
		
		UIALogger.logDebug("Waiting for video element now...");
		var noOfTimes = Math.ceil(timeout/5);
		for (var i=0; i<noOfTimes; i++) {
			//first check for an alert
			var alert = springboard.alertSinceDate(date);
			if (alert) {
				throw new Error("Got an alert");
			}
			
			//check for the end call button
			if (this.isFaceTimeCallActive()) break;
			
			UIATarget.localTarget().pushTimeout(0);
			var facetimeFailed = this.mainWindow().elements().firstWithPredicate("name contains 'FaceTime failed'");
			UIATarget.localTarget().popTimeout();
			if (facetimeFailed.isValid())
				throw new Error("Got a facetime failed error");
			UIALogger.logDebug("Still waiting for video after " + (i)*UIATarget.localTarget().timeout() + " seconds...");
			UIATarget.localTarget().delay(5);
		}
		
		if (connectingText.isVisible()) 
			UIALogger.logWarning("Connecting text is still visible");
		
		if (!this.isFaceTimeCallActive()) {
			UIALogger.logError("Video element did not show up");
			return false;
		}
		
		return true;
	}
	
	// --------------------------------------------------------------------------------
	//	Function: endVideoCall 
	//		Ends a video call. Expect one to be active.
	//
	//	Parameters: 
	//		None
	//
	//	Returns: 
	//		None
	//
	//	Throws: 
	//		Error
	// --------------------------------------------------------------------------------
	facetime.endVideoCall = function endVideoCall() {
		UIALogger.logMessage("Looking for end call button...");
		/*
		var endCallButton = this.mainWindow().elements().firstWithPredicate("isVisible == 1 and name == 'End call'");
		if (!endCallButton.isValid()) 
			throw new Error("Could not find the 'End Call' button");
		endCallButton.tap();
		 */
		//workaround for <rdar://problem/8426544>
		//START WORKAROUND
		if (!this.isFaceTimeCallActive()) throw new Error("No active calls to end");
		var endCallButtons = this.mainWindow().elements().withName('End call');
		var endCallButton = endCallButtons[endCallButtons.length-1]; //<rdar://problem/8842013>
		UIATarget.localTarget().tap(endCallButton.rect());
		//END WORKAROUND
		
		var calledEnded = endCallButton.withPredicate("isVisible == 0").isValid();
		if (!calledEnded) throw new Error("'End Call' button did not go away");
	}
	
	// --------------------------------------------------------------------------------
	//	Function: getVideoCallFailureData 
	//		Gets video call failure data
	//
	//	Parameters: 
	//		options (dictionary) - a dictionary of optional arguments
	//		takeScreenshot (boolean) - if set to true, will take a screenshot
	//		screenshotName (string) - the name of the screenshot image file (can also 
	//			include the path to it). If no value is specified, the screenshot is 
	//			saved as "/var/mobile/Library/Logs/CrashReporter/VCFailure<date string>"
	//		runCommands (array of strings) - additional system.run commands to gather 
	//			more data
	//
	//	Returns: 
	//		An object containing:
	//			failureText (string) - the error string if it is found
	//			screenshotName (string) - the name of the screenshot, if one is captured
	//
	//	Throws: 
	//		Error
	// --------------------------------------------------------------------------------
	facetime.getVideoCallFailureData = function getVideoCallFailureData(options) {
		if (!options) options = new Options();
		var failureData = new Object();
		
		var date = new Date();
		var dateString = "" + date.getHours() + date.getMinutes() + date.getSeconds(); // the quotes make this into a string.
		
		UIALogger.logDebug("Gathering failure data...");
		UIATarget.localTarget().frontMostApp().logElementTree();
		
		var failureText = "Unknown VC failure occurred at " + dateString;
		UIATarget.localTarget().pushTimeout(0);
		var alert = (options.alertDate) ? springboard.alertSinceDate(options.alertDate) : null;
		var connectingElement = this.mainWindow().elements().firstWithPredicate("isVisible == 1 and name contains 'connecting'");
		var facetimeFailedElement = this.mainWindow().elements().firstWithPredicate("isVisible == 1 and name contains 'FaceTime failed'");			
		UIATarget.localTarget().popTimeout();
		if (alert)
			failureText = "Error at " + dateString + " : " + alert.alertMessageArray.join(' - ');
		else if (facetimeFailedElement.isValid())
			failureText = "Error at " + dateString + " : " + facetimeFailedElement.name();
		else if (connectingElement.isValid())
			failureText = "Still connecting at " + dateString;
		failureData.failureText = failureText;
		
		if (options.takeScreenshot == true) {
			UIALogger.logDebug("Taking screen shot now...");
			var screenshotName = "/var/mobile/Library/Logs/CrashReporter/VCFailure"+dateString;
			if (options.screenshotName) screenshotName = options.screenshotName;
			failureData.screenshotName = UIATarget.localTarget().captureScreenWithName(screenshotName);
		}
		
		if (options.runCommands) {
			for (var i=0; i<options.runCommands.length; i++) 
				UIAUtility.logToolOutput(options.runCommands[i],60);
		}
		return failureData;
	}

	// --------------------------------------------------------------------------------
	//	Function: dismissCallFailureView 
	//		Dismisses the 'FaceTime failed' sheet by selecting the 'Cancel' button 
	//
	//	Parameters: 
	//		None
	//
	//	Returns: 
	//		None
	//
	//	Throws: 
	//		Error
	// --------------------------------------------------------------------------------
	facetime.dismissCallFailureView = function dismissCallFailureView() {
		UIATarget.localTarget().pushTimeout(0);
		var isOnCallFailedScreen = this.mainWindow().buttons()["Call Back"].isVisible();
		UIATarget.localTarget().popTimeout();
		if (isOnCallFailedScreen) {
			UIALogger.logWarning("On call failed screen. Need to tap 'Cancel'");
			this.mainWindow().buttons()["Cancel"].tap();
		}
	}
	
	//----------------------------------------------------------------------------------------
	//	Function: makeVideoCallToContact
	//		Makes a video call to the given contact.
	//
	//	Parameters: 
	//		contactName (string) - Name of the person to call
	//		options (Object) - a dictionary of optional parameters
	//
	//	Optional parameters:
	//		groupName (string) - the name of the group where the contact is stored. If no 
	//			value is provided, "All Contacts" is assumed. 
	//		numberOrAddress (string) - if multiple email addresses or phone numbers are 
	//			associated with the contact, this parameter specifies which one to use. If no 
	//			value is specified, the first value is chosen by default. Note that the phone number 
	//			should be exactly formatted as it appears in the info card. 
	//		
	// 
	//	Returns:
	//		None
	//----------------------------------------------------------------------------------------
	facetime.makeVideoCallToContact = function makeVideoCallToContact(contactName, options) {
		if (!options) options = new Object();
		var groupName = options.groupName;
		if (!groupName) groupName = "All Contacts";
		
		var numberOrAddress = options.numberOrAddress;
		
		if (!this.navigationBar().withName("Info").isValid() ||
			!this.mainWindow().tableViews()[0].staticTexts()[contactName].isValid()) {
			UIALogger.logDebug("Not at the card right now, proceeding with the setup");
			
			this.getToContactsList();
			this.chooseGroup(groupName);
			
			var contactElement = this.searchForContact(contactName);
			if (!contactElement.isValid()) { 
				throw new Error("Contact " + contactName + " not found");
			}
			contactElement.tap();
		}
		
		UIALogger.logDebug("Found the right card, moving on.");
		
		if (!this.navigationBar().withName("Info").isValid()) {
			UIALogger.logWarning("the info nav bar did not show up");
		}
		UIATarget.localTarget().delay(1);
		
		if (UIATarget.localTarget().model() == 'iPhone') {
			//there is a this button
			UIATarget.localTarget().pushTimeout(0);
			var videoCallButton = this.cellsContainingElementsWithPredicate(this.mainWindow().tableViews()[0], "name contains 'FaceTime'")[0].buttons()["FaceTime"];
			UIATarget.localTarget().popTimeout();
			if (!videoCallButton.isValid()) { 
				this.getToContactsList();
				throw new Error("FaceTime button not found.");
			}
			UIALogger.logDebug("Found the button.");
			
			var alertDate = new Date(); //date object for alert checking purposes
			
			videoCallButton.scrollToVisible();
			videoCallButton.tap();
			
			var actionSheet = this.actionSheet();
			if (actionSheet.isValid()) {
				UIALogger.logDebug("Found an action sheet");
				if (numberOrAddress) {
					var actionSheetButton = actionSheet.buttons().firstWithPredicate("name contains '" + numberOrAddress + "'");
					if (!actionSheetButton.isValid()) {
						throw new Error("Specified number type did not show up in the action sheet");
					}
				} else {
					var actionSheetButton = actionSheet.buttons()[0];
				}
				UIATarget.localTarget().delay(1);
				actionSheetButton.logElement();
				actionSheetButton.tap();
			}
		} else {
			//no FaceTime button
			var infoTableCells = this.mainWindow().tableViews()[0].cells();
			if (numberOrAddress) {
				var numberCell = infoTableCells.firstWithValueForKey(numberOrAddress, "value");
			} else {
				//do our best here...
				var numberCell = infoTableCells[0];
			}
			numberCell.logElement();
			numberCell.scrollToVisible();
			UIATarget.localTarget().delay(1); //animation
			try {
				numberCell.tap();
			} catch(e) {
				//some debug info for <rdar://problem/9742623> Script Failed to Start FaceTime Call
				if (numberCell.checkIsValid()) {
					UIALogger.logDebug("number cell is valid");
				} else {
					UIALogger.logDebug("number cell is not valid");
				}
				if (numberCell.isVisible()) {
					UIALogger.logDebug("number cell is visible");
				} else {
					UIALogger.logDebug("number cell is not visible");
				}
				if (numberCell.hitpoint() != null) {
					UIALogger.logDebug("number cell has a valid hitpoint");
				} else {
					UIALogger.logDebug("number cell does not have a valid hitpoint")
				}
				this.logElementTree();
				throw e;
			}
		}
		
	}
	
}
