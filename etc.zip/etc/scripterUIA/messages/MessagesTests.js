#import "./Messages.js"
#import "../libs/PHTesting.js"

// --------------------------------------------------------------------------------
//	Function: messagesTest_sendReceiveTextMessage 
//		Sends the SMS message to the phone number specified and waits for the
//		appropriate SMS to be received. Depending on the parameters, it may retry
//		if the first message is not received within the given timeout.
//
//	Parameters:
//		textToSend (string) - SMS to be sent
//	
//  Optional Parameters:
//		messageToReceive (string) - SMS that we are expecting to receive.  If we're
//			expecting the same thing that we sent, this doesn't need to get filled out.
//			this is useful if autocorrection is expected to kick in. 
//		phoneNumber (string) - Phone number to send the SMS to.  If no phone number
//			is specified, the SMS will be sent to the phone itself.  
//		timeout (integer) - Number of seconds to wait for SMS to send/receive.
//		minPercentForPass (number) - Expected percentage of "pass" tests 0-1 - If this is set, we run the first
//			test.  If the first test fails, we run <retry> more tests, and try to get the 
//			expected percentage of passed tests out of those <retry> tests.  (optional)
//		numberOfAdditionalTextMessagesToSend (number) - Retry number.  If "percentage" is set and the first test fails, this
//			is the number of additional tests we try to run.  Default is 10.  (optional)
//		noVerification (bool) - if this is set to true, don't do any verification to check
//			for an incoming SMS or MMS.  (default is false--verification will be done.)
//
//	Returns:
//		1 if SMS is successfully sent and received, 0 if not.
//
//  Usage:
//		messagesTest_sendReceiveTextMessage "Hi."  "timeout:100" "phoneNumber:14089619343" "phoneNumber:5555555555" "
// --------------------------------------------------------------------------------
function messagesTest_sendReceiveTextMessage() 
{
	this.testResult = 0;
	
	// Message To Send
	if (this.argv.length < 0) {
		this.testError = "Must have at least one argument"
		return 0;
	}	
	var textToSend = this.argv[0];
	
	// Push options onto optionsArray;
	var optionsArray = new Array();
	for (var i=1; i<this.argv.length; i++) {
		optionsArray.push(this.argv[i]);
	}
	var options = new Object();
	options.message = UIAUtility.valuesForKey("messageToReceive", optionsArray, 1);  
	options.phoneNumber = UIAUtility.valuesForKey("phoneNumber", optionsArray);
	options.timeout = UIAUtility.valuesForKey("timeout", optionsArray, 1);
	minPercentForPass = UIAUtility.valuesForKey("minPercentForPass", optionsArray, 1);
	numberOfAdditionalTextMessagesToSend = UIAUtility.valuesForKey("numberOfAdditionalTextMessagesToSend", optionsArray, 1);
	options.noVerification = UIAUtility.valuesForKey("noVerification", this.argv, 1);
	
	if (!options.message) options.message = textToSend;
	if (!options.phoneNumber) phoneNumber=telephony.myPhoneNumber;
	if (!options.timeout) options.timeout = 120; // wait up to 2 minutes for a message to come in.
	
	// Send the text message
	messages.sendTextMessage(textToSend, options.phoneNumber);
	
	if ((options.noVerification != true) && (options.noVerification != "true")) {
		// Wait for the text message to be received.
		if (messages.waitForTextMessage(options)) {
			return this.testResult = 1;	
		}
		else if (!minPercentForPass) {
			// we only want to try once--the send failed, so we return a failure
			this.testError = "Sent the message but did not receive expected message";
			UIALogger.logError(this.testError);
			UIATarget.localTarget().frontMostApp().logElementTree();
			return this.testResult = 0;	
		}
	}
	else {
		UIALogger.logMessage("'No Verification' was set, so we do not need to wait for the text message to arrive.");
		return this.testResult = 1;
	}
	
	if (minPercentForPass > 1) minPercentForPass=1;
	if (minPercentForPass < 0) minPercentForPass=0;

	UIALogger.logMessage("Sending first SMS failed.  Sending " + numberOfAdditionalTextMessagesToSend  + " more");
	
	UIALogger.logMessage("textToSend = '" + textToSend + "', messageToReceive = '" + options.message + 
			"', phoneNumber = '" + phoneNumber + "', timeout = '" + options.timeout + "', minPercentForPass = '" + 
			minPercentForPass + "', numberOfAdditionalTextMessagesToSend = '" + 
			numberOfAdditionalTextMessagesToSend + "'");
				
	var numPassed = 0;
	for (var i=0; i < numberOfAdditionalTextMessagesToSend; i++) {
		if (!messages.isActive()) {
			this.testError = "MobileSMS is no longer active.  Failing test.";
			UIALogger.logMessage(this.testError);
			return this.testResult=0;
		};
		
		// Send the text message
		messages.sendTextMessage(textToSend, phoneNumber);

		// Wait for the text message to be received.
		if (messages.waitForTextMessage(options)) {
			numPassed++;
		}
	}
	
	var passRatio = numPassed / numberOfAdditionalTextMessagesToSend;
	if (passRatio >= minPercentForPass) {
		UIALogger.logMessage("After first failure, tried to send " + numberOfAdditionalTextMessagesToSend + " text message(s), and " +
			numPassed + " were received.");
		return this.testResult = 1;
	}
	else {
		this.testError = "Tried to send " + numberOfAdditionalTextMessagesToSend + " text message(s), but " +
			numPassed + " were received.  Needed a percentage of " + minPercentForPass;
		messages.logElementTree();  // try to find out what's going wrong in <rdar://problem/8173664> 
		UIALogger.logMessage(testName, this.testError);
		return this.testResult = 0;
	}
}

// --------------------------------------------------------------------------------
//	Function: messagesTest_sendReceiveBulkSMS 
//		Sends the SMS message to the phone numbers specified and (if specified) waits
//		for the appropriate SMS to be received.  
//
//	Parameters:
//		textToSend (string) - SMS to be sent
//		phoneNumber (string) - Phone number(s) to send the SMS to.  At least one of these
//			must be supplied, but you can supply as many as you'd like.
//	
//  Optional Parameters:
//		phoneNumber (string) - Additional phone numbers can be supplied 
//		expectedMessage (string) - SMS that we are expecting to receive.  If we're
//			expecting the same thing that we sent, this doesn't need to get filled out.
//			this is useful if autocorrection is expected to kick in or if the device in 
//			question is expected to send something different back.
//		timeout (integer) - Number of seconds to wait for SMS to send/receive.
//		expectedPercentage (number) - Percentage of test passes that we expect in order to pass the entire test.
//			For example, if .5 is passed in, we expect at least 50% of the expected
//			messages to be received.  Passing in a 1 means we should expect all messages
//			to be successfully received..  
//		noVerification (bool) - if this is set to true, don't do any verification to check
//			for an incoming SMS or MMS.  (default is false--verification will be done.)
//
//	Usage:
//	   messagesTest_sendReceiveBulkSMS "Hi." "phoneNumber:5555555" "expectedMessage:From 5 number" "phoneNumber:4444444444" 
//		If the above parameters are used, the function will send the message "Hi." to the phonenumbers 5555555555 and 4444444444.
//		It will expect "From 5 number" back from 5555555555 and "Hi." from 4444444444.  (Order of phonenumbers and expected messages
//		are important--the first expected message will belong to the first phonenumber)
//
//	Returns:
//		1 if SMS is successfully sent and received, 0 if not.  
//		
//	Throws:
//		An error if something unexpected happens.
// --------------------------------------------------------------------------------
function messagesTest_sendReceiveBulkSMS() 
{
	this.testResult = 0;
	
	// Message To Send
	if (this.argv.length < 0) {
		this.testError = "Must specify at least one argument"
		return 0;
	}	
	var textToSend = this.argv[0];
	
	// Push options onto optionsArray;
	var optionsArray = new Array();
	for (var i=1; i<this.argv.length; i++) {
		optionsArray.push(this.argv[i]);
	}
	
	var options = new Object;
	var phoneNumbers = UIAUtility.valuesForKey("phoneNumber", optionsArray);  
	var expectedMessages = UIAUtility.valuesForKey("expectedMessage", optionsArray);
 	options.timeout = UIAUtility.valuesForKey("timeout", optionsArray, 1);
	options.expectedPercentage = UIAUtility.valuesForKey("expectedPercentage", optionsArray, 1);
	options.noVerification = UIAUtility.valuesForKey("noVerification", this.argv, 1);
	
	if (!expectedMessages) expectedMessages = new Array();
	if (!phoneNumbers) { throw new Error("Must specify at least one phone number from which to receive a message,use syntax 'phoneNumber:5555555555'"); }
	if (!options.timeout) options.timeout = 120; // wait up to 2 minutes for a message to come in.
	if (!options.expectedPercentage) options.expectedPercentage = 1;
	
	var expectedMessageArray = new Array();
	
	for (var i=0; i<phoneNumbers.length; i++) {
		var expectedMessageObject = new Object();
		expectedMessageObject.sender = phoneNumbers[i];
		if (expectedMessages[i])
			expectedMessageObject.message = expectedMessages[i];
		else
			expectedMessageObject.message = textToSend;
		expectedMessageArray.push(expectedMessageObject);
	}
	
	messages.sendTextMessage(textToSend, phoneNumbers);
	
	if ((options.noVerification != true) && (options.noVerification != "true")) { 
		// Wait for messages to be received
		if (!messages.waitForMultipleTextMessages(expectedMessageArray, options)) {
			this.testError = "Did not receive the expected text messages."
			UIALogger.logError(this.testError);
			UIATarget.localTarget().frontMostApp().logElementTree();
			return this.testResult = 0;
		}
	}
	else {
		UIALogger.logMessage("'No Verification' was set, so we do not need to wait for the text message to arrive.");
	}
	
	return this.testResult = 1;
}	

// --------------------------------------------------------------------------------
//	Function: messagesTest_sendReceivePhotoOrVideoMMS 
//		Sends a photo via MMS to the phone number specified and waits for the 
//		appropriate MMS to be received. 
//
//	Parameters: 
//		None
//
//  Optional Arguments
//		phoneNumber (string) - Phone numbers to send the MMS to.  If no phone number
//			is specified, the MMS will be sent to the phone itself.  You can specify as
//			many phone numbers as you'd like, but only one 'from' phone number.
//		from (string) -  Specifies where to get the photo from. "Choose Existing", "Take Video"
//			or "Take Photo" are the options.  If nothing is specified, it will take a photo.
//		photoAlbum (string) - If 'from' specifies that an existing photo is to be used,
//			this setting specifies which photo album to use.  If nothing is specified, we
//			choose one at random.  (This parameter does nothing if "Take Photo" is specified.)
//		textToSend (string) - a string indicating any text to send. (If not specified, no
//			text is sent with the photo.)
//		noVerification (bool) - if this is set to true, don't do any verification to check
//			for an incoming SMS or MMS.  (default is false--verification will be done.)
//		timeout (number) - Amount of time (in seconds) to wait for SMS to send/receive.
//		contactName (string) - Contact name to send the MMS to.
//
//	Returns:
//		1 if SMS is successfully sent and received, 0 if not.
//
//  Usage: 
//		messagesTest_sendReceivePhotoOrVideoMMS "phoneNumber:5555555555" "noVerification:1" "from:Choose Existing"
// --------------------------------------------------------------------------------
function messagesTest_sendReceivePhotoOrVideoMMS() 
{
	var options = new Object();
	options.phoneNumbers = UIAUtility.valuesForKey("phoneNumber", this.argv); 
	options.from = UIAUtility.valuesForKey("from", this.argv, 1);
	options.photoAlbum = UIAUtility.valuesForKey("photoAlbum", this.argv, 1);
	options.textToSend = UIAUtility.valuesForKey("textToSend", this.argv, 1);
	options.noVerification = UIAUtility.valuesForKey("noVerification", this.argv, 1);
	options.timeout = UIAUtility.valuesForKey("timeout", this.argv, 1);  
	options.contactNames = UIAUtility.valuesForKey("contactName", this.argv, 1);

	// set default values for anything that needs them.
	if (!options.timeout) options.timeout = 120;  // if timeout isn't specified, set it to 2 minutes.
	if (!options.phoneNumbers) {
		if (!options.contactNames) {
			options.phoneNumbers = new Array(telephony.myPhoneNumber);
			if (!options.phoneNumbers) {
				this.testError = "Failed to get device's phone number.";
				UIALogger.logMessage(this.testError);
				return this.testResult = 0;
			}
		}
	}
	else if (typeof options.phoneNumber == 'string') {
		// if we only have one phoneNumber, make it into an array.
		options.phoneNumbers = new Array(options.phoneNumbers);
	}
	
	if (typeof options.contactNames == 'string') {
		options.contactNames = new Array(options.contactNames);
	}
	
	// set options.mediaType, so we can check for the right type of MMS when we get something.
	if (options.from && options.from == "Take Video") {
		options.mediaType = "video";
	}
	else if (options.from && options.from == "Take Photo") {
		options.mediaType = "photo";
	}
	// XXX TODO: If someone chooses "Choose Existing", we don't know if it will be a photo or a video.  Need to work this part out.
	//<rdar://problem/8062817> UIA: If "Choose Existing" is used for messagesTest_sendReceivePhotoOrVideoMMS(), can't check MMS message type
/*	else {
		options.mediaType = "photo";
	}*/
	
	var messageToLog = "phoneNumbers = '" + options.phoneNumbers + "', from = '" + options.from + 
	"', photoAlbum = '" + options.photoAlbum + "', expectedMessage = '" + options.expectedMessage + "', timeout = '" + 
	options.timeout;
	
	if (!options.contactNames) {
		messageToLog = messageToLog + "'.";
	} else {
		messageToLog = messageToLog + "', contactNames = '" + options.contactNames + "'.";
	}
	
	UIALogger.logMessage(messageToLog);
	
	messages.sendPhotoOrVideoMMS(options);
	
	if ((options.noVerification != true) && (options.noVerification != "true")) {
		if (messages.waitForTextMessage(options)) {
			return this.testResult = 1;	
		}
		else {
			// we only want to try once--the send failed, so we return a failure
			this.testError = "Did not receive expected message";
			UIALogger.logError(this.testError);
			UIATarget.localTarget().frontMostApp().logElementTree();
			return this.testResult = 0;	
		}
	}
	else {
		UIALogger.logMessage("'No Verification' was set, so we do not need to wait for the text message to arrive.");
	}
	
	return this.testResult = 1;
}


// --------------------------------------------------------------------------------
//	Function: messagesTest_deleteThread 
//		Deletes an SMS thread.
//
//	Parameters: 
//		None needed.  If no arguments are given, the first thread is deleted.
//
//	Optional Parameters:
//		threadIndex (integer) - thread number to delete.  
//		threadName (string) - thread name to delete.  This is a wildcard match, i.e. 
//			name matches '(408) 555-5555'
//
//  	Note: 
//		If both 'threadIndex' and 'threadName' are provided, only the threadIndex will be used
//
//	Returns:
//		1 if thread is successfully deleted, 0 if not.
// --------------------------------------------------------------------------------
function messagesTest_deleteThread() 
{	
	this.testError = 0;

	// Push options onto optionsArray;
	var optionsArray = new Array();
	for (var i=0; i<this.argv.length; i++) {
		optionsArray.push(this.argv[i]);
	}
	var options = new Object();
	options.threadIndex = UIAUtility.valuesForKey("threadIndex", optionsArray, 1); 
	options.threadName = UIAUtility.valuesForKey("threadName", optionsArray, 1);
	
	messages.deleteThreadByNumber(options);

	return this.testResult = 1;
}

// Create self tests -- this is an unnamed function, just to make sure any local variables stay in the correct context
(function() {	
	if ((typeof messages != 'undefined') && springboard.displaysApp(messages)) { 
		if (typeof messages.selfTests == 'undefined') {
			messages.selfTests = new Array();
		}
		var date = new Date();
		var testSuffix = "" + date.getHours() + date.getMinutes() + date.getSeconds();
		var title1 = "Unit Test SMS: " + testSuffix;
		var bulkSMSText = "Unit Test Bulk SMS: " + testSuffix;
		var kSMSBuddy1 = "4083321896";
		var kSMSBuddy2 = "4083323272";
	
		messages.selfTests.push(phtCreateTest("SendReceiveSMS", ["This is a SelfTest message."], messagesTest_sendReceiveTextMessage, "Send and Receive a Simple SMS"));
		messages.selfTests.push(phtCreateTest("SendReceiveSMSWithMinPercentToReceive", ["Hi.  How are you?", "minPercentForPass:.9", "numberOfAdditionalTextMessagesToSend:10"], messagesTest_sendReceiveTextMessage, "Send and received an SMS with a minimum percent to receive"));	
		messages.selfTests.push(phtCreateTest("DeleteFirstThread", ["threadIndex:0"], messagesTest_deleteThread, "Delete First Thread"));	
		messages.selfTests.push(phtCreateTest("SendReceveBulkSMS", [bulkSMSText, "timeout:30", "expectedPercentage:0.5", "phoneNumber:" + telephony.myPhoneNumber, "phoneNumber:" + kSMSBuddy1, "phoneNumber:" + kSMSBuddy2], messagesTest_sendReceiveBulkSMS, "Send and receive bulk SMS"));	
		if (system.hasCapability('mms')) {
			messages.selfTests.push(phtCreateTest("TakePhotoAndSendMMS", ["from:Take Photo"], messagesTest_sendReceivePhotoOrVideoMMS, "Take a photo and send it using MMS"));
			messages.selfTests.push(phtCreateTest("SendExistingPhotoMMS", ["from:Choose Photo", "textToSend:Hello There-SelfTest."], messagesTest_sendReceivePhotoOrVideoMMS, "Send an existing photo using MMS"));
			if (system.hasCapability('video-camera')) {
				messages.selfTests.push(phtCreateTest("SendVideoMMS", ["from:Take Video", "timeout:300"], messagesTest_sendReceivePhotoOrVideoMMS, "Send a video using MMS"));
			}
		}
	}		
}())
