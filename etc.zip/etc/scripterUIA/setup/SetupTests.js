#import "./Setup.js"
#import "../libs/PHTesting.js"

//----------------------------------------------------------------------------------------
//	Function: setupTest_setupDevice
//		Navigates through the SetupBuddy on the device. 
//
//	Parameters: 
//		None
//
//  Optional Parameters:  (optional parameters as used like this:  "language:English" "wifinetwork:AppleWiFi")
//      language (string) - language to choose.  If not specified, chooses English
//      country (string) - country to choose.  If not specified, chooses United States.
//      shouldDisableLocationServices (bool) - set to 1 if you want to disable location services.
//      wifiNetwork (string) - wifi network to choose.  If not specified, no network is chosen.
//      wifiPassword (string) - password for the wifi network
//      useCellularNetwork (bool) - set this to one to use a cellular network instead of a wifi network.
//      restoreRoute (string) = "new", "icloud" or "itunes".  If nothing is entered, we set it up as a new device.  
//      appleID (string) = apple ID to setup.
//      appleIDPassword (password) = password for the apple id account.
//      icloudBackup (string) = "new", "latest", "itunes".  If nothing is entered, we set it up as a new device. 
//      dontSendDiagnostics (bool) = set to 1 if you don't want Diagnostics to be sent to apple.  Otherwise, Diagnostics will be turned on.
//      dontUseSiri (bool) = set to 1 if you don't want to use Siri (aka Assistant).  Otherwise, Siri will be turned on.
//	
//	Returns:
//		throws exception if test fails, returns 1 if it succeeded.  Uses the PHTesting object.  
//----------------------------------------------------------------------------------------
function setupTest_setupDevice() {
	this.testResult = 0;

	var options = new Object();
	options.language = UIAUtility.valuesForKey("language", this.argv, 1); 
	options.country = UIAUtility.valuesForKey("country", this.argv, 1); 
	options.shouldDisableLocationServices = UIAUtility.valuesForKey("shouldDisableLocationServices", this.argv, 1); 
	options.wifiNetwork = UIAUtility.valuesForKey("wifiNetwork", this.argv, 1); 
	options.wifiPassword = UIAUtility.valuesForKey("wifiPassword", this.argv, 1); 
	options.useCellularNetwork = UIAUtility.valuesForKey("useCellularNetwork", this.argv, 1); 
	options.restoreRoute = UIAUtility.valuesForKey("restoreRoute", this.argv, 1); 
	options.appleID = UIAUtility.valuesForKey("appleID", this.argv, 1); 
	options.appleIDPassword = UIAUtility.valuesForKey("appleIDPassword", this.argv, 1); 
	options.icloudBackup = UIAUtility.valuesForKey("icloudBackup", this.argv, 1); 
	options.dontSendDiagnostics = UIAUtility.valuesForKey("dontSendDiagnostics", this.argv, 1); 
	options.dontUseSiri = UIAUtility.valuesForKey("dontUseSiri", this.argv, 1); 
		
	UIALogger.logMessage("Setting up device with options: " + JSON.stringify(options));
	setup.navigateSetupBuddy(options);
	return this.testResult = 1;
}