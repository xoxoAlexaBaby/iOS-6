#This script will do httpDownloadTest
#accept one argument (optional): PassSecond, how long the download should finish in seconds; default is 70 seconds

#!/bin/sh -x
pass_second=70
count=1
pass_count=0
fail_count=0

pushd /usr/local/bin/

if [ "$1" != "" ]; then
	pass_second=$1
fi
echo "The Pass criteria set as $pass_second seconds"


while true; do
	echo ""
	echo "Cycle $count started, please wait for downloading...."
	START=$(date +%s)
	output=$(httpDownloadTest -p -bw -noFile "http://documentation.apple.com/en/finalcutpro/usermanual/Final%20Cut%20Pro%207%20User%20Manual%20(en).pdf" 2>&1)
	END=$(date +%s)
	DIFF=$(( $END - $START ))
	
	echo "Http Download Finished"
	echo $output
 	echo $output | grep "Downloaded 0 kbytes"
	if [ 0 -ne $? ]; then
		if [ "$DIFF" -le "$pass_second" ]; then
			echo
			echo "Cycle $count: Pass; It took $DIFF seconds to finish the download"
			((pass_count++))
		else 
			echo
			echo "Cycle $count: Fail; It took $DIFF seconds to finish the download"
			((fail_count++))
		fi
	else
		echo
		echo "Cycle $count: Fail; httpDownloadTest returns fail"
		((fail_count++))
	fi
	
	echo "WiFi Off/On"
	sleep 1
	mobilewifitool -- device power -i en0 0
	sleep 5
	mobilewifitool -- device power -i en0 1
	sleep 5
	echo ""
	echo "Finished $count cycles: $pass_count cycles Passed, $fail_count cycles Failed"
	((count++))
	echo ""
done
