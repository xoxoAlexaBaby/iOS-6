//iPod Acceptance Test Catalogue.


if (typeof audio.acceptanceTests == 'undefined') {
	audio.acceptanceTests = new Array();
}if (typeof video.acceptanceTests == 'undefined') {
	video.acceptanceTests = new Array();
}

//	Audio Tests
	audio.acceptanceTests.push(phtCreateTest("PlayRandomSong", [null, 10], iPodTest_playSongFromSongList, "Play Random Song for 10 Seconds"));

	// Video Tests
	video.acceptanceTests.push(phtCreateTest("PlayRandomVideo", [null, 10], iPodTest_playMovieFromVideoList, "Play Random Video for 10 Seconds"));

	


