//Contacts Acceptance Test Catalogue.

if (typeof addressbook.acceptanceTests == 'undefined') {
	addressbook.acceptanceTests = new Array();
}

addressbook.acceptanceTests.push(phtCreateTest("NewContact", ["Bob", "Dylan"], contactsTest_newContact, "Add a new contact to the addressbook"));


