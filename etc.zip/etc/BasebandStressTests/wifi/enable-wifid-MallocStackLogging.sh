#!/bin/sh

ROOT="${ROOT:=/}"

usage()
{
	echo "usage: $0 (off|on)"
	exit 1
}

if [ ${EUID} -ne 0 ]; then
        echo "must run as root"
        exit 1
fi

if [ $# -ne 1 ]; then
	usage
fi

if [ ! -d ${ROOT}/System/Library/LaunchDaemons-ORIG ]; then
	mkdir ${ROOT}/System/Library/LaunchDaemons-ORIG
fi

#----------

if [ ! -f ${ROOT}/System/Library/LaunchDaemons-ORIG/com.apple.wifid.plist ]; then
	cp -p ${ROOT}/System/Library/LaunchDaemons/com.apple.wifid.plist			\
		${ROOT}/System/Library/LaunchDaemons-ORIG/com.apple.wifid.plist
fi

case "${1}" in
	"on"  | "On"  | "y" | "yes" | "Yes" )
#		defaults write									\
#			 ${ROOT}/System/Library/LaunchDaemons/com.apple.wifid.plist			\
#			 EnvironmentVariables							\
#			 -dict-add MallocStackLogging Yes
		defaults write									\
			 ${ROOT}/System/Library/LaunchDaemons/com.apple.wifid.plist			\
			 EnvironmentVariables							\
			 -dict-add MallocStackLoggingNoCompact Yes
#		defaults write									\
#			 ${ROOT}/System/Library/LaunchDaemons/com.apple.wifid.plist			\
#			 EnvironmentVariables							\
#			 -dict-add MallocBadFreeAbort Yes
		;;
	"off" | "Off" | "n" | "no"  | "No"  )
		if [ -f ${ROOT}/System/Library/LaunchDaemons-ORIG/com.apple.wifid.plist ]; then
			cp -p ${ROOT}/System/Library/LaunchDaemons-ORIG/com.apple.wifid.plist	\
				${ROOT}/System/Library/LaunchDaemons/com.apple.wifid.plist
		fi
		;;
	* )
		usage
esac

plutil -convert xml1 ${ROOT}/System/Library/LaunchDaemons/com.apple.wifid.plist
chmod 644 ${ROOT}/System/Library/LaunchDaemons/com.apple.wifid.plist

#----------

HELPER="com.apple.SCHelper"
if [ -f ${ROOT}/System/Library/LaunchDaemons/com.apple.SCHelper-embedded.plist ]; then
	HELPER="com.apple.SCHelper-embedded"
fi

if [ ! -f ${ROOT}/System/Library/LaunchDaemons-ORIG/${HELPER}.plist ]; then
	cp -p ${ROOT}/System/Library/LaunchDaemons/${HELPER}.plist				\
		${ROOT}/System/Library/LaunchDaemons-ORIG/${HELPER}.plist
fi

case "${1}" in
	"on"  | "On"  | "y" | "yes" | "Yes" )
		defaults write									\
			 ${ROOT}/System/Library/LaunchDaemons/${HELPER}				\
			 EnvironmentVariables							\
			 -dict-add MallocStackLogging Yes
#		defaults write									\
#			 ${ROOT}/System/Library/LaunchDaemons/${HELPER}				\
#			 EnvironmentVariables							\
#			 -dict-add MallocStackLoggingNoCompact Yes
#		defaults write									\
#			 ${ROOT}/System/Library/LaunchDaemons/${HELPER}				\
#			 EnvironmentVariables							\
#			 -dict-add MallocBadFreeAbort Yes
		;;
	"off" | "Off" | "n" | "no"  | "No"  )
		if [ ! -f ${ROOT}/System/Library/LaunchDaemons-ORIG/${HELPER}.plist ]; then
			cp -p ${ROOT}/System/Library/LaunchDaemons-ORIG/${HELPER}.plist		\
				${ROOT}/System/Library/LaunchDaemons/${HELPER}.plist
		fi
		;;
	* )
		usage
esac

plutil -convert xml1 ${ROOT}/System/Library/LaunchDaemons/${HELPER}.plist
chmod 644 ${ROOT}/System/Library/LaunchDaemons/${HELPER}.plist

#----------

echo "*** com.apple.wifid.plist updated, reboot required."

