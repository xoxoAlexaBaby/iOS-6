/*
 Class: UIApp (phone)
 Phone object
 */
#import "../contacts/Contacts.js"

if (system.hasCapability("telephony")) {
	phone = UIAApp.application("Phone", "com.apple.mobilephone");
	if (typeof telephony == 'undefined') telephony = new Telephony();
}

if (typeof phone != 'undefined') { 
	
	phone.alertHandler = function alertHandler(alert) {
		if (alert.name() == "You must disable airplane mode to place a call.") {
			UIALogger.logMessage("Got the disable airplane mode alert");
			alert.buttons()["Disable"].tap();
		}
	}

	//	----------------------------------------------------------------------------------------------------------------------
	//	Function: numberField 
	//		Returns the UIAElement for the number field in the keypad view
	//
	//	Parameters:
	//		None
	//
	//	Returns: 
	//		UIAElement for the number field
	//
	//	Throws: 
	//		Error
	//	----------------------------------------------------------------------------------------------------------------------
	phone.numberField = function numberField() {
		return phone.mainWindow().elements().firstWithPredicate("name == 'Blank phone number' or name == 'Phone number'")
    }
    
	//	----------------------------------------------------------------------------------------------------------------------
	//	Function: getToKeypadView 
	//		Goes to the keypad view. Ends any existing calls.
	//
	//	Parameters:
	//		None
	//
	//	Returns: 
	//		None
	//
	//	Throws: 
	//		Error
	//	----------------------------------------------------------------------------------------------------------------------
	phone.getToKeypadView = function getToKeypadView() {
		
		UIALogger.logMessage("Going to keypad view...");
		this.launchIfNotActive();
		
		// end any calls that may exist (do multiple times for multiple calls)
		var callCount = telephony.getCallCount();
		while (callCount-- > 0) {
			this.getToCallPage();
			var endButton = this.mainWindow().elements().firstWithPredicate("name contains 'End'");
			if (endButton.isValid()) {
				endButton.tap();
				endButton.waitForInvalid();
			}
		}
		
		//see if the tabBar is visible
		var tabBar = this.tabBar();
		if (tabBar.isVisible()) {
			UIALogger.logMessage("No exisiting calls. Tapping the keypad button...");
			tabBar.buttons()["Keypad"].tap();
			return ;
		}

		var actionSheet = this.actionSheet();
		if (actionSheet.isValid()) {
			UIALogger.logDebug("Found an action sheet to dismiss");
			actionSheet.buttons()["Cancel"].tap();
			actionSheet.waitForInvalid();
		}
		
		this.getToContactsTopLevel();
		
		//check the tabBar again
		tabBar = this.tabBar();
		if (tabBar.isValid()) {
			UIALogger.logMessage("No existing calls. Tapping the keypad button...");
			tabBar.buttons()["Keypad"].tap();
			return ;
		} else {
			throw new Error("Toolbar still not visible");
		}
	}
	
	//overwriting the UIAApp version to call getToKeypadView first
	phone.getToContactsList = function getToContactsList() {
		phone.getToKeypadView();
		this.__proto__.getToContactsList.apply(this);
	}

    //	----------------------------------------------------------------------------------------------------------------------
    //	Function: getToView
    //		Navigates to the "Favorites", "Recents", "Contacts", "Keypad" or "Voicemail" view
    //
    //	Parameters:
    //		view (string) - the name of the view ("Favorites", "Recents", "Contacts", "Keypad" or "Voicemail") to navigate to
    //
    //	Returns:
    //		None
    //	----------------------------------------------------------------------------------------------------------------------
    phone.getToView = function getToView(view) {
        UIALogger.logDebug("Going to view: " + view);
        this.launchIfNotActive();
        var recentsButton = this.tabBar().buttons().firstWithPredicate("name == '" + view + "' and isVisible == 1");
        UIATarget.localTarget().delay(1);
        recentsButton.tap();
        
        if (!recentsButton.withValueForKey(1, "value").isValid()) {
            throw new Error("Tapped the 'Recents' button but the button did not get selected");   
        }
        
        UIALogger.logDebug("Navigated to " + view);
    }
    
	//	----------------------------------------------------------------------------------------------------------------------
	//	Function: isOnCallPage
	//		Returns true if we are on "phone call" page, which comes up when in a phone call. 
	//
	//	Parameters:
	//		None
	//
	//	Returns:
	//		(string) - return true, if we are on the call page; false otherwise.
	//	----------------------------------------------------------------------------------------------------------------------
	phone.isOnCallPage = function isOnCallPage() {
		return (this.mainWindow().buttons()["mute"].isValid() && 
				this.mainWindow().buttons()["keypad"].isValid());
	}
	
	//----------------------------------------------------------------------------------------
	//	Function: getToCallPage 
	//		Gets to the "phone call" page, which comes up when in a phone
	//		call.  If we aren't in a phone call, it returns false.
	//
	//	Parameters: 
	//		None
	//
	//	Returns: 
	//		None
	//
	//	Throws: 
	//		Error
	//----------------------------------------------------------------------------------------
	
	phone.getToCallPage = function getToCallPage() {
		if (telephony.getCallCount() < 1) {
			throw new Error("There are currently no phone calls.");
		}
		
		if (this.isOnCallPage()) {
			UIALogger.logMessage("Already in call page");
			return ;
		}
		
		var statusBar = UIATarget.localTarget().frontMostApp().statusBar();
		if (statusBar.staticTexts().firstWithPredicate("name contains 'Touch to return to call'").isValid()) {
			statusBar.tap();
		}
		
		//tap "Hide Keypad" or "Hide Sources"
		var hideButton = this.mainWindow().buttons().firstWithPredicate("name matches 'Hide ((Keypad)|(Sources))'");
		if (hideButton.isValid()) hideButton.tap();

		if (this.isActive() && this.isOnCallPage()) {
			UIALogger.logMessage("Got to call page");
			return ;
		}
		
		throw new Error("Could not get to the call page.")
	}
	
	//----------------------------------------------------------------------------------------
	//	Function: getToAudioSourcePage
	//		Gets to the "audio source" page if BT Headset is connected, which comes up 
	//		when in a phone call. 
	//
	//	Parameters: 
	//		None
	//
	//	Returns: 
	//		None
	//
	//	Throws: 
	//		Error
	//----------------------------------------------------------------------------------------
	
	phone.getToAudioSourcePage = function getToAudioSourcePage() {
		if (telephony.getCallCount() < 1) {
			throw new Error("There are currently no phone calls");
		}
		
		if (this.mainWindow().buttons()["Hide Sources"].isValid() && this.mainWindow().buttons()["End"].isValid()) {
			UIALogger.logMessage("Already in Audio Source Page");
			return ;
		}
		
		if (this.isOnCallPage()) {
			this.mainWindow().buttons()["audio source"].tap();
			
			if (this.mainWindow().buttons()["Hide Sources"].isValid() && this.mainWindow().buttons()["End"].isValid()) {
				UIALogger.logMessage("Got to Audio Source Page");
				return ;
			}
		}
		
		throw new Error("Could not get to the audio source page.");
	}

	//----------------------------------------------------------------------------------------
	//	Function: dialNumber
	//		Dials the specified number
	//
	//	Parameters: 
	//		phoneNumber (string) - the number to dial
	//
	//	Returns: 
	//		None
	//
	//	Throws: 
	//		Error
	//----------------------------------------------------------------------------------------
	phone.dialNumber = function dialNumber(phoneNumber) {
		var number = this.returnCleanedNumber(phoneNumber);
		
		UIALogger.logMessage("Clearing old number.");
		this.mainWindow().buttons()["Delete"].tapWithOptions({duration:2});
		
		UIALogger.logMessage("Dialing number '" + number + "'.");
		
		var length = number.length;
		for (i = 0; i < length; i++) {
			var digit = number.substring(i, i + 1);
			UIALogger.logMessage("Selecting button '" + digit + "'.");
			if (digit == "+") {
				// hold the 0 key for 2 seconds to bring up the "+"
				this.mainWindow().keys().firstWithPredicate("name == '0' and isVisible == 1").tapWithOptions({duration:2});
			} else if (digit == ",") {
				// hold the * key for 2 seconds to bring up the ","
				this.mainWindow().keys().firstWithPredicate("name == '*' and isVisible == 1").tapWithOptions({duration:2});
			} else {
				this.mainWindow().keys().firstWithPredicate("name == '" + digit + "' and isVisible == 1").tap();
			}
		}
	}
	
	//----------------------------------------------------------------------------------------
	//	Function: makeCall 
	//		Makes call(s). No validation is performed.
	//
	//	Parameters: 
	//		phoneNumbers (array) - this is an array of phone numbers to be dialed. The first 
	//			number is dialed, and once it becomes active, the second call (if specified) 
	//			is added. If a third phone number is specified, the first two calls are merged
	//			and then the third call is added.
	//		options - a hash of optional arguments
	//
	//	Optional Parameters: 
	//		shouldReset (boolean) - if set to true, getToKeypadView is called before and after 
	//			making the calls. Note that getToKeypadView ends all the existing calls. By 
	//			default it is set to false, which means that the existing calls are not ended. 
	//		shouldMerge (boolean) - if set to true, the last two calls are merged (only if there 
	//			are two calls). It is set to false, by default.
	//		desiredCallStatus (string) - the desired call status after tapping the 'Call' button.
	//			This status is passed on to the callExists function call. It is set to 'Active' 
	//			by default. 
	//
	//	Returns: 
	//		None
	//
	//	Throws: 
	//		Exception
	//----------------------------------------------------------------------------------------
	phone.makeCall = function makeCall(phoneNumbers, options) {
		
		if (!options) options = new Object();
		if (!options.desiredCallStatus) options.desiredCallStatus = "Active";
		var result = false;
		
		if (!phoneNumbers || phoneNumbers.length < 1) {
			throw new Error("Not enough arguments specified.");
		}
		
		UIALogger.logMessage("Going to the dialing pad...");
		if (options.shouldReset) {
			UIALogger.logMessage("Need to reset...");
			this.getToKeypadView();
		} else {
			this.launchIfNotActive();
		}
		
		UIALogger.logMessage("Number of phone numbers to call: " + phoneNumbers.length);
		
		try { 
			for (var i = 0; i < phoneNumbers.length; i++) {
				
				var phoneCount = telephony.getCallCount();
				UIALogger.logMessage("Number of existing calls: " + phoneCount);
				
				if (phoneCount > 1) {
					UIALogger.logMessage("Need to merge calls first...");
					var mergeButton = this.mainWindow().buttons()["merge calls"];
					if (mergeButton.isValid()) mergeButton.tap(); 
				}
				
				if (phoneCount > 0) {
					UIALogger.logMessage("Need to tap the add call button...");
					var addCallButton = this.mainWindow().buttons()["add call"];
					if (!addCallButton.isValid()) throw new Error("Could not find the 'add call' button");
					UIATarget.localTarget().pushTimeout(15);
					if (!addCallButton.withValueForKey(1, "isEnabled").isValid()) throw new Error("'add call' button did not become enabled");
					UIATarget.localTarget().popTimeout();
					addCallButton.tap();
					UIATarget.localTarget().delay(1);
				}
				
				this.tabBar().buttons()["Keypad"].tap();
				
				UIALogger.logMessage("Making the " + (i+1) + "th phone call to " + phoneNumbers[i]);
				this.dialNumber(phoneNumbers[i]);
				
				this.mainWindow().buttons()["Call"].tap();
				var cleanedNumber = this.returnCleanedNumber(phoneNumbers[i]);
				
				UIALogger.logMessage("Waiting for the call to return status of " + 
									 options.desiredCallStatus + " for " + cleanedNumber);
				if (telephony.callExists(cleanedNumber, options.desiredCallStatus, 30) != true) {
					throw new Error("Timed out waiting for call status to turn 'Active' for " + phoneNumbers[i]);
				}
				UIALogger.logMessage(phoneNumbers[i] + "'s connected.");
			}
			
			if (options.shouldMerge && telephony.getCallCount() > 1) {
				UIALogger.logMessage("Should merge calls now...");
				this.mainWindow().buttons()["merge calls"].tap();
			}
			
			result = true;
			
		} catch(e) {
			UIALogger.logError("Encountered Error: " + e.message);
			this.getToKeypadView();
			throw e;
		}
		
		if (options.shouldReset) {
			UIALogger.logMessage("Now reseting...");
			this.getToKeypadView();
		}
	}

 	//----------------------------------------------------------------------------------------
	//	Function: addDialedNumberToContact
	//		Add a number to an existing contact via the + button on the keypad
	//
	//	Parameters: 
	//		contactName (string) - the name of the (new or existing) contact. 
	//
	//	Optional parameters:
	//		addToExistingContact (boolean) - if set to true, the displayed phone number is added 
	//		    to an existing contact. It is set to false by default. 
	//
	//	Returns: 
	//		None
	//
	//	Throws: 
	//		Error
	//----------------------------------------------------------------------------------------   
    phone.addDialedNumberToContact = function addNumberToContact(contactName, options) {
        if (!options) options = new Options();
        UIALogger.logDebug("Adding the displayed number to " + contactName);
        
        var displayedNumberElement = phone.mainWindow().staticTexts()["Phone number"];
        if (!displayedNumberElement.isValid()) throw new Error("Could not find the phone number element");
        
        var displayedNumber = displayedNumberElement.name();
        if (!displayedNumber || displayedNumber.length == 0) throw new Error("No displayed phone number");
        UIALogger.logDebug("Displayed number is " + displayedNumber);
        
        phone.mainWindow().buttons()["Save as contact"].tap();
        
        //check if an action sheet showed up
        var actionSheet = phone.actionSheet();
        if (actionSheet.isValid()) {
            UIALogger.logDebug("Got an action sheet -- selecting the specified action");
            UIATarget.localTarget().delay(1); //a second for animation
            if (options.addToExistingContact) 
                actionSheet.buttons()["Add to Existing Contact"].tap();
            else
                actionSheet.buttons()["Create New Contact"].tap();
        } else {
            UIALogger.logDebug("Did not get an action sheet -- checking if we intended this to be the case...");
            if (options.addToExistingContact) throw new Error("Action sheet for 'Add to Existing Contact' did not come up");
        }
        
        if (options.addToExistingContact) {
            phone.selectContact(contactName);
            if (!phone.navigationBar().withName("Info").isValid()) {
                throw new Error("The 'Info' nav bar did not come up after selecting the existing contact ");
            }
        } else {
            if (!phone.navigationBar().withName("New Contact").isValid()) {
                throw new Error("Selected 'Create New Contact' but the 'New Contact' nav bar did not come up ");
            }
            phone.editContactInfo([{type:"First", value:contactName}]);
        }
        
        UIALogger.logDebug("Selecting 'Done'");
        phone.navigationBar().buttons()["Done"].tap();
    }
    
	//----------------------------------------------------------------------------------------
	//	Function: recentWithIdentifier
	//		Returns the UIAElement represending the table cell in the "Recents" list with the 
	//		provided identifier
	//
	//	Parameters: 
	//		identifier (string or UIAPredicateString) - the name of the recent entry or a 
	//		    UIAPredicate object that can be used to identify it. 
	//
	//	Returns: 
	//		the UIAElement corresponding to the provided identifier
	//
	//	Throws: 
	//		Error
	//----------------------------------------------------------------------------------------
    phone.recentWithIdentifier = function recentWithIdentifier(identifier) {
        var recentsTable = this.mainWindow().tableViews()[0];
		if (identifier instanceof UIAPredicateString) {
            return recentsTable.scrollToElementWithPredicate(identifier.predicateString);
		} else {
            return recentsTable.scrollToElementWithName(identifier);
		}
        
    }

	//----------------------------------------------------------------------------------------
	//	Function: makeCallToRecent
	//		Makes a call to an entry in "Recents" list with the provided identifier
	//
	//	Parameters: 
	//		identifier (string or UIAPredicateString) - the name of the recent entry or a 
	//		    UIAPredicate object that can be used to identify it. 
	//
	//	Returns: 
	//		None
	//
	//	Throws: 
	//		Error
	//----------------------------------------------------------------------------------------
	phone.makeCallToRecent = function makeCallToRecent(identifier) {
        phone.getToContactsList();
		phone.getToView("Recents");
        
		var recentsTable = this.mainWindow().tableViews()[0];
		if (identifier instanceof UIAPredicateString) {
            UIALogger.logDebug("Calling recent with predicate string: " + identifier.predicateString);
            phone.recentWithIdentifier(identifier).tap();
		} else {
            UIALogger.logDebug("Calling recent with name: " + identifier);
            phone.recentWithIdentifier(identifier).tap();
		}
		UIALogger.logDebug("Calling ");
	}
    
    phone.clearAllRecents = function clearAllRecents() {
        phone.getToView("Recents");
        
        var recentsTable = this.mainWindow().tableViews()[0];
        if (recentsTable.cells().length == 0) {
            UIALogger.logDebug("Recents table is already clear");
            return ;
        }
        
        UIALogger.logDebug("Seleting 'Edit'");
        var editButton = this.navigationBar().buttons()["Edit"];
        UIATarget.localTarget().delay(1);
        editButton.tap();
        
        UIALogger.logDebug("Selecting 'Clear'");
        var clearButton = this.navigationBar().buttons()["Clear"];
        UIATarget.localTarget().delay(1);
        clearButton.tap();
        
        UIALogger.logDebug("Selecting 'Clear All Recents' button on the action sheet");
        var confirmClearButton = this.actionSheet().buttons()["Clear All Recents"];
        UIATarget.localTarget().delay(1);
        confirmClearButton.tap();
        
        recentsTable = this.mainWindow().tableViews()[0];
        if (!recentsTable.cells()[0].waitForInvalid()) {
            UIALogger.logWarning("The first cell did not become invalid");
        }
        
        if (recentsTable.cells().length != 0) {
            throw new Error("Select 'Clear' but the recents did not get cleared");
        }
    }
    
	//----------------------------------------------------------------------------------------
	//	Function: addRecentNumberToAddressbook
	//		Makes a call to an entry in "Recents" list with the provided identifier
	//
	//	Parameters: 
	//		number (string) - the phone number in the recents list that should be added to the 
	//		    addressbook.
	//
	//	Optional parameters:
	//		addToExistingContact (boolean) - if set to true, the recent phone number is added 
	//		    to an existing contact (specified by the contactName parameter)
	//		contactName (string) - the name of the (new or existing) contact. This parameter 
	//		    is required if addToExistingContact is set to true.
	//
	//	Returns: 
	//		None
	//
	//	Throws: 
	//		Error
	//----------------------------------------------------------------------------------------
    phone.addRecentNumberToAddressbook = function addRecentNumberToAddressbook(number, options) {
        if (!options) options = new Object();
        
        UIALogger.logDebug("Adding " + number + " from the recents list to the addressbook");
        phone.getToView("Recents");
        
        var recentNumber = this.recentWithIdentifier(new UIAPredicateString("name contains '" + number + "'"));
        if (!recentNumber.isValid()) {
            throw new Error("Could not find a recent call with number " + number);   
        }
        recentNumber.buttons().firstWithPredicate("name beginswith 'more info'").tap();
        
        if (!this.mainWindow().navigationBars()["Info"].isValid()) {
            throw new Error("Selected the recent call entry but the 'Info' nav bar did not come up");
        }
        UIATarget.localTarget().delay(1);
        
        if (options.addToExistingContact) {
            if (!options.contactName) {
                throw new Error("No contact name provided");
            }
            UIALogger.logDebug("Adding to existing contact " + options.contactName);
            this.mainWindow().tableViews()[0].scrollToElementWithName("Add to Existing Contact").tap();
            
            var contactResult = this.searchForContact(options.contactName);
            if (!contactResult.isValid()) {
                throw new Error("Could not find a search result for " + options.contactName);
            }
            contactResult.tap();
        } else {
            UIALogger.logDebug("Creating a new contact");
            this.mainWindow().tableViews()[0].scrollToElementWithName("Create New Contact").tap();
            
            if (options.contactName) {
                UIALogger.logDebug("Entering name information: " + options.contactName);
                this.editContactInfo([{type:"First", value:options.contactName}]);
            }
        }
        
        UIALogger.logDebug("Selecting 'Done' button");
        var doneButton = this.navigationBar().buttons()["Done"];
        UIATarget.localTarget().delay(1);
        doneButton.tap();
        
        //some verification
        UIALogger.logDebug("Checking if the 'Edit' button came up");
        if (!this.navigationBar().buttons()["Edit"].isValid()) {
            throw new Error("Tapped 'Done', but the 'Edit' button did not come up");
        }
        
        if (!this.infoTable().cells().firstWithPredicate("name contains '" + number + "'")) {
            throw new Error("Selected 'Done' but the contact info table does not contain the number " + number);
        }
    }

    //----------------------------------------------------------------------------------------
    //	Function: addFavoriteUsingAddButton
    //		Add a favorite contact using the add button on the "Favorites" view
    //
    //	Parameters: 
    //		contactName (string) - the name of the contact to be added as a favorite
    //      options (object) - a dictionary of optional arguments
    //
    //  Optional parameters:
    //      phoneNumber (string) - the phone number of the contact that should be selected. 
    //          This parameter can be useful if the specified contact has multiple phone 
    //          numbers. If no value is specified, the first phone number is chosen. 
    //      favoriteType (string) - "Voice Call" or "FaceTime". By defauly, "Voice Call" is 
    //          chosen. 
    //
    //	Returns: 
    //		None
    //
    //	Throws: 
    //		Error
    //----------------------------------------------------------------------------------------
    phone.addFavoriteUsingAddButton = function addFavoriteUsingAddButton(contactName, options) {
        if (!options) options = new Object();
        
        this.getToView("Favorites");
        this.navigationBar().buttons()["Add"].tap();
        
        this.getToContactsTopLevel();
        var contactElement = this.searchForContact(contactName);
        if (!contactElement.isValid()) {
            throw new Error("Contact '" + contactName + "' not found");
        }
        contactElement.tap();
        if (phone.navigationBar().withName("Info").isValid()) {
            UIALogger.logDebug("Selecing the contact brought up the 'Info' -- possibly because mulitiple numbers are specified");
            var cell;
            if (!options.phoneNumber) {
                cell = this.mainWindow().tableViews()[0].cells()[0].withValueForKey(1, "isVisible");
                UIALogger.logDebug("Selecting the first cell: " + cell.name());
            } else {
                cell = this.mainWindow().tableViews()[0].scrollToElementWithPredicate("value contains '" + phone.formatUSANumber(options.phoneNumber) + "'");
                UIALogger.logDebug("Selecting the number: " + options.phoneNumber);
            }
            cell.tap();
        }
        UIATarget.localTarget().delay(1); //delay needed for the next table to come up properly. See <rdar://problem/8264334>.
        
        //the "Voice" or "FaceTime" action sheet might show up
        var shouldUseVoiceButton = this.actionSheet().buttons()["Voice Call"];
        if (!options.favoriteType) options.favoriteType = "Voice Call";
        if (shouldUseVoiceButton.isValid()) {
            UIALogger.logDebug("Got a voice or facetime action sheet -- choosing '" + options.favoriteType + "'");
            UIATarget.localTarget().delay(1);
            phone.actionSheet().buttons()[options.favoriteType].tap();
            shouldUseVoiceButton.waitForInvalid();
        }
    }

    //----------------------------------------------------------------------------------------
    //	Function: addContactToFavorites
    //		Select the specified contact, and add it as a favorite by selecting the "Add to Favorites"
    //      button in the contact card
    //
    //	Parameters: 
    //		contactName (string) - the name of the contact to be added as a favorite
    //      options (object) - a dictionary of optional arguments
    //
    //  Optional parameters:
    //      phoneNumber (string) - the phone number of the contact that should be selected. 
    //          This parameter can be useful if the specified contact has multiple phone 
    //          numbers. If no value is specified, the first phone number is chosen. 
    //      favoriteType (string) - "Voice Call" or "FaceTime". By defauly, "Voice Call" is 
    //          chosen. 
    //
    //	Returns: 
    //		None
    //
    //	Throws: 
    //		Error
    //----------------------------------------------------------------------------------------
    phone.addContactToFavorites = function addContactToFavorites(contactName, options) {
        if (!options) options = new Object();
        
        this.getToContactsList();
        
        var contactElement = this.searchForContact(contactName);
        if (!contactElement.isValid()) {
            throw new Error("Contact '" + contactName + "' not found");
        }
        
        contactElement.tap();
        if (!phone.navigationBar().withName("Info").isValid()) {
            UIALogger.logWarning("Tapped the contact, but the 'Info' nav bar did not show up");   
        }
        UIATarget.localTarget().delay(1); //delay needed for the next table to come up properly. See <rdar://problem/8264334>.
        
        UIALogger.logDebug("Looking for 'Favorites' button");
        var cell = this.cellsContainingElementsWithPredicate(this.mainWindow().tableViews().firstWithPredicate("isVisible == 1"), "name contains 'Favorites'")[0];
        cell.scrollToVisible();
        cell.buttons().firstWithPredicate("name contains 'Favorites'").tap();
        
        // If a contact has multiple numbers that can be added to favorites, you'll have to choose one in the action sheet
        var actionSheet = this.actionSheet();
        if (actionSheet.isValid()) {
            if (actionSheet.staticTexts()["Add to Favorites."].isValid()) {
                UIATarget.localTarget().delay(1);
                UIALogger.logMessage("Got an action sheet with the phone numbers -- selecting an option");
                if (!options.phoneNumber) 
                    actionSheet.buttons()[0].tap();
                else {
                    var actionSheetButtons = actionSheet.buttons();
                    var numberFound = false;
                    for (var i=0; i<actionSheetButtons.length; i++) {
                        var buttonPhoneNumber = actionSheetButtons[i].name().split(',')[1];
                        if (buttonPhoneNumber && phone.returnCleanedNumber(buttonPhoneNumber) == phone.returnCleanedNumber(options.phoneNumber)) {
                            actionSheetButtons[i].tap();
                            numberFound = true;
                            break;
                        }
                    }
                    
                    if (numberFound == false) {
                        throw new Error("Number not found");
                    }
                }
                actionSheet.waitForInvalid();
            }
            
            //the "Voice" or "FaceTime" action sheet might show up
            var shouldUseVoiceButton = this.actionSheet().buttons()["Voice Call"];
            if (!options.favoriteType) options.favoriteType = "Voice Call";
            if (shouldUseVoiceButton.isValid()) {
                UIALogger.logDebug("Got a voice or facetime action sheet -- choosing '" + options.favoriteType + "'");
                UIATarget.localTarget().delay(1);
                phone.actionSheet().buttons()[options.favoriteType].tap();
                shouldUseVoiceButton.waitForInvalid();
            }
        }
    }

	// --------------------------------------------------------------------------------
	//	Function: removeContactFromFavorites
	//		Removes the specified contact from the favorites list
	//
	//	Parameters:
	//		contactName (string) - the name of the contact to be removed as a favorite
	//
	//	Returns: 
	//		None
	//
	//	Throws: 
	//		Error
	// --------------------------------------------------------------------------------
    phone.removeContactFromFavorites = function removeContactFromFavorites(contactName) {
        UIALogger.logDebug("Removing " + contactName + " from favorites");
        phone.getToView("Favorites");
        
        phone.navigationBar().buttons()["Edit"].tap();
        var contactCell = phone.mainWindow().tableViews()[0].cells().firstWithPredicate("name contains '" + contactName + "'");
        phone.deleteTableCell(contactCell);
        
    }
	// --------------------------------------------------------------------------------
	//	Function: answerCall
	//		Waits for a call and then answers it
	//
	//	Parameters:
	//		phoneNumber (string) - optional - phone number of incoming call. If no number 
	//			is specified, an incoming call from any number is received. 
	//		waitTimeout (string) - how long to wait before giving up on the incoming call
	//
	//	Returns: 
	//		None
	//
	//	Throws: 
	//		Error
	// --------------------------------------------------------------------------------
	phone.answerCall = function answerCall(phoneNumber, waitTimeout) {
		UIALogger.logMessage("Waiting for incoming call.");
		if (telephony.callExists(phoneNumber, "Ringing", waitTimeout) == false) {	
			throw new Error("Failed to detect incoming call.");
		}
		UIATarget.localTarget().delay(1); // need to wait for the buttons to complete animating
		
		
		UIALogger.logMessage("Answering call by selecting button 'Answer'.");
		this.mainWindow().buttons()["Answer"].tap();
		
		UIALogger.logMessage("Validating call status.");
		if (telephony.callExists(phoneNumber, "Active", 10) == false) {
			throw new Error("Could not verify 'active' state of call.");		
		}
		UIALogger.logMessage("Call status is active.");
	}
	
	// --------------------------------------------------------------------------------
	//	Function: endCall
	//		ends a call if one exists.
	//
	//	Optional Parameters:
	//		number (string) - the phone number of the call to end
	//
	//	Returns: 
	//		None
	//
	//	Throws: 
	//		Error - "No calls to end, getCallCount is less than 1." - If there are no active calls to end. 
	//		Error - "Call to end was not found" - If the call to end was not found in acive call list.
	//		Error - "Call to end was on hold and we failed to take it off hold."
	//		Error - "Call still exists" - If attempt to end call failed.
	//
	//  Note:
	//		We do not check variations of the phone number like searching with or without the country code or area code.
	// --------------------------------------------------------------------------------
	phone.endCall = function endCall(phoneNumber) {
	
		UIALogger.logMessage("Call to end is:  " + phoneNumber);
	
		// Check to see if there are any active calls, fail if none.
		if (telephony.getCallCount() < 1) {
			UIALogger.logError("No active/held calls, count is:  " + telephony.getCallCount());
			throw new Error("No calls to end, getCallCount is less than 1.");
		}
		
		this.getToCallPage();
		
		if ((telephony.callExists(phoneNumber, "Active", 5) == false) && (phoneNumber != "undefined")) {
			
			// if the call is not active it may be held, make it active
			if (telephony.callExists(phoneNumber, "Held", 5)) {
				UIALogger.logMessage("Call to end is currently on hold.");
				this.mainWindow().buttons().firstWithPredicate("name == 'hold' or name == 'swap'").tap();
					
				if (telephony.callExists(phoneNumber, "Active", 5) == false) {
					UIALogger.logError("Failed to move call from Hold to Active!");
					throw new Error("Call to end was on hold and we failed to take it off hold.");
				} 
			} else {
				UIALogger.logError("Did not find " + phoneNumber + " in list of active calls, printing element tree!");
				this.logElementTree();
				throw new Error("Call to end was not found");
			}
		}
			
		UIALogger.logMessage("Call to end is active, tapping END");	
		var endCallButton = this.mainWindow().buttons()["End"].withPredicate("isVisible == 1");
		UIATarget.localTarget().delay(1);
		endCallButton.tap();
	
		UIALogger.logMessage("Waiting for call to end.");
		//need to minimize delay here... otherwise we will not pick the disconnected status
		if ((telephony.callExists(phoneNumber, "Disconnected", 5) == true))  {
			UIALogger.logMessage("Call has been disconnected.");
		} else {
			UIALogger.logError("Did not find call in disconnected state!");
			throw new Error("Call still exists");
		}
	}

	// --------------------------------------------------------------------------------
	//	Function: endAllCalls
	//		Ends all existing calls.
	//
	//	Optional Parameters:
	//		none
	//
	//	Returns: 
	//		None
	//
	//	Throws: 
	//		Error - If endCall() throws.
	//		Error - If we try and end more calls than originally reported.
	//
	//	NOTE: 
	//		Uses phone.endCall() to end each individual call.
	//		If needed, can support a parameter and end all instances of passed in number.
	// --------------------------------------------------------------------------------
	phone.endAllCalls = function endAllCalls() {
		var numberOfCallsToEnd = telephony.getCallCount();  //Save total number of current calls
	
		UIALogger.logMessage("Ending all calls, found: " + numberOfCallsToEnd);
		
		// Check to see if there are any active calls, fail if none.
		if (numberOfCallsToEnd < 1) {
			UIALogger.logError("No active/held calls found!");
			return ;
		}
		
		//Call phone.endCall() till all calls are ended, Error if we loop more than CallCount.
		while ((telephony.getCallCount() > 0) && numberOfCallsToEnd-- > 0) {
			UIALogger.logMessage("Ending call");
			phone.endCall();	// If phone.endCall throws we let it get passed up the stack
		}
		if (telephony.getCallCount() > 0) {
			UIALogger.logError(telephony.getCallCount() + " call(s) still exist after ending all calls!");
			throw new Error("One or more calls still exist");
		}
	}
	
	phone.requestCall = function requestCall(serverIP, delay) {		
		command = "/usr/local/bin/CallMe -d " + delay + " " + serverIP;
		
		UIALogger.logMessage("Scheduling future call.");
		result = system.run(command);
		
		UIALogger.logMessage(result.stdout);
		UIALogger.logMessage(result.stderr);	
	}
	
	phone.requestSMS = function requestSMS(serverIP, message, delay) {
		command = "/usr/local/bin/CallMe -d " + delay + " -m " + message + " " + serverIP;
		
		UIALogger.logMessage("Scheduling future SMS.");
		result = system.run(command);
		
		UIALogger.logMessage(result.stdout);
		UIALogger.logMessage(result.stderr);	
	}
	
	phone.requestEndCall = function requestEndCall(serverIP, delay) {
		command = "/usr/local/bin/CallMe -e -d " + delay + " " + serverIP;
		
		UIALogger.logMessage("Scheduling end of call.");
		result = system.run(command);
		
		UIALogger.logMessage(result.stdout);
		UIALogger.logMessage(result.stderr);	
	}
	
	//----------------------------------------------------------------------------------------
	//	Function: returnUSATenDigitNumber 
	//		If the number is an American number, return the 10 
	//		digit phone number.  Otherwise, this function returns the number as it was.
	//
	//	Parameters: 
	//		phoneNumber (string) - Phone Number to be converted.
	//
	//	Returns: 
	//		String representing the phone number
	//----------------------------------------------------------------------------------------
	phone.returnUSATenDigitNumber = function returnUSATenDigitNumber(phoneNumber) {
		if ((phoneNumber == 'undefined') || (!phoneNumber)) {
			return null;
		}
		if (phoneNumber.length == 10) {
			return phoneNumber;
		}
		else if ((phoneNumber.length == 11) && (phoneNumber[0] == "1")) {
			return (phoneNumber.substr(1,10));
		}
		else if ((phoneNumber.length == 12) && (phoneNumber[0] == "+") && (phoneNumber[1] == "1")) {
			return (phoneNumber.substr(2,10));
		}
		return phoneNumber;
	}
	
	//----------------------------------------------------------------------------------------
	//	Function: returnUSAElevenDigitNumber 
	//		If the number is an American number, return the 
	//		eleven digit phone number, which starts with a "1" 
	//
	//	Parameters: 
	//		phoneNumber (string) - Phone Number to be converted.
	//
	//	Returns: 
	//		String representing the phone number
	//----------------------------------------------------------------------------------------
	phone.returnUSAElevenDigitNumber = function returnUSAElevenDigitNumber(phoneNumber) {
		if ((phoneNumber == 'undefined') || (!phoneNumber)) {
			return null;
		}
		if (phoneNumber.length == 11) {
			return phoneNumber;
		}
		else if (phoneNumber.length == 10) {
			return ("1" + phoneNumber);
		}
		else if ((phoneNumber.length == 12) && (phoneNumber[0] == "+") && (phoneNumber[1] == "1")) {
			return (phoneNumber.substr(1,11));
		}
		return phoneNumber;
	}
	
	//----------------------------------------------------------------------------------------
	//	Function: returnTenDigitNumber
	//		Adds a plus sign onto phone numbers for calling outside of the country.
	//
	//	Parameters: 
	//		phoneNumber (string) - Phone Number to be converted.
	//
	//	Returns: 
	//		string representing the phone numbers
	//----------------------------------------------------------------------------------------
	phone.returnNumberWithPlus = function returnNumberWithPlus(phoneNumber) {
		if ((phoneNumber == 'undefined') || (!phoneNumber)) {
			return null;
		}
		if ((phoneNumber.length == 11) && (phoneNumber[0] == "1")) {
			return ("+" + phoneNumber);
		}
		else if (phoneNumber.length == 10) {
			return ("+1" + phoneNumber);
		}
		else if (phoneNumber[0] != "+") {
			return ("+" + phoneNumber);
		}
		return phoneNumber;
	}
	
	
	
	//----------------------------------------------------------------------------------------
	//	Function: returnCleanedNumber
	//		Returns a number after removing all occurences of (,),-, and " "
	//								
	//	Parameters: 
	//		phoneNumber (string) - Phone Number to be cleaned.
	//
	//	Returns: 
	//		string representing the phone number
	//----------------------------------------------------------------------------------------
	phone.returnCleanedNumber = function returnCleanedNumber(phoneNumber) {
		return phoneNumber.replace(/\(|\)| |-/g,"");
	}

	//----------------------------------------------------------------------------------------
	//	Function: formatUSANumber
	//		Returns a number after formatting it as it would appear in the dialer, etc.
	//          1xxxyyyzzzz is returned as +1 (xxx) yyy-zzzz
	//          xxxyyyzzzz is returned as (xxx) yyy-zzzz
	//								
	//	Parameters: 
	//		phoneNumber (string) - U.S. phone Number to be formatted.
	//
	//	Returns: 
	//		formatted phone number
	//----------------------------------------------------------------------------------------
    phone.formatUSANumber = function (phoneNumber) {
        var formattedNumber = phoneNumber;
        if (phoneNumber.length == 12 && (phoneNumber[0] == "+") && (phoneNumber[1] == "1")) {
            formattedNumber = phoneNumber.substr(0,2) + " (" + phoneNumber.substr(2,3) + ") " + phoneNumber.substr(5,3) + "-" + phoneNumber.substr(8,4);
        } else if (phoneNumber.length == 11 && (phoneNumber[0] == "1"))  {
            formattedNumber = phoneNumber.substr(0,1) + " (" + phoneNumber.substr(1,3) + ") " + phoneNumber.substr(4,3) + "-" + phoneNumber.substr(7,4);
        } else if (phoneNumber.length == 10) {
            formattedNumber = "(" + phoneNumber.substr(0,3) + ") " + phoneNumber.substr(3,3) + "-" + phoneNumber.substr(6,4);
        }
        return formattedNumber;
    }

	//----------------------------------------------------------------------------------------
	//	Function: waitForPhoneCallToStart
	//		For use with Assistant.  This function waits for the Phone App to come up and waits for
	//			a call to begin. Throws an error if it doesn't happen.
	//								
	//	Parameters: 
	//		timeout (integer) - amount of time to wait for phone call to begin (optional - 60 seconds by default)
	//
	//	Returns: 
	//		formatted phone number
	//----------------------------------------------------------------------------------------
    phone.waitForPhoneCallToStart = function waitForPhoneCallToStart(timeout) {
        if (!timeout) timeout = 60;
        
		for (i=0; i<timeout; i++) {
			if (UIATarget.localTarget().frontMostApp().name() == this.name) {
				UIALogger.logMessage("Phone is active after " + i + " seconds.");
				break;
			}
			UIATarget.localTarget().delay(1);
		}
		
		if (i >= timeout) {
			throw new Error("Phone is not frontmost, number of active calls is " + telephony.getCallCount() + ", Assistant Info: " + springboard.currentAssistantInfo());
		}
		
		for (; i<timeout; i++) {
			if (telephony.getCallCount() >= 1) {
				UIALogger.logMessage("At least one call is active after " + i + " seconds, Assistant Info " + springboard.currentAssistantInfo());
				break;
			} 
			UIATarget.localTarget().delay(1);
		}
		if (i >= timeout) {
			throw new Error("Waited '" + timeout + "' seconds, but no calls are active.");
		}
		
		UIALogger.logMessage("Phone is frontmost app and a phone call is occurring.")
		
    }
}