#import "UIAAppStressLibrary.js"

var username = "stressrack1@stressstuff.apple.com";
var password = "t3stst0r3";
var appsList = ["Spider: The Secret of Bryce Manor", "Space Invaders Infinity Gene", "Twitterrific", "Thereminator", "Facebook", "Pandora Radio", "LEGO Photo", "Brushes", "BubbleWrap"];
var bundleList = ["com.tigerstylegames.spider", "jp.co.taito.infinitygene", "com.iconfactory.Twitterrific", "com.yourcompany.Thereminator", "com.facebook.Facebook", "com.pandora", "com.lego.clickbuild", "com.stevesprang.Brushes", "nz.co.orsome.bubbleWrap"];

if (typeof appstore != 'undefined') {
	appstoreStress = AppStressBase.stressTest("AppStore");
	
	if (typeof appstoreStress != 'undefined') {

		appstoreStress.setup = function setup() {
			appstoreStress.addTest(appstoreStress._purchaseAppThroughSearching);
			appstoreStress.addTest(appstoreStress._updateAllApps);
			
			// make sure the test store has been selected so we don't accidentaly rack up store charges on someones device
			UIAUtility.logToolOutput("/usr/local/bin/setstore itms2", 5);

		}
		
		appstoreStress.run = function run() {
			appstoreStress.executeRandomTests(2);
		}
		
		// purchase app through searching
		appstoreStress._purchaseAppThroughSearching = function _purchaseAppThroughSearching() {
			var appIndex = system.randomInteger(0, appsList.length - 1);
			var args = new Array (
					appsList[appIndex],
					password,
					appsList[appIndex],
					bundleList[appIndex],
					username
					);
			
			appstoreStress.executeTest( "PurchaseAppThroughSearching", args, 
										appStoreTest_purchaseAppThroughSearching, "Purchase an app by searching." );
		}
		
		// update all apps
		appstoreStress._updateAllApps = function _updateAllApps() {
			appstoreStress.executeTest( "UpdateAllApps", [password], appStoreTest_updateAllApps, "Update all apps.");
		}
	}
}