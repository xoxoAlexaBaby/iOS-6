#!/usr/bin/perl

open (PS, "| /usr/local/bin/h4isp -x");
printf ("$ARGV[1]\n");
printf ("$ARGV[0]\n");

if (1 <= $#ARGV && ($ARGV[1] eq "OFF"))
{
	printf (PS "off\n");
}
elsif (0 <= $#ARGV && ($ARGV[0] eq "FRONT"))
{
	printf (PS "on\n");
	printf (PS "v off\n");
	printf (PS "start 1 8 0\n");
	printf (PS "maxframerate 1 24\n");
	printf (PS "minframerate 1 24\n");
}
elsif (0 <= $#ARGV && ($ARGV[0] eq "REAR"))
{
	printf (PS "on\n");
	printf (PS "v off\n");
	printf (PS "start 0 6 0\n");
	printf (PS "maxframerate 0 24\n");
	printf (PS "minframerate 0 24\n");
}
close (PS);