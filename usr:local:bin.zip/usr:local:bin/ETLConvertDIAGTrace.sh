#!/bin/sh

set -e

hfile="./hash.txt"
hash="-h $hfile"
clean="true"
verb="0"

function usage
{
    echo "\nUsage:\nETLConvertDIAGTrace.sh -d directory_with_raw_files -h compressed_hash_file -m file_to_merge_everything [-t] [-c] [-v number]\n\
        \t-d directory_with_raw_files: The folder containing the DIAG RAW files\n\
        \t-h compressed_hash_file: BZIP2 compressed hash file required to parse QSR msg\n\
        \t-m file_to_merge_everything: Will merge all RAW files into one big file and translate it to DLF\n\
        \t-t Adjust time-stamps based on the start time found in info.txt\n\
	\t-c Clean output directory for *.log\n\
	\t-v Set verbosity for ETLDLFConvertRawToDLF\nNOTE: The parameters must be in the order listed above\n"
    exit -1
}

while getopts d:h:m:v:tc opt
do
   case "$opt" in
      d)
          folder="$OPTARG"
          if [ -e "$folder" ]; then
              allfiles=(`ls -1 "$folder"/*.raw`)
              alltimes=(`grep "Starting From:" "$folder/info.txt" | sed s/Starting.From:.//`)
	  else
	      usage
	  fi
	  ;;
      h)
          hashbz2="$OPTARG"
          if [ -e "$hfile" ]
          then
              echo "Found $hfile, using this instead of compressed hash file..."
	  else
              if [ -e "$hashbz2" ]
              then
                  echo "Uncompressing and cleaning $hashbz2..."
                  bzcat $hashbz2 | grep -v '^[#<]' > "$hfile"
	      else
                  usage
              fi
          fi
	  ;;
      m)
          merge="$OPTARG"
          echo "Merging all files to: $merge"
          rm -f "$merge.raw" "$merge"
          touch "$merge.raw" "$merge"
          for rawfile in "${allfiles[@]}"
          do
              cat "$rawfile" >> "$merge.raw"
          done
	  ;;
      t) 
          ts="-t ${alltimes[0]}"
	  ;;
      c)
          clean="rm -rf ETLConvertRawToDLF.log libTelephony.log"
          ;;
      v)
          verb="$OPTARG"
	  ;;
      [?])  
        usage
	;;
      esac
done

if [ -n "$merge" ]; then
   
   cmd="ETLConvertRawToDLF $merge.raw $merge $hash $ts $verb"
   echo "Executing: $cmd"
   $cmd
   $clean
   echo "Done: $merge"
   rm -f "$merge.raw"
   exit 0
fi

usage
