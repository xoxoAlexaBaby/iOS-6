//Messages Acceptance Test Catalogue.


if (typeof messages.acceptanceTests == 'undefined') {
	messages.acceptanceTests = new Array();
}	

	//	SAMPLE
    //  var date = new Date();
	//	var timestamp = "" + date.getHours() + date.getMinutes() + date.getSeconds();
	//	messages.acceptanceTests.push(phtCreateTest("Messages_Test001", ["Arg-1" + timestamp, "Arg-2"], Messages_doSomeTest, "Test description..."));
	


