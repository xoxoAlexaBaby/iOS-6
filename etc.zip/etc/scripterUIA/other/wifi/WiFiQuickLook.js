#!/usr/local/bin/scripter -uiautomation YES -f

#import "/usr/local/etc/scripterUIA/libs/PHTesting.js"
#import "/usr/local/etc/scripterUIA/libs/HarnessUtility.js"
#import "/usr/local/etc/scripterUIA/settings/SettingsTests.js"
#import "/usr/local/etc/scripterUIA/safari/SafariTests.js"
#import "/usr/local/etc/scripterUIA/mail/MailTests.js"
#import "/usr/local/etc/scripterUIA/springboard/SpringboardTests.js"
#import "/usr/local/etc/scripterUIA/system/SystemTests.js"
#import "/usr/local/etc/scripterUIA/other/wifi/WiFiTests.js"
#import "/usr/local/etc/scripterUIA/youtube/YouTubeTests.js"
#import "/usr/local/etc/scripterUIA/facetime/FaceTimeTests.js"
#import "/usr/local/etc/scripterUIA/maps/MapsTests.js"

var kReportPath = "/var/mobile/Library/Logs/Testing/";
var hasWifi = system.hasCapability('wifi');
//var hasTelephony = system.hasCapability("telephony");

// requires these specific bits of content be on the test device
//var kSongName = "Yesterday";
//var kMovieName = "Trailer H"
//var kMovieSublist = "The Simpsons Movie";
//var kMP4MovieName = "TikiBarTV10-DrinkbotMP4V";
//var kDRMedSongName = "Delerium DRM";
//var kDRMedMovieName = "Nasa DRM";

var start = new Date();
var timeString = start.getTime() + "";  // turn this into a string
var runID = "WiFiQuickLook " + start.toDateString() + " - " + timeString.substr(-6);

//var kSMSBuddy1 = "4083321896";
//var kSMSBuddy2 = "4083323272";

//kStoreUsername = "jsmith.purple@gmail.com";
//kStorePassword = "sugarbowl";

// this is some setup that is required for the sms tests
//globalSMSNumber = telephony.myPhoneNumber;

function addTestsToArray(tests) {
	var defaultNetwork = "AppleWiFi";
	var hiddenNetwork = "123";
	var wpa2Network = "1WPA2";
	var leapNetwork = "MW_Cisco_ACS";
	var hiddenPeapNetwork = "mw ias";
	var iperfNetwork = "abdiperf"
	var iperfServer = "192.168.1.113"
	var hiddenTtlsNetwork = "MW-M48-Odyssey"
	var legacyNetwork = "ABD DLINK G ONLY"
	var beaconNetwork = "WRT54G beacon alignment"
	var beaconNetworkPassword = "12345678"
	var WAPIPSKNetwork = "haiwapipsk"
	var WAPIHEXNetwork = "haiwapiHEX"
	var WAPICertNetwork = "haiwapicert"
	
	var beaconServer = "192.168.1.16"

	var hiddenPassword = "1234567890";
	var wpa2Password = "12345678";
	var leapUsername = "wirelessuser";
	var leapPassword = "wireless@1234567890";
	var legacyPassword = "1234567890";
	var WAPIPSKPassword = "12345678"
	var WAPIHEXPassword = "1234abcd"

	var tempUsername = "abc";
	var tempPassword = "1234567";

	var AbandNetwork = "BH_M52_5N_Only";
	var AbandPassword = "wireless";

	var folder = "ABD";
	var emailTitle = "EAP-TLS MW_Cisco_ACS wirelessuser pre-populated.mobileconfig";
	//var emailTitle = "WiFi ABD, EAP-TLS MW_Cisco_ACS wirelessuser pre-populated.mobileconfig"
	var profileName = "EAP-TLS MW_Cisco_ACS wirelessuser pre-populated.mobileconfig";
	var download_verification_string_Tls = "EAP-TLS MW_Cisco_ACS wirelessuser pre-populated";
	var emailAccount = "wifiabd@gmail.com";
	var timeout = 60;
	var profilePassword = "wireless";

	var folder_EAPFast = "ABD";
	var emailTitle_EAPFast = "MW_Cisco_ACS_EAP_FAST_Anon3_WPA-WPA2_iPCUv2_121";
	var profileName_EAPFast = "MW_Cisco_ACS_eap_fast wpa-wpa2 anon 3.mobileconfig";
	var download_verification_string_EAPFast = "MW_Cisco_ACS_eap_fast wpa/wpa2 anon 3"

	var emailTitle_Ttls = "MW-M48-Odyssey_hidden_root_eap_ttls_pap_iPCUv2_122"
	var profileName_Ttls = "MW-M48-Odyssey_hidden_root_eap_ttls_pap_iPCUv2_122.mobileconfig"
	var download_verification_string_Ttls = "MW-M48-Odyssey_hidden_root_eap_ttls_pap_iPCUv2_122"
	
	var emailTitle_WAPI = "WAPI new cert"
	var profileName_WAPI = "as.cer"
	var profileName_WAPIUser = "ASUE.cer"

	var URL1 = "http://www.yahoo.com";
	var URL2 = "http://www.google.com"
	var ping_destination = "www.google.com"

	var iperf_time = 30;
	var iperf_pass = 3;
	var delay = 25;
	var personalHotspotPassword = "wireless"

	var wifiplistPath = kReportPath + "wifi"
	var wifiplistAfterAutoJoinPath = kReportPath + "wifiAfterWiFiOnOff"
	
	var isChinaDevice = system.hasWiFiCapability("WAPI")

	//WiFi
	tests.push("Test Ask to Join Window with bg WPA2 network " + wpa2Network);
	tests.push(phtCreateTest("Join WPA2 network from Ask To Join Window " + wpa2Network, ["com.apple.mobilesafari", wpa2Network, wpa2Password], springboardTest_joinWiFiFromAskToJoinWindow, "Join WPA2 network from Ask To Join Window: " + wpa2Network));
	tests.push(phtCreateTest("LoadSafariPage", [URL1], safariTest_loadSafariPage, "Load web page in Safari"));
	tests.push(phtCreateTest("WiFiInterfaceActiveTest", null, systemTest_isWiFiInterfaceActive, "Check if WiFi Interface is active"));
	tests.push(phtCreateTest("PingTests", [ping_destination], systemTest_ping, "Ping " + ping_destination));
	//Forget the wpa2 network
	tests.push(phtCreateTest("Forget " + wpa2Network, [wpa2Network], settingsTest_forgetWifi, "Forget " + wpa2Network));
	
	if (isChinaDevice) {
		tests.push("Test with China devices for using WLAN on UI");
		tests.push(phtCreateTest("WAPIUI", null, settingsTest_checkWAPIUI, "Check China devices use WLAN on UI"));
		
		tests.push("Test with China devices for WAPI PSK");
		tests.push(phtCreateTest("WAPIPSK", [1, WAPIPSKNetwork, WAPIPSKPassword, "WAPI"], settingsTest_setWifiPro, "Associated with WAPI PSK network "+WAPIPSKNetwork));
		tests.push(phtCreateTest("LoadSafariPage", [URL1], safariTest_loadSafariPage, "Load web page in Safari"));
		tests.push(phtCreateTest("WiFiInterfaceActiveTest", null, systemTest_isWiFiInterfaceActive, "Check if WiFi Interface is active"));
		tests.push(phtCreateTest("PingTests", [ping_destination], systemTest_ping, "Ping " + ping_destination));
		tests.push(phtCreateTest("Turn Off WiFi", [0], settingsTest_setWifi, "Turn Off WiFi"));
		tests.push(phtCreateTest("Turn On WiFi", [1], settingsTest_setWifi, "Turn On WiFi"));
		tests.push(phtCreateTest("LoadSafariPage2", [URL2], safariTest_loadSafariPage, "Load web page in Safari"));
		tests.push(phtCreateTest("Auto Join with " + WAPIPSKNetwork, [WAPIPSKNetwork], settingsTest_checkSSID, "Auto Join with " + WAPIPSKNetwork));
		tests.push(phtCreateTest("WiFiInterfaceActiveTest", null, systemTest_isWiFiInterfaceActive, "Check if WiFi Interface is active"));
		tests.push(phtCreateTest("Forget " + WAPIPSKNetwork, [WAPIPSKNetwork], settingsTest_forgetWifi, "Forget " + WAPIPSKNetwork));
		
		tests.push("Test with China devices for WAPI HEX");
		tests.push(phtCreateTest("WAPIHEX", [1, WAPIHEXNetwork, WAPIHEXPassword, "WAPI"], settingsTest_setWifiPro, "Associated with WAPI HEX network "+WAPIHEXNetwork));
		tests.push(phtCreateTest("LoadSafariPage", [URL1], safariTest_loadSafariPage, "Load web page in Safari"));
		tests.push(phtCreateTest("WiFiInterfaceActiveTest", null, systemTest_isWiFiInterfaceActive, "Check if WiFi Interface is active"));
		tests.push(phtCreateTest("PingTests", [ping_destination], systemTest_ping, "Ping " + ping_destination));
		tests.push(phtCreateTest("Forget " + WAPIHEXNetwork, [WAPIHEXNetwork], settingsTest_forgetWifi, "Forget " + WAPIHEXNetwork));
		
		tests.push("Test with China devices for enterprise WAPI network " + WAPICertNetwork);
		//Associate with default WiFi network to download profile
		tests.push(phtCreateTest("Associate with default " + defaultNetwork, [1, defaultNetwork], settingsTest_setWifiPro, "Associate with " + defaultNetwork));
		tests.push(phtCreateTest("PingTests", [ping_destination], systemTest_ping, "Ping " + ping_destination));
		tests.push(phtCreateTest("downloadWAPIProfileFromMail", [emailTitle_WAPI, profileName_WAPI, "account:" + emailAccount, "folder:" + folder, "timeout:" + timeout, "noVerification:true", "waitForMailTimeout:" + timeout], mailTest_downloadMailAttachment, "Download WAPI Root Cert from mail attachment"));
		tests.push(phtCreateTest("installWAPIProfile", null, settingsTest_installProfile, "Install the WAPI Root Cert"));
		tests.push(phtCreateTest("downloadWAPIProfileFromMail", [emailTitle_WAPI, profileName_WAPIUser, "account:" + emailAccount, "folder:" + folder, "timeout:" + timeout, "noVerification:true", "waitForMailTimeout:" + timeout], mailTest_downloadMailAttachment, "Download WAPI User Cert from mail attachment"));
		tests.push(phtCreateTest("installWAPIUserProfile", null, settingsTest_installProfile, "Install the WAPI User Cert"));
		tests.push(phtCreateTest("Associate with WAPI enterprise network using certs " + WAPICertNetwork, [1, WAPICertNetwork, "0", "WAPI enterprise"], settingsTest_setWifiPro, "Associate with WAPI enterprise network use certs " + WAPICertNetwork));
		tests.push(phtCreateTest("LoadSafariPage", [URL1], safariTest_loadSafariPage, "Load web page in Safari"));
		tests.push(phtCreateTest("WiFiInterfaceActiveTest", null, systemTest_isWiFiInterfaceActive, "Check if WiFi Interface is active"));
		tests.push(phtCreateTest("PingTests", [ping_destination], systemTest_ping, "Ping " + ping_destination));
		//Forget the default WiFi network
		tests.push(phtCreateTest("Forget default " + defaultNetwork, [defaultNetwork], settingsTest_forgetWifi, "Forget " + defaultNetwork));
		tests.push(phtCreateTest("Forget " + WAPICertNetwork, [WAPICertNetwork], settingsTest_forgetWifi, "Forget " + WAPICertNetwork));
		tests.push(phtCreateTest("deleteAllProfiles", null, settingsTest_deleteProfile, "Delete All the Profiles"));
	}
	
	tests.push("Test with hidden bg network " + hiddenNetwork + " WEP 40bit");
	tests.push(phtCreateTest("Associate with hidden network " + hiddenNetwork, [1, hiddenNetwork, hiddenPassword, "hidden", "WEP"], settingsTest_setWifiPro, "Associate with hidden network " + hiddenNetwork));
	tests.push(phtCreateTest("LoadSafariPage", [URL1], safariTest_loadSafariPage, "Load web page in Safari"));
	tests.push(phtCreateTest("WiFiInterfaceActiveTest", null, systemTest_isWiFiInterfaceActive, "Check if WiFi Interface is active"));
	tests.push(phtCreateTest("SaveWiFiPlistTest", [wifiplistPath + hiddenNetwork + ".plist"], wifiTest_wifiplist, "Save the plist"));
	tests.push(phtCreateTest("PingTests", [ping_destination], systemTest_ping, "Ping " + ping_destination));
	tests.push(phtCreateTest("Turn Off WiFi", [0], settingsTest_setWifi, "Turn Off WiFi"));
	tests.push(phtCreateTest("Turn On WiFi", [1], settingsTest_setWifi, "Turn On WiFi"));
	tests.push(phtCreateTest("LoadSafariPage2", [URL2], safariTest_loadSafariPage, "Load web page in Safari"));
	tests.push(phtCreateTest("Auto Join with " + hiddenNetwork, [hiddenNetwork], settingsTest_checkSSID, "Auto Join with " + hiddenNetwork));
	tests.push(phtCreateTest("WiFiInterfaceActiveTest", null, systemTest_isWiFiInterfaceActive, "Check if WiFi Interface is active"));
	tests.push(phtCreateTest("SaveWiFiPlistTestAfterWiFiOnOff", [wifiplistAfterAutoJoinPath + hiddenNetwork + ".plist"], wifiTest_wifiplist, "Save the plist after WiFi On Off"));
	tests.push(phtCreateTest("PingTests", [ping_destination], systemTest_ping, "Ping " + ping_destination));

	tests.push("Test with default network " + defaultNetwork);
	tests.push(phtCreateTest("Associate with " + defaultNetwork, [1, defaultNetwork], settingsTest_setWifiPro, "Associate with " + defaultNetwork));
	tests.push(phtCreateTest("LoadSafariPage", [URL1], safariTest_loadSafariPage, "Load web page in Safari"));
	tests.push(phtCreateTest("WiFiInterfaceActiveTest", null, systemTest_isWiFiInterfaceActive, "Check if WiFi Interface is active"));
	tests.push(phtCreateTest("PingTests", [ping_destination], systemTest_ping, "Ping " + ping_destination));
	tests.push(phtCreateTest("MapGetCurrentLocation", null, mapsTest_getCurrentLocation, "Get your current location on MAP"));

	//add airplane mode test 
	tests.push("Test with default network " + defaultNetwork + " with Airplane Mode On Off");
	tests.push(phtCreateTest("TurnAirplaneModeOn", ["Airplane Mode", 1], settingsTest_changeSingleSwitch, "Turn Airplane Mode ON")); 
	tests.push(phtCreateTest("TurnAirplaneModeOff", ["Airplane Mode", 0], settingsTest_changeSingleSwitch, "Turn Airplane Mode OFF"));
	tests.push(phtCreateTest("Auto Join with " + defaultNetwork, [defaultNetwork], settingsTest_checkSSID, "Auto Join with " + defaultNetwork));
	tests.push(phtCreateTest("LoadSafariPage", [URL1], safariTest_loadSafariPage, "Load web page in Safari"));
	tests.push(phtCreateTest("WiFiInterfaceActiveTest", null, systemTest_isWiFiInterfaceActive, "Check if WiFi Interface is active"));
	tests.push(phtCreateTest("PingTests", [ping_destination], systemTest_ping, "Ping " + ping_destination));

	var VCisSupported = system.deviceType.match(/N90.*|N92.*/)

	if(VCisSupported) {
		tests.push("Test VC with " + defaultNetwork);
		tests.push(phtCreateTest("FTCall", [ "VC Auto", false, "All Contacts", "20"], facetimeTest_makeVideoCallToContact, "Facetime Test for 20 seconds"));
		tests.push(phtCreateTest("FTEnd", null, facetimeTest_endVideoCall, "End Facetime call"));
	}

	//Forget the hidden network
	tests.push(phtCreateTest("Forget " + hiddenNetwork, [hiddenNetwork], settingsTest_forgetWifi, "Forget " + hiddenNetwork));

	tests.push(phtCreateTest("Turn Off WiFi", [0], settingsTest_setWifi, "Turn Off WiFi"));
	tests.push(phtCreateTest("Turn On WiFi", [1], settingsTest_setWifi, "Turn On WiFi"));
	tests.push(phtCreateTest("LoadSafariPage2", [URL2], safariTest_loadSafariPage, "Load web page in Safari"));
	tests.push(phtCreateTest("Auto Join with " + defaultNetwork, [defaultNetwork], settingsTest_checkSSID, "Auto Join with " + defaultNetwork));
	tests.push(phtCreateTest("WiFiInterfaceActiveTest", null, systemTest_isWiFiInterfaceActive, "Check if WiFi Interface is active"));
	tests.push(phtCreateTest("PingTests", [ping_destination], systemTest_ping, "Ping " + ping_destination));
	
	PersonalHotspotIsSupported = system.deviceType.match(/N90.*|N92.*/)
	if (PersonalHotspotIsSupported) {
		//WiFi Hotspot tests
		tests.push("Personal Hotspot Tests");
		tests.push(phtCreateTest("Enable Personal Hotspot", [1, personalHotspotPassword], settingsTest_setPersonalHotspot, "Enable Personal Hotspot"));
		tests.push(phtCreateTest("Disable Personal Hotspot", [0], settingsTest_setPersonalHotspot, "Disable Personal Hotspot"));
		tests.push(phtCreateTest("Auto Join after disable Personal Hotspot with " + defaultNetwork, [defaultNetwork], settingsTest_checkSSID, "Auto Join after disable Personal Hotspot with " + defaultNetwork));
		tests.push(phtCreateTest("Personal Hotspot Timer", [defaultNetwork, personalHotspotPassword], settingsTest_personalHotspotTimer, "Auto Join after 90 seconds Personal Hotspot Timer"));
		tests.push(phtCreateTest("WiFiInterfaceActiveTest", null, systemTest_isWiFiInterfaceActive, "Check if WiFi Interface is active"));
		tests.push(phtCreateTest("PingTests", [ping_destination], systemTest_ping, "Ping " + ping_destination));
	}
	
	tests.push(phtCreateTest("Forget " + defaultNetwork, [defaultNetwork], settingsTest_forgetWifi, "Forget " + defaultNetwork));

	if(system.hasWiFiCapability("Aband")){
		tests.push("Test with A band N Mode network " + AbandNetwork);
		tests.push(phtCreateTest("Associate with " + AbandNetwork, [1, AbandNetwork, AbandPassword], settingsTest_setWifiPro, "Associate with " + AbandNetwork));

		if(system.hasWiFiCapability("N")){
			tests.push(phtCreateTest("Check association using N rate with network " + AbandNetwork, null, wifiTest_associateNRate, "Check association using N rate with network " + AbandNetwork));
		}
		tests.push(phtCreateTest("LoadSafariPage", [URL1], safariTest_loadSafariPage, "Load web page in Safari"));
		tests.push(phtCreateTest("WiFiInterfaceActiveTest", null, systemTest_isWiFiInterfaceActive, "Check if WiFi Interface is active"));
		tests.push(phtCreateTest("PingTests", [ping_destination], systemTest_ping, "Ping " + ping_destination));
		tests.push(phtCreateTest("Turn Off WiFi", [0], settingsTest_setWifi, "Turn Off WiFi"));
		tests.push(phtCreateTest("Turn On WiFi", [1], settingsTest_setWifi, "Turn On WiFi"));
		tests.push(phtCreateTest("LoadSafariPage2", [URL2], safariTest_loadSafariPage, "Load web page in Safari"));
		tests.push(phtCreateTest("Auto Join with " + AbandNetwork, [AbandNetwork], settingsTest_checkSSID, "Auto Join with " + AbandNetwork));
		if(system.hasWiFiCapability("N")){
			tests.push(phtCreateTest("Check association using N rate with network " + AbandNetwork, null, wifiTest_associateNRate, "Check association using N rate with network " + AbandNetwork));
		}

		tests.push(phtCreateTest("WiFiInterfaceActiveTest", null, systemTest_isWiFiInterfaceActive, "Check if WiFi Interface is active"));
		tests.push(phtCreateTest("PingTests", [ping_destination], systemTest_ping, "Ping " + ping_destination));
		tests.push(phtCreateTest("Forget " + AbandNetwork, [AbandNetwork], settingsTest_forgetWifi, "Forget " + AbandNetwork));
	}
	
	//Add low coverage RSSI -75 legacy AP test
	tests.push("Test with low signal legacy g network " + legacyNetwork + " WEP 40bit");
	tests.push(phtCreateTest("Associate with low signal legacy g network " + legacyNetwork, ["ON", legacyNetwork, legacyPassword, "hidden", "WEP"], settingsTest_setWifiPro, "Associate with low signal legacy g network " + legacyNetwork));
	tests.push(phtCreateTest("Check RSSI with low signal legacy g network " + legacyNetwork, [legacyNetwork], wifiTest_getRSSI, "Check RSSI with low signal legacy g network " + legacyNetwork));
	tests.push(phtCreateTest("LoadSafariPage", [URL1], safariTest_loadSafariPage, "Load web page in Safari"));
	tests.push(phtCreateTest("WiFiInterfaceActiveTest", null, systemTest_isWiFiInterfaceActive, "Check if WiFi Interface is active"));
	tests.push(phtCreateTest("PingTests", [ping_destination], systemTest_ping, "Ping " + ping_destination));
	tests.push(phtCreateTest("Turn Off WiFi", [0], settingsTest_setWifi, "Turn Off WiFi"));;
	tests.push(phtCreateTest("Turn On WiFi", [1], settingsTest_setWifi, "Turn On WiFi"));
	tests.push(phtCreateTest("LoadSafariPage2", [URL2], safariTest_loadSafariPage, "Load web page in Safari"));
	tests.push(phtCreateTest("Auto Join with " + legacyNetwork, [legacyNetwork], settingsTest_checkSSID, "Auto Join with " + legacyNetwork));
	tests.push(phtCreateTest("WiFiInterfaceActiveTest", null, systemTest_isWiFiInterfaceActive, "Check if WiFi Interface is active"));
	tests.push(phtCreateTest("PingTests", [ping_destination], systemTest_ping, "Ping " + ping_destination));
	if (!isChinaDevice) {
		tests.push(phtCreateTest("YouTubeTests", [20, 1, true, "Featured"], youtubeTest_playVideosInYouTubeCategory, "Play a radom video from YouTube Featured"));
	}
	tests.push(phtCreateTest("Forget " + legacyNetwork, [legacyNetwork], settingsTest_forgetWifi, "Forget " + legacyNetwork));
	
	tests.push("iperf test " + iperfNetwork);
	tests.push(phtCreateTest("Associate with " + iperfNetwork, [1, iperfNetwork], settingsTest_setWifiPro, "Associate with " + iperfNetwork));
	tests.push(phtCreateTest("Ping iperf server " + iperfServer, [iperfServer], systemTest_ping, "Ping to " + iperfServer));
	tests.push(phtCreateTest("Run iperf to " + iperfServer, [iperfServer, iperf_time, iperf_pass], wifiTest_iperf, "Run iperf to " + iperfNetwork + " (reports fail if get less than "+iperf_pass+"Mbps)"));
	tests.push(phtCreateTest("Forget " + iperfNetwork, [iperfNetwork], settingsTest_forgetWifi, "Forget " + iperfNetwork));
	
	//add beacon alignment ping test
	tests.push("Beacon alignment ping test " + beaconNetwork);
	tests.push(phtCreateTest("Associate with " + beaconNetwork, [1, beaconNetwork, beaconNetworkPassword], settingsTest_setWifiPro, "Associate with " + beaconNetwork));
	tests.push(phtCreateTest("Ping WRT54G router " + beaconServer, [beaconServer], systemTest_ping, "Ping to " + beaconServer));
	tests.push(phtCreateTest("Fast Ping WRT54G router " + beaconServer, [beaconServer, 5], wifiTest_fastping, "Fast Ping to " + beaconServer));
	tests.push(phtCreateTest("Forget " + beaconNetwork, [beaconNetwork], settingsTest_forgetWifi, "Forget " + beaconNetwork));

	tests.push("Test with enterprise LEAP bg network " + leapNetwork);
	tests.push(phtCreateTest("Associate with enterprise LEAP network " + leapNetwork, [1, leapNetwork, tempPassword, "enterprise", "none", tempUsername], settingsTest_setWifiPro, "Associate with enterprise network " + leapNetwork));
	tests.push(phtCreateTest("LoadSafariPage", [URL1], safariTest_loadSafariPage, "Load web page in Safari"));
	tests.push(phtCreateTest("WiFiInterfaceActiveTest", null, systemTest_isWiFiInterfaceActive, "Check if WiFi Interface is active"));
	tests.push(phtCreateTest("eapolmethodLEAP", ["LEAP"], wifiTest_eapolmethod, "Check if eapol method is LEAP"));
	tests.push(phtCreateTest("PingTests", [ping_destination], systemTest_ping, "Ping " + ping_destination));
	tests.push(phtCreateTest("Forget " + leapNetwork, [leapNetwork], settingsTest_forgetWifi, "Forget " + leapNetwork));

	tests.push("Test with hidden enterprise bgn PEAP network " + hiddenPeapNetwork);
	tests.push(phtCreateTest("Associate with hidden enterprise PEAP network " + hiddenPeapNetwork, [1, hiddenPeapNetwork, tempPassword, "hidden", "WPA2 Enterprise", tempUsername], settingsTest_setWifiPro, "Associate with hidden enterprise PEAP network " + hiddenPeapNetwork));
	if(system.hasWiFiCapability("N")){
		tests.push(phtCreateTest("Check association using N rate with network " + hiddenPeapNetwork, null, wifiTest_associateNRate, "Check association using N rate with network " + hiddenPeapNetwork));
	}

	tests.push(phtCreateTest("LoadSafariPage", [URL1], safariTest_loadSafariPage, "Load web page in Safari"));
	tests.push(phtCreateTest("WiFiInterfaceActiveTest", null, systemTest_isWiFiInterfaceActive, "Check if WiFi Interface is active"));
	tests.push(phtCreateTest("SaveWiFiPlistTest", [wifiplistPath + hiddenPeapNetwork + ".plist"], wifiTest_wifiplist, "Save the plist"));
	tests.push(phtCreateTest("eapolmethodPEAP", ["PEAP"], wifiTest_eapolmethod, "Check if eapol method is PEAP"));
	tests.push(phtCreateTest("PingTests", [ping_destination], systemTest_ping, "Ping " + ping_destination));
	tests.push(phtCreateTest("Turn Off WiFi", [0], settingsTest_setWifi, "Turn Off WiFi"));
	tests.push(phtCreateTest("Turn On WiFi", [1], settingsTest_setWifi, "Turn On WiFi"));
	tests.push(phtCreateTest("LoadSafariPage2", [URL2], safariTest_loadSafariPage, "Load web page in Safari"));
	tests.push(phtCreateTest("Auto Join with " + hiddenPeapNetwork, [hiddenPeapNetwork], settingsTest_checkSSID, "Auto Join with " + hiddenPeapNetwork));
	if(system.hasWiFiCapability("N")){
		tests.push(phtCreateTest("Check association using N rate with network " + hiddenPeapNetwork, null, wifiTest_associateNRate, "Check association using N rate with network " + hiddenPeapNetwork));
	}
	tests.push(phtCreateTest("WiFiInterfaceActiveTest", null, systemTest_isWiFiInterfaceActive, "Check if WiFi Interface is active"));
	tests.push(phtCreateTest("SaveWiFiPlistTestAfterWiFiOnOff", [wifiplistAfterAutoJoinPath + hiddenPeapNetwork + ".plist"], wifiTest_wifiplist, "Save the plist after WiFi On Off"));
	tests.push(phtCreateTest("eapolmethodPEAP2", ["PEAP"], wifiTest_eapolmethod, "Check if eapol method is PEAP"));
	tests.push(phtCreateTest("PingTests", [ping_destination], systemTest_ping, "Ping " + ping_destination));
	tests.push(phtCreateTest("Forget " + hiddenPeapNetwork, [hiddenPeapNetwork], settingsTest_forgetWifi, "Forget " + hiddenPeapNetwork));
	
	tests.push("Test with enterprise TLS network using profile " + leapNetwork);
	//Associate with default WiFi network to download profile
	tests.push(phtCreateTest("Associate with default " + defaultNetwork, [1, defaultNetwork], settingsTest_setWifiPro, "Associate with " + defaultNetwork));
	tests.push(phtCreateTest("PingTests", [ping_destination], systemTest_ping, "Ping " + ping_destination));
	tests.push(phtCreateTest("downloadEAPTLSProfileFromMail", [emailTitle, profileName, "account:" + emailAccount, "folder:" + folder, "timeout:" + timeout, "noVerification:true", "waitForMailTimeout:" + timeout], mailTest_downloadMailAttachment, "Download EAP-TLS profile from mail attachment"));
	tests.push(phtCreateTest("installEAPTLSProfile", [profilePassword], settingsTest_installProfile, "Install the current profiles"));
	tests.push(phtCreateTest("Associate with enterprise TLS network using profile " + leapNetwork, [1, leapNetwork, "0", "profile", "none"], settingsTest_setWifiPro, "Associate with TLS enterprise network use profile " + leapNetwork));
	//Forget the default WiFi network
	tests.push(phtCreateTest("Forget default " + defaultNetwork, [defaultNetwork], settingsTest_forgetWifi, "Forget " + defaultNetwork));
	tests.push(phtCreateTest("LoadSafariPage", [URL1], safariTest_loadSafariPage, "Load web page in Safari"));
	tests.push(phtCreateTest("WiFiInterfaceActiveTest", null, systemTest_isWiFiInterfaceActive, "Check if WiFi Interface is active"));
	tests.push(phtCreateTest("eapolmethodTLS", ["TLS"], wifiTest_eapolmethod, "Check if eapol method is TLS"));
	tests.push(phtCreateTest("PingTests", [ping_destination], systemTest_ping, "Ping " + ping_destination));
	tests.push(phtCreateTest("Turn Off WiFi", [0], settingsTest_setWifi, "Turn Off WiFi"));
	tests.push(phtCreateTest("Turn On WiFi", [1], settingsTest_setWifi, "Turn On WiFi"));
	tests.push(phtCreateTest("LoadSafariPage2", [URL2], safariTest_loadSafariPage, "Load web page in Safari"));
	tests.push(phtCreateTest("Auto Join with " + leapNetwork, [leapNetwork], settingsTest_checkSSID, "Auto Join with " + leapNetwork));
	tests.push(phtCreateTest("WiFiInterfaceActiveTest", null, systemTest_isWiFiInterfaceActive, "Check if WiFi Interface is active"));
	tests.push(phtCreateTest("eapolmethodTLS2", ["TLS"], wifiTest_eapolmethod, "Check if eapol method is TLS"));
	tests.push(phtCreateTest("PingTests", [ping_destination], systemTest_ping, "Ping " + ping_destination));
	// Delete all the profiles
	tests.push(phtCreateTest("deleteAllProfiles", null, settingsTest_deleteProfile, "Delete All the Profiles"));
	
	tests.push("Test with enterprise EAP-Fast network using profile " + leapNetwork);
	//Associate with default WiFi network to download profile
	tests.push(phtCreateTest("Associate with default " + defaultNetwork, [1, defaultNetwork], settingsTest_setWifiPro, "Associate with " + defaultNetwork));
	tests.push(phtCreateTest("PingTests", [ping_destination], systemTest_ping, "Ping " + ping_destination));
	tests.push(phtCreateTest("downloadEAPFastProfileFromMail", [emailTitle_EAPFast, profileName_EAPFast, "account:"+emailAccount, "folder:"+folder, "timeout:"+timeout, "noVerification:true", "waitForMailTimeout:"+timeout], mailTest_downloadMailAttachment, "Download EAP-Fast profile from mail attachment"));
	tests.push(phtCreateTest("installEAPFastProfile", [leapPassword], settingsTest_installProfile, "Install the current profiles"));
	tests.push(phtCreateTest("Associate with enterprise EAP-Fast network using profile " + leapNetwork, [1, leapNetwork, "0", "profile", "none"], settingsTest_setWifiPro, "Associate with EAP-Fast enterprise network use profile " + leapNetwork));
	//Forget the default WiFi network
	tests.push(phtCreateTest("Forget default " + defaultNetwork, [defaultNetwork], settingsTest_forgetWifi, "Forget " + defaultNetwork));
	tests.push(phtCreateTest("LoadSafariPage", [URL1], safariTest_loadSafariPage, "Load web page in Safari"));
	tests.push(phtCreateTest("WiFiInterfaceActiveTest", null, systemTest_isWiFiInterfaceActive, "Check if WiFi Interface is active"));
	tests.push(phtCreateTest("eapolmethodEAPFast", ["EAP-FAST"], wifiTest_eapolmethod, "Check if eapol method is EAP-FAST"));
	tests.push(phtCreateTest("PingTests", [ping_destination], systemTest_ping, "Ping " + ping_destination));
	// Delete all the profiles
	tests.push(phtCreateTest("deleteAllProfiles", null, settingsTest_deleteProfile, "Delete All the Profiles"));
	
	tests.push("Test with enterprise hidden EAP-TTLS bgn network using profile " + hiddenTtlsNetwork);
	//Associate with default WiFi network to download profile
	tests.push(phtCreateTest("Associate with default " + defaultNetwork, [1, defaultNetwork], settingsTest_setWifiPro, "Associate with " + defaultNetwork));
	tests.push(phtCreateTest("PingTests", [ping_destination], systemTest_ping, "Ping " + ping_destination));
	tests.push(phtCreateTest("downloadEAPTttlsProfileFromMail", [emailTitle_Ttls, profileName_Ttls, "account:"+emailAccount, "folder:"+folder, "timeout:"+timeout, "noVerification:true", "waitForMailTimeout:"+timeout], mailTest_downloadMailAttachment, "Download EAP-TTLS profile from mail attachment"));
	tests.push(phtCreateTest("installEAPTttlsProfile", [leapPassword], settingsTest_installProfile, "Install the current profiles"));
	tests.push(phtCreateTest("Associate with enterprise hidden EAP-TTLS network using profile " + hiddenTtlsNetwork, [1, hiddenTtlsNetwork, "0", "profile", "none"], settingsTest_setWifiPro, "Associate with EAP-TTLS enterprise hidden network use profile " + hiddenTtlsNetwork));
	if(system.hasWiFiCapability("N")){
		tests.push(phtCreateTest("Check association using N rate with network " + hiddenTtlsNetwork, null, wifiTest_associateNRate, "Check association using N rate with network " + hiddenTtlsNetwork));
	}
	//Forget the default WiFi network
	tests.push(phtCreateTest("Forget default " + defaultNetwork, [defaultNetwork], settingsTest_forgetWifi, "Forget " + defaultNetwork));
	tests.push(phtCreateTest("LoadSafariPage", [URL1], safariTest_loadSafariPage, "Load web page in Safari"));
	tests.push(phtCreateTest("WiFiInterfaceActiveTest", null, systemTest_isWiFiInterfaceActive, "Check if WiFi Interface is active"));
	tests.push(phtCreateTest("eapolmethodTTLS", ["TTLS"], wifiTest_eapolmethod, "Check if eapol method is TTLS"));
	tests.push(phtCreateTest("PingTests", [ping_destination], systemTest_ping, "Ping " + ping_destination));
	// Delete all the profiles
	tests.push(phtCreateTest("deleteAllProfiles", null, settingsTest_deleteProfile, "Delete All the Profiles"));

}

function usage() {
	
	system.println("usage: QuickLook.js [--enable <string>] [--disable <string>] [-o <path> | -filepath <path> | --filename <string>] [-l | --list]");
	system.println("	--disable	tests to skip (may use regex to describe tests)");
	system.println("	--enable	tests to run (may use regex to describe tests)");
	system.println("	--filepath	full path for the results file");
	system.println("	--filename	name to use for the results file");
	system.println("	--nosetup	skip the setup phase of the QuickLook")
	system.println("	--noemailsetup	skip the setup email account of the QuickLook")
	system.println("	--writecrashes	write out crashes to the results file")
	system.println("	--list		list the available tests");
	system.println("	--help | -h	usage description");
}

function main() {
	
	var tests = new Array();
	var version = harness_getBuildVersion();
	var filename = "WiFiQuickLook_" + version + ".txt";
	var writeCrashes = false;
	var filepath;
	var enableSetup = true;
	var enableEmailSetup = true;
	var defaultNetwork = "AppleWiFi";
	
	// seed the generator, so that any random events are the same for every run
	system.setRandomSeed(1);
	UIATarget.localTarget().unlockScreenIfNecessary();	// screen must be unlocked to check for springboard app icons
	
	// process command line arguments
	var options = new Options();
	if (options.help || options.h) {
		usage();
		return;
	}
	if (options.list || options.l) {
		addTestsToArray(tests);
		harness_listTests(tests);
		return;
	}
	if (options.filename) filename = options.filename;
	if (options.nosetup) enableSetup = false;
	if (options.writecrashes) writeCrashes = true;
	if (options.noemailsetup) enableEmailSetup = false;
	if (options.o) filepath = options.o;
	else if (options.filepath) filepath = options.filepath;
	else {
		harness_makeDirectory(kReportPath);
		filepath = kReportPath + filename;
	}
	
	// if setup is enabled, add the setup tests to the test array.
	if (enableSetup) {
		
		// Unlock the device
		tests.push("Setup");
		//tests.push(phtCreateTest("UnlockDevice", ["0"], systemTest_lockAndUnlockDevice, "Unlock the device")); 
		// Set auto-lock to never
		tests.push(phtCreateTest("SetAutoLockToNever", ["General", "Auto-Lock", "Never"], settingsTest_chooseCheckmarkedItem, "Set Auto-Lock to Never"));	
			
		// Associate with default network and create email account used for profile
		if(enableEmailSetup) {
					
			// Enabled Known Network UI from Internal Settings
			//tests.push(phtCreateTest("enabledWiFiKnownNetowrkUI", ["Internal Settings", "Settings", "Known Networks UI", 1], settingsTest_changeSingleSwitch, "Enable WiFi Known Network UI from Internal Settings"));
			tests.push(phtCreateTest("EnableWifiLogging", ["Internal Settings", "WiFi", "Logging", "UI Logging", 1], settingsTest_changeSingleSwitch, "Enable Wifi Logging"));
			tests.push(phtCreateTest("EnableWifiManagerLogging", ["Internal Settings", "WiFi", "Logging", "WiFi Manager", "Logging", 1], settingsTest_changeSingleSwitch, "Enable WifiManager Logging"));
			
			tests.push("Configure Email address, Associate with" + defaultNetwork);
			tests.push(phtCreateTest("Configure Email address, Associate with " + defaultNetwork, [1, defaultNetwork], settingsTest_setWifiPro, "Associate with " + defaultNetwork));
			tests.push(phtCreateTest("CreateGmailAccount", ["gmail","wifiabd","wifiabd@gmail.com", "wireless"], settingsTest_createEmailAccount, "Create a wifiabd@gmail.com email account"));
		}
		
		// Delete all the profiles
		tests.push(phtCreateTest("deleteAllProfiles", null, settingsTest_deleteProfile, "Delete All the Profiles"));
		
		//Remove all the preferred WiFi network (Enterprise Netowrk using profiles not included) from Known Network UI
		//tests.push(phtCreateTest("deletePrefferedWiFiNetwork", [], settingsTest_deletePreferredNetwork, "Delete Preferred WiFi Netowrk"));
		tests.push(phtCreateTest("deletePrefferedWiFiNetwork", ["wifi.removeAllPreferredNetworks"], wifiTest_wirelessTester, "Delete Preferred WiFi Netowrk use WirelessTester"));
		tests.push(phtCreateTest("EnableCoreLocation", ["corelocation.setLocationServicesEnabled:", "-bool Yes"], wifiTest_wirelessTester, "Enable Core Location Services use WirelessTester"));
	}
	
	addTestsToArray(tests); // add all of the normal tests to the array
	
	// uncomment this line if you want top data added to the output
	//system.setDefault("com.apple.harness", "utilities", ["/usr/bin/top -o -cpu -l 1"]);
	
	harness_removeFile(filepath);
	harness_runTestsFromArray(tests, filepath, options.disable, options.enable, false, writeCrashes);
	
	system.println("Done Running QuickLook.");
}

main();
