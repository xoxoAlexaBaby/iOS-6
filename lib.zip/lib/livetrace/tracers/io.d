#pragma D option quiet
#pragma D option strsize=64
#pragma D option bufsize=512k
#pragma D option dynvarsize=64k
#pragma D option aggsize=64k

/* @description Trace IO request start and completions */

io:::start
{
    printf("%d %s %08x io_start %08x - %c %s %d at %d (%08x)\n", timestamp, execname, (uint32_t) curthread, (uint32_t) arg0, (args[0]->b_flags & B_READ) ? 'R' : 'W', args[2]->fi_name, args[0]->b_bcount, args[2]->fi_offset, args[0]->b_flags);
}

io:::done
{
    printf("%d %s %08x io_done %08x %s\n", timestamp, execname, (uint32_t) curthread, (uint32_t) arg0, args[2]->fi_name);
}
