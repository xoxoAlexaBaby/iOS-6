
# powerprofiler_base.sh
# 
# serves as a library of code for powerprofiler.sh

# Are we running on an M68?
ioreg -w0 -l |grep M68AP
if [ "$?" = "0" ]
then
	export M68AP=1
else
	export M68AP=0
fi
echo "Are we on M68?  $M68AP"

export AS_ALLOW_MULTI_SCREENSHOTS=1

_connect_to_wifi()
{
	if [ "$WIFI_PASS" = "" ]
	then
		scripter -f /usr/local/etc/scripter/general/ExecuteTest.js settingsTest_setWifi "ON" $WIFI_AP
	else
		scripter -f /usr/local/etc/scripter/general/ExecuteTest.js settingsTest_setWifi "ON" $WIFI_AP $WIFI_PASS
	fi
	
	apple80211 --ssid
	if [ "$?" = "0" ]
	then
		echo "Successfully connected to Wi-Fi."
	else
		#scripter -f /usr/local/etc/scripter/general/ExecuteTest.js smsTest_sendReceiveSMS
		echo "Failed to connect to Wi-Fi."
		exit
	fi
}


reset_power_config()
{
	echo "Resetting power config..."
	#default power config is Wi-Fi on, 2G enabled, Bluetooth off and auto-lock set to 1 minute.
	
	# if we're on a 3G phone, disable 3G
	if [ "$M68AP" = "0" ]
	then
		scripter -f /usr/local/etc/scripter/general/ExecuteTest.js settingsTest_ChangeSingleSwitch "General" "Enable 3G" "OFF" "Network"
	fi
	
	_connect_to_wifi
	scripter -f /usr/local/etc/scripter/general/ExecuteTest.js settingsTest_chooseCheckmarkedItem "General" "5 Minutes" "Auto-Lock"
	echo "Done resetting power config."
}


_browse()
{
	START_TIME=`date +%s`
	DURATION=$((60 * $1))
	END_TIME=$(($START_TIME + $DURATION))
	CURRENT_TIME=$START_TIME
	
	while [ $CURRENT_TIME -lt $END_TIME ] ; do
		scripter -f /usr/local/etc/scripter/general/ExecuteTest.js safariTest_loadSafariPage "http://www.apple.com/iphone";
		scripter -f /usr/local/etc/scripter/general/ExecuteTest.js safariTest_loadSafariPage "http://www.google.com";
		scripter -f /usr/local/etc/scripter/general/ExecuteTest.js safariTest_loadSafariPage "http://www.arstechnica.com" 
		scripter -f /usr/local/etc/scripter/general/ExecuteTest.js safariTest_loadSafariPage "http://www.latimes.com";
		scripter -f /usr/local/etc/scripter/general/ExecuteTest.js safariTest_loadSafariPage "http://www.dodgers.com" 
		scripter -f /usr/local/etc/scripter/general/ExecuteTest.js safariTest_loadSafariPage "http://news.bbc.co.uk"
		CURRENT_TIME=`date +%s`
	done
}

browse_edge()
{
	reset_power_config
	echo "POWERPROFILER: BEGIN BROWSE_EDGE $1" `date +%s`
	Wedgie -E $EPOCH_SECS -A begin_browse_edge >> $TEST_LOG_NAME
	
	scripter -f /usr/local/etc/scripter/general/ExecuteTest.js settingsTest_setWifi "OFF"

	# if we're on a 3G phone, disable 3G
	if [ "$M68AP" = "0" ]
	then
		scripter -f /usr/local/etc/scripter/general/ExecuteTest.js settingsTest_ChangeSingleSwitch "General" "Enable 3G" "OFF" "Network"
	fi
		
	Wedgie -l -t $((60 * $1)) >/var/logs/Wedgie.2G_browse.`date +%h_%d_%y__%H_%M_%S`.txt &
	_browse $1

	echo "POWERPROFILER: END BROWSE_EDGE" `date +%s`
	Wedgie -E $EPOCH_SECS -A end_browse_edge >> $TEST_LOG_NAME
}

browse_hsdpa()
{
	if [ "$M68AP" = "1" ]
	then
		ECHO "ACK *** trying to run a 3G test on a 2G phone *** FAIL"
		return
	fi

	reset_power_config
	echo "POWERPROFILER: BEGIN BROWSE_HSDPA" `date +%s`
	Wedgie -E $EPOCH_SECS -A begin_browse_hsdpa >> $TEST_LOG_NAME
	
	scripter -f /usr/local/etc/scripter/general/ExecuteTest.js settingsTest_setWifi "OFF"
	scripter -f /usr/local/etc/scripter/general/ExecuteTest.js settingsTest_ChangeSingleSwitch "General" "Enable 3G" "ON" "Network"
	Wedgie -l -t $((60 * $1)) >/var/logs/Wedgie.3G_browse.`date +%h_%d_%y__%H_%M_%S`.txt &
	_browse $1

	echo "POWERPROFILER: END BROWSE_HSDPA" `date +%s`
	Wedgie -E $EPOCH_SECS -A end_browse_hsdpa >> $TEST_LOG_NAME
}


browse_wifi()
{
	reset_power_config
	echo "POWERPROFILER: BEGIN BROWSE_WIFI" `date +%s`
	Wedgie -E $EPOCH_SECS -A begin_browse_wifi >> $TEST_LOG_NAME
	
	_connect_to_wifi
	_browse $1
	
	echo "POWERPROFILER: END BROWSE_WIFI" `date +%s`
	Wedgie -E $EPOCH_SECS -A end_browse_wifi >> $TEST_LOG_NAME
}


_makecall()
{
	START_TIME=`date +%s`
	DURATION=$((60 * $1))
	END_TIME=$(($START_TIME + $DURATION))
	CURRENT_TIME=$START_TIME

	while [ $CURRENT_TIME -lt $END_TIME ] ; do
		eventer p|grep "End"
		if [ "$?" = "1" ]
		then
			echo "Call not active.  Dialing."
			scripter -f /usr/local/etc/scripter/general/ExecuteTest.js phoneTest_makeCall 4089748874
		else
			sleep 10
		fi
		CURRENT_TIME=`date +%s`
	done
}

_endcall()
{
	eventer h

	scripter -f /usr/local/etc/scripter/general/ExecuteTest.js phoneTest_endCall 4089748874
}

makecall_2g()
{
	reset_power_config
	echo "POWERPROFILER: BEGIN CALL_2G" `date +%s`
	Wedgie -E $EPOCH_SECS -A begin_call_2g >> $TEST_LOG_NAME
	
	# if we're on a 3G phone, disable 3G
	if [ "$M68AP" = "0" ]
	then
		scripter -f /usr/local/etc/scripter/general/ExecuteTest.js settingsTest_ChangeSingleSwitch "General" "Enable 3G" "OFF" "Network"
	fi
	
	Wedgie -l -t $((60 * $1)) >/var/logs/Wedgie.2G_call.`date +%h_%d_%y__%H_%M_%S`.txt &
	_makecall $1
	_endcall
	
	echo "POWERPROFILER: END CALL_2G" `date +%s`
	Wedgie -E $EPOCH_SECS -A end_call_2g >> $TEST_LOG_NAME
}

makecall_3g()
{
	if [ "$M68AP" = "1" ]
	then
		ECHO "ACK *** trying to run a 3G test on a 2G phone *** FAIL"
		return
	fi

	reset_power_config
	echo "POWERPROFILER: BEGIN CALL_3G" `date +%s`
	Wedgie -E $EPOCH_SECS -A begin_call_3g >> $TEST_LOG_NAME
	
	scripter -f /usr/local/etc/scripter/general/ExecuteTest.js settingsTest_ChangeSingleSwitch "General" "Enable 3G" "ON" "Network"
	Wedgie -l -t $((60 * $1)) >/var/logs/Wedgie.3G_call.`date +%h_%d_%y__%H_%M_%S`.txt &
	_makecall $1
	_endcall
	
	echo "POWERPROFILER: END CALL_3G" `date +%s`
	Wedgie -E $EPOCH_SECS -A end_call_3g >> $TEST_LOG_NAME
}

sms()
{
	echo "***************** SMS() *****************"
	reset_power_config
	echo "POWERPROFILER: BEGIN SMS" `date +%s`
	Wedgie -E $EPOCH_SECS -A begin_sms >> $TEST_LOG_NAME
	
	Wedgie -l -t $((60 * $1)) &

	START_TIME=`date +%s`
	DURATION=$((60 * $1))
	END_TIME=$(($START_TIME + $DURATION))
	CURRENT_TIME=$START_TIME
	
	while [ $CURRENT_TIME -lt $END_TIME ] ; do
		if [ "$SMS_NUMBER" = "" ]
		then
			scripter -f /usr/local/etc/scripter/general/ExecuteTest.js smsTest_sendReceiveSMS
		else
			scripter -f /usr/local/etc/scripter/general/ExecuteTest.js smsTest_sendReceiveSMS "Hi how are you" "Hi how are you" $SMS_NUMBER
		fi
		CURRENT_TIME=`date +%s`
	done

	echo "POWERPROFILER: END SMS" `date +%s`
	Wedgie -E $EPOCH_SECS -A end_sms >> $TEST_LOG_NAME
}

video()
{
	reset_power_config
	echo "POWERPROFILER: BEGIN VIDEO" `date +%s`
	Wedgie -E $EPOCH_SECS -A begin_video >> $TEST_LOG_NAME
	
	START_TIME=`date +%s`
	DURATION=$((60 * $1))
	END_TIME=$(($START_TIME + $DURATION))
	CURRENT_TIME=$START_TIME

	while [ $CURRENT_TIME -lt $END_TIME ] ; do
		scripter -f /usr/local/etc/scripter/general/ExecuteTest.js iPodTest_playMovieFromVideoList "$VIDEO_NAME" 60
		CURRENT_TIME=`date +%s`
	done

	echo "POWERPROFILER: END VIDEO" `date +%s`
	Wedgie -E $EPOCH_SECS -A end_video >> $TEST_LOG_NAME
}

music()
{
	reset_power_config
	echo "POWERPROFILER: BEGIN AUDIO" `date +%s`
	Wedgie -E $EPOCH_SECS -A begin_audio >> $TEST_LOG_NAME

	START_TIME=`date +%s`
	DURATION=$((60 * $1))
	END_TIME=$(($START_TIME + $DURATION))
	CURRENT_TIME=$START_TIME

	while [ $CURRENT_TIME -lt $END_TIME ] ; do
		scripter -f /usr/local/etc/scripter/general/ExecuteTest.js iPodTest_playSongFromSongList "$SONG_NAME" 60
		CURRENT_TIME=`date +%s`
	done

	echo "POWERPROFILER: END AUDIO" `date +%s`
	Wedgie -E $EPOCH_SECS -A end_audio >> $TEST_LOG_NAME
}

maps()
{
	reset_power_config
	echo "POWERPROFILER: BEGIN MAPS" `date +%s`
	Wedgie -E $EPOCH_SECS -A begin_maps >> $TEST_LOG_NAME
	
	scripter -f /usr/local/etc/scripter/general/ExecuteTest.js mapsTest_toggleFindMe

	START_TIME=`date +%s`
	DURATION=$((60 * $1))
	END_TIME=$(($START_TIME + $DURATION))
	CURRENT_TIME=$START_TIME

	while [ $CURRENT_TIME -lt $END_TIME ] ; do
		scripter -f /usr/local/etc/scripter/general/ExecuteTest.js mapsTest_search "Los Angeles, CA"
		scripter -f /usr/local/etc/scripter/general/ExecuteTest.js mapsTest_flick
		scripter -f /usr/local/etc/scripter/general/ExecuteTest.js mapsTest_zoomIn
		scripter -f /usr/local/etc/scripter/general/ExecuteTest.js mapsTest_zoomOut
		scripter -f /usr/local/etc/scripter/general/ExecuteTest.js mapsTest_drag

		eventer h
		
		CURRENT_TIME=`date +%s`
	done

	scripter -f /usr/local/etc/scripter/general/ExecuteTest.js mapsTest_toggleFindMe

	echo "POWERPROFILER: END MAPS" `date +%s`
	Wedgie -E $EPOCH_SECS -A end_maps >> $TEST_LOG_NAME
}

game()
{
	reset_power_config
	echo "POWERPROFILER: BEGIN GAME" `date +%s`
	Wedgie -E $EPOCH_SECS -A begin_game >> $TEST_LOG_NAME
	
	scripter -f /usr/local/etc/scripter/general/ExecuteTest.js misc_startHoldem
	sleep $((60 * $1))
	eventer h
	
	echo "POWERPROFILER: END GAME" `date +%s`
	Wedgie -E $EPOCH_SECS -A end_game >> $TEST_LOG_NAME
}

camera()
{
	reset_power_config
	echo "POWERPROFILER: BEGIN CAMERA" `date +%s`
	Wedgie -E $EPOCH_SECS -A begin_camera >> $TEST_LOG_NAME

	START_TIME=`date +%s`
	DURATION=$((60 * $1))
	END_TIME=$(($START_TIME + $DURATION))
	CURRENT_TIME=$START_TIME

	while [ $CURRENT_TIME -lt $END_TIME ] ; do
		scripter -f /usr/local/etc/scripter/general/ExecuteTest.js cameraTest_takeNewPicture
		scripter -f /usr/local/etc/scripter/general/ExecuteTest.js photo_viewSomePicturesFromAPhotoAlbum
		
		CURRENT_TIME=`date +%s`
	done

	echo "POWERPROFILER: END CAMERA" `date +%s`
	Wedgie -E $EPOCH_SECS -A end_camera >> $TEST_LOG_NAME
}

camera_videorecord()
{
    reset_power_config
    echo "POWERPROFILER: BEGIN CAMERA RECORD VIDEO" `date +%s`
    Wedgie -E $EPOCH_SECS -A begin_camera >> $TEST_LOG_NAME

    START_TIME=`date +%s`
    DURATION=$((60 * $1))

    scripter -f /usr/local/etc/scripter/general/ExecuteTest.js cameraTest_captureVideo $DURATION 

    echo "POWERPROFILER: END CAMERA" `date +%s`
    Wedgie -E $EPOCH_SECS -A end_camera >> $TEST_LOG_NAME
}

youtube_3g()
{
    # disconnect from wifi.
    scripter -f /usr/local/etc/scripter/general/ExecuteTest.js settingsTest_setWifi "OFF"
    # connect 3g network.
    scripter -f /usr/local/etc/scripter/general/ExecuteTest.js settingsTest_ChangeSingleSwitch "General" "Enable 3G" "ON" "Network"
    _youtube_runner
}

youtube_wifi() 
{
    _connect_to_wifi
    _youtube_runner
}

_youtube_runner()
{
	echo "POWERPROFILER: BEGIN YOUTUBE" `date +%s`

	while true; do
	    scripter -f /usr/local/etc/scripter/general/ExecuteTest.js youtubeTest_playRandomVideoInYouTubeFeatured
	done

	echo "POWERPROFILER: END YOUTUBE" `date +%s`
}


email()
{
	reset_power_config
	echo "POWERPROFILER: BEGIN EMAIL !!! THIS IS A NO-OP !!!" `date +%s`
	Wedgie -E $EPOCH_SECS -A begin_mail >> $TEST_LOG_NAME

	/usr/bin/true

	echo "POWERPROFILER: END EMAIL" `date +%s`
	Wedgie -E $EPOCH_SECS -A end_mail >> $TEST_LOG_NAME
}

# Can replay the events that took place during a random run.
playback() {
        echo "Reading playback file ..."
        cat $1 | while read LINE ; do
                echo "Read: " $LINE
                $LINE
        done
}

# A random profile that lets you test different orders, durations, and
# sleep times.  A replay log is automatically created for repros.
random() {
echo "Random Profile";
maxreps=10;
count=0;
while [ $count -lt $maxreps ]
do
        let call_type=$RANDOM%9;

        let work_time=$RANDOM%15;
        case $call_type in
        0)
                echo "Calling browse_edge " $work_time
                echo "browse_edge "$work_time >> $RP_LOG
                browse_edge $work_time
        ;;
        1)
                echo "Calling browse_wifi " $work_time
                echo "browse_wifi "$work_time >> $RP_LOG
                browse_wifi $work_time
        ;;
        2)
                echo "Calling makecall " $work_time
                echo "makecall_2g "$work_time >> $RP_LOG
                makecall_2g $work_time
        ;;
        3)
                echo "Calling sms " $work_time
                echo "sms "$work_time >> $RP_LOG
                sms $work_time
        ;;
        4)
                echo "Calling video "  $work_time
                echo "video "$work_time >> $RP_LOG
                video $work_time
        ;;
        5)
                echo "Calling music "  $work_time
                echo "music "$work_time >> $RP_LOG
                music $work_time
        ;;
        6)
                echo "Calling maps " $work_time
                echo "maps "$work_time >> $RP_LOG
                maps $work_time
        ;;
	7)
		echo "Calling thermal virus " $work_time
		echo "thermal_virus "$work_time >> $RP_LOG
		thermal_virus $work_time
	;;
        *)
                let naptime=$RANDOM%60
                echo "Calling sleep "$naptime
                echo "phone_sleep "$naptime >> $RP_LOG
                phone_sleep $naptime
        ;;
        esac
done
}

# Takes the number of minutes for the phone to sleep.
phone_sleep() {
        echo "phone_sleep() called for " $1 " mins"
	sleep_time=$(($1*60))
        /usr/local/bin/SleepCycler -s $sleep_time
}

# Takes the number of minutes to run the thermal_virus
thermal_virus() {
	work_time=$(($1*60))
	/usr/local/bin/Wedgie -n -s -t $work_time
}

start_charging() {
	setbatt on 
	setbatt on  
	# seems to be a bug? Need to call twice.
}

stop_charging() {
	setbatt off 

	# the kill is because setbatt drain hangs and needs a manual ctrl-c usually.
	setbatt drain & 
	#pid=$!
	#kill -9 $pid
	sleep 1;
	killall setbatt drain;
}

# get's the state of charge.
getSOC() {
        soc=`hdqtool | grep StateOfCharge | awk '{print $2}'`
        soc=`echo ${soc//,}`
        return $((soc))
}


# QA's long term charge/discharge test.  Starts with 100% SOC and drains to 0%, then 
# charges to 90% SOC and drains to 0% and so on.  We can graph accuracy, and we can 
# also ensure that every SOC corresponds to the correct amount of runtime.
longterm_test() {
        charge_max=30;
        getSOC;
        soc=$?

        echo "Long term test" > /longterm.log;

        while [ $charge_max -ge 10 ]; do

                # ensure the battery is charge to the right amount.
                while [ $soc -lt $charge_max ]; do
			start_charging;
                        sleep 10;
			getSOC;
			soc=$?;
                        echo "charge battery, soc: " $soc >> /longterm.log
                done

                # now discharge the battery recording start and end time.
                echo "Test at Max SOC of " $charge_max " started at: " `date` >> /longterm.log

		while [ $soc -gt 5 ]; do 
			stop_charging;
			camera_videorecord 1;
			getSOC;				
			soc=$?;
			echo "discharging battery, soc: " $soc >> /longterm.log
		done

                echo "Test at Max SOC of " $charge_max " ended at: " `date` >> /longterm.log

                # lower the max charge by 10%
                let charge_max=$charge_max-10;
        done
}



##########  Device Configuration  ##########
echo "Setting backlight to 50%..."
defaults write /private/var/mobile/Library/Preferences/com.apple.springboard SBBacklightLevel -float 0.5

# Turn off ALS
echo "Turning off ALS..."
defaults write /private/var/mobile/Library/Preferences/com.apple.springboard SBEnableALS NO

# Set movie to loop forever
echo "Setting movie to loop forever..."
defaults write com.apple.mobileipod RepeatMovieForever 1

# Set music to loop forever
echo "Setting music to loop forever..."
defaults write /private/var/mobile/Library/Preferences/com.apple.mobileipod MusicRepeatSetting All

echo "Removing Celestial preferences and setting volume to 50%..."
rm -f ~/Library/Preferences/com.apple.celestial.plist
defaults write /private/var/mobile/Library/Preferences/com.apple.celestial default_volume 0.5

# Disable SpringBoard's low power alerts
echo "Disabling low power alerts..."
defaults write /private/var/mobile/Library/Preferences/com.apple.springboard SBHideLowPowerAlerts -boolean YES

# Show numeric battery level in the status bar
echo "Showing numeric battery level in status bar..."
defaults write /private/var/mobile/Library/Preferences/com.apple.springboard SBShowBatteryLevel -boolean YES

# set owner of com.apple.springboard.plist back to mobile (any call of defaults via the root user will change this file's owner)
chown mobile:mobile  /private/var/mobile/Library/Preferences/com.apple.springboard.plist

# Restart SpringBoard and mediaserverd so that they pick up all the user defaults we just set
echo "Restarting mediaserverd and SpringBoard..."
killall mediaserverd
killall SpringBoard
sleep 2

# Uncomment one of these two lines to specify whether airplane mode should be ON or OFF.
#scripter -f /usr/local/etc/scripter/general/ExecuteTest.js settingsTest_setAirplaneMode "ON"
#scripter -f /usr/local/etc/scripter/general/ExecuteTest.js settingsTest_setAirplaneMode "OFF"
##########  End Device Configuration  ##########

