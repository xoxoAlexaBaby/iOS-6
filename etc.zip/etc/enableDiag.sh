date
DEVICENAME=`hostname`
echo "DEVICE: $DEVICENAME"
echo "Setting up bbctl commands:"
/usr/local/bin/bbctl usb off
/usr/local/bin/bbctl mux off
sleep 1
/usr/local/bin/bbctl radio on
/usr/local/bin/bbctl usb on
/usr/local/bin/bbctl mux on
/usr/local/bin/bbusbctl on
echo "Done... Setting up commands.\n"
