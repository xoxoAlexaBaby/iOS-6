#!/usr/local/bin/scripter -f

#import "../libs/PHTesting.js"
#import "../libs/HarnessUtility.js"
#import "../springboard/AssistantTests.js"
#import "../settings/SettingsTests.js"
#import "../notes/NotesTests.js"

/*
These are Assistant Tests.  Setup required:
1. Copy the assistant files to /var/mobile/ on the device.
2. Copy the address book to /var/mobile/Library/Preferences/AddressBook
2a. Make sure the address book copied has the correct permissions.
*/

var kReportPath = "/var/mobile/Library/Logs/Testing/";
var hasWifi = system.hasCapability('wifi');
var hasTelephony = system.hasCapability("telephony");
var kRecordingsPath = "/var/mobile/siri_recordings/male/"; 


// phone numbers
var kMoviePhone = "4087773456"
var kLoopBackNumber = "4089748874"

/*
// requires these specific bits of content be on the test device
var kSongName = "Yesterday";
var kMovieName = "Trailer H"
var kMovieSublist = "The Simpsons Movie";
var kMP4MovieName = "TikiBarTV10-DrinkbotMP4V";
var kDRMedSongName = "Delerium DRM";
var kDRMedMovieName = "Nasa DRM";


var start = new Date();
var timeString = start.getTime() + "";  // turn this into a string
var runID = "Assistant " + start.toDateString() + " - " + timeString.substr(-6);

var kSMSBuddy1 = "4083321896";
var kSMSBuddy2 = "4083323272";

kStoreUsername = "jsmith.purple@gmail.com";
kStorePassword = "telluride";
  
// this is some setup that is required for the sms tests
globalSMSNumber = telephony.myPhoneNumber;
*/

function addTestsToArray(tests) {

	// Phone Tests
	if ((typeof phone != 'undefined') && springboard.displaysApp(phone)) {
	    var thePath = kRecordingsPath + "phone_test_files/phone_test_files_built_in_mic/";
		tests.push("Phone: Built-In Mic");
		tests.push(phtCreateTest("PhoneMicT1", [thePath + "t1.spx", "phoneNumber:" + kMoviePhone], assistantTest_makePhoneCall, "Mic T1: Call Yvonne")); 
		tests.push(phtCreateTest("PhoneMicT2", [thePath + "t2.spx", "phoneNumber:" + kMoviePhone], assistantTest_makePhoneCall, "Mic T2: Call Alex Kingston")); 
		tests.push(phtCreateTest("PhoneMicT3", [[thePath + "t3a.spx", thePath + "t3b.spx"], "phoneNumber:" + kMoviePhone], assistantTest_makePhoneCall, "Mic T3a&b: Call Nigel")); 
		tests.push(phtCreateTest("PhoneMicT4", [thePath + "t4.spx", "phoneNumber:" + kMoviePhone], assistantTest_makePhoneCall, "Mic T4: Call Bob")); 
		tests.push(phtCreateTest("PhoneMicT5", [[thePath + "t5a.spx", thePath + "t5b.spx"], "phoneNumber:" + kMoviePhone], assistantTest_makePhoneCall, "Mic T5a&b: Call Greg")); 
		tests.push(phtCreateTest("PhoneMicT6", [thePath + "t6.spx", "phoneNumber:" + kMoviePhone], assistantTest_makePhoneCall, "Mic T6: Call Granny")); 
        tests.push(phtCreateTest("PhoneMicT7", [[thePath + "t7a.spx", thePath + "t7b.spx"], "phoneNumber:" + kMoviePhone], assistantTest_makePhoneCall, "Mic T7a&b: Call Mark Adams")); 
        tests.push(phtCreateTest("PhoneMicT8", [thePath + "t8.spx", "phoneNumber:" + kMoviePhone], assistantTest_makePhoneCall, "Mic T8: Call Peter Wokawski home")); 
		tests.push(phtCreateTest("PhoneMicT9", [[thePath + "t9a.spx", thePath + "t9b.spx"], "phoneNumber:" + kMoviePhone], assistantTest_makePhoneCall, "Mic T9a&b: Call Eric at work")); 
		tests.push(phtCreateTest("PhoneMicT10", [[thePath + "t10a.spx", thePath + "t10b.spx", thePath + "t10c.spx"], "phoneNumber:" + kMoviePhone], assistantTest_makePhoneCall, "Mic T10a&b&c: Call Paul")); 
		tests.push(phtCreateTest("PhoneMicT11", [thePath + "t11.spx", "phoneNumber:511"], assistantTest_makePhoneCall, "Mic T11: Dial 511")); 
		tests.push(phtCreateTest("PhoneMicT12", [thePath + "t12.spx", "phoneNumber:" + kLoopBackNumber], assistantTest_makePhoneCall, "Mic T12: Dial 408-974-8874")); 
		tests.push(phtCreateTest("PhoneMicT13", [thePath + "t13.spx", "phoneNumber:18005558355"], assistantTest_makePhoneCall, "Mic T13: Call 1-800-555-8355")); 
		tests.push(phtCreateTest("PhoneMicT14", [thePath + "t14.spx"], assistantTest_makePhoneCall, "Mic T14: Call my sister on mobile")); 
		
		thePath = kRecordingsPath + "phone_test_files/phone_test_files_wired_headset/";
		tests.push("Phone: Wired Headset");
		tests.push(phtCreateTest("PhoneWiredHeadsetT1", [thePath + "t1.spx", "phoneNumber:" + kMoviePhone], assistantTest_makePhoneCall, "Wired Headset T1: Call Yvonne")); 
		tests.push(phtCreateTest("PhoneWiredHeadsetT2", [thePath + "t2.spx", "phoneNumber:" + kMoviePhone], assistantTest_makePhoneCall, "Wired Headset T2: Call Alex Kingston")); 
		tests.push(phtCreateTest("PhoneWiredHeadsetT3", [[thePath + "t3a.spx", thePath + "t3b.spx"], "phoneNumber:" + kMoviePhone], assistantTest_makePhoneCall, "Wired Headset T3a&b: Call Nigel")); 
		tests.push(phtCreateTest("PhoneWiredHeadsetT4", [thePath + "t4.spx", "phoneNumber:" + kMoviePhone], assistantTest_makePhoneCall, "Wired Headset T4: Call Bob")); 
		tests.push(phtCreateTest("PhoneWiredHeadsetT5", [[thePath + "t5a.spx", thePath + "t5b.spx"], "phoneNumber:" + kMoviePhone], assistantTest_makePhoneCall, "Wired Headset T5a&b: Call Greg")); 
		tests.push(phtCreateTest("PhoneWiredHeadsetT6", [thePath + "t6.spx", "phoneNumber:" + kMoviePhone], assistantTest_makePhoneCall, "Wired Headset T6: Call Granny")); 
        tests.push(phtCreateTest("PhoneWiredHeadsetT7", [[thePath + "t7a.spx", thePath + "t7b.spx"], "phoneNumber:" + kMoviePhone], assistantTest_makePhoneCall, "Wired Headset T7a&b: Call Mark Adams")); 
        tests.push(phtCreateTest("PhoneWiredHeadsetT8", [thePath + "t8.spx", "phoneNumber:" + kMoviePhone], assistantTest_makePhoneCall, "Wired Headset T8: Call Peter Wokawski home")); 
		tests.push(phtCreateTest("PhoneWiredHeadsetT9", [[thePath + "t9a.spx", thePath + "t9b.spx"], "phoneNumber:" + kMoviePhone], assistantTest_makePhoneCall, "Wired Headset T9a&b: Call Eric at work")); 
		tests.push(phtCreateTest("PhoneWiredHeadsetT10", [[thePath + "t10a.spx", thePath + "t10b.spx", thePath + "t10c.spx"], "phoneNumber:" + kMoviePhone], assistantTest_makePhoneCall, "Wired Headset T10a&b&c: Call Paul")); 
		tests.push(phtCreateTest("PhoneWiredHeadsetT11", [thePath + "t11.spx", "phoneNumber:511"], assistantTest_makePhoneCall, "Wired Headset T11: Dial 511")); 
		tests.push(phtCreateTest("PhoneWiredHeadsetT12", [thePath + "t12.spx", "phoneNumber:" + kLoopBackNumber], assistantTest_makePhoneCall, "Wired Headset T12: Dial 408-974-8874")); 
		tests.push(phtCreateTest("PhoneWiredHeadsetT13", [thePath + "t13.spx", "phoneNumber:18005558355"], assistantTest_makePhoneCall, "Wired Headset T13: Call 1-800-555-8355")); 
		tests.push(phtCreateTest("PhoneWiredHeadsetT14", [thePath + "t14.spx"], assistantTest_makePhoneCall, "Wired Headset T14: Call my sister on mobile"));
	}
	
	// Mail Tests
	if ((typeof mail != 'undefined') && springboard.displaysApp(mail)) {
	    var thePath = kRecordingsPath + "mail_test_files/mail_test_files_built_in_mic/";
		tests.push("Mail: Built-In Mic");
//		tests.push(phtCreateTest("MailMicT1", [thePath + "t1.spx", "endVerification:I will be late"], assistantTest_sendEmail, "Mic T1: Mail Peter Wokawski I will be late")); 
		// "I will be late" is used for the subject.  Asks for the body of the email
//		tests.push(phtCreateTest("MailMicT2", [thePath + "t2.spx", "endVerification:Be right there"], assistantTest_sendEmail, "Mic T2: Mail Greg at home be right there")); 
		// "Be right there" is used for the subject.  Asks for the body of the email
//		tests.push(phtCreateTest("MailMicT3", [[thePath + "t3a.spx", thePath + "t3b.spx", thePath + "t3c.spx", thePath + "t3d.spx"]], assistantTest_sendEmail, "Mic T3: Mail Richard")); 
//		tests.push(phtCreateTest("MailMicT4", [[thePath + "t4a.spx", thePath + "t4b.spx"], "endVerification:What are you planning to buy for her birthday"], assistantTest_sendEmail, "Mic T4: Email my sister what are you planning to buy for her birthday")); 
//		tests.push(phtCreateTest("MailMicT5", [thePath + "t5.spx", "endVerification:How was the vacation"], assistantTest_sendEmail, "Mic T1: Email Paul how was the vacation")); 
        // missing t5a file
//		tests.push(phtCreateTest("MailMicT6", [thePath + "t6.spx", "endVerification:team lunch"], assistantTest_sendEmail, "Mic T1: Send an email to Johnny about team lunch")); 
		// Needs to verify "What would you like the email to say" -- then the test will be done, but we need to make sure to exit out of the assistant afterwards (or clear state)
//		tests.push(phtCreateTest("MailMicT7", [thePath + "t7.spx", "endVerification:I will be late"], assistantTest_sendEmail, "Mic T1: Find all email from Matt Hoppa"));   
		// missing t7 file.
//		tests.push(phtCreateTest("MailMicT8", [thePath + "t8.spx", "endVerification:new emails", "endVerification:No new email"], assistantTest_genericTest, "Mic T8: Show me unread messages"));
        // "Show me unread messages" has response of "You  have no new text messages"
		tests.push(phtCreateTest("MailMicT9", [thePath + "t9.spx", "endVerification:EmailFindDucs#findingEmailsAbout"], assistantTest_genericTest, "Mic T9: Find emails on coupons"));     
	}
	
	
    // Notes Tests
    if ((typeof notes != 'undefined') && springboard.displaysApp(notes)) {
        var thePath = kRecordingsPath + "notes_test_files/notes_test_files_built_in_mic/";
    	tests.push("Notes: Built-In Mic");
    	tests.push(phtCreateTest("DeleteAllNotes", null, notesTest_deleteAllNotes, "Delete all notes on device")); 
  //  	tests.push(phtCreateTest("NotesMicT1", [thePath + "t1.spx", "endVerification:I will be late"], assistantTest_genericTest, "Mic T1: Note to myself to buy eggs on the way home.")); 
        // missing t1 file
    	tests.push(phtCreateTest("NotesMicT2", [[thePath + "t2a.spx", thePath + "t2b.spx", thePath + "t2c.spx"], "endVerification:Note#creating"], assistantTest_genericTest, "Mic T2: Create a note - Summer to do")); 
    	tests.push(phtCreateTest("NotesMicT3", [thePath + "t3.spx", "endVerification:travel around the world"], assistantTest_genericTest, "Mic T3: Travel around the world")); 
    	tests.push(phtCreateTest("NotesMicT4", [thePath + "t4.spx", "endVerification:Here are all your notes"], assistantTest_genericTest, "Mic T4: Where is my break todos note")); 
        tests.push(phtCreateTest("NotesVerifyNoteExists", ["Summer to do", "partialMatch:1"], noteTest_verifyNoteTitle, "Verify Summer To Do note exists")); 
    	
	}	
	
	
	
}

function usage() {
	system.println("usage: AssistantTester.js [--enable <string>] [--disable <string>] [-o <path> | -filepath <path> | --filename <string>] [-l | --list]");
	system.println("	--disable	tests to skip (may use regex to describe tests)");
	system.println("	--enable	tests to run (may use regex to describe tests)");
	system.println("	--filepath	full path for the results file");
	system.println("	--inputpath full path for the recordings to use");
	system.println("	--filename	name to use for the results file");
	system.println("	--wifiname	name to use for the wifi basestation");
	system.println("	--wifipassword	password to use for the wifi basestation");
	system.println("	--nosetup	skip the setup phase of the QuickLook")
	system.println("	--list		list the available tests");
	system.println("	--writecrashes	write out crashes to the results file")
	system.println("	--help | -h	usage description");
}

function main() {
	var tests = new Array();
	var version = harness_getBuildVersion();
	var filename = "AssistantTester_" + version + ".txt";
	var filepath;
	var wifiname;
	var wifipassword;
	var writeCrashes = false;
	var enableSetup = true;
	
	// seed the generator, so that any random events are the same for every run
	system.setRandomSeed(1);
	UIATarget.localTarget().unlockScreenIfNecessary();	// screen must be unlocked to check for springboard app icons
	
	// process command line arguments
	var options = new Options();
	if (options.help || options.h) {
		usage();
		return;
	}
	if (options.list || options.l) {
		addTestsToArray(tests);
		harness_listTests(tests);
		return;
	}
	if (options.filename) filename = options.filename;
	if (options.inputpath) kRecordingsPath = options.recordingsPath;
	if (options.nosetup) enableSetup = false;
	if (options.writecrashes) writeCrashes = true;
	if (options.o) filepath = options.o;
	else if (options.filepath) filepath = options.filepath;
	else {
		harness_makeDirectory(kReportPath);
		filepath = kReportPath + filename;
	}
	
	// if setup is enabled, add the setup tests to the test array.
	if (enableSetup) {
		
		// Unlock the device
		tests.push("Setup");
		//tests.push(phtCreateTest("UnlockDevice", ["0"], systemTest_lockAndUnlockDevice, "Unlock the device")); 
		
		// Set auto-lock to never
		tests.push(phtCreateTest("SetAutoLockToNever", ["General", "Auto-Lock", "Never"], settingsTest_chooseCheckmarkedItem, "Set Auto-Lock to Never"));
		
		// Set user to Dan Young
		tests.push(phtCreateTest("SetMyInfo", ["Mail, Contacts, Calendars", "My Info", "Dan Young", "noValidation:1"], settingsTest_chooseCheckmarkedItem, "Set My Info"));
		
		// Setup proper Wi-Fi
		if (hasWifi) {
			if (options.wifiname) {
				wifiname = options.wifiname;
				if (options.wifipassword) {
					wifipassword = options.wifipassword;
				}
			}
			else {
				wifiname = "AppleWifi";
				wifipassword = null;
				
			}
			tests.push(phtCreateTest("SetWifi", ["1", wifiname, wifipassword, "backupNetwork:AppleWiFi"], settingsTest_setWifi, "Set Wifi to " + wifiname));
			//tests.push(phtCreateTest("SetWifiOn", ["1", "AppleWiFi"], settingsTest_setWifi, "Turn wifi on and set it to AppleWiFi"));
		}
		// Setup the proper yahoo mail account
		tests.push(phtCreateTest("SetupYahooAccount", ["yahoo", "Yohan Dandifop", "yohan.dandifop@yahoo.com", "apple123", "description:yohan.dandifop@yahoo.com", "contactsSync:0", "calendarsSync:0", "notesSync:0"], 
		    settingsTest_createEmailAccount, "Create yahoo email account"));
	}
	
	addTestsToArray(tests); // add all of the normal tests to the array
	
	// uncomment this line if you want top data added to the output
	//system.setDefault("com.apple.harness", "utilities", ["/usr/bin/top -o -cpu -l 1"]);
	
	harness_removeFile(filepath);
	harness_runTestsFromArray(tests, filepath, options.disable, options.enable, false, writeCrashes);
	
	system.println("Done Running AssistantTester.");
}

main();
