/*
 Class: UIApp (appstore)
 AppStore object
 */

#import "../libs/SpringBoard.js"

appstore = UIAApp.application("App Store", "com.apple.AppStore");

if (typeof appstore != 'undefined') {
	
	appstore.alertHandler = function alertHandler(alert) {
		
		//check if we got a 'Would you like to download your free copy of iBooks now?' alert
		var isIBooksAlert = alert.withPredicate("name contains 'download your free copy of iBooks'").isValid();
		if (isIBooksAlert) {
			UIALogger.logDebug("Got the download iBooks alert");
			alert.buttons()["Not Now"].tap();
		}
		
		if (!alert.waitForInvalid()) {
			throw new Error("Could not handle the alert");
		}
		
		return true;
	}
	
	//overwriting this to also account for the Loading... that comes up on the main view
	appstore.waitForNetworkLoadingToFinish = function waitForNetworkLoadingToFinish(seconds) {
		if (!seconds) seconds = 60;
		if (!this.__proto__.waitForNetworkLoadingToFinish(seconds)) return false;
		var loadingText = this.mainWindow().staticTexts().firstWithPredicate("name contains 'Loading'");
		if (loadingText.isValid()) {
			UIALogger.logDebug("Loading text found in the main window. Waiting for it to go away...");
			UIATarget.localTarget().pushTimeout(seconds);
			var didLoad = this.waitForInvisible(loadingText);
			UIATarget.localTarget().popTimeout();
			return didLoad;
		}
		return true;
	}
	
	appstore.launchIfNotActive = function launchIfNotActive() {
		this.__proto__.launchIfNotActive.apply(this);
		this.waitForNetworkLoadingToFinish(60);
	}
	
	// --------------------------------------------------------------------------------
	//	Function: getToView(viewName) 
	//		Switches the UILayout using the button bar buttons
	//
	//	Parameters:	
	//		viewName (string) - name of the view to switch to; Featured, Categories, Top 25, Search, More
	//
	//	Returns: 
	//		None
	// --------------------------------------------------------------------------------
	appstore.getToView = function getToView(viewName) {
		this.waitForNetworkLoadingToFinish(60);
		UIALogger.logDebug("Going to '" + viewName + "'");
		var tabButton = this.tabBar().buttons().firstWithPredicate("name contains '" + viewName + "'");
		if (!tabButton.isValid()) {
			this.logElementTree();
			throw new Error("Did not find the tab button: " + viewName);
		}
		tabButton.tap();
		if (!tabButton.withValueForKey(1, "value").isValid()) 
			throw new Error("Tapped the '" + viewName + "' button, but the value did not change");
		this.waitForNetworkLoadingToFinish();
	}

	//----------------------------------------------------------------------------------------
	//	Function: search 
	//		Selects the search tab, performs a search using <searchString>
	//		and selects the cell matching <displayName>
	//
	//	Parameters:	
	//		searchString (string - optional) - the search string to use. if null then appName will be used	
	//		options (object) - a hash of additional optional arguments
	//
	//	Options:
	//		displayName (string) - application name, as displayed in the app store (required if different than search string)
	//
	//	Notes:
	//		assumes the app store is launched
	//
	//	Returns: None
	//----------------------------------------------------------------------------------------
	appstore.search = function search(searchString, options) {
		if (!options) options = new Object();
		var displayName = (typeof options.displayName == 'undefined') ? searchString : options.displayName;
		
		if (UIATarget.localTarget().model() == 'iPad') {
			appstore.getToView("Featured");
			var searchBar = this.navigationBar().searchBars()[0];
			if (searchBar.value() != "") searchBar.tap(); //needed to go to search view
		} else
			appstore.getToView("Search");
		UIATarget.localTarget().delay(1); //animation delay
		this.__proto__.search.apply(this, [searchString, {searchBarEvalString:"this.navigationBar().searchBars()[0]"}]);
		
		if (!this.waitForNetworkLoadingToFinish()) UIALogger.logWarning("Network loading did not finish");
		
		UIALogger.logDebug("Looking for search result now...");
		UIATarget.localTarget().pushTimeout(30);
		if (UIATarget.localTarget().model() == 'iPad') {
			var appElement = this.mainWindow().scrollViews()[0].webViews()[0].elements()[displayName];
			appElement.scrollToVisible();
		} else {
			var appElement = this.mainWindow().tableViews()[0].scrollToElementWithPredicate("name beginswith '" + displayName + "'");
		}
		UIATarget.localTarget().popTimeout();
		
		if (!appElement.isValid()) throw new Error("Failed to locate '" + displayName + "' in the search results");
		
		UIALogger.logDebug("Selecting the search result: " + appElement.name());
		appElement.tap();
		this.waitForNetworkLoadingToFinish();
	}
	
	//----------------------------------------------------------------------------------------
	//	Function: purchaseCurrentSelection 
	//		Locates the price button for the currently selected
	//		application and selects it
	//
	//	Parameters: 
	//		options (object) - a hash of additional optional arguments
	//
	//	Options:
	//		username (string) - the iTunes account username
	//		password (string) - the iTunes account password
	//
	//	Notes:
	//		assumes the app to purchase has been selected and its detailed view is being displayed
	//
	//	Returns: None
	//----------------------------------------------------------------------------------------
	appstore.purchaseCurrentSelection = function purchaseCurrentSelection(options) {
		if (options) {
			if (typeof options.username == 'string') springboard.iTunesUsername = options.username;
			if (typeof options.password == 'string') springboard.iTunesPassword = options.password;
		}
		
		UIATarget.localTarget().pushTimeout(10);
		if (UIATarget.localTarget().model() == 'iPad')
			var priceButton = this.mainWindow().scrollViews()[0].webViews()[0].buttons()[0];
		else
			var priceButton = this.mainWindow().tableViews()[0].buttons()[0];
		UIATarget.localTarget().popTimeout();
		priceButton.tap();
		
		if (priceButton.withName("INSTALLED").isValid()) {
			UIALogger.logDebug("Target application is already installed.");
			return ;
		} else {
			priceButton.withPredicate("name contains 'INSTALL' or name == 'BUY APP' or name == 'BUY NOW'").tap();
			UIATarget.localTarget().delay(5); //let the alert handlers do their job
			UIATarget.localTarget().frontMostApp().logElementTree(); //logging for <rdar://problem/8116067>
		}
	}
	
	//----------------------------------------------------------------------------------------
	//	Function: checkForUpdates 
	//		Checks for pending app updates on the Updates view
	//
	//	Parameters: 
	//		none
	//
	//	Returns: 
	//		number of pending updates, zero if none found
	//----------------------------------------------------------------------------------------
	appstore.checkForUpdates = function checkForUpdates() {
		
		this.getToView("Updates");
		
		if (this.mainWindow().staticTexts().firstWithPredicate("name == 'All Apps Are Up to Date' or name == 'No Updates'").isValid()) {
			return 0;
		}
		
		var updateButton = this.tabBar().buttons().firstWithPredicate("name contains 'Updates'");
		if (!updateButton.isValid()) throw new Error("Could not find the updates button");
		updateButton.logElement();
		
		var number = parseInt(updateButton.name().match(/[0-9]+/));
		if (isNaN(number)) 
			return 0;
		else 
			return number;
	}
	
	//----------------------------------------------------------------------------------------
	//	Function: updateAllApps
	//		Switches to the updates view and selects updates all
	//
	//	Parameters: 
	//		password (string - optional) - the iTunes account password
	//
	//	Notes:
	//
	//	Returns: none
	//----------------------------------------------------------------------------------------
	appstore.updateAllApps = function updateAllApps(password) {
		
		UIALogger.logDebug("Updating all the apps...");
		
		if (password) springboard.iTunesPassword = password;
		
		this.getToView("Updates");
		this.navigationBar().buttons()["Update All"].tap();
	
		//give a little time for alerts to pop up...
		UIATarget.localTarget().delay(5);
	}
	
}
