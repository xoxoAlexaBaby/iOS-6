echo "*******  Sleeping for 5 Seconds:"
SEND_AT_COMMAND=`which SendATCommand`
APBuild=`/usr/local/bin/lockdown_query get NULL BuildVersion 2>&1`
DLCI_DEV_NODE="/dev/dlci.spi-baseband.extra_0"

sleep 5
date
echo "Setting up Auto-Answering "
echo "AT+S0=1"
echo "${SEND_AT_COMMAND} -d $dlciPort  S0=1"
${SEND_AT_COMMAND} -d $DLCI_DEV_NODE  S0=1
echo "Done Setting up AT Command.\n\n"
