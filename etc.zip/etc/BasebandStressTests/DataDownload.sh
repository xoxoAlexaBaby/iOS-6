#!/bin/sh

SCRIPTS_DIR="/usr/local/etc/BasebandStressTests/"

Usage()
{
	echo "\nUSAGE: $0    -i <iterations>  -d <size of Data File - 1, 2, 5>  -h < to print this>"
	echo "		example: $0   -i 10   -d 1 \n"
	echo "		For Help $0 -h\n"
	exit 1
}


## PARAMETERS VALIDATION
LOOPS=0
dataSize=10

while getopts 'i:d:h' OPTION; 
do
	case "$OPTION" in
		i )	LOOPS="$OPTARG";;
		d )	dataSize="$OPTARG";;
		h ) Usage;;
		/?)	echo "INVALID OPTIONS.\n"; exit 1;;
	esac
done

shift $(($OPTIND - 1))
if [ $LOOPS -le 0 ]; then Usage; fi

URL="http://pttest.apple.com/${dataSize}MB.txt"

date
startTime=`date "+%s"`
elapsedTime=0
currentTime=$startTime
tStartTime=`date -r $startTime`
echo "Current Time - $currentTime"
lastKOOLStateTime=$startTime
timeForKOOLState=0

COUNT=0
pass=0
fail=0
downloadFile=`perl -lne '($s,$m,$H,$d,$M,$Y,$D) = localtime(); $Y += 1900; $M++; printf ("DataDownload_%02d%02d-%02d%02d",$M,$d,$H,$m); ' `


while  [ $COUNT -lt $LOOPS ];
do
	((COUNT++))
	pdpip=0
	loopStartTime=`date "+%s"`
	tLoopStartTime=`date -r $loopStartTime`
	# Activate the Data Context
	echo "\n\n ****** Beginning Iteration - $COUNT *************" 
	echo "Activating Data Context"
	/usr/local/bin/DataContext -c $pdpip up > dummy.txt
	sleep 1
	
	echo "\n\n ****** Beginning Iteration - $COUNT *************"  >> ${downloadFile}.txt
	echo `date` ": $COUNT. Downloading data"  >> ${downloadFile}.txt
	echo "1. Data Download begin..."
	/usr/local/bin/StreamPerf HTTP -c $pdpip $URL  > Download.txt
	cat Download.txt >> ${downloadFile}.txt
	cat Download.txt
	FOUND=`grep Average Download.txt | awk '{print $5}'`
		
	echo "Calculating timers..."
	currentTime=`date "+%s"`
	elapsedTime=$(($currentTime - $startTime))
	timeForKOOLState=$(($currentTime - $lastKOOLStateTime))
	tCurrentTime=`date -r $currentTime`
	

	#if [ $timeForKOOLState -ge 600 ]; then
		echo "Taking *KOOL*STATE"
		testCT -l "$tCurrentTime: Dumping Logs after $COUNT download iterations"
	#	lastKOOLStateTime=$currentTime
		echo " Sleeping for 25 s to dump logs."
		sleep 25
	#fi
	
	echo "DATA DOWNLOAD START TIME = $tLoopStartTime *** END TIME = $tCurrentTime:: DATA RATE = $FOUND Mbps."
	echo "DATA DOWNLOAD START TIME = $tLoopStartTime *** END TIME = $tCurrentTime:: DATA RATE = $FOUND Mbps.\n\n"  >> ${downloadFile}.txt
	echo "*** Elapsed Time = $elapsedTime"
	#echo "DATA DOWNLOAD STRESS KOOLSTATE Timer = $timeForKOOLState, Last KOOLSTATE = $lastKOOLStateTime\n"
	#echo  `date` ": $COUNT Data Calls were made so far... Passed: $pass Failed: $fail."
	echo " Sleeping for 5 seconds...\n\n"
	sleep 5
	
done
