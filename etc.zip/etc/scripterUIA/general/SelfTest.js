#!/usr/local/bin/scripter -uiautomation YES -f

SELF_TEST_ARRAY = new Array();

#import "../libs/PHTesting.js"
#import "../libs/HarnessUtility.js"
#import "../settings/SettingsTests.js"
#import "../mail/MailTests.js"
#import "../safari/SafariTests.js"
#import "../maps/MapsTests.js"
#import "../ipod/iPodTests.js"
#import "../notes/NotesTests.js"
#import "../contacts/ContactsTests.js"
#import "../clock/ClockTests.js"
#import "../calculator/CalculatorTests.js"
#import "../phone/PhoneTests.js"
#import "../appstore/AppStoreTests.js"
#import "../3rdparty/FacebookTests.js"
#import "../calendar/CalendarTests.js"
#import "../weather/WeatherTests.js"
#import "../camera/CameraTests.js"
#import "../springboard/SpringboardTests.js"
#import "../youtube/YouTubeTests.js"
#import "../stocks/StocksTests.js"
#import "../system/SystemTests.js"
#import "../messages/MessagesTests.js"
#import "../photos/PhotoTests.js"
#import "../itunes/iTunesTests.js"
#import "../facetime/FaceTimeTests.js"
#import "../nike/NikeTests.js"
#import "../photobooth/PhotoBoothTests.js"

// Skipping iTunes Tests for Now--please be sure to add these tests soon!

var kReportPath = "/var/mobile/Library/Logs/Testing/";

// TODO: implement the usage description
function usage() {
	system.println("usage: SelfTest.js [--enable <string>] [--disable <string>] [-o <path> | -filepath <path> | --filename <string>] [-l | --list]");
	system.println("	--disable	tests to skip (may use regex to describe tests)");
	system.println("	--enable	tests to run (may use regex to describe tests)");
	system.println("	--filepath	full path for the results file");
	system.println("	--filename	name to use for the results file");
	system.println("	--list		list the available tests");
	system.println("	--help | -h	usage description");
}

function main() {
	
	SELF_TEST_ARRAY = new Array();
	for (appName in UIAApp._applications) {
		var app = UIAApp._applications[appName];
		if (typeof app.selfTests != 'undefined') {
			UIALogger.logDebug("adding " + app.selfTests.length + " tests for " + appName);
			SELF_TEST_ARRAY = SELF_TEST_ARRAY.concat(app.selfTests);	
		}
		else  {
			UIALogger.logError("Can't find SelfTests for '" + appName + "'");
		}
	}
	
	system_addSelfTest();  // add the system tests specifically.

	// seed the generator, so that any random events are the same for every run
	system.setRandomSeed(1);
	
	var version = harness_getBuildVersion();
	var filename = "SelfTest_" + version + ".txt";
	var filepath;
	
	// process command line arguments
	var options = new Options();
	if (options.help || options.h) {
		usage();
		return;
	}
	if (options.list || options.l) {
		harness_listTests(SELF_TEST_ARRAY);
		return;
	}
	if (options.filename) filename = options.filename;
	if (options.o) filepath = options.o;
	else if (options.filepath) filepath = options.filepath;
	else {
		harness_makeDirectory(kReportPath);
		filepath = kReportPath + filename;
	}
	
	harness_removeFile(filepath);
	harness_runTestsFromArray(SELF_TEST_ARRAY, filepath, options.disable, options.enable, true);
	
	system.run("/bin/cat " + filepath, 5);
	system.println("Done Running Self Test.");
}

main();

