#import "../../libs/System.js"
#import "../../libs/SpringBoard.js"
#import "../../libs/PHTesting.js"


// --------------------------------------------------------------------------------
//	wifiTest_wifiplist - dump and save wifi plist.
//
//	Arguments:
//	 filepath (string) - File path and name to save the wifi plist
//
//	Return:
//	 1 for pass, 0 for fail.
// --------------------------------------------------------------------------------
function wifiTest_wifiplist()
{
	this.testResult = 0;
			
	if (this.argv.length < 1) {
		this.testError = "Did not provide the filepath for saving wifi plist"
		UIALogger.logError(this.testError);
		this.testResult = 0
		return 0
	}
	else {
		filepath = this.argv[0];
		UIALogger.logMessage("The wifi plist will be saved under: " + filepath);
	}
	system.run("/bin/cp /Library/Preferences/SystemConfiguration/com.apple.wifi.plist " + filepath);
	system.run("/usr/bin/plutil -convert xml1 "+ filepath)
		
	this.testResult = 1;
	return 1;
}

// --------------------------------------------------------------------------------
//	wifiTest_associateNRate - Check associated with WiFi network using N rate.
//
//	Arguments:
//	 None
//
//	Return:
//	 1 if it is N rate, 0 if it legacy rate.
// --------------------------------------------------------------------------------
function wifiTest_associateNRate()
{
	this.testResult = 0;
	var searchString = /mcs/	
	var output = UIAUtility.logToolOutput("/usr/local/bin/wl nrate");
	
	if (output.search(searchString) != -1) {
		UIALogger.logMessage("Associate using N rate")
		UIALogger.logMessage(output)
	} else {
		UIALogger.logError("Associate using legacy rate");
		UIALogger.logMessage(output)
		return 0;
	}

	this.testResult = 1;
	return 1;
}


// --------------------------------------------------------------------------------
//	wifiTest_wirelessTester - Use WirelessTester
//
//	Arguments:
//	 cmd
//	argu (optional) -- argument for WirelessTester cmd
//	timeout (optional) -- timeout for the command
//
//	Return:
//	 1 if Pass, 0 if fail.
// --------------------------------------------------------------------------------
function wifiTest_wirelessTester()
{
	this.testResult = 0;
	var timeout = 10;
	
	if (this.argv.length < 1) {
		this.testError = "Did not provide the cmd for WirelessTester"
		UIALogger.logError(this.testError);
		this.testResult = 0
		return 0
	}
	
	var cmd = this.argv[0];
	command = "/usr/local/bin/WirelessTester -c \""+cmd+"\"";
	
	if (this.argv.length > 1) {
		var argu = this.argv[1];
		UIALogger.logMessage("Argu is: "+argu)
		command = "/usr/local/bin/WirelessTester -c \""+cmd+"\" " + argu;
	}
	
	if (this.argv.length > 2) {
		timeout = parseInt(this.argv[2]);
	}
	
	UIALogger.logMessage("Command is: "+command)
	
	var result = system.run(command, timeout);
	if (result.stderr != "") {
		UIALogger.logMessage("Test result is: "+result.stdout);
		UIALogger.logError(result.stderr);
		return this.testResult;
	} 

	return this.testResult = 1;
}

// --------------------------------------------------------------------------------
//	wifiTest_eapolmethod - Check whether enterprise WiFi uses correct eapol method.
//
//	Arguments:
//	 eapolmethod (string) - name of the eapol method (TLS/LEAP/TTLS/EAP-FAST/PEAP)
//
//	Return:
//	 1 if eapol method matches, 0 if it fails.
// --------------------------------------------------------------------------------
function wifiTest_eapolmethod()
{
	this.testResult = 0;
			
	if (this.argv.length < 1) {
		UIALogger.logError("Did not provide the eapol method: TLS/LEAP/TTLS/EAP-FAST/PEAP");
		return 0;
	}
	else {
		eapolmethod = this.argv[0];
		UIALogger.logMessage("Check for eapol method " + eapolmethod);
	}
			
	var success = false;
	var searchString = "<string>" + eapolmethod + "</string>"
	
	
	output = UIAUtility.logToolOutput("/usr/local/bin/eapoltest state en0", 10);
	
	var total_output = "";
	if (output) {
		total_output = total_output + output; 
		var outputList = total_output.split("\n"); 
		for (var i=0; i<outputList.length; i++) {
			var matchList = outputList[i].match(searchString);
				if (matchList != null) {
					//system.println(outputList[i]);
					UIALogger.logMessage("eapol method is " + eapolmethod)
					success = true;
					break;
				}
				
			}
	}
	
	if (!success) {
		this.testError = "eapol method is not " + eapolmethod + ", test failed";
		UIALogger.logError(this.testError);
		return 0;
	}
	
	this.testResult = 1;
	return 1;
}

// --------------------------------------------------------------------------------
//	wifiTest_iperf - iperf tests for WiFi (bidirectional iperf individually, client mode)
//
//	Arguments:
//	 client (string) - client ip address; optional--default is 192.168.1.113
// 	 time (int) - seconds to run iperf; optional -- default is 30 seconds
// 	 pass_number (int) - number of Mbps for pass -- default is 5 (for 5Mbps)
//
//	Return:
//	 test results if test succeeds, 0 if it fails.
// --------------------------------------------------------------------------------
function wifiTest_iperf()
{
	var client_ip = "192.168.1.113";
	var seconds = 30
	var pass_number = 5
	time_out = 2*seconds+20
	this.testResult = 0;
	
	if (this.argv.length > 0) {
		client_ip = client_ip = this.argv[0];
	}

	if (this.argv.length > 1) {
		seconds = this.argv[1];
	}

	if (this.argv.length > 2) {
		pass_number = parseInt(this.argv[2]);
	}

	UIALogger.logMessage("run iperf to given client ip address " + client_ip + " for " + seconds + " seconds; pass criteria is "+pass_number+"Mbps");

	springboard.getToSpringBoard();

	var tx_success = false;
	var rx_success = false;
	var searchString = "bits/sec"
	var tx_result = ""
	var rx_result = ""
	var error_result = "0.00 bits/sec"
	
	//Workaround for <rdar://problem/7278327> iperf 2.0.4 -r command does not work
	output = UIAUtility.logToolOutput("/usr/local/bin/iperf -c " + client_ip + " -t " + seconds + " -r", time_out);
	//output = UIAUtility.logToolOutput("/var/log/iperf-2.0.2 -c " + client_ip + " -t " + seconds + " -r", time_out);
	
	var total_output = "";
	if (output) {
		total_output = total_output + output; 
		var outputList = total_output.split("\n");
		 
		for (var i=0; i<outputList.length; i++) {
			var matchList = outputList[i].match(searchString);
			if (matchList != null) {
				if (i<outputList.length-2) {
					tx_result = outputList[i].replace(/\[.+[\s\w|\s]Bytes\s+/, "")
					var errormatch = tx_result.match(error_result)
					if (errormatch == null) {
						tx_success = true
						UIALogger.logMessage("iperf TX is " + tx_result)
					}
					else {
						UIALogger.logMessage("iperf TX fail: " + tx_result)
					}
				}
				else {
					rx_result = outputList[i].replace(/\[.+[\s\w|\s]Bytes\s+/, "")
					var errormatch = rx_result.match(error_result)
					if (errormatch == null) {
						rx_success = true
						UIALogger.logMessage("iperf RX is " + rx_result)
					}
					else {
						UIALogger.logMessage("iperf RX fail: " + rx_result)
					}
				}
				
			}
				
		}
	}

	if ((!tx_success) || (!rx_success)) {
		this.testError = "run iperf to " + client_ip + " failed, (TX: " + tx_result + " / RX: " + rx_result + ")";
		UIALogger.logError(this.testError);
		return 0;
	}
	
	
	var TX_number = parseFloat(tx_result);
	var RX_number = parseFloat(rx_result);
	
	if ((TX_number <= pass_number) || (RX_number <= pass_number)) {
		this.testError = "run iperf to " + client_ip + " failed, because results are less than "+pass_number+"Mbps. (TX: " + tx_result + " / RX: " + rx_result + ")";
		UIALogger.logError(this.testError);
		return 0;
	} else if (tx_result.match("Kbits/sec") || rx_result.match("Kbits/sec")) {
		UIALogger.logError("Results are less than 1Mbits/sec")
		this.testError = "run iperf to " + client_ip + " failed, because results are less than "+pass_number+"Mbps. (TX: " + tx_result + " / RX: " + rx_result + ")";
		UIALogger.logError(this.testError);
		return 0;
	}
	
	var result = "(TX: " + tx_result + " / RX: " + rx_result + ")";
	
	UIALogger.logMessage(result);
			
	this.testResult = result;
	return result;
}

// --------------------------------------------------------------------------------
//	wifiTest_fastping - Check WiFi Internet Connection using fast ping.
//
//	Arguments:
//		ping_destination (string) - ping destination: URL or IP address; 
//		time (string)- how long you want to ping in seconds;
//
//	Return:
//	 1 if test succeeds, 0 if it fails.
// --------------------------------------------------------------------------------
function wifiTest_fastping()
{
	this.testResult = 0;
	this.testError = ""
			
	if (this.argv.length < 2) {
		UIALogger.logError("Please provide two arguments for this test: ping destination (URL or IP address); and the time you want to ping in seconds")
		return this.testResult
	}
	else {
		var ping_destination = this.argv[0];
		var timeout = this.argv[1];
		try {
			var command_timeout = parseInt(timeout) + 5
		} catch(e) {
			UIALogger.logError(e.message)
			this.testError = "Did not put a valid number as time you want to ping, please input a number"
			return this.testResult
		}
		UIALogger.logMessage("fast ping to " + ping_destination + " for " + timeout + " seconds")
	}
			
	var success = false;
	var searchString = "ping statistics"
	
	output = UIAUtility.logToolOutput("/sbin/ping -i .1 -t " + timeout + " " + ping_destination, command_timeout);
	var total_output = ""
	var result_number = 0
	if (output) {
		total_output = total_output + output; 
		var outputList = total_output.split("\n"); 
		for (var i=0; i<outputList.length; i++) {
			var matchList = outputList[i].match(searchString);
			if (matchList != null) {
				//system.println(outputList[i]);
				//UIALogger.logMessage("ping " + ping_destination + " pass")
				success = true;
				result_number = i;
				break;
			}
				
		}
		
	}
	
	if (!success) {
		this.testError = "Could not get the fast ping result"
		UIALogger.logError = this.testError
		return this.testResult = 0
	}
	
	if (result_number + 3 <= outputList.length) {
		var result = outputList[result_number+1] + "\n" +outputList[result_number+2]
	} else {
		var result = outputList[result_number+1]
	}
		
	UIALogger.logMessage(result)
	
	this.testResult = result;
	return result;
}

//----------------------------------------------------------------------------------------
//	Function: wifiTest_getRSSI
//		Get the RSSI number if WiFi joined with correct network
//
//	Parameters:
//		network (string) - name of the network.
//
//	Returns: 
//		1 if test succeeds, 0 if it fails.
//----------------------------------------------------------------------------------------		
function wifiTest_getRSSI(){
	this.testResult = 0;
	this.testError = ""
	var timeout = 10
	var success = false;
			
	if (this.argv.length < 1) {
		UIALogger.logError("Please provide oen arguments for this test: the name of the network")
		return this.testResult
		
	}
	else {
		var network = this.argv[0];
		UIALogger.logMessage("Check the RSSI with the device joined " + network)
	}
	
	var actualNetwork = ""
	
	UIALogger.logMessage("Check if WiFi is joined with network: " + network);

	//Verify the network SSID
	for (var i=0; i<timeout; i=i+1) {
		var result = system.run("/usr/local/bin/apple80211 --ssid", 5);
		actualNetwork = result.stdout.replace("\n", "").replace("ssid = ", "");
		if (actualNetwork == network){
			UIALogger.logMessage("apple80211 --ssid shows: joined network " + actualNetwork );
			success = true
			break;
			
		}
		UIATarget.localTarget().delay(1);
	}
	
	if (success) {
		UIALogger.logMessage("Try to get RSSI")
	} else {
		this.testError = "Did not join with correct network: "+network+"; apple80211 --ssid shows: "+actualNetwork
		UIALogger.logError(this.testError)
		return this.testResult
	}

	var result = system.run("/usr/local/bin/apple80211 --rssi", 5);
	var rssi = result.stdout.replace("\n", "").replace("rssi: ", "");
	UIALogger.logMessage("The RSSI is: "+rssi)
	rssi = "RSSI is: "+rssi
	return this.testResult = rssi

} // end wifiTest_getRSSI

function wifi_addSelfTest() {
	
}