#import "./PhotoBooth.js"
#import "../libs/PHTesting.js"


//Workaround for <rdar://problem/8902206> Photo booth effect elements are not visible
var kPhotoBoothEffects = ["Thermal Camera", "Mirror", "X-Ray", "Kaleidoscope", "Normal", "Light Tunnel", "Squeeze", "Twirl", "Stretch"];

function photoboothTest_takePhoto() {
		
	var photoEffect;
	if (this.argv.length > 0) {
		if (this.argv[0] == "All") 
			photoEffect = kPhotoBoothEffects;
		else
			photoEffect = new Array(this.argv[0]);
	} else {
		photoEffect = new Array("Normal");
	}
	
	
	var cameraDirection = "Front";
	if (this.argv.length > 1) {
		cameraDirection = this.argv[1];
	}
	
	// Delete the photo after verifying it has been taken, defaults to yes
	var deletePhoto = 1;
	if (this.argv.length > 1) {
		deletePhoto = this.argv[1];
	}
	
	// Launch the Photo Booth application if it is not active
	photobooth.launchIfNotActive();
	
	photobooth.returnToEffects();
	UIATarget.localTarget().delay(2);
	var arrayOfEffectButtons = photobooth.mainWindow().elements().withPredicate("isVisible == 1");
	var numberOfPhotos;
	for (var i = 0; i < photoEffect.length; i++) {
		this.testResult = 1;
		photobooth.chooseEffect(photoEffect[i]);
		UIALogger.logMessage("Choosing effect " + photoEffect[i]);
		numberOfPhotos = photobooth.getNumberOfPhotos();
		UIALogger.logMessage("Current # of photos is: " + numberOfPhotos);
		
		photobooth.chooseCamera(cameraDirection);
		UIALogger.logMessage("Choosing '" + cameraDirection + "' camera direction");
		photobooth.takePicture();
		
		//Let the photo appear in the tray
		UIATarget.localTarget().delay(10);
		if (photobooth.getNumberOfPhotos() <= numberOfPhotos) throw new Error("Number of photos did not change after taking a photo");
		else {
			UIALogger.logMessage("# of photos after taking a photo is: " + numberOfPhotos);
			this.testResult = 1;
		}
		photobooth.deletePhoto();
		photobooth.returnToEffects();
		UIATarget.localTarget().delay(3);
	}
	
	return this.testResult;
}

// Create self tests -- this is an unnamed function, just to make sure any local variables stay in the correct context
(function() {	
 	if ((typeof photobooth != 'undefined') && springboard.displaysApp(photobooth)) {
		if (typeof photobooth.selfTests == 'undefined') {
			photobooth.selfTests = new Array();
		}
 
		photobooth.selfTests.push(phtCreateTest("TakePhotosUsingAllEffects", ["All"], photoboothTest_takePhoto, "Take photos using all effects"));
	}
 }())