#import "UIAAppStressLibrary.js"

if (typeof youtube != 'undefined') {
	youtubeStress = AppStressBase.stressTest("YouTube");
	
	if (typeof youtubeStress != 'undefined') {
		
		youtubeStress.setup = function setup() {
			youtubeStress.addTest(youtubeStress._playAllVideos);
			youtubeStress.addTest(youtubeStress._playRandomVideo);
			
			// tests not currently working
//			youtubeStress.addTest(youtubeStress._scrubVideo);
//			youtubeStress.addTest(youtubeStress._addBookmarkFromVideo);
//			
//			if(STRESS_MAIL_ACCOUNT && STRESS_MAIL_PASSWORD) {
//				youtubeStress.addTest(youtubeStress._emailVideo);
//			}
		}
		
		youtubeStress.run = function run() {
			youtubeStress.executeRandomTests(2);
		}
		
		// play all videos in favorites
		youtubeStress._playAllVideos = function _playAllVideos() {
			youtubeStress.executeTest( "PlayAllVideos", [ 10, 16, false ], 
					youtubeTest_playVideosInYouTubeCategory, "Play all videos in YouTube favorites." );	
		}
		
		// play a random video in favorites
		youtubeStress._playRandomVideo = function _playRandomVideo() {
			var duration = system.randomInteger(1, 120);
			youtubeStress.executeTest( "PlayRandomVideo", [ duration, 1, true ],
					youtubeTest_playVideosInYouTubeCategory, "Play a random video." );
		}
		
		// scrub video
		youtubeStress._scrubVideo = function _scrubVideo() {
			youtubeStress.executeTest("ScrubVideo", [], youtubeTest_scrubVideo, "Scrub a video.");
		}
		
		// email video
		youtubeStress._emailVideo = function _emailVideo() {
			youtubeStress.executeTest( "EmailVideo", [STRESS_MAIL_ACCOUNT], 
										youtubeTest_emailYoutubeVideo, "Email a video." );
		}
		
		// add bookmark from video
		youtubeStress._addBookmarkFromVideo = function _addBookmarkFromVideo() {
			youtubeStress.executeTest( "AddBookmarkFromVideo", [], 
										youtubeTest_addBookmarkFromMovie, "Add a bookmark from a video." );
		}
	}
}