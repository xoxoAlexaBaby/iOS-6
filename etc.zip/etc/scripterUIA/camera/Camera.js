/*
 Class: UIApp (camera)
 Camera object
 */

#import "../libs/SpringBoard.js"
#import "../libs/UIAAppCameraAdditions.js"


if (system.hasCapability("still-camera")) {
	camera = UIAApp.application("Camera", "com.apple.camera");
}

if (typeof camera != 'undefined') {

	//camera views -- values returned by getCurrentView
	camera.views = {};
	camera.views.CAMERA_VIEW = "CameraView";  //the view with the take picture, etc. buttpns
	camera.views.CAMERA_ROLL_VIEW = "CameraRollView"; //the view with the photo/video thumbnails
	camera.views.PHOTO_VIEW = "PhotoView"; //selected photo view
	camera.views.VIDEO_VIEW = "VideoView"; //selected video view
	camera.views.DELETE_ACTIONSHEET_VIEW = "DeleteActionsheetView"; //the actionsheet that comes up after tapping the trash icon
	camera.views.BULK_SELECT_VIEW = "BulkSelectView"; //the view that comes up after tapping the action button in camera roll
	camera.views.ACTION_ACTIONSHEET_VIEW = "ActionActionsheetView"; //the actionsheet that comes up after tapping the action button in photo/video view
	camera.views.EMAIL_VIEW = "EmailView"; //email compsose sheet view
	
	camera.launchIfNotActive = function launchIfNotActive() {
        var launchAlertHandler = function (alert) {
            alert.logElementTree();
            if (alert.staticTexts().withPredicate("name contains[cd] 'Photo Stream'")) {
                UIALogger.logMessage(" Encountered Alert: " + alert.staticTexts()[0].name());
                var laterButton = alert.buttons()["Later"];
                if (laterButton.isVisible()) {
                    laterButton.tap();
                }
            }
        };
        
        UIATarget.pushAlertHandler(launchAlertHandler);	

		this.__proto__.launchIfNotActive.apply(this);
		this.isCameraIrisOpen();
        UIATarget.popAlertHandler();
	}
		
	camera.swipeToCameraRoll = function swipeToCameraRoll() {
		UIALogger.logMessage("Swiping to access the camera roll");
		camera.dragInsideWithOptions({startOffset:{x:0.1,y:0.5}, endOffset:{x:0.9,y:0.5}});
	}

	camera.swipeToCameraView = function swipeToCameraView() {
		UIALogger.logMessage("Swiping to access the camera");
		camera.dragInsideWithOptions({startOffset:{x:0.9,y:0.5}, endOffset:{x:0.1,y:0.5}});
	}
/*	//----------------------------------------------------------------------------------------
	//	Function: getToCamera
	//		Gets the camera into the camera view, so that camera will be ready to take pictures.
	//
	//	Parameters: 
	//		none
	//
	//	Returns: 
	//		none
	//----------------------------------------------------------------------------------------
	camera.getToCamera = function getToCamera() {
		this.launchIfNotActive();
		UIALogger.logDebug("Going to camera view...");
		var currentView = this.getToCamera
		
		if (currentView == this.views.CAMERA_VIEW) {
			UIALogger.logDebug("Already in '" + currentView + "'");
			return ;
		}
		
		UIALogger.logDebug("Will first go to camera roll view");
		this.getToCameraRoll();
		
		UIALogger.logDebug("Tapping 'Done' button now");
		var doneButton = this.mainContainerView().navigationBar().buttons()["Done"]; //TODO: file a bug for this one
		doneButton.tap();
		UIATarget.localTarget().delay(2);
		if (doneButton.isVisible()) UIALogger.logWarning("'Done' button did not become invalid");
		
		UIATarget.localTarget().pushTimeout(10); //this animation might take a while -- give it some more time...
		currentView = this.getCurrentView();
		UIATarget.localTarget().popTimeout();
		
		if (currentView != this.views.CAMERA_VIEW) throw new Error("Could not get to camera view. Still in '" + currentView + "'");
	}
	*/
	//----------------------------------------------------------------------------------------
	//	Function: getToCameraRoll
	//		Gets the camera into the "album" view--the area where all of the 
	//		photo/video thumbnails are displayed (aka the Camera Roll).
	//
	//	Optional Parameters: 
	//		view (string) - optional - the button on the nav bar, "All", "Photos" or "Videos", 
	//			that needs to be selected in the camera roll. If no value is specified, no
	//			button is tapped. Note that this parameter only applies for devices that support
	//			video (for other devices this parameter is ignored)
	//
	//	Returns: 
	//		none
	//----------------------------------------------------------------------------------------
	camera.getToCameraRoll = function getToCameraRoll(options) {

		this.launchIfNotActive();
		
		var view;
		var swipeFromCameraView;
		if (typeof options != 'undefined') {
			view = (typeof options.view != 'undefined') ? options.view : null;
			swipeToCameraRoll = (typeof options.swipeToCameraRoll != 'undefined') ? options.swipeToCameraRoll : null;
		}

		UIATarget.localTarget().pushTimeout(1);
		// First, look for the navigation bar and check if we're already in the camera roll
		var navBar = this.mainContainerView().navigationBar();

		UIALogger.logMessage("Already in the camera roll? Looking for segmented controls...");
		if (navBar.segmentedControls()[0].isVisible()) {
			UIALogger.logDebug("Found the segmented controls - we're in the camera roll");

			if (view) {
				UIALogger.logMessage("Selecting '" + view + "' in the nav bar");
				navBar.segmentedControls()[0].buttons().firstWithPredicate("name contains '" + view + "'").tap();
			}
			
			UIATarget.localTarget().popTimeout();
			return;
		}

		UIALogger.logMessage("Segmented controls not found. Checking for any visible action sheets");
		
		// Check to see if the actionsheet is up, if it is, then Cancel it and keep going
		if (this.actionSheet().isVisible()) {
			UIALogger.logMessage("Action Sheet found - tapping 'Cancel' button to dismiss");
			this.actionSheet().buttons()["Cancel"].tap();
		}
		
		//Check for the visibility of the toolbar with the capture button to determine if we're in the camera capture view
		var toolbarElement = this.mainContainerView().toolbar();
		var isInCameraView = 0;
		
		
		UIALogger.logMessage("Next, check for camera toolbar to determine if the camera view is visible");
		if (toolbarElement.isValid())
			isInCameraView = (toolbarElement.buttons()["Take Picture"].isVisible() || toolbarElement.buttons()["Record Video"].isVisible()) ? true : false;
		
		UIALogger.logDebug("Toolbar capture button element visiblity: " + isInCameraView);
		
		//If not in the camera view, try to bring up the controls
		if (!isInCameraView) {
			UIALogger.logMessage("Not currently in the camera view - trying to bring up the Photo/Video view controls");
			this.bringUpControls();
		} else { 
			UIALogger.logMessage("Currently in the camera view");
			if (swipeToCameraRoll) {
				this.swipeToCameraRoll();
			} else {
				UIALogger.logMessage("Tapping the 'Photo and Viedo viewer' button to access the camera roll");
				this.viewfinderToolbarButtonWithName("Photo and Video viewer").tap();
			}
		}

		// Let the animation settle down - 5 SECONDS IS WAAAAY TOO LONG.  this needs to be changed
		UIATarget.localTarget().delay(5);

		UIALogger.logMessage("Looking for the navigation bar");

        var maxAttempts = 5;
        
		
        for (var currentAttempt = 0; currentAttempt < maxAttempts; currentAttempt++) {
             this.bringUpControls(); 

            navBar = this.mainContainerView().navigationBar();
            if (!navBar.isVisible()) {
                UIATarget.localTarget().popTimeout();
                throw new Error("Failed to find the navigation bar");
            }		

            if (navBar.leftButton().isVisible()) {
                try{
                // Tap the done button to exit the camera/video view
               
                    UIALogger.logMessage("Tapping the left navigation button to exit photo view to the camera roll");
                    navBar.leftButton().tap();
                } catch(e) {
                    UIALogger.logError("Failed to tap the left Button");
                }
            } else {
                break;
            }
            
        
        }
		
		// Let the animation settle down
		UIATarget.localTarget().delay(1);

		var segControls = this.mainContainerView().navigationBar().segmentedControls()[0];
		if (!segControls.isValid()) UIALogger.logWarning("Nav bar with seg controls did not show up");
		
		if (view) {
			UIALogger.logMessage("Selecting '" + view + "' in the nav bar");
			this.mainContainerView().navigationBar().segmentedControls()[0].buttons().firstWithPredicate("name contains '" + view + "'").tap();
		}
		UIATarget.localTarget().delay(1); //give it a second to update/load
		UIATarget.localTarget().popTimeout();						
	} // end getToCameraRoll
	
	
	//----------------------------------------------------------------------------------------
	//	Function: getToCamera
	//		Navigates to the Camera 
	//
	//	Optional Parameters: 
	//		mode (string) - 'Photo' or 'Video' - Camera mode to select after accessing the camera
	//		swipeToCameraView (boolean) - Use swipe gesture to access the camera view
	//
	//	Returns: 
	//		none
	//----------------------------------------------------------------------------------------
	camera.getToCamera = function getToCamera(options) {
		this.launchIfNotActive();
		
		var view;
		var swipeToCameraView;
		var isInCameraView;
		var toolbarElement;
		var isInCameraView;
		
		if (typeof options != 'undefined') {
			view = (typeof options.view != 'undefined') ? options.view : null;
			swipeToCameraView = (typeof options.swipeToCameraView != 'undefined') ? options.swipeToCameraView : null;
		}
		
		UIATarget.localTarget().pushTimeout(1);

		toolbarElement = this.mainContainerView().toolbar();
		isInCameraView = 0;
		
		// Are we already in the camera view?
		UIALogger.logMessage("Are we already in the camera view? Checking for camera toolbar...");
		if (toolbarElement.isValid()) {
			isInCameraView = (toolbarElement.buttons()["Take Picture"].isVisible() || toolbarElement.buttons()["Record Video"].isVisible()) ? true : false;
		}

		if (isInCameraView) {
			UIALogger.logMessage("Already in the camera view.");
			//If so, switch camera modes if one is supplied
			if (view) this.selectCameraMode(view);
			UIATarget.localTarget().popTimeout();
			return;
		}
		
		// Check to see if the actionsheet is up, if it is, then Cancel it and keep going
		if (this.actionSheet().isVisible()) {
			UIALogger.logMessage("Action Sheet found - tapping 'Cancel' button to dismiss");
			this.actionSheet().buttons()["Cancel"].tap();
		}

		UIALogger.logMessage("Not currently in the camera view - trying to bring up the Photo/Video view controls");
		var navBar;

		this.bringUpControls();
		UIALogger.logMessage("Looking for the navigation bar");
		navBar = this.mainContainerView().navigationBar();
		if (!navBar.isVisible()) {
			UIATarget.localTarget().popTimeout();
			throw new Error("Failed to find the navigation bar");
		}

		if (swipeToCameraView) {
			this.swipeToCameraView();
		} else {
			UIALogger.logMessage("Returning to the camera")
            var returnButton;
            if (UIATarget.localTarget().model() == 'iPad') returnButton = navBar.buttons()["Done"];
            else returnButton = this.toolbar().buttons()["Return to Camera"];
            
            if (!returnButton.isVisible()) throw new Error("Cound not exit the Camera Roll.  Button to return to camera is not visible");
            try {
                returnButton.tap();
            } catch(e) {
                throw new Error("Could not tap the button to return to the camera");
            }
			UIATarget.localTarget().delay(2);
		}

		toolbarElement = this.mainContainerView().toolbar();
		if (toolbarElement.isValid()) {
			isInCameraView = (toolbarElement.buttons()["Take Picture"].isVisible() || toolbarElement.buttons()["Record Video"].isVisible()) ? true : false;
		}

		if (!isInCameraView) {
			UIATarget.localTarget().popTimeout();
			throw new Error("Could not reach the camera");
		}

		if (view) this.selectCameraMode(view);
		UIATarget.localTarget().popTimeout();
		return;
		
	} // end getToCameraView
		
		
	
		
/*	camera.getToCameraRoll = function getToCameraRoll(view) {
		this.launchIfNotActive();
		UIALogger.logDebug("Going to camera roll view...");
		var currentView = this.getCurrentView();
		
		switch (currentView) {
			case this.views.CAMERA_ROLL_VIEW:
				UIALogger.logDebug("Already in '" + currentView + "'");
				break ;
			case this.views.CAMERA_VIEW:
				this.viewfinderToolbarButtonWithName("Photo and Video viewer").tap();
				try {
UIALogger.logMessage("Bringing up controls");
					//for cases where we end up in the photo view
					this.bringUpControls();
UIALogger.logMessage("Tapping back button");
					UIATarget.localTarget().delay(2);
					this.mainContainerView().navigationBar().leftButton().tap();
				} catch(e) {
					UIALogger.logError(e.message);
					UIALogger.logDebug("Probably not in Photo/Video view");
				}
				break;
			case this.views.PHOTO_VIEW:
				this.bringUpControls();
				this.mainContainerView().navigationBar().leftButton().tap();
				break;
			case this.views.VIDEO_VIEW:
				this.bringUpControls();
				this.mainContainerView().navigationBar().leftButton().tap();
				break;
			case this.views.DELETE_ACTIONSHEET_VIEW:
				var actionSheet = this.actionSheet();
				actionSheet.cancelButton().tap();
				actionSheet.waitForInvalid();
				UIATarget.localTarget().delay(1);
				this.mainContainerView().navigationBar().leftButton().tap();
				break;
			case this.views.BULK_SELECT_VIEW:
				var navBar = this.mainContainerView().navigationBar();
				navBar.buttons()["Cancel"].tap();
				break;
			case this.views.ACTION_ACTIONSHEET_VIEW:
				var actionSheet = this.actionSheet();
				actionSheet.cancelButton().tap();
				actionSheet.waitForInvalid();
				UIATarget.localTarget().delay(1);
				this.mainContainerView().navigationBar().leftButton().tap();
				break;
			case this.views.EMAIL_VIEW:
				this.mainContainerView().navigationBar().buttons()["Cancel"].tap();
				UIATarget.localTarget().delay(1);
				this.actionSheet().buttons()["Delete"].tap();
				UIATarget.localTarget().delay(1);
				try {
					//for cases where we end up in the photo view
					this.bringUpControls();
					this.mainContainerView().navigationBar().leftButton().tap();
				} catch(e) {
					UIALogger.logError(e.message);
					UIALogger.logDebug("Probably not in Photo/Video view");
				}
				break;
			default:
				throw new Error("Unknown view type '" + currentView + "'");
		}
		
		if (camera.supportsVideo()) {
			//expected view for devices that support video
			var segControls = this.mainContainerView().navigationBar().segmentedControls()[0];
			if (!segControls.isValid()) UIALogger.logWarning("Nav bar with seg controls did not show up");
		} else {
			var navBar = this.mainContainerView().navigationBar().withName("Camera Roll");
			if (!navBar.isValid()) UIALogger.logWarning("'Camera Roll' nav bar did not come up");
		}
		
		currentView = this.getCurrentView();
		if (currentView != this.views.CAMERA_ROLL_VIEW) throw new Error("Could not get to camera roll. Still in '" + currentView + "'");
		
		if (view && this.supportsVideo()) {
			UIALogger.logMessage("Selecting '" + view + "' in the nav bar");
			this.mainContainerView().navigationBar().segmentedControls()[0].buttons().firstWithPredicate("name contains '" + view + "'").tap();
			UIATarget.localTarget().delay(1); //give it a second to update/load
		}
	}
	
	//----------------------------------------------------------------------------------------
	//	Function: getCurrentView
	//		Returns a name for the current view you are on within camera 
	//
	//	Parameters: 
	//		none
	//
	//	Returns: 
	//		one of the values in camera.views corresponding to the current view
	//----------------------------------------------------------------------------------------
	camera.getCurrentView = function getCurrentView() {
		UIALogger.logDebug("Getting current view...");
		
		//Check for the visibility of the toolbar with the capture button
		var toolbarElement = this.mainContainerView().toolbar();
		var isInCameraView = toolbarElement.buttons()["Take Picture"].isVisible() || toolbarElement.buttons()["Record Video"].isVisible();
		UIALogger.logDebug("Toolbar capture button element visiblity: " + isInCameraView);
//		if (isInCameraView && !viewfinderElement.withPredicate("isVisible == 1").isValid())
//			UIALogger.logWarning("Viewfinder is valid, but not visible");
			
		
		UIATarget.localTarget().pushTimeout(0.1);
		var viewName;
		
		if (isInCameraView) {
			viewName = this.views.CAMERA_VIEW;
		} else if (this.mainContainerView().navigationBar().withName("Camera Roll").isVisible()) {
			viewName = this.views.CAMERA_ROLL_VIEW;
		} else if (this.mainContainerView().navigationBar().segmentedControls()[0].isValid()) {
			viewName = this.views.CAMERA_ROLL_VIEW;
		} else if (this.mainContainerView().scrollViews()[0].scrollViews()[0].images().firstWithPredicate("name matches 'Photo, .* orientation'").isValid()) {
			viewName = this.views.PHOTO_VIEW;
		} else if (this.mainContainerView().scrollViews()[0].elements()["Video"].isValid() || 
					this.mainContainerView().scrollViews()[0].scrollViews()[0].elements().firstWithPredicate("name beginswith 'Video'").isValid()) {
			viewName = this.views.VIDEO_VIEW;
		} else if (this.actionSheet().isValid()) {
			var actionSheet = this.actionSheet();
			if (actionSheet.buttons()["MMS"].isValid()) {
				viewName = this.views.ACTION_ACTIONSHEET_VIEW;
			} else if (actionSheet.buttons().firstWithPredicate("name contains 'Delete'").isValid()) {
				viewName = this.views.DELETE_ACTIONSHEET_VIEW;
			} 
		} else if (this.toolbar().buttons()["Copy"].isValid()) {
			viewName = this.views.BULK_SELECT_VIEW;
		} else if (this.isDisplayingEmailComposeSheet()) {
			viewName = this.views.EMAIL_VIEW;
		}
		UIATarget.localTarget().popTimeout();
		
		if (!viewName) {
			this.logElementTree();
			throw new Error("Current view did not match any existing view types");
		}
		
		UIALogger.logDebug("In '" + viewName + "'");
		return viewName;
	}
	
*/	
	//----------------------------------------------------------------------------------------
	//	Function: deletePhoto
	//		Taps the trash icon to delete the photo/video currently being displayed
	//
	//	Parameters: 
	//		none
	//
	//	Returns: 
	//		none
	//----------------------------------------------------------------------------------------
	camera.deletePhoto = function deletePhoto() {
		UIATarget.localTarget().pushTimeout(1);
		UIALogger.logDebug("Deleting photo");
//		var currentView = this.getCurrentView();

//		if (currentView != this.views.PHOTO_VIEW && currentView != this.views.VIDEO_VIEW)
//			throw new Error("Expect to be in photo view to delete it");
		this.bringUpControls();

		var actionSheet;
		if (UIATarget.localTarget().model() != 'iPad') {		
            var toolbar = this.mainContainerView().toolbar();
            if (!toolbar.isVisible()) {
                this.logElementTree();
                UIATarget.localTarget().popTimeout();
                throw new Error("Could not find a toolbar on the current view");
            }
            
            if (!toolbar.buttons()["Delete"].isVisible()) {
                this.logElementTree();
                UIATarget.localTarget().popTimeout();
                throw new Error("Could not find the 'Delete' button in the current toolbar");
            }
            
			if (this.photoToolbarButtonWithName("Delete").isVisible()) {
				UIALogger.logMessage("Tapping Trash Can button to delete photo");
				this.photoToolbarButtonWithName("Delete").tap();
			} else {
				UIALogger.logDebug("Attempting to bring up controls");
				this.bringUpControls();
				this.photoToolbarButtonWithName("Delete").tap();
			}
			UIATarget.localTarget().delay(1);			
			actionSheet = this.actionSheet();
		} else {
			UIALogger.logDebug("Attempting to bring up controls");
			this.bringUpControls();
			UIATarget.localTarget().delay(1);            
			UIALogger.logMessage("Tapping Trash Can button to delete photo");			
            
			var deleteButton = this.mainWindow().navigationBar().buttons()["Delete"];
            if (!deleteButton.isValid()) {
                throw new Error("Cannot find the delete button");
                
            }
            deleteButton.tap();
			UIATarget.localTarget().delay(1);
			actionSheet = this.mainWindow().popover().actionSheet();			
		}

		
		if (!actionSheet.isValid()) throw new Error("Tapped the trash button, but the action sheet did not come up");
		UIATarget.localTarget().delay(1);
		actionSheet.buttons().firstWithPredicate("name contains 'Delete'").tap();
		actionSheet.waitForInvalid();
		UIATarget.localTarget().popTimeout();
	}
	
	//----------------------------------------------------------------------------------------
	//	Function: bulkSelectAllPhotos
	//		Bulk selects all the pictures in camera roll
	//
	//	Parameters: 
	//		none
	//
	//	Returns: 
	//		none
	//----------------------------------------------------------------------------------------
	camera.bulkSelectAllPhotos = function bulkSelectAllPhotos() {
		UIALogger.logDebug("Bulk selecting all photos");
		this.mainContainerView().toolbar().buttons()["Action"].tap();
		if (!this.mainContainerView().navigationBar().withName("Select Photos").isValid()) 
			UIALogger.logWarning("Tapped the action button, but the 'Select Photos' nav bar did not appear");
		var photoRowCells = this.mainContainerView().tableViews()[0].cells().toArray();
		
		var deleteButton = this.mainContainerView().toolbar().buttons()["Delete"];
		if (!deleteButton.isValid()) throw new Error("Did not find the delete button");
		
		var counter = 0;
		for (var i=0; i<photoRowCells.length; i++) {
			photoRowCells[i].scrollToVisible();
			var images = photoRowCells[i].images().toArray();
			for (var j=0; j<images.length; j++) {
				UIALogger.logDebug("Selecting photo number " + (++counter));
				images[j].tap();
				var expectedDeleteName = "Delete";
				if (!deleteButton.withName(expectedDeleteName).isValid())
					throw new Error("Did not find the button '" + expectedDeleteName + "'");
			}
		}
	}
	
	//----------------------------------------------------------------------------------------
	//	Function: deleteAllPhotos
	//		Bulk delete all the pictures in camera roll
	//
	//	Parameters: 
	//		none
	//
	//	Returns: 
	//		none
	//----------------------------------------------------------------------------------------
	camera.deleteAllPhotos = function deleteAllPhotos() {
		UIALogger.logMessage("Deleting all photos");
		this.bulkSelectAllPhotos();
		this.mainContainerView().toolbar().buttons().firstWithPredicate("name contains 'Delete'").tap();
		var actionsSheet = this.actionSheet();
		if (!actionsSheet.isValid()) throw new Error("Tapped the 'Delete' button, but the action sheet did not come up");
		UIATarget.localTarget().delay(1);
		actionsSheet.buttons().firstWithPredicate("name contains 'Delete'").tap();
		actionsSheet.waitForInvalid();
	}
	
	//----------------------------------------------------------------------------------------
	// Function: selectThumbnailWithOptions
	//		Selects a thumbnail in camera roll
	//
	//	Parameters:
	//		options (Object) - dictionary of optional arguments
	//
	//	Optional Parameters: 
	//		photoName (string) - the name of the thumbnail image that should be select. 
	//		randomize (int) - If a photoName is not specified, then this option will be 
	//								used to determine if the thumbnail to be deleted is random.
	//								By default, this is 0, which indicates that the first photo
	//								found is deleted
	//
	//	Returns: 
	//		none
	//----------------------------------------------------------------------------------------
	camera.selectThumbnailWithOptions = function selectThumbnailWithOptions(options) {
		
		if (!options) options = new Options();
		var randomize = (typeof options.randomize != 'undefined') ? options.randomize : 0;
		var thumbnailElement;
		var photoTable = this.mainContainerView().tableViews().firstWithPredicate("isVisible == 1");
		if (!photoTable.isValid()) throw new Error("Did not find a photos table");
		
		if (options.photoName) {
			UIALogger.logDebug("Selecting thumbnail with name '" + options.photoName + "'");
			thumbnailElement = this.cellsContainingElementsWithPredicate(photoTable, "name == '" + options.photoName + "'");
		} else if (randomize) {
			var rows = photoTable.cells().length;
			//Check for the label at the bottom of the table with the # of photos and/or videos and compensate for it 
			var offset = (photoTable.cells()[rows - 1].staticTexts()[0].isValid()) ? 2 : 1;

			var row = system.randomInteger(0,(rows - offset));
			//Using elements().length until [<rdar://problem/9165559> VO does not read the names of Camera roll photos] is fixed
//			var columns = this.mainContainerView().tableViews().firstWithPredicate("isVisible == 1").cells()[row].images().length;
			var columns = this.mainContainerView().tableViews().firstWithPredicate("isVisible == 1").cells()[row].elements().length;
			var column = system.randomInteger(0,columns - 1);
			UIALogger.logMessage("Selecting row: " + row + " and column " + column);
			photoTable.cells()[row].elements()[column].scrollToVisible();
			//Using elements().length until [<rdar://problem/9165559> VO does not read the names of Camera roll photos] is fixed
//			thumbnailElement = photoTable.cells()[row].images()[column];
			thumbnailElement = photoTable.cells()[row].elements()[column];

		} else {
			UIALogger.logDebug("Selecting the first thumbnail");
//			photoTable.cells()[0].images()[0].scrollToVisible();
			photoTable.cells()[0].elements()[0].scrollToVisible();

//			thumbnailElement = photoTable.cells()[0].images()[0];
			thumbnailElement = photoTable.cells()[0].elements()[0];			
		}
		UIATarget.localTarget().delay(2);
		thumbnailElement.logElement();
		thumbnailElement.tap();
        var navBar = this.mainContainerView().navigationBar();
        
        UIATarget.localTarget().pushTimeout(1);
		if (!navBar.elements().firstWithPredicate("name matches '[0-9]+ of [0-9]+'").isValid() && !navBar.elements().firstWithPredicate("name beginswith 'Trim'").isValid()) {
        UIATarget.localTarget().popTimeout();
            this.logElementTree();
			throw new Error("Tapped a thumbnail, but still in thumbnail view - not currently viewing a photo or video");
        }
        UIATarget.localTarget().popTimeout();

	}
	
}