#########################
##	ScriptName:	3GVoiceCallsTest.sh
##	Usage:		./3GCallsOnly.sh {iterations to run} {Max_Length_of_Calls_in_minutes,0=NO LIMT}
##	Purpose: 	To make calls on 3G and keep them active till either a call drop happens or 
##				the device hands over to 2G, keep call active for 30 seconds after HO to ensure that 
##				the HO succeeded.
##				Length of call can be user specified in minutes or 2 hours if given as 0 minutes
##				After every iteration check whether the device is still on 3G or not, otherwise 
##				try forcing 3G by going in/out of Airplane mode.
##	Author:		Puneet Mishra 
##	Revision History
VERSION=v9_VI
##
##  VERSION		9
##	06/22/2008		pmishra@apple.com	First Version	
##	07/13/2010		Jerome Jesu jesu@apple.com. V21 -- Time Synced
##################################################

echo "Running Version $VERSION of the 3G Data and Voice scripts..."
SCRIPTS_DIR="/usr/local/etc/BasebandStressTests/"
WAIT_TIME=60     # Interval between calls.
SCRIPTS_DIR="/usr/local/etc/BasebandStressTests/"
source $SCRIPTS_DIR/config.sh


WAIT_TIME=60     # Interval between calls.
NUMBER="4089619342"
timeBetweenCalls=28


## PARAMETERS VALIDATION
startTime=0
loops=0
interval=0
repetitions=1
dataSize=1
ratSelection=0   # default is 3G

while getopts 'i:t:d:x:r:h' OPTION; 
do
	case "$OPTION" in
		i )	loops=1; 
			TOTAL_CALLS="$OPTARG";;
		t )	interval="$OPTARG";;
		d )	dataSize="$OPTARG";;
		x )	repetitions="$OPTARG";;
		r )	ratSelection="$OPTARG";;
		h ) echo "Usage: ./VoiceCallsTest--DataAndVoice.sh -i <number of calls> -t <minutes per call> -d <data size - 1, 2, 5> -x <repetitions> -r <0 | 1>"; exit 1;;
		/?)	echo "INVALID OPTIONS.\n"; exit 1;;
	esac
done
shift $(($OPTIND - 1))

if [ $loops -ne 1 ]; then
	echo "\nUSAGE: $0    -i <iterations>   -t <Call Interval in minutes>  -d <size of Data File - 1, 2, 5>  -x <data download attempts> -r <0 | 1>"
	echo "		example for 3G: $0   -i 100    -t 10   -d 1   -x 1 -r 0\n"
	echo "		example for 2G: $0   -i 100    -t 10   -d 1   -x 1 -r 1\n"
	exit 1
fi

if  [ $interval -gt 0 ]; then 
	MaxCallLength=`expr $interval \* 60`
else
	MaxCallLength=`expr 2 \* 60 \* 60`	  
	# two hours call
fi

if [ $dataSize -ne 1 ] && [ $dataSize -ne 2 ] && [ $dataSize -ne 5 ]; then 
	echo "Going with Default download of 1MB, since $dataSize MB is not available..."
	dataSize=1
fi

if [ $repetitions -gt 3 ]; then 
	echo "going with Default of 1 repetition..."
	repetitions=1
fi

URL="http://pttest.apple.com/${dataSize}MB.txt"

DEVICE_NAME=`hostname`
tempSuffix=`date | cut -c1-3 -c 5-7 -c9-10 -c12-13 -c15-16 -c18-19 | sed 's/[ ]//g' `;
SUFFIX1="${DEVICE_NAME}_${tempSuffix}"
#SUFFIX1=`echo $DEVICE_NAME | perl -lne '($s,$m,$H,$d,$M,$Y,$D) = localtime(); $Y += 1900; $M++; printf ("%s_%02d%02d-%02d%02d",$_,$M,$d,$H,$m); ' `


##############################################################################
##### HELPER FUNCTIONS 

getBuildVersions()
{
	/usr/local/bin/CoreTelephonyMonitor -q 2> BBVersion.txt &
	sleep 2; killall -9 CoreTelephonyMonitor; sleep 1;
	BB_Build=`grep "Firmware Version" BBVersion.txt | awk '{print $3}' | sed 's/\[//g' | sed 's/\]//g'`
	IMEI=`grep IMEI: BBVersion.txt | awk '{print $2}' | sed 's/\[//g' | sed 's/\]//g'`
	SERIAL=`/usr/local/bin/lockdown_query get NULL SerialNumber 2>&1`
	if [ $DEVICE_NAME == "iPhone" ]; then  DEVICE_NAME=$SERIAL; fi
	APBuild=`sw_vers -buildVersion`
}

initialize()
{
	iterations=0
	HandOverInCurrentCall=NO
	# kill any stray CTM processes from previous iterations/runs
	killall -9 CoreTelephonyMonitor
	killProcess StreamPerf
	killProcess "ping"

	dismissAlerts	
	/usr/local/bin/testCT -x | grep status
	#grep "Call to $NUMBER"  CT.txt
	if [ $? -eq 0 ]; then 
		echo "Calls are active... so ending them."
		/usr/local/bin/testCT -e    #end all active calls
	else
		echo " There are no active calls to end."
	fi
	
	#Go to home scren
	/usr/local/bin/eventer h

	# kill any stray CTM processes from previous iterations/runs
	killall -9 CoreTelephonyMonitor	
	isCallDropped=1
}

generateReport()
{  	
    	echo "\n #################### Processing Logs ##########################"
		echo; ls -rlt $logsDir/log-bb-*;
		sleep 5;
		processCsiLogs
		echo " #################### Processing Completed ##########################\n"
		echo "Device_Name, Baseband Build, Iteration, Pass, Drop, Fail, Total Hand Overs in Test, HandOver In This Call, Call Start Time, Call End Time, Length Of Current Call, CallDrops(CSI_logs), CallFailures(CSI_Logs), Modem Resets, AP_Build, IMEI, SERIAL, 3G Drop, 2G within 15s, 2G after 15s, CALL DROP DURING" 
		echo "$DEVICE_NAME,$BB_Build,$COUNT,$PASS,$DROP,$FAIL,$HandOver,$HandOverInCurrentCall,$callStarted,$callEnded,$currentCallLength,$totalCallDrops,$totalCallFailures,$modemReset,$APBuild,$IMEI,$SERIAL,$umts,$umtsgsm,$gsm,$CALLDROPDURING,"
		echo "$DEVICE_NAME,$BB_Build,$COUNT,$PASS,$DROP,$FAIL,$HandOver,$HandOverInCurrentCall,$callStarted,$callEnded,$currentCallLength,$totalCallDrops,$totalCallFailures,$modemReset,$APBuild,$IMEI,$SERIAL,$umts,$umtsgsm,$gsm,$CALLDROPDURING,"  >> $resultFile.csv
		
		cp $resultFile.csv /var/mobile/Library/Logs/CrashReporter/
		cp callended_${SUFFIX1}.txt /var/mobile/Library/Logs/CrashReporter/
}

dismissAlerts()
{
	echo "Dismissing Alerts.."
	/usr/local/bin/scripter -f /usr/local/etc/scripter/general/Interact.js com.apple.springboard "dismissAlerts(app)"
}

#prints the date in a CFAbsoluteTime format , used for syncing call drops with locations from GPS
logCallEndedDate()
{
	callEnded=`date`
	i=`date +%s`
	dateInCFAbsoluteSeconds=`expr $i - 0`
	echo $dateInCFAbsoluteSeconds >> callended_${SUFFIX1}.txt
	echo " CALL Ended at $dateInCFAbsoluteSeconds -- Playing OLD CAR HORN Sound.\n" 
	killHungProcess  figplayAV 10 &
	/usr/local/bin/figplayAV -a /Library/Ringtones/Old\ Car\ Horn.m4r 
	musicPlayed=$?
	if [ $musicPlayed -eq 0 ]; then echo "OLD CAR HORN was played. Check your ENT specialist if you dont hear."; fi
}	

checkIfCallDropped()
{
		/usr/local/bin/testCT -x | grep status
		#grep -i "There are currently no calls." CT.txt
		isCallDropped=$?
}

logCallPASS()
{
		PASS=`expr $PASS + 1`
		CALLDROPDURING=""
		dismissAlerts
}

processCsiLogs()
{
	cp  $logFiles  $csiLogsDir/
	#ls $csiLogsDir/*csi* | perl -lne '$f = $_; open (F, $f); $f =~ s/(.*\Qlog-bb-\E)(.*)(\Q-csi.\E(.*))/$2/; foreach (<F>) { chomp; if (/\QReason: \E/) { s/^(.*Reason: )//; $i=$_; print "$i,$f"; last; } } close F; '  > /tmp/crashReasons
	
	totalCsiLogs=`ls $csiLogsDir/*csi* | wc -l | awk '{print $1}' `
	totalModemResets=`head -1 $csiLogsDir/*csi*  | grep "modem reset" | wc -l | awk '{print $1}' `
	totalBasebandCrashes=`head -1 $csiLogsDir/*csi*  | grep "baseband crash"| wc -l | awk '{print $1}' `
	totalCallFailures=`head -1 $csiLogsDir/*csi*  | grep -i "call fail" | wc -l | awk '{print $1}' `
	totalCallDrops=`head -1 $csiLogsDir/*csi*  | grep -i "call drop"| wc -l | awk '{print $1}'`
	totalFTO=`head -1 $csiLogsDir/*csi*  | grep "FTO" | wc -l | awk '{print $1}' `
	totalBBResets=$(($totalModemResets + $totalBasebandCrashes))
	#totalBBResets=`echo $totalBBResets | perl -lne ' if (/^\s*$/) { print "0";} else { print;} ' `
	cp /tmp/crashReasons CrashReasons.csv
	
	echo "\n ****************  LOG DETAILS:  *********************"
	echo "  RESETS-$totalModemResets  CRASHES-$totalBasebandCrashes   TOTAL-$totalBBResets"
	echo "  FAIL-$totalCallFailures,  DROPS-$totalCallDrops,  FTO-$totalFTO,"
	echo "  TOTAL-$totalCsiLogs\n"
	echo "\n ****************  REASONS FOR CSI LOGS:  *********************"
	head -1 $logFiles
	cp  $logFiles  $csiLogsDir/
} 


killHungProcess()
{
		echo "Sleeping $2 seconds..."
		sleep $2
		echo "Killing $1"
		GREP="grep $1"
		PIDS=`ps -A | $GREP | grep -v grep | awk '{print $1}'`
		echo " Showing Process.."
		ps -A | $GREP
		echo "KILLING Processes -- $PIDS.\n"
		kill -9 $PIDS
}

killProcess()
{
		echo "Killing $1"
		GREP="grep $1"
		PIDS=`ps -A | $GREP | grep -v grep | awk '{print $1}' `
		echo "KILLING Processes -- $PIDS.\n"
		kill -9 $PIDS
}

generateHoToneAndWaitFor15s()
{
	HandOverInCurrentCall=YES
	killHungProcess  figplayAV 5 &
	/usr/local/bin/figplayAV /Library/Ringtones/Doorbell.m4r &
	echo "HO Happened"
    HandOver=`expr $HandOver + 1`
	# wait for 15 seconds to ensure HO was successful and the call is still going
	# on 2G
	sleep_afterHO=0
	CALLDROPDURING="Within 10 seconds after HO"
						
	while [ $sleep_afterHO -lt 10 ]; do
		sleep 1;
		grep -i "There are currently no calls." CT.txt
		if [ $? -eq 0 ]; then break;  fi
		if [  $sleep_afterHO -gt 15 ]; then  CALLDROPDURING="On 2G 15 seconds after HO"; fi
		CALLDROPDURING="On 2G 15 seconds after HO"
		sleep_afterHO=`expr $sleep_afterHO + 1`; 
	done	
                		
}

reselectTo3G()
{
		echo "Checking for 3G indication"
		checkFor3G_seconds=0
		
		while [ $checkFor3G_seconds -le 60 ]; 
		do
                grep -i kCTRegistrationDataIndicator3 CT.txt
                if [ $? -eq 0 ]; then
                	killall -9 CoreTelephonyMonitor				
					echo "On 3G"
                	break;
                fi
				echo "No 3G yet, waiting for 3G indication"
				sleep 2;	
				checkFor3G_seconds=`expr $checkFor3G_seconds + 2`
		done
		echo "Waited for reselection: $checkFor3G_seconds seconds"
		CALLDROPDURING="On 3G"
}

handleIRATHandover()
{
		generateHoToneAndWaitFor15s
		#check if the call is still active
		checkIfCallDropped
		
		if [ $isCallDropped -eq 0 ]; then
			echo "CALL PASSED: HO Successful"
			logCallPASS
			testCT -l " Call Ending after IRAT Handover."
		else
			echo "CALL DROPPED AFTER IRAT HO"
			DROP=`expr $DROP + 1`
			if [  $sleep_afterHO -ge 10 ]; then ((gsm++));
			else ((umtsgsm++)); fi
			echo " #### Call dropped - $DROP - after IRAT\n #### Logging the Call Ended time."
			logCallEndedDate
		fi	
}

runBackgroundData()
{
	date >> DataStressTest.txt ;
	StreamPerf HTTP -x $repetitions $URL  >> DataStressTest.txt &
}


##############################################################################

# start counter
COUNT=0
PASS=0
FAIL=0
DROP=0
HandOver=0
HandOverInCurrentCall=NO
umts=0
gsm=0
umtsgsm=0
CALLDROPDURING=""
modemReset=0
totalCallDrops=0
totalCallFailures=0
modemReset=0
iterations=0

logsDir="/private/var/wireless/Library/Logs/CrashReporter/Baseband/"
logFiles="$logsDir/*csi*"
csiLogsDir="CsiLogs_Temp"
getBuildVersions
#resultFile=`echo $DEVICE_NAME | perl -lne '($s,$m,$H,$d,$M,$Y,$D) = localtime(); $Y += 1900; $M++; printf ("Results_%s_%02d%02d-%02d%02d",$_,$M,$d,$H,$m); ' `
resultFile="Results_${DEVICE_NAME}_${SUFFIX1}"
echo "Device_Name, Baseband Build, Iteration, Pass, Drop, Fail, Total Hand Overs in Test, HandOver In This Call, Call Start Time, Call End Time, Call Length in s, CallDrops(CSI_logs), CallFailures(CSI_Logs), Modem Resets, AP_Build, IMEI, SERIAL, 3G Drop, 2G within 15s, 2G after 15s, CALL DROP DURING" >> $resultFile.csv
mv $csiLogsDir $csiLogsDir-$SUFFIX1/
mkdir $csiLogsDir/

getBuildVersions
echo 


# Starting the Drive Tests
while [ $COUNT -lt $TOTAL_CALLS ]
do
		COUNT=`expr $COUNT + 1`;
		echo "\n\n******************* Beginnning Iteration: $COUNT ********************"
		initialize

		# Wait for registration on 3G
        /usr/local/bin/CoreTelephonyMonitor 2>CT.txt &
		if [ $ratSelection -eq 0 ]; then
			echo "Wait for the Device to Reselect to 3G"
			reselectTo3G
			echo "Time to Reselect to 3G: $checkFor3G_seconds seconds"
		fi
		dismissAlerts
        

		##### MAKING VOICE CALL		
		callStarted=`date`
 		callStartTimeSeconds=`date "+%s"`
        /usr/local/bin/testCT -c $NUMBER
        
        if [ $? -eq 0 ];  
        then   #call succeeded
        
       			#killall -9 CoreTelephonyMonitor
        		/usr/local/bin/CoreTelephonyMonitor 2> CT.txt &
			
				## Waiting till the Call Drops or Hands over or Call length reached...
	        	while [ 1 ]
    	    	do
						echo "Call status processing..."
						killProcess StreamPerf	
						sleep 5
						
						echo "Checking for RAT Selection and kickoff StreamPerf"
                		if [ $ratSelection -eq 0 ]; 
                		then
							DataContext up
							date >> DataStressTest.txt ;
							runBackgroundData
							sleep 15;
							
							echo "Checking for Data Indicator"
                			grep -i kCTRegistrationDataIndicatorNone CT.txt
                			hoHappened=$?
                			if [ $hoHappened -eq 0 ]; then
								handleIRATHandover
								break;
							fi

                		fi
 
 
       					#check if the call is still active
       					echo "Checking for Call Drop..."
						checkIfCallDropped
						
						if [ $isCallDropped -eq 0 ]; 
						then
                				iterations=`expr $iterations + 1`
                				callLength=`expr $iterations \* 20`
                				echo "Call still going"
                				echo "Approximate time since call is up: $callLength seconds" 
                		
                				if [ $callLength -ge $MaxCallLength ]
                				then
									echo "CALL PASSED: Call Length limit specified by user has been reached"
                					PASS=`expr $PASS + 1`
                					CALLDROPDURING=""
									#end the call
									echo "Ending call after reaching Max Call Time - $MaxCallLength."
									break;
								fi                		
               			else
               					echo "CALL DROPPED ON 3G"
    	    					callEnded=`date`                		
        	        			DROP=`expr $DROP + 1`
        	        			((umts++))
        	        			echo " #### Call dropped on 3G -- Drop = $DROP\n #### Logging the Call Ended time."
        	        			logCallEndedDate
                        		break;                
                		fi  
                             
				done
			
		else	
				#call failed
				echo "CALL SETUP FAILED"
        		callEnded=`date`                
				CALLDROPDURING="Call Setup Failure"
               	FAIL=`expr $FAIL + 1`
               	date
               	echo " #### Call Failed - $FAIL - during ORIGINATION\n ####  Call Ended time is not logged."
               	endFlag=0
               	#logCallEndedDate
    	fi 
    	
		now=`date "+%s"`
    	/usr/local/bin/testCT -x | grep status
		#grep "Call to $NUMBER"  CT.txt
		if [ $? -eq 0 ]; then
				echo "Ending the Call... $COUNT"
				/usr/local/bin/testCT -e    #end all active calls
				callEnded=`date`;
		fi
		
		currentCallLength=$(($now - $callStartTimeSeconds))
    	generateReport
    	echo "Sleep for $timebetweenCalls seconds before making the next call
    	echo $timebetweenCalls
done


killall -9 CoreTelphonyMonitor
sleep 10
echo "Done with the Voice Call Testing for $COUNT calls... Processing the logs again."
generateReport
echo "Done..."

