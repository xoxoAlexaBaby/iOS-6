#import "./iTunes.js"
#import "../libs/PHTesting.js"

//----------------------------------------------------------------------------------------
//	Function: iTunesTest_previewSong
//		Previews a song
//
//	Optional Parameters:	
// 		tabButton (string) - the name of the tab button to be selected. If no value is 
//			provided, "Music" is selected.
//		navButton (string) - the name of the nav button to be selected. If no value is 
//			provided, nothing is selected. 
//		searchItem (string)
//		pathItem (string) - the name of the path item (a path item represents a step in 
//			the "path" to the song). Multiple path item elements can be provided 
//			to navigate to a certain song. 
//		For example:
//			e.g. iTunesTest_previewSong 'tabButton:Music' 'navButton:Featured' 'pathItem:XXX'
//			'pathItem:YYY'
//			 will select "Music" tab bar button, then select the "Featured" navigation bar 
//			 button. Then the function will select the path element with name "XXX", and then 
//			 the function will navigate to "YYY"
//		If no path elements are specified, a random song will be previewed. 
//
//	Returns: 
//		1 if test passes, 0 if it fails
//----------------------------------------------------------------------------------------
function iTunesTest_previewSong() {
	
	var options = new Options();
	options.tabButton = UIAUtility.valuesForKey("tabButton", this.argv, 1); 
	options.navButton = UIAUtility.valuesForKey("navButton", this.argv, 1); 
	options.timeToPlayPreview = UIAUtility.valuesForKey("timeToPlayPreview", this.argv, 1); 
	options.path = UIAUtility.valuesForKey("pathItem", this.argv, this.argv.length);
	options.searchItem = UIAUtility.valuesForKey("searchItem", this.argv, 1);
	
	itunes.getToView("Music"); //will reset things
	if (!options.tabButton && !options.searchItem) options.tabButton = "Music";
	
	UIALogger.logDebug("Track to preview will be selected from '" + options.tabButton + ":" + options.navButton + "'.");
	
	itunes.launchIfNotActive();	
	if (options.searchItem) itunes.search(options.searchItem);
	
	var track = itunes.navigateItemSelection(options.path, {tabButton:options.tabButton, navButton:options.navButton});
	itunes.previewTrack(track);
	if (!itunes.waitForNetworkLoadingToFinish(10)) UIALogger.logWarning("Network loading did not finish");
	
	if (options.timeToPlayPreview) {
		UIALogger.logDebug("Letting the preview play for " + options.timeToPlayPreview + " seconds");
		UIATarget.localTarget().delay(options.timeToPlayPreview);
	}
	
	//might need some verification here
	return this.testResult = 1;
}

//----------------------------------------------------------------------------------------
//	Function: iTunesTest_purchaseSong
//		Purchases a song
//
//	Optional Parameters:	
// 		tabButton (string) - the name of the tab button to be selected. If no value is 
//			provided, "Music" is selected.
//		navButton (string) - the name of the nav button to be selected. If no value is 
//			provided, nothing is selected. 
//		iTunesUsername (string) - the username of the iTunes account that will be used for 
//			purchasing the song
//		iTunesPassword (string) - the password of the iTunes account that will be used for 
//			purchasing the song
//		searchItem (string) - 
//		pathItem (string) - the name of the path item (a path item represents a step in 
//			the "path" to the song). Multiple path item elements can be provided 
//			to navigate to a certain song. 
//		For example:
//			e.g. iTunesTest_previewSong 'tabButton:Music' 'navButton:Featured' 'pathItem:XXX'
//			'pathItem:YYY'
//			 will select "Music" tab bar button, then select the "Featured" navigation bar 
//			 button. Then the function will select the path element with name "XXX", and then 
//			 the function will navigate to "YYY"
//		If no path elements are specified, a random song will be purchased. 
//
//	Returns: 
//		1 if test passes, 0 if it fails
//----------------------------------------------------------------------------------------
function iTunesTest_purchaseSong() {
	
	var options = new Options();
	options.tabButton = UIAUtility.valuesForKey("tabButton", this.argv, 1); 
	options.navButton = UIAUtility.valuesForKey("navButton", this.argv, 1); 
	options.timeToPlayPreview = UIAUtility.valuesForKey("timeToPlayPreview", this.argv, 1); 
	options.path = UIAUtility.valuesForKey("pathItem", this.argv, this.argv.length);
	options.iTunesUsername = UIAUtility.valuesForKey("iTunesUsername", this.argv, 1); 
	options.iTunesPassword = UIAUtility.valuesForKey("iTunesPassword", this.argv, 1); 
	options.searchItem = UIAUtility.valuesForKey("searchItem", this.argv, 1);
	
	if (!options.tabButton && !options.searchItem) options.tabButton = "Music";
	if (options.iTunesUsername) springboard.iTunesUsername = options.iTunesUsername;
	if (options.iTunesPassword) springboard.iTunesPassword = options.iTunesPassword;
	var shouldVerify = (options.path && options.path.length > 0);
	
	UIALogger.logDebug("Track to purchase will be selected from '" + options.tabButton + ":" + options.navButton + "'.");
	
	itunes.launchIfNotActive();
	itunes.getToView("Music"); //will reset things
	if (options.searchItem) itunes.search(options.searchItem);
	
	var track = itunes.navigateItemSelection(options.path, {tabButton:options.tabButton, navButton:options.navButton});
	var priceButton = itunes.priceButtonForTrack(track);
	if (!priceButton.isValid()) {
		this.testError = "Failed to locate a price button for the track.";
		return this.testResult = 0;
	}
	
	var date = new Date(); //this is for alert verification later
	
	UIALogger.logDebug("Tapping the price button");
	priceButton.scrollToVisible();
	priceButton.tap();
	UIATarget.localTarget().delay(1);
	priceButton.logElement();
	if (!priceButton.withPredicate("name == 'BUY VIDEO' or name == 'BUY NOW' or name == 'BUY ALBUM' or name == 'DOWNLOAD' or name == 'BUY SONG' or name == 'GET EPISODE'").isValid()) {
		this.testError = "Tapped the price button but it did not change state";
		return this.testResult = 0;
	}
	UIATarget.localTarget().tap(priceButton.rect());
	UIATarget.localTarget().delay(5); //let the alerts kick in

	var alert = springboard.alertSinceDate(date);
	if (alert && (alert.alertMessageArray[0].indexOf("Unable to purchase") >= 0 || alert.alertMessageArray[0].indexOf("This Apple ID has been disabled for security reasons") >= 0)) {
		this.testError = "Got an alert with the message: " + alert.alertMessageArray[0];
		return this.testResult = 0;
	}
	
	if (!itunes.waitForDownloadBadgeOfZero()) {
		this.testError = "Download badge did not become 0";
		UIALogger.logDebug(this.testError);
		return this.testResult = 0;
	}

	if (shouldVerify) {
		var trackName = options.path[options.path.length-1];
		UIALogger.logDebug("Verifying '" + trackName + "' was purchased by searching in spotlight");
		springboard.getToSpotlight();
		
		var trackElement = springboard.search(trackName, {resultPredicateString:"name contains '" + trackName + "'"});
		if (trackElement.isValid()) {
			return this.testResult = 1;
		} else {
			this.testError = "Could not find the downloaded item in spotlight";
			return this.testResult = 0;
		}
	}
	
	return this.testResult = 1;
}

// Create self tests -- this is an unnamed function, just to make sure any local variables stay in the correct context
(function() {	
	if (typeof itunes.selfTests == 'undefined') {
		itunes.selfTests = new Array();
	}
	itunes.selfTests.push(phtCreateTest("PreviewRandomSong", [], iTunesTest_previewSong, "Preview random song"));
	if (UIATarget.localTarget().model() == 'iPad')
		itunes.selfTests.push(phtCreateTest("PreviewSong", ["searchItem:Run Back to Your Side", "pathItem:Run Back to Your Side", "pathItem:Run Back to Your Side"], iTunesTest_previewSong, "Preview song"));
	else
		itunes.selfTests.push(phtCreateTest("PreviewSong", ["searchItem:Run Back to Your Side", "pathItem:Run Back to Your Side"], iTunesTest_previewSong, "Preview song"));
	itunes.selfTests.push(phtCreateTest("PurchaseFreePodcast", ["searchItem:Apple Education", "pathItem:Apple Education", "pathItem:Apple Science Innovator"], iTunesTest_purchaseSong, "Purchase free podcast"));
}())
