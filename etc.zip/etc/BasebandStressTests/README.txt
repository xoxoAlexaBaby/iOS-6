
SCRIPTS in /usr/local/etc/BasebandStressTests/ folder help:
===========================================================


IPC Stress Test Scripts:
========================
1.  IPCStressTest_v21.sh  -- Northstar Stress test script baseline
2.  IPCStressTest_v24.sh  -- Addition of mini-stress tests to v21
3.  IPCDataStressTest_v24.sh  -- NorthStart Data Stress Test Script



Twitterriffic Stress Tests:
===========================
TwitterificStressTest_v3.sh -- northStart script with support for importing results to webserver



MOMT Call Stress Test Scripts:
==============================
MTStressTest.sh -- to be run on the MT device with SMSBuddy
MTStressTest.sh -- to be run on the MO device with SMSBuddy


Drive Test Scripts:
===================
3GVoiceCallsTest-AudioFeedback_v18.sh  -- with bug fixes for NorthStar
DataLoop.sh  -- can be used for Multi-call during Drive tests


Auto-Answer scripts:
====================
setAutoAnswerOnReset.sh -- Script to set up auto-answer after Baseband resets
setupAutoAnswer.sh  -- scripts to set auto-answer for Kirkwood/Northstar


Get Hang Logs:
==============
Collecting of some useful logs when a device hangs.


Other Scripts:
==============
These are scripts that are used by some of the above parent scripts during stress tests or drive tests or MOMT tests. They are not meant for runnning individually.


Configuration
=============
There are 2 servers that needs to be known for any issues or failures - web server and the logs server. All logs are automatically posted to the Logs Server every 2 hours from each device. All Raw Stats are posted to the Logs Server every 15 minutes. The Raw stats are processed every 1 hour and the results are posted to the web-page. All IPC Stress Tests can be kicked off from anywhere within the LAN where the servers are reachable.
1. http://telephonyqa.apple.com/results/ -- Web Sever 
2. afp://telephonylogs.apple.com/ -- Logs Server. 
Mount points are listed below.
     StressTestLogs:   Baseband and other Crash logs
     StressTestStats:  Raw Statistics
     StressTestScripts:  Location for Updated ipc Stress Test Scripts and other scripts that goes on MAC for starting/setting up the stress rack.
     TelephonyLogs:   For other logs


Installation of Scripts on MAC
==============================
1. Copy the scripts from ScriptsOnMac on afp://telephonylogs.apple.com/StressTestScripts/. Run the installScripts to install them on your MAC. This is a one-time set-up
2. Then Copy the IPCStressTestScripts with the latest version number to your desktop. or copy whenever a new version is available
3. Open the IPCStressTest_vXX.sh or IPCDataStressTest_vXX.sh file and verify whether one of the lines in the beginning is as shown below and not commented out:
      SERVER_ADDR="17.202.20.33"


Device set-up for Stress Tests
==============================
1. Update AP on multiple devices using Purple Restore
2. Update the baseband on multiple devices using the scripts below:
      ICE2:   UpdateBaseband.sh   <Path to Baseband_Build/>
      ICE3:   UpdateBaseband_ICE3.sh   <Path to Baseband_Build/>
3. Modify prepareDevices.sh script based on want needs to be deleted from the device.
4. Set-up tracing.
5. Run the script prepareDevices.sh to clean out all old logs. Make sure that these logs are not required anymore. This also reboots the device
6. Once all the devices boot-up, now kick off the Stress Tests Scripts. There are 2 ways to start the Stress Tests on any device. Either one can be used based on the need.

The easiest way to kick-off multiple devices simultaneously if the installation of Scripts on MAC listed above was followed. The other way is to telnet into each device and manually start them. 


Starting Stress Tests on each device
====================================
1. Telnet into Device 2. Clean up old logs if not done previously. Then do,
           mkdir StressTest_MonDay/
           cd StressTest_MonDay/
           nohup /usr/local/etc/BasebandStressTests/IPCStressTests_vXX.sh  "options" &
3. This would start the Stress Tests and run as long as the number of iterations. Default - 1000 iterations. 4. Repeat the above steps for each device.


Starting Stress Tests simultaneously
====================================
1. Clean up old logs if not done previously.
           nohup /usr/local/etc/BasebandStressTests/IPCStressTests_vXX.sh  "options" &
2. Connect all the devices to the MAC and run the script below:
           StartStressTests.sh <PATH TO IPC SCRIPTS>/IPCStressTest_vXX.sh “options"  <DirForStressTests> & 

                        <PATH TO IPC SCRIPTS> --  path for IPCStressTestScripts_Vxx Folder on MAC where the scripts are copied to
                        <DirForStressTests>   --  directory where all Stress Test logs are collected and to look for if there any issues.
                         options              --  listed in the section below


Options for Running Stress Tests
================================
Default options used: "-u -g -m -a"
 -h <HOLD TIME in seconds> :  Call interval time, 	Default - 15s
 -i <number of Iterations> :  Total Iterations, 	Default - 1500
 -n <Loop Back Number>     :  Loopback Phone number, 	Default - +14089748874
 -l <sms Loop Back Number> :  SMS Phone Number, 	Default - +11111111111
 -j <SSID>                 :  Specify SSID, 		Default - CSIQA
 -p <WEP Key>              :  Specify WEP key, 	Default - 123456789a
 -u                        :  Upload Logs/Stats, 	Default - DISABLED
 -g                        :  Enable Locmon, 		Default - DISABLED
 -m                        :  Enable MultiRAB, 	Default - DISABLED
 -s                        :  SMS Failure Logging, 	Default - DISABLED
 -w                        :  Disable Sleep Cycling,	Default - Enabled
 -d                        :  Data Download Failure Logging 	Default -  DISABLED
 -a                        :  Additional Logging Enabled, 	Default - Disabled.
 -t                        :  Log Top output/Memory Dumps, 	Default - Disabled.
 -k                        :  Disable Logs Uploading with -u option.


What to look for if any issues
==============================
If the logs/stats are not uploaded, you can do one or more of the below:
 -- check telephonylogs.apple.com whether it is reachable and the corresponding folder is created 
 -- check for disk usage on telephonylogs.apple.com. Clean up unwanted logs if the disk space is full
 -- reboot the machine if needed and if everything looks okay in the telephonylogs machine
 -- reboot telephonyqa.apple.com if the stats are not posted to the webpage
 -- log into the device and check whether the logs are still there on the device
 -- look into the <DirForStressTests_MonDay> Created when the stress tests are started
 -- check the options when you started the stress tests. -u might have been left out.

If there are any script issues, file a bug against Purple Telephony Scripts 1.0 
The <DirForStressTests> has tons of logs like nohup.out, LOG_**.log, DownloadStressTest.txt, UploadStressTest.txt and others which would give enough info on what happened during the stress tests. 
LOG_DeviceName_Timestamp.log which has the timestamp for all tests executed. This would be really useful in debugging certain periods or time intervals or power issues. 
