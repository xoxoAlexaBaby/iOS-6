#!/usr/bin/perl

use strict;
use warnings;

use File::Basename;
use File::Copy;
use File::Path;

use constant SUCCESS => '__SUCCESS__';
use constant FAIL => '__FAIL__';

# ---
# Process and validate options
# ---

# Usage: $0 [ini_file]
my $iniFile = shift;
unless ($iniFile) {
	$iniFile = "/var/root/reset/reset.ini";
}
unless (-r $iniFile) {
	die "ERROR: Can't read config file '$iniFile'.\n";
}

if ($iniFile =~ /tethered\.ini$/i) {
	# Special case for tethered devices
	# Read list of phone numbers from command line
	my $shouldContinue = 0;
	my $phoneNumber = `/usr/local/bin/CoreTelephonyMonitor -n`;
	chomp $phoneNumber;
	if ($phoneNumber) {
		foreach my $arg (@ARGV) {
			if ($phoneNumber =~ /$arg/) {
				# Only continue if this device's phone number matches one from the command line
				$shouldContinue = 1;
				last;
			}
		}
		unless ($shouldContinue) {
			print "INFO: Device phone number '$phoneNumber' not in list, stopping here.\n";
			exit(0);
		}
	}
	else {
		print "INFO: This device does not have a phone number; stopping here.\n";
		exit(0);
	}
}

# ---
# Globals
# ---

my %default = ();
my @copy = ();
my @sync = ();
my @exec = ();
my $success = 1;
our $cache1;

# Verify psync.pl can be found
my $psyncFile = `which psync.pl`;
chomp $psyncFile;
die "ERROR: psync.pl cannot be found on the path\n" unless (-x $psyncFile);
#$psyncFile = '/pep/AutoPPT/bin/psync.pl';

# ---
# Read the config file
# ---

# Per-file states
my $section = '';
my $domain = '';

open(INI, $iniFile) || die "ERROR: Can't open config file '$iniFile': $!\n";
print "Reading config file '$iniFile' ...\n";
while (<INI>) {
	my $line = $_;
	
	# Per-line states
	my $parameter = '';
	my $value = '';

	# Parse line
	chomp $line;
	if ($line && $line !~ /^\s*[;#]/) {
		# Line is not blank and not a comment
		if ($line =~ /^\s*\[\s*(.*?)\s*\]/) {
			# Line is a section
			$section = $1;
			$domain = '';
		}
		elsif ($line =~ /^\s*(.*?)\s*=\s*(.*?)\s*$/) {
			# Line is a parameter=value
			$parameter = $1;
			$value = $2;
		}
		elsif ($line =~ /^\s*(.*?)\s*$/) {
			# Line is a parameter
			$parameter = $1;
			$value = '';
		}
		else {
			print "WARNING: Weird line '$line'\n";
		}
	}
	
	# Process line
	if ($parameter) {
		if ($section =~ /default/i) {
			# Store user preferences to set
			if ($parameter =~ /domain/i) {
				$domain = $value;
			}
			else {
				if ($domain) {
					if (exists $default{$domain}->{$parameter}) {
						print "WARNING: Replacing existing default variable '$parameter'\n";
					}
					$default{$domain}->{$parameter} = $value;
				}
				else {
					print "ERROR: In [$section] line '$line': Must specify domain first\n";
					$success = 0;
				}
			}
		}
		elsif ($section =~ /sync/i) {
			# Store paths to sync
			my $cacheFile = $value;
			my $subPath = '';
			if ($value =~ /^(.*?):\/*(.*)$/) {
				$cacheFile = $1;
				$subPath = $2;
			}
			my %hash = ();
			$hash{path} = $parameter;
			$hash{cacheFile} = $cacheFile;
			$hash{subPath} = $subPath;
			push @sync, \%hash;
		}
		elsif ($section =~ /copy/i) {
			# Store files or directories to copy
			my %hash = ();
			$hash{source} = $parameter;
			$hash{dest} = $value;
			push @copy, \%hash;
		}
		elsif ($section =~ /exe/i) {
			# Store commands to execute
			push @exec, $parameter;
		}
		else {
			print "WARNING: Unknown section '$section'\n";
		}
	}
}
close(INI);

unless ($success) {
	die "FAILED!\n";
}

# ---
# Make it so
# ---

print "Resetting ...\n";

# Sync paths
foreach my $hash (@sync) {
	my $syncPath = $hash->{path};
	my $cacheFile = $hash->{cacheFile};
	my $subPath = $hash->{subPath};
	my $syncPathStr = $syncPath . ($subPath ? "/$subPath" : "");
	my $sourcePath = $cacheFile;
	$sourcePath =~ s/\.cache$//i;
	print "- Syncing '$syncPathStr' ...\n";
	if ( run( "'$psyncFile' '$sourcePath' '$syncPath'". ( $subPath ? " -s '$subPath'" : "" ) . ( -d $sourcePath ? "" : " -f" ) ) eq FAIL() ) {
		die "ERROR: Can't sync path: '$syncPath' using '$cacheFile'\n";
	}
	else {
		print "+ Synced '$syncPathStr' using '$cacheFile'\n";
	}
}

# Copy files or directories
foreach my $hash (@copy) {
	my $source = $hash->{source};
	my $dest = $hash->{dest};
	print "- Copying '$source' to '$dest' ...\n";
	if (-f $source) {
		if (File::Copy::copy($source, $dest)) {
			print "+ Copied file '$source'\n";
		}
		else {
			die "ERROR: Can't copy file '$source': $!\n";
		}
	}
	else {
		`ditto -V '$source' '$dest'`;
		if ($?) {
			die "ERROR: Can't copy directory '$source': $!\n";
		}
		else {
			print "+ Copied directory '$source'\n";
		}
	}
}	

# Set defaults
if (%default) {
	print "- Setting defaults ...\n";
	foreach my $domain (keys %default) {
		foreach my $variable (keys %{$default{$domain}}) {
			die "ERROR: Can't set default: $domain '$variable' = '$default{$domain}->{$variable}'.\n" if (setDefault($domain, $variable, $default{$domain}->{$variable}) eq FAIL());
			print "+ Set $domain: '$variable' = '$default{$domain}->{$variable}'\n";
		}
	}
}

# Execute commands
foreach my $cmd (@exec) {
	print "- Executing '$cmd' ...\n";
	if ( run($cmd) eq SUCCESS() ) {
		print "+ Completed\n";
	}
	else {
		die "ERROR: Command '$cmd' failed.\n";
	}
}

# Finished
print "Reset succeeded\n";
exit 0;

# --- Good old-fashion subroutines ---

sub getDefault {
	my ($domain, $variable) = @_;
	my $out = `defaults read $domain $variable`;
	return FAIL() if ($?);
	if ($out) {
		return $out;
	}
	else {
		return undef;
	}
}

sub setDefault {
	my ($domain, $variable, $value) = @_;
	`defaults write $domain $variable $value`;
	if (getDefault($domain, $variable) =~ /^$value/) {
		return SUCCESS();
	}
	else {
		return FAIL();
	}
}


sub run {
	my ($command) = @_;
	if (open(RUN, "$command 2>&1 |")) {
		while (<RUN>) {
			print $_;
		}
		close(RUN);
		if ($?) {
			return FAIL();
		}
		else {
			return SUCCESS();
		}
	}
	else {
		return FAIL();
	}
}
