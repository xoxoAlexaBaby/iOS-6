#!/bin/sh

# powerprofiler.sh
# 
#
# Copyright © 2008 Apple Inc. All Rights Reserved.

export WIFI_AP="ma1-3291"
export WIFI_PASS="4xc139g!"
export SMS_NUMBER=""
export VIDEO_NAME="03 VGA \!DRM TV Show, 24"
export SONG_NAME="02 AAC stereo, Blush Response"

source /usr/local/bin/powerprofiler_base.sh

# Run the background logger
export EPOCH_SECS="`Wedgie -e`"
export PP_TIMESTAMP="powerprofiler_`date -r $EPOCH_SECS +%h_%d_%y_%H:%M:%S`"

mkdir /var/logs/$PP_TIMESTAMP

export LEVEL_LOG_NAME="/var/logs/$PP_TIMESTAMP/levels.txt"
export TEST_LOG_NAME="/var/logs/$PP_TIMESTAMP/tests.txt"
export META_LOG_NAME="/var/logs/$PP_TIMESTAMP/meta.txt"
export RP_LOG="/var/logs/$PP_TIMESTAMP/rp_playback.txt"

Wedgie -a -t 3000000 > $LEVEL_LOG_NAME &

touch $META_LOG_NAME
sw_vers|sed 's/:./=/' >> $META_LOG_NAME
ioreg -l -w0|grep -i IOPlatformSerialNumber|sed 's/[\|\ \"]//g' >> $META_LOG_NAME

echo "POWERPROFILER: START" `date +%s`

# modify the commands below to define your test procedure
# times are in minutes
talker2g() {
echo "Talker 2G"
echo "profile=Talker 2G" >> $META_LOG_NAME
browse_edge 48
browse_wifi 12
makecall_2g 240
sms 12
video 30
music 12
maps 60
}

talker3g() {
echo "Talker 3G"
echo "profile=Talker 3G" >> $META_LOG_NAME
browse_hsdpa 48
browse_wifi 12
makecall_2g 120
makecall_3g 120
sms 12
video 30
music 12
maps 60
}

surfer2g() {
echo "Surfer 2G"
echo "profile=Surfer 2G" >> $META_LOG_NAME
browse_edge 144
browse_wifi 36
makecall_2g 60
sms 12
music 12
maps 12
}

surfer3g() {
echo "Surfer 3G"
echo "profile=Surfer 2G" >> $META_LOG_NAME
browse_hsdpa 144
browse_wifi 36
makecall_2g 30
makecall_3g 30
sms 12
music 12
maps 12
}

texter2g() {
echo "Texter 2G"
echo "profile=Texter 2G" >> $META_LOG_NAME
browse_edge 14
browse_wifi 5
makecall_2g 60
sms 180
video 90
music 180
maps 6
}

texter3g() {
echo "Texter 3G"
echo "profile=Texter 3G" >> $META_LOG_NAME
browse_hsdpa 14
browse_wifi 5
makecall_2g 30
makecall_3g 30
sms 180
video 90
music 180
maps 6
}

gamer2g() {
echo "Gamer 2G"
echo "profile=Gamer 2G" >> $META_LOG_NAME
game 240
browse_edge 14
browse_wifi 4
makecall_2g 60
sms 12
}

gamer3g() {
echo "Gamer 3G"
echo "profile=Gamer 3G" >> $META_LOG_NAME
game 240
browse_hsdpa 14
browse_wifi 4
makecall_2g 30
makecall_3g 30
sms 12
}

# high-sleep-low current profile
high_sleep_low_current() {
    while true; do
	scripter -f /usr/local/etc/scripter/general/ExecuteTest.js settingsTest_chooseCheckmarkedItem "General" "Never" "Auto-Lock"
	thermal_virus 60 
	phone_sleep 30 
    done
}

video_capture_sleep() {
    while true; do
	camera_videorecord 30   
	phone_sleep 60         
    done
}

sleep_overnight() {
    # sleep for 12 hours, simulate overnight.
    phone_sleep 720
    thermal_virus 1000
}

sleep_weekend() {
    # sleep 40 hours.
    phone_sleep 2400
    thermal_virus 1000
}

ota_3g() {
    while true; do 
	makecall_3g 60
    done
}

surfnsleep_short() {
    while true; do
	browse_wifi 30;
	phone_sleep 5;
    done
}

surfnsleep_long() {
    while true; do
	browse_wifi 30;
	phone_sleep 60;
    done
}

surfnsleep_long_3g() {
        while true; do
	    browse_hsdpa 30;
	    phone_sleep 60;
	done
}
			    
videoHD() {
    export VIDEO_NAME="generations-de-atv-hd-preview-keyed";
    video 99999999
}

maps() {
        # disconnect from wifi.
        scripter -f /usr/local/etc/scripter/general/ExecuteTest.js settingsTest_setWifi "ON"
	# connect 3g network.
	scripter -f /usr/local/etc/scripter/general/ExecuteTest.js settingsTest_ChangeSingleSwitch "General" "Enable 3G" "OFF" "Network"
    scripter -f /usr/local/bin/MapsDirectionScript.js
}

maps_3g() {
        # disconnect from wifi.
        scripter -f /usr/local/etc/scripter/general/ExecuteTest.js settingsTest_setWifi "OFF"
	# connect 3g network.
	scripter -f /usr/local/etc/scripter/general/ExecuteTest.js settingsTest_ChangeSingleSwitch "General" "Enable 3G" "ON" "Network"
    scripter -f /usr/local/bin/MapsDirectionScript.js
}

wifi_browse() {
	browse_wifi 12000;
}

browse3g() {
    browse_hsdpa 12000;
}

streaming_264() {
    scripter -f /usr/local/etc/scripter/general/ExecuteTest.js safariTest_loadSafariPage "http://creek.apple.com/ROTK.php";
}

USAGE="Usage:  $0 [ -t2|-t3|-x2|-x3|-s2|-s3|-g2|-g3 ]"
case "$1" in
	-w1) wifi_browse;;
	-w2) browse3g;;
	-z1) surfnsleep_short;;
	-z2) surfnsleep_long;;
	-z3) surfnsleep_long_3g;;
	-t2) talker2g;;
	-t3) talker3g;;
	-x2) texter2g;;
	-x3) texter3g;;
	-s2) surfer2g;;
	-s3) surfer3g;;
	-s4) streaming_264;;
	-f1) maps;;
	-f2) maps_3g;;
	-g2) gamer2g;;
	-g3) gamer3g;;
	-r1) random;;
	-r2) playback $2;;
	-h1) high_sleep_low_current;;
	-v1) video_capture_sleep;;
	-v2) camera_videorecord $2;;
	-v3) videoHD;;
	-c0) stop_charging;;
	-c1) start_charging;;
	-m1) longterm_test;;
	-n1) sleep_overnight;;
	-n2) sleep_weekend;;
	-o1) ota_3g;;
	-y1) youtube_3g;;
	-y2) youtube_wifi;;
	*) echo "$USAGE"
	exit 0
	;;
esac

echo "POWERPROFILER: DONE" `date +%s`


# Stop the background logger
killall Wedgie

# make sure we don't leave the phone in a bad state.
start_charging

scripter -f /usr/local/etc/scripter/general/ExecuteTest.js notesTest_createNote "PowerProfiler DONE\!" "xxx"
