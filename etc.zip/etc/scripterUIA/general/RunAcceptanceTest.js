#!/usr/local/bin/scripter -uiautomation YES -f

// Acceptance Test Runner for (SWAT) 
// Richard Heard rheard@apple.com

#import "../libs/PHTesting.js"
#import "../libs/HarnessUtility.js"

#import "../settings/SettingsTests.js"
#import "../safari/SafariTests.js"
#import "../maps/MapsTests.js"
#import "../ipod/iPodTests.js"
#import "../notes/NotesTests.js"
#import "../mail/MailTests.js"
#import "../contacts/ContactsTests.js"
#import "../clock/ClockTests.js"
#import "../calculator/CalculatorTests.js"
#import "../phone/PhoneTests.js"
#import "../appstore/AppStoreTests.js"
#import "../calendar/CalendarTests.js"
#import "../weather/WeatherTests.js"
#import "../camera/CameraTests.js"
#import "../springboard/SpringboardTests.js"
#import "../youtube/YouTubeTests.js"
#import "../stocks/StocksTests.js"
#import "../system/SystemTests.js"
#import "../messages/MessagesTests.js"
#import "../photos/PhotoTests.js"


#import "../phone/PhoneAcceptanceTestCatalogue.js"			// Phone Acceptance tests
#import "../ipod/iPodAcceptanceTestCatalogue.js"			// iPod Acceptance tests
#import "../mail/MailAcceptanceTestCatalogue.js"			// Mail Acceptance tests
#import "../messages/MessagesAcceptanceTestCatalogue.js"	// Messages Acceptance tests
#import "../safari/SafariAcceptanceTestCatalogue.js"		// Safari Acceptance tests
#import "../notes/NotesAcceptanceTestCatalogue.js"			// Notes Acceptance tests
#import "../contacts/ContactsAcceptanceTestCatalogue.js"	// Contacts Acceptance tests

//Above files contain lines like below for each test
	//function phtCreateTest(name, argv, main, desc);
	//<appname>.acceptanceTests.push(phtCreateTest("Notes_CreateNote", ["UnitTest Note 1", "Hi!  I like being a note.  How about you?"], notesTest_createNote, "Create a Note"));

ACCEPTANCE_TEST_CATALOGUE = new Array();

for (appName in UIAApp._applications) {
	var app = UIAApp._applications[appName];
	//UIALogger.logDebug("ACCEPTANCE_TEST_CATALOGUE tests for: " + appName + "  " + app.name);
	if (typeof app.acceptanceTests != 'undefined') {
		//UIALogger.logDebug("adding acceptanceTests length = " + app.acceptanceTests.length);
		ACCEPTANCE_TEST_CATALOGUE = ACCEPTANCE_TEST_CATALOGUE.concat(app.acceptanceTests);	
	}
	else "app.acceptanceTests is undefined";
	
	//UIALogger.logDebug("ACCEPTANCE_TEST_CATALOGUE length = " + ACCEPTANCE_TEST_CATALOGUE.length);
}

function usage() {
	system.println("usage: RunAcceptanceTest.js --jstestid <jSTestID> [--reportpath <string>] [--uialogfilename <string>] [--syslogfilename <string>] [--resultfilename <string>] ");
   system.println("	--jstestid <string> REQUIRED the JS test id to run (from ShipWreck jSTestID field)");
	system.println("	--reportpath     full path for the results files");
	system.println("	--uialogfilename	name for the syslog file");
	system.println("	--syslogfilename	name for the syslog file");
	system.println("	--resultfilename	name for the syslog file");
	system.println("	--list list all the available acceptance tests");
	system.println("	--help | -h	usage description");
}

function main() {
	//system.println("starting...");
	// seed the generator, so that any random events are the same for every run
	system.setRandomSeed(1);
   
	
	// process command line arguments
	var options = new Options();
	if (options.help || options.h) {
		usage();
		return;
	}
   //list
	if (options.list || options.l) {
		harness_listTests(ACCEPTANCE_TEST_CATALOGUE);
		return;
	}
   
   //get the test id to run
   if (! options.jstestid) {
      system.println(" --jstestid is required but could not be found.");
      usage();
      return;   
   }
   var testid = options.jstestid;
   
   //default arguments / command line overides. 
	var reportpath = (options.reportpath) ? options.reportpath : "/var/mobile/Library/Logs/Testing/";
   var uialogfilename = (options.uialogfilename) ? options.uialogfilename : "uialog.txt";
   var syslogfilename = (options.syslogfilename) ? options.syslogfilename : "syslog.txt";
   var crashlogfilename = (options.crashlogfilename) ? options.crashlogfilename : "crashes.txt";
   var resultfilename = (options.resultfilename) ? options.resultfilename : "result.txt";
   
   harness_makeDirectory(reportpath);
	harness_removeFile(reportpath + "/" + uialogfilename);
	harness_removeFile(reportpath + "/" + syslogfilename);
	harness_removeFile(reportpath + "/" + crashlogfilename);
	harness_removeFile(reportpath + "/" + resultfilename);
   
   
   
   //locate the test we are interested in running.
   var runTest = false;
   for (i in ACCEPTANCE_TEST_CATALOGUE){
      var test = ACCEPTANCE_TEST_CATALOGUE[i];
      if (test.testName == testid){
         runTest = test;
         break;
      }
   }
   
   if (runTest == false){
      //test not found.
      system.println("A test with id: '" + testid + "' could not be found.");
      //lets write ISSUE to the result.txt file (ie test with this name not found)
      var resultfile = new File(reportpath + "/" + resultfilename, "w");
      resultfile.write("ISSUE:A test with id: '" + testid + "' could not be found.\n");
      return;
   }
   
   
   //send logs to the uialogs file and capture a screenshot on logFail
	if (reportpath && uialogfilename) new UIAFileLogger(reportpath + "/" + uialogfilename);    
	if (reportpath) new UIACaptureScreenLogger(reportpath);

   system.println("--------------Running Test--------------");
	harness_runAcceptanceTest(runTest, reportpath, syslogfilename, crashlogfilename, resultfilename);
	system.println("---------Finished Running Test----------");
}

main();


//------------------------------------------------------------------------------

function harness_runAcceptanceTest(test, reportpath, syslogfilename, crashlogfilename, resultfilename){
      
   var syslogfile = new File(reportpath + "/" + syslogfilename, "w");
   var crashlogfile = new File(reportpath + "/" + crashlogfilename, "w");
   var resultfile = new File(reportpath + "/" + resultfilename, "w");
   
   
	//save the start time so we know which part of the syslog to grab.
   var testStartTime = new Date();
   
   
   var testName = test.testName;
   var functionName = harness_getNameOfFunctionMain(test.main.toString());
   var functionPrefix = harness_getPrefixOfFunctionName(functionName);
   
   var deviceInfo = harness_getDeviceInfo();
   UIALogger.logMessage(deviceInfo);
   
   //----------- RUN THE TEST -----------
   
   try {
      // Make sure the device is still unlocked and that there are no alerts
      UIATarget.localTarget().unlockScreenIfNecessary();
      
      
      // Execute the test
      UIALogger.logMessage("Running Acceptance Test: '" + test.testName + "'");
      test.execute();
      
      // run some optional utilities after each test
//      UIAUtility.runUtilities("com.apple.harness");
   } catch(e) { //RH: this seems to be redundant, although i guess it catches errors in the phtest object.
      test.testResult = 0;
      test.testError = e.message;
      test.onException(e);
   }
   
   //Set the timeout to the default timeout
   if (UIATarget.localTarget().timeout() != UIATarget.defaultTimeout) 
      UIATarget.localTarget().setTimeout(UIATarget.defaultTimeout);
   
   //workaround for cases where the alert does not get dismissed
   try {
      var alert = UIATarget.localTarget().frontMostApp().alert();
      if (alert.isValid()) {
         UIALogger.logError("UNEXPECTED ALERT -- this should have been dismissed earlier");
         alert.logElementTree();
         try {
            UIATarget.onAlert(alert);
         } catch(e) {
            UIALogger.logError(e);
         }
         
         if (!alert.waitForInvalid()) {
            alert.buttons()[0].tap(); //default handler type behavior
            if (!alert.waitForInvalid()) UIALogger.logError("Alert did not go away");
         }
      } 
   } catch(e) {
      UIALogger.logError("Encountered error while checking for alerts: " + e);
   }
   
   // Log the result to the proper file
   var result;
   if (test.testResult == 1) 	result = "PASS";
   else if (test.testResult <= 0)	result = "FAIL";
   else result = test.testResult;	// sometimes we want a number as a result
   var resultString = test.testError;
   var description = test.desc ? test.desc : test.testName;
   if (resultString != "") {
      UIALogger.logMessage("Test Error Encountered: " + resultString);
   } 
   
   UIALogger.logMessage("Test Result: " + result + " (For Test: " + test.testName + ")");
   resultfile.write(result + ":" + resultString + "\n");
   
   
   system.sleep(3); // delay to make flow more user-like and to give us time to wait for crashes to register
   
   
   var now = new Date();
   var timeSinceLastTest =  (now.getTime() - testStartTime.getTime());
   var success = false;
   
   // get from Crash Reporter and DumpBasebandCrash
   var newCrashFiles = harness_crashLogPathsFromSysLog(timeSinceLastTest);
   
   if (newCrashFiles.length) {
      for (var i=0; i < newCrashFiles.length; i++) {
         // add contents of crash log to array of crashes.
         var crashContents = _harness_getCrashReportFromPath(newCrashFiles[i]);
         crashContentsList.push(crashContents);
         
         newCrashFiles[i] = _harness_processNameFromCrashLogPath(newCrashFiles[i]);				
      }
      newCrashFiles = UIAUtility.consolidateArray(newCrashFiles, "times");  // consolidate the array of crashes
      var i = 0
      while (i < newCrashFiles.length) {
         crashlogfile.write("CRASH: " + newCrashFiles[i] + "\n");
         i++;			
      }
   }
   
   
   // add syslog messages that have a level less than or equal to four
   var syslogOut = UIAUtility.logToolOutput("/usr/bin/syslog -k Level le 4 -k Time ge -" + Math.floor(timeSinceLastTest/1000), 60);
   if (syslogOut) syslogfile.write(syslogOut + "\n");
   
   // add important sandboxd information to output and prefix it with "sandbox: "
   var sandboxOutput = UIAUtility.logToolOutput("/usr/bin/syslog -k Time ge -" + Math.floor(timeSinceLastTest/1000), 60, "sandbox"); 
   var sandboxFile = new File("/var/mobile/syslog_out_for_sandbox.txt", "w");  // Total hack to be able to run a perl command, since we can't use pipe
   sandboxFile.write(sandboxOutput);
   //var sandboxOutput = UIAUtilitylogToolOutput("/usr/bin/perl -n -e 'print if (m/^\\w{3} \\w{3}\\s+\\d+ \\d+:\\d+:\\d+ \\w+ (sandboxd|kernel.*\\(sandbox\\))/)' /tmp/syslog_out_for_sandbox.txt", 60 );  // All matching sandbox
   var sandboxOutput = UIAUtility.logToolOutput("/usr/bin/perl -n -e 'print if (m/^\\w{3} \\w{3}\\s+\\d+ \\d+:\\d+:\\d+ \\w+ sandboxd/)' /var/mobile/syslog_out_for_sandbox.txt", 60 );  // Things of note
   var sandboxList = sandboxOutput.split("\n");
   for (var sandboxIndex = 0; sandboxIndex < sandboxList.length; sandboxIndex++) {
      if (sandboxList[sandboxIndex] == "") continue;  // skip empty lines
      syslogfile.write("sandbox: " + sandboxList[sandboxIndex] + "\n");
   }
   
   //get some network info to see if the failure happened because of network failures
   if (test.testResult <= 0) {
      UIAUtility.getNetworkInfo();
   }
   system.println("");  // print an empty line to make the output on screen a bit easier to read.
   
	
	
   
   UIALogger.logMessage("Finished Running Acceptance Test: '" + test.testName + "'");
}







