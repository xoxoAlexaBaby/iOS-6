#!/usr/local/bin/scripter -f

#import "../libs/HarnessUtility.js"

var system = new System();

// default options
var inputDirectory = "/var/mobile/siri_recordings";
var resultsDirectory = "/tmp/speechrecognizer"
var logfileString = resultsDirectory + "/logfile.txt";
var resultsFileString = resultsDirectory + "/resultsFile.txt";
var tmpResultsFileString = resultsDirectory + "/speechRecognizerOut.txt";
var goldenResultsFileString = "";
var passFailResultsFileString = resultsDirectory + "/passFailResultsFile.txt";
var syslogFileString = resultsDirectory + "/syslog.txt";
var passCount = 0;
var failCount = 0;
var errorCount = 0;


function usage() {
	system.println("usage: SpeechRecognizer.js [--directory <input directory>] [--logfile <log file>] [--resultsfile <results file> ]");
	system.println("	--directory     the directory in which the input files reside.  If not specified, '" + inputDirectory + "'");
	system.println("	--logfile 	verbose logging from the script goes here.  If not specified, '" + logfileString + "'");
	system.println("	--resultsfile   the results of the script goes to this file.  If not specified, '" + resultsFileString + "'");
	system.println("	--goldenfile    if specified, compare the results from the run to the results in the golden file");
	system.println("	--passfailfile  pass/fail results go here, if a goldenfile is specified: '" + passFailResultsFileString + "' by default");
	system.println("	--syslogfile    syslog is put here: '" + syslogFileString + "' by default");
	system.println("	--help | -h	usage description");
}

function main() {
    // process command line arguments
    var options = new Options();
    if (options.help || options.h) {
    	usage();
    	return;
    }
    if (options.directory) inputDirectory = options.directory;
    if (options.logfile) logfileString = options.logfile;
    if (options.resultsfile) resultsFileString = options.resultsfile;
    if (options.goldenfile) goldenResultsFileString = options.goldenfile;
    if (options.passfailfile) passFailResultsFileString = options.passfailfile;
    if (options.syslogfile) syslogFileString = options.syslogfile;

    // remove the old log files 
    UIALogger.logMessage("Removing old log file '" + logfileString + "'");
    var result = system.run("/bin/rm -rf " + logfileString);

    UIALogger.logMessage("Removing old results file '" + resultsFileString + "'");
    var result = system.run("/bin/rm -rf " + resultsFileString);
    
    UIALogger.logMessage("Removing old syslog file '" + syslogFileString + "'");
    var result = system.run("/bin/rm -rf " + syslogFileString);
    
    // create the /tmp/speechrecognizer directory, just in case we need it
    system.run("/bin/mkdir " + resultsDirectory);
    
    if (goldenResultsFileString != "") {
        UIALogger.logMessage("Removing old pass/fail file '" + passFailResultsFileString + "'");
        var result = system.run("/bin/rm -rf " + passFailResultsFileString);
    }

    // open the files
    var resultsFile = new File(resultsFileString, "w");
    var syslogFile = new File(syslogFileString, "w");
    var goldenResultsFile;
    if (goldenResultsFileString != "") {
        passFailResultsFile = new File(passFailResultsFileString, "w");
    }

    // get all of the files in the directory
    var result = system.run("/usr/bin/find " + inputDirectory + " -iname '*.spx' -print", 5);
    var allFiles = result.stdout;
    var fileArray = allFiles.split("\n");
    
    if (fileArray.length == 1 || fileArray[0] == "") {
        var errorString = "ERROR! Input directory '" + inputDirectory + "' does not contain any valid files";
        UIALogger.logError(errorString + "\n");
        return;
    }
          
    // For every file, run the assistant_tool command and parse the file it creates
    for (var fileIndex = 0; fileIndex < fileArray.length; fileIndex++) {
        var testStartTime = new Date();
        var theFile = fileArray[fileIndex];
        if (!theFile || theFile == "") {
            //UIALogger.logError("Error: invalid file found: " + theFile);
            continue;
        }
                
        var fileSubString = theFile.substr(inputDirectory.length + 1);
        if (fileSubString == "") {
            fileSubString = theFile;  // if you pass only one file, instead of a directory, use the original file name
        }
        
        UIALogger.logMessage("Processing " + theFile);
    
        // Main Event
        var tmpResultsFileURL = "file://" + tmpResultsFileString
        var assistantToolOut = system.run("/usr/local/bin/assistant_tool recognizeSpeech '" + theFile + "' '" +  tmpResultsFileURL + "'", 300);
        UIATarget.localTarget().delay(1);  // make sure we give the system enough time to detect/save/etc the file
        
        // log to the logfile--have to use echo because of limitations of file.read() and file.write()
        result = system.run("/bin/sh -c \"/bin/echo '" + theFile + "' >> '" + logfileString + "'\"");
        result = system.run("/bin/sh -c \"/bin/date  >> '" + logfileString + "'\"");
        result = system.run("/bin/sh -c \"/bin/echo '\n' >> '" + logfileString + "'\"");
        //result = system.run("/bin/sh -c \"/bin/echo '" + assistantToolOut.stdout + "\n' >> '" + logfileString + "'\"");
        
        // If the output file doesn't exist, log lots of errors
        if (!system.fileExists(tmpResultsFileString)) {
            var errorString = "ERROR! assistant_tool did not create an output file for " + theFile;
            UIALogger.logError(errorString + "\n");
            resultsFile.write(fileSubString + ": ERROR - No output file created!\n");
            continue;
        }
 
        // put the plist results into the logfile
        var catCommand = "/bin/sh -c \"/bin/cat '" + tmpResultsFileString + "' >> '" + logfileString + "'\"";
        result = system.run(catCommand); 
    
        var thePlist = system.plistData(tmpResultsFileString);
        var finalString = ""
        for (var i=0; i<thePlist.length; i++) {
            var interpretations = thePlist[i].properties.interpretations;
            for (var j=0; j<interpretations.length; j++) {
                var tokens = interpretations[j].properties.tokens;
                for (var k=0; k<tokens.length; k++) {
                    var properties = tokens[k].properties;
                    var theText = properties.text;
                    if (properties.confidenceScore > 10) {
                        if (properties.removeSpaceBefore == true) {
                            //UIALogger.logDebug("removeSpaceBefore first, '" + finalString + "'");
                            finalString = finalString.substr(0, finalString.length - 1);  // extract the last space from the string
                            //UIALogger.logDebug("removeSpaceBefore last, '" + finalString + "'");
                        }
                        finalString += theText;
                        if (properties.removeSpaceAfter == true) {
                            finalString = finalString.substr(0, finalString.length - 1);  // extract the last space from the string
                            //UIALogger.logDebug("removeSpaceafter, '" + finalString + "'");
                        }
                        // If we're not at the end of the array, add a space--it will get extracted later, if needed.
                        finalString += " ";
                    }
                    else {
                        UIALogger.logMessage("Skipping '" + theText + "', confidenceScore = " + properties.confidenceScore);
                    }
                } // end of tokens
            } // end of interpretations stuff
        } // end of plist processing for the given file
        
        finalString = finalString.substr(0, finalString.length - 1); // extract the last space from the string 
        UIALogger.logMessage("String from server = '" + finalString + "'");
    
        // Write the results to the appropriate files
        resultsFile.write(fileSubString + ": " + finalString + "\n");
        system.run("/bin/sh -c \"/bin/echo 'RESULT: " + fileSubString + ": " + finalString + "\n\n\n\n\n' >> '" + logfileString + "'\""); // write results into the logfile.
		
        theFile + "\n";
        
        // create pass/fail results from the golden file
        if (goldenResultsFileString != "") {
            var theCommand = "/bin/sh -c \"cat '" + goldenResultsFileString + "' | grep ^'" + fileSubString + "'\"";
            UIALogger.logDebug("theCommand = " + theCommand);
            var resultString = "";
            
            result = system.run(theCommand);
            if (!result.stdout || (result.stdout == "")) {
                resultString = "ERROR: Not in golden file"; 
                errorCount++;
            }
            else {
                var goldenString = result.stdout.substring(fileSubString.length + 2, result.stdout.length - 1);  // "account for ': ' and '\n'"
                UIALogger.logMessage("goldenString = '" + goldenString + "'");
                if (!goldenString || (goldenString == "")) {
                    resultString = "ERROR: Empty string in golden file";
                    errorCount++;
                }
                else if (goldenString == finalString) {
                    resultString = "PASS";
                    passCount++;
                }
                else {
                    resultString = "FAIL: got '" + finalString + "', expected '" + goldenString + "'";
                    failCount++;
                }
            }
            passFailResultsFile.write(fileSubString + ": " + resultString + "\n");
        }
        
        // remove the file where we temporarily stored the results
        var result = system.run("/bin/rm -rf " + tmpResultsFileString);
        
        system.println(""); // add an extra newline so stdout is easier to read.
        
        // write syslog to logfile
        var now = new Date();
        var timeSinceLastTest =  (now.getTime() - testStartTime.getTime());
        result = system.run("/usr/bin/syslog -k Time ge -" + Math.floor(timeSinceLastTest/1000), 60);
		if (result.stdout) syslogFile.write(result.stdout + "\n");
    
    } // end iterating over the files
    
    if (goldenResultsFileString != "") {
        passFailResultsFile.write("\nPASS: " + passCount + "\n");
        passFailResultsFile.write("FAIL: " + failCount + "\n");
        passFailResultsFile.write("ERROR: " + errorCount + "\n");
    }    
} // end main

main();

