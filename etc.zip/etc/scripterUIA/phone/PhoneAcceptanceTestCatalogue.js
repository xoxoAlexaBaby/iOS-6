//Phone Acceptance Test Catalogue.

if (typeof phone.acceptanceTests == 'undefined') {
	phone.acceptanceTests = new Array();
}

// Test data used for Phone testing...

var hideCallerID = "*67";			//Per call method to hide caller ID

// Test Phone numbers used for automation testing...
	// *** Please use full 11 digit number for US numbers ***
	var usAppleLoopback = "+14089619343";   //Infinite loop of spoken word
	var usMoviePhone = "+14087773456";		//Couple of minutes of loud spoken words
	var usAppleStoreEM = "+15103502400";	//Apple store automated system, hands up if no voice.  Emeryville (1 minute 20 seconds max length)

// Timed with auto remote hand up.
	var usMyCallerID = "+17125809999";		//Repeats callers ID twice and hangs up.  (20 seconds max length)
	var us30Second = "+15138639995";		//30 second call (Ohio), should say callerID or Error then play busy tone before ending call. 



//notes.acceptanceTests = new Array();
//notes.acceptanceTests.push(phtCreateTest("Notes_CreateNote", ["UnitTest Note 1", "Hi!  I like being a note.  How about you?"], notesTest_createNote, "Create a Note"));

	// Coppied from selftests...need to be verified if can run without pre-test setup.
	
//	phone.acceptanceTests.push(phtCreateTest("Phone_MakeCall", ["+14089619343"], phoneTest_makeCall, "Call Loopback Number"));
//	phone.acceptanceTests.push(phtCreateTest("Phone_HoldCall", null, phoneTest_holdCall, "Hold Call"));
//	phone.acceptanceTests.push(phtCreateTest("Phone_UnholdCall", null, phoneTest_unholdCall, "Unhold Call"));
	
	//Need a way to call into the device to run these tests...
	//phone.acceptanceTests.push(phtCreateTest("Phone_AnswerCall", [ipaddress], phoneTest_answerCall, "Answer a Call"));  // Cannot be tested currently
	//phone.acceptanceTests.push(phtCreateTest("Phone_DeclineCall", [ipaddress], phoneTest_declineCall, "Decline a Call"));  // Cannot be tested currently
	//phone.acceptanceTests.push(phtCreateTest("Phone_HoldCallAndAnswer", [ipaddress], phoneTest_HoldCallAndAnswer, "Hold Call and Answer"));  // Cannot be tested currently
	//phone.acceptanceTests.push(phtCreateTest("Phone_phoneTest_ignoreCall", [ipaddress], phoneTest_ignoreCall, "Ignore Incoming Call"));  // Cannot be tested currently
	
	
//	phone.acceptanceTests.push(phtCreateTest("Phone_AddCall", ["4087773456"], phoneTest_addCall, "Add a phone call using keypad")); // Movie Phone
//	phone.acceptanceTests.push(phtCreateTest("Phone_PushSpeakerButton", ["speaker"], phoneTest_changeButtonStateDuringCall, "Push speaker button")); 
//	phone.acceptanceTests.push(phtCreateTest("Phone_MergeCalls", null, phoneTest_mergeCalls, "Merge two calls")); 
//	phone.acceptanceTests.push(phtCreateTest("Phone_EndCall", ["4087773456"], phoneTest_endCall, "End calls")); // Both
//	phone.acceptanceTests.push(phtCreateTest("Phone_MakeCallToContact", ["Bob Dylan", "home"], phoneTest_makeCallToContact, "Make call using contact name"));
//	phone.acceptanceTests.push(phtCreateTest("Phone_EndCall", [null], phoneTest_endCall, "End calls")); // Both
//	phone.acceptanceTests.push(phtCreateTest("Phone_MakeCallFromRecents", ["Bob Dylan"], phoneTest_makeCallFromRecents, "Make call from recents call list"));
//	phone.acceptanceTests.push(phtCreateTest("Phone_EndCall", [null], phoneTest_endCall, "End calls")); // Both
//	phone.acceptanceTests.push(phtCreateTest("Phone_AddContactToFavorites", ["Bob Dylan"], phoneTest_addContactToFavorites, "Add contact to favorites"));
//	phone.acceptanceTests.push(phtCreateTest("Phone_RemoveContactFromFavorites", ["Bob Dylan"], phoneTest_removeContactFromFavorites, "Remove contact from favorites"));
	//phone.acceptanceTests.push(phtCreateTest("AudioSourceChange", ["Built-in speaker", "Speaker"], phoneTest_changeAudioSource, "Changing Audio Source when BT Connected"));
	//phone.acceptanceTests.push(phtCreateTest("PlayVoicemail", ["Caller Name"], phoneTest_playVoicemail, "Play a Voicemail")); // Cannot be tested currently
	//phone.acceptanceTests.push(phtCreateTest("PauseVoicemail", ["Caller Name"], phoneTest_pauseVoicemail, "Pause a Voicemail")); // Cannot be tested currently
	//phone.acceptanceTests.push(phtCreateTest("DeleteVoicemail", ["Caller Name"], phoneTest_deleteVoicemail, "Delete a Voicemail")); // Cannot be tested currently
	
	
	//Apps Team Acceptance tests...
	phone.acceptanceTests.push(phtCreateTest("phoneAT_addCallWithFreeLine", [usAppleLoopback, usMoviePhone], phoneAT_addCallWithFreeLine, "Add a call with a free line"));
	phone.acceptanceTests.push(phtCreateTest("phoneAT_call-7-10-11", [usAppleLoopback], phoneAT_callLengths, "Call a number using 7, 10, 11 digit format"));
	phone.acceptanceTests.push(phtCreateTest("phoneAT_mergeAndEndCalls", [usAppleLoopback, usMoviePhone], phoneAT_mergeAndEndCalls, "Merge two calls and end individually")); 
	
//DEBUG
//UIALogger.logDebug("YES we really did add tests phone.acceptanceTests.length = " + phone.acceptanceTests.length);


