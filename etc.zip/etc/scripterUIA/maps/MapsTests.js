#import "./Maps.js"
#import "../mail/Mail.js"
#import "../libs/PHTesting.js"

function mapsTest_search() {
	var maxTypeDelay = system.randomReal(0.5, 1);

	if (this.argv.length > 0) { 
		var location = this.argv[0];
	} else {
		this.logError(this.testName + ": No search text specified.");
		return 64;
	}
	
	try {
		maps.getToMapView();
	} catch(e) {
		UIALogger.logError(e.message);
		this.testError = "Could not get to map view";
		return this.testResult = 0;
	}
	
	UIALogger.logMessage("Searching for " + location);
	try {
		maps.searchLocation(location);
	} catch(e) {
		UIALogger.logError(e.message);
		this.testError = "Could not search for " + location;
		return this.testResult = 0;
	}
	
	maps.waitForNetworkLoadingToFinish();
	
	UIALogger.logMessage("Checking for result pins...");
	var resultPin = maps.visibleElementsWithName(maps.mainWindow().scrollViews()[0].popover(), maps.MORE_INFO_BUTTON_NAME)[0];
	if (resultPin.length == 0) {
		this.testError = "No result pin showed up";
		return this.testResult = 0;
	}
	
	return this.testResult = 1;
}

function mapsTest_flick() {
	
	var view;
	var x1, x2, y1, y2, speed;
	
	try {
		maps.getToMapView();
	} catch(e) {
		UIALogger.logError(e.message);
		this.testError = "Could not get to map view";
		return this.testResult = 0;
	}
	
	if (this.argv.length < 1) {
		this.argv.push(UIAUtility.randomFromArray(maps.getAvailableViews()));
	}
	view = this.argv[0];	
	
	if (this.argv.length < 2) {this.argv.push(maps.randomX());}
 	x1 = parseInt(this.argv[1]);	
	
	if (this.argv.length < 3) {this.argv.push(maps.randomY());}
 	y1 = parseInt(this.argv[2]);	
	
	if (this.argv.length < 4) {this.argv.push(maps.randomX());}
 	x2 = parseInt(this.argv[3]);	
	
	if (this.argv.length < 5) {this.argv.push(maps.randomY());}
 	y2 = parseInt(this.argv[4]);	
	
	if (this.argv.length < 6) {this.argv.push(system.randomReal(0.01, 0.1));}
	speed = parseFloat(this.argv[5]);	
	
	try {
		maps.viewAs(view);
	} catch(e) {
		UIALogger.logError(e.message);
		this.testError = "Failed to select " + view + " view.";
		return this.testResult = 0;
	}
	
	UIALogger.logMessage("Flick from (" + x1 + "," + y1 + ") to (" + x2 + "," + y2 + ").");
	UIATarget.localTarget().flickFromTo({x:x1, y:y1}, {x:x2, y:y2});					
	
	// we should check loading status here
	if (true) {
		UIALogger.logMessage("Flick from (" + x1 + "," + y1 + ") to (" + x2 + "," + y2 + ") completed.");
		return this.testResult = 1;
	}

	
	return;
}

function mapsTest_drag() {
	
	var view;
	var x1, x2, y1, y2, speed;
	
	try {
		maps.getToMapView();
	} catch(e) {
		UIALogger.logError(e.message);
		this.testError = "Could not get to map view";
		return this.testResult = 0;
	}
	
	if (this.argv.length < 1) {
		this.argv.push(UIAUtility.randomFromArray(maps.getAvailableViews()));
	}
	view = this.argv[0];	
	
	if (this.argv.length < 2) {this.argv.push(maps.randomX());}
 	x1 = parseInt(this.argv[1]);	
	
	if (this.argv.length < 3) {this.argv.push(maps.randomY());}
 	y1 = parseInt(this.argv[2]);	
	
	if (this.argv.length < 4) {this.argv.push(maps.randomX());}
 	x2 = parseInt(this.argv[3]);	
	
	if (this.argv.length < 5) {this.argv.push(maps.randomY());}
 	y2 = parseInt(this.argv[4]);	
	
	if (this.argv.length < 6) {this.argv.push(system.randomReal(0.5, 5));}
	speed = parseFloat(this.argv[5]);	
	
	try {
		maps.viewAs(view);
	} catch(e) {
		this.testError = "Failed to select " + view + " view.";
		return this.testResult = 0;
	}
	
	UIALogger.logMessage("Drag from (" + x1 + "," + y1 + ") to (" + x2 + "," + y2 + ").");
	UIATarget.localTarget().dragFromToForDuration({x:x1, y:y1}, {x:x2, y:y2}, speed);					
	
	// we should check loading status here
	if (true) {
		UIALogger.logMessage("Drag from (" + x1 + "," + y1 + ") to (" + x2 + "," + y2 + ") completed.");
		this.testResult = 1;
	}
	
	return;
}

function mapsTest_zoomIn() {
	var view;
	var x1, y1;
	
	try {
		maps.getToMapView();
	} catch(e) {
		UIALogger.logError(e.message);
		this.testError = "Could not get to map view";
		return this.testResult = 0;
	}
	
	if (this.argv.length < 1) {
		this.argv.push(UIAUtility.randomFromArray(maps.getAvailableViews()));
	}
	view = this.argv[0];	
	
	if (this.argv.length < 2) {this.argv.push(maps.randomX());}
 	x1 = parseInt(this.argv[1]);	
	
	if (this.argv.length < 3) {this.argv.push(maps.randomY());}
 	y1 = parseInt(this.argv[2]);
	
	try {
		maps.viewAs(view);
	} catch(e) {
		UIALogger.logError(e.message);
		this.testError = "Failed to select " + view + " view.";
		return this.testResult = 0;
	}
	
	UIALogger.logMessage("Zooming into (" + x1 + "," + y1 + ").");
	UIATarget.localTarget().doubleTap({x:x1, y:y1});	
	
	// we should check loading status here
	if (true) {
		UIALogger.logMessage("Zoom in (" + x1 + "," + y1 + ") completed.");
		return this.testResult = 1;
	}
	
	return;	
}


function mapsTest_zoomOut() {
	
	var view;
	var x1, y1;
	
	try {
		maps.getToMapView();
	} catch(e) {
		UIALogger.logError(e.message);
		this.testError = "Could not get to map view";
		return this.testResult = 0;
	}
	
	if (this.argv.length < 1) {
		this.argv.push(UIAUtility.randomFromArray(maps.getAvailableViews()));
	}
	view = this.argv[0];	
	
	if (this.argv.length < 2) {this.argv.push(maps.randomX());}
 	x1 = parseInt(this.argv[1]);	
	
	if (this.argv.length < 3) {this.argv.push(maps.randomY());}
 	y1 = parseInt(this.argv[2]);	
	
	try {
		maps.viewAs(view);
	} catch(e) {
		UIALogger.logError(e.message);
		this.testError = "Failed to select " + view + " view.";
		return this.testResult = 0;
	}
	
	UIALogger.logMessage("Zooming out (" + x1 + "," + y1 + ").");
	UIATarget.localTarget().tapWithOptions({x:x1, y:y1}, {tapCount:2, touchCount:2});
	
	// we should check loading status here
	if (true) {
		UIALogger.logMessage("Zoom out (" + x1 + "," + y1 + ") completed.");
		this.testResult = 1;
	}
		
	return;	
}

//----------------------------------------------------------------------------------------
//	Function: mapsTest_getCurrentLocation 
//		Test to get the current location.
//
//	Parameters: None
//
//	Returns: 
//		1 if the test passes
//		0 if the test fails
//----------------------------------------------------------------------------------------

function mapsTest_getCurrentLocation() {
	
	try {
		maps.getToMapView();
	} catch(e) {
		UIALogger.logError(e.message);
		this.testError = "Could not get to map view";
		return this.testResult = 0;
	}
	
	try {
		maps.getCurrentLocation();
	} catch(e) {
		UIALogger.logError(e.message);
		this.testError = "Failed to find our current location."
		return this.testResult = 0;
	}

	return this.testResult = 1;
	
}

//---------------------------------------------------------------------------------------------
//	Function: mapsTest_addBookmark 
//		Test to add a bookmark. Drops a pin, and bookmarks the pin's location
//
// Parameters: 
//		None
//
// Returns:
//     1 if the test passes
//     0 if the test fails
//---------------------------------------------------------------------------------------------

function mapsTest_addBookmark() {
	
	maps.launchIfNotActive();
	var bookmarkName;
	
	try {
		bookmarkName = maps.addBookmark(); 
	} catch(e) {
		UIALogger.logError(e.message);
		this.testError = e.message;
		return this.testResult = 0;
	}
	
	//verify
	UIALogger.logMessage("Verifying " + bookmarkName + " was added...");
	try {
		maps.getToMapView();
	} catch(e) {
		this.testError = "Could not go back to the main map page";
		return this.testResult = 0;
	}	

	try {
		maps.getToBookmarksView({toolbarButton:"Bookmarks"});
	} catch(e) {
		this.testError = "Could not go the bookmarks view page";
		return this.testResult = 0;
	}	
	
	UIALogger.logMessage("Checking if " + bookmarkName + " exists in the bookmarks list...");
	if (!maps.bookmarksTable().scrollToElementWithPredicate("name contains '" + bookmarkName + "'").isValid()) {
		this.testError = "Could not find the added bookmark " + bookmarkName;
		return this.testResult = 0;
	}
	
	UIALogger.logMessage("Done verifying. Now going back to the main screen...");
	try {
		maps.getToMapView();
	} catch(e) {
		this.testError = "Could not get back to the main map view";
		return this.testResult = 0;
	}
	
	return this.testResult = 1;	
}

//---------------------------------------------------------------------------------------------
//	Function: mapsTest_deleteBookmark 
//		Test to delete a bookmark. Assumes at least one bookmark exists. 
//
// Parameters: 
//		None
//
// Returns:
//     1 if the test passes
//     0 if the test fails
//---------------------------------------------------------------------------------------------
function mapsTest_deleteBookmark() {
	
	try {
		maps.getToMapView();
	} catch(e) {
		UIALogger.logError(e.message);
		this.testError = "Could not get to maps view";
		return this.testResult = 0;
	}
	
	maps.getToBookmarksView();
	var bookmarksTable = maps.bookmarksTable();
	var numOfCells = bookmarksTable.cells().length;
	UIALogger.logDebug("Number of cells before deleting is " + numOfCells);
	
	try {
		maps.deleteBookmark();
	} catch(e) {
		UIALogger.logError(e.message);
		this.testError = e.message;
		return this.testResult = 0;
	}

	//verify	
	UIALogger.logMessage("Verifying bookmark was deleted by checking the number of cells");
	var updatedNumOfCells = bookmarksTable.cells().length;
	if (updatedNumOfCells != (numOfCells-1)) {
		UIALogger.logError("No. of cells before delete: " + numOfCells + " after delete: " + updatedNumOfCells);
		this.testError = "The bookmark was not deleted";
		return this.testResult = 0;
	}

	UIALogger.logMessage("Done verifying. Now going back to the main screen...");
	try {
		maps.getToMapView();
	} catch(e) {
		this.testError = "Could not get back to the main map view"; 
		return this.testResult = 0;
	}
	
	return this.testResult = 1;
}

//---------------------------------------------------------------------------------------------
//	Function: mapsTest_shareLocation
//		Tests the Share A Location feature in Maps app
//
// Optional Parameters:
//		sendThru (string) - specifies how the location detail should to be sent - MMS or Email - 
//			if both options are available. If a null value is provided, the choice will be 
//			made randomly. If Email is chosen, it assumes that an email account exists.
//		shouldValidate (boolean) - true, if validation needs to be performed. It is set to 
//			false by default.
//		timeout (integer) - specifies the amount of time to wait for the location to arrive 
//		mailRecipient (string) - specifies the recipient of the email containing the location. 
//			It is set to weliketesting@me.com by default
//		phoneNumber (string) - specifies the phone number the MMS containing the location 
//			should be sent to
//		searchLocation (string) - specifies a particular location that needs to be shared. The 
//			location will be searched, and the result will be shared. If this parameter is 
//			not specified, then the test drops a pin, shares the location of the pin. 
//		emailSubject (string) - the subject of the email that will be sent out. This parameter
//			will be assigned a default subject, if no value is specified.
//		
//
// Returns:
//     1 if the test passes
//     0 if the test fails
//
// Usage:
//		mapsTest_shareLocation "timeout:120" "shouldValidate:true" "sendThru:MMS"
//---------------------------------------------------------------------------------------------
function mapsTest_shareLocation() {
	
	try {
		maps.getToMapView();
	} catch(e) {
		UIALogger.logError(e.message);
		this.testError = "Could not get to map view";
		return this.testResult = 0;
	}
	
	var options = new Object();
	
	options.sendThru = UIAUtility.valuesForKey("sendThru", this.argv, 1); 
	options.shouldValidate = UIAUtility.valuesForKey("shouldValidate", this.argv, 1);
	options.timeout = UIAUtility.valuesForKey("timeout", this.argv, 1);
  	options.to = UIAUtility.valuesForKey("mailRecipient", this.argv, 1);
	options.phoneNumber = UIAUtility.valuesForKey("timeout", this.argv, 1);
	options.searchLocation = UIAUtility.valuesForKey("searchLocation", this.argv, 1);
	options.subject = UIAUtility.valuesForKey("emailSubject", this.argv, 1);
	
	//special case for N82C, to avoid dealing with chinese characters in subject 
	var date = new Date();
	if (!options.subject) options.subject = "Share Location Test "+ date.getHours() + date.getMinutes() + date.getSeconds();

	
	// set default values for anything that needs them.
	if (!options.timeout) options.timeout = 120;  // if timeout isn't specified, set it to 2 minutes.
	if (options.shouldValidate == null) options.shouldValidate = false;
	
	UIALogger.logMessage("Puting a pin for the location to share");
	
	//checking if we need to search for the location
	var infoViewOptions = {infoButtonName:"Share Location"};
	if (options.searchLocation) {
		UIALogger.logMessage("Trying to search for and share " + options.searchLocation);
		infoViewOptions.location = options.searchLocation;
	} 
	
	maps.getToInfoView(infoViewOptions);
	
	UIALogger.logMessage("Checking for an action sheet with Email/MMS choice option");
	var actionSheet = maps.shareLocationActionSheet();
 
	if (actionSheet.isValid()) {
		if (!options.sendThru) options.sendThru = UIAUtility.randomFromArray(["Email", "MMS"]);
		UIALogger.logMessage("Action sheet found. Multiple options available. Choosing " + options.sendThru);
		
		var sendThruButton = actionSheet.buttons()[options.sendThru];
		if (!sendThruButton.isValid()) {
			this.testError = "Could not tap on " + options.sendThru + " in the action sheet";
			return this.testResult = 0;
		}
		sendThruButton.tap();
	}
	
	//check the desired option and the actual chosen option are consistent
	UIATarget.localTarget().delay(1);
	if (maps.isDisplayingEmailComposeSheet()) {
		if (!options.sendThru || options.sendThru == "Email") {
			
			//type out the email and send it
			UIALogger.logMessage("Typing email and sending it");
			if (!options.to) options.to = "weliketesting@me.com";
			maps.composeEmail(options);			

			UIALogger.logMessage("The subject of the email is " + options.subject);
			maps.navigationBar().buttons()["Send"].tap();
			
			if (options.shouldValidate && (options.shouldValidate == "true" || options.shouldValidate == true)) {
				UIALogger.logMessage("Verifying that the email was received...");
				if (!mail.verifyEmailExists(options.subject, options.to, "Inbox", 120)) {
					this.testError = "The email was not received.";
					UIALogger.logError(this.testError);
					return this.testResult = 0;
				}
				UIALogger.logMessage("The email was received");
			} else {
				UIALogger.logMessage("The test did not verify that the email was received.");
			}
		} else {
			this.testError = "Showing the email view, but chose " + options.sendThru + " option";
			return this.testResult = 0;
		}
	} else if (maps.getCurrentView() == 'MMSComposeView') { //need to use windows()[0] because of <rdar://problem/8040194>
		if (!options.sendThru || options.sendThru == "MMS") {
			throw new Error("Not implemented");
			
			if (!options.phoneNumber) {
				options.phoneNumber = telephony.myPhoneNumber;
				
				if (!options.phoneNumber) {
					this.testError = "Failed to get device's phone number.";
					return this.testResult = 0; 
				}
			}
			
			if (!options.textToSend) options.textToSend = "";			
			UIALogger.logMessage("Sending MMS on " + options.phoneNumber);
			
			// commented out error-checking because sms_createThread and sms_continueMessage do not return boolean values
			if (!sms_createThread(null, options.phoneNumber)) {
				//this.testError = "Could not type the recipient";
				//return this.testResult = 0;
			}
			
			if (!sms_continueMessage(options.textToSend, false)) {
				//this.testError = "Could not type the message";
				//return this.testResult = 0;
			}
			
			if (options.shouldValidate && (options.shouldValidate == "true" || options.shouldValidate == true)) {
				UIALogger.logMessage("Verifying that the message was received...");
				if (!sms_waitForSMS(options.phoneNumber,options.textToSend, options.timeout)) {
					this.testError = "MMS was sent, but could not be verified that it was received";
					return this.testResult = 0;
				}
				UIALogger.logMessage("The message was received.");
			} else {
				UIALogger.logMessage("The test did not verify that the MMS was received.");
			}
		} else {
			this.testError = "Showing the MMS view, but chose " + options.sendThru + " option";
			return this.testResult = 0;
		}
	} else {
		this.testError = "Did not get a send email or MMS view";
		return this.testResult = 0;
	}
	
	maps.getToMapView();
	
	return this.testResult = 1;
}

//---------------------------------------------------------------------------------------------
//	Function: mapsTest_getDirections
//		Gets the direction between two locations
//
//	Parameters: 
//		startLocation (string) - the location to be filled out in the 'Start:' text field
//		endLocation (string) - the location to be filled out in the 'End:' text field
//
//	Optional Parameters:
//		directionsType (string) - the type of directions to be provided - driving, transit or 
//			walking. It is set to driving by default. 
//
//	Returns:
//     1 if the test passes
//     0 if the test fails
//---------------------------------------------------------------------------------------------
function mapsTest_getDirections() {
	
	maps.getToMapView();
	
	var options = new Object();
	
	if (this.argv.length > 0) { 
		options.startLocation = this.argv[0];
	} else {
		this.logError(this.testName + ": No start location specified.");
		return 64;
	}
	if (this.argv.length > 1) { 
		options.endLocation = this.argv[1];
	} else {
		this.logError(this.testName + ": No end location specified.");
		return 64;
	}
	
	options.directionsType = UIAUtility.valuesForKey("directionsType", this.argv, 1);
	if (!options.directionsType) options.directionsType = "driving";
	
	maps.getDirections(options.startLocation, options.endLocation, {directionsType:options.directionsType});
	
	var noDirectionPredicateString = (UIATarget.localTarget().model() == 'iPad') ? "name matches 'No .* Directions.*'" : "name endswith 'could not be found between these locations'";
	var noDirectionsElem = (maps.mainWindow().staticTexts().firstWithPredicate(noDirectionPredicateString));
	if (noDirectionsElem.isValid()) {
		this.testError = "Directions could not be found. " + noDirectionsElem.name();
		return this.testResult = 0;
	}
	
	maps.stepThroughDirections();
	maps.getToMapView();
	
	return this.testResult = 1;
	
}

//---------------------------------------------------------------------------------------------
//	Function: mapsTest_showTraffic
//		Uses the 'Show Traffic' option to display traffic. 
//
//	Assumes:
//		Traffic is available in the area where the option is used. The searchLocation parameter
//			can be used to ensure this.
//
//	Parameters: 
//		None
//
//	Optional Parameters:
//		searchLocation (string) - the test searches for the location specified by this parameter
//			and then turns on the traffic view. 
//
//	Returns:
//     1 if the test passes
//     0 if the test fails
//
//---------------------------------------------------------------------------------------------
function mapsTest_showTraffic() {
	
	try {
		maps.getToMapView();
	} catch(e) {
		UIALogger.logError(e.message);
		this.testError = "Could not get to map view";
		return this.testResult = 0;
	}
	location = UIAUtility.valuesForKey("searchLocation", this.argv, 1);
	
	if (location) {
		UIALogger.logMessage("Searching for " + location);
		try {
			maps.searchLocation(location);
		} catch(e) {
			this.testError = "Could not perform the search for " + location;
			return this.testResult = 0;
		}
	}
	UIATarget.localTarget().delay(1);
	
	try {
		maps.changeTrafficView({showTraffic:"on"});
	} catch(e) {
		UIALogger.logError(e.message);
		this.testError = "Could not choose Show Traffic";
		return this.testResult = 0;
	}
	UIATarget.localTarget().delay(1);
	
	var result;
	try {
		result = maps.showsTraffic();
	} catch(e) {
		UIALogger.logError(e.message);
		this.testError = "Could not determine if the maps shows traffic or not";
		return this.testResult = 0;
	}
	if (!result) {
		this.testError = "Could not enable Show Traffic";
		return this.testResult = 0;
	}
	
	return this.testResult = 1;
}

//---------------------------------------------------------------------------------------------
//	Function: mapsTest_viewLocationDetail
//		Views a location's details
//
//	Parameters: 
//		none
//
//	Optional Parameters:
//		searchLocation (string) - the test searches for the location specified by this parameter
//			amd views the details of the result. If a location is not specified, the 'Drop Pin' 
//			option is used. 
//		addressToVerify (string) - if a value is provided, the test checks if the address 
//			displayed on the info page is the same as the one specified by this parameter.
//
//	Returns:
//     1 if the test passes
//     0 if the test fails
//
//---------------------------------------------------------------------------------------------
function mapsTest_viewLocationDetail() {
	
	maps.launchIfNotActive();
	
	var options = new Object();
	options.location = UIAUtility.valuesForKey("searchLocation", this.argv, 1); 
	options.addressToVerify = UIAUtility.valuesForKey("addressToVerify", this.argv, 1); 
	
	try {
		maps.getToInfoView(options);
	} catch(e) {
		UIALogger.logError(e.message);
		this.testError = "Could not get to the info view";
		return this.testResult = 0;
	}
	
	if (options.addressToVerify) {
		UIALogger.logMessage("Verifying the address of the location is " + options.addressToVerify);
		if (UIATarget.localTarget().model() == 'iPad')
			var addressCell = maps.mainWindow().scrollViews()[0].popover().tableViews()[0].scrollToElementWithName("address");
		else
			var addressCell = maps.mainWindow().tableViews()[0].scrollToElementWithName("address");
		if (!addressCell.isValid()) {
			this.testError = "Could not find an address in the info view";
			return this.testResult = 0;
		}
		
		if (addressCell.value().indexOf(options.addressToVerify) < 0) {
			UIALogger.logError("The expected address does not match '" + addressCell.value() + "'");
			this.testError = "Could not find the specified address: " + options.addressToVerify;
			return this.testResult = 0;
		}
	}
	
	try {
		maps.getToMapView();
	} catch(e) {
		UIALogger.logError(e.message);
		this.testError = "Could not get to map view";
		return this.testResult = 0;
	}
	return this.testResult = 1;
}

//---------------------------------------------------------------------------------------------
//	Function: mapsTest_showStreetView
//		Selects street view for a location
//
//	Parameters: 
//		none
//
//	Optional Parameters:
//		searchLocation (string) - the test searches for the location specified by this parameter
//			amd views the street view of the result. If a location is not specified, the 'Drop Pin' 
//			option is used. 
//
//	Returns:
//     1 if the test passes
//     0 if the test fails
//
//---------------------------------------------------------------------------------------------
function mapsTest_showStreetView() {
	
	maps.launchIfNotActive();
	
	var options = new Object();
	options.location = UIAUtility.valuesForKey("searchLocation", this.argv, 1); 
	
	try {
		maps.putPinMarker(options);
	} catch(e) {
		UIALogger.logError(e.message);
		if (options.location)
			this.testError = "Could not search for " + options.location + " and select the result";
		else 
			this.testError = "Could not drop/replace pin, and select it";
		return this.testResult = 0;
	}

	
	try {
		maps.showStreetView();
	} catch(e) {
		this.testError = e.message;
		return this.testResult = 0;
	}
	
	UIALogger.logMessage("Going to map view now");
	try {
		maps.getToMapView();
	} catch(e) {
		UIALogger.logError(e.message);
		this.testError = "Could not get to map view";
		return this.testResult = 0;
	}
	
	this.testResult = 1;
	
}

// Create self tests -- this is an unnamed function, just to make sure any local variables stay in the correct context
(function() {	
	if (typeof maps.selfTests == 'undefined') {
		maps.selfTests = new Array();
	}
	maps.selfTests.push(phtCreateTest("MapAddress", ["Indianapolis, IN"], mapsTest_search, "Search for city"));
	maps.selfTests.push(phtCreateTest("MapSearch", ["pizza"], mapsTest_search, "Search for keyword"));
	maps.selfTests.push(phtCreateTest("ZoomOutMaps", [maps.getAvailableViews()[0], 150, 150], mapsTest_zoomOut, "Zoom out in map view"));
	maps.selfTests.push(phtCreateTest("ZoomInMaps", ["Satellite", 150, 150], mapsTest_zoomIn, "Zoom in in map view"));
	maps.selfTests.push(phtCreateTest("DragSatelliteView", ["Satellite", 1, 170, 315, 425, 1], mapsTest_drag, "Drag map in satellite view"));
	maps.selfTests.push(phtCreateTest("FlickMapView", [maps.getAvailableViews()[0], 1, 170, 315, 425, 0.1], mapsTest_flick, "Flick map in map view"));
	maps.selfTests.push(phtCreateTest("GetCurrentLocation", null, mapsTest_getCurrentLocation, "Get your current location"));
	maps.selfTests.push(phtCreateTest("AddBookmark", null, mapsTest_addBookmark, "Add a bookmark"));
	maps.selfTests.push(phtCreateTest("DeleteBookmark", null, mapsTest_deleteBookmark, "Delete a bookmark"));
	maps.selfTests.push(phtCreateTest("ShareLocation", ["searchLocation:Boston,MA", "sendThru:Email", "shouldValidate:true"], mapsTest_shareLocation, "Share a location")); 
	maps.selfTests.push(phtCreateTest("ViewLocationDetails", ["searchLocation:Canada"], mapsTest_viewLocationDetail, "View a location's details")); //TODO: enable validation, once found fix for N82C
	maps.selfTests.push(phtCreateTest("GetDirections", ["New York, NY","Boston, MA"], mapsTest_getDirections, "Get driving directions"));
	maps.selfTests.push(phtCreateTest("ShowTraffic", ["searchLocation:New York, NY"], mapsTest_showTraffic, "Turns on Show Traffic"));
	maps.selfTests.push(phtCreateTest("ShowStreetView", ["searchLocation:Boston, MA"], mapsTest_showStreetView, "Find Boston MA and load multiple views in Streetview"));
}())
