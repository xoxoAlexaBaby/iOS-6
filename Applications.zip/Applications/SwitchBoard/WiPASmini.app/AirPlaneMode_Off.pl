#!/usr/bin/perl

if ((0 <= $#ARGV) && ($ARGV[0] eq "OFF"))
{
	$state = "FALSE";
}
else
{
	$state = "TRUE";
}

open (PS, "| scutil --prefs /Library/Preferences/SystemConfiguration/com.apple.radios.plist");
printf (PS "get /\n");
$cmd = "d.add AirplaneMode ? " . $state . "\n";
printf (PS $cmd);
printf (PS "set /\n");
printf (PS "commit\n");
printf (PS "apply\n");
printf (PS "q\n");
close (PS);