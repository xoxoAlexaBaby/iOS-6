/*
 Class: UIApp (youtube)
	YouTube object
*/

#import "../libs/SpringBoard.js"
#import "../libs/UIAAppMailAdditions.js"
#import "../libs/UIAAppMediaAdditions.js"

youtube = UIAApp.application("YouTube", "com.apple.youtube");

if (typeof youtube != 'undefined') {
    youtube.launchIfNotActive = function launchIfNotActive() {
		this.__proto__.launchIfNotActive.apply(this);
        // Dismiss any lingering popovers that might cause tests to fail

        var popover = this.mainWindow().popover();
        if (popover.isVisible()) {
            UIALogger.logMessage("Dismissing popover...");
            popover.dismiss();
            popover.waitForInvalid();
            UIATarget.localTarget().delay(1);
        }
	}
    
	youtube.authentication = {};
	youtube.authentication.username;
	youtube.authentication.password;
	
	youtube.alertHandler = function alertHandler(alert) {
		if (!alert.isVisible()) {
			UIALogger.logWarning("Alert not visible");
		}

		if (!alert.waitForInvalid()) throw new Error("Could not handle the alert");
		return true;
	}
	
	
	youtube._getVideoSlider = function _getVideoSlider() {
		UIATarget.localTarget().pushTimeout(0);
		var slider;
		if (UIATarget.localTarget().model() != "iPad") {
			slider = this.mainWindow().navigationBar().sliders().firstWithPredicate("name beginswith 'Track position'");
		} else {
			if (this.isLandscape()) {
				slider = this.mainWindow().navigationBars().firstWithPredicate("ANY sliders.name beginswith 'Track position'").sliders().firstWithPredicate("name beginswith 'Track position'");
			} else {
				slider = this.mainWindow().sliders().firstWithPredicate("name beginswith 'Track position'");
			}
			
		}	
		UIATarget.localTarget().popTimeout();
		return slider;
		
	} // end _getVideoSlider
	
	// Helper function - returns the total video play time in seconds
	youtube._getTotalVideoTime = function _getTotalVideoTime() {
		UIATarget.localTarget().pushTimeout(0);
		this.bringUpControlScreen();
		var slider = this._getVideoSlider();
		var timeObject;
		if (slider.isVisible()) {
			timeObject = UIAUtility.processTrackPositionValue(slider.value());
		} else {
			this.logElementTree();
			UIATarget.localTarget().popTimeout();
			throw new Error("Could not find slider");
		}
		UIATarget.localTarget().popTimeout();
		return (timeObject.totalTimeInfo.minutes * 60) + timeObject.totalTimeInfo.seconds;
		
	}
	
	// Helper function - returns the current play time in seconds
	youtube._getCurrentVideoTime = function _getCurrentVideoTime() {
		UIATarget.localTarget().pushTimeout(0);
		this.bringUpControlScreen();
		var slider = this._getVideoSlider();
		var timeObject;
		if (slider.isVisible()) {
			timeObject = UIAUtility.processTrackPositionValue(slider.value());
		} else {
			this.logElementTree();
			UIATarget.localTarget().popTimeout();
			throw new Error("Could not find slider");
		}
		UIATarget.localTarget().popTimeout();
		return (timeObject.elapsedTimeInfo.minutes * 60) + timeObject.elapsedTimeInfo.seconds;
	}
	
	youtube._setFullScreenMode = function _setFullScreenMode(mode) {
		UIATarget.localTarget().pushTimeout(0);
		this.bringUpControlScreen();

		if (mode.toUpperCase() == 'ON' && this.mainWindow().buttons()["Full screen"].isVisible()) {
			this.mainWindow().buttons()["Full screen"].tap();
		} else if (mode.toUpperCase() == 'OFF' && this.mainWindow().images().firstWithPredicate("ANY buttons.name == 'Exit Full screen'").buttons()["Exit Full screen"].isVisible()) {
			this.mainWindow().images().firstWithPredicate("ANY buttons.name == 'Exit Full screen'").buttons()["Exit Full screen"].tap();
		} 
		
		UIATarget.localTarget().pushTimeout(0);
		return;
	} 
    
    youtube.videoDurationExceedsMinDuration = function videoDurationExceedsMinDuration(videoName, minDuration) {
        var duration = videoName.match(/Duration [0-9]+:[0-9]+:[0-9]+/).toString();
        if (!duration) throw new Error("Could not determine the duration of video: '" + videoName + "'");
        
        duration = duration.replace("Duration ","");
        duration = (parseInt(duration.split(":")[0]) * 24) + (parseInt(duration.split(":")[1]) * 60) + parseInt((duration.split(":")[2]));
        
        UIALogger.logMessage("Current video selection duration: " + duration + " seconds");
        
        if (duration < minDuration) return false;
        return true;

    }
    
	//----------------------------------------------------------------------------------------
	//	Function: areVideosPresent 
	//		Checks to see if videos are present on current page.  
	//		
	//
	//	Parameters: 
	//		video (string) - video name to specify
	//
	//	Returns:
	//		Returns the # of videos in the table if there are videos present, false if no videos are present
	//
	//----------------------------------------------------------------------------------------
	youtube.areVideosPresent = function areVideosPresent() {

		
		var videosTable = this.mainWindow().tableViews()[0];

		if (!videosTable.isValid()) {
			UIALogger.logMessage( "No videos Present");
			return false;
		} else {
			var videoCount = this.mainWindow().tableViews()[0].cells().length;
			return videoCount;
		}
	}
	

	//----------------------------------------------------------------------------------------
	//	Function: waitForVideoToLoad
	//		 Waits for the movie to load
	//
	//	Parameters: 
	//		timeout (int) - max time to wait for video to load. Defaults to 30 seconds
	//
	//	Returns: 
	//		An exception if the movie could not load
	//----------------------------------------------------------------------------------------
	youtube.waitForVideoToLoad = function waitForVideoToLoad(timeout) {

		if (!timeout) timeout = 180;
		
		
		//Let any animations settle down
		UIATarget.localTarget().delay(2);
		UIALogger.logDebug( "Waiting patiently for video to load.  Timing out in " + timeout + " seconds.");
		// Loop maxCount times to wait for the movie to load.  
		for (var count = 0; count < timeout; count++) {
			UIALogger.logMessage( "Waiting patiently for video to load. " + (timeout - count) + " seconds remaining");
			UIATarget.localTarget().delay(1);

			var loadingElement;
			if (UIATarget.localTarget().model() != "iPad") {
				loadingElement = this.mainWindow().navigationBar();
			} else {
				loadingElement = this.mainWindow();
			}
			
			if (!loadingElement.staticTexts().firstWithPredicate("name beginswith 'Loading'").isVisible()) break;
		}
		if (!this.isInVideoView() || count >= timeout) throw new Error("Timed out waiting " + timeout + " seconds for movie to finish loading.");
		return;
		
	} // end youtube.waitForVideoToLoad


	//----------------------------------------------------------------------------------------
	//	Function: pickRandomVideo 
	//		Return the name of a random video in the current view.  Unless specified otherwise
    //      a video with a minimum duration of 45 seconds will be chosen to allow the test
    //      to run.  Videos shorter than approximately 30 seconds 
	//
	//	Parameters: 
	//		None
	//
	//	Returns: 
	//		The name of a random video that is picked to be played.  
	//
	//	Throws: 
	//		Exception a video cannot be picked.
	//----------------------------------------------------------------------------------------
	youtube.pickRandomVideo = function pickRandomVideo(minDuration) {
		var maxCells;
        minDuration = (!minDuration) ? 45 : minDuration;
        var maxAttempts = 10;
        var randomRow;
        var videoCell;
        var videoName;
        var randomColumn;
        var duration;
        
		if (UIATarget.localTarget().model() != "iPad") {
			maxCells = this.mainWindow().tableViews()[0].cells().withPredicate("not name contains 'Load More...'").length;
		} else {
			maxCells = this.mainWindow().tableViews()[0].cells().withPredicate("not ANY elements.name == 'Load More...'").length;
		}

        for (var currentAttempt = 0; currentAttempt < maxAttempts; currentAttempt++) {
            randomRow = system.randomInteger(0,(parseInt(maxCells) - 1));
            UIALogger.logDebug("Choosing random row: " + randomRow + " from " + maxCells + " total cells");
            videoCell = this.mainWindow().tableViews()[0].cells()[randomRow];
		
            if (UIATarget.localTarget().model() == "iPad") {
                randomColumn = system.randomInteger(0,(parseInt(videoCell.elements().length) - 1));
                UIALogger.logDebug("Choosing random column: " + randomColumn + " from " + videoCell.elements().length + " total columns");
                videoCell = this.mainWindow().tableViews()[0].cells()[randomRow].elements()[randomColumn];
            }

            if (!this.videoDurationExceedsMinDuration(videoCell.name(), minDuration)) {
                UIALogger.logMessage("Current video - '" + videoCell.name() + "' does not meed the minimum duration of " + minDuration + " seconds.");
                UIALogger.logMessage("Finding a new video to play...");                
                continue;
            }
            
            if (videoCell.isValid()) {
                videoName = videoCell.name();
                UIALogger.logMessage("Found video - " + videoName)
                return videoName;
            }
        }
        
		throw new Error("Could not find a video to play");
		
	} // end youtube.pickRandomVideo
	

	//----------------------------------------------------------------------------------------
	//	Function: isVideoPlaying 
	//		Checks if the slider's value is changing or not to determine 
	//		if a video is playing
	//
	//	Parameters: 
	//		None
	//
	//	Returns:
	//		True, if the video is playing, false if not
	//
	//  Throws: 
	//		Error if the video state could not be determined
	//----------------------------------------------------------------------------------------
	youtube.isVideoPlaying = function isVideoPlaying() {
		
		UIATarget.localTarget().pushTimeout(0);

		if (this.mainWindow().navigationBar().name() == "More Info") {
			UIALogger.logMessage("Video has ended - we're on the 'More Info' view");
			return true;
		} 		

		UIALogger.logMessage( "Determining if video is playing...");
		
		var startTime = this._getCurrentVideoTime();
		UIALogger.logMessage("Video start point:" + startTime);
		
		//Let the video play for 1 second
		UIATarget.localTarget().delay(1);

		UIATarget.localTarget().popTimeout();

		var endTime = this._getCurrentVideoTime();
		UIALogger.logMessage( "Video end point:" + endTime);
		
		if (startTime == endTime) { 
			UIALogger.logMessage( "Start and end time are the same...");
			return false;
		} else if ( startTime > endTime ) {
			UIALogger.logMessage( "Start time is greater than the end...");			
			return false;
		}
		UIALogger.logMessage( "Start time: " + startTime + "  End time: " + endTime);					
		return true;

	} // end youtube.isVideoPlaying


	//----------------------------------------------------------------------------------------
	//	Function: searchForVideo 
	//		Assumes the search page is being displayed. Clears the 
	//		text field and types in the search string.
	//
	//	Parameters: 
	//		searchString (string) - the string to be searched
	//
	//	Throws: 
	//		An error if the video could not be found
	//----------------------------------------------------------------------------------------
	youtube.searchForVideo = function searchForVideo(searchString) {
		
		UIALogger.logMessage( "Searching for " + searchString);
		try {
			
			if (UIATarget.localTarget().model() == "iPad") {
				// This is a bit hackish, but by going to the 'Featured' tab,
				// we can reuse the same searchBarEvalString for both iPads and non-iPads,
				// negating the need to hard code navigationBars()[1] to access the navigation bar.
				this.getToCategoryView("Featured");
			}
			this.search(searchString, {searchBarEvalString:"this.mainWindow().navigationBar().searchBars()[0]"});
		} catch (e) {
			UIALogger.logError(e.message);
			throw new Error( "Could not find video: " + searchString);
		}
		
		UIALogger.logMessage( "Done Searching for "+ searchString);
		return ;

	} // end youtube.searchForVideo


	//----------------------------------------------------------------------------------------
	//	Function: bringUpControlScreen 
	//	Assumes the video has been loaded. Brings up the control screen
	//
	//	Parameters: 
	//		None
	//
	//	Returns: 
	//		true, if the control screen was brought up
	//----------------------------------------------------------------------------------------
	youtube.bringUpControlScreen = function bringUpControlScreen() {
		
		var maxAttempts = 10;
		UIALogger.logMessage("Tapping window to bring up controls");
		UIATarget.localTarget().pushTimeout(0);
		for (var tapCount = 0; tapCount < maxAttempts; tapCount++) {			
			if (UIATarget.localTarget().model() != "iPad") {
				this.mainWindow().tap();
				//Wait for the video overlay fade-in to stop
				UIATarget.localTarget().delay(0.75);
				if (this.mainWindow().navigationBar().isVisible()) {
					UIATarget.localTarget().popTimeout();
					return;				
				}
			} else {
				
				var mainWindow = this.mainWindow();
				
				if (mainWindow.sliders().firstWithPredicate("name beginswith 'Track position'").isVisible() || mainWindow.navigationBars().firstWithPredicate("ANY sliders.isVisible == 1").isVisible()) {
					UIATarget.localTarget().popTimeout();
					return;
				}
				this.mainWindow().elements().firstWithName("Video").tap();
				UIATarget.localTarget().delay(0.75);
			}
		}

		UIATarget.localTarget().popTimeout();
		throw new Error("Could not bring up control screen");

	} // end youtube.bringUpControlScreen


	//----------------------------------------------------------------------------------------
	//	Funciton: getToCategoryView
	//		Navigates to the desired view, such as Featured, Bookmarks, etc
	//
	//	Parameters: 
	//		choice (string) - 				
	//					The options are:
	//						Featured
	//						Top Rated
	//						Most Viewed
	//						Favorites
	//						Subscriptions
	//						My Videos
	//						History
	//						Search (non-iPad only)
	//
	//	Returns: 
	//		true, if the desired screen is being displayed
	//----------------------------------------------------------------------------------------
	youtube.getToCategoryView = function getToCategoryView(choice) {

		this.launchIfNotActive();


        //Dismiss any lingering email compose 
        
        // Look for any visible action sheets and dismiss them
        if (UIATarget.localTarget().model() != 'iPad') {
            var actionSheet = this.actionSheet();
            if (actionSheet.isVisible()) {
                UIALogger.logMessage("Encountered an action sheet - attempting to dismiss");
                if (actionSheet.buttons()["Cancel"].isVisible()) {
                    actionSheet.buttons()["Cancel"].tap();
                } else {
                    this.logElementTree();
                    throw new Error("Encountered an action sheet without a 'Cancel' button - not sure which button to tap!");
                }
            }
        } 
        
		// Exit video if currently playing
		youtube.exitVideo();

		// A little bit of setup
		if (UIATarget.localTarget().model() == "iPad") {
			// Dismiss any popovers 
			var popover = youtube.mainWindow().popover();
			popover.logElementTree();
			if (popover.isVisible()) {
				popover.dismiss();
			}
			UIATarget.localTarget().delay(2);
		}

		var categoryButton = this.mainWindow().tabBar().buttons().firstWithName(choice);	

		if (!categoryButton.isValid()){
			if (UIATarget.localTarget().model != "iPad") {
				this.mainWindow().tabBar().buttons()["More"].tap();

				//Let any animations cease
				UIATarget.localTarget().delay(1);
				if (!this.mainWindow().tableViews()[0].cells()[choice].isValid()) {
					throw new Error( "Could not find the'" + choice + "' category.");
				} else {
					this.mainWindow().tableViews()[0].cells()[choice].tap();
				}
				
			} else {
				throw new Error( "'" + choice + "' tab bar button is not valid.");
			}
		} else {
			UIALogger.logMessage( "Choosing the '" + choice + "'category.");
			categoryButton.tap();
		}

		return this.waitForVideoListToFinishLoading();
		
	} // end youtube.getToCategoryView


	//----------------------------------------------------------------------------------------
	//	Function: exitVideo
	//		Taps the Done button
	//
	//	Throws:
	//		an exception if the button could not be pressed
	//----------------------------------------------------------------------------------------
	youtube.exitVideo = function exitVideo() {
		
		var maxAttempts = 10;

		for (var attempts = 0; attempts < maxAttempts; attempts++) {
			UIATarget.localTarget().pushTimeout(1);
			//First, check to see if we're even in the video view
			if (!this.mainWindow().elements().firstWithName("Video").isValid()) {
				UIALogger.logMessage("Not currently in a video");
				UIATarget.localTarget().popTimeout();
				return ;					
			}

			// exitVideoButton: In the case of the iPad, the left navigation bar button, otherwise, the Done button
			var exitVideoButton;
			if (UIATarget.localTarget().model() != "iPad") {
				this.bringUpControlScreen();
				var navigationBar = this.mainWindow().navigationBars().firstWithPredicate("isVisible == 1");
				exitVideoButton = navigationBar.buttons().Done;
			} else {
				if (!this.mainWindow().buttons().firstWithName("Full screen").isVisible()) this.bringUpControlScreen();
					
					
				exitVideoButton = this.mainWindow().navigationBars().firstWithPredicate("leftButton.isVisible == 1").leftButton();
			}
			
			if (exitVideoButton.isVisible()) {
				exitVideoButton.tap();
				UIALogger.logMessage( "Tapped '" + exitVideoButton.name() + "' button");

				UIATarget.localTarget().popTimeout();
				//Wait for video to disappear
				exitVideoButton.waitForInvalid();

				//Give the animation a chance to settle down
				UIATarget.localTarget().delay(5);
				//Check for Video view
				if (!this.mainWindow().elements().firstWithName("Video").isVisible()) {
					UIATarget.localTarget().popTimeout();
					return ;					
				}
			}
		}
		UIATarget.localTarget().popTimeout();
		throw new Error("Could not exit the video");
	} // end youtube.exitVideo
	
	
	//----------------------------------------------------------------------------------------
	//	Funciton: playVideo
	//		Selects the video, waits for it to load and makes sure the video is playing.  If a 
	//		pla
	//
	//	Parameters: 
	//		videoName (string) - name of the video
	//	
	//	Optional Parameters:
	//		playbackTime (int) - duration of playback.  If none is specified, the playback time 
	//			will default to 5 seconds 
	//
	//	Throws:
	//		Exception if the video playback could not be started 
	//----------------------------------------------------------------------------------------
	youtube.playVideo = function playVideo(videoName, options) {

		var timeout = 120;
		videoName = this.sanitizeVideoName(videoName);
		var videoButton;
		UIALogger.logMessage(videoName);
		var date = new Date();
		try { 
			if (!this.mainWindow().tableViews()[0].isValid()) {
				this.logElementTree();
				throw new Error("No videos in video table");
			}
			if (UIATarget.localTarget().model() != "iPad") {
				videoButton = this.mainWindow().tableViews()[0].scrollToElementWithPredicate("name matches '.*" + videoName + ".*'");
				UIALogger.logDebug("Scrolling to: " + videoButton.name());
			} else {
				var videoTableCell = this.mainWindow().tableViews()[0].cells().firstWithPredicate("ANY elements.name matches '.*" + videoName + ".*'");
				videoButton = videoTableCell.elements().firstWithPredicate("name matches '.*" + videoName + ".*'");

				UIALogger.logDebug("Scrolling to: " + videoButton.name());

                try {
                    videoButton.scrollToVisible();
                } catch(e) {
                    UIALogger.logError("scrollToVisible failed.  Reverting to manual scrolling.");
                    var maxAttempts = 20;
                    if (!videoButton.isVisible()) {
                        this.statusBar().tap()
                        for (var currentAttempt = 0; currentAttempt < maxAttempts && !videoButton.isVisible(); currentAttempt++) {
                            UIALogger.logMessage("Scrolling...");
                            this.mainWindow().tableViews()[0].scrollDown();
                            UIATarget.localTarget().delay(2);

               				videoButton = videoTableCell.elements().firstWithPredicate("name matches '.*" + videoName + ".*'");
                        }
                        if (currentAttempt == maxAttempts) throw new Error("Could not scroll to " + videoName);
                    }
					videoButton = videoTableCell.elements().firstWithPredicate("name matches '.*" + videoName + ".*'");
                }
				
			}

			UIATarget.localTarget().delay(4);

            if (!videoButton.checkIsValid()) throw new Error("Video is not valid");
			videoButton.tap();
			 
			this.waitForVideoToLoad();
            UIALogger.logMessage("Video has loaded");
			var playbackSlider = this._getVideoSlider();
			UIALogger.logMessage("Waiting for slider to disappear and playback to begin");

			//Let the video begin playing. Loop while the slider is visible - when it's not, the video will be playing.
			 for (var loadTime = 1; loadTime < timeout && playbackSlider.isVisible(); loadTime++) {
				UIATarget.localTarget().delay(1);
				 UIALogger.logMessage(loadTime + " of " + timeout + " seconds has elapsed");
			 }
			UIALogger.logMessage("Slider has disappeared");			
			if (loadTime >= timeout && playbackSlider.isVisible())
				throw new Error("Video playback did not begin after " + timeout + " + seconds");


			var totalTime = this._getTotalVideoTime();
			UIALogger.logDebug("Total play time: " + totalTime + " seconds");
			
			var playbackTimeout = totalTime / 5;
			//Let the video play
			if (options && options.playbackTime) playbackTimeout = options.playbackTime;
			playbackTimeout = (playbackTimeout > totalTime) ? totalTime : playbackTimeout;
				

			UIALogger.logMessage("Playing video for " + playbackTimeout	+ " seconds.");
			UIATarget.localTarget().delay(playbackTimeout);
			
			if(!this.isVideoPlaying())
				throw new Error("Video is not playing; attempt to play back '" + videoName + "' failed.");

		} catch (e) {
			
			UIALogger.logError(e.message);
			var lastAlert = this.alertSinceDate(date);
			if (lastAlert != null) {
				var alertString = lastAlert.alertMessageArray.join(" ");
				UIALogger.logMessage("Got an alert with message: " + alertString);
				if (alertString.match(/The author of this video does not allow playback/)) {
					throw new Error("Alert found: " + alertString);
				} else if (alertString.match(/This movie could not be played/)) {
					throw new Error("Alert found: " + alertString);
				} else if (alertString.match(/This video does not currently support/)) {
					throw new Error("Alert found: " + alertString);
				} else if (alertString.match(/Server is not responding/)) {
					throw new Error("Alert found: " + alertString);
				} else if (alertString.match(/Cannot connect to YouTube/)) {
					throw new Error("Alert found: " + alertString);
				} else if (alertString.match(/Movie could not be played/)) {
					throw new Error("Alert found: " + alertString);
				}
			}
			throw new Error(e.message);
			
		}
		
		UIALogger.logMessage( "Successfully started the playback for the movie '" + videoName + "'");
		return ;
		
	} // end youtube.playVideo


	//----------------------------------------------------------------------------------------
	//	Function: bookmarkExists
	//		Checks if the specified video exists as a bookmark
	//
	//	Parameters: 
	//		videoName (string) - the name of the video being looked for. 
	//
	//	Returns: 
	//		True, if the video exists as a bookmark, false if it doesn't
	//	
	//----------------------------------------------------------------------------------------
	youtube.bookmarkExists = function bookmarkExists(videoName) {
		videoName = this.sanitizeVideoName(videoName);
		UIALogger.logMessage("Switching to 'Favorites' view and looking for video: " + videoName);
		this.getToCategoryView("Favorites");
		var bookmarkButton;
		if (UIATarget.localTarget().model() != "iPad") {		
			bookmarkButton = this.mainWindow().tableViews()[0].scrollToElementWithPredicate("name matches '.*" + videoName + ".*'");
		} else {
			bookmarkButton = this.mainWindow().tableViews()[0].cells().firstWithPredicate("ANY elements.name matches '.*" + videoName + ".*'");
		}
		
		if (bookmarkButton.isValid()) {
			UIALogger.logMessage("Found '" + videoName + "'");
			return true;
		} else {
			UIALogger.logMessage("Could not find '" + videoName + "'");
			return false;
		}
		
	} // end youtube.bookmarkExists



	//----------------------------------------------------------------------------------------
	//	Funciton: deleteBookmarkedVideo
	//		Deletes the given movie and tests to check if the video has actually been deleted
	//
	//	Parameters: 
	//		videoName (string) - Name of the video to delete.  Please note that the name of the 
	//							video must be exact.  An approximate match will not be successful
	//
	//	Throws:
	//		Exception if the bookmark could not be deleted or any reason 
	//----------------------------------------------------------------------------------------
	youtube.deleteBookmarkedVideo = function deleteBookmarkedVideo( videoName ) {
		videoName = this.sanitizeVideoName(videoName);

		var youtubeTable = this.mainWindow().tableViews()[0];
		if (!this.areVideosPresent())  { 
			UIALogger.logError( "No videos in Favorites" ); 
			return false;
		}
	
		var videoButton = youtubeTable.scrollToElementWithPredicate("name matches '.*" + videoName + ".*'");
		
		if (!videoButton.isValid())	throw new Error( "Cannot find " + videoName + " in the 'Favorites' table" ); 
		
		var editButton = this.mainWindow().navigationBar().buttons().firstWithName("Edit");
		
		if (!editButton.isValid()) throw new Error( "Cannot find Edit button" ); 
		
		editButton.tap();
		UIALogger.logMessage("Deleting " + videoName);
	
		this.deleteTableCell(videoButton);
	
		if (!this.bookmarkExists(videoName)) {
			UIALogger.logMessage( "City to remove not found in list. Deletion successful"); 
			return true;
		} 
		throw new Error( "City to remove found in list. Deletion not successful"); 

	} // end youtube.deleteBookmarkedVideo


	//----------------------------------------------------------------------------------------
	//	Function: waitForVideoListToFinishLoading 
	//		Wait until video list is populated with videos
	//
	//	Parameters: 
	//		None
	//
	//	Returns: 
	//		True if contents of the finish loading 
	//----------------------------------------------------------------------------------------
	youtube.waitForVideoListToFinishLoading = function waitForVideoListToFinishLoading(maxCount){		
		if (maxCount == 0 || !maxCount) maxCount = 60;
		
		UIALogger.logMessage( "Waiting patiently for list to load");	
		UIATarget.localTarget().pushTimeout(1);
		for (var count = 0; count < maxCount && !this.mainWindow().tableViews()[0].isValid(); count++) {
			UIALogger.logMessage("Waiting for video list to load... " + (maxCount - count) + " seconds left.");
		}
		UIATarget.localTarget().popTimeout();
		return this.areVideosPresent();
		
	} // end youtube.waitForVideoListToFinishLoading


	//----------------------------------------------------------------------------------------
	//	Functoon: signOutOfYouTubeAccount
	//		Sign out of youtube account
	//
	//	Parameters: 
	//		None
	//
	//	Throws:
	//		exception if the account could not be signed out of
	//----------------------------------------------------------------------------------------
	youtube.signOutOfYouTubeAccount = function signOutOfYouTubeAccount() {
		this.getToCategoryView("Favorites");
		var signOutButton = this.mainWindow().navigationBar().buttons().firstWithName("Sign Out");
		if (!signOutButton.isValid()) throw new Error("'Sign Out' button is not valid");
		signOutButton.tap();
		UIATarget.localTarget().delay(2);
		var actionSheetElement;
		if (UIATarget.localTarget().model() == 'iPad') {
			actionSheetElement = this.mainWindow().popover().actionSheet().buttons().firstWithName("Sign Out");
		} else {
			actionSheetElement = this.actionSheet().buttons().firstWithName("Sign Out");			
		}

		actionSheetElement.tap();
		return;
		
	} // end youtube.signOutOfYouTubeAccount

	//----------------------------------------------------------------------------------------
	//	Funciton: signInToYouTubeAccount 
	//		Sign in to youtube account
	//
	//	Parameters: 
	//		None
	//
	//	Throws:
	//		exception if the account could not be signed into
	//----------------------------------------------------------------------------------------
	youtube.signInToYouTubeAccount = function signInToYouTubeAccount() {
		var alertDate = new Date();
		this.getToCategoryView("Favorites");
        var authResult = 1;
		UIALogger.logMessage( "Attempting to sign into account");

		if (youtube.mainWindow().navigationBar().buttons().firstWithName("Sign Out").isValid()) {
			UIALogger.logMessage( "Currently signed into account. Attempting to sign out.");
			youtube.signOutOfYouTubeAccount();
		}
		
		// Let any animations cease
		UIATarget.localTarget().delay(1);
		var signInButton = this.mainWindow().navigationBar().buttons().firstWithName("Sign In");
		if (!signInButton.isValid()) throw new Error("'Sign In' button is not valid");

        var youtubeSignInAlertHandler = function(alert) {
            UIATarget.localTarget().pushTimeout(1);
            
            if (alert.staticTexts().firstWithPredicate("name contains 'Existing Favorite'").isValid()) {
                UIALogger.logMessage("Merging existing youtube bookmarks");
                alert.buttons().firstWithName("Merge").tap();
            } else if (alert.staticTexts().firstWithPredicate("name contains 'YouTube Password'").isValid()) {
                UIALogger.logMessage("Entering username / password");
                youtube.enterTextInTextField(alert.textFields().firstWithValueForKey("Username", "value"), youtube.authentication.username);
                UIATarget.localTarget().delay(1);
                youtube.enterTextInTextField(alert.secureTextFields().firstWithValueForKey("Password", "value"), youtube.authentication.password);
                alert.buttons().firstWithName("Sign In").tap();
            } else if (alert.staticTexts().firstWithPredicate("name contains 'Authentication Failed'").isValid()) {
                UIALogger.logMessage("Authentication Failed");
                authResult = 0;
            }
            
            UIATarget.localTarget().popTimeout();
            

        };

        UIATarget.pushAlertHandler(youtubeSignInAlertHandler);
        signInButton.tap();

        // It's not ideal, but wait for 10 seconds to ensure that auth (or lack thereof) has completed
		UIATarget.localTarget().delay(10);	
        
        UIATarget.popAlertHandler();
        
        if (!authResult) throw new Error("Failed to authenticate with supplied username and password");


		return;
	} // end youtube.signInToYouTubeAccount

	//----------------------------------------------------------------------------------------
	//	Function: addBookmark	
	//		Add a bookmark of a video that is already playing, ensures that 
	//		the Movie player add bookmark button is not enabled before   
	//		continuing on.
	//	
	//	Parameters: 
	//		None
	//	
	//	Throws: 
	//		An exception if the bookmark could not be added
	//----------------------------------------------------------------------------------------
	youtube.addBookmark = function addBookmark() {
		var maxAttempts = 5;
		var bookmarkElement;
		for ( var attempt = 0; attempt < 5; attempt++) {
            
            
            // use videoHasBeenBookmarked here to check
			if (UIATarget.localTarget().model() != "iPad") {

                if (this.videoHasBeenBookmarked()) throw new Error("Movie player 'Bookmark' button is disabled, video has been bookmarked");
                this.bringUpControlScreen();
				bookmarkElement = this.mainWindow().buttons().firstWithPredicate("name contains 'Bookmark'");
				bookmarkElement.tap();
				UIALogger.logMessage("Added bookmark...");
				return;
			} else {
				UIALogger.logMessage("Here we go");
				//iPad-specific bookmark scripts
				UIATarget.localTarget().pushTimeout(0);

				if (!this.mainWindow().buttons().firstWithName("Full screen").isValid()) {
					//This branch is for videos in fullscreen mode (landscape or not)
					if (this.videoHasBeenBookmarked()) throw new Error("Movie player 'Bookmark' button is disabled, video has been bookmarked");
					bookmarkElement = this.mainWindow().images().firstWithPredicate("ANY buttons.name == 'Bookmark'").buttons().firstWithPredicate("name == 'Bookmark' and isVisible == 1");
					bookmarkElement.tap();
				} else {
					if (this.videoHasBeenBookmarked()) throw new Error("Movie player 'Bookmark' button is disabled, video has been bookmarked");
					//This branch is for full-screen iPad views, landscape or otherwise 
					bookmarkElement = this.mainWindow().buttons().firstWithPredicate("name beginswith 'Add' and isVisible == 1");
					bookmarkElement.tap();
					UIATarget.localTarget().popTimeout();
					if (!this.isLandscape() && this.mainWindow().popover().isValid()) {
						this.mainWindow().popover().tableViews()[0].cells()["Favorites"].tap();
                        //Let the popover have a chance to disappear
                        UIATarget.localTarget().delay(2);
						return;
					}
					
				} // end if-else
 
			} // end if-else

		} // end for
		
		throw new Error("Could not add bookmark");
	}
	
	//----------------------------------------------------------------------------------------
	//	Function: sanitizeVideoName 
	//		Sanitize video information such as # of views that may change and could potentially
	//		throw off tests.  Also calls escapeString also escape regex characters.
	//
	//	Parameters: 
	//		None
	//
	//	Returns: 
	//		Sanitized string
	//----------------------------------------------------------------------------------------
	youtube.sanitizeVideoName = function sanitizeVideoName(string) {
		if (string.match(/^more info, /)) {
			string = string.replace(/^more info, /, "");
		} 
		string = string.replace(/, [0-9]* views.*/, "");
		return UIAUtility.escapeString(string);				
	} //end sanitizeVideoName

    
    //----------------------------------------------------------------------------------------
	//	Function: videoHasBeenBookmarked 
	//		Check via the movie overlay if the video has already been bookmarked or not.
	//
	//	Parameters: 
	//		None
	//
	//	Returns: 
	//		true if the video has been bookmarked, false otherwise
	//----------------------------------------------------------------------------------------
	youtube.videoHasBeenBookmarked = function videoHasBeenBookmarked() {
        UIALogger.logMessage("Determining if video has already been bookmarked");
        var popover;
        if (UIATarget.localTarget().model() != "iPad") {
            
            youtube.bringUpControlScreen();
            bookmarkElement = this.mainWindow().buttons().firstWithPredicate("name contains 'Bookmark'");
            if (!bookmarkElement.isEnabled()) {
                UIALogger.logMessage("Movie player 'Bookmark' button is disabled, video has been bookmarked");
                return true;
            }
			UIALogger.logMessage("Video has not been bookmarked yet");
        } else {
            
            //iPad-specific bookmark scripts
            UIATarget.localTarget().pushTimeout(1);
            this.bringUpControlScreen();            
            if (!this.mainWindow().buttons().firstWithName("Full screen").isValid()) {
                //This branch is for videos in fullscreen mode (landscape or not)
                bookmarkElement = this.mainWindow().images().firstWithPredicate("ANY buttons.name == 'Bookmark'").buttons().firstWithPredicate("name == 'Bookmark' and isVisible == 1");
                bookmarkElement.tap();
                popover = this.mainWindow().popover();
                if (!popover.tableViews()[0].cells()["Favorites"].isEnabled()) {
                    UIALogger.logMessage("Movie player 'Favorites' button is disabled, video has already been bookmarked");
                    popover.dismiss();
                    return true;
                }
                popover.dismiss();
                
            } else {
                //This branch is for full-screen iPad views, landscape or otherwise 
                bookmarkElement = this.mainWindow().buttons().firstWithPredicate("name beginswith 'Add' and isVisible == 1");
                bookmarkElement.tap();
                popover = this.mainWindow().popover();
                UIATarget.localTarget().popTimeout();
                if (!this.isLandscape()) {
                if (!popover.tableViews()[0].cells()["Favorites"].isEnabled()) {
                        UIALogger.logMessage("Movie player 'Favorites' button is disabled, video has already been bookmarked");
                        popover.dismiss();
                        return true;
                    }
                    popover.dismiss();
                    //Let the popover have a chance to disappear
                    UIATarget.localTarget().delay(2);
                }
                
            } // end if-else
            
        } // end if-else
        
        return false;
        
	} //end videoHasBeenBookmarked
    

} // end if
