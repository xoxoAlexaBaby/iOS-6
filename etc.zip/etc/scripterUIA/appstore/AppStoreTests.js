#import "./AppStore.js"
#import "../libs/PHTesting.js"

//----------------------------------------------------------------------------------------
//	Function: appStoreTest_purchaseAppThroughSearching 
//		Search for an application using specified search
//		text, select the application by display name from the resulting list and select the
//		application for installation.
//
//	Parameters: 
//		displayName (string) - the name of the application to install as displayed in the store
//		password (string) - the active accounts iTunes password (if null we'll try to use the last password)
//		searchString (string - optional) - the search string to use when searching for the application
//		appName (string - optional) - the app icon name for validating the application's icon
//		username (string - optional) - the username that matches the above password.
//
//	Returns: 
//		1 if we can verify that the application was installed and 0 if not
//----------------------------------------------------------------------------------------
function appStoreTest_purchaseAppThroughSearching() {
	
	var displayName, appName, password, searchString, username;
	if (this.argv.length < 1) {
		this.logError(this.testName + ": Application display name not specified.");
		return 64;		
	}
	
	var puchaseOptions = new Object();
	if (this.argv.length > 0) displayName = this.argv[0];
	if (this.argv.length > 1) puchaseOptions.password = this.argv[1];
	if (this.argv.length > 2) searchString = this.argv[2];
	if (!searchString) searchString = displayName;
	if (this.argv.length > 3) appName = this.argv[3];
	if (this.argv.length > 4) puchaseOptions.username = this.argv[4];
	
	UIALogger.logMessage("Application to be purchased is '" + displayName +"'.");

	appstore.launchIfNotActive();
	
	var date = new Date();
	appstore.search(searchString, {displayName:displayName});
	appstore.purchaseCurrentSelection(puchaseOptions);
	var alert = springboard.alertSinceDate(date);
	if (alert && alert.alertMessageArray[0].indexOf("read and agree") >= 0) {
		UIALogger.logDebug("Got the 'Terms and Conditions' changed alert. Need to purchase again");
		appstore.launchIfNotActive();
		appstore.search(searchString, {displayName:displayName});
		appstore.purchaseCurrentSelection(puchaseOptions);
	}
	
	if (appName) {
		var subTest = phtCreateTest("ValidateAppInstallation", [appName, 240], appStoreTest_validateAppInstallation, "Validating the installation of application '" + appName + "'.");
		var result = subTest.execute();
		if (subTest.testError) this.testError = subTest.testError;
		return this.testResult = subTest.testResult;		
	}
	
	return this.testResult = 1;
}

//----------------------------------------------------------------------------------------
//	Function: appStoreTest_validateAppInstallation 
//		Check to see if an application has been installed
//
//	Parameters: 
//		appName (string) - the icon name for the application
//		additionalAppNames (strings - optional) - used to verify multiple apps
//		timeout (number) - how long to wait for the install process to complete
//
//	Notes: 
//		This test will wait for pending installations and fail if we don't complete withing a timeout specified
//
//	Returns: 
//		1 if we can verify that the application was installed and 0 if not
//----------------------------------------------------------------------------------------
function appStoreTest_validateAppInstallation() {
	
	var appNames, timeout;
	var missingApps = new Array();
	
	if (this.argv.length < 1) {
		UIALogger.logError("Application name not specified.");
		return 64;
	}
	
	if (this.argv.length > 0) appNames = [this.argv[0]];
	for (var index = 1; index < this.argv.length-1; index++) {
		appNames.push(this.argv[index]);
	}
	
	// if the last argument appears to be a timeout use it as such, otherwise pop it on the array as another ID
	var timeout = parseFloat(this.argv[this.argv.length-1]);
	if (!timeout) {
		timeout = 120.0;
		if (this.argv.length > 1) {
			appNames.push(this.argv[this.argv.length-1]);
		}
	}
	
	// bring springboard up
	springboard.getToSpringBoard();
	
	if (!springboard.isFrontmost()) {
		this.testError = "Failed to return to springboard.";
		UIALogger.logError(this.testError);
		return this.testResult = 0;
	}
	springboard.waitForNetworkLoadingToFinish();
	
	//we are going to use the fact that a downloading icon has other info in its name to check when it has finished downloading
	for (var appIndex = 0; appIndex < appNames.length; appIndex++) {
		var appName = appNames[appIndex];
		var appIcon = springboard.mainWindow().scrollViews()[0].elements().firstWithPredicate("name contains '" + appName + "'"); 
		if (!appIcon.isValid()) {
			UIALogger.logError("Application with name '" + appName + "' not found.");
			missingApps.push(appName);
		} else {
			UIALogger.logDebug("Found '" + appIcon.name() + "'");
			UIATarget.localTarget().pushTimeout(timeout);
			var installed = appIcon.withName(appName).isValid();
			UIATarget.localTarget().popTimeout();
			if (!installed) {
				this.testError = appIcon.name() + " did not install successfully";
				UIALogger.logError(this.testError);
				return this.testResult = 0;
			}
		}
	}
	
	if (missingApps.length > 0) {
		this.testError = "Failed to locate application(s) by name(s).";
		return this.testResult = 0;						
	}		
	
	return this.testResult = 1;
}

//----------------------------------------------------------------------------------------
//	Function: appStoreTest_updateAllApps 
//		Update all installed applications.
//
//	Parameters: 
//		password (string - optional) - the iTunes account password
//
//	Returns: 
//		1 if we can verify that the application was installed and 0 if not
//----------------------------------------------------------------------------------------
function appStoreTest_updateAllApps() {
	var password;
	if (this.argv.length > 0) password = this.argv[0];
	
	appstore.launchIfNotActive();
	
	var count = appstore.checkForUpdates();
	if (count > 0) {
		UIALogger.logDebug(count + " updates available.");	
		appstore.updateAllApps(password);
	} else {
		UIALogger.logDebug("No application updates available.");
	}
	
	return this.testResult = 1;
}

// Create self tests -- this is an unnamed function, just to make sure any local variables stay in the correct context
(function(){
	if (typeof appstore.selfTests == 'undefined') {
		appstore.selfTests = new Array();
	}
	
	var kStoreUsername = "jsmith.purple@gmail.com";
	var kStorePassword = "sugarbowl";
	appstore.selfTests.push(phtCreateTest("PurchaseFacebook", ["Facebook", kStorePassword, null, "Facebook", kStoreUsername], appStoreTest_purchaseAppThroughSearching, "Search for 3rd party app 'Facebook' and purchase it"));
}())