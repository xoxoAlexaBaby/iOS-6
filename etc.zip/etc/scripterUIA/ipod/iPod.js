/*
 Class: UIApp (ipod)
 YouTube object
 */
#import "../libs/SpringBoard.js"
#import "../libs/UIAAppMediaAdditions.js"

if (UIATarget.localTarget().model() != 'iPad')
    audio = UIAApp.application("Music", "com.apple.mobileipod");
else 
    audio = UIAApp.application("Music", "com.apple.Music");

video = UIAApp.application("Videos", "com.apple.videos");

if (typeof audio != 'undefined' && typeof video != 'undefined') {
	
	audio.playbackActions = {};
	audio.playbackActions.PLAY = "Play";
	audio.playbackActions.PAUSE = "Pause";
	audio.playbackActions.PREVIOUS = "Previous";
	audio.playbackActions.NEXT = "Next";
	
	audio.flipActions = {};
	audio.flipActions.FORWARD = "Forward";
	audio.flipActions.BACK = "Back";
	
	video.playbackActions = {};
	video.playbackActions.PLAY = "Play";
	video.playbackActions.PAUSE = "Pause";
	video.playbackActions.PREVIOUS = "Previous";
	video.playbackActions.NEXT = "Next";
	
	audio.alertHandler = function alertHandler(alert) {

		UIATarget.localTarget().pushTimeout(0);
		//Current Location message
		
		if (alert.staticTexts().firstWithPredicate("name contains 'Delete'").isValid()) {
			UIALogger.logMessage("Got the delete playlist alert");
			alert.buttons()["Delete"].tap();
		} 
		UIATarget.localTarget().popTimeout();
		
		if (!alert.waitForInvalid()) throw new Error("Could not handle the alert");
		return true;
	}
	
	//----------------------------------------------------------------------------------------
	//	Function: songsTable 
	//		Returns the table element that contains the song, artist, album, etc. names. On 
	//		iPad devices, this is generally the right-hand side table, otherwise it is mostly 
	//		the (only) visible table
	//
	//	Parameters: 
	//		None
	//
	//	Returns: 
	//		the songs table element
	//----------------------------------------------------------------------------------------
	audio.songsTable = function songsTable() {
		var visibleTables = this.mainWindow().tableViews().withPredicate("isVisible == 1");
		return visibleTables[visibleTables.length-1];
	}
	
	//----------------------------------------------------------------------------------------
	//	Function: bottomBar 
	//		Returns the bottom bar element that contains the Songs, Artists, Albums, Genres, 
	//		etc. buttons
	//
	//	Parameters: 
	//		None
	//
	//	Returns: 
	//		the bottom bar element
	//----------------------------------------------------------------------------------------
	audio.bottomBar = function bottomBar() {
		if (UIATarget.localTarget().model() == 'iPad') {
			UIATarget.localTarget().pushTimeout(0);
			var bottomBar = this.mainWindow().segmentedControls().firstWithPredicate("ANY buttons.label contains 'Songs' and isVisible == 1");
			UIATarget.localTarget().popTimeout();
			return bottomBar;
		} else
			return this.tabBar();
	}

    //----------------------------------------------------------------------------------------
    //	Function: bottomBarButtonWithName 
    //		Returns the bottom bar button element with the specified name 
    //
    //	Parameters: 
    //		name (string) - the name of the bottom bar button element (e.g. Songs, Playlists, etc.)
    //
    //	Returns: 
    //		the bottom bar element with the specified name
    //----------------------------------------------------------------------------------------
    audio.bottomBarButtonWithName = function bottomBarButtonWithName(name) {
        if (UIATarget.localTarget().model() == 'iPad')
            return this.bottomBar().buttons().firstWithPredicate("label contains '" + name + "'");
        else
            return this.bottomBar().buttons()[name];
    }
	//----------------------------------------------------------------------------------------
	//	Function: albumArt 
	//		Returns the UIAElement representing the album art 
	//
	//	Parameters: 
	//		None
	//
	//	Returns: 
	//		the UIAElement representing the album art 
	//----------------------------------------------------------------------------------------
    audio.albumArt = function () {
        return this.mainWindow().scrollViews()[0].elements().firstWithPredicate("name contains 'Album art'");
    }
    
	//----------------------------------------------------------------------------------------
	//	Function: audioControlWithName 
	//		Returns the control element with the given name. 
	//
	//	Parameters: 
	//		name (string) - the name of the control e.g. "Play", "Pause", "Done", "Back", etc.
	//
	//	Returns: 
	//		the control element with the specified name
	//----------------------------------------------------------------------------------------
	audio.audioControlWithName = function audioControlWithName(name) {
		if (UIATarget.localTarget().model() == 'iPad') {
			var isInAlbumArtView = this.albumArt().isValid();
			if (isInAlbumArtView) {
				UIALogger.logDebug("In album art view");
				UIATarget.localTarget().pushTimeout(0);
				var controlElement = this.mainWindow().elements()[name];
				UIATarget.localTarget().popTimeout();
				if (controlElement.isValid() && !controlElement.isVisible()) {
					UIALogger.logDebug("Found control but it is not visible -- tapping the main window");
					this.mainWindow().tap();
					var isVisible = controlElement.withPredicate("isVisible == 1").isValid();
					if (!isVisible) 
						UIALogger.logWarning("Tapped the window to bring up the controls, but still seem to be invisible");
				}
				return controlElement;
			} else
				return this.mainWindow().elements()[name]; //this will work with the non-Now Playing view
		} else {
			switch (name) {
				case 'Back':
					return this.mainWindow().navigationBar().elements()[name];
				default:
					return this.mainWindow().elements()[name];
			}
		}
	}

	//----------------------------------------------------------------------------------------
	//	Function: topBarElementWithName 
	//		Returns an element, in the top bar of the music player app, with the specified 
	//		name
	//
	//	Parameters: 
	//		name (string) - the name of the top bar element 
	//
	//	Returns: 
	//		the top bar element with the specified name
	//----------------------------------------------------------------------------------------
	audio.topBarElementWithName = function topBarElementWithName(name) {
        if (UIATarget.localTarget().model() == 'iPad') 
            return this.mainWindow().elements()[name];
        else 
            return this.navigationBar().elements()[name];
	}

	//----------------------------------------------------------------------------------------
	//	Function: topBarElementWithPredicate 
	//		Returns an element, in the top bar of the music player app, with the specified 
	//		predicate
	//
	//	Parameters: 
	//		predicateString (string) - the predicate string that will be used to fine the 
	//		    the top bar element 
	//
	//	Returns: 
	//		the top bar element with the specified predicate
	//----------------------------------------------------------------------------------------
    audio.topBarElementWithPredicate = function topBarElementWithPredicate(predicateString) {
        if (UIATarget.localTarget().model() == 'iPad') 
            return this.mainWindow().elements().firstWithPredicate(predicateString);
        else 
            return this.navigationBar().elements().firstWithPredicate(predicateString);
    }
    
	//----------------------------------------------------------------------------------------
	//	Function: areSongsOnDevice 
	//		Must be navigated to one of the views where songs should be.
	//
	//	Parameters: 
	//		None
	//
	//	Returns: 
	//		Returns true if songs are on the device, false if not.
	//----------------------------------------------------------------------------------------
	audio.areSongsOnDevice = function areSongsOnDevice() {
		UIATarget.localTarget().pushTimeout(0.1);
		var result = this.mainWindow().elements().firstWithPredicate("name contains 'No Music' or name contains 'No Content'").isValid();
		UIATarget.localTarget().popTimeout();
		return (!result);
	}
	
	//----------------------------------------------------------------------------------------
	//	Function: getSongName
	//		Gets the name of the current song--it may or may not be playing. 
	//		Note that this function might tap the 'Now Playing' button (for Apex).
	//
	//	Parameters: 
	//		None
	//
	//	Returns: 
	//		The name of the song, or throws an error if it is not able to determine the song name.
	//
	//	Throws: 
	//		Error
	//----------------------------------------------------------------------------------------
	audio.getSongName = function getSongName() {	
		return audio.getSongDetails().currentSongName;
	}
	
	//----------------------------------------------------------------------------------------
	//	Function: verifyMusicIsPlaying
	//		Checks whether the track progressed or not to verify that the music is playing. 
	//
	//	Parameters: 
	//		time (int) - optional - the number of seconds to allow the music to play before 
	//			checking whether the track progressed or not. If no value is specified, a 
	//			random value is chosen. 
	//
	//	Returns: 
	//		None
	//
	//	Throws: 
	//		Error
	//----------------------------------------------------------------------------------------
	audio.verifyMusicIsPlaying = function verifyMusicIsPlaying(time) {
		
		if (!time) time = system.randomInteger(1,5); 
		UIALogger.logMessage("Verifying music is playing for " + time + " seconds");
				
		if (!this.audioControlWithName("Pause").isValid()) {
			UIALogger.logError("Pause button is not present -- music cannot be playing");
			return false;
		}
		
		try {
			this.controlSongPlaybackState(this.playbackActions.PLAY, time);
			return true;
		} catch(e) {
			UIALogger.logError("Encountered error: " + e.message);
			return false; 
		}
	}
	
	//----------------------------------------------------------------------------------------
	//	Function: navigatePreviousNext
	//		Selects the previous/next buttons in the order specified. 
	//		Assumes that a song is playing. 
	//
	//	Parameters: 
	//		actions (array) - a sequence of audio.playbackActions.PREVIOUS or 
	//			audio.playbackActions.NEXT. For instace, [audio.playbackActions.PREVIOUS, 
	//			audio.playbackActions.NEXT, audio.playbackActions.PREVIOUS] will tap the 
	//			Previous button, then the Next button, and then the Previous button again
	//		shouldVerify (boolean) - if set to true, it checks that the effect of tapping 
	//			the next/previous button is expected (song name, song indices, etc.). It is 
	//			set to false, by default. Please note that the verification does not work 
	//			with Shuffle enabled on Wildcat.
	//
	//	Returns: 
	//		None
	//
	//	Throws: 
	//		Error
	//----------------------------------------------------------------------------------------
	audio.navigatePreviousNext = function navigatePreviousNext(actions, shouldVerify) {
		
		// currentSong, previousSongStack, nextSongStack will keep track of song info
		// for Wildcat e.g. if A is playing now, A will be assigned to currentSong. 
		// If 'Next' is tapped, nextSongStack will be popped, and the returned song 
		//	name will be assigned to currentSong (provided the stack is not empty). 
		//	And, A will be pushed on to the previousSongStack. Note that this system 
		//	of storing state is not very 'Repeat All' friendly since multiple copies 
		//	of the same song can be stored in cases where 'Repeat All' is enabled. 
		var currentSong;
		var previousSongStack = new Array();
		var nextSongStack = new Array();
		
		// songDictionary will keep track of song info for Apex. The keys will be indices 
		// of songs, and the value will be the song names
		var songDictionary = new Array();
		
		var currentSongDetails = audio.getSongDetails();	
		currentSong = currentSongDetails.currentSongName;
		
		UIALogger.logMessage("Currently playing " + currentSong);
		
		if (currentSongDetails.currentSongIndex != null) 
			songDictionary[currentSongDetails.currentSongIndex.toString()] = currentSong;
		
		var isRepeatAllEnabled = (this.audioControlWithName("Repeat").value() == 1); 
		if (isRepeatAllEnabled) UIALogger.logMessage("Repeat is enabled");
		
		for (var i=0; i<actions.length; i++) {
			UIALogger.logMessage("Performing " + (i+1) + "th action. Using '" + actions[i] + "' control.");
			
			var buttonName = (actions[i] == audio.playbackActions.PREVIOUS) ? "Previous track" : "Next track";
			var controlElement = this.audioControlWithName(buttonName);
			if (!controlElement.isValid()) {
				throw new Error("Could not find the '" + actions[i] + "' button");
			}
			controlElement.logElement();
			controlElement.tap();
			UIATarget.localTarget().delay(1);
			
			if (!shouldVerify) continue;
			
			var lastPlayedSongDetails = currentSongDetails;
			try {
				currentSongDetails = audio.getSongDetails();
			} catch(e) {
				UIALogger.logError(e.message);
				// This mostly likely implies no song is playing. In what cases can this happen?
				
				// Case #1 first track and hit previous and there was no repeat
				// Case #2 last track and hit next and no repeat
				if (lastPlayedSongDetails.currentSongIndex && !isRepeatAllEnabled) {
					if (lastPlayedSongDetails.currentSongIndex == 1 && actions[i] == audio.playbackActions.PREVIOUS) {
						UIALogger.logMessage("Hit 'Previous' when playing the first track");
						return ;
					}
					if (lastPlayedSongDetails.currentSongIndex == lastPlayedSongDetails.totalNumberOfSongs && 
						actions[i] == audio.playbackActions.NEXT) {
						UIALogger.logMessage("Hit 'Next' when playing the last track");
						return ;
					}
				}
				
				// Case #last Error
				throw new Error("Could not get the current song details");
			}
			
			//check expected index if did not just select previous as the first action and not wildcat
			//there is ambiguity associated with tapping previous as the first action since we do not know 
			//if it will jump to the previous track, or seek to the start
			if (i != 0 && currentSongDetails.currentSongIndex != null) {
				UIALogger.logMessage("Verifying that the index of the current song is expected");
				var expectedIndex = (actions[i] == audio.playbackActions.NEXT) ? lastPlayedSongDetails.currentSongIndex + 1 : lastPlayedSongDetails.currentSongIndex - 1;
				if (isRepeatAllEnabled) expectedIndex = ((expectedIndex - 1 + currentSongDetails.totalNumberOfSongs) % (currentSongDetails.totalNumberOfSongs)) + 1;
				UIALogger.logMessage("The expected index is " + expectedIndex + ". The current index is " + currentSongDetails.currentSongIndex);
				if (expectedIndex != currentSongDetails.currentSongIndex) {
					throw new Error("The current song index is not expected.");
				}
			}
			
			//check expected song name if info available
			if (currentSongDetails.currentSongIndex != null) {
				//in Apex world
				var currentSongName = currentSongDetails.currentSongName;
				var expectedSongName = songDictionary[currentSongDetails.currentSongIndex.toString()];
				if (expectedSongName != null) {
					UIALogger.logMessage("Checking if the current song name '" + currentSongName + "' is expected.");
					if (expectedSongName != currentSongName) {
						UIALogger.logError("Song at index " + currentSongDetails.currentSongIndex + " is " + currentSongName);
						throw new Error("Name mismatch. The expected song is " + expectedSongName);
					}
				} else {
					UIALogger.logMessage("Song at index " + currentSongDetails.currentSongIndex + " is " + currentSongName);
					songDictionary[currentSongDetails.currentSongIndex.toString()] = currentSongName;
				}
			} else {
				//in Wildcat world
				if (i == 0 && actions[i] == audio.playbackActions.PREVIOUS) {
					currentSong = currentSongDetails.currentSongName;
				} else {
					var stackToPush = (actions[i] == audio.playbackActions.NEXT) ? previousSongStack : nextSongStack;
					var stackToPop = (actions[i] == audio.playbackActions.NEXT) ? nextSongStack : previousSongStack;
					stackToPush.push(currentSong);
					currentSong = currentSongDetails.currentSongName;
					if (stackToPop.length > 0) {
						UIALogger.logMessage("Verifying that the current song name is expected");
						var expectedSongName = stackToPop.pop();
						UIALogger.logMessage("Current song name is '" + currentSong + "'. Expected song name is '" + expectedSongName + "'");
						if (expectedSongName != currentSong) {
							throw new Error("The current song name is not expected.");
						}
					}
				}
			}
		} //end for loop
	}


	//----------------------------------------------------------------------------------------
	//	Function: getSongDetails
	//		Gets the details of the current song--it may or may not be playing. 
	//		Note that this function might tap the 'Now Playing' button.
	//
	//	Parameters: 
	//		None
	//
	//	Returns: A hash containing the details of the song: 
	//		currentSongName - the name of the song that is playing or paused
	//		currentArtistName
	//		currentAlbumName
	//		currentSongIndex - the index of the song in the list (x of y) -- only for non-iPad devices
	//		totalNumberOfSongs - total number of songs in the list -- only for non-iPad devices
	//		timeRemaining - time remaining as shown next to the progress slider
	//		timeElapsed - time elapsed as shown next to the progress slider
	//
	//	Throws: 
	//		Error
	//----------------------------------------------------------------------------------------
	audio.getSongDetails = function getSongDetails() {	
		
		UIALogger.logMessage("Getting song details");
		var songDetails = new Object();
		
		//toggle to current playing screen
		UIATarget.localTarget().pushTimeout(0.1);
		if (UIATarget.localTarget().model() == 'iPad')
			var nowPlayingButton = this.mainWindow().buttons().firstWithPredicate("name contains 'Now playing'");
		else
			var nowPlayingButton = this.navigationBar().buttons()["Now playing"];
		UIATarget.localTarget().popTimeout();
		if (nowPlayingButton.isValid()) nowPlayingButton.tap();
		
		if (UIATarget.localTarget().model() == 'iPad')
			var nowPlayingImage = this.albumArt();
		else 
			var nowPlayingImage = this.mainWindow().images().firstWithPredicate("name contains 'NowPlaying'");
		if (!nowPlayingImage.isValid()) throw new Error("Not in the 'Now playing' view");
		UIATarget.localTarget().delay(1); //a second for animations
		
		//expose the top overlay and get the song title element
		var songInfoDelimiter;
		if (UIATarget.localTarget().model() == 'iPad') {
			songInfoDelimiter = ", ";
			if (!this.audioControlWithName("Track position").isValid()) UIALogger.logWarning("Did not find the 'Track position' slider");
			var titleElement = this.mainWindow().elements().firstWithPredicate("className == 'UIAElement'");
		} else {
			//check the top overlay
			songInfoDelimiter = ". ";
			UIATarget.localTarget().pushTimeout(0.1);
			if (nowPlayingImage.name() != "NowPlayingTopOverlay.png") this.mainWindow().tap();
			UIATarget.localTarget().popTimeout();
			var titleElement = this.navigationBar().elements().firstWithPredicate("name contains '" + songInfoDelimiter + "'");
		}
		if (!titleElement.isValid()) throw new Error("Could not find the song title element");
		if (!titleElement.name()) {
			UIALogger.logError("Song title is blank");
			throw new Error("Song title is not in the expected format");
		}
		var titleArr = titleElement.name().split(songInfoDelimiter);
        
		if (UIATarget.localTarget().model() == 'iPad') {
			if (titleArr.length == 1) {
			    songDetails.currentSongName = titleArr[0];
			} else {
			    songDetails.currentArtistName = titleArr[0];
			    songDetails.currentSongName = titleArr[1];
			    songDetails.currentAlbumName = titleArr[2]; 
			}
		} else {
			songDetails.currentArtistName = titleArr[0];
			songDetails.currentSongName = titleArr[1];
			songDetails.currentAlbumName = titleArr[2];
		}
		UIALogger.logDebug("Artist name: " + songDetails.currentArtistName);		
		UIALogger.logDebug("Song name: " + songDetails.currentSongName);
		UIALogger.logDebug("Album name: " + songDetails.currentAlbumName);
		
		if (UIATarget.localTarget().model() != 'iPad') {
		    var indexElement = this.mainWindow().elements().firstWithPredicate("name contains ' of '");
            
		    if (!indexElement.isValid()) throw new Error("Could not find the index element");
		    var indexArr = indexElement.name().split(" of ");
		    songDetails.currentSongIndex = parseInt(indexArr[0]);
		    UIALogger.logDebug("Song index: " + songDetails.currentSongIndex);
		    songDetails.totalNumberOfSongs = parseInt(indexArr[1]);
		    UIALogger.logDebug("Total number: " + songDetails.totalNumberOfSongs);
		}
				
		var timeElapsedElement = this.audioControlWithName("Track position");
		if (!timeElapsedElement.isValid()) throw new Error("Could not determine the elapsed time");
		
		timeElapsedElement.logElement();
		var trackPositionInfo = UIAUtility.processTrackPositionValue(timeElapsedElement.value());
		songDetails.timeElapsed = trackPositionInfo.elapsedTimeInfo.seconds + 60*trackPositionInfo.elapsedTimeInfo.minutes + 3600*trackPositionInfo.elapsedTimeInfo.hours;
		UIALogger.logDebug("Time elapsed: " + songDetails.timeElapsed);
		
		songDetails.totalTime = trackPositionInfo.totalTimeInfo.seconds + 60*trackPositionInfo.totalTimeInfo.minutes + 3600*trackPositionInfo.totalTimeInfo.hours;
		UIALogger.logDebug("Total time: " + songDetails.totalTime);

		
		songDetails.timeRemaining = songDetails.totalTime - songDetails.timeElapsed;
		UIALogger.logDebug("Time remaining: " + songDetails.timeRemaining);
		
		return songDetails;
	}
	
	//----------------------------------------------------------------------------------------
	//	Function: getFirstSongInPlaylist
	//		Returns the first song element in the list that is not "Shuffle."
	//		Assumes that the playlist is being displayed.
	//
	//	Parameters: 
	//		None
	//
	//	Returns: 
	//		The first song element. 
	//----------------------------------------------------------------------------------------
	audio.getFirstSongInPlaylist = function getFirstSongInPlaylist() {	
		return this.songsTable().cells().firstWithPredicate("name != 'Shuffle' and name != 'Edit'");
	}
	
	//----------------------------------------------------------------------------------------
	//	Function: numOfSongsInPlaylist 
	//		Returns the number of songs in the playlist currently selected.
	//		Assumes a playlist is being displayed.
	//
	//	Parameters: 
	//		None
	//	
	//	Returns: the number of songs in the playlist. Throws error, if it cannot determine the
	//		number.
	//
	//	Throws: 
	//		Error	
	//----------------------------------------------------------------------------------------
	audio.numOfSongsInPlaylist = function numOfSongsInPlaylist() {
		UIALogger.logDebug("Getting the number of songs in playlist");
		var playlistTable = this.songsTable();
		if (!playlistTable.isValid()) {
			throw new Error("Did not find the playlist table");
		}
				
		return playlistTable.cells().withPredicate("name != 'Shuffle' and name != 'Edit' and name != 'Clear' and name != 'Delete' and name != 'Done'").length;
	}
	
	audio.pauseSong = function pauseSong() {
		this.audioControlWithName("Pause").tap();
		return true;
	}
	
	//----------------------------------------------------------------------------------------
	//	Function: pickAndPlaySong
	//		Goes to the Songs list, and plays a random song
	//
	//	Parameters: 
	//		None
	//
	//	Returns: 
	//		The name of the song that was played. 
	//
	//	Throws: 
	//		Error
	//----------------------------------------------------------------------------------------
	audio.pickAndPlaySong = function pickAndPlaySong(songName, songPath) {
		
		this.getToSongsView();
			
		if (songPath && songPath.length > 0) this.navigateSongPath(songPath);
		UIATarget.localTarget().delay(1);
		
		var songTable = this.songsTable();
		if (!songTable.isValid()) throw new Error("Did not find a songs table");
		
		if (!songName) {
			UIALogger.logMessage("Selecting random song");
			var randomSongElement = UIAUtility.randomFromArray(songTable.cells());
			if (!randomSongElement) throw new Error("No songs found");
			songName = randomSongElement.name();
			UIALogger.logMessage("Playing '" + songName + "'");
			randomSongElement.scrollToVisible();
			randomSongElement.tap();
		} else {
			UIALogger.logMessage("Selecting '" + songName + "'");
			var songElement = songTable.scrollToElementWithPredicate("name matches '.*" + UIAUtility.escapeString(songName) + ".*'");
			songElement.tap();
		}
		
		if (!this.mainWindow().images().firstWithPredicate("name contains 'NowPlaying'")) 
			UIALogger.logWarning("'Now Playing' view did not come up");
		
		return songName;
	}

	//----------------------------------------------------------------------------------------
	//	Function: flipThroughCoverFlow 
	//		Goes to the coverflow mode, and then flips through the albums
	//
	//	Parameters: 
	//		actions (array) - optional - a sequence of audio.flipActions.FORWARD or 
	//			audio.flipActions.BACK to specify how to navigate through in the coverflow mode. 
	//			for e.g. [audio.flipActions.FORWARD, audio.flipActions.FORWARD, audio.flipActions.BACK]
	//			will go forward two times, and then go back once. If no value is specified, random 
	//			actions are performed (with a smaller probability of switching directions)
	//
	//	Returns: 
	//		None
	//
	//	Throws: 
	//		Error
	//----------------------------------------------------------------------------------------
	audio.flipThroughCoverFlow = function flipThroughCoverFlow(actions) {		
		UIALogger.logDebug("Switching to the coverflow mode");
		UIATarget.localTarget().setDeviceOrientation(UIA_DEVICE_ORIENTATION_LANDSCAPELEFT);
		UIATarget.localTarget().delay(1); //give some time for animation
		
		if (!audio.mainWindow().buttons()["Track list"].isVisible()) {
			throw new Error("Could not switch to the coverflow mode");
		}

		var currentPosition = 0; //stores relative index position from where we started
		var trackElement = audio.mainWindow().elements().firstWithPredicate("name contains ',' and isVisible == 1");
		if (!trackElement.isValid()) throw new Error("Could not find the track element");
		var trackElementNameAtCurrentPosition = trackElement.name();
		var trackInfo = new Array(); //will store the album name at position n for verification
		var getOppositeDirection = function (direction) { 
			if (direction == audio.flipActions.FORWARD) 
				return audio.flipActions.BACK;
			else 
				return audio.flipActions.FORWARD;
		};
		if (!actions) actions = new Array();
		var randomize = (actions.length == 0);
		var numberOfActions = (randomize) ? system.randomInteger(1,20) : actions.length;
		
		UIALogger.logDebug("No of actions = " + numberOfActions);
		for (var i=0; i<numberOfActions; i++) {
			if (randomize) {
				//get the preferred action -- should prefer to stay in the same direction (not applicable when i == 0 and hence the check for actions[i-1])
				var preferredAction = (actions[i-1]) ? actions[i-1] : UIAUtility.randomFromArray([audio.flipActions.FORWARD, audio.flipActions.BACK]);
				actions[i] = (system.randomInteger(0,100) > 25) ? preferredAction : getOppositeDirection(preferredAction);
			}
			
			var nextPosition = (actions[i] == audio.flipActions.FORWARD) ? currentPosition+1 : currentPosition-1;
			if (randomize && trackInfo[nextPosition] == "end") { 
				UIALogger.logDebug("Position " + nextPosition + " detected as the end. Reversing direction from " + actions[i]);
				actions[i] = getOppositeDirection(actions[i]); 
				nextPosition = (actions[i] == audio.flipActions.FORWARD) ? currentPosition+1 : currentPosition-1;
			}
			
			var action = actions[i];
			UIALogger.logDebug("Executing action " + (i+1) + " : " + action);
			var dragOptions = new Object();
			dragOptions.duration = 0.8;
			if (action == audio.flipActions.FORWARD) {
				dragOptions.startOffset = {x:0.7, y:0.5};
				dragOptions.endOffset = {x:0.3, y:0.5};
			} else {
				dragOptions.startOffset = {x:0.3, y:0.5};
				dragOptions.endOffset = {x:0.7, y:0.5};
			}

			trackElement.dragInsideWithOptions(dragOptions);
			if (!trackElement.withPredicate("name != '" + trackElementNameAtCurrentPosition.replace("'","\\'") + "'").isValid()) {
				//only throw an error if the action was not randomly generated which does not guarantee not bumping at the end
				if (!randomize) throw new Error("The track value did not change even after flipping " + action); 
				UIALogger.logError("Track value did not change from " + trackElementNameAtCurrentPosition);
				trackInfo[nextPosition] = "end";
				UIALogger.logDebug("Marking position " + nextPosition + " as 'end'");
			} else {
				currentPosition = nextPosition;
			}

			trackElement.logElement();
			trackElementNameAtCurrentPosition = trackElement.name();
			
			if (trackInfo[currentPosition]) {
				//element info found -- check if it is expected
				if (trackInfo[currentPosition] != trackElementNameAtCurrentPosition) { 
					UIALogger.logDebug("Expected name=" + trackInfo[currentPosition]);
					UIALogger.logDebug("Actual name=" + trackElementNameAtCurrentPosition);
					UIALogger.logDebug("Position=" + currentPosition);
					throw new Error("name mismatch at position " + currentPosition);
				}
			} else {
				UIALogger.logDebug("Setting song at position " + currentPosition + " to " + trackElementNameAtCurrentPosition);
				trackInfo[currentPosition] = trackElementNameAtCurrentPosition;
			}
			
			UIATarget.localTarget().delay(1);
			
		}
		
	}
	
	//----------------------------------------------------------------------------------------
	//	Function: getToSongsView 
	//		Goes to the songs list
	//
	//	Parameters: 
	//		None
	//
	//	Returns: 
	//		None
	//
	//	Throws: 
	//		Error
	//----------------------------------------------------------------------------------------
	audio.getToSongsView = function getToSongsView() {
		
		UIALogger.logMessage("Going to songs view...")
		this.launchIfNotActive();
		
		//need to be portrait orientation to go to the songs view
		if (UIATarget.localTarget().model() != 'iPad') UIATarget.localTarget().setDeviceOrientation(UIA_DEVICE_ORIENTATION_PORTRAIT);
		
		var conversionMessage = "This may take a few minutes"; //Handles uncertainty between This may take a while or few minutes.
		
		UIALogger.logMessage("Checking for the conversion message");
		var convertingElement = this.mainWindow().elements().firstWithPredicate("name contains '" + conversionMessage + "'");
		if (convertingElement.isValid()) {
			UIALogger.logMessage("Waiting for conversion to finish");
			UIATarget.localTarget().pushTimeout(60);
			convertingElement.waitForInvalid();
			UIATarget.localTarget().popTimeout();
		}

		if (!this.areSongsOnDevice()) {
			throw new Error("No songs on the device -- please add content.");
		}
		
		UIATarget.localTarget().pushTimeout(0);
		var backButton = this.audioControlWithName("Back");
		UIATarget.localTarget().popTimeout();
		if (backButton.isValid()) {
		    UIALogger.logMessage("Back button found. Tapping it.");
		    UIATarget.localTarget().delay(1); //a second for animation
		    backButton.tap();
		}
		
		var bottomBar = this.bottomBar();
		if (!bottomBar.isVisible()) {
			UIALogger.logMessage("The bottom bar is not present.");
			
			if (this.isInVideoView()) {
				// it's the audio/video ipod app and we're watching a movie.
				UIALogger.logMessage("In movie view. Clicking done button.");
				audio.videoViewElementWithPredicate("ANY elements.name == 'Done'").elements()["Done"].tap();
			}
			
			var actionSheet = this.actionSheet();
			if (actionSheet.isValid()) {
				UIALogger.logMessage("Action sheet is up. Canceling it");
				actionSheet.buttons()["Cancel"].tap();
			}
			
		} else {
			//bottom bar is present, but make sure we're out of edit views
			UIATarget.localTarget().pushTimeout(0);
			var doneButton = this.topBarElementWithName("Done");
			UIATarget.localTarget().popTimeout();
			if (doneButton.isValid()) {
				UIALogger.logDebug("In edit playlist view. Tapping 'Done'");
				doneButton.tap();
				UIATarget.localTarget().delay(1);
			}
			
			UIATarget.localTarget().pushTimeout(1);
			if (UIATarget.localTarget().model() == 'iPad')
				var doneEditingButton = this.mainWindow().buttons()["Done"];
			else
				var doneEditingButton = this.mainWindow().tableViews()[0].scrollToElementWithName("Done");
			UIATarget.localTarget().popTimeout();
			if (doneEditingButton.isValid()) {
				UIALogger.logDebug("In edit playlist view. Tapping 'Done'");
				doneEditingButton.tap();
			}
            
			//check is a playlist is selected
			UIATarget.localTarget().pushTimeout(0);
			var playlistBackButton = this.mainWindow().buttons()["Playlists"];
			UIATarget.localTarget().popTimeout();
			if (playlistBackButton.isValid()) {
			    UIALogger.logDebug("Going back to the main playlist view");
			    playlistBackButton.tap();
			}
		}
		
		/*
		if (UIATarget.localTarget().model() == 'iPad') {
			//tap the music button
			var musicTableCell = this.mainWindow().tableViews()[0].scrollToElementWithName("Music");
			if (musicTableCell.value() != 1) musicTableCell.withPredicate("isVisible == 1").tap();
			if (!musicTableCell.withValueForKey(1,"value").isValid())
				throw new Error("Tapped 'Music' but the value did not change to 1");
		}
		*/
		
		bottomBar = this.bottomBar();
		//cheking again to see if the tab bar is visible
		if (!bottomBar.isVisible()) {
			//this.mainWindow().logElementTree();
			throw new Error("The bottom bar is still not present.");
		}
		
		var songsButton = this.bottomBarButtonWithName("Songs").withValueForKey(1, "isVisible");
		UIATarget.localTarget().delay(1); //a second for animation
		songsButton.tap();
		if (!songsButton.withValueForKey(1,"value").isValid())
			UIALogger.logWarning("Tapped Songs button, but the selected button did not change");

		if (UIATarget.localTarget().model() != 'iPad') {
			if (!this.navigationBar().withName("Songs").isValid()) {
				//this.mainWindow().logElementTree();
				throw new Error("The songs nav bar did not show up");
			}	
		}
	}
	
	//----------------------------------------------------------------------------------------
	//	Function: addSongsToPlaylist 
	//		Selects the specified songs to be added to the playlist. Assumes
	//		that the app is in the add songs view ('+' next to to the songs)
	//
	//	Parameters:
	//		songs (array of string|array) - optional - the name of the songs that need to be
	//			added. The array element can be one of two types:
	//				1. a string for the name of the song
	//				2. an array of strings for the path to the song
	//					e.g. ["Artists", "Beatles", "Yesterday"]
	//			If no value is specified, random songs are selected.
	//
	//	Returns: 
	//		an array containing the name of the songs that were added
	//----------------------------------------------------------------------------------------
	audio.addSongsToPlaylist = function addSongsToPlaylist(songs) {
		
		if (!this.topBarElementWithPredicate("name contains 'Add songs'").isValid())
			throw new Error("'Add songs' nav bar is not up");
		
		var songNames = new Array();
		var songTable = this.mainWindow().tableViews().firstWithPredicate("isVisible == 1");
		if (!songTable.isValid()) {
			throw new Error("Could not find the songs table");
		}

		if (songs == null) {
			UIALogger.logDebug("Go to 'Songs' list first");
			this.navigateSongPath(["Songs"]); //otherwise the table cell names will never match with what is added
			
			UIALogger.logDebug("Songs not specified. Will add random songs");
			var totalNoOfSongs = this.numOfSongsInPlaylist();
			if (totalNoOfSongs == 0) {
				throw new Error("No songs in the songs list");
			}
			var noOfSongs = system.randomInteger(1,totalNoOfSongs);
			UIALogger.logDebug("Total no. of songs=" + totalNoOfSongs + " No. of songs to be added to the playlist=" + noOfSongs);
			
			var songCells = songTable.cells();
			if (songCells.length == 0) throw new Error("No media cells found");
			
			for (var i=0; i<noOfSongs; i++) {
				UIALogger.logDebug("Adding " + (i+1) + "th song");
				
				var songToAdd = UIAUtility.randomFromArray(this.mainWindow().tableViews().firstWithPredicate("isVisible == 1").cells());
				songToAdd.scrollToVisible();
				
				UIALogger.logDebug("Add '" + songToAdd.name() + "' to the playlist");
				//Don't add 'Add All Songs' to the songs list
				if (songToAdd.name().indexOf("Add All") < 0) songNames.push(songToAdd.name());
				
				songToAdd.tap();
				UIATarget.localTarget().delay(1);
			}
			return songNames;
		} else {
			//songs are specified
			for (var i=0; i<songs.length; i++) {
				var song = songs[i];
				var songName;
				if (typeof song == 'object') {
					//this is an path array, the song name should be the last element
					songName = song[song.length-1];
				} else {
					songName = song;
					songs[i] = ["Songs", song]; //make songs[i] an array so that it can be passed to navigateMediaCells
				}
				
				//Don't add 'Add All Songs' to the songs list
				if (songName.indexOf("Add All") < 0) songNames.push(songName);
				
				UIALogger.logDebug("Set the " + (i+1) + "th song to " + songName);
				UIALogger.logDebug("Navigating to " + songName);
				
				this.navigateSongPath(songs[i]);
				UIATarget.localTarget().delay(1);
			}	
		}
		
		this.navigateSongPath(["Songs"]); //leave the view on a top-level page
		
		return songNames;
	}
	
	//----------------------------------------------------------------------------------------
	//	Function: deleteSongsInPlaylist
	//		Deletes the specified songs from the playlist. Assumes
	//		that the app is in the edit view ('-' next to to the songs)
	//
	//	Parameters:
	//		songs (array of strings) - optional - the name of the songs that need to be
	//			deleted. If no value is specified, random songs are selected.
	//
	//	Returns: 
	//		An array containing the name of the songs that were deleted.
	//----------------------------------------------------------------------------------------
	audio.deleteSongsInPlaylist = function deleteSongsInPlaylist(songs) {
		var noOfDeletedSongs;
		var deletedSongs = new Array();

		if (songs != null) {
			noOfDeletedSongs = songs.length;
		} else {
			var totalNoOfSongs = this.numOfSongsInPlaylist();
			if (totalNoOfSongs == 0) {
				throw new Error("No songs in the songs list");
			}
			noOfDeletedSongs = system.randomInteger(1,totalNoOfSongs);
			UIALogger.logDebug("Total no. of songs=" + totalNoOfSongs + " No. of songs to be deleted =" + noOfDeletedSongs);
		}

		var songCells = this.songsTable().cells().withPredicate("name != 'Shuffle' and name != 'Done'");
		
		for (var i=0; i<noOfDeletedSongs; i++) {
			UIALogger.logDebug("Deleting " + (i+1) + "th song");
			var songCell;
			
			if (songs != null) {
				//this is for the case where the songs are specified
				songCell = songCells.firstWithPredicate("name matches '.*" + UIAUtility.escapeString(songs[i]) + ".*'");
			} else {
				//this is for the random song selection
				songCell = UIAUtility.randomFromArray(songCells.withPredicate("checkIsValid == 1"));
			}
			if (!songCell.isValid()) throw new Error("Song cell not found");
	
			songCell.scrollToVisible();
			UIALogger.logDebug("Scrolled to '" + songCell.name() + "'");
			
			UIALogger.logDebug("Deleting '" + songCell.name() + "' in the playlist");
			deletedSongs.push(songCell.name());
			
			this.deleteTableCell(songCell);
		}
		
		return deletedSongs;
	}
	
	//----------------------------------------------------------------------------------------
	//	Function: createPlaylist
	//		Creates a new playlist
	//
	//	Parameters:
	//		playlistName (string) - the name of the new playlist
	//		songs (array of string|array) - optional - the name of the songs that need to be
	//			added. The array element can be one of two types:
	//				1. a string for the name of the song
	//				2. an array of strings for the path to the song
	//					e.g. ["Artists", "Beatles", "Yesterday"]
	//			If no value is specified, random songs are selected.
	//		shouldVerify (boolean) - optional - if set to true, verifies if the playlist was created
	//			successfully. It set to false , by default.
	//	
	//	Returns: 
	//		None
	//
	//	Throws: 
	//		Error
	//----------------------------------------------------------------------------------------
	audio.createPlaylist = function createPlaylist(playlistName, songs, shouldVerify) {		
	
		UIALogger.logDebug("Creating playlist with name: " + playlistName + ".");
		
        this.bottomBarButtonWithName("Playlists").tap();
        if (!this.topBarElementWithName("Playlists").isValid())
            throw new Error("Tapped the Playlists tab bar button, but the nav bar title did not change");
        
		var addPlaylistButton;
		if (UIATarget.localTarget().model() == 'iPad') {
			addPlaylistButton = this.mainWindow().buttons()["New"];
		} else {
			addPlaylistButton = this.mainWindow().tableViews()[0].scrollToElementWithPredicate("name contains 'Add Playlist'");
		}
		
		UIATarget.disableOnAlert = 1;
		addPlaylistButton.tap();
		var newPlaylistAlert = this.alert();
		UIATarget.localTarget().delay(3); //let the onAlert realize it should not dismiss it
		UIATarget.disableOnAlert = 0;
		
		if (!newPlaylistAlert.isValid()) throw new Error("Did not get an alert after tapping Add Playlist");
		this.enterTextInTextField(newPlaylistAlert.textFields()[0], playlistName);
		newPlaylistAlert.buttons()["Save"].tap();
		
		if (newPlaylistAlert.waitForInvalid()) UIALogger.logWarning("New playlist alert did not go away");
		
		var songNames = this.addSongsToPlaylist(songs);
		UIATarget.localTarget().delay(1);
		
		this.topBarElementWithName("Done").tap();
		UIATarget.localTarget().delay(1);
		
		if (UIATarget.localTarget().model() == 'iPad') {
			this.topBarElementWithPredicate("name == 'Done' and isVisible == 1").tap();
		}
		
		if (!this.topBarElementWithPredicate("name contains '" + playlistName + "'").isValid()) 
			throw new Error("Tapped Done, but the playlists nav bar did not show up");
		UIATarget.localTarget().delay(1);
		
		if (shouldVerify) {
			UIALogger.logDebug("Verifying the playlist was created");
			this.selectPlaylist(playlistName);
			var playlistTable = this.songsTable();
			for (var i=0; i<songNames.length; i++) {
				UIALogger.logDebug("Verifying the " + (i+1) + "th song '" + songNames[i] + "' was added");
				var songElement = playlistTable.cells().firstWithPredicate("name matches '.*" + UIAUtility.escapeString(songNames[i]) + ".*'");
				if (!songElement.isValid()) {
					throw new Error("Couldn't find '" + songNames[i] + "' in the playlist");
				}
			}
			UIALogger.logDebug("Verified the songs were added to the playlist");
		}
	}
	
	//----------------------------------------------------------------------------------------
	//	Function: clearPlaylist
	//		Clears the playlist, by tapping the 'Clear' button. N/A for Wildcat.
	//
	//	Parameters:
	//		playlistName (string) - the name of the playlist that needs to be cleared
	//	
	//	Returns: 
	//		None
	//
	//	Throws: 
	//		Error
	//----------------------------------------------------------------------------------------
	audio.clearPlaylist = function clearPlaylist(playlistName) {
		
		UIALogger.logDebug("Clearing the playlist '" + playlistName + "'");
		this.selectPlaylist(playlistName);
	
		UIALogger.logDebug("Tapping the 'Clear' button");
		var playlistTable = this.mainWindow().tableViews()[0];
		if (!playlistTable.isValid()) throw new Error("Could not find the playlist table");
		this.cellsContainingElementsWithPredicate(playlistTable, "name contains 'Clear'")[0].buttons()["Clear"].tap();
	
		var actionSheet = this.actionSheet();
		if (!actionSheet.isValid()) throw new Error("Tapped 'Clear' but the action sheet did not come up");
		UIATarget.localTarget().delay(1);
		actionSheet.buttons()["Clear Playlist"].tap();
		if (!actionSheet.waitForInvalid()) throw new Error("'Clear Playlist' action sheet did not go away");
		
		UIALogger.logDebug("Verifying that the songs were deleted");
		var numOfSongs = this.numOfSongsInPlaylist();
		if (numOfSongs != 0) {
			UIALogger.logError("The number of songs after clearing is " + numOfSongs);
			throw new Error("The number of songs after clearing is not 0");
		}
	}
	
	//----------------------------------------------------------------------------------------
	//	Function: deletePlaylist
	//		Deletes the playlist
	//
	//	Parameters:
	//		playlistName (string) - the name of the playlist that needs to be deleted
	//
	//	Returns: 
	//		None
	//
	//	Throws: 
	//		Error
	//----------------------------------------------------------------------------------------
	audio.deletePlaylist = function deletePlaylist(playlistName) {
		
		this.selectPlaylist(playlistName);
	
		if (UIATarget.localTarget().model() == 'iPad') {
			this.navigationBar().buttons()["Edit"].tap();
			this.deleteTableCell(this.mainWindow().tableViews()[0].cells().firstWithPredicate("name contains '" + playlistName + "'"));
		} else {
			UIALogger.logDebug("Tapping the 'Delete' button");
			var playlistTable = this.mainWindow().tableViews()[0];
			if (!playlistTable.isValid()) throw new Error("Could not find the playlist table");
			this.cellsContainingElementsWithPredicate(playlistTable, "name contains 'Delete'")[0].buttons()["Delete"].tap();
			
			var actionSheet = this.actionSheet();
			if (!actionSheet.isValid()) throw new Error("Tapped 'Delete' but the action sheet did not come up");
			UIATarget.localTarget().delay(1);
			actionSheet.buttons()["Delete Playlist"].tap();
			if (!actionSheet.waitForInvalid()) throw new Error("'Delete Playlist' action sheet did not go away");
		}
				
		UIALogger.logDebug("Verifying that the playlist '"+ playlistName + "' was deleted");
		try {
			this.selectPlaylist(playlistName);
		} catch(e) {
			UIALogger.logError(e.message);
			UIALogger.logDebug("Playlist seems to have been deleted");
			return ;
		}
		throw new Error("Playlist was not deleted");
	}
	
    audio._playlistElements = function _playlistElements() {
        if (UIATarget.localTarget().model() == 'iPad') {
            var playlistButtons = [];
            var playlistCells = this.mainWindow().tableViews()[0].cells();
            for (var i=0; i<playlistCells.length; i++) 
                playlistButtons = playlistButtons.concat(playlistCells[i].buttons().toArray());
            return playlistButtons;
        } else {
            return this.mainWindow().tableViews()[0].cells().toArray();
        }
    }
    
	//----------------------------------------------------------------------------------------
	//	Function: selectPlaylist
	//		Selects the specified playlist, and plays the first song in the playlist.
	//		
	//
	//	Parameters: 
	//		playlistName (string) - optional - the name of the playlist the needs to be 
	//			selected. If no value is specified, a random playlist is selected.
	//
	//	Returns: 
	//		The name of the playlist that was selected
	//
	//	Throws: 
	//		Error
	//----------------------------------------------------------------------------------------
	audio.selectPlaylist = function selectPlaylist(playlistName) {
		
		var playlistsToAvoid = ["Music", "Podcasts", "On-The-Go", "Genius", "Add Playlist"]; //a partial match is used

		UIALogger.logMessage("Tapping playlists to get to the playlist view");
		this.bottomBarButtonWithName("Playlists").tap();
		UIATarget.localTarget().delay(1);
		
		if (!this.topBarElementWithName("Playlists").isValid())
		    throw new Error("Tapped 'Playlists' in the tab bar, but the 'Playlists' nav bar did not show up");
		
		//tap the Playlist tab button once more to make sure we are at the top most level
		this.bottomBarButtonWithName("Playlists").tap();
		
		var playlistTable = this.mainWindow().tableViews()[0];
		if (!playlistTable.isValid()) throw new Error("Could not find the playlist table");
		
		var playlistElements = this._playlistElements();
		if (!playlistName || playlistName == "") {
			UIALogger.logMessage("Need to find a random playlist to play");
			var eligiblePlaylistElements = new Array();
			
			for (var i = 0; i < playlistElements.length; i++) {
				var playlistName = playlistElements[i].name();
				var matched = false;
				for (var j = 0; j < playlistsToAvoid.length; j++) {
					if (playlistName.match(playlistsToAvoid[j]))
						matched = true;
				}
				if (!matched) {
					UIALogger.logMessage("Adding " + playlistName + " to array");
					eligiblePlaylistElements.push(playlistElements[i]);
				}
			}
			
			if (eligiblePlaylistElements.length == 0) {
				throw new Error("No matching playlists found");
			}
			var playlistElement = UIAUtility.randomFromArray(eligiblePlaylistElements);
			UIALogger.logMessage("Selecting '" + playlistElement.name() + "'");
			playlistElement.scrollToVisible();
			playlistName = playlistElement.name(); //for random playlist
		} else {
			var playlistElement;
			UIALogger.logDebug("Selecting playlist '" + playlistName + "'"); 
			for (var i=0; i < playlistElements.length; i++) {
			    var aPlaylistName = playlistElements[i].name();
			    if (aPlaylistName && aPlaylistName.indexOf(playlistName) == 0) {
			        playlistElement = playlistElements[i];
			        break;
			    }
			}
			if (!playlistElement) throw new Error("Did not find a playlist with name '" + playlistName + "'");
			playlistElement.scrollToVisible();
		}
		if (!playlistElement.isVisible()) {
			throw new Error("Could not scroll to the playlist to play");
		}
		playlistElement.tap();
		
		if (!this.topBarElementWithPredicate("name beginswith '" + playlistName + "'").isValid())
			UIALogger.logWarning("Tapped the playlist element, but it did not select it");
		return playlistName;
	}
	
	//----------------------------------------------------------------------------------------
	//	Function: navigateSongPath
	//		Navigates to the specified path in audio player. 
	//
	//	Assumes:
	//		This function navigates from the state it is called. This means that the first 
	//		element in the path should be visible, or become visible after the scroll (or after 
	//		returning to the top most level by tapping the 'Back' button repeatedly, if 
	//		returnToTopLevel is set to true). 
	//
	//	Parameters: 
	//		itemPath (array) - the elements of the array represent steps in the path. For instance, 
	//			the array ["Artists","The Beatles","All Albums"] will tap the Artists bottom bar
	//			button, select the "The Beatles" table cell, and then select "All Albums". 
	//		returnToTopLevel (bool) - optional - If set to true, the function will navigate to the top 
	//			most level by tapping the 'Back' button repeatedly. It is set to false, by default.
	//
	//	Returns: 
	//		None
	//
	//	Throws: 
	//		Error
	//----------------------------------------------------------------------------------------
	audio.navigateSongPath = function navigateSongPath(itemPath, returnToTopLevel) {
		
		var availableTabBarButtons = ["Playlists", "Artists", "Songs", "Albums", "Genres", "Videos", 
									  "Composers", "Audiobooks", "Compilations", "Podcasts", "iTunes U"];
		var currentIndex = 0;
		
		if (itemPath == null || itemPath.length == 0) {
			throw new Error("No path specified");
		}
		
		//checking if the first one is a bottom button (Artists, Songs, etc.)
		var pathElementName = itemPath[0];
		if (typeof pathElementName  == "string" && availableTabBarButtons.indexOf(pathElementName) > -1) {
			currentIndex++;
			UIALogger.logMessage("First argument '" + pathElementName + "' is a bottom bar button.");
			var bottomBar = this.bottomBar();
			if (bottomBar.isVisible()) {
				UIALogger.logMessage("Bottom bar is present. Looking for '" + pathElementName + "' in the bottom bar");
				try {
					this.bottomBarButtonWithName(pathElementName).tap();
				} catch(e) {
					UIALogger.logMessage("Did not find the '" + pathElementName + "' in the bottom bar. Checking if there is a 'More' button");
					this.bottomBarButtonWithName("More").tap();
					UIATarget.localTarget().delay(1);
					this.mainWindow().tableViews()[0].scrollToElementWithName(pathElementName).tap();
				}
			} else {
				UIALogger.logMessage("Did not find a bottom bar. Expect to be in the video application of an iPod touch");
			}
		}
		
		if (returnToTopLevel) {
			UIALogger.logMessage("Going back to the top level");
			for (var i=0; i<5; i++) {
				try {
					this.navigationBar().leftButton().tap();
					UIATarget.localTarget().delay(1);
				} catch(e) {
					UIALogger.logMessage("No back button found. Assume that reached the top level");
					break;
				}
			}
		}
		
		for (; currentIndex<itemPath.length; currentIndex++) {
			var navBarLabel = this.navigationBar().withPredicate("name != null").name();
			UIALogger.logMessage("The nav bar label is '" + navBarLabel + "'");
			
			//TODO: we should account for grid cells for iPad
			//TODO: we should re-use this regular expression for exact match of the name, probably wrap it in a function like songCellWithName or something
			var tableElement = this.songsTable().scrollToElementWithPredicate("name matches '(.*(,|\\\\.) )*" + UIAUtility.escapeString(itemPath[currentIndex]) + "((,|\\\\.).*)*'");
			if (!tableElement.isValid()) throw new Error("Could not find the table cell: " + itemPath[currentIndex]);
			tableElement.tap();
			
			this.navigationBar().withPredicate("name != '" + navBarLabel + "'");
		}
	}
		
	//----------------------------------------------------------------------------------------
	//	Function: controlSongPlaybackState
	//		Taps "Play" or "Pause", depending on the specified parameter. Assumes that the 
	//		play/pause controls are being displayed. 
	//
	//	Parameters: 
	//		desiredState (string) - audio.playbackActions.PLAY if the media needs to be 
	//			played, and audio.playbackActions.PAUSE if it needs to be paused. 
	//		time (int) - optional - this parameter is mainly used for verification. If this 
	//			parameter is specified, the function will sleep for the specified time, and 
	//			verify the scrubber state after this time interval.  
	//
	//	Returns: 
	//		None
	//
	//	Throws: 
	//		Error
	//----------------------------------------------------------------------------------------
	audio.controlSongPlaybackState = function controlSongPlaybackState(desiredState, time) {
		if (desiredState != audio.playbackActions.PLAY && desiredState != audio.playbackActions.PAUSE)
			throw new Error("Invalid desiredState: " + desiredState);
		var details = audio.getSongDetails();
		
		UIALogger.logMessage("Going to '" + desiredState + "' the media for " + time + " seconds.");
		try {
			var desiredStateButton = this.audioControlWithName(desiredState);
			desiredStateButton.tap();
			if (!desiredStateButton.withPredicate("name != '" + desiredState + "'").isValid())
				UIALogger.logWarning("The button name did change from '" + desiredState + "'");
			UIATarget.localTarget().delay(2); //let things update themselves
			
		} catch(e) {
			UIALogger.logMessage("Could not find the element for " + desiredState  + ". Perhaps, the action is already selected");
		}
		
		var slider = this.audioControlWithName("Track position");
		var currentValue = slider.value();
		
		if (time != null) {
			UIATarget.localTarget().delay(time);
			
			if (!slider.checkIsValid()) { 
				//check if the song has ended
				UIALogger.logMessage("Time remaining=" + details.timeRemaining + " Time to play/pause=" + time);
				if (details.timeRemaining <= time && desiredState == audio.playbackActions.PLAY) {
					UIALogger.logMessage("The song finished before performing the action");
					return ;
				}
				throw new Error("Could not find the slider");
			}
			
			var oldValue = currentValue;
			currentValue = slider.value();
			
			UIALogger.logMessage("The current slider value is " + currentValue);
			UIALogger.logMessage("The old slider value was " + oldValue);
			var hasProgressed = (oldValue != currentValue); 
			if (desiredState == audio.playbackActions.PLAY && !hasProgressed) {
				throw new Error("There was no progress even though the Play button was tapped");
			} 
			if (desiredState == audio.playbackActions.PAUSE && hasProgressed) {
				throw new Error("There was progress even though the Pause button was tapped");
			}
		}
	}
	
	//----------------------------------------------------------------------------------------
	//	Function: scrubSong
	//		Scrubs the song progress slider to the specificed level. Assumes the 
	//		song to be scrubbed is playing.
	//
	//	Parameters: 
	//		desiredLevel (real) - a floating number between 0 and 1 representing the progress 
	//			that is required.
	//
	//	Returns: 
	//		None
	//----------------------------------------------------------------------------------------
	audio.scrubSong = function scrubSong(desiredLevel) {
		var songDetails = this.getSongDetails();
		
		var scrubberElement = this.audioControlWithName("Track position");
		if (!scrubberElement.isValid()) {
			throw new Error ("Could not find the scrubber element");
		}
		
		UIALogger.logDebug("Checking the playback state of the device");
		var isPaused = (this.audioControlWithName("Play").isValid());
		if (isPaused) 
			UIALogger.logDebug("The song appears to be paused");
		else 
			UIALogger.logDebug("The song appears to be playing");
		
		var currentLevel = scrubberElement.value();
		var error = 0.05;
		UIALogger.logDebug("Value of the slider before dragging it is " + currentLevel);
		var currentLevelInFloat = songDetails.timeElapsed/songDetails.totalTime;
		UIALogger.logDebug("Progress in float value is " + currentLevelInFloat);
		if (Math.abs(currentLevelInFloat - desiredLevel) < error) { 
			UIALogger.logDebug("The current progress level and the desired progress level are the same");
			return ;
		}
		
		scrubberElement.dragToValue(desiredLevel);
		UIATarget.localTarget().delay(1);
		
		if (isPaused) {
			//Perform verification only if the song was paused -- too much uncertainty when the song is playing
			if (!scrubberElement.isValid()) {
				throw new Error("Could not find the scrubber element after dragging the slider");
			}
			
			UIALogger.logDebug("Verifying the value of the slider changed");
			UIALogger.logDebug("Value of the slider is: " + scrubberElement.value());
			if (currentLevel == scrubberElement.value()) {
				throw new Error("The slider value did not change after scrubbing");
			}
			currentLevel = scrubberElement.value();
			
			UIALogger.logDebug("Verifying that the playback state did not change after scrubbing");
			var oldState = isPaused;
			isPaused = (this.audioControlWithName("Play").isValid());
			if (oldState != isPaused) { 
				throw new Error("Playback state changed after scrubbing");
			}
		}
	}
	//----------------------------------------------------------------------------------------
	//	Function: getFirstVideoFromVideoList
	//		Gets the first video in the list of videos. Assumes that the video list is being 
	//		displayed.
	//
	//	Parameters: 
	//		None
	//
	//	Returns: 
	//		the name of the first video in the list. 
	//----------------------------------------------------------------------------------------
	video.getFirstVideoFromVideoList = function getFirstVideoFromVideoList() {
		return this.mainWindow().tableViews()[0].cells()[0];
	}
	
	//----------------------------------------------------------------------------------------
	//	Function: isInVideoSummaryView
	//		Returns true if the video summary view is currently being displayed (the video 
	//		summary view is the view that comes up after tapping a video grid cell button to 
	//		select a video on an iPad). 
	//
	//	Parameters: 
	//		None
	//
	//	Returns: 
	//		true if the video summary view is currently being displayed; false otherwise. 
	//----------------------------------------------------------------------------------------
	video.isInVideoSummaryView = function isInVideoSummaryView() {
		return (UIATarget.localTarget().model() == 'iPad' && video.navigationBar().leftButton().withPredicate("name != 'Store'").isValid());
	}
	
	//----------------------------------------------------------------------------------------
	//	Function: areVideosOnDevice
	//		Checks if the 'No Videos' or 'No Content' text is being displayed.
	//
	//	Assumes:
	//		Must be navigated to one of the views where video should be.
	//
	//	Parameters: 
	//		None
	//
	//	Returns: 
	//		Returns true if videos are on the device, false if not.
	//----------------------------------------------------------------------------------------
	video.areVideosOnDevice = function areVideosOnDevice() {
		UIATarget.localTarget().pushTimeout(0.1);
		var result = this.mainWindow().elements().firstWithPredicate("name contains 'No Videos' or name contains 'No Content'").isValid();
		UIATarget.localTarget().popTimeout();
		return (!result);
	}

	//----------------------------------------------------------------------------------------
	//	Function: pickAndPlayVideo
	//		goes to the videos list, selects and plays the specified video. 
	//
	//	Parameters: 
	//		videoName (string) - the name of the video that has to be played. 
	//		videoPath (string) - optional - the array elements specify the path to the video. 
	//
	//	Returns: 
	//		The name of the video that was played
	//
	//	Throws: 
	//		Error
	//----------------------------------------------------------------------------------------
	video.pickAndPlayVideo = function pickAndPlayVideo(videoName, videoPath)
	{	
		this.getToMoviesView();
		
		if (videoPath && videoPath.length > 0) this.navigateVideoPath(videoPath);
		UIATarget.localTarget().delay(1);
		
		var videoTable = this.mainWindow().tableViews()[0];
		if (!videoTable.isValid()) throw new Error("Did not find a videos table");
		
		if (!videoName) {
			UIALogger.logMessage("Selecting random video");
			
			if (UIATarget.localTarget().model() == 'iPad') {
				var randomRowElement = UIAUtility.randomFromArray(videoTable.cells());
				if (!randomRowElement) throw new Error("No videos found");
				randomRowElement.scrollToVisible();
				
				var randomVideoElement = UIAUtility.randomFromArray(randomRowElement.buttons());
				videoName = randomVideoElement.name();
				UIALogger.logMessage("Playing '" + randomVideoElement.name() + "'");
				randomVideoElement.tap();
				
				UIALogger.logDebug("Tapping the Play button");
				var playButton = this.mainWindow().buttons()["Play"];
				UIATarget.localTarget().delay(1);
				playButton.tap();
			} else {
				var randomVideoElement = UIAUtility.randomFromArray(videoTable.cells());
				if (!randomVideoElement) throw new Error("No videos found");
				
				videoName = randomVideoElement.name();
				UIALogger.logMessage("Playing '" + randomVideoElement.name() + "'");
				randomVideoElement.scrollToVisible();
				randomVideoElement.tap();
			}
			
			//higher timeout to absolutely make sure we're not in video view
			UIATarget.localTarget().pushTimeout(10);
			var inVideoView = this.isInVideoView();
			UIATarget.localTarget().popTimeout();
			
			if (inVideoView) return videoName;

			UIALogger.logDebug("Not in video view -- might have selected a folder. Choosing again...");
			videoTable = this.mainWindow().tableViews()[0];
			if (!videoTable.isValid()) throw new Error("Did not find a videos table");
			var randomVideoElement = UIAUtility.randomFromArray(videoTable.cells().withPredicate("not name contains 'Get More Episodes'"));
			if (!randomVideoElement) throw new Error("No videos found");
			
			videoName = randomVideoElement.name();
			UIALogger.logMessage("Playing '" + randomVideoElement.name() + "'");
			randomVideoElement.scrollToVisible();
			randomVideoElement.tap();
		} else {
			UIALogger.logMessage("Selecting '" + videoName + "'");
			if (UIATarget.localTarget().model() == 'iPad') {
				if (this.isInVideoSummaryView()) {
					UIALogger.logDebug("In video summary view. Selecting the specified episode");
					var videoElement = videoTable.scrollToElementWithPredicate("name matches '.*" + UIAUtility.escapeString(videoName) + ".*'");
					videoName = videoElement.name();
					videoElement.tap();
				} else {
					UIATarget.localTarget().pushTimeout(0);
					var predicateString = "name matches '.*" + UIAUtility.escapeString(videoName) + ".*'";
					UIATarget.localTarget().popTimeout();
					var videoElement = this.mainWindow().tableViews()[0].scrollToElementWithPredicate("ANY buttons." + predicateString).buttons().firstWithPredicate(predicateString);
					videoName = videoElement.name();
					videoElement.tap();
					
					UIALogger.logDebug("Tapping the Play button");
					var playButton = this.mainWindow().buttons()["Play"];
					UIATarget.localTarget().delay(1);
					playButton.tap();
				}
			} else {
				var videoElement = videoTable.scrollToElementWithPredicate("name matches '.*" + UIAUtility.escapeString(videoName) + ".*'");
				videoName = videoElement.name();
				videoElement.tap();
			}
		}
		
		if (!this.isInVideoView())
			UIALogger.logWarning("Video view did not come up");
		
		return videoName;
	} 
	
	//----------------------------------------------------------------------------------------
	//	Function: navigateVideoPath
	//		Navigates to the specified path in video player. 
	//
	//	Assumes:
	//		This function navigates from the state it is called. This means that the first 
	//		element in the path should be visible, or become visible after the scroll (or after 
	//		returning to the top most level by tapping the 'Back' button repeatedly, if 
	//		returnToTopLevel is set to true). 
	//
	//	Parameters: 
	//		itemPath (array) - the elements of the array represent steps in the path. 
	//		returnToTopLevel (bool) - optional - If set to true, the function will navigate to the top 
	//			most level by tapping the 'Back' button repeatedly. It is set to false, by default.
	//
	//	Returns: 
	//		None
	//
	//	Throws: 
	//		Error
	//----------------------------------------------------------------------------------------
	video.navigateVideoPath = function navigateVideoPath(itemPath, returnToTopLevel) {
		
		var availableNavBarButtons = ["Movies", "Podcasts"];
		var currentIndex = 0;
		
		if (itemPath == null || itemPath.length == 0) {
			throw new Error("No path specified");
		}
		
		if (UIATarget.localTarget().model() != 'iPad' && this.tabBar().isValid()) audio.navigateSongPath(["Videos"]);
		
		if (returnToTopLevel) {
			UIALogger.logMessage("Going back to the top level");
			for (var i=0; i<5; i++) {
				try {
					this.navigationBar().leftButton().tap();
					UIATarget.localTarget().delay(1);
				} catch(e) {
					UIALogger.logMessage("No back button found. Assume that reached the top level");
					break;
				}
			}
		}
		
		//checking if the first one is a bottom button (Artists, Songs, etc.)
		var pathElementName = itemPath[0];
		if (UIATarget.localTarget().model() == 'iPad' && typeof pathElementName  == "string" && availableNavBarButtons.indexOf(pathElementName) > -1) {
			currentIndex++;
			UIALogger.logMessage("First argument '" + pathElementName + "' is a nav bar button.");
			var navBarButton = this.navigationBar().segmentedControls()[0].buttons().firstWithPredicate("name contains '" + pathElementName + "'");
			if (navBarButton.isVisible()) {
				UIALogger.logDebug("Found nav bar button. Selecting it");
				navBarButton.tap();
				if (!navBarButton.withValueForKey(1,"value").isValid()) throw new Error("Tapped the nav bar button '" + navBarButton.name() + "' but it did not get selected");
			} else {
				UIALogger.logMessage("Did not find a nav bar button. Checking if that is the only video type...");
				if (this.navigationBar().name() != pathElementName) {
					this.navigationBar().logElementTree();
					throw new Error("Could not select the nav bar button '" + pathElementName + "'");
				}
			}
		}
		
		for (; currentIndex<itemPath.length; currentIndex++) {
			
			var navBarLabel = this.navigationBar().name();
			UIALogger.logMessage("The nav bar label is '" + navBarLabel + "'");
			
			if (UIATarget.localTarget().model() == 'iPad') {
				//check whether in video summary view or not
				if (this.isInVideoSummaryView()) {
					UIALogger.logDebug("In video summary view");
					var tableElement = this.mainWindow().tableViews()[0].scrollToElementWithPredicate("name matches '.*" + UIAUtility.escapeString(itemPath[currentIndex]) + ".*'");
				} else {
					//need to access specific button in the grid table cell
					UIATarget.localTarget().pushTimeout(0);
					var predicateString = "name matches '.*" + UIAUtility.escapeString(itemPath[currentIndex]) + ".*'";
					UIATarget.localTarget().popTimeout();
					var tableElement = this.mainWindow().tableViews()[0].scrollToElementWithPredicate("ANY buttons." + predicateString).buttons().firstWithPredicate(predicateString);
				}
			} else {
				var tableElement = this.mainWindow().tableViews()[0].scrollToElementWithPredicate("name matches '.*" + UIAUtility.escapeString(itemPath[currentIndex]) + ".*'");
			}
			if (!tableElement.isValid()) throw new Error("Could not find the table cell: " + itemPath[currentIndex]);
			UIATarget.localTarget().delay(1); //give time for the scroll animation to finish
			tableElement.tap();
			
			this.navigationBar().withPredicate("name != " + navBarLabel);
		}
	}
	
	//----------------------------------------------------------------------------------------
	//	Function: getToMoviesView
	//		Goes to the movies list
	//
	//	Parameters: 
	//		None
	//
	//	Returns: 
	//		None
	//
	//	Throws: 
	//		Error
	//----------------------------------------------------------------------------------------
	video.getToMoviesView = function getToMoviesView() {
		
		UIALogger.logMessage("Going to movies view...");
		this.launchIfNotActive();
		
		var conversionMessage = "This may take a few minutes"; //Handles uncertainty between This may take a while or few minutes.
		
		UIALogger.logMessage("Checking for the conversion message");
		var convertingElement = this.mainWindow().elements().firstWithPredicate("name contains '" + conversionMessage + "'");
		if (convertingElement.isValid()) {
			UIALogger.logMessage("Waiting for conversion to finish");
			UIATarget.localTarget().pushTimeout(60);
			convertingElement.waitForInvalid();
			UIATarget.localTarget().popTimeout();
		}
						
		if (!this.areVideosOnDevice()) {
			throw new Error("No videos on the device -- please add content.");
		}	
		
		UIALogger.logMessage("Checking if a video is playing");
		if (this.isInVideoView()) {
			UIALogger.logMessage("Video is playing. Tapping Done.");
			try {
				//sometimes this might return false if the video just ended
				this.videoControlWithName('Done').withPredicate("isVisible == 1").tap();
			} catch(e) {
				UIALogger.logDebug("Encountered error while trying to tap Done: " + e.message);
				UIALogger.logDebug("Checking if the video view is still visible...");
				if (this.isInVideoView()) throw new Error("Could not tap the 'Done' button");
			}
		}

		for (var i=0; i<5; i++) {
			var backButton = this.navigationBar().leftButton().withPredicate("isVisible == 1 and name != 'Store'");
			if (backButton.isValid()) {
				UIALogger.logMessage("Found back button");
				backButton.tap();
				UIATarget.localTarget().delay(1);
			} else {
				break;
			}
		}
		
		if (UIATarget.localTarget().model() == 'iPad') {
			var navBar = this.navigationBar();
			if (navBar.segmentedControls()[0].buttons().length > 0) {
				var buttonToSelect = navBar.segmentedControls()[0].buttons().firstWithPredicate("name contains 'Movies'");
				UIALogger.logDebug("Selecting button '" + buttonToSelect.name() + "'");
				buttonToSelect.tap();
				if (!buttonToSelect.withValueForKey(1,"value").isValid()) throw new Error("Tapped '" + buttonToSelect.name() + "', but the button did not get selected");
			} else {
				UIALogger.logDebug("Did not find any buttons on the nav bar");
			}
		} else {
			var tabBar = this.tabBar();
			if (tabBar.isValid()) {
				UIALogger.logMessage("Found a tab bar. So, tapping 'Videos'");
				audio.navigateSongPath(["Videos"]);
			}
			
			if (!this.navigationBar().withName("Videos").isValid()) {
				//this.mainWindow().logElementTree();
				throw new Error("The videos nav bar did not show up");
			}
		}
	}

	//----------------------------------------------------------------------------------------
	//	Function: controlVideoPlaybackState 
	//		Taps "Play" or "Pause", depending on the specified parameter. 
	//		Assumes that the play/pause controls are being displayed. 
	//
	//	Parameters: 
	//		desiredState (string) - video.playbackActions.PLAY if the media needs to be played, 
	//			video.playbackActions.PAUSE if it needs to be paused. 
	//		time (int) - optional - this parameter is mainly used for verification. If this 
	//			parameter is specified, the function will sleep for the specified time, and 
	//			verify the scrubber state after this time interval.  
	//
	//	Returns: 
	//		None
	//
	//	Throws: 
	//		Error
	//----------------------------------------------------------------------------------------
	video.controlVideoPlaybackState = function controlVideoPlaybackState(desiredState, time) {
		if (desiredState != video.playbackActions.PLAY && desiredState != video.playbackActions.PAUSE)
			throw new Error("Invalid desiredState: " + desiredState);

		var date = new Date();
		var details = this.getVideoDetails();
		
		UIALogger.logMessage("Going to '" + desiredState + "' the video for " + time + " seconds.");
		try {
			var desiredStateButton = this.videoControlWithName(desiredState);
			desiredStateButton.tap();
			if (!desiredStateButton.withPredicate("name != '" + desiredState + "'").isValid())
				UIALogger.logWarning("The button name did change from '" + desiredState + "'");
		} catch(e) {
			UIALogger.logError(e.message);
			UIALogger.logMessage("Could not find the element for " + desiredState  + ". Perhaps, the action is already selected");
		}
				
		if (time != null) {			
			try {
				var slider = this.getTrackPositionSlider();
				var currentValue = slider.value();
				UIALogger.logDebug("Letting the video play for " + time + " seconds");
				UIATarget.localTarget().delay(time);
				
				slider = this.getTrackPositionSlider();
			} catch(e) {
				UIALogger.logError(e.message);
				var timeInterval = ((new Date()).getTime() - date.getTime())/1000;
				//check if the video has ended
				UIALogger.logMessage("Time remaining=" + details.timeRemaining + " Time since beginning=" + timeInterval);
				if (details.timeRemaining <= timeInterval && desiredState == video.playbackActions.PLAY) {
					UIALogger.logMessage("The video finished before performing the action");
					return ;
				}
				throw new Error("Could not find the slider");
			}
			
			var oldValue = currentValue;
			currentValue = slider.value();
			
			UIALogger.logMessage("The current slider value is " + currentValue);
			UIALogger.logMessage("The old slider value was " + oldValue);
			var hasProgressed = (oldValue != currentValue); 
			if (desiredState == video.playbackActions.PLAY && !hasProgressed) {
				throw new Error("There was no progress even though the Play button was tapped");
			} 
			if (desiredState == video.playbackActions.PAUSE && hasProgressed) {
				throw new Error("There was progress even though the Pause button was tapped");
			}
		}
	}
	
	//----------------------------------------------------------------------------------------
	//	Function: verifyVideoIsPlaying
	//		Checks whether the track progressed or not to verify that the video is playing. 
	//
	//	Parameters: 
	//		time (int) - optional - the number of seconds to allow the video to play before 
	//			checking whether the track progressed or not. If no value is specified, a 
	//			random value is chosen. 
	//
	//	Returns: 
	//		None
	//
	//	Throws: 
	//		Error
	//----------------------------------------------------------------------------------------
	video.verifyVideoIsPlaying = function verifyVideoIsPlaying(time) {
		UIALogger.logMessage("Verifying video is playing... ");
		
		var detailsBeforeDelay = this.getVideoDetails();
		UIATarget.localTarget().delay(time);
		var detailsAfterDelay = this.getVideoDetails();
		
		if (detailsBeforeDelay.timeElapsed >= detailsAfterDelay.timeElapsed) {
			throw new Error("The media did not progress")
		}
	}	
}