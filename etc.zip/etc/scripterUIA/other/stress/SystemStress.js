#import "UIAAppStressLibrary.js"

systemStress = AppStressBase.stressTest('System');

if (typeof systemStress != 'undefined') {
	
	systemStress.setup = function setup() {
		systemStress.addTest(systemStress._testLock);
		// commented out until <rdar://problem/8389224> is fixed
//		systemStress.addTest(systemStress._testLockWithPasscode);
		systemStress.addTest(systemStress.testSleep);
	}
	
	systemStress.init = function init() {
		if (!systemStress._unlockScreen(gDefaultPasscode)) { return false }
		
		try {
			springboard.getToFirstIconPage();
		}
		catch (e) {
			UIALogger.logError("Could not get to SpringBoard -- " + e);
			return false;
		}
		
		return true;
	}
	
	systemStress.run = function run() {
		systemStress.executeRandomTest();
	}
	
	// sleep -- this is public since other areas use it
	systemStress.testSleep = function testSleep() {
		var sleepTime = system.randomInteger(15, 30);
		var result;
		
		result = systemStress.executeTest("Sleep", [sleepTime], systemTest_lockAndUnlockDevice, "Lock device, sleep, unlock device.");
		
		if(result) { gAppStressData.incCounter("SleepCycle") }
		
		return systemStress._unlockScreen(gDefaultPasscode);
	}
	
	// lock
	systemStress._testLock = function _testLock() {
		systemStress.executeTest("Lock", [], systemTest_lockAndUnlockDevice, "Lock and unlock device.");
	}
	
	// lock w/ passcode
	systemStress._testLockWithPasscode = function _testLockWithPasscode() {
		if (systemStress.executeTest("SetPasscode", [gDefaultPasscode], settingsTest_setPasscode, "Set the default passcode.")) {
			systemStress.executeTest( "LockWithPasscode", [system.randomInteger(5, 10), gDefaultPasscode], 
									  systemTest_lockAndUnlockDevice, "Lock and unlock device with passcode." );
			systemStress.executeTest("ClearPasscode", [gDefaultPasscode], settingsTest_turnPasscodeOff, "Clear the default passcode.");
		}
	}
		
	
	// can't run picture frame yet
	
	systemStress._unlockScreen = function _unlockScreen(passcode) {
		var unlockCount = 5;
		
		while (system.isScreenLocked() && unlockCount--) {
			UIALogger.logError("ERROR: screen is still locked.");
			
			try {
				UIATarget.localTarget().unlockScreenIfNecessary(passcode);
			} catch(e) {
				UIALogger.logError("ERROR: unable to unlock screen.");
				if (unlockCount) {
					UIALogger.logMessage("Trying to unlock again...");
					system.sleep(5);
				}
			}
		}
		
		return system.isScreenLocked() ? false : true;
	}

}
