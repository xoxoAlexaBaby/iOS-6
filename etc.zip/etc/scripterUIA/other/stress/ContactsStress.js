#import "UIAAppStressLibrary.js"

//data to use for creating contact
var firstNames = new Array("Andy", "Dave", "Evan", "Fredrick", "Heather", "Ingus", "Luther", "Rickie", "Usher", "Yani");
var lastNames = new Array("Anderson", "Garrison", "Johnson", "Smith", "Williams", "Zulu");
var companies = new Array("Bogus Inc.", "Unreal Company", "Sample Networks", "Imaginary U.");
var phoneNumbers = new Array("4089748874", "8586515050");
var faceTimeNumbers = new Array();
var emailAddresses = new Array("name@bogus.org", "name@unreal.com", "name@sample.net", "name@imagine.edu");

// contact object
function contactObj (firstName, lastName, phoneNumber) {
	this.firstName = firstName;
	this.lastName = lastName;
	this.phoneNumber = phoneNumber;
}

contactObj.getRandomContact = function getRandomContact(faceTime) {
	var contact;
	var contactList = contactObj._faceTimeFilter(faceTime);
	
	if (contactList.length == 0) { return null }
	
	contact = UIAUtility.randomFromArray(contactList);
	
	return contact;
}

contactObj.newContact = function newContact(faceTime) {
//	var useCompany = system.randomInteger(0, 2);
	var firstName;
	var lastName;
	var numberList;
	var contact;
	
//	if (useCompany == 0) {
//		firstName = UIAUtility.randomFromArray(companies);
//	}
//	else {
//		firstName = UIAUtility.randomFromArray(firstNames);
//		lastName = UIAUtility.randomFromArray(lastNames);
//	}
	
	firstName = UIAUtility.randomFromArray(firstNames);
	lastName = UIAUtility.randomFromArray(lastNames);
	
	numberList = faceTime ? faceTimeNumbers : phoneNumbers;
	
	contact = new contactObj(firstName, lastName, UIAUtility.randomFromArray(numberList));
	
	return contact;
}


contactObj.pushContact = function pushContact(contact) {
	contactObj._contactList.push(contact);
}


contactObj.popContact = function popContact(contact) {
	var index;
	
	if (contactObj._contactList.length == 0) { return null }
	
	if (contact) {
		for (index = 0; index < contactObj._contactList.length; index++) {
			if (contact.asStr() == contactObj._contactList[index].asStr()) { break }
		}
		if (index >= contactObj._contactList.length) { return null }
	}
	else {
		index = system.randomInteger(0, (contactObj._contactList.length - 1));
	}
	
	contact = contactObj._contactList[index];
	contactObj._contactList.splice(index);
	
	return contact;
}

contactObj._contactList = new Array();

contactObj._faceTimeFilter = function _faceTimeFilter(faceTime) {
	var contactList = new Array();
	var filter;
	
	// set faceTime to 'false' if it's not defined
	faceTime = faceTime ? true : false;
	
	for (var key in contactObj._contactList) {
		filter = faceTimeNumbers.indexOf(contactObj._contactList[key].phoneNumber) >= 0 ? true : false;
		
		if (filter == faceTime) { contactList.push(contactObj._contactList[key]) }
	}
	
	return contactList;
}

contactObj.prototype.asStr = function asStr () {
	if (this.lastName != null) {
		return this.firstName + " " + this.lastName;
	}
	
	return this.firstName;
}

contactObj.prototype.asList = function asList () {
	var nameList = new Array(this.firstName);
	
	if (this.lastName != null) { nameList.push(this.lastName) }
	
	return nameList;
}

// contacts stress tests
if (typeof addressbook != 'undefined') {
	contactsStress = AppStressBase.stressTest("Contacts");
	
	if (typeof contactsStress != 'undefined') {
		contactsStress.usedNames = new Array();

		contactsStress.setup = function setup () {
//			contactsStress.addTest(contactsStress.addNewContact);
			contactsStress.addTest(contactsStress._deleteContact, 5);
			contactsStress.addTest(contactsStress._addNewPhone);
			contactsStress.addTest(contactsStress._addNewEmail);
			contactsStress.addTest(contactsStress._assignRingtone);
			contactsStress.addTest(contactsStress._dragContacts);
			contactsStress.addTest(contactsStress._flickContacts);
			
			// clear out old contacts
//			contactsStress._clearContacts();
		}
		
		contactsStress.run = function run () {
			contactsStress.executeRandomTests(3);
		}
		
		// add new contact
		contactsStress.addNewContact = function addNewContact(faceTime) {
			return contactsStress._addContact(contactObj.newContact(faceTime));
		}
		
		
		// delete contact
		contactsStress._deleteContact = function _deleteContact(contact) {
			var contact;
			var result;
			
			if (contact == null) { contact = contactsStress.pickContact() }
			
			result = contactsStress.executeTest( "DeleteContact", 
									  		   	 contact.asList(), 
									  		   	 contactsTest_deleteContact, 
									  		   	 "Delete " + contact.asStr() + " from contacts list.");
			
			// remove the contact from the internal list
			if (result) { contactObj.popContact(contact) }
			
			return result;
		}
		
		// add new phone number
		contactsStress._addNewPhone = function _addNewPhone(contact) {
			var phoneNumber;
			var phoneNumberType;
			var result;
			
			if (contact) {
				phoneNumber = contact.phoneNumber;
				phoneNumberType = "mobile";
				if (!contactsStress._selectContact(contact)) {
					UIALogger.logError("Can't find contact " + contact.asStr() + " -- skipping test.");
					return false
				}
			}
			else {
				contact = contactsStress.pickContact();
				if (contact == null) {
					UIALogger.logMessage("No contacts to modify -- skipping test.");
					return false;
				}
				
				phoneNumber = UIAUtility.randomFromArray(phoneNumbers);
				phoneNumberType = UIAUtility.randomFromArray(addressbook.numberTypes());
			}
			
			result = contactsStress.executeTest( "AddNewPhoneNumber", 
									  			 [ phoneNumber, phoneNumberType ], contactsTest_addNewPhone, 
									  			 "Add new phone number to " + contact.asStr() + ".");
			
			return result;
		}
		
		// add new email
		contactsStress._addNewEmail = function _addNewEmail() {
			var contact = contactsStress.pickContact();
			var args;
			var result;
			
			if (contact == null) {
				UIALogger.logMessage("No contacts to modify -- skipping test.");
				return;
			}
		
			args = new Array()
			args.push(UIAUtility.randomFromArray(emailAddresses));
			args.push(UIAUtility.randomFromArray(addressbook.emailTypes()));
			
			result = contactsStress.executeTest( "AddNewEmail", 
									  			 args, contactsTest_addNewEmail, 
									  			 "Add new email to " + contact.asStr() + ".");
			
			return result;
		}
		
		// assign ringtone
		contactsStress._assignRingtone = function _assignRingtone() {
			var contact = contactsStress.pickContact();
			var args;
			var result;
			
			if (contact == null) {
				UIALogger.logMessage("No contacts to modify -- skipping test.");
				return;
			}
		
			ringtone = UIAUtility.randomFromArray(addressbook.ringtones());
			
			result = contactsStress.executeTest( "AssignRingtone", 
									  			 [ ringtone ], 
									  			 contactsTest_assignRingtone, 
									  			 "Assign ringtone to " + contact.asStr() + ".");
			
			return result;
		}
		
		// drag contacts list
		contactsStress._dragContacts = function _dragContacts() {
			contactsStress.executeTest("DragContacts", [], contactsTest_dragContactsList, "Drag contacts list.");
		}
		
		// flick contacts list
		contactsStress._flickContacts = function _flickContacts() {
			contactsStress.executeTest("FlickContacts", [], contactsTest_flickContactsList, "Flick contacts list.");
		}
		
		
		// add contact (only called internally)
		contactsStress._addContact = function _addContact(contact) {
			var result;
			
			if (telephony.getCallCount() > 0) {
				UIALogger.logMessage("Skipping test: This test can not be run while on a call.");
				return false;
			}

			result = contactsStress.executeTest( "AddContact", 
												 contact.asList(), 
												 contactsTest_newContact, 
												 "Add " + contact.asStr() + " to contacts list.");

			if (result) {
				// always add 'mobile' phone # so the contact works w/ Phone tests
				result = contactsStress._addNewPhone(contact);

				if (result) {
					// add the name to the list of used names if it isn't there already
					contactObj.pushContact(contact);
				}
			}
			
			result = contactsStress._selectContact(contact);
			
			return result;
		}
		
		
		// select contact (only called by other tests)
		contactsStress._selectContact = function _selectContact(contact) {
			var result = contactsStress.executeTest( "Select Contact", 
												 	 contact.asList(), 
												 	 contactsTest_selectContact, 
												 	 "Select " + contact.asStr() + " from contacts list.");
			
			return result;
		}
		
		// pick a contact from those already added
		contactsStress.pickContact = function pickContact(faceTime) {
			var contact = contactObj.getRandomContact(faceTime);
			
			if (contact == null) {
				contact = contactObj.newContact(faceTime);
				
				// try to find a contact that already exists
				if (contactsStress._selectContact(contact)) {
					contactObj.pushContact(contact);
					return contact;
				}
				
				if (contactsStress._addContact(contact)) { return contact }
				
				return null;
			}
			
			return contact;
		}
		
		contactsStress._clearContacts = function _clearContacts() {
			var contact;
			var result;
			
			for (var first in firstNames) {
				for (var last in lastNames) {
					contact = new contactObj(firstNames[first], lastNames[last]);
					do {
						result = contactsStress._deleteContact(contact);
					} while (result);
				}
			}
		}
	}
}

