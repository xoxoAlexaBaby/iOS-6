
###########################################################################
# Function to Dump the Unwanted Logs and delete them
###########################################################################
dumpLogs()
{
		echo "Dumping Logs after $1 iterations using SIGUSR2...   \c"; date;
		killall -USR2 CommCenter
		sleep 45
		ls $logFiles | perl -lne ' $file = $_; open (F, $file); foreach $l (<F>) { if ($l =~ /\Q<string>Reason: Dump state\E/) { $file =~ s/(.*)(\Qcsi.plist\E)/$1/g; print "$file"; last; } } ' > /tmp/deleteFiles;
}

###########################################################################
# Function take a *KOOL*STATE# when any failure happens
# Failure message $1 is stored as the User Explanation for the failure.
###########################################################################
takeK00lState()
{
		${TOOLS_DIR}/scripter -f /usr/local/etc/scripter/general/Interact.js com.apple.springboard "dismissAlerts(app)"
        $TESTCT -c *5005*78283#
        sleep 1
        #touch the Reply Button
        eventer t 175 415
		echo "String - $1."
        eventer w $1
        sleep 1
        #touch the Send button
        eventer t 268 29
}

###########################################################################
# Processing Dumped logs
###########################################################################
saveDumpedLogs()
{
	perl -lne '$s="*"; $f = "$_$s"; system `mv $f*bin  $f*csi.plist RemovedLogs/`; print "Removing \"$f\""; system `rm $f`; ' /tmp/deleteFiles;
}

removeDumpedLogs()
{
	perl -lne '$s="*"; $f = "$_$s"; system `mv $f*csi.plist RemovedLogs/`; print "Removing \"$f\""; system `rm $f`; ' /tmp/deleteFiles;
}

