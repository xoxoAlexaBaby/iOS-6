#import "../libs/SpringBoard.js"
#import "../libs/PHTesting.js"
#import "../phone/Phone.js"
#import "../mail/Mail.js"

// This is a file containing all of the assistant tests.  Note that these functions may change names and/or move in the near(ish) future.

//----------------------------------------------------------------------------------------
//	Function: _resetAssistant 
//		Helper function for assistantTests.  This ends any calls, makes sure we're not in
//      assistant, etc.  It is wise to use this at the beginning of all assistant tests.
//
//	Parameters: 
//		none
// 
//	Returns:
//		throws error if something doesn't work as it should.
//----------------------------------------------------------------------------------------
function _resetAssistant() {
    // End any phone calls that might exist--assistant doesn't work if there are active phone calls.
	try {
	    UIALogger.logMessage("Trying to end any phone calls that may exist.");
	    phone.endAllCalls();
	}
	catch (e) {
	    UIALogger.logMessage("No calls to end.");
	}
	
	// If we are in assistant, exit out of it so we have a fresh start.
	if (springboard.microphoneButton().isValid()) {
	    UIALogger.logMessage("Siri microphone button is on-screen.  Running 'springboard.getToFirstIconPage()");
	    springboard.getToFirstIconPage(); 
    }
}

//----------------------------------------------------------------------------------------
//	Function: assistantTest_makeAndEndPhoneCall 
//		Makes a call based on the given voice command
//
//	Parameters: 
//		inputVoiceCommand (string or Array of strings) - input file(s)
//
//  Optional Parameters:
//		phoneNumber (string) - phone number that we expect to be connected to		
// 
//	Returns:
//		1 if test passes, 0 or 64 if test fails.
//----------------------------------------------------------------------------------------
function assistantTest_makePhoneCall() {
	this.testResult = 0;
	
	if (this.argv.length < 1) {		
		UIALogger.logError(this.testError);
		this.testError = "Not enough args were passed to this function."
		return 0;		
	}
	
	var inputVoiceCommand = this.argv[0];
	
	// Push options onto optionsArray;
	var optionsArray = new Array(); 
	for (var i=1; i<this.argv.length; i++) {
		optionsArray.push(this.argv[i]);
	}
	var options = new Array();
	
	options.phoneNumber = UIAUtility.valuesForKey("phoneNumber", optionsArray, 1);  
	
	_resetAssistant();
	springboard.issueVoiceCommand(inputVoiceCommand);
	try {
	    phone.waitForPhoneCallToStart();
	    UIATarget.localTarget().delay(5);  // give a few seconds for phone call to take place.
	    phone.endCall(options.phoneNumber);
	} 
	catch (e) {
	    // end the phone call if one exists.
	    UIALogger.logError("Caught error: " + e.message + ",  Assistant Info: " + springboard.currentAssistantInfo());
	    UIATarget.localTarget().logElementTree();  // debugging info
	    if (telephony.getCallCount() >= 1) {
	        UIALogger.logMessage("Had an error, but phone call is active--ending phone call.");
	        phone.launchIfNotActive();
	        phone.getToCallPage();
	        phone.endCall();
	    }
	    throw e.message;
	}
	return this.testResult = 1;

}

//----------------------------------------------------------------------------------------
//	Function: assistantTest_sendEmail 
//		Send an email
//
//	Parameters: 
//		inputVoiceCommand (string or Array of strings) - input file(s)
//
//  Optional Parameters:
//      endVerification (string) - string to look for in assistant after all of the voice 
//          commands have been submitted.
//      dontSend (bool) - set to 1 or "true" if you want to cancel sending the email.
//		validateSent (bool) - indicates whether or not we should validate that the 
//			email is in the sent folder.  Default is to not validate.  Note that a subject
//          is needed if you want to validate that the email was successfully sent.
//      verficationArray (string) - as many strings as desired--each one indicates a string
//          expected in the assistant after hitting the microphone button.  Order matters.
//          
//	Returns:
//		1 if test passes, 0 if test fails.
//----------------------------------------------------------------------------------------
function assistantTest_sendEmail() {
    this.testResult = 0;
	
	if (this.argv.length < 1) {		
		UIALogger.logError(this.testError);
		this.testError = "Not enough args were passed to this function."
		return 0;		
	}
	
	var inputVoiceCommand = this.argv[0];
	
	// Set the optional parameters
	var options = new Array();
	options.endVerification = UIAUtility.valuesForKey("endVerification", this.argv);  
	options.dontSend = UIAUtility.valuesForKey("dontSend", this.argv, 1);
	options.subject = UIAUtility.valuesForKey("subject", this.argv, 1);
	options.validateSent = UIAUtility.valuesForKey("validateSent", this.argv, 1);
	options.verificationArray = UIAUtility.valuesForKey("verificationArray", this.argv);
	
	_resetAssistant();
	springboard.issueVoiceCommand(inputVoiceCommand, options);
    springboard.sendEmailViaAssistant(options);
    return this.testResult = 1;
}

//----------------------------------------------------------------------------------------
//	Function: assistantTest_genericTest
//		This a a generic assistant test.  It inputs one or more files and then looks for a string 
//          (or strings) if one (or more) are specified.
//
//	Parameters: 
//		inputVoiceCommand (string or Array of strings) - input file(s)
//
//  Optional Parameters:
//      endVerification (string) - string to look for in assistant after all of the voice 
//          commands have been submitted.  If there's more than one specified, the function 
//          looks for all of them.
//          
//	Returns:
//		1 if test passes, 0 if test fails.
//----------------------------------------------------------------------------------------
function assistantTest_genericTest() {
    this.testResult = 0;
	
	if (this.argv.length < 1) {		
		UIALogger.logError(this.testError);
		this.testError = "Not enough args were passed to this function."
		return 0;		
	}	
	var inputVoiceCommand = this.argv[0];
	
	// Set the optional parameters
	var options = new Array();
	options.endVerification = UIAUtility.valuesForKey("endVerification", this.argv);  
	
	_resetAssistant();
	springboard.issueVoiceCommand(inputVoiceCommand, options);
	if (options.endVerification) {
	    var verificationArray = options.endVerification;
        if (typeof options.endVerification == "string") {
            verificationArray = new Array(options.endVerification);
        }
        var timeout = 60;
        for (var i = 0; i<verificationArray.length; i++) {
	        UIALogger.logMessage("Looking for '" + verificationArray[i] + "' in Assistant.");
        	if (!springboard.waitForStringInAssistant(verificationArray[i], timeout)) {
        	    this.testError = "Could not find '" + verificationArray[i] + "' in assistant, Assistant Info " + springboard.currentAssistantInfo()
        	    return this.testResult = 0;
	        }
	        timeout = 10;  // change timeout to 10, since the first timeout was so long.
	    }
	}
	return this.testResult = 1;
}