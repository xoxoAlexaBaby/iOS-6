#import "./Safari.js"
#import "../mail/Mail.js"
#import "../libs/PHTesting.js"

//----------------------------------------------------------------------------------------
//	Function: safariTest_loadSafariPage 
//		Loads a url in Safari
//
//	Parameters: 
//		url (string) - URL to load.  Needs to have "http://" prefix.
//		waitForLoad (bool) - whether or not to wait for the page to load before zooming, flcking, or dragging (optional if not followed by any other arguments)
//		additionalTests (string1, string2, etc....) - additional tests that should be run after loading the page (optional)
//															Use the following strings to perform those tests.  Tests will be done in the order they are passed
//														"flick" - randomly flick on the screen once
//														"drag" - randomly drag on the screen once
//														"flicksAndDrags" - randomly flick or drag on the screen a random number of times; max 5
//														"doubleClickZoomIn" - randomly double-click to zoom
//														"doubleClickZoomOut" - double-click on the center of the screen.  If doubleClick zoom was used to zoom, this will zoom out.
//														"pinchZoomIn" - use pinching to zoom in on the center of the screen.
//														"pinchZoomOut" - use pinching to zoom out
//														"random" - randomly choose one of the previous options
//
//	Returns:
//		1 if test passes, 0 or 64 if test fails.
//----------------------------------------------------------------------------------------
function safariTest_loadSafariPage()
{	
	if (this.argv.length > 0) { 
		var url = this.argv[0];
	} else {
		UIALogger.logError("No url specified.");
		return 64;		
	}
	var additionalTestArray = ["flick", "drag", "flicksAndDrags", "doubleClickZoomIn", "doubleClickZoomOut", "pinchZoomIn", "pinchZoomOut"];
	var waitForLoad = true;
	var extras = new Array();	
	if (this.argv.length > 1){
		waitForLoad = this.argv[1];
		for (var i=2; i < this.argv.length; i++) {
			extras.push(this.argv[i]);
		}		
	}
	
	this.testResult = 0;
	safari.reset();
	UIATarget.localTarget().delay(1);

	var date = new Date();
	
	if (waitForLoad) {
		try {
			safari.loadPageAndWait(url, 240);	
		} catch(e) {
			UIALogger.logError(e.message);
			this.testError = "Safari never finished loading the  page.  Bailing";
			safari.reset();
			return 0;
		}
		UIATarget.localTarget().delay(2);
	}
	else {
		UIALogger.logMessage("Loading URL " + webPage);
		safari.loadURL(webPage);
		UIATarget.localTarget().delay(10);
	};
	
	var gotErrorDialog = (!safari.checkForPageLoadErrorSinceDate(date));
	if (gotErrorDialog) {
		this.testError = "Got an error dialog.";
		UIALogger.logError(this.testError);
		return this.testResult = 0;
	}
	
	var addressBar = safari.addressBar();
	addressBar.scrollToVisible();
	if (!addressBar.isVisible()) UIALogger.logWarning("Address bar not visible after loading the page");
	
	//do extra tests
	try {
		var mainWebView = safari.getSafeWebDocumentView({excludeEdges:true});
	} catch(e) {
		UIALogger.logError(e.message);
		this.testError = "Error.  Could not find WebView."
		UIALogger.logError(this.testError);
		return 0;
	};
	
	for (var j=0; j < extras.length; j++) {
		UIALogger.logMessage("Running " + extras[j] + " test.");
		if (extras[j] == "random") {
			extras[j] = UIAUtility.randomFromArray(additionalTestArray);
		};
		
		switch (extras[j]) {
			case "flick":
				UIATarget.localTarget().randomFlick(mainWebView);
				UIATarget.localTarget().delay(1);
				break;
			case "drag":
				UIATarget.localTarget().randomDrag(mainWebView);
				UIATarget.localTarget().delay(1);
				break;
			case "flicksAndDrags":
				UIATarget.localTarget().randomDragsOrFlicks(mainWebView);
				UIATarget.localTarget().delay(1);
				break;
			case "doubleClickZoomIn":
				UIATarget.localTarget().doubleTapRandomPoint(mainWebView);
				UIATarget.localTarget().delay(2);
				break;
			case "doubleClickZoomOut":
				var centerX = mainWebView.origin.x + mainWebView.size.width/2;
				var centerY = mainWebView.origin.y + mainWebView.size.height/2;
				UIALogger.logMessage("Zooming out by double-tapping: (" +  centerX + ", " + centerY + ")");
				UIATarget.localTarget().doubleTap({x:centerX, y:centerY});
				break;
			case "pinchZoomIn":
				UIATarget.localTarget().randomStretch(mainWebView);
				break;
			case "pinchZoomOut":
				UIATarget.localTarget().randomPinch(mainWebView);
				break;
		}
	};
	
	safari.reset();
	return this.testResult = 1;
}

//----------------------------------------------------------------------------------------
//	Function: safariTest_crawlWeb 
//		Starts on a page and chooses a random link off that page.  
//		Script continues crawling this way until it reaches the number of pages that
//		it should crawl through.
//
//	Parameters: 
//		startPage (string) - URL to load initially.  Needs to have "http://" prefix.
//		numPages (integer) - Number of links to load, one after the other.
//		zoomAndScroll (bool) - Whether or not you want to scroll and zoom on each page before continuing your crawl.(optional)
// 
//	Returns:
//		1 if test passes, 0 or 64 if test fails.
//----------------------------------------------------------------------------------------
function safariTest_crawlWeb(){
	if (this.argv.length < 2) {
		this.testError = "Requires start page and a number of pages to crawl."
		return 64;
	};
	
	var startPage = this.argv[0];
	var numPages = parseInt(this.argv[1]);
	var zoomAndScroll = false;
	if (this.argv.length > 2) {zoomAndScroll = this.argv[2]};
	
	safari.reset();
	UIATarget.localTarget().delay(1);
	
	try {
		safari.crawlWeb(startPage,numPages, zoomAndScroll);
		return this.testResult = 1;
	} catch(e) {
		this.testError = "Crawl web test failed";
		UIALogger.logError("safariTest_crawlWeb", this.testError);
		return this.testResult = 0;
	}
}

//----------------------------------------------------------------------------------------
//	Function: safariTest_loadRandomBookmark 
//		Picks a random bookmark in Safari and loads the page.
//
//	Parameters: 
//		None
// 
//	Returns:
//		1 if test passes, 0 if test fails.
//----------------------------------------------------------------------------------------
function safariTest_loadRandomBookmark() {
	
	UIALogger.logMessage("Going to the bookmark list view");
	try {
		safari.getToBookmarksView();
	} catch(e) {
		UIALogger.logError("Encountered an error: " + e.message);
		this.testError = "Could not get to the bookmark list view";
		UIALogger.logError(this.testError);
		return this.testResult = 0;
	}
	
	var date = new Date();
	
	UIALogger.logMessage("Now selecting a bookmark...");
	try {
		var result = safari.selectRandomBookmarkOnPage();
		if (!result) {
			this.testError = "Could not find a bookmark to select";
			UIALogger.logError(this.testError);
			return this.testResult = 0;
		}
	} catch(e) {
		UIALogger.logError("Encountered Error: " + e.message);
		this.testError = "Could not find a bookmark to select";
		UIALogger.logError(this.testError);
		return this.testResult = 0;
	}
	
	UIALogger.logMessage("Waiting for the page to load...");
	try {
		safari.waitForPageToLoad(120, {date:date})
	} catch(e) {
		UIALogger.logError(e.message);
		this.testError = "Test timed out waiting for page to load or dialog was encountered.";
	}
	
	if (this.testError) {
		
		var path = safari.asApplication().archiveWebViews();
		//adding this temporarily for <rdar://problem/8867341>
		UIALogger.logDebug("web view saved to " + path);
		system.run("/bin/mv " + path + " /var/mobile/Library/Logs/Testing/", 5);
		
		safari.reset();
		UIALogger.logError(this.testError);
		return this.testResult = 0;		
	}
	
	return this.testResult = 1;
}

//----------------------------------------------------------------------------------------
//	Function: safariTest_addBookmark 
//		Adds a bookmark
//
//	Parameters:  
//		bookmarkURL (string) - url to navigate to before creating a bookmark. (optional)
//			Will create a bookmark for the current page if no url is specified
// 
//	Returns:
//		1 if test passes, 0 if test fails.
//----------------------------------------------------------------------------------------
function safariTest_addBookmark () {
	UIALogger.logMessage("Creating a new bookmark.");
	this.testResult = 0;
	var bookmarkURL = null;
	if (this.argv[0] && this.argv[0] != "" && this.argv[0] != "null") bookmarkURL = this.argv[0];
	safari.reset();
	
	//create the bookmark
	try {
		var bookmarkName = safari.addBookmark("bookmark", bookmarkURL);
	} catch(e) {
		UIALogger.logError(e.message);
		this.testError = "Unable to create a bookmark.";
		UIALogger.logError(this.testError);
		return this.testResult;
	}
	
	try {
		safari.getToBookmarksView();
	} catch(e) {
		UIALogger.logError(e.message);
		this.testError = "Could not get to the bookmarks view";
		return this.testResult = 0;
	}
	UIATarget.localTarget().delay(1);
	
	try {
		safari.scrollToBookmarkWithName(bookmarkName);
		UIALogger.logMessage("Bookmark added for " + bookmarkName + ".");
		return this.testResult = 1;
	} catch(e) {
		this.testError = "Could not find bookmark " + bookmarkName + "."
		UIALogger.logError(this.testError);
		return this.testResult;
	}
}

//----------------------------------------------------------------------------------------
//	Function: safariTest_addBookmarkToHomeScreen 
//		Adds a bookmark to the home screen
//
//	Parameters:  
//		bookmarkURL (string) - url to navigate to before creating a bookmark. (optional)
//			Will create a bookmark for the current page if no url is specified
//		bookmarkCapCount (integer) - The number of bookmark icons allowed on the home screen.
//			If none is specified, the limit is not set. (optional)
// 
//	Returns:
//		1 if test passes, 0 if test fails.
//----------------------------------------------------------------------------------------
function safariTest_addBookmarkToHomeScreen () {
	UIALogger.logMessage("Creating a new bookmark on home screen.");
	this.testResult = 0;
	var bookmarkURL = null;
	if (this.argv[0] && this.argv[0] != "" && this.argv[0] != "null") bookmarkURL = this.argv[0];
	var bookmarkCapCount = this.argv[1];
	
	safari.reset();
	
	//create the bookmark
	try {
		var bookmarkName = safari.addBookmark("home screen", bookmarkURL);
	} catch(e) {
		UIALogger.logError(e.message);
		this.testError = "Unable to create a bookmark.";
		return this.testResult;
	}
	
	UIALogger.logMessage("Verifying the bookmark was added to the home screen");
	
	var bookmarkIcon = springboard.mainWindow().scrollViews()[0].elements()[bookmarkName];	
	if (bookmarkIcon.isValid()) {
		UIALogger.logMessage("Bookmark added to the home screen for " + bookmarkName + ".");
		this.testResult = 1;
	} 
	else{
		this.testError = "Could not find bookmark " + bookmarkName + " on the home screen.";
		UIALogger.logError(this.testError);
		return this.testResult;
	}
	
	//if there's no cap count, don't worry about cleanup
	if (!bookmarkCapCount) {
		return this.testResult;
	}

	var pageIndicator = springboard.mainWindow().pageIndicators()[0];
	if (!pageIndicator.isValid()) {
		this.testError = "No page indicator visible";
		UIALogger.logMessage(this.testError);
		return this.testResult = 0;
	}
	
	var bookmarkIconsNumber = 0;
	var similarBookmarks = [];
	for (var i=1; i<=pageIndicator.pageCount()-1; i++) {
        UIALogger.logDebug("Going to " + i + " page to find " + bookmarkName);
		pageIndicator.selectPage(i);
        UIATarget.localTarget().delay(0.5);
		similarBookmarks = similarBookmarks.concat(springboard.mainWindow().scrollViews()[0].elements().withPredicate("name == '" + bookmarkName + "' and isVisible == 1").toArray());
		UIATarget.localTarget().delay(0.5);
	}
	
	UIALogger.logMessage("Found " + similarBookmarks.length + " icons with name '" + bookmarkName + "'");
	if (similarBookmarks.length > Math.max(0, parseInt(bookmarkCapCount))) {
		UIALogger.logMessage("Deleting the first bookmark");
		var bookmarkToDelete = springboard.getIconWithName(bookmarkName);
		springboard.deleteIcon(bookmarkToDelete)
	}

	
	return this.testResult;
}

//----------------------------------------------------------------------------------------
//	Function: safariTest_performGoogleSearch 
//		Performs a google search with the specified search criteria and link to verify.
//
//	Parameters:  
//		searchString (string) - string to type into the search filed
//		link (string) - the link to verify exists on the search results page
//		exactMatch (bool) - true if the link must match exactly, false if it can partially match
//
//	Returns:
//		1 if test passes, 0 if test fails.
//----------------------------------------------------------------------------------------
function safariTest_performGoogleSearch() {
	if (this.argv.length < 2) { 
		UIALogger.logError("Requires a 'searchString' and 'link' url to run.");
		return 64;		
	}
	
	var searchString = this.argv[0];
	var link = this.argv[1];
	var exactMatch = true;
	if (this.argv.length > 2) {
		if ((this.argv[2] == "false") || (this.argv[2] == 0)) {
			exactMatch = false;
		}
	}
	var timeout = 240;
	this.testResult = 0;
	
	safari.reset();
	var date = new Date();
	try {
		safari.search(searchString);
	} catch(e) {
		this.testError = "Could not tap on the search field, and type " + searchString;
		UIALogger.logError(this.testError);
		safari.reset();
		return this.testResult = 0;
	}
	
	// do nothing until safari finishes loading the results
	try {
		safari.waitForPageToLoad(timeout, {date:date});
	} catch(e) {
		UIALogger.logError(e.message);
		this.testError = "Safari never finished loading the page.  Bailing.";
		safari.reset();
		return 0;
	}
	
	// check to see if we ended up on a page with our our search string in the input element
	var inputElement = safari.webViewElementWithPredicate(safari.mainWindow().scrollViews()[0].webViews()[0],
                                                          "className == 'UIATextField' and value == '" + searchString + "'");
	if (!inputElement.isValid()) {
		this.testError = "Page loaded after the search did not contain an input element with the text '" + searchString + "'.";
		return this.testResult = 0;
	}
	
	// check if the link to verify the search results exists
	UIALogger.logMessage("Checking thru links on the page..");
	var found = safari.findLinkOnPage(link, exactMatch);
	if (found) {
		safari.reset();
		return this.testResult = 1;
	} else {
		this.testError = "Couldn't find link: " + link;
		UIALogger.logError(this.testError);
		safari.reset();
		return 0;
	}
}

//----------------------------------------------------------------------------------------
//	Function: safariTest_selectItemFromSuggestionList 
//		Selects an item from the Suggestion list and goes to that url.
//
//	Parameters:  
//		partialURLString (string) - partial url to type into the url field to trigger the suggestion list
//		suggestionListItem (string) - the item in the suggestion list to select
//		link (string) - link to search for to verify the page loaded correctly
// 
//	Returns:
//		1 if test passes, 0 if test fails.
//----------------------------------------------------------------------------------------
function safariTest_selectItemFromSuggestionList() {
	if (this.argv.length < 3) { 
		UIALogger.logError("Requires a 'partialURLString', 'suggestionListItem', and 'link' to run.");
		return 64;		
	}
	
	var partialURLString = this.argv[0];
	var suggestionListItem = this.argv[1];
	var link = this.argv[2];
	this.testResult = 0;
	var timeout = 240;
	
	safari.reset();
	UIATarget.localTarget().delay(1); //TODO: should check if this is really needed....
	
	// click the url view, so we can type something
	var addressBar = safari.addressBar();
	if (!addressBar.isValid()) {
		this.testError = "Could not find the address bar";
		return this.testResult = 0;
	} 
	addressBar.scrollToVisible();
	addressBar.tap();
	
	try {
		safari.enterTextInTextField(safari.mainWindow().textFields().firstWithPredicate("name == 'Address' and isVisible == 1"), partialURLString);
	} catch(e) {
		UIALogger.logError(e.message);
		this.testError = "Couldn't click the URL view to start typing a URL.";
		safari.reset();
		return 0;
	}
	UIATarget.localTarget().delay(3);

	if (UIATarget.localTarget().model() == 'iPad')
		var suggestionTable = safari.mainWindow().popover().tableViews()[0];
	else
		var suggestionTable = safari.mainWindow().tableViews()[0];
	if (!suggestionTable.isValid()) {
		this.testError = "Could not find the suggestion table";
		return this.testResult = 0;
	}
	var itemElement = suggestionTable.scrollToElementWithPredicate("name contains '" + suggestionListItem + "'");
	if (!itemElement.isValid()) {
		this.testError = "Didn't find suggestion: '" + suggestionListItem + "' in the Suggestion list.";
		safari.mainWindow().buttons()["Cancel"].tap();
		safari.reset();
		return 0;
	}
	var date = new Date();
	itemElement.tap();
	UIATarget.localTarget().delay(2);
	
	// do nothing until safari finishes loading the results
	try {
		safari.waitForPageToLoad(timeout, {date:date});
	} catch(e) {
		UIALogger.logError(e.message);
		this.testError = "Safari never finished loading the page.  Bailing.";
		safari.reset();
		return 0;
	}
	
	// check if the link to verify the search results exists
	UIALogger.logMessage("Checking thru links on the page.");
	var found = safari.findLinkOnPage(link, false);
	if (found) {
		safari.reset();
		return this.testResult = 1;
	} else {
		this.testError = "Couldn't find link: " + link;
		safari.reset();
		return 0;
	}
}

//----------------------------------------------------------------------------------------
//	Function: safariTest_refreshPage 
//		Refreshes the existing web page
//
//	Parameters:  
//		webPage (string) - web page to load then refresh. Note that it is a 
//			good idea to choose a webPage that takes a few seconds to load for the test 
//			to be robust.
//
// 
//	Returns:
//		1 if test passes, 0 if test fails.
//----------------------------------------------------------------------------------------
function safariTest_refreshPage() {
	if (this.argv.length < 1) { 
		UIALogger.logError("Requires a web page URL to run.");
		return 64;		
	}
	
	var webPage = this.argv[0];
	this.testResult = 0;
	var timeout = 240;
	var refreshTimeout = 2;
	var refreshInterval = 0.5;
	
	safari.reset();

	UIALogger.logMessage("Loading page " + webPage);
	// do nothing until safari finishes loading the results
	try {
		safari.loadPageAndWait(webPage, timeout);
	} catch(e) {
		UIALogger.logError(e.message);
		this.testError = "Safari never finished loading the page.  Bailing";
		safari.reset();
		return 0;
	}
	UIATarget.localTarget().delay(2);
	
	UIALogger.logMessage("Tapping the refresh button");
	try {
		safari.tapRefreshButton();
	} catch(e) {
		UIALogger.logError(e.message);
		this.testError = "Could not tap the refresh button";
		return this.testResult = 0;
	}
	
	UIALogger.logMessage("Checking to see if its loading...");
	//need to check multiple times to account for the faster devices loading the webpages really fast <rdar://problem/8944162>
	var count = refreshTimeout/refreshInterval;
	var isLoading = false;
	for (var i=0; i<count; i++) {
		var isLoading = safari.isLoading();
		if (isLoading) break;
		UIATarget.localTarget().delay(refreshInterval);
	}
	
	if (isLoading) {
		safari.reset();
		return this.testResult = 1;
	}
	
	this.testError = "Page '" + webPage + "' isn't reloading."
	UIALogger.logError(this.testError);
	safari.reset();
	return 0;
}

//----------------------------------------------------------------------------------------
//	Function: safariTest_clickOnURL 
//		Clicks on the link x,y location provide from the webpage provided,
//		and verifies we've traversed the link properly
//
//	Parameters:  
//		webPage (string) - web page to load to click a link against
//		url (string) - url to verify link traversal
//		x, y (integer) - x,y coords to click on the screen - (optional; use if scripter can't see link)
// 
//	Returns:
//		1 if test passes, 0 if test fails.
//----------------------------------------------------------------------------------------
function safariTest_clickOnURL() {
	if (this.argv.length < 2) { 
		UIALogger.logError("Requires a web page, the URL to click.");
		return 64;		
	}
	
	var webPage = this.argv[0];
	var url = this.argv[1];
	
	if (this.argv.length > 3) {
		var x = this.argv[2];
		var y = this.argv[3];
	}
	
	this.testResult = 0;
	var timeout = 240;
	
	safari.reset();
	
	// do nothing until safari finishes loading the results
	try {
		safari.loadPageAndWait(webPage, timeout);
	} catch(e) {
		UIALogger.logError(e.message);
		this.testError = "Safari never finished loading the initial page.  Bailing";
		safari.reset();
		return 0;
	}
	UIATarget.localTarget().delay(2);
	
	var date = new Date();
	
	UIALogger.logDebug("Looking for link with url " + url);
	var linkElement = safari.mainWindow().scrollViews()[0].webViews()[0].links().firstWithPredicate("url contains '" + url + "'");
	if (!linkElement.isValid()) {
		this.testError = "Did not find a link with url " + url;
		return this.testResult = 0;
	}
	linkElement.scrollToVisible();
	linkElement.tap();
	
	UIATarget.localTarget().delay(2);
	// do nothing until safari finishes loading the results
	try {
		safari.waitForPageToLoad(timeout, {date:date});
	} catch(e) {
		UIALogger.logError(e.message);
		this.testError = "Safari never finished loading the link page.  Bailing.";
		safari.reset();
		return 0;
	}
	UIATarget.localTarget().delay(3);
	
	// verify we're on the correct page
	var page = safari.activeURL();
	UIALogger.logMessage("expected to be on: " + url);
	UIALogger.logMessage("page we're on: " + page);
	
	// only requiring a match helps with localization redirects etc redirects in many sites (i.e. http://store.apple.com/us mathces for store.apple.com)
	if (page.match(url)) {
		this.testResult = 1;
		safari.reset();
		return 1;
	} 
	else {
		this.testError = "Expected to be on: '" + url + "'.  Ended up on: '" + page + "'";
		UIALogger.logError(this.testError);	
	}
	safari.reset();
	return 0;
}

//----------------------------------------------------------------------------------------
//	Function: safariTest_openWebPageInTab
//		Opens webPage1 page initially, then webPage2 in a second tab
//
//	Parameters:  
//		webPage1 (string) - web page to open
//		webPage2 (string) - 2nd web page to open
//		tabText (String) - text in the tab view to find and verify
// 
//	Returns:
//		1 if test passes, 0 if test fails.
//----------------------------------------------------------------------------------------
function safariTest_openWebPageInTab() {
	if (this.argv.length < 3) { 
		UIALogger.logError("Requires 2 web pages to run.");
		return 64;		
	}
	
	var webPage1 = this.argv[0];
	var webPage2 = this.argv[1];
	var tabText = this.argv[2];
	this.testResult = 0;
	var timeout = 240;

	safari.reset();
	try {
		safari.closeAllTabs();
	} catch(e) {
		UIALogger.logError(e.message);
		this.testError = "Could not close all the tabs";
		return this.testResult = 0;
	}
	
	// do nothing until safari finishes loading the results
	try {
		safari.loadPageAndWait(webPage1, timeout);
	} catch(e) {
		UIALogger.logError(e.message);
		this.testError = "Safari never finished loading the initial page.  Bailing";
		safari.reset();
		return 0;
	}
	UIATarget.localTarget().delay(2);
	
	var date = new Date()
	// open 2nd web page in tabbed view
	safari.openNewTabWithWebPage(webPage2);
	
	UIATarget.localTarget().delay(2);

	safari.waitForPageToLoad(timeout, {date:date});
	
	// verify we're on the right page
	var page = safari.activeURL();
	if (page != webPage2) {
		this.testError = "I'm on page: " + page + ".  I should be on page: " + webPage2;
		UIALogger.logError(this.testError);
		safari.reset();
		return 0;
	}
	
	// verify the tab is showing the correct URL
    if (UIATarget.localTarget().model() != 'iPad') {
        try {
            var tabButton = safari.visibleElementsWithName(safari.toolbar(), 'Pages')[0];
        } catch(e) {
            UIALogger.logError(e.message);
            this.testError = "Could not find the tab button";
            UIALogger.logError(this.testError);
            return this.testResult = 0;
        }
        tabButton.tap();
        
        UIATarget.localTarget().delay(2);
    }

	var textExists = safari.tabWithName(tabText).isValid();
	if (!textExists) {
		this.testError = "Couldn't verify the text in tab:  '" + tabText + "' exists in the Tab view.";
		UIALogger.logError(this.testError);
	}
	
	// close the new tab to clean up safari
	try {
		safari.closeTab();
	} catch(e) {
		UIALogger.logError(e.message);
		this.testError = "Could not close the tab";
		return this.testResult = 0;
	}
	UIATarget.localTarget().delay(2);
	
	safari.reset();
	if (this.testError) {
		return 0;
	} else {
		this.testResult = 1;
		return 1;
	}
}

//----------------------------------------------------------------------------------------
//	Function: safariTest_openWebPageFromPreviousTab 
//		Opens webPage1 page initially, then webPage2 in a second tab
//		navigates back to tab1 and verifies it loads properly
//
//	Parameters:  
//		webPage1 (string) - web page to open
//		webPage2 (string) - 2nd web page to open
//		tabText1 (string) - text in the first tab view to find and verify
//		tabText2 (string) - text in the second tab view to find and verify
// 
//	Returns:
//		1 if test passes, 0 if test fails.
//----------------------------------------------------------------------------------------
function safariTest_openWebPageFromPreviousTab() {
	this.testResult = 0;
	
	if (this.argv.length < 4) { 
		UIALogger.logError("Requires 2 web pages, and 2 sets of text to verify in order to run.");
		return 64;		
	}
	
	var webPage1 = this.argv[0];
	var webPage2 = this.argv[1];
	var tabText1 = this.argv[2];
	var tabText2 = this.argv[3];
	var timeout = 240;
	
	safari.reset();
	try {
		safari.closeAllTabs();
	} catch(e) {
		UIALogger.logError(e.message);
		this.testError = "Could not close all the tabs";
		return this.testResult = 0;
	}
	
	// do nothing until safari finishes loading the results
	try {
		safari.loadPageAndWait(webPage1, timeout);
	} catch(e) {
		UIALogger.logError(e.message);
		this.testError = "Safari never finished loading the initial page.  Bailing";
		UIALogger.logError(this.testError);
		return this.testResult = 0;
	}
	UIATarget.localTarget().delay(2);
	
	// open 2nd web page in tabbed view
	UIALogger.logMessage("Opening new tab: " + webPage2);
	try {
		safari.openNewTabWithWebPage(webPage2, timeout);
	} catch(e) {
		UIALogger.logError(e.message);
		this.testError = "Safari never loaded the page in a tab.  Bailing";
		UIALogger.logError(this.testError);
		return this.testResult = 0;
	}
	
	// verify we've on the right page
	var page = safari.activeURL();
	if (page != webPage2) {
		this.testError = "I'm on page: " + page + ".  I should be on page: " + webPage2;
		UIALogger.logError(this.testError);
		return this.testResult = 0;
	}
	
	// verify the tab is showing the correct URL
	UIALogger.logMessage("Going to the previous tab.");
    
    if (UIATarget.localTarget().model() != 'iPad') {
        //need to navigate to the tab view
        var tabButton = safari.visibleElementsWithName(safari.toolbar(), 'Pages')[0];
        if (!tabButton.isValid()) {
            this.testError = "Could not find the tab button";
            UIALogger.logError(this.testError);
            return this.testResult = 0;
        }
        tabButton.tap();	
        UIATarget.localTarget().delay(2);
    }
		
	UIALogger.logMessage("Now verifying the tab label for the second tab. Expected label is: " + tabText2);
	if (!safari.tabWithName(tabText2).isValid()) {
		this.testError = "Couldn't verify the text in tab:  '" + tabText2 + "' exists in the Tab view.";
		try {
			safari.closeAllTabs();
		} catch(e) {
			UIALogger.logError(e.message);
		}
		return this.testResult = 0;
	}
	
	UIALogger.logMessage("Now going to first tab");
	try {
		var previousTab = safari.goToTab(0);
	} catch(e) {
		this.testError = "Could not go to the previous tab";
		UIALogger.logError(this.testError);
		return this.testResult = 0;
	}
	
	UIALogger.logMessage("Now verifying the tab label for the first tab. Expected label is: " + tabText1);
	if (!safari.tabWithName(tabText1).isValid()) {
		this.testError = "Couldn't verify the text in tab:  '" + tabText1 + "' exists in the Tab view.";
		try {
			safari.closeAllTabs();
		} catch(e) {
			UIALogger.logError(e.message);
		}
		return this.testResult = 0;
	}
	
	var date = new Date()
	UIALogger.logMessage("Now selecting the first tab");
	//previousTab.tap();
	UIATarget.localTarget().tapWithOptions(previousTab.rect());
	
	try {
		safari.waitForPageToLoad(timeout, {date:date});
	} catch(e) {
		UIALogger.logError(e.message);
		this.testError = "Safari didn't finish loading the initial page, when it was viewed a second time.";
		try {
			safari.closeAllTabs();
		} catch(e) {
			UIALogger.logError(e.message);
		}
		return this.testResult = 0;
	}
	
	// verify we're on the right page
	var page = safari.activeURL();
	if (page != webPage1) {
		this.testError = "I'm on page: " + page + ".  I should be on page: " + webPage1;
	}
	
	UIALogger.logMessage("Closing Tabs");
	try {
		safari.closeAllTabs(); 
	} catch(e) {
		UIALogger.logError(e.message);
		this.testError = "Could not close the tabs";
		return this.testResult = 0;
	}
	UIATarget.localTarget().delay(2);
	
	if (this.testError) {
		return this.testResult = 0;
	} else {
		return this.testResult = 1;;
	}
}

//----------------------------------------------------------------------------------------
//	Function: safariTest_navigateWebPagesWithPreviousNextButtons 
//		Opens the specified webpages and then navigates Back/Forward in the order specified.
//
//	Parameters:  
//		url (string) - the url of the webpage to be loaded. Multiple webpages 
//			can be loaded. At least two urls should be specified for the 
//			the test to run. The webpages are loaded in the order they were 
//			specified. 
//		action (string) - can be 'Back' or 'Forward'. Multiple actions can be 
//			specified. At least one action is required for the test to run. 
//			The actions are executed in the order they were specified. If an 
//			action tries to go back/forward to a webpage that was not loaded as 
//			a part of the test, the action will be ignored.
//
//	Usage:
//		safariTest_navigateWebPagesWithPreviousNextButtons "url:http://www.amazon.com" 
//				"url:http://www.google.com" "action:Back" 
// 
//	Returns:
//		1 if test passes, 0 if test fails.
//----------------------------------------------------------------------------------------
function safariTest_navigateWebPagesWithPreviousNextButtons() {
	var webpages = UIAUtility.valuesForKey("url", this.argv, this.argv.length);
	var actions = UIAUtility.valuesForKey("action", this.argv, this.argv.length);
	
	//this one is there for backward compatibility
	if (!webpages && !actions && this.argv.length > 0) {
		UIALogger.logMessage("Using the old spec for this test. Please note that this spec is deprecated and should not be used.");
		webpages = this.argv;
		actions = ["Back", "Forward"];
	}
	
	if (!webpages || (typeof webpages != 'object') || webpages.length < 2) {
		UIALogger.logError("Requires at least 2 web pages to run.");
		return 64;
	}
	if (!actions) {
		UIALogger.logError("Requires at least 1 action to run.");
		return 64;	
	}	
	if (typeof actions != 'object') actions = [actions]; //make it an array, if not already one.
	
	safari.reset();
	
	UIALogger.logMessage("Need to load " + webpages.length + " webpages. Now loading...");
	var timeout = 240;
	for (var i=0; i<webpages.length; i++) {
		UIALogger.logMessage("Loading " + webpages[i]);
		try {
			safari.loadPageAndWait(webpages[i], timeout);
		} catch(e) {
			UIALogger.logError(e.message);
			this.testError = "Safari never finished loading the page: " + webpages[i];
			UIALogger.logMessage(this.testError);
			return this.testResult = 0;
		}
		webpages[i] = safari.activeURL(); //make sure you have the exact url
		UIATarget.localTarget().delay(1);
	}
	
	var currentPageIndex = webpages.length-1;
	
	UIALogger.logMessage("Now navigating backwards/forward. Need to do it " + actions.length + " times.");
	for (var i=0; i<actions.length; i++) {
		
		UIALogger.logMessage("Navigating " + actions[i]);
		
		UIALogger.logMessage("Making sure the action is valid...");
		var oldPageIndex = currentPageIndex; //in case, it needs to be reverted
		if (actions[i] == 'Back')  currentPageIndex--;
		else if (actions[i] == 'Forward') currentPageIndex++;
		
		//the action should not take us to a page that was not loaded as a part of the test
		if (currentPageIndex < 0 || currentPageIndex >= webpages.length) {
			UIALogger.logError("Invalid action. Skipping this action.");
			currentPageIndex = oldPageIndex;
			continue; 
		}
		
		var date = new Date();
		try {
			var navButton = safari.visibleElementsWithName(safari.toolbar(), actions[i])[0];
		} catch(e) {
			UIALogger.logError(e.message);
			this.testError = "Could not find the button: " + actions[i];
			UIALogger.logError(this.testError);
			return this.testResult = 0;
		}
		navButton.tap()
		UIATarget.localTarget().delay(2);
		
		// do nothing until safari finishes loading the results
		try {
			safari.waitForPageToLoad(timeout, {date:date});
		} catch(e) {
			UIALogger.logError(e.message);
			this.testError = "Safari never finished loading the page.";
			UIALogger.logError(this.testError);
			return 0;
		}
		
		// verify we're on the right page
		var expectedURL = webpages[currentPageIndex];
		var page = safari.activeURL();
		if (page != expectedURL) {
			this.testError = "Expected to be on page: '" + expectedURL + "'.  Ended up on: '" + page + "'.";
			UIALogger.logError(this.testError);
			return this.testResult = 0;
		}
		
		UIATarget.localTarget().delay(1);
	} //end of for loop
	
	return this.testResult = 1;
}

//----------------------------------------------------------------------------------------
//	Function: safariTest_copyFromWebPage 
//		Opens webPage, performs a double tap and hold on an
//		element at the specified offset and copies the default selected region.
//		
//
//	Parameters:  
//		url (string) - url for the page to open
//		elementPredicate (predicate) - element predicate to specify element to tqp on in the Webview
//		xOffset (number 0.0-1.0) - x offset within element being tapped (optional; defaults to 0.5)
//		yOffset (number 0.0-1.0) - y offset within element being tapped (optional; defaults to 0.5)
// 
//	Returns:
//		1 if test passes, 0 if test fails.
//----------------------------------------------------------------------------------------
function safariTest_copyFromWebPage() {
	if (this.argv.length < 2) { 
		UIALogger.logError("Requires a web page and an element query.");
		return 64;		
	}
	
	var url = this.argv[0];
	var elementPredicate = this.argv[1];
	
	var options = new Object(); options.tapOffset = new Object();
	options.tapOffset.x = (this.argv.length > 2) ? argv[2] : 0.5;	// default x offset is 50%
	options.tapOffset.y = (this.argv.length > 3) ? argv[3] : 0.5;	// default y offset is 50%
	
	var timeout = 30;
	
	safari.reset();	// includes safari launch
	
	var currentPage = safari.activeURL();
	if (currentPage != url) {
		try {
			safari.loadPageAndWait(url, 240);
		} catch(e) {
			this.testError = "Failed to load web page to be copied from.";
			safari.reset();
			return this.testResult = 0;
		}
		currentPage = safari.activeURL();
	}
	UIALogger.logError("Safari is on '" + currentPage + ".");
	
	// double tap and hold on the item at a specific offset	
	// doing this by performing a tap followed by a tap and hold at the moment because we have no 
	// double tap and hold synthetic event.  the tap and the tap and hold actions that follow 
	// need to be performed together and should not encounter any additional delay or this will fail
	
	var pageElement = safari.mainWindow().scrollViews()[0].webViews()[0].elements().firstWithPredicate(elementPredicate);
	if (!pageElement.isValid()) {
		this.testError = "Failed to locate page element to copy.";
		safari.reset();
		return this.testResult = 0;
	}

	//need to use target.tap to avoid delays that might occur from using element.tap
	UIATarget.localTarget().tapWithOptions(pageElement.rect(), options);
	options.duration = 2;
	UIATarget.localTarget().tapWithOptions(pageElement.rect(), options);
    
	try {
		safari.copyWithOptions(null, options);
	} catch(e) {
		UIALogger.logError(e.message);
		this.testError = "Failed copy operation.";
		safari.reset();
		return this.testResult = 0;
	}
	
	return this.testResult = 1;
}

//---------------------------------------------------------------------------------------------
//	Function: safariTest_mailLinkToPage 
//		Loads the specified webpage, and sends a link to the page using the
//		'Mail Link to this Page' option.
//
// Parameters:
//		url (string) - the url of the webpage whose link needs to be sent.
//		toAddress (string) - specifies the recipient of the email containing the link. 
//		subject (string) - the subject of the email that should be sent
//		shouldValidate (boolean) - true, if validation needs to be performed. It is set to 
//			true, by default. Validation involves checking if the email was received, and 
//			whether clicking on the link loads the webpage or not.
//
// Returns:
//     1 if the test passes
//     0 if the test fails
//---------------------------------------------------------------------------------------------
function safariTest_mailLinkToPage() {
	
	if (this.argv.length < 2) { 
		UIALogger.logError("Requires a 'url' and 'toAddress' to run.");
		return 64;		
	}
	
	var url = this.argv[0];
	var toAddress = this.argv[1];
	var date = new Date();
	var subject = "Mail Link Test " + date.getHours() + date.getMinutes() + date.getSeconds();
	var shouldValidate = true;
	if (this.argv.length > 2) subject = this.argv[2];
	if (this.argv.length > 3) shouldValidate = this.argv[3];
	
	safari.getToWebpageView();
	safari.loadPageAndWait(url, 240);		

	var url = safari.activeURL(); //exact url
	UIALogger.logDebug("The active url is " + url);
	
	safari.mailLinkToPage(toAddress, {subject:subject});
	
	if (shouldValidate == true || shouldValidate == "true") {
		UIALogger.logDebug("Need to validate that the email was received with subject: " + subject);
		
		UIALogger.logDebug("Checking that email with the subject '" + subject + "' was received.");
		mail.chooseEmail(subject, toAddress, "Inbox");

		var inThreadView = (mail.navigationBar().withPredicate("name matches '[0-9]+ Messages'").isValid());
		if (inThreadView) {
			UIALogger.logDebug("In 'ThreadView'. Select the first message");
			mail.mainWindow().tableViews()[0].cells()[0].tap();
		}
		
		var date = new Date();
		
		UIALogger.logError("Tapping the link in the email body...");
		mail.mainWindow().scrollViews()[0].webViews().firstWithPredicate("ANY links.name == '" + url + "'").links()[0].tap();
		
		//check that safari is active
		if (!safari.isActive()) {
			this.testError = "Safari did not launch after clicking the link";
			UIALogger.logError(this.testError);
			return this.testResult = 0;
		}
		
		UIALogger.logError("Waiting for the page to load...");
		safari.waitForPageToLoad(240, {date:date});
		
		var currentURL = safari.activeURL();
		if (currentURL != url) {
			this.testError = "Did not load the correct url.";
			UIALogger.logError(this.testError + ". Expected: " + url + ", got: " + currentURL);
			return this.testResult = 0;
		}
	}
	
	return this.testResult = 1;
}

//---------------------------------------------------------------------------------------------
//	Function: safariTest_printWebPage 
//		Loads the specified webpage, and prints the webpage.
//
// Parameters:
//		url (string) - the url of the webpage that should be printed.
//		printerName (string) - optional - the name of the printer. If no value is specified, 
//			a random printer is selected
//		numberOfCopies (number) - optional - the number of copies to print
//
// Returns:
//     1 if the test passes
//     0 if the test fails
//---------------------------------------------------------------------------------------------
function safariTest_printWebPage() {
	
	if (this.argv.length < 1) { 
		UIALogger.logError("Requires a 'url' to run.");
		return 64;		
	}
	
	var url = this.argv[0];
	var options = new Object();
	if (this.argv.length > 1 && this.argv[1] != "null") options.printerName = this.argv[1];
	if (this.argv.length > 2 && this.argv[2] != "null") options.numberOfCopies = this.argv[2];
	
	safari.getToWebpageView();
	safari.loadPageAndWait(url, 240);		
	
	var url = safari.activeURL(); //exact url
	UIALogger.logDebug("The active url is " + url);
	
	UIALogger.logDebug("Selecting the 'Print' option");
	safari.getToAddBookmarkView({alertButton:"Print"});
	
	safari.printWithOptions(options);

	return this.testResult = 1;
}


// Create self tests -- this is an unnamed function, just to make sure any local variables stay in the correct context
(function() {	
	if (typeof safari.selfTests == 'undefined') {
		safari.selfTests = new Array();
	}
	
	if (UIATarget.localTarget().model() == 'iPad') {
		var openWebPageInTabParameters = ["http://pttest.apple.com/perfmarketing-power/testcontent/smithsonian.html", "http://pttest.apple.com/perfmarketing-power/testcontent/google.html", "pttest.apple.com"];
		var openWebPageFromPreviousTabParameters = ["http://pttest.apple.com/perfmarketing-power/testcontent/smithsonian.html", "http://pttest.apple.com/perfmarketing-power/testcontent/google.html", "pttest.apple.com", "pttest.apple.com"];
	} else {
		var openWebPageInTabParameters = ["http://pttest.apple.com/perfmarketing-power/testcontent/smithsonian.html", "http://pttest.apple.com/perfmarketing-power/testcontent/google.html", "Google"];
		var openWebPageFromPreviousTabParameters = ["http://pttest.apple.com/perfmarketing-power/testcontent/smithsonian.html", "http://pttest.apple.com/perfmarketing-power/testcontent/google.html", "Smithsonian Institution", "Google"];
	}
	safari.selfTests.push(phtCreateTest("LoadSafariPage", ["http://pttest.apple.com/perfmarketing-power/testcontent/digg.html"], safariTest_loadSafariPage, "Load web page in Safari"));
	safari.selfTests.push(phtCreateTest("CrawlWeb", ["http://news.google.com", 5], safariTest_crawlWeb, "Crawl through five links from news.google.com"));
	safari.selfTests.push(phtCreateTest("LoadRandomBookmark", null, safariTest_loadRandomBookmark, "Load Random Bookmark"));
	safari.selfTests.push(phtCreateTest("AddBookmark", ["http://pttest.apple.com/perfmarketing-power"], safariTest_addBookmark, "Add bookmark"));
	safari.selfTests.push(phtCreateTest("AddWebClip", ["http://pttest.apple.com/perfmarketing-power"], safariTest_addBookmarkToHomeScreen, "Add a webclip"));
	safari.selfTests.push(phtCreateTest("MailLinkToPage", ["http://pttest.apple.com/perfmarketing-power", "weliketesting@me.com"], safariTest_mailLinkToPage, "Mail a link to a page"));
	safari.selfTests.push(phtCreateTest("PerformGoogleSearch", ["I can has cheezburger", "icanhascheezburger.com", false], safariTest_performGoogleSearch, "Perform a Google search"));
	safari.selfTests.push(phtCreateTest("SelectItemFromSuggestionList", ["www.appl", "apple.com/", "http://www.apple.com/"], safariTest_selectItemFromSuggestionList, "Select an item from the Suggestion List"));
	safari.selfTests.push(phtCreateTest("RefreshPage", ["http://pttest.apple.com/perfmarketing-power/testcontent/smithsonian.html"], safariTest_refreshPage, "Refresh page"));
	safari.selfTests.push(phtCreateTest("ClickOnURL", ["http://pttest.apple.com/perfmarketing-power/", "flickr.html"], safariTest_clickOnURL, "Click on URL"));
	safari.selfTests.push(phtCreateTest("OpenWebPageInTab", openWebPageInTabParameters, safariTest_openWebPageInTab, "Open a web page in a Tab"));
	safari.selfTests.push(phtCreateTest("OpenWebPageFromPreviousTab", openWebPageFromPreviousTabParameters, safariTest_openWebPageFromPreviousTab, "Open a web page from a previous tab"));
	safari.selfTests.push(phtCreateTest("NavigateBackForward", ["http://pttest.apple.com/perfmarketing-power/testcontent/smithsonian.html", "http://pttest.apple.com/perfmarketing-power/testcontent/caltrain.html"], safariTest_navigateWebPagesWithPreviousNextButtons, "Navigate with the Back / Forward buttons"));
	safari.selfTests.push(phtCreateTest("RandomFlickAndDragPage", ["http://pttest.apple.com/perfmarketing-power/testcontent/digg.html", true, "flicksAndDrags"], safariTest_loadSafariPage, "Load digg.com and randomly flick and drag on the page"));
	safari.selfTests.push(phtCreateTest("RandomZoomOnPage", ["http://pttest.apple.com/perfmarketing-power/testcontent/digg.html", true, "doubleClickZoomIn", "doubleClickZoomOut"], safariTest_loadSafariPage, "Load digg.com and randomly zoom in and out on the page"));
	safari.selfTests.push(phtCreateTest("RandomFlickDragAndZoomOnPage", ["http://pttest.apple.com/perfmarketing-power/testcontent/digg.html", true, "flicksAndDrags", "doubleClickZoomIn", "flicksAndDrags", "pinchZoomOut"], safariTest_loadSafariPage, "Load digg.com and randomly flick, then zoom, then flick, then zoom"));
	safari.selfTests.push(phtCreateTest("CopyFromWebPage", ["http://pttest.apple.com/perfmarketing-power/testcontent/disney.html", "name contains 'Tigger & Pooh'"], safariTest_copyFromWebPage, "Copy text from a web page onto the pasteboard."));
	if (system.hasCapability("multitasking")) {
		safari.selfTests.push(phtCreateTest("PrintWebPage", ["http://pttest.apple.com/perfmarketing-power/testcontent/disney.html", "dailyQLAutomation"], safariTest_printWebPage, "Print a web page from Safari"));
	}
	//safari.selfTests.push(phtCreateTest("PlayQuicktimeMovie", playQuicktimeMovieParameters, safariTest_playQuicktimeMovie, "Plays a quicktime movie."));
}())