#################################################################################################
#                                                                                               #
#   ScriptName: printStatistics.sh                                                              #
#                                                                                               #
#   Usage:      <path_to_Script>/printStatistics.sh                                             #
#                                                                                               #
#   Purpose:    This Scripts helps in printing the Statistics for Stress Tests                  #
#                                                                                               #
#   Author:     Jerome Jesu                                                                     #
#   Contact:    jesu@apple.com                                                                  #
#   Version:    v20                                                                             #
#                                                                                               #
#   Copyright   2010 Apple. All rights reserved.                                                #
#################################################################################################


TOOLSDIR="/usr/local/bin"

###########################################################################
# Function take a *KOOL*STATE# when any failure happens
# Failure message $1 is stored as the User Explanation for the failure.
###########################################################################
generateFileNames()
{
	SUFFIX1=`echo $DEVICENAME | perl -lne '($s,$m,$H,$d,$M,$Y,$D) = localtime(); $Y += 1900; $M++; printf ("STATS_%s-%02d%02d-%02d%02d%02d",$_,$M,$d,$H,$m,$s); ' `
	SUFFIX2=`echo $DEVICENAME | perl -lne '($s,$m,$H,$d,$M,$Y,$D) = localtime(); $Y += 1900; $M++; printf ("LOGS_%s-%02d%02d-%02d%02d%02d",$_,$M,$d,$H,$m,$s); ' `
	SUFFIX3=`echo $DEVICENAME | perl -lne '($s,$m,$H,$d,$M,$Y,$D) = localtime(); $Y += 1900; $M++; printf ("CRASHES_%s-%02d%02d-%02d%02d%02d",$_,$M,$d,$H,$m,$s);'`
	ResultsFile="/var/root/$SUFFIX1.csv"
	LOGSFILE="/var/root/$SUFFIX2.log"
	CsiLogsFile="/var/root/$SUFFIX3.csv"
}



###########################################################################
# Function take a *KOOL*STATE# when any failure happens
# Failure message $1 is stored as the User Explanation for the failure.
###########################################################################
takeK00lState()
{
		/usr/local/bin/scripter -f /usr/local/etc/scripter/general/Interact.js com.apple.springboard "dismissAlerts(app)"
        /usr/local/bin/testCT -c "*5005*78283#"
        sleep 1
        #touch the Reply Button
        eventer t 175 415
		echo "String - $1."
        eventer w $1
        sleep 1
        #touch the Send button
        eventer t 268 29
}


#########################################################
# STOP and START LOCMON on the background every 25 iterations
#########################################################
stopStartLocmon()
{
	echo "Entering Function to check whether GPS is running... "
	echo "Starting Locmon to stress the GPS and Baseband..."
	#echo "Finding Process.."
	#PIDS=`ps -A | grep locmon | perl -lne ' if ( !/grep/ ) { @L = split; $L[0] =~ s/\s*//g; print $L[0];} ' `
	echo "Killing Processes  --- $PIDS.\n"
	#echo `date` ": _____Locmon Process IDs-> $PIDS - $dcount _____"  >> $LOGSFILE
	#kill $PIDS
	killall -9 locmon
	echo `date` ": _____Locmon STOP - $dcount _____"  >> $LOGSFILE
	sleep 30
	$TOOLSDIR/locmon -l -i 2> locmonStressTest.txt &
	echo `date` ": _____Locmon START - $dcount _____"  >> $LOGSFILE
}



###########################################################################
#Function to Convert given run time in seconds to HH:MM:SS
# USAGE: calculateTime RUN_TIME (in seconds) [1 to output to Stats file, 0 otherwise] 
###########################################################################
calculateTime()
{
	runTime=$1;
	hours=$(($runTime / 3600)); hours2=$(($hours * 3600));
	mins2=$(($runTime - $hours2)); mins=$(($mins2 / 60));
	abSecs=$(($hours * 3600 + $mins * 60)); secs=$(($runTime - $abSecs));
	if [ $hours -lt 10 ]; then  hours=`echo "0$hours"`;  fi
	if [ $mins -lt 10 ];  then  mins=`echo "0$mins"`;    fi
	if [ $secs -lt 10 ];  then  secs=`echo "0$secs"`;    fi
	totalTime="$hours:$mins:$secs"
	if [ $2 -eq 1 ]; then echo " Total RunTime : $totalTime, RunTime (in secs): $runTime." >> Stats.txt;	fi
	echo $totalTime
}

###########################################################################
# Function to calculate Percentages
# USAGE: calculatePercent <total Fails/Pass> <Total>
###########################################################################
calculatePercent()
{
	if [ $2 -ne 0 ]; then  Percent=$((100 * $1 / $2)); fi
	echo $Percent
}

###########################################################################
# FUNCTION to process the CSI logs and report the number of crashes and Call Drops
###########################################################################
processCsiLogs()
{
	echo `date` ": _____PROCESSING CSI LOGS - $dcount _____"  >> $LOGSFILE
	totalCsiLogs=`ls $csiLogsDir/*csi* | wc -l | awk '{print $1}'`
	totalModemResets=`cat /tmp/crashReasons | grep "modem reset" | wc -l | awk '{print $1}'`
	totalAtTimeouts=`cat /tmp/crashReasons | grep -i "timeout" | grep "AT" | grep -v "modem reset" | wc -l | awk '{print $1}'`
	totalASM=`cat /tmp/crashReasons | grep -i "Fatal Error"| wc -l | awk '{print $1}'`
	totalLocationdError=`cat /tmp/crashReasons | grep -i "locationd qmux"| wc -l | awk '{print $1}'`
	totalTempTimeouts=`cat /tmp/crashReasons | grep "temperature update" | grep -v "modem reset" | wc -l | awk '{print $1}'`
	totalBasebandCrashes=`cat /tmp/crashReasons | grep "baseband crash"| wc -l | awk '{print $1}'`
	totalTraceDiag=`cat /tmp/crashReasons | grep "Trace DIAG"| grep -i config | wc -l | awk '{print $1}'`
	totalCallFailures=`cat /tmp/crashReasons | grep -i "call fail" | wc -l | awk '{print $1}'`
	totalCallDrops=`cat /tmp/crashReasons | grep -i "call drop"| wc -l | awk '{print $1}'`
	totalDumps=`cat /tmp/crashReasons | grep "Dump" | wc -l | awk '{print $1}'`
	totalUserDumps=`cat /tmp/crashReasons | grep "User" | wc -l | awk '{print $1}'`
	totalFTO=`cat /tmp/crashReasons | grep "FTO" | wc -l | awk '{print $1}' `
	totalBBResets=$(($totalModemResets + $totalBasebandCrashes + $totalAtTimeouts + $totalTempTimeouts + $totalASM + $totalTraceDiag + $totalLocationdError))
	totalLogs=$(($totalBBResets + $totalCallFailures + $totalCallDrops + $totalDumps + $totalUserDumps + $totalFTO))
	totalOthers=$(($totalCsiLogs - $totalLogs))

	echo "\n ****************  LOG DETAILS:  *********************"
	echo "RESETS-$totalModemResets  CRASHES-$totalBasebandCrashes  ASM-$totalASM"
	echo "FAIL-$totalCallFailures,  DROPS-$totalCallDrops, DUMPS-$totalDumps, USERDUMPS-$totalUserDumps"
	echo "FTO-$totalFTO,  OTHERS-$totalOthers"
	
	if [ $minUpTime -eq 0 ] && [ $totalBBResets -gt 0 ]; then
		ls $logFiles | perl -lne '@C = stat($_); $f = $_; open (F, $f); 
			while (<F>) {
				chomp; if (/\QReason: \E/) { 
				$m = (split /:/)[1];  
				if ($m !~ /call/i && $m !~ /dump/i && $m !~ /FTO/ && $m !~ /user/i && $m !~ /location/i) { 
					$t = @C[9]; print "$f:$m:$t"}; 
					last;
			} }' > /tmp/firstCrash
			
		firstResetTime=`perl -e '
			END{ $file = (sort {$H{$a} <=> $H{$b}} keys %H)[0]; print "$H{$file}";} 
			open (F, "/tmp/firstCrash") || print "$!.\n"; 
			while (<F>) {
				$f = (split /:/)[0]; $H{$f} = (split /:/)[2];}'`
				
		echo "First Reset Time - $firstResetTime"
		if [ $firstResetTime -lt 0 ]; then firstResetTime=0; fi
	fi
} 


logDataDownloadFailures()
{
	echo `date` ": _____LOGGING DATA DOWNLOAD FAILURES - $dcount _____"  >> $LOGSFILE
	isLowThroughput=0; lowThroughputTracker=0;
	
	isDataPASS=`perl -lne 'BEGIN {$count = 0; }  END { print "$count"; }  if (/Mean Throughput|Average Throughput/) { @w = split; $count++ if ( $w[4] =~ /^\d{1,3}[.]\d{1,4}/ & $w[4] !~ /^[0]{1,3}[.][0]{3,}/ ); } ' /tmp/DownloadDummy.txt`
	
	throughput=`cat /tmp/DownloadDummy.txt | egrep "Mean Throughput|Average Throughput" |
				perl -lne '	BEGIN {$rate = 0; }   END { print "$rate"; }  @w = split; 
					if ( $w[4] =~ /^\d{1,3}[.]\d{1,5}/ & $w[4] !~ /^[0]{1,3}[.][0]{3,}/ ) { $rate = $w[4] } ' `

	isLowThroughput=`echo "$throughput,${MIN_DATA_RATE}" | perl -lne '($r,$t)= (split /,/);  if ($r <= $t) { print "1"} else {print "0"}'`
	
	if [ $isDataPASS -gt 0 ]; then
		((dataPassCount++))
		if [ $dataFailTracker -ge 5 ]; then killall -9 tcpdump; fi
		dataFailTracker=0
		startTcpDump=0
	else
		((dataFailCount++))
		((dataFailTracker++))
	fi

	

	if [ $isLowThroughput -gt 0 ]; then
		maxLowThptAttempts=$(($lastlowThroughput + 5));
		if [ $DataAttempts -gt $lastlowThroughput ] && [ $DataAttempts -le $maxLowThptAttempts ]; then 
			echo `date` ": LowThroughput hit"
			((lowThroughputTracker++));	
		else
			echo `date` ": LowThroughput hit but resetting to zero"
			lowThroughputTracker=0;
			killall -9 tcpdump;
			startTcpDump=0
			lastlowThroughput=$DataAttempts;
		fi
	fi
	
	
	if [ $startTcpDump -eq 0 ]; then
		if [ $dataFailTracker -ge ${MIN_DATA_FAIL_ATTEMPTS} ] || [ $lowThroughputTracker -ge ${MIN_DATA_FAIL_ATTEMPTS} ]; then 
			startTcpDump=1
			nohup /usr/sbin/tcpdump -i pdp_ip0 -s 65000 -w /var/wireless/Library/Logs/CrashReporter/DataDownloadError_${dcount}.dump  &
		fi
	fi
	
	if [ $dataFailureLogs -eq 1 ]; then 
		if [ $dataFailTracker -ge ${MAX_DATA_FAIL_ATTEMPTS} ]  ||  [ $lowThroughputTracker -ge ${MAX_DATA_FAIL_ATTEMPTS} ];  then
			sleep 2
			#ping -c 100 -f 74.125.224.116
			date
			DataContext up
			DataContext -c 2 up
			ping -c 25 74.125.224.116 &
			ping -c 25 -b pdp_ip2 74.125.224.116
			sleep 2
			#((smsCount++))
			#failureMessage="$DEVICENAME - $BB_Build - $APBUILD - $dcount: $SMS_NUMBER - $dcount. Data Download Fail or Low Throughput 10 times continuously ";
			#echo "MESSAGE ==> $failureMessage. Sending SMS now to $MYPHONE"
			#sendSMS $MYPHONE $smsCount "$failureMessage"
			echo `date` ": Dumping logs after Data Dowload Failure or Low Throughput" 
			if [ $lowThroughputTracker -ge ${MAX_DATA_FAIL_ATTEMPTS} ];  then
				${TESTCT} -l "LowThroughput on PDP-$pdpid ${MAX_DATA_FAIL_ATTEMPTS} times - $dcount : $DEVICENAME";
				lowThroughputTracker=0;
			else
				${TESTCT} -l "DataDownloadFailed on PDP-$pdpid ${MAX_DATA_FAIL_ATTEMPTS} times - $dcount : $DEVICENAME";
				dataFailTracker=0
			fi
			sleep 10;
			startTcpDump=0
			killall -9 tcpdump
		fi
	fi
	
	dataFailCount1=$(($DataAttempts - $dataPassCount))
	echo "******** Download Attempts -> $DataAttempts; Data Fail Count -> $dataFailCount; FailCount1 -> $dataFailCount1, Data Pass Count -> $dataPassCount---$isDataPASS  - $throughput " >> DownloadStressTest.txt	
	echo "******** lowThroughputTracker - $lowThroughputTracker; lastlowThroughput - $lastlowThroughput;  dataFailTracker - $dataFailTracker." >> DownloadStressTest.txt	
		
	#isDataFAIL=`perl -lne ' BEGIN {$count = 0; }  END { print "$count" }  if (/Mean Throughput|Average Throughput/) { @w = split; $count++ if ( $w[4] =~ /^[0][.][0]{3,}/ | $w[4] =~ /\d{3,}[.]\d{3,}/ | $w[4] =~ /inf/); } ' /tmp/DownloadDummy.txt`	
	#isLowThroughput=`perl -lne ' END { if ($rate < .200) { print "1" } else { print "0"} }  
	#	if (/Mean Throughput|Average Throughput/) { @w = split; 
	#		if ( $w[4] =~ /^\d{1,3}[.]\d{1,4}/ & $w[4] !~ /^[0]{1,3}[.][0]{3,}/ ) { $rate = $w[4] } else { $rate = 0 } 
	#	} ' /tmp/DownloadDummy.txt `

}


###########################################################################
# Function to print the IPC Stress Test statistics to a CSV File.
###########################################################################
printIPCStatistics()
{
	# Process all the CSI Logs to find the number of crahses/call drops/call failures.
	cp  $logFiles  $csiLogsDir/
	#ls $logFiles | perl -lne '$file =~ s/(.*)(\Qcsi.plist\E)/$1/g; 
	#	$w="*"; open (F, $_); $firstLine = <F>;  
	#	system `mv $file$w RemovedLogs/` if ($firstLine =~ /Dump/i); 
	#	close F; '

	ls $csiLogsDir/*csi* | perl -lne '
						$f = $_; open (F, $f); $f =~ s/(.*\Qlog-bb-\E)(.*)(\Q-csi.\E(.*))/$2/; 
						while (<F>) { chomp; if (/\QReason: \E/) { 
							s/^(.*Reason: )//; s/--/_/g; s/,/_/g;   
							if ( /ATCS_TIMEOUT/ ) { s/(txid=\d+\s+)(msgid)/$2/; s/on message for svc=\d+\s+client=\d+\s+//;  }
							s/(times)(\s[-]\s\d+\s:\s.*)$/$1/ if ( /DataDownloadFailed|LowThroughput/ );
							$i=$_; print "$i,$f" if (! /Dump State/ig); last; } 
						} close F; 
				'  > /tmp/crashReasons
	
	
	# Process CSI Logs to get crash breakdowns
	processCsiLogs
		
	#ls $crashDir/*.plist $wirelessDir/*.plist $mobileDir | perl -lne '$f = (split /\//)[-1]; if (! /LatestCrash/g &&  ! /SystemLog/  && ! /aggregated/g ) { $f =~ s/(\D+)?[_-](.*)(.plist)$/$1$2/ ;  print "$1,$2"; }' >> /tmp/crashReasons
	ls $crashDir/*plist $wirelessDir/*plist $mobileDir/*plist $mobileDir/Retired/*plist | 
		perl -lne '
			$f = (split /\//)[-1]; 
			if (! /LatestCrash/g &&  ! /SystemLog/  && ! /aggregated/g) { 
				$f =~ s/^(.+)[_-](\d{4}-\d{2}-\d{2}-\d{6})(.*)(.plist)$/$1$2$3/; 
				print "$1,$2"; }
		'  >> /tmp/crashReasons
	cp /tmp/crashReasons crashReasons
	
	
	# Find out the Crashes/call failure statistics with Time stamp based on the CSI/Crash Logs.	
	echo "\nDEVICE:, $DEVICENAME\n" > $CsiLogsFile
	echo `date` ", Crash Reasons Summary." >> $CsiLogsFile
				
	perl -e 'open (F, "/tmp/crashReasons"); 
		while (<F>) { chomp; ($r,$t) = split/,/; $C{$r}++; push (@{$H{$r}},$t); } 
		close F; 
		foreach $k (keys %H) {
		print ("$k,$C{$k}, ",join(", ", @{$H{$k}},"\n") )} 
	' >> $CsiLogsFile
	
	crash=`perl -e '
		open (F, "/tmp/crashReasons"); 
		while (<F>) { 
			chomp; 
			($r,$t) = split/,/; 
			$C{$r}++; 
			push (@{$H{$r}},$t); } 
		close F; 
		foreach $k (keys %H) {
			print ("$k,$C{$k},",join(",", @{$H{$k}},"::::") ) if ($k !~ /call |fto|core|aggregated/i && $k !~ /^\s*$/);
		} '`
	
	testCurrentTime=$2
	testStartTime=$1	
	tcurTime="0"
	tcurTime=`date -r $testCurrentTime | cut -c5-19`
	tStartTime=`date -r $testStartTime | cut -c5-19`
	runTime=$(($testCurrentTime - $testStartTime))
	tRunTime=`calculateTime $runTime 255`
	if [ $totalBBResets -ne 0 ]; then	avgUpTime=$(($runTime / $totalBBResets)); 
	else	avgUpTime=$runTime;  fi
		
	tavgUpTime=`calculateTime $avgUpTime 255`
	echo "Average UpTime....  $tavgUpTime. Last Log Time - $checkTimeForUploadingStats, $lastLogTime seconds.\n"

	callFailPercent=`calculatePercent $fail $callCount`
	smsFailPercent=`calculatePercent $sfail $smsCount`
	callDropPercent=`calculatePercent $totalCallDrops $smsCount`

	lastLogTime=$tcurTime
	if [ $minUpTime -le 0 ]; then  minUpTime=$(($firstResetTime - $startTime)); fi

	echo "Calculating Download Data Rate/Failures..."		
	calculateDownloadRates
	
	echo "Calculating Upload Data Rate/Failures..."
	#calculateUploadStatsiPerf
	calculateUploadStatsStreamPerf

	echo "Calculating Failure %s..."
	downloadFailPercent=`calculatePercent $dataFailCount $DataAttempts`
	uploadFailPercent=`calculatePercent $uploadFailCount $uploadAttempts`
	dataFailPercent="$downloadFailPercent %--$uploadFailPercent %"
	echo "DataUploadFail - $DataUploadFail"
		
	
	echo `date` ": _____PRINTING STATS - $dcount _____"  >> $LOGSFILE
	echo "START_TIME, CURRENT_TIME, MEID, DEVICE_NAME, AP_BUILD, BB_BUILD, ITERATIONS, Total BB RESETS, Total_CALLS, Total_SMS, CALL_DROPS, CALL_FAILURES, FTOs, Download_Attempts, Download Pass, Download Fails, DataFailPercent, DownloadDataRate, Upload_Attempts, UploadDataRate, CallFails_CT, SMSFails_CT, START_TIME(s), CURRENT_TIME(s), RUN_TIME(s), FirstResetTime(s), D3, PDPActAttempts, PDPActFAIL, UDID, RUN_TIME (Hours), SCRIPT, Hardware, SERIAL, TARGET, Min Data Rates, Max Data Rates, MDN, SNUM, MMS, MMS Fail, CRASHES, "
	echo "$tStartTime, $tcurTime, $MEID, $DEVICENAME, $APBuild, $BB_Build, $dcount, $totalBBResets, $callCount, $smsCount, $totalCallDrops, $totalCallFailures, $totalFTO, $DataAttempts, $dataPassCount , $dataFailCount5, $dataFailPercent, $downloadDataRate, $uploadAttempts, $uploadDataRate, $fail, $sfail, $testStartTime, $testCurrentTime, $runTime, $minUpTime, $dataFailCount --$dataFailCount2, $pdpAttempts, $pdpFails, $UDID, $tRunTime, $scriptname, $Hardware, $SERIAL, $LOOPS, $MinDownloadRate -- $MinUploadRate, $MaxDownloadRate -- $MaxUploadRate, $PhoneNumber, $SNUM, $mmscount, $mmsFail, $crash, "
	echo "$tStartTime, $tcurTime, $MEID, $DEVICENAME, $APBuild, $BB_Build, $dcount, $totalBBResets, $callCount, $smsCount, $totalCallDrops, $totalCallFailures, $totalFTO, $DataAttempts, $dataPassCount , $dataFailCount5, $dataFailPercent, $downloadDataRate, $uploadAttempts, $uploadDataRate, $fail, $sfail, $testStartTime, $testCurrentTime, $runTime, $minUpTime, $dataFailCount --$dataFailCount2, $pdpAttempts, $pdpFails, $UDID, $tRunTime, $scriptname, $Hardware, $SERIAL, $LOOPS, $MinDownloadRate -- $MinUploadRate, $MaxDownloadRate -- $MaxUploadRate, $PhoneNumber, $SNUM, $mmscount, $mmsFail, $crash, " >> $ResultsFile
		
}

calculateUploadStatsStreamPerf()
{
	# Using StreamPERF
	uploadDataRate=`perl -lne ' 
			END { printf ("%0.03f", $sum/$count); }
			if (/^\QINFO: \E\(\d{1,}\)/) { 	@w = split; 
			if ($w[4] =~ /^\d{1,2}[.]\d{1,6}/  & $w[4] !~ /^[0]{1,3}[.][0]{3,}/ ) { 
				$count++; $sum += $w[4] } 
		}' UploadStressTest.txt`

	DataUploadFail=`perl -lne ' 
			END { $count=0 if (! defined $count); print "$count" }  
			if (/Mean Throughput|Average Throughput/) { 
			@w = split; 
			$count++ if ( $w[4] =~ /[0]{1,}[.][0]{3,}/ | $w[4] =~ /\d{3,}[.]\d{3,}/  | $w[4] =~ /inf/  | $w[4] =~ /nan/ ); 
		} ' UploadStressTest.txt` 
	MinUploadRate=`grep Average UploadStressTest.txt | awk '{print $5}' | perl -lne ' print if (! /inf|nan/); ' | sort | head -1`
	MaxUploadRate=`grep Average UploadStressTest.txt | awk '{print $5}' | perl -lne ' print if (! /inf|nan/); ' | sort | tail -1`

}

calculateUploadStatsiPerf()
{
	uploadDataRate=`perl -lne ' 
			END { if (defined $count) {  printf ("%0.03f", $sum/$count); 
				} else { print "0";} } 
			$rate = (split/\s+/)[-2]; 
			if ($rate =~ /^\d+$|^\d+[.]/ && $rate != 0) { $count++; $sum += $rate;} ' DataUploadStress.txt `
		
	DataUploadPass=`perl -lne ' 
			BEGIN { $passcount = 0; }
			END { print $passcount; } 
			$rate = (split/\s+/)[-2]; 
			$passcount++ if ($rate != 0 && $rate =~ /^\d+|^\d+[.]/);' DataUploadStress.txt`
	DataUploadFail=$(($uploadAttempts - $DataUploadPass))
	MinUploadRate=`cat DataUploadStress.txt | awk '{print $7}' | sort | head -1`
	MaxUploadRate=`cat DataUploadStress.txt | awk '{print $7}' | sort | tail -1`
}


calculateDownloadRates()
{
	dataFailCount2=`perl -lne ' 
			END { $count=0 if (! defined $count); print "$count" }  
			if (/Mean Throughput|Average Throughput/) { 
			@w = split; 
			$count++ if ( $w[4] =~ /[0]{1,}[.][0]{3,}/ | $w[4] =~ /\d{3,}[.]\d{3,}/  | $w[4] =~ /inf/  | $w[4] =~ /nan/  ); 
		} ' DownloadStressTest.txt` 
			
	downloadDataRate=`perl -lne ' 
			END { printf ("%0.03f", $sum/$count); }
			if (/^\QINFO: \E\(\d{1,}\)/) { 	@w = split; 
			if ($w[4] =~ /^\d{1,3}[.]\d{1,6}$/ & $w[4] !~ /^[0]{1,3}[.][0]{3,}/ ) { 
				$count++; $sum += $w[4] } 
		}' DownloadStressTest.txt`

	if [ $dataFailCount3 -gt $DataAttempts ]; then dataFailCount3=$dataFailCount2; fi
	MinDownloadRate=`grep Average DownloadStressTest.txt | awk '{print $5}' | perl -lne ' print if (! /inf|nan/); ' | sort | head -1`
	MaxDownloadRate=`grep Average DownloadStressTest.txt | awk '{print $5}' | perl -lne ' print if (! /inf|nan/); ' | sort | tail -1`
	echo " Data Fail Counters - 1=$dataFailCount, 2=$dataFailCount2, 3=$dataFailCount3---$isDataFAIL"
	echo " Data Pass Count - $dataPassCount --- $isDataPASS."

}

