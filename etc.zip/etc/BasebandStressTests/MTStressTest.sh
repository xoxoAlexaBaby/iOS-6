#!/bin/sh

#################################################################################################
#                                                                                               #
#   ScriptName: CalltressTest.sh                                                                #
#                                                                                               #
#   Usage:      nohup <path_to_Script>/IPCStressTest.sh  <Device_Phone_Number>  <Iterations> &  #
#                                                                                               #
#   Purpose:    To run stress tests on the device stressing the IPC. The script keeps running   #
#               Data downloads, make calls, Send/Receive SMS continuously until the Iterations  #
#               specified.                                                                      #
#               The purpose of the script is to ensure the stability of the Baseband/AP builds  #
#                                                                                               #
#   Author:     Jerome Jesu                                                                     #
#                                                                                               #
#   Revisions:   v2                                                                             #
#################################################################################################
SCRIPTS_DIR="/usr/local/etc/BasebandStressTests"
# GETTING Config INFO
source $SCRIPTS_DIR/config.sh

calledNumber=0
callingNumber=0
iterations=0
interval=60
stress2G=0  # Default is 0
#Hardware=`/usr/local/bin/lockdown_query get NULL HardwareModel 2>&1 | sed 's/AP//'; `


Usage()
{
	echo "\nUSAGE: $0  -c <MO Number>  -i <iterations>  [ -n <MT Number>  -t <Call Interval in seconds. Default=60>  -r <0 | 1>]"
	echo "		example: $0   -c 4085505132   -i 100  [ -t 10    -n 4085505133  -r 1]"
	echo "                    -r 1 is to run on 2G. Default 0 if not specified.\n"
	exit
}



######## PARAMETERS VALIDATION
while getopts 'c:i:n:t:r:h' OPTION; 
do
	case "$OPTION" in
		c )	callingNumber=1
			MONumber="$OPTARG"
			callingNumber=`echo $MONumber | perl -lne ' s/[+]//g; if (/\D/g) { print "0";} else { print "1";};' `;;
		i )	iterations=1; LOOPS="$OPTARG";;
		n ) calledNumber="$OPTARG"
			calledNumber=`echo $calledNumber | perl -lne ' s/[+]//g; if (/\D/g) { print "0";} else { print "1";};' `;;
		t )	interval="$OPTARG";;
		r )	stress2G="$OPTARG"; echo "Stress Test for 2G MT Calls";;
		h ) Usage; exit 1;;
		/?)	echo "INVALID OPTIONS.\n"; exit 1;;
	esac
done
shift $(($OPTIND - 1))

if [ $callingNumber -ne 1 ] && [ $iterations -ne 1 ]; then
	Usage;
	exit 0
fi

if  [ $interval -le 30 ]; then 	interval=60; fi


if [ $stress2G -eq 1 ]; then
	echo " Switching to 2G"
	if [ $HARDWARE == "N90" ]; then	
		echo "${SEND_AT_COMMAND} -v -d ${DLCI_DEV_NODE} +xact=0,0"
		${SEND_AT_COMMAND} -v -d ${DLCI_DEV_NODE} +xact=0,0
	else
		${SEND_AT_COMMAND} -v -d ${DLCI_DEV_NODE} +cops=2
		sleep 3
		echo "${SEND_AT_COMMAND} -v -d ${DLCI_DEV_NODE} +xrat=0,0"
		${SEND_AT_COMMAND} -v -d ${DLCI_DEV_NODE} +xrat=0,0
		sleep 2
		${SEND_AT_COMMAND} -v -d ${DLCI_DEV_NODE} +cops=0
	fi
	sleep 5
	eventer h
	echo " Switched to 2G"
fi


#CallingNumber=`echo $MONumber | perl -lne ' s/[+]//g; @L = split //;  s/^([1])(\d{10})$/$2/  if (@L > 10); print;' `
PhoneNumber=`echo ${PHONE_NUMBER} | perl -lne 's/[(]|[)]|\s+|[-]//g; s/^([1])(.*)$/+$1$2/; print;' `
flag=`echo $PhoneNumber | perl -lne ' s/[+]//g; if (/^\d{10,11}$/ && $_ !~ /[0]{6,}/ ) { print "1";} else { print "0";};' `
if [ $flag -eq 1 ];  then  
	MTNumber=$PhoneNumber
elif [ $calledNumber -eq 1 ];  then  
	MTNumber=$calledNumber; 
else  
	echo "I can't get the Phone Number of the device or it is invalid. Please specify it using option -n <MT NUMBER>"
fi
echo "MTNumber - $MTNumber, FLAG = $flag, MO Number = $MONumber, Iterations = $LOOPS, Interval = $interval"



############################################################################################
initialize()
{
		#/usr/bin/SendATCommand -d /dev/dlci.spi-baseband.extra_0 S0=1
		${TESTCT} -c "*5005*2267#"
		rm /var/mobile/CallsStats.txt
		if [ $(($COUNT % 10)) -eq 1 ]; then
			killall -9 SMSBuddy
			/usr/local/bin/SMSBuddy &
		fi
	
		# kill any stray CTM processes from previous iterations/runs and end all active calls
		killall -9 CoreTelephonyMonitor					
		/usr/local/bin/scripter -f /usr/local/etc/scripter/general/Interact.js com.apple.springboard "dismissAlerts(app)"
		koolStateFlag=0
		callPassed=0;  callStatus=0; 
		MoCallCount=0
}

# Function to get the S/w Version Numbers of AP and Baseband Firmware
getBuildVersions()
{
		BB=`${LOCKDOWN_QUERY} get NULL BasebandVersion 2>&1`
		DeviceName=`${LOCKDOWN_QUERY} get NULL DeviceName 2>&1`
		IMEI=`${LOCKDOWN_QUERY} get NULL InternationalMobileEquipmentIdentity 2>&1`
		if [ $DeviceName == "iPhone" ]; then  DeviceName=$IMEI; fi
		APBuild=`${LOCKDOWN_QUERY} get NULL BuildVersion 2>&1`
}

calculatePercent()
{
		Percent=`echo "$1 $2" |  perl -lne '@a = split; $percent = ($a[0]*100)/$a[1]; printf ("%.2f",$percent);'`
		echo $Percent
}

# FUNCTION to process the CSI logs and report the number of crashes and Call Drops
processCsiLogs()
{
		cp  $logFiles  $csiLogsDir/
		ls  $csiLogsDir/*csi* | perl -lne '$f = $_; open (F, $f); $f =~ s/(.*\Qlog-bb-\E)(.*)(\Q-csi.\E(.*))/$2/; foreach (<F>) { chomp; if (/\QReason: \E/) { s/^(.*Reason: )//; s/,/_/g; $i=$_; print "$i,$f"; last; } } close F; '  > /tmp/crashReasons
		cp /tmp/crashReasons crashReasons
		totalCsiLogs=`ls $csiLogsDir/*csi* | wc -l | perl -lne ' s/\s*//; print'`
		totalModemResets=`cat /tmp/crashReasons | grep "modem reset" | wc -l | perl -lne ' s/\s*//; print'`
		totalBasebandCrashes=`cat /tmp/crashReasons | grep "baseband crash"| wc -l | perl -lne ' s/\s*//; print'`
		totalCallFailures=`cat /tmp/crashReasons | grep -i "call fail" | wc -l | perl -lne ' s/\s*//; print'`
		totalCallDrops=`cat /tmp/crashReasons | grep -i "call drop"| wc -l | perl -lne ' s/\s*//; print'`
		totalFTO=`cat /tmp/crashReasons | grep "FTO" | wc -l | perl -lne ' s/\s*//; print' `
		totalBBResets=$(($totalModemResets + $totalBasebandCrashes))
		
		echo "\n ****************  LOG DETAILS:  *********************"
		echo "RESETS-$totalModemResets  CRASHES-$totalBasebandCrashes"
		echo "FAIL-$totalCallFailures,  DROPS-$totalCallDrops,   FTO-$totalFTO"
} 

reselectTo3G()
{
		checkFor3G_seconds=0
		while [ 1 ]; do
                grep -i kCTRegistrationDataIndicator3G CT.txt
                if [ $? -eq 0 ]; then
                	killall -9 CoreTelephonyMonitor				
					echo "On 3G"
                	break;
                fi
                
				echo "No 3G yet, waiting for 3G indication"
				sleep 2;	
				checkFor3G_seconds=`expr $checkFor3G_seconds + 2`
		done	
}

sendSMSToMODevice()
{
/usr/local/bin/testCT -s $MONumber "SMSBuddy
$SCRIPTS_DIR/MOStressTest.sh
-p 
$MTNumber
-i 
$COUNT" > /tmp/dummy.txt
grep "SMSSent PASS" /tmp/dummy.txt; smsSendResult=$?; rm /tmp/dummy.txt;
smsSendResult=$? 
}

############################################################################################


###### START MT STRESS TESTS
COUNT=0
MT_PASS=0
MT_FAIL=0
MO_FAIL=0
MO_PASS=0

callEndTime=$(($interval - 2))
logsDir="/var/wireless/Library/Logs/CrashReporter/Baseband/"
logFiles="$logsDir/*csi*"

getBuildVersions

SUFFIX1=`echo $DeviceName | perl -lne '($s,$m,$H,$d,$M,$Y,$D) = localtime(); $Y += 1900; $M++; printf ("momt_%s_Stats-%02d%02d-%02d%02d",$_,$M,$d,$H,$m); ' `
ResultsFile="/var/mobile/$SUFFIX1.csv"
echo "  DEVICE, Baseband, AP Build, Iterations, MO Call Count, MO_PASS-MO_FAIL,  MT_PASS-MT_FAIL, MO Start Time, MT End Time, Duration, Modem Resets, Call Drops, Call Failures"  > $ResultsFile
${TESTCT} -x | grep status
if [ $? -eq 0 ]; then 	${TESTCT} -e; fi
#nohup $SCRIPTS_DIR/setAutoAnswerOnReset.sh &
sleep 1
CsiLogsDir="CsiLogs_Temp_$SUFFIX1"
mkdir $CsiLogsDir
rm CALL_STATUS.txt
killall -9 SMSBuddy

while [ $COUNT -lt $LOOPS ]
do
		((COUNT++))
		echo "\n\n  ################### Begining Iteration - $COUNT ####################\n"
		date
		initialize
		${CT_MONITOR} 2>CT.txt &
		
		if [ $stress2G -eq 0 ]; then
			echo "Wait for the Device to Reselect to 3G"
			reselectTo3G
			echo "Time to Reselect to 3G: $checkFor3G_seconds seconds"
		fi
		rm /var/mobile/CallsStats.txt
		
  		########################################### 	
		# SEND SMS to the BUDDY Device to make a call to this device
		echo "Sending SMS to the MO Device to make a call to him..."
		sendSMSToMODevice
		
		while [ $smsSendResult -ne 0 ]; do
				sleep 2; 
				sendSMSToMODevice
				smsSendResult=1;
		done
		
		/usr/local/bin/scripter -file /usr/local/etc/scripter/general/ExecuteTest.js "events.holdLock(2)"
		echo "Sleeping for 30 seconds..."
		#/usr/local/bin/SleepCycler -n 1 -s 30
		sleep 30
		eventer h
		
		# Starting the check and wait for 20 seconds for the call to be made
		${CT_MONITOR} 2>CT.txt &
		callStarted=`date "+%s"`
		waitTimer=0; isActive=1; callStatus=1;
		
		
		
  		########################################### 	
		# Check for MT CALL Success
		while [ $callStatus -ne 0 ]; do	
				echo "$waitTimer. Checking for Call..."
				sleep 2
				${TESTCT} -x | grep "status"
				callStatus=$?
				waitTimer=`expr $waitTimer + 2`
				if [ $waitTimer -ge 120 ]; then break; fi
		done
		startTime1=`date "+%s"`
		echo "Wait timer = $waitTimer."
		
		
		
		# Check the call Status from CT also just in case
		grep "Call from $MONumber" CT.txt
    	isActive=$?	
    	echo "FLAGS --> isActive=$isActive,  callStatus=$callStatus.\n"
		if [ $isActive -eq 0 ] || [ $callStatus -eq 0 ]; then
    			echo " Received Incoming Call - $COUNT.\n"
    			((MT_PASS++))
    			callPassed=1
    	
    	elif  [ $isActive -ne 0 ] & [ $callStatus -ne 0 ]; then
       			((MT_FAIL++))
       			koolStateFlag=1
				echo "INCOMING CALL ( $COUNT ) FAILED !!!!\n"
     	fi
    	
    	echo `date` ": $COUNT" >> CALL_STATUS.txt
    	${TESTCT} -x >> CALL_STATUS.txt
 
 		
  		########################################### 	
 		# CHECK FOR MO CALL SUCCESS
		if [ $callPassed -eq 1 ]; then
				((MO_PASS++))
				echo "MT CALL PASSED.. SO MO CALL SHOULD HAVE PASSSED..."
				timeToSleep=$interval
				
		else
			# if MT CALL FAILED, MO CALL might have Failed
			echo "MT CALL FAILED OR NOT SURE... so checking to see if MO Call Succeeded..."
    		${CT_MONITOR} 2> checkAgainCT_${COUNT}.txt &
		   	secondsToWait=0

			while [ $secondsToWait -lt $callEndTime ];
			do
				if [ -e /var/mobile/CallsStats.txt ]; 
				then 
						echo "*********"
						cat /var/mobile/CallsStats.txt
						break;					
				else
					secondsToWait=$(($secondsToWait + 2))
					sleep 2;
					echo "$secondsToWait seconds over... "
					startTime1=$callStarted							
				fi	
			done
			
			echo " Waited for $secondsToWait seconds... "
			if [ $secondsToWait -ge $callEndTime ]; then 
				timeToSleep=2;
				((MO_FAIL++))
				echo "Time Expired.... $COUNT. MO CALL FAILED!!!! "
			else
				timeToSleep=$(($callEndTime - $secondsToWait));
			fi		
		fi
 		date
 		
 		if [ -e /var/mobile/CallsStats.txt ]; then
				MoCallCount=`perl -lne ' $m = (split)[1]; print $m; ' /var/mobile/CallsStats.txt`
				startTime1=`perl -lne ' $s = (split)[3]; print $s; ' /var/mobile/CallsStats.txt`
					
				grep FAIL /var/mobile/CallsStats.txt
				result=$?
				if [ $result -eq 0 ]  &&  [ $callPassed -ne 1 ]; then
						((MO_FAIL++))
						koolStateFlag=1
						echo "$COUNT. MO CALL FAILED!!!! "
				elif [ $result -ne 0 ]  &&  [ $callPassed -ne 1 ]; then 
						((MO_PASS++))
						echo "$COUNT. MO CAll PASSED..."
				fi						
		fi
		date
 		########################################### 
 		

		if [ $koolStateFlag -eq 1 ]; then  ${TESTCT} -l "MT OR MO CALL $COUNT FAILED."; fi
		killall -9 CoreTelephonyMonitor				
		date
		echo " ****** Time to Sleep -- $timeToSleep."
		sleep $timeToSleep;
		/usr/local/bin/scripter -f /usr/local/etc/scripter/general/Interact.js com.apple.springboard "dismissAlerts(app)"
	
		
		echo "ENDING THE CALL..."
		#grep "Call from $MONumber"  CT.txt
		${TESTCT} -x | grep "status active"
		if [ $? -eq 0 ]; then 
			echo "Calls are active... so ending them."
			${TESTCT} -e    #end all active calls
		else
			echo " There are no active calls to end."
		fi
		
		endTime1=`date "+%s"`
		echo " StartTimes --- $startTime, $startTime1;  EndTimes -- $endTime; $endTime1;\n"
		endTime=`date -r $endTime1 | cut -c5-7 -c8-10 -c11-19 `
		startTime=`date -r $startTime1 | cut -c5-7 -c8-10 -c11-19 `
		
		callDuration=$(($endTime1 - $startTime1))
		echo " StartTimes --- $startTime, $startTime1;  EndTimes -- $endTime; $endTime1;\n"

		
		processCsiLogs
		echo "  DEVICE, Baseband, AP Build, Iterations, MO CallCount, MO_PASS-MO_FAIL,  MT_PASS-MT_FAIL, MO Start Time, MT End Time, Duration, Modem Resets, Call Drops, Call Failures" 
		echo "  $DEVICENAME, $BB, ${APBUILD}, $COUNT, $MoCallCount, $MO_PASS--$MO_FAIL, $MT_PASS--$MT_FAIL, $startTime, $endTime, $callDuration, $totalBBResets, $totalCallDrops, $totalCallFailures"
		echo "  $DEVICENAME, $BB, ${APBUILD}, $COUNT, $MoCallCount, $MO_PASS--$MO_FAIL, $MT_PASS--$MT_FAIL, $startTime, $endTime, $callDuration, $totalBBResets, $totalCallDrops, $totalCallFailures" >> $ResultsFile
		echo " Sleeping for 30 seconds before making the next call...\n\n"
		sleep 30

done


killall -9 DoOnBBReset 
killall -9 setATCommandOnReset.sh 
killall -9 SMSBuddy
echo "Disabling Auto-Answer"
${TESTCT} -c "#5005*2267#"

if [ $stress2G -eq 1 ]; then
	echo " Switching to 3G"
	if [ $HARDWARE == "N90" ]; then	
		#${SEND_AT_COMMAND} -v -d ${DLCI_DEV_NODE} +cops=2
		echo "${SEND_AT_COMMAND} -v -d ${DLCI_DEV_NODE} +xact=1,2"
		${SEND_AT_COMMAND} -v -d ${DLCI_DEV_NODE} +xact=1,2
	else
		${SEND_AT_COMMAND} -v -d ${DLCI_DEV_NODE} +cops=2
		sleep 3
		echo "${SEND_AT_COMMAND} -v -d ${DLCI_DEV_NODE} +xrat=0,0"
		${SEND_AT_COMMAND} -v -d ${DLCI_DEV_NODE} +xrat=1,2
		sleep 2
		${SEND_AT_COMMAND} -v -d ${DLCI_DEV_NODE} +cops=0
	fi
	sleep 5
	eventer h
	echo " Switched to 3G"
fi

echo " DONE WITH THE MT CALL TESTS"
