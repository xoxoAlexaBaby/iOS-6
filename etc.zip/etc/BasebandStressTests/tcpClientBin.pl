#!/usr/bin/perl -w
use IO::Socket;
use Time::Local;

die "USAGE: ./tcpClientBin <Server IP Addr> <SuffixForDirName> <DeviceName> <Results_FileToBe_Uploaded>\n" if ( @ARGV != 4);

$addr = shift;
$outputdir = shift;
$host = shift;
$file = shift;

if (! -e $file) 
{ 
	die "File $file does not exist.!!!!\n";  
} else {
	open (F, "$file") || die " Cannot open $file for reading. $!\n";;
	binmode(F);
}

$socket = IO::Socket::INET->new(PeerAddr => $addr, 
								PeerPort => 12100,
                                Proto    => 'tcp',
                                Type     => SOCK_STREAM)
                     or
die "Cannot open socket... $!\n";


$SIG{PIPE} = 'handler';    #  SIGPIPE if server end of socket is gone when we try to write to it.
$SIG{INT}  = 'handler';  
$SIG{QUIT} = 'handler'; 
$length = 1024;
$fname = (split /\//,$file)[-1];
$outputdir = "DIR:$outputdir";
$device = "DEVICE:$host";
$fname = "FILE:$fname";
@L = ($outputdir,$device,$fname);
$inbuf ="";

print "\nOutputDir = $outputdir...Host = $device....File = $file.\n";


$then = time();
foreach (@L)
{
	print $socket "$_\n";
	$in = <$socket>;
	chomp $in;
	if ($in =~ /FAILED/g) { 
		print " ****** UPLOADING LOGS TO SERVER FAILED !!!!!    WILL TRY NEXT TIME...\n";
		close ($socket);
		exit (3);
		
	} elsif ($in =~ /\QEXISTS\E/g) {
		print "$fname -- $in.. Bailing out.\n\n";
		close ($socket);
		exit (10);
	}
}

print $socket "BINARY\n";
print "Uploaded Filename, host and Dir.\n\n";

$fileSize = -s F;

print " FileSize - $fileSize\n\n";

if (-z F) 
{ 
	print "File $file is EMPTY. So closing the socket.\n\n"; 
	syswrite ($socket, "QUITBIN"); close $socket; exit (10) 
}

while ( $bytesread = read ( F, $buffer, $length ) ) 
{
	$total += $bytesread;
	syswrite ($socket, $buffer, $bytesread);
	if ( $total % 2048000 == 0) {	$inbuf = <$socket>; print "$inbuf"; 	}
	if ($fileSize == $total) { 
		print " Final Read had $bytesread bytes. File completely read.\n\n"; 
		syswrite ($socket, "QUITBIN"); last;
	}
}

#######  Send QUIT packet to server.
if (defined ($inbuf = <$socket>)) {
	chomp $inbuf;
	print "***** \"$inbuf\" from server!\n\n";
	$uploadSize = (split /\s+/, $inbuf)[0];
} else {
	$uploadSize = 0;
}

print "Total Bytes Uploaded -- $uploadSize.\n"; 
close F;
close($socket) if (defined $socket);
$now = time();
print "Total Time Taken to Upload: $now - $then = ", $now - $then, "\n";

if ($uploadSize == $fileSize) { print "Size Matches. SUCCESS.\n\n"; exit 10}
else { exit 4 }

sub handler
{
    my ($signo) = shift;

    if ($signo eq "INT" || $signo eq "QUITBIN")
    {
    #  Send the quit packet on a terminal interrupt!
         print $socket "QUITBIN\n"; 
         close($socket);
         exit(1);
    }
    else  ############  SIGPIPE!!
    {
         print "Server died\n";
         exit(2);
    }
}

sub openFileFail
{
	my ($file1, $skt) = @_;
	print " Cannot open $file1 for reading!!!!!\n";
	print $skt "BINARY\n";
	close ($skt);
	exit (5);
}