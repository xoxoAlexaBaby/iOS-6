#import "YouTube.js"
#import "../libs/PHTesting.js"

//----------------------------------------------------------------------------------------
//	Function: youtubeTest_searchForMovie 
//		Searches for a movie and plays the first result.  
//		Please note that an exact video name must be supplied for the search 
//		per <rdar://problem/7058697> Tracking bug for changing YouTube video regex matching
//
//	Parameters: 
//		searchString (string) - the string used for the search
//		timeout (int) - the duration to play the video.  Defaults to 10 seconds
//
//	Returns:
//	 0 if test failed, 1 if it succeeded.  Uses the PHTesting object.
//----------------------------------------------------------------------------------------
function youtubeTest_searchForMovie() {

	
	if (this.argv.length < 1) {
		this.logError("Not enough args being passed.");
		return 64;		
	}

	var timeout = 10;
	if (this.argv.length > 1) { 
		timeout = parseInt(this.argv[1]);
	} 
	var alertTitle = "";
	// Length of time to wait before failing the search.
	var searchTimeout = 90;
	if (this.argv.length > 2) { 
		searchTimeout = parseInt(this.argv[2]);
	} 
	
	var searchString = this.argv[0];
	
    // Create a simple alert handler that's used to log any alert 
    var testAlertHandler = function (alert) {
        alert.logElementTree();
        alertTitle = " Encountered Alert: " + alert.staticTexts()[0].name();
        alertEncountered = 1;
    };
    
    UIATarget.pushAlertHandler(testAlertHandler);	

	youtube.launchIfNotActive();
		
	if (UIATarget.localTarget().model() != "iPad") {
		try{ 
			youtube.getToCategoryView("Search"); 
		} catch (e) {
			UIALogger.logError(e.message);
			this.testError = "Could not get to Search view. ";
			return this.testResult = 0;
		}
	}
	
	try {
		youtube.searchForVideo(searchString);
	} catch (e) {
		UIALogger.logError(e.message);
		this.testError = "Search for " + searchString + " failed. ";
		return this.testResult = 0;
	}
		
	// Look for results
	if (!youtube.waitForVideoListToFinishLoading(searchTimeout)) {
		this.testError = "Timed out after waiting " + searchTimeout + " seconds for videos to load." + alertTitle;
		return this.testResult = 0;
	}	
	
	
	try {
		youtube.playVideo(searchString, {playbackTime:timeout});
	} catch (e) {
		UIALogger.logError(e.message);
		this.testError = e.message + alertTitle;
		return this.testResult = 0;
	}
	
	youtube.exitVideo();

	UIALogger.logMessage("Successfully searched for video and played it");
	
	return this.testResult = 1;
}

//----------------------------------------------------------------------------------------
//	Function: youtubeTest_addBookmarkFromMovie 
//		Plays a movie and adds a bookmark from the view
//
//	Parameters: 
//		choice (string) - Where to look for the video. It can be one of the following:
//							Non-iPad:	Featured, Most Viewed, Bookmarks or Search. (optional)
//							iPad:		Featured, Top Rated, Most Viewed, Favorites, Subscriptions, My Videos, History
//
//						  If no category is specified, Featured will be used as a default							
//		name (string) - The exact name of the video.  (optional) 
//      minDuration (int) - minimum video length to play.  45 seconds by default, shorter
//                          videos may not allow the test to successfully run, resulting in
//                          false negatives
//
//	Returns:
//	 0 if test failed, 1 if it succeeded.  Uses the PHTesting object.
//----------------------------------------------------------------------------------------
function youtubeTest_addBookmarkFromMovie() {
	
	var choice = "Featured";
	var name = null;
	var timeout = 10;
	var minDuration = 45;
    var alertEncountered = 0;
	if (this.argv.length > 0) {
		choice = this.argv[0];
	}
    var maxAttempts = 10;
    var alertTitle = "";
    
	if (this.argv.length > 2) { 
		timeout = parseInt(this.argv[2]);
	} 
    
    if (this.argv.length > 3) { 
		minDuration = parseInt(this.argv[3]);
	} 

    
    // Create a simple alert handler that's used to log any alert 
    var testAlertHandler = function (alert) {
        alert.logElementTree();
        alertTitle = " Encountered Alert: " + alert.staticTexts()[0].name();
        alertEncountered = 1;
    };
    
    UIATarget.pushAlertHandler(testAlertHandler);	
	youtube.launchIfNotActive();

	try {
		youtube.getToCategoryView(choice);
	} catch (e) {
        this.testError = "Could not get to '" + choice + "' view.";
		youtube.logElementTree();
        UIATarget.popAlertHandler();
		return this.testResult = 0;
	}

	if (!youtube.waitForVideoListToFinishLoading()) {
        this.testError = "Timed out waiting for videos to load. " + alertTitle;
        UIATarget.popAlertHandler();   
        return this.testResult = 0;
    }
    
    try {

        if (this.argv.length > 1) {
            name = this.argv[1];
            UIALogger.logMessage("Playing " + name);
            if (!youtube.videoDurationExceedsMinDuration(name, minDuration)) UIALogger.logDebug("WARNING: video '" + name + "' may not be long enough to adequately complete the test.");
            youtube.playVideo(name, {playbackTime:timeout});
        } else {
            // Pick a video that is longer than the minimum duration
            for (var currentAttempt = 0; currentAttempt < maxAttempts; currentAttempt++) {
                name = youtube.pickRandomVideo(minDuration);
                UIALogger.logMessage("Playing " + name);
                youtube.playVideo(name, {playbackTime:timeout});
                if (!youtube.videoHasBeenBookmarked()) break;
                youtube.exitVideo();
                UIALogger.logMessage("Choosing a different video - " + name + " has already been bookmarked");
				if (UIATarget.localTarget().model() != 'iPad') youtube.getToCategoryView(choice);
            }

        }
        
    } catch (e) {
        this.testError = e.message + alertTitle;
        UIATarget.popAlertHandler();
        return this.testResult = 0;
    }

	UIATarget.localTarget().delay(3);

	UIALogger.logMessage("Selecting Add Bookmark" );		
	
	try {
		youtube.addBookmark();
	} catch (e) {
		UIALogger.logError(e.message);
		this.testError = "Could not select the add bookmark button. " + e.message + alertTitle;
        UIATarget.popAlertHandler();
		return this.testResult = 0;
	}

	UIALogger.logMessage("Attempting to exit the video" );

	youtube.exitVideo();
	
	try {	
		if (youtube.bookmarkExists(name)) {
			UIALogger.logMessage("Successfully added " + name + " to bookmarks");
            UIATarget.popAlertHandler();
			return this.testResult = 1;
		}
	} catch (e) {
		UIALogger.logError(e.message);
	}
    UIATarget.popAlertHandler();
	youtube.logElementTree();
	this.testError = "Could not verify that bookmark " + name + " was added" + alertTitle;
	return this.testResult = 0;
	
} // end youtubeTest_addBookmarkFromMovie

//----------------------------------------------------------------------------------------
//	Function: youtubeTest_loginToYoutubeAccount
//		Logs into youtube account
//
//		As of Jasper 8C67, this is broken due to: <rdar://problem/8139691> scripter throws an error when trying to access an alert through settings
//
//	Parameters: 
//		argv[0] - youtube username - if not provided, will default to "weliketesting"
//		argv[1] - youtube password - if not provided, will default to "testtest" 
//
//	Returns:
//		0 if test failed, 1 if it succeeded.  Uses the PHTesting object.
//----------------------------------------------------------------------------------------

function youtubeTest_loginToYoutubeAccount() {
	
	if ( this.argv.length < 2 ) {
		youtube.authentication.username = "weliketesting";
		youtube.authentication.password = "testtest";
	} else {
		youtube.authentication.username = this.argv[0];
		youtube.authentication.password = this.argv[1];
	}		
	    
    youtube.launchIfNotActive();
    
	try {
		youtube.getToCategoryView("Favorites");
	} catch (e) {
		UIALogger.logError(e.message);		
		this.testError = "Could not navigate to Bookmarks";
		youtube.logElementTree();
		return this.testResult = 0;
	}

	UIATarget.localTarget().delay(2);
	
	try {
		youtube.signInToYouTubeAccount();
	} catch (e) {
		UIALogger.logError(e.message);
		this.testError = "Could not sign into youtube account: " + e.message;
		return this.testResult = 0;
	}

	//Look for the Sign Out button in the navigation bar to determine if we are indeed signed in
	if (!youtube.mainWindow().navigationBar().buttons().firstWithName("Sign Out").isValid()){
		this.testError = "Failed to complete authentication";
		return this.testResult = 0;
	} 
	
	
	return this.testResult = 1;

	
} // end youtubeTest_loginToYoutubeAccount


//----------------------------------------------------------------------------------------
//	Function: youtubeTest_emailYoutubeVideo 
//		Emails a random video from the Featured list.  No validation is performed
//
//	Parameters: 
//		to (string) - recipient of the email.
//
//	Returns:
//		0 if test failed, 1 if it succeeded.  Uses the PHTesting object.
//----------------------------------------------------------------------------------------
//TODO - Once the right stuff is in place, this should do some validation
function youtubeTest_emailYoutubeVideo() {
	
	var recipient = (this.argv.length > 0) ? this.argv[0] : "weliketesting@me.com";
	var shouldValidate = false;
	var videoName;
	
	if (this.argv.length > 1) {
		shouldValidate = this.argv[1];
	}
	
	youtube.launchIfNotActive();
	    
	try {
		youtube.getToCategoryView("Featured");
	} catch (e) {
		UIALogger.logError(e.message);
		this.testError = "Could not navigate to 'Featured' videos";
		return this.testResult = 0;
	}
	
	try {
		youtube.waitForVideoListToFinishLoading();
	} catch (e) {
		UIALogger.logError(e.message);
		this.testError = "Video list was not loaded";
		return this.testResult = 0;
	}
	
	try {
		videoName = youtube.sanitizeVideoName(youtube.pickRandomVideo());
	} catch (e) {
		UIALogger.logError(e.message);
		this.testError = "Could not pick a random Video";
		return this.testResult = 0;		
	}

	var shareButton;
	var videoTableCell;
	
	if (UIATarget.localTarget().model() != "iPad") {

		videoTableCell = youtube.mainWindow().tableViews()[0].cells().firstWithPredicate("name matches '.*" + videoName + ".*'");

		if (!videoTableCell.isVisible()) videoTableCell.scrollToVisible();
		
		videoTableCell.logElementTree();
		UIALogger.logDebug(videoName + "::" + youtube.mainWindow().tableViews()[0].cells().firstWithPredicate("name matches '.*" + videoName + ".*'").name());		
		UIATarget.localTarget().delay(2);
		
		if (!videoTableCell.isValid()) {
			this.testError = "Could not find video in table";
			return this.testResult = 0;		
		}
		
		if (!videoTableCell.isVisible()) {
			this.testError = "Tried scrolling video cell to visible, but failed to do so.";
			return this.testResult = 0;		
		}

		UIATarget.localTarget().delay(2);
		//Tap the more info chevron 
		var moreInfoButton = videoTableCell.buttons()[0];
		moreInfoButton.tap();

		//Allow any animations to cease
		UIATarget.localTarget().delay(5);
		UIATarget.localTarget().pushTimeout(25);
		var shareVideoGroup = youtube.mainWindow().tableViews()[0].groups().firstWithPredicate("ANY buttons.name beginswith 'Share'");
		UIATarget.localTarget().popTimeout();
		
		if (!shareVideoGroup.isValid()) {
			youtube.mainWindow().logElementTree();
			this.testError = "Did not find the table group to share video";
			return this.testResult = 0;
		}
		shareButton = shareVideoGroup.buttons().firstWithPredicate("name beginswith 'Share'");
        
        if (!shareButton.checkIsValid()) {
            this.testError = "Share button could not be tapped";
            return this.testResult = 0;
        }
        shareButton.tap();
        var actionSheet = youtube.actionSheet();
        if (actionSheet.isValid()) {
            var mailLinkButton = actionSheet.buttons().firstWithPredicate("name beginswith 'Mail Link'");
            if (mailLinkButton.isValid()) {
                mailLinkButton.tap()
            } else {
                youtube.logElementTree();
                throw new Error("Encountered an alert sheet, but did not find a 'Mail Link...' button.");
            }
            
        }
        
	} else {
		UIATarget.localTarget().delay(5);
		videoTableCell = youtube.mainWindow().tableViews()[0].cells().firstWithPredicate("ANY elements.name matches '.*" + videoName + ".*'");
		UIALogger.logDebug(videoName + "::" + youtube.mainWindow().tableViews()[0].cells().firstWithPredicate("ANY elements.name matches '.*" + videoName + ".*'").name());
		videoTableCell.scrollToVisible();
        UIATarget.localTarget().delay(3);
		var videoElement = videoTableCell.elements().firstWithPredicate("name matches '.*" + videoName + ".*'");
		UIALogger.logDebug(videoElement.name());		
		if (!videoElement.isVisible()) {
			this.testError = "Could not scroll to video in table";
			return this.testResult = 0;		
		}
		
		videoElement.tap();
		//Delay for animations
		UIATarget.localTarget().delay(5);

		//Ensure the app is not in full screen mode
		if (UIATarget.localTarget().model() == 'iPad') youtube._setFullScreenMode("OFF");
        var maxAttempts = 10;

        for(var currentAttempt = 0; currentAttempt < maxAttempts; currentAttempt++) {
            youtube.bringUpControlScreen();

            shareButton = youtube.mainWindow().buttons().firstWithName("Share");
            try {
                if (shareButton.isVisible()) shareButton.tap();
                break;  
            } catch(e) {
                UIALogger.logMessage("Could not tap the 'Share' button. Trying again");
            }
            UIATarget.localTarget().delay(2);
        }   
        if (currentAttempt == maxAttempts) {
            throw new Error("Cound not tap the 'Share button' after numerous attempts");
        }
        
        var popover = youtube.mainWindow().popover();
        if (!popover.isVisible()) throw new Error("Could not find popover to share video");
        var mailLinkButton = popover.actionSheet().buttons().firstWithName("Mail Link to this Video");
        try {
            mailLinkButton.tap();
        } catch(e) {
            if (!mailLinkButton.isVisible()) throw new Error("Could not find the 'Mail Link to this Video' button");
            throw new Error("Could not tap the 'Mail Link to this Video' button");
        }

	}

 	UIATarget.localTarget().delay(5);
	
	if (!mail.mainWindow().navigationBar().staticTexts().firstWithName("Welcome to Mail").isValid()) {
		youtube.composeEmail({to:recipient});
      	UIATarget.localTarget().delay(3);
		youtube.mainWindow().navigationBar().buttons().firstWithName("Send").tap();
	} else {				
		this.testError = "Failed to send email.  Email account is not setup";
		return this.testResult = 0;
	}
	
	UIALogger.logMessage("No verification performed -- email may or may not have been sent");
	return this.testResult = 1;
	
} // end youtubeTest_emailYoutubeVideo


//----------------------------------------------------------------------------------------
//	Function: youtubeTest_scrubVideo 
//		Picks a random video from the "Featured" category and scrubs the video
//
//	Parameters: 
//		locations (array) - an array of ratios to scrub.  Will choose random values if none are provided
//		speed (int) - time to allow for the scrub flick. Defaults to 2 seconds between scrubs
//		pauseBeforeScrubbing (bool) - pause the video before scrubbing.  
//			Useful in isolating the scrubbing from video playback. Defaults to false.
//
//	Returns:
//	 0 if test failed, 1 if it succeeded.
//----------------------------------------------------------------------------------------
function youtubeTest_scrubVideo() 
{
	var locations = new Array();
	var speed;
	var name;
	
	var minSliderLocationRatio = 0.1;
	var maxSliderLocationRatio = 0.75;
	if (this.argv.length > 0) { 
		locations = this.argv[0];
	} else {
		for( var i = 0; i < 10; i++ ) {
			//create array of 10 random slider locations
			locations.push( system.randomReal( minSliderLocationRatio, maxSliderLocationRatio ) );
		}
	}
	
	if (this.argv.length > 1) { 
		speed = parseInt(this.argv[1]);
	} else {
		speed = 2;
	}
	
	if (this.argv.length > 2) { 
		pauseBeforeScrubbing = this.argv[2];
	} else {
		pauseBeforeScrubbing = false;
	}
	
	
	//Launch youtube if it's not active and wait for it to load
	youtube.launchIfNotActive();
	
	try{ 
		youtube.getToCategoryView("Featured"); 
	} catch (e) {
		UIALogger.logError(e.message);
		this.testError = "Could not get to 'Featured' view. ";
		return this.testResult = 0;
	}
	
	youtube.waitForVideoListToFinishLoading();
	
	name = youtube.pickRandomVideo();
	
	try {
		youtube.playVideo(name);
	} catch (e) {
		UIALogger.logError(e.message);
		//DEBUG
		youtube.logElementTree();
		this.testError = "Could not begin video playback";
		return this.testResult = 0;
	}
	// Pause video so that the video won't end during our scrubbing
	if (pauseBeforeScrubbing) youtube.videoViewElementWithPredicate("name == 'Pause'").tap();
	
	//Put in try-catch block - check for video details to determine if the video ended before we finished scrubbing
	try {
		UIALogger.logMessage("Scrubbing to locations: " + locations.join(" -> "));	
		for (var i = 0; i < locations.length; i++) {
			UIALogger.logMessage("Scrubbing to location: " + locations[i]);

			UIATarget.localTarget().pushTimeout(0.1);
			youtube.bringUpControlScreen();

			var scrubberElement;
			if (UIATarget.localTarget().model() == "iPad") {
				scrubberElement = youtube.mainWindow().sliders().firstWithPredicate("name beginswith 'Track position'");
			} else {
				scrubberElement = youtube.mainWindow().navigationBar().sliders()[0];
			}
			scrubberElement.dragToValue(locations[i]);

			UIATarget.localTarget().popTimeout();
			UIATarget.localTarget().delay(speed);
		}
	} catch (e) {
		if (youtube.mainWindow().navigationBar().name() == "More Info") {
			UIALogger.logMessage("Video exited before we could finish scrubbing.");
		} else {
			UIALogger.logError(e.message);
			this.testError = "Failed to complete scrubbing test";
			this.testResult = 0;
		}
	}
	
	youtube.exitVideo();
		
	return this.testResult = 1;
	
} // end youtubeTest_scrubVideo
	
//----------------------------------------------------------------------------------------
//	youtubeTest_playVideosInYouTubeCategory - plays each of the videos in a youtube category,
// 		for the specified timeout time.
//
//	Optional Parameters: 			
//		timeout (int) - number of seconds to play each video.
//		videoPlaybackCount (int) - number of videos to playback.  If greater than the number
//			of videos on the device, we use only the number of videos on the device.
//		playVideosRandomly (bool) - boolean specifying whether to play the videos randomly
//		category (string) - the category to pick a video from(defaults to Favorites): 
//							Favorites
//							Featured
//							Most Viewed 
//							Top Rated
//							History
//							My Videos
//      minDuration (int) - minimum video length to play.  45 seconds by default, shorter
//                          videos may not allow the test to successfully run, resulting in
//                          false negatives
//
//	Returns:
//	 0 if test failed, 1 if it succeeded.  Uses the PHTesting object.
//----------------------------------------------------------------------------------------
function youtubeTest_playVideosInYouTubeCategory() 
{
	var timeout = 60;
	var videoPlaybackCount = 1;
	var playVideosRandomly = false;
	var videoArray = new Array();
	var randomRow;
	var bookmarkRowCount;
	var category = "Favorites";
    var minDuration = 45;
	if (this.argv.length > 0) { 
		timeout = parseInt(this.argv[0]);
	} 

	if (this.argv.length > 1) { 
		videoPlaybackCount = parseInt(this.argv[1]);
	} 

	if (this.argv.length > 2) { 
		playVideosRandomly = parseInt(this.argv[2]);
	} 

	if (this.argv.length > 3) { 
		category = this.argv[3];
	} 

	if (this.argv.length > 4) { 
		minDuration = this.argv[4];
	} 
	
	
	youtube.launchIfNotActive();

	// Exit video if currently playing
	if (youtube.isInVideoView()) {
		UIALogger.logMessage("Video playing - exiting....");
		youtube.exitVideo();	
	}

	
	// Get to the supplied category and let the video list load and check for videos
	if (!youtube.getToCategoryView(category)) {
		this.testError = "No videos in '" + category + "'";
		return this.testResult = 0;
	}

	if (UIATarget.localTarget().model() == "iPad") {

		// check to make sure videoPlayBackCount is less than or equal to the number of videos that are on the device
		var numberOfRows = youtube.mainWindow().tableViews()[0].cells().length;
		var numberOfColumns = youtube.mainWindow().tableViews()[0].cells()[0].elements().length;
		var maxNumberOfVideos = numberOfRows*numberOfColumns; // rough estimate of how many videos might be in favorites--could be a little high
		UIALogger.logMessage("maxNumberOfVideos = " + maxNumberOfVideos);
		if (videoPlaybackCount > maxNumberOfVideos) videoPlaybackCount = maxNumberOfVideos;
		
		// If randomly-chosen bookmarks is specified, then create a new array 
		// with random bookmarks
		if (playVideosRandomly) {
			UIALogger.logMessage("Playing videos randomly");
			var cells = youtube.mainWindow().tableViews()[0].cells().toArray();
			bookmarkRowCount = youtube.mainWindow().tableViews()[0].cells().length;
			for (var i = 0; i < videoPlaybackCount; i++) {
                randomRow = system.randomInteger(0,bookmarkRowCount - 1);
                numberOfColumns = cells[randomRow].elements().length;
                var randomColumn = system.randomInteger(0, numberOfColumns - 1);
                videoArray[i] = cells[randomRow].elements()[randomColumn].name();
                UIALogger.logDebug("Random indices: row = " + randomRow + ", column = " + randomColumn);
                UIALogger.logDebug("i = " + i);
                UIALogger.logDebug("videoArray[i] = " + videoArray[i]);
				UIATarget.localTarget().delay(2);
			}
		} else {
			var videoArrayIndex = 0;
			for (var i = 0; i < numberOfRows; i++) {
				numberOfColumns = youtube.mainWindow().tableViews()[0].cells()[i].elements().length;
				for (var j = 0; j < numberOfColumns; j++, videoArrayIndex++) {
					if (videoArrayIndex >= videoPlaybackCount) break;
					UIALogger.logDebug("videoArrayIndex = " + videoArrayIndex);
					videoArray[videoArrayIndex] = youtube.mainWindow().tableViews()[0].cells()[i].elements()[j].name();
					UIALogger.logDebug("videoArray[videoArrayIndex] = " + videoArray[videoArrayIndex]);
					UIATarget.localTarget().delay(2);
				}
			}
		}

	} else {
		// non-ipad devices:
		// check to make sure videoPlayBackCount is less than or equal to the number of videos that are on the device
		var numberOfVideos = youtube.mainWindow().tableViews()[0].cells().length;
		UIALogger.logMessage("maxNumberOfVideos = " + numberOfVideos);
		if (videoPlaybackCount > numberOfVideos) videoPlaybackCount = numberOfVideos;

		// If randomly-chosen bookmarks is specified, then create a new array with random bookmarks
		if (playVideosRandomly) {
			bookmarkRowCount = youtube.mainWindow().tableViews()[0].cells().length;
			for (var i = 0; i < videoPlaybackCount; i++) {
				randomRow = system.randomInteger(0,bookmarkRowCount - 1);
				UIALogger.logMessage("Choosing random row " + randomRow + " from " + bookmarkRowCount + " total rows");
				videoArray[i] = youtube.mainWindow().tableViews()[0].cells()[randomRow].name();
				UIALogger.logDebug("Adding '" + videoArray[i] + "' to the array of random videos to play");
				UIATarget.localTarget().delay(2);
			}
		} else {
			for (var i = 0; i < videoPlaybackCount; i++) {
				videoArray[i] = youtube.mainWindow().tableViews()[0].cells()[i].name();
				UIALogger.logDebug("Adding '" + videoArray[i] + "' to the array of videos to play");
				UIATarget.localTarget().delay(2);
			}
		}
	}
	
	UIALogger.logDebug(videoArray.join(" -> "));
	// Iterate through array, playing videos
	for (var i = 0; i < videoArray.length && i < videoPlaybackCount; i++ ) {		
		UIALogger.logDebug("Playing video at index: " + i);
		UIALogger.logDebug(videoArray[i]);
		if (!videoArray[i].match(/Load More/)) {
            if (!youtube.videoDurationExceedsMinDuration(videoArray[i], minDuration)) {
                UIALogger.logMessage("Current video - '" + videoArray[i] + "' does not meed the minimum duration of " + minDuration + " seconds.");
                UIALogger.logMessage("Continuing to the next video...");                
                continue;
            }
			youtube.playVideo(videoArray[i], {playbackTime:timeout});
			youtube.exitVideo();
			var leftButton = youtube.mainWindow().navigationBar().leftButton();
			
			if (UIATarget.localTarget().model() != 'iPad') { youtube.getToCategoryView(category); }
		}
	}
	
	return this.testResult = 1;
	 
} // end youtubeTest_playVideosInYouTubeBookMarks



// Create self tests -- this is an unnamed function, just to make sure any local variables stay in the correct context
(function() {	
	if (typeof youtube.selfTests == 'undefined') {
		youtube.selfTests = new Array();
	}
	
	if (system.hasCapability('youtube') && typeof youtube != 'undefined' ) {
		youtube.selfTests.push(phtCreateTest("SearchForMovie", ["The Real Bruce Lee", 45], youtubeTest_searchForMovie, "Search for movie"));
		youtube.selfTests.push(phtCreateTest("Add bookmark for a movie", [], youtubeTest_addBookmarkFromMovie, "Add bookmark"));
		youtube.selfTests.push(phtCreateTest("LoginToYoutubeAccount", [], youtubeTest_loginToYoutubeAccount, "Login to Youtube Account"));	
		youtube.selfTests.push(phtCreateTest("EmailYoutubeVideo", ["weliketesting@me.com"], youtubeTest_emailYoutubeVideo, "Email Video"));	
		youtube.selfTests.push(phtCreateTest("ScrubYouTubeVideo", [[0.4,0.3,0.25,0.70,0.5]], youtubeTest_scrubVideo, "Scrub YouTube Video"));
		youtube.selfTests.push(phtCreateTest("PlayVideosInFavorites", [20, 10, 1], youtubeTest_playVideosInYouTubeCategory, "Play videos in 'Favorites'"));
		youtube.selfTests.push(phtCreateTest("PlayRandomVideoInFeatured", [20, 1, 1, "Featured"], youtubeTest_playVideosInYouTubeCategory, "Play random video in 'Featured'")); 
//		youtube.selfTests.push(phtCreateTest("PlayVideosInFavorites", [20, 1, 1], youtubeTest_playVideosInYouTubeCategory, "Play videos in 'Favorites'"));
		youtube.selfTests.push(phtCreateTest("PlayVideosInMostViewed", [20, 10, 1, "Most Viewed"], youtubeTest_playVideosInYouTubeCategory, "Play videos in 'Most Viewed'"));
//		youtube.selfTests.push(phtCreateTest("PlayVideosInTopRated", [20, 10, 1, "Top Rated"], youtubeTest_playVideosInYouTubeCategory, "Play videos in 'Top Rated'"));
//		youtube.selfTests.push(phtCreateTest("PlayVideosInFeatured", [20, 1, 1, "Featured"], youtubeTest_playVideosInYouTubeCategory, "Play videos in 'Top Featured'"));
	}
}())