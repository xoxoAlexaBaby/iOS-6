//Mail Acceptance Test Catalogue.


if (typeof mail.acceptanceTests == 'undefined') {
	mail.acceptanceTests = new Array();
}
var date = new Date();
	var testSuffix = "" + date.getHours() + date.getMinutes() + date.getSeconds();
	var title1 = "This is a Unit Test Email: " + testSuffix;
	
	//This test requires an account be created, need default config to have account(s) or pre-tests to setup as needed.
	mail.acceptanceTests.push(phtCreateTest("Mail_ComposeAndSendEmail", ["AppsAuto001@gmail.com", title1, "Hi.  How are you today?  I am an acceptance test", "from:AppsAuto001@gmail.com"], mailTest_composeAndSendEmail, "Compose and Send Predefined Message"));
	


