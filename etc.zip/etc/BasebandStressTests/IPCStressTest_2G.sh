#!/bin/sh

#################################################################################################
#                                                                                               #
#   ScriptName: IPCDataStressTest.sh                                                            #
#                                                                                               #
#   Usage:      nohup <path_to_Script>/IPCDataStressTest.sh [-Option <optarg>] [ ... ] &        #
#                                                                                               #
#   Purpose:    To run stress tests on the device stressing the IPC. The script keeps running   #
#               Data downloads, make calls, Send/Receive SMS continuously until the Iterations  #
#               specified.                                                                      #
#               The purpose of the script is to ensure the stability of the Baseband/AP builds  #
#                                                                                               #
#   Author:     Jerome Jesu                                                                     #
#   Contact:    jesu@apple.com                                                                  #
#                                                                                               #
#################################################################################################


SCRIPTS_DIR="/usr/local/etc/BasebandStressTests/"
scriptname=`basename $0`
source $SCRIPTS_DIR/config.sh

usage()
{
	echo "\nUSAGE:   $0 <DevicePhNumber> [ OPTIONS ]"
	echo " \t\t <DevicePhNumber>  --  Phone number of the Stress Test DUT."
	echo "\nOPTIONS: "
	echo "  -h <HOLD TIME in seconds> :  Default - 15s"
	echo "  -i <number of Iterations> :  Default - 1500"
	echo "  -n <Loop Back Number>     :  Default - +14089748874"
	echo "  -l <sms Loop Back Number> :  Default - +11111111111"
	echo "  -j <SSID>                 :  Default - CSIQA"
	echo "  -p <WEP Key>              :  Default - AP_WEPKEY"
	echo "  -u                        :  Default - UPLOAD to Server DISABLED"
	echo "  -g                        :  Default - Locmon DISABLED"
	echo "  -m                        :  Default - MultiRAB DISABLED"
	echo "  -s                        :  Default - SMS Failure Logging DISABLED"
	echo "  -d                        :  Default - Data Download Failure Logging DISABLED"
	echo "  -a                        :  Default - Additional Logging Disabled."
	echo "  -w                        :  Default - SleepCycling Enabled\n"
}

#/usr/local/bin/CoreTelephonyMonitor 2>CT.txt &

flag=0
source $SCRIPTS_DIR/Defaults.sh

IPCVERSION=" ######## Version:    IPCStressTestScripts_v25/$scriptname, $VERSION_PREFIX."
scriptname=`basename $0 | perl -lne 's/[.]//; s/sh//; print'`
scriptname="${scriptname}_${VERSION_PREFIX}"
echo $IPCVERSION $scriptname

echo " ****** LOOPS  -- $LOOPS."
echo " ****** Number -- $LOOP_BACK_NUMBER."
echo " ****** HOLD   -- $CALL_INTERVAL.\n\n"
echo " ****** Phone Number used for Loop-Back SMS --- $SMS_NUMBER ####"

##########################################################################
#################### START EXECUTING STRESS TESTS  #######################
##########################################################################

source $SCRIPTS_DIR/TestCases.sh
source $SCRIPTS_DIR/printStatistics.sh
source $SCRIPTS_DIR/uploadStatsLogs.sh
source $SCRIPTS_DIR/dumpingLogs.sh

if [ $isTopOutput -eq 1 ] && [ -e /$SCRIPTS_DIR/getMemoryStatus.sh ] &&  [ -e /$SCRIPTS_DIR/getTopOutput.sh ]; then
	nohup $SCRIPTS_DIR/getTopOutput.sh &
	nohup $SCRIPTS_DIR/getMemoryStatus.sh &
fi

if [ $additionalLoggging -eq 1 ] && [ -e /$SCRIPTS_DIR/setCommandsOnReset.sh ]; then 
	nohup $SCRIPTS_DIR/setCommandsOnReset.sh &
	sleep 1
fi

getBuildVersions
SUFFIX1=`echo $DEVICENAME | perl -lne '($s,$m,$H,$d,$M,$Y,$D) = localtime(); $Y += 1900; $M++; printf ("ipc_%s_Stats-%02d%02d-%02d%02d",$_,$M,$d,$H,$m); ' `
SUFFIX2=`echo $DEVICENAME | perl -lne '($s,$m,$H,$d,$M,$Y,$D) = localtime(); $Y += 1900; $M++; printf ("ipc_%s_Crashes-%02d%02d-%02d%02d",$_,$M,$d,$H,$m);'`
SUFFIX3=`echo $DEVICENAME | perl -lne '($s,$m,$H,$d,$M,$Y,$D) = localtime(); $Y += 1900; $M++; printf ("LOGS_%s-%02d%02d-%02d%02d",$_,$M,$d,$H,$m);'`
ResultsFile="/var/root/$SUFFIX1.csv"
CsiLogsFile="/var/root/$SUFFIX2.csv"
LOGSFILE="/var/root/$SUFFIX3.log"

echo "START_TIME, CURRENT_TIME, IMEI, DEVICE_NAME, AP_BUILD, BB_BUILD, ITERATIONS, Total BB RESETS, Total_CALLS, Total_SMS, CALL_DROPS, CALL_FAILURES, FTOs, Download_Attempts, Download Pass, Download Fails, DataFailPercent, AvgDownloadDataRate, Upload_Attempts, AvgUploadDataRate, CallFails_CT, SMSFails_CT, START_TIME(s), CURRENT_TIME(s), RUN_TIME(s), FirstResetTime(s), D3, PDPActAttempts, PDPActFAIL, UDID, RUN_TIME (Hours), ScriptName, Hardware" >> $ResultsFile


UploadedLogs="$logsDir/UploadedLogs/"
mkdir "RemovedLogs/"
mkdir $csiLogsDir/
rm /Library/Logs/CrashReporter/Power*

startTime=`date "+%s"`
firstResetTime=$startTime
tStartTime=`date -r $startTime | cut -c5-19`
lastStatsUploadTime=`date "+%s"`
lastLogsUploadTime=$lastStatsUploadTime


while [ $dcount -lt $LOOPS ]
do
		date
		((dcount++)) 
		((count++))
		((callCount++))
		((smsCount++))
		loopStartTime=`date "+%s"`
		
		echo "\n\n  ################### Begining Iteration - $dcount ####################\n"
		echo "\n\n  ################### Begining Iteration - $dcount ####################\n" >> DownloadStressTest.txt
	
	
		# 1a.  RE-START locmon after 25 iterations ONLY IF locmon is NOT running
		if [ "$EnableLocmon" ] && [ $(($dcount % 25)) -eq 0 ]; then  restartLocmonIfStopped; fi
		
		
		# Data Download for www.apple.com
		Repetition=1;  ((DataAttempts++));
		#DataAttempts=$(($DataAttempts + $Repetition));
		DownloadData $Repetition http://17.254.17.224/1MB.txt 1	
		if [ $DoSleep -eq 1 ]; then runSleepCycler 1 10;  fi



		# MAKING MO CALL 1
		echo "\n	####	MAKING MO CALL 1 - $callCount."
		rand=`expr $RANDOM % 10`
		callTimer=`expr $rand + 20`
		makeCALL $LOOP_BACK_NUMBER $callTimer $callCount			
		if [ $DoSleep -eq 1 ]; then  runSleepCycler 2 10; 	fi
		
		
		
	    # MOMT Loopback SMS-1 600+ chars
		echo "\n	####	Sending 600+ chars MO SMS(1) - $smsCount..."
		sendSMS $SMS_NUMBER $smsCount $SMSSTRING1						
		if [ $DoSleep -eq 1 ]; then  runSleepCycler 3 10; fi

		((count++))
		((callCount++))
		((smsCount++))
		#((mmsAudioCount++))		((mmsVideoCount++))		((mmsImageCount++))
				



		# MAKING DATA CALL 2
		Repetition=1; ((DataAttempts++));
		#DataAttempts=$(($DataAttempts + $Repetition));
		DownloadData $Repetition http://17.254.17.224/1MB.txt 1
		

		# MAKING MO call 2
		echo "\n	####	MAKING MO CALL 2 - $callCount."
		makeCALL $LOOP_BACK_NUMBER $callTimer $callCount
		#MultiCall $LOOP_BACK_NUMBER $Repetition http://17.254.17.224/1MB.txt $callCount 2
		if [ $DoSleep -eq 1 ]; then  runSleepCycler 4 10;  fi

		
		# 2b.  Collect Top output every 25 iterations
		if [ $(($dcount % 25)) -eq 0 ]; then
			if [ $(($dcount % 50)) -eq 0 ]; then  
				collectTopOutput;  
			else
				tail -f 50000 /var/root/Library/Caches/locationd/locationd.log >> /var/wireless/Library/Logs/CrashReporter/locationd_${dcount}.log &	
				sleepInterval=$((RANDOM % 120 + 120));
				echo "IDLE TIME:  Sleeping for $sleepInterval."
				sleep $sleepInterval;
			fi
		fi
				
		
		# MOMT Loopback SMS 2
		echo "\n	####	Sending SMS(2) - $smsCount..."
		sendSMS $SMS_NUMBER $smsCount $SMSSTRING2
			
		
		# Downloading 1 MB Data for 3rd time
		Repetition=1; ((DataAttempts++));
		#DataAttempts=$(($DataAttempts + $Repetition));
		DownloadData $Repetition http://17.254.17.224/1MB.txt 3
		if [ $DoSleep -eq 1 ]; then  runSleepCycler  5  10;  fi
		
		
		echo " \n*****($callCount.) Calls -- Pass: $pass FAIL: $fail. **** ($smsCount.) SMS Sent -- Pass: $spass FAIL: $sfail.*****\n"
		
		echo "Bringing datacontext up." ;
		((pdpAttempts++)) 
		echo "***** PDP Iteration - $dcount." >> DataContextStatus.txt
		DataContext up > /tmp/DataContextStatus
		#cat /tmp/DataContextStatus  >> DataContextStatus.txt
		#grep "Failed" /tmp/DataContextStatus
		#fail=$?
		#if [ $fail -eq 0 ]; then
		#	echo " **** PDP Context Activation Failed..."
		#	((pdpFails++))
		#	sleep 10
		#	takeK00lState "$count--ActivationFailed."
		#fi

		sleep 5;
		echo "Bringing datacontext down."; DataContext down;
		if [ $DoSleep -eq 1 ]; then runSleepCycler 6 10; fi
		
		
		# Log the Current System time in seconds	 	
		curTime=`date "+%s"`
		tcurTime=`date -r $curTime | cut -c5-19`
		
		# Time take for the current loop
		curLoopTimeTaken=$(($curTime - $loopStartTime))
		
		# Check if the timer expired to start printing/Dumping out the logs.
		checkTimeForUploadingStats=$(($curTime - $lastStatsUploadTime))
		checkTimeForUploadingLogs=$(($curTime - $lastLogsUploadTime))
		
		
		echo "\n STATS INTERVAL: $STATS_INTERVAL. "
		echo "\n ****** Current Time = $tcurTime, $curTime;  Loop Time = $curLoopTimeTaken; Loop StartTime = $loopStartTime "
		echo " ******  Last Stats UpLoad Time = $lastStatsUploadTime, LOGS = $lastLogsUploadTime;"
		echo " Check time for Stats = $checkTimeForUploadingStats ; check Time for Logs = $checkTimeForUploadingLogs ;\n"
		
		
		
		if [ $checkTimeForUploadingStats -ge $STATS_INTERVAL ] || [ $dcount -eq $LOOPS ]; then
			
			# print Statistics to the Results file
			echo "Printing Stats:"
			printIPCStatistics $startTime $curTime $dcount
						
			if [ "$UPLOAD" ] ;  then  
				echo "\n ******** Uploading Stats to the Server: ( $checkTimeForUploadingStats -- LastLogTime - $lastStatsUploadTime.)\n"
				uploadStats			
			fi			
			lastStatsUploadTime=`date "+%s"`
		fi
		
		
		if [ "$UPLOAD" ];	then 
			if [ $checkTimeForUploadingLogs -ge $LOG_INTERVAL ] || [ $dcount -eq $LOOPS ]; then
				echo "\n ******** Uploading Logs to the Server: ( $checkTimeForUploadingLogs -- LastLogTime - $lastLogsUploadTime.\n"
				# Comment out this line if Uploading logs using Wifi is not needed.
				uploadLogs;
				lastLogsUploadTime=`date "+%s"`
			fi
		fi
		
done
