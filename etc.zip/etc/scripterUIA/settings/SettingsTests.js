#import "./Settings.js"
#import "../libs/PHTesting.js"

//----------------------------------------------------------------------------------------
//	Function: settingsTest_createEmailAccount 
//		Creates a new Email account with the information provided.
//
//	Parameters: 
//		typeOfAccount (string) - the type of mail account from which the email is 
//			originating.  
//		name (string) - The name of the email account to create.  Should be username for
//			exchange.  For all other accounts, this should be the first and last name
//		address (string) - email address of the account
//		password (string) - password of the account
//   
//	Optional Parameters: 
//  	server (string) - server for use with Exchange or 'Other' email accounts.  If not entered,
//			function uses last part of email address
//		description (string) - This is the description of the email.  If none is provided, the address
//			of the account is used. 
//
//	Optional Parameters ('Other' accounts only):
//			usePop (bool) - "true" or "1" passed in if Pop account should be used.  Otherwise,	
//				IMAP is used.
//			inHostName (string) - incoming host name.  If not specified, uses 'server' first. If 'server' 
//				isn't specified, uses last section of 'address'
//			inUserName (string) - incoming username.  If not specified, uses 'name'.
//			inPassword (string) - incoming Password.  If not specified, uses 'password'.
//			outHostName (string) - outgoing host name.  If not specified, uses 'inHostName,' then 'server', then
//				last section of 'address'
//			outUserName (string) - outgoing user name.  If not specified, uses 'inUserName', then 'name', if you
//				want the field to be left empty, specify "BLANK"
//			outPassword (string) - outgoing password.  If not specified, uses 'inPassword', then 'password'.  If you
//				want the field to be left empty, specify "BLANK"
//
//  Optional Parameters (Sync):
//		GENERAL NOTES - The below parameters are used to setup sync.  Not all of these options are available for all accounts.
//		If you try to set an option that isn't there, the test will fail
//			mailSync (bool) - "true" or "1" passed in if contacts sync needs to be enabled. "false" or "0" 
//				passed in if contacts sync needs to be disabled. If no value is specified, the default value is used.
//			contactsSync (bool) - "true" or "1" passed in if contacts sync needs to be enabled. "false" or "0" 
//				passed in if contacts sync needs to be disabled. If no value is specified, the default value is used.
//			calendarsSync (bool) - "true" or "1" passed in if calendars sync needs to be enabled. "false" or "0" 
//				passed in if calendars sync needs to be disabled. If no value is specified, the default value is used.
//			bookmarksSync (bool) - "true" or "1" passed in if bookmarks sync needs to be enabled. "false" or "0" 
//				passed in if bookmarks sync needs to be disabled. If no value is specified, the default value is used.
//			notesSync (bool) - "true" or "1" passed in if bookmarks sync needs to be enabled. "false" or "0" 
//				passed in if bookmarks sync needs to be disabled. If no value is specified, the default value is used.
//			findMyDevice (bool) - "true" or "1" passed in if 'Find My iPhone' or 'Find My 'iPod Touch' needs to be enabled. 
//				"false" or "0" passed in if it needs to be disabled. If no value is specified, the default value is used.
//			shareLocation (bool) - "true" or "1" passed in if 'Find My iPhone' or 'Find My 'iPod Touch' needs to be enabled. 
//				"false" or "0" passed in if it needs to be disabled. If no value is specified, the default value is used.
// 		
// Optional Parameters (alerts):
//		alert:query:elementToTap -  This is used to dismiss dialog/alert boxes after an account is setup.  "query" indicates
//			the alert to look for and "element to tap" is the element in that alert to tap, if the alert is found.  As many of 
//			these can be specified as desired.  One example use case is setting up an "other" account that doesn't support SSL
//			(i.e. "alert:name matches 'Cannot Connect Using SSL':No").  
//
//	Returns:
//		0 if test failed, 1 if it succeeded.  Uses the PHTesting object.
//
//  Usage:
//		settingsTest_createEmailAccount "other" "Jane Doe" "jane@something.com" "password" "server:somethingelse.com" "inHostName:janedoe"
//----------------------------------------------------------------------------------------
function settingsTest_createEmailAccount() {
	this.testResult = 0;
	
	if (this.argv.length < 4) {		
		UIALogger.logError(this.testError);
		this.testError = "Not enough args were passed to this function."
		return 0;		
	}
	
	var typeOfAccount = this.argv[0];
	var name = this.argv[1];
	var address = this.argv[2];
	var password = this.argv[3]; 
	
	// push options onto optionsArray;
	var optionsArray = new Array();
	for (var i=3; i<this.argv.length; i++) {
		optionsArray.push(this.argv[i]);
	}
	
	var server = UIAUtility.valuesForKey("server", optionsArray, 1);  
	var description = UIAUtility.valuesForKey("description", optionsArray, 1);
	var alerts = UIAUtility.valuesForKey("alert", optionsArray);
	
	if (!description) description = address;  // if no description is provided use the email address

	var options = new Object();
	if (alerts) options.alerts = alerts;
	
	// if the account type is 'other', deal with those parameters...
	if (typeOfAccount.toLowerCase() == "other") {
		options.usePop = UIAUtility.valuesForKey("usePop", optionsArray, 1); 
		options.inHostName = UIAUtility.valuesForKey("inHostName", optionsArray, 1); 
		if (!options.inHostName) {
			if (server) options.inHostName = server;
			else {
				var indexOfAtSymbol = address.indexOf("@");
				options.inHostName = address.substring(indexOfAtSymbol + 1); // extract the server name (i.e whatever.com)
			}
		} 
		options.inUserName = UIAUtility.valuesForKey("inUserName", optionsArray, 1); 
		if (!options.inUserName) options.inUserName = name;
		options.inPassword = UIAUtility.valuesForKey("inPassword", optionsArray, 1); 
		if (!options.inPassword) options.inPassword = password;
		options.outHostName = UIAUtility.valuesForKey("outHostName", optionsArray, 1); 
		if (!options.outHostName) options.outHostName = options.inHostName;
		options.outUserName = UIAUtility.valuesForKey("outUserName", optionsArray, 1); 
		if (!options.outUserName) options.outUserName = options.inUserName;
		options.outPassword = UIAUtility.valuesForKey("outPassword", optionsArray, 1); 
		if (!options.outPassword) options.outPassword = options.inPassword;
		
		UIALogger.logMessage("usePop = " + options.usePop + ", inHostName = " + options.inHostName + 
			", inUserName = " + options.inUserName + ", inPassword = " + options.inPassword + 
			", outHostName = " + options.outHostName + ", outUserName = " + options.outUserName + 
			", outPassword = " + options.outPassword)
	}

	// Setup sync options
	options.mailSync = UIAUtility.valuesForKey("mailSync", optionsArray, 1);
	if (options.mailSync != null) 
		options.mailSync = (options.mailSync == "true" || options.mailSync == "1");
	
	options.contactsSync = UIAUtility.valuesForKey("contactsSync", optionsArray, 1);
	if (options.contactsSync != null) 
		options.contactsSync = (options.contactsSync == "true" || options.contactsSync == "1");
		
	options.calendarsSync = UIAUtility.valuesForKey("calendarsSync", optionsArray, 1);
	if (options.calendarsSync != null)
		options.calendarsSync = (options.calendarsSync == "true" || options.calendarsSync == "1");
		
	options.bookmarksSync = UIAUtility.valuesForKey("bookmarksSync", optionsArray, 1);
	if (options.bookmarksSync != null)
		options.bookmarksSync = (options.bookmarksSync == "true" || options.bookmarksSync == "1");
		
	options.notesSync = UIAUtility.valuesForKey("notesSync", optionsArray, 1);
	if (options.notesSync != null)
		options.notesSync = (options.notesSync == "true" || options.notesSync == "1");	
		
	options.findMyDevice = UIAUtility.valuesForKey("findMyDevice", optionsArray, 1);
	if (options.findMyDevice != null)
		options.findMyDevice = (options.findMyDevice == "true" || options.findMyDevice == "1");
		
	options.shareLocation = UIAUtility.valuesForKey("shareLocation", optionsArray, 1);
	if (options.shareLocation != null)
		options.shareLocation = (options.shareLocation == "true" || options.shareLocation == "1");

	try {
		settings.createEmailAccount(typeOfAccount, name, address, password, description, server, options);
	} catch (e) {
		if (e.message) this.testError = e.message;
		else this.testError = "An unknown error occurred."
		return this.testResult = 0;
	}
	return this.testResult = 1;
}

//----------------------------------------------------------------------------------------
//	Function: settingsTest_createCalDAVAccount 
//		Navigates to the CalDAV account pane, fills out the account info, and saves it
//
//	Parameters: 
//		username    (String) - name of the person that the account belongs to
//		password    (String) - password for the account
//		description (String) - a description for the account (can be null to leave the default value)
//		server      (String) - the server for the account
//	
//	Returns: 
//		0 if test failed, 1 if it succeeded.  Uses the PHTesting object.
//----------------------------------------------------------------------------------------
function settingsTest_createCalDAVAccount() {
	this.testResult = 0;
	
	if (this.argv.length < 4) {		
		UIALogger.logError(this.testError);
		this.testError = "Not enough args were passed to this function."
		return 0;		
	}
	
	var username = this.argv[0];
	var password = this.argv[1];
	var description = this.argv[2];
	var server = this.argv[3];
	
	try {
		settings.createCalDAVAccount(username, password, description, server);
	} catch (e) {
		if (e.message) this.testError = e.message;
		else this.testError = "An unknown error occurred."
		return this.testResult = 0;
	}
	return this.testResult = 1;

}

//----------------------------------------------------------------------------------------
//	Function: settingsTest_deleteEmailAccount 
//		Deletes an Email account. 
//
//	Requires:
//		The account exists
//
//	Parameters: 
//		address (string) - the address or description of the account to be deleted. If the 
//							provided value is null, the default account is used
//
//	Returns:
//	 0 if test failed, 1 if it succeeded.  Uses the PHTesting object.
//----------------------------------------------------------------------------------------
function settingsTest_deleteEmailAccount() {
	this.testResult = 0;
	
	if (this.argv.length < 1) {
		this.testError = "Not enough args were passed to the function."
		UIALogger.logMessage(this.testError);
		return 0;		
	}
	
	var address = this.argv[0];
	UIALogger.logMessage("Getting ready to delete the email account " + address);
	
	try {
		settings.deleteEmailAccount(address);
	} catch (e) {
		if (e.message) this.testError = e.message;
		else this.testError = "An unknown error occurred."
		return this.testResult = 0;
	}
	
	this.testResult = 1;
	UIALogger.logMessage("Account was deleted");
	return 1;
	
	
} 


// --------------------------------------------------------------------------------
//	Function: settingsTest_setWifi 
//		Sets wifi to desired place.
//
//	Parameters:
//		value (string) - Either 1 (for ON) or 0 (for OFF)
//		network (string) - If value is 1, this should be the name of the network.
//		password (string) - password to use for the chose network.
//
//
//  Optional Parameters:
//		backupNetworkName (string) - Specify an backup network here in the event the test cannot join the preferred network,  
//		backupPassword (string) - Password for the backup network
//		timeout (string) - number of seconds wait for the network to show up in WiFi Preferences
//
//	Returns:
//		1 if test succeeds, 0 if it fails.
//
//  Usage: 
//		settingsTest_setWifi "1" "Automation" "password" "backupNetwork:AppleWifi"
// --------------------------------------------------------------------------------
function settingsTest_setWifi()
{
	var value; 
	var network = "";
	var password = "";
	var backupNetworkName = "";
	var backupPassword = "";
	
	if (this.argv.length < 1) {
		this.testError = "Must enter at least one parameter: on/off";
		UIALogger.logError(arguments.callee.name, this.testError);
		return 0;
	}
	value = parseInt(this.argv[0]);
	
	if (this.argv.length > 1) {
		network = this.argv[1];
	}
	
	if (this.argv.length > 2) {
		password = this.argv[2];
	}
	
	// push options onto optionsArray;
	var optionsArray = new Array();
	for (var i=3; i<this.argv.length; i++) {
		optionsArray.push(this.argv[i]);
	}
	
	backupNetworkName = UIAUtility.valuesForKey("backupNetwork", optionsArray, 1);
	backupNetworkPassword = UIAUtility.valuesForKey("backupPassword", optionsArray, 1);
	timeout = UIAUtility.valuesForKey("timeout", optionsArray, 1);
	try {
		settings.setWifi(value, network, password, {backupNetwork:backupNetworkName, backupPassword:backupNetworkPassword, timeout:timeout});
	} catch(e) {
		UIALogger.logError(e.message);
		this.testError = e.message;
		return this.testResult = 0;
	}
	return this.testResult = 1;
	
} // end settingsTest_setWifi

// --------------------------------------------------------------------------------
//	Function: settingsTest_setWifiPro
//		Sets wifi to desired place.
//
//	Parameters:
//		value (string) - Either "1" (ON) or "0" (OFF)
//		network (string) - If value is 1, this should be the name of the network.
//		password (string) - password to use for the chose network.
//		networktype (string) - "broadcast", "hidden", means it is a hidden network, "enterprise", means it is a enterprise network, "profile" means it is using profile,
//			"WAPI" means WAPI PSK or HEX, "WAPI enterprise" means WAPI enterprise
//	 	security (string) - "None", "WEP, "WPA", "WPA2","WPA Enterprise", "WPA2 Enterprise" security type for hidden network (use "none" for enterprise broadcast/profile network)
//		 username (string) - the username for enterprise network
//
//
//  Optional Parameters:
//		timeout (string) - number of seconds wait for the network to show up in WiFi Preferences
//
//	Returns:
//		1 if test succeeds, 0 if it fails.
//
//  Usage: 
//		settingsTest_setWifiPro "1" "Automation" "password" "broadcast" "None" "" "timeout:5"
// --------------------------------------------------------------------------------
function settingsTest_setWifiPro()
{
	var value; 
	var network = "";
	var password = "";
	var networktype = "broadcast";
	var security = "None";
	var other = "Other…"; 
	var username = "";
	this.testResult = 0;
	
	if (this.argv.length < 1) {
		this.testError = "Must enter at least one parameter: '1' (ON) or '0' (OFF)";
		UIALogger.logError(arguments.callee.name, this.testError);
		return 0;
	}
	value = parseInt(this.argv[0]);
	
	if (this.argv.length > 1) {
		network = this.argv[1];
	} 
	
	if (this.argv.length > 2) {
		password = this.argv[2];
	}
	
	//if it is a hidden or enterprise network
	if (this.argv.length > 3) {
		networktype = this.argv[3];
	}
	
	if (this.argv.length > 4 ) {
		security = this.argv[4];
	}
	
	if (this.argv.length > 5) {
		username = this.argv[5]
	}
	
	var optionsArray = new Array();
	for (var i=6; i<this.argv.length; i++) {
		optionsArray.push(this.argv[i]);
	}
	
	var timeout = UIAUtility.valuesForKey("timeout", optionsArray, 1);
	
	if (networktype == "broadcast") {
		try {
			settings.setWifi(value, network, password, {timeout:timeout});
		} catch(e) {
			UIALogger.logError(e.message);
			this.testError = e.message;
			return this.testResult = 0;
		}
		
	} else if (networktype == "hidden") {
		try {
			settings.setWifiHidden(network, password, security, username, {timeout:timeout});
		} catch(e) {
			UIALogger.logError(e.message);
			this.testError = e.message;
			return this.testResult = 0;
		}
		
	} else if (networktype == "enterprise") {
		if (password == "" || username == "") {
			this.testError = "Did not provide password or username for Enterprise Network";
			return this.testResult = 0;
		}
		
		try {
			settings.setWifiEnterprise(network, password, username, {timeout:timeout});
		
		} catch(e) {
			UIALogger.logError(e.message);
			this.testError = e.message;
			return this.testResult = 0;
		}

	} else if (networktype == "profile") {
		try {
			settings.setWifiProfile(network, {timeout:timeout});
		} catch(e) {
			UIALogger.logError(e.message);
			this.testError = e.message;
			return this.testResult = 0;
		}
				
	} else if (networktype == "WAPI") {
		if (password == "") {
			this.testError = "Password is needed for WAPI, this test did not provide one";
			UIALogger.logError(this.testError);
			return this.testResult = 0;
		}
		try {
			settings.setWifiWAPI(network, password, {timeout:timeout});
		} catch(e) {
			UIALogger.logError(e.message);
			this.testError = e.message;
			return this.testResult = 0;
		}
				
	} else if (networktype == "WAPI enterprise") {
		try {
			settings.setWifiWAPIEnterprise(network, {timeout:timeout});
		} catch(e) {
			UIALogger.logError(e.message);
			this.testError = e.message;
			return this.testResult = 0;
		}
				
	} else {
		this.testError = "Wrong network type inputed, need to be 'broadcast', 'hidden', 'enterprise', 'profile', WAPI, or WAPI enterprise";
		UIALogger.logError(this.testError);
		return this.testResult = 0;
	}
	
	
	return this.testResult = 1;
	
} // end settingsTest_setWifiPro

// --------------------------------------------------------------------------------
//	Function: settingsTest_forgetWifi
//		Sets wifi to desired place.
//
//	Parameters:
//		network (string) - The name of the network.
//
//  Optional Parameters:
//		timeout (string) - number of seconds wait for the network to show up in WiFi Preferences
//
//	Returns:
//		1 if test succeeds, 0 if it fails.
//
//  Usage: 
//		settingsTest_forgetWifi "AppleWiFi"
// --------------------------------------------------------------------------------
function settingsTest_forgetWifi()
{
	var network = ""
	this.testResult = 0
	this.testError = ""
	var settingsTable;
	
	if (this.argv.length < 1) {
		this.testError = "Must enter at least one parameter: the name of the network you want to forget";
		UIALogger.logError(this.testError);
		return this.testResult;
	}
	
	network = this.argv[0];
	
	var optionsArray = new Array();
	for (var i=1; i<this.argv.length; i++) {
		optionsArray.push(this.argv[i]);
	}
	
	var timeout = UIAUtility.valuesForKey("timeout", optionsArray, 1);
	
	UIALogger.logMessage("Try to forget network: " + network);
	
	try {
		settings.getToWiFiNetworkDetailedView(network, {timeout:timeout})
	} catch(e) {
		UIALogger.logError(e.message)
		return this.testResult;
	}
	
	var date = new Date();
	if (UIATarget.localTarget().model() == 'iPad') {
		settingsTable = settings.mainWindow().tableViews()[1];
	} else {
		settingsTable = settings.mainWindow().tableViews()[0];
	}
	
	var forgetTableCell = settingsTable.cells().firstWithPredicate("name BEGINSWITH 'Forget this Network'")
	
	if (forgetTableCell.isValid()) {
		forgetTableCell.tap()
		UIATarget.localTarget().delay(2);
		
		if (UIATarget.localTarget().model() == 'iPad') {
			var lastAlert = settings.alertSinceDate(date);
			if (lastAlert != null && lastAlert.alertMessageArray[0].match(/^Forget.*/)) {
				UIALogger.logMessage("Forget alert shows and dismissed")

			} else {
				this.testError = "Did not pop up Forget Network Alert Window"
				UIALogger.logError(this.testError)
				return this.testResult = 0;
			}
		
		} else {
			var forgetButton = settings.actionSheet().buttons()["Forget"]
			if (forgetButton.isValid()) {
				forgetButton.tap()
				UIALogger.logMessage("Tapped Forget Button")
			} else {
				this.testError = "Did not pop up Forget Button"
				UIALogger.logError(this.testError)
				return this.testResult = 0;
			}
			
		}
		
		var detailNavigationBar = settings.mainWindow().navigationBars().firstWithPredicate("name matches '" + network + "'") 
		forgetTableCell = settingsTable.cells().firstWithPredicate("name BEGINSWITH 'Forget this Network'")
		//check if the alert window dispeared
		if(detailNavigationBar.isVisible()){
			UIALogger.logMessage("Forget the network alert window dispeared. Forget the network: "+network)

			//check if the Forget the Network table cell is gone
			if (!forgetTableCell.isValid()) {
				this.testError
				UIALogger.logMessage("Forget button disspeared, Forget the network passed")
				return this.testResult = 1;
			} else {
				this.testError = "Forget button is still showing"
				UIALogger.logError(this.testError)
				return this.testResult = 0;
			}

		} else {
			this.testError = "Did not return to network detail view"
			UIALogger.logError(this.testError)
			return this.testResult = 0;
		}
		
	} else {
		UIALogger.logError("Did not find 'Forget this Network' button for network '" + network);
		return this.testResult = 0;
	}
	
} // end settingsTest_forgetWifi


// --------------------------------------------------------------------------------
//	Function: settingsTest_ checkSSID
//		Sets wifi to desired place.
//
//	Parameters:
//		network (string) - The name of the network.
//
//	Returns:
//		1 if test succeeds, 0 if it fails.
//
//  Usage: 
//		settingsTest_checkSSID "AppleWiFi"
// --------------------------------------------------------------------------------
function settingsTest_checkSSID()
{
	this.testResult = 0
	this.testError = ""
	var timeout = 10
	
	
	if (this.argv.length < 1) {
		this.testError = "Must enter at least one parameter: the name of the network you want to check";
		UIALogger.logError(arguments.callee.name, this.testError);
		return this.testResult;
	}
	
	network = this.argv[0];
	
	UIALogger.logMessage("Try to check the if the joined network SSID matches: " + network);
	
	try {
		if (settings.checkWiFiName(network, timeout)) {
			return this.testResult = 1;
		} else {
			return this.testResult = 0;
		}
	} catch (e) {
		this.testError = e.message
		UIALogger.logError(this.testError)
		return this.testResult
	}
		
} // end settingsTest_checkSSID

// --------------------------------------------------------------------------------
//	Function: settingsTest_ installProfile
//		Install profiles. The profile window need to show up when run this test, 
//		because profile window is triggered by other applications.
//
//	Parameters:
//		password (option) - password needed for profile installation
//		timeout (option) - timeout wait for profile installation, default is 10 seconds
//
//	Returns:
//		1 if test succeeds, 0 if it fails.
//
//  Usage: 
//		settingsTest_installProfile
// --------------------------------------------------------------------------------
function settingsTest_installProfile()
{
	this.testResult = 0
	this.testError = ""
	var password = ""
	var timeout = 10
	
	if (this.argv.length > 0) {
		password = this.argv[0];
	}
	
	if (this.argv.length>1) {
		timeout = parseInt(this.argv[1]);
	}
	
	UIALogger.logMessage("Password for the profile is:" + password + ", timeout wait for profile installation is " + timeout + " seconds")
	
	if (settings.mainWindow().navigationBar().withName("Install Profile").isVisible()){
		UIALogger.logMessage("Install Profile Window shows up");
		try {
			settings.installProfile(password, timeout);
		} catch (e) {
			this.testError = e.message;
			UIALogger.logError(this.testError)
			return this.testResult = 0;
		}
		
	} else {
		this.testError = "Install Profile Window did not show up"
		UIALogger.logError(this.testError)
		return this.testResult = 0;
		
	}
	return this.testResult = 1;
	
} // end settingsTest_installProfile

// --------------------------------------------------------------------------------
//	Function: settingsTest_ deleteProfile
//		delete profiles. 
//
//	Parameters:
//	 	profile (string) - optional. Name of the profile to be deleted, if no argument, 
//						all the profiles will be deleted
//
//	Returns:
//		1 if test succeeds, 0 if it fails.
//
//  Usage: 
//		settingsTest_deleteProfile
// --------------------------------------------------------------------------------
function settingsTest_deleteProfile()
{
	this.testResult = 0
	this.testError = ""
	var profile = ""
	
	if (this.argv.length > 0) {
		profile = this.argv[0];
		UIALogger.logMessage("Delete profile: " + profile)
		try {
			settings.deleteProfile({profileName:profile});
		} catch (e) {
			this.testError = e.message;
			UIALogger.logError(this.testError)
			return this.testResult = 0;
		}
		
	} else {
		UIALogger.logMessage("Delete all profiles")
		try {
			settings.deleteProfile();
		} catch (e) {
			this.testError = e.message;
			UIALogger.logError(this.testError)
			return this.testResult = 0;
		}
	}

	
	
	return this.testResult = 1;
	
} // end settingsTest_deleteProfile

// --------------------------------------------------------------------------------
//	Function: settingsTest_setPersonalHotspot
//		Enable personal hotspot for WiFi from UI. 
//		Note: This test will unload the /System/Library/LaunchDaemons/com.apple.usbethernetsharing.plist
//		 (For Phnoenix): Enable the Personal Hotspot will cause the disconnect of telnet session. 
//		To run this function without the disconnect of the telnet session, 
//		need to set aside /System/Library/SystemConfiguration/USBEthernetSharing.bundle and reboot the device.  
//		Or alternatively, on the Mac host, set aside /System/Library/Extensions/AppleUSBEthernetHost.kext
//		From Telluride9A268, need to remove /System/Library/UserEventPlugins/USBEthernetSharing.plugin
//		and reboot test device to keep the Telnet session
//		
//
//	Parameters:
//		value (string) - Either "1" (ON) or "0" (OFF)
//		password (string) - password you want to set for your hotspot, need to be at least 8 chars,
//			default password is "12345678"
//		loadUSBTetheringPlistBack (boolean) - true, if you want to load the com.apple.usbethernetsharing.plist
//			back at the end of the test. This test need to unload the plist to maintain the telnet session.
//			Default is false
//
//	Returns:
//		1 if test succeeds, 0 if it fails.
//
//  Usage: 
//		settingsTest_setPersonalHotspot 1 12345678
// --------------------------------------------------------------------------------
function settingsTest_setPersonalHotspot()
{
	this.testResult = 0
	this.testError = ""
	var password = "12345678"
	var value = 1
	var loadUSBTetheringPlistBack = false

	if (this.argv.length < 1) {
		this.testError = "Must enter at least one parameter: '1' (ON) or '0' (OFF)";
		UIALogger.logError(this.testError);
		return 0;
	}
	value = parseInt(this.argv[0]);
	
	if (this.argv.length > 1) {
		password = this.argv[1];
		if (password.length < 8) {
			this.testError = "Must enter at least 8 char long for the password";
			UIALogger.logError(this.testError);
			return this.testResult;
		}
	}
	
	if (this.argv.length > 2) {
		loadUSBTetheringPlistBack = this.argv[2];
		if (loadUSBTetheringPlistBack == "true" || loadUSBTetheringPlistBack == "1") {
			loadUSBTetheringPlistBack = true
			UIALogger.logMessage("This test will load the USB Tethering Plist Back")
			
		} else {
			loadUSBTetheringPlistBack = false
			UIALogger.logMessage("This test will not load the USB Tethering Plist Back")
		}
	}
	
	UIALogger.logMessage("Set Personal Hostspot to: " + value + ", password is " + password)
	
	try {
		settings.setPersonalHotspot(value, password, loadUSBTetheringPlistBack);
	} catch (e) {
		this.testError = e.message;
		UIALogger.logError(this.testError)
		return this.testResult = 0;
	}
	
	return this.testResult = 1;
	
} // end settingsTest_setPersonalHotspot

// --------------------------------------------------------------------------------
//	Function: settingsTest_personalHotspotTimer
//		Test the personal Hotspot Timer if there is no client joined
//		Note: This test will unload the /System/Library/LaunchDaemons/com.apple.usbethernetsharing.plist
//		 (For Phnoenix): Enable the Personal Hotspot will cause the disconnect of telnet session. 
//		To run this function without the disconnect of the telnet session, 
//		need to set aside /System/Library/SystemConfiguration/USBEthernetSharing.bundle and reboot the device.  
//		Or alternatively, on the Mac host, set aside /System/Library/Extensions/AppleUSBEthernetHost.kext
//		From Telluride9A268, need to remove /System/Library/UserEventPlugins/USBEthernetSharing.plugin
//		and reboot test device to keep the Telnet session
//		
//
//	Parameters:
//		network (string) - network you want to check for auto join after timeout
//		password (string) - password you want to use for the personal hotspot
//		loadUSBTetheringPlistBack (boolean) - true, if you want to load the com.apple.usbethernetsharing.plist
//			back at the end of the test. This test need to unload the plist to maintain the telnet session.
//			Default is false
//
//	Returns:
//		1 if test succeeds, 0 if it fails.
//
//  Usage: 
//		settingsTest_personalHotspotTimer AppleWiFi 12345678
// --------------------------------------------------------------------------------
function settingsTest_personalHotspotTimer()
{
	this.testResult = 0;
	this.testError = "";
	var password = "12345678";
	var waitTimeAutoJoin = 15;
	var network = ""
	var loadUSBTetheringPlistBack = false;

	if (this.argv.length < 2) {
		this.testError = "Must supply the name of the network for Auto Join verification, and the password for the personal hotspot";
		UIALogger.logError(this.testError);
		return this.testResult;
	}
	
	network = this.argv[0];
	password = this.argv[1];
	if (password.length < 8) {
		this.testError = "Must enter at least 8 char long for the password";
		UIALogger.logError(this.testError);
		return this.testResult;
	}
		
	if (this.argv.length > 2) {
		loadUSBTetheringPlistBack = this.argv[2];
		if (loadUSBTetheringPlistBack == "true" || loadUSBTetheringPlistBack == "1") {
			loadUSBTetheringPlistBack = true;
			UIALogger.logMessage("This test will load the USB Tethering Plist Back")
		} else {
			loadUSBTetheringPlistBack = false;
			UIALogger.logMessage("This test will not load the USB Tethering Plist Back")
		}
	}
	
	
	UIALogger.logMessage("Test Personal Hostspot timer, check auto join with network: " + network);
	
	try {
		if (settings.checkWiFiName(network, 5)){
			UIALogger.logMessage("WiFi UI shows "+network);
		} else {
			var WiFiTableCellValue = settings.getWiFiTableCell().value();
			this.testError = "WiFi UI does not set to "+network+", UI shows: " + WiFiTableCellValue;
			UIALogger.logError(this.testError);
			return this.testResult = 0;
		}
		
	} catch (e) {
		this.testError = e.message;
		UIALogger.logError(this.testError);
		return this.testResult = 0;
	}
	
	try {
		settings.setPersonalHotspot(1, password, loadUSBTetheringPlistBack);
	} catch (e) {
		this.testError = e.message;
		UIALogger.logError(this.testError);
		return this.testResult = 0;
	}
	
	var date = new Date();
	UIALogger.logMessage("Enable Personal Hotspot at: " + date);
	
	UIALogger.logMessage("Navigate out off Personal Hotspot pane and check for Auto Join");
	try {
		settings.returnToTopLevel();
		if (settings.checkWiFiName(network, waitTimeAutoJoin)){
			var date = new Date();
			UIALogger.logMessage("WiFi UI shows "+network+" at: " + date);
		} else {
			var WiFiTableCellValue = settings.getWiFiTableCell().value();
			var date = new Date();
			this.testError = "WiFi UI does not set to "+network+" for Auto Join, UI shows: " + WiFiTableCellValue +", at time " + date;
			UIALogger.logError(this.testError);
			return this.testResult = 0;
		}
		
	} catch (e) {
		this.testError = e.message;
		UIALogger.logError(this.testError);
		return this.testResult = 0;
	}
	
	UIALogger.logMessage("Try to disable the Personal Hotspot")
	try {
		settings.setPersonalHotspot(0, password, loadUSBTetheringPlistBack);
	} catch (e) {
		this.testError = e.message;
		UIALogger.logError(this.testError);
		return this.testResult = 0;
	}
	
	return this.testResult = 1;
	
} // end settingsTest_setPersonalHotspot

// --------------------------------------------------------------------------------
//	Function: settingsTest_disconnectPersonalHotspotClients
//		Disconnect all personal hotspot clients for WiFi from UI. 
//
//	Parameters:
//		None
//
//	Returns:
//		1 if test succeeds, 0 if it fails.
//
//  Usage: 
//		settingsTest_disconnectPersonalHotspotClients
// --------------------------------------------------------------------------------
function settingsTest_disconnectPersonalHotspotClients()
{
	this.testResult = 0
	this.testError = ""

	try {
		UIALogger.logMessage("Start disconnect all personal hotspot clients")
		settings.disconnectPersonalHotspotClients();
	} catch (e) {
		this.testError = e.message;
		UIALogger.logError(this.testError)
		return this.testResult = 0;
	}
	
	return this.testResult = 1;
	
} // end settingsTest_disconnectPersonalHotspotClients

// --------------------------------------------------------------------------------
//	Function: settingsTest_deletePreferredNetwork
//		delete preferred WiFi network from Known Networks UI
//
//	Parameters:
//	 	network (string) - optional. Name of the network to be deleted, if no argument, 
//						all the network will be deleted
//
//	Returns:
//		1 if test succeeds, 0 if it fails.
//
//  Usage: 
//		settingsTest_deletePreferredNetwork AppleWiFi
// --------------------------------------------------------------------------------

function settingsTest_deletePreferredNetwork()
{
	this.testResult = 0
	this.testError = ""
	var network = ""

	if (this.argv.length < 1) {
		UIALogger.logMessage("This test will delete all the perferred networks from Known Networks UI")
	} else {
		network = this.argv[0]
		UIALogger.logMessage("This test will delete the perferred networks: " + network + " from Known Networks UI")
	}
	
	try {
		settings.deletePreferredNetwork(network);
	} catch (e) {
		this.testError = e.message;
		UIALogger.logError(this.testError)
		return this.testResult = 0;
	}
	
	return this.testResult = 1;
	
} // end settingsTest_deletePreferredNetwork

// --------------------------------------------------------------------------------
//	Function: settingsTest_checkWAPIUI
//		check if China device shows WLAN not WiFi on UI
//
//	Parameters:
//	 	None
//
//	Returns:
//		1 if test succeeds, 0 if it fails.
//
//  Usage: 
//		settingsTest_checkWAPIUI
// --------------------------------------------------------------------------------

function settingsTest_checkWAPIUI()
{
	this.testResult = 0
	this.testError = ""
	var network = ""
	
	try {
		if (settings.checkWAPIUI()) {
			return this.testResult = 1;
		} else {
			this.testError = "This is not a China device, could not run this test"
			UIALogger.logError(this.testError)
			return this.testResult = 0;
		}
	} catch (e) {
		this.testError = e.message;
		UIALogger.logError(this.testError)
		return this.testResult = 0;
	}
	
	
	
} // end settingsTest_checkWAPIUI


/// --------------------------------------------------------------------------------
//	Function: settingsTest_chooseCheckmarkedItem 
//		Chooses the chosen check-marked item in the settings test.
//
//	Parameters:
//		viewsToNavigate (string) ...  levels of setting's tablecells to navigate to.
//		checkedItem (string) - The Name of the item to be chosen.
//
//  Options:
//      noValidation (string) - set to "true" if you want to skip validation.
//          This is useful if the item doesn't show a checkmark after it's 
//          selected.  (i.e. "Mail, Contacts, Calendars" -> "My Info")
//
//	Returns:
//		1 if test succeeds, 0 if it fails.
// --------------------------------------------------------------------------------
function settingsTest_chooseCheckmarkedItem() 
{

	var checkedItem;
	var viewsToNavigate = new Array();
	
	if (this.argv.length < 2) {
		this.testError = "Must enter at least two parameters: viewsToNavigate, checkedItem";
		UIALogger.logError(this.testError);
		return this.testResult = 0;
	}
	
	// take care of optional parameters
	var options = new Object();
	options.noValidation = UIAUtility.valuesForKey("noValidation", this.argv, 1);  
	if (options.noValidation != null) {
	    this.argv.pop(); // pop the optional parameter off of the end.
	}
	
	checkedItem = this.argv.pop();

	settings.launchIfNotActive();
			
	// push navigation views onto an array of additional settings table cells
	for (var levelIndex = 0; levelIndex < this.argv.length; levelIndex++) {
		viewsToNavigate.push(this.argv[levelIndex]);
	}
	
	if (!viewsToNavigate || !checkedItem) {
		this.testError = "One of the parameters passed in was not valid.";
		UIALogger.logError(this.testError);
		return this.testResult = 0;
	}
	
	
	try {
		settings.chooseCheckmarkedItem(checkedItem, viewsToNavigate, options);
	} catch(e) {
		settings.logElementTree();
		this.testError = e.message;
		UIALogger.logError(this.testError);
		return this.testResult = 0;
	}
	
	return this.testResult = 1;
	
} // end settingsTest_chooseCheckmarkedItem




// --------------------------------------------------------------------------------
//	Function: settingsTest_changeSingleSwitch 
//		Changes a switch in settings (or verifies that
//		the the switch is already set to the desired value).
//
//	Parameters:
//		viewsToNavigate (array) - An array containing the path that should be followed to
//									reach the switch to change. Each element will correspond
//									to a table cell to tap.  By default, the test will 
//									return to the top level of the navigation hierarchy before 
//									attempting to navigate to the table containing the switch
//									to change.
//		switchName (string) - The name of the switch to change.
//		switchValue (string) - The value that the switch should be set to:
//									0: OFF 
//									1: ON	
//
//	Returns:
//		1 if test succeeds, 0 if it fails.
// --------------------------------------------------------------------------------
function settingsTest_changeSingleSwitch() 
{
	var switchName;
	var switchValue;
	var viewsToNavigate = new Array();
	var argvArrayLength = this.argv.length;
	this.testResult = 0;
	
	if (this.argv.length < 2) {
		this.testError = "Must enter three parameters: viewsToNavigate, switchName and switchValue";
		UIALogger.logError(this.testError);
		return this.testResult = 0;
	} else {
		switchValue = this.argv.pop();
		switchName = this.argv.pop();
		viewsToNavigate = this.argv;
	}		
	
	system.sleep(1);
	settings.launchIfNotActive();

	settings.changeSingleSwitch(viewsToNavigate, switchName, switchValue);
	
	return this.testResult = 1;
}


// --------------------------------------------------------------------------------
//	Function: settingsTest_setSliderToValue() 
//		Changes a slider in settings (or verifies that the the slider is already set to the desired value).
//
//	Parameters:
//		viewsToNavigate (array) - An array containing the path that should be followed to
//									reach the slider to change. Each element will correspond
//									to a table cell to tap.  By default, the test will 
//									return to the top level of the navigation hierarchy before 
//									attempting to navigate to the table containing the slider
//									to change.
//		sliderName (string) - The name of the slider to change.
//		sliderValue (float) - A decimal value between 0 and 1 to set the slider to
//
//	Returns:
//		1 if test succeeds, 0 if it fails.
// --------------------------------------------------------------------------------
function settingsTest_setSliderToValue()
{
	var sliderName;
	var sliderValue;
	var viewsToNavigate = new Array();
	var argvArrayLength = this.argv.length;
	this.testResult = 0;
	
	if (this.argv.length < 2) {
		this.testError = "Must enter three parameters: viewsToNavigate, sliderName and sliderValues";
		UIALogger.logError(this.testError);
		return this.testResult = 0;
	} else {
		sliderValue = this.argv.pop();
		sliderName = this.argv.pop();
		viewsToNavigate = this.argv;
	}		
	
	system.sleep(1);
	settings.launchIfNotActive();
	
	UIALogger.logMessage("Navigating the view hierarchy with path: " + viewsToNavigate.join( " -> " ) );
	
	try {
		settings.navigateNavigationViews(viewsToNavigate, {returnToTopLevel:true});
	} catch (e) {
		UIALogger.logError(e.message);
		this.testError = "Could not navigate to '" + sliderName + "'";
		UIALogger.logError(this.testError);
		return this.testResult = 0;
	}


	try {
		settings.setSliderSetting(sliderName, sliderValue);
	} catch (e) {
		this.testError = e.message;
		UIALogger.logError(this.testError);
		return this.testResult = 0;
	}
	
	return this.testResult = 1;
}


// --------------------------------------------------------------------------------
//	Function: settingsTest_setWallpaper
//		Sets the wallpaper from the settings page. It selects the first wallpaper on the page
//
//	Parameters:
//	  choice (optional) - choose from Wallpaper, Camera Roll, etc. It is set to 
//	  Wallpaper by default. 
//
//	Returns:
//	 1 if test succeeds, 0 if not.
// --------------------------------------------------------------------------------
function settingsTest_setWallpaper() {

	this.testResult = 0;
	var photoChoice = "Wallpaper";
	var supportsHomeScreenWallpaper;
	
	if (this.argv.length > 0) photoChoice = this.argv[0];
	
	UIATarget.localTarget().pushTimeout(1);

	settings.launchIfNotActive();
	try {
		settings.selectWallpaper(photoChoice);
	} catch (e) {
		UIALogger.logMessage(e.message);
		this.testError = "Could not select a wallpaper";
		UIALogger.logError(this.testError);
		//DEBUG 
		settings.logElementTree();
        return this.testResult = 0;
	}
	
	UIALogger.logMessage(arguments.callee.name + ": Set the wallpaper successfully");
	return this.testResult = 1;
}


// --------------------------------------------------------------------------------
//	Function: systemTest_setPasscode 
//		Sets the passcode on the device.
//
//	Required Parameters:
//		passcode (string) - passcode to set
//		
//	Optional Parameters:
//		currentPasscode (string) - the current passcode.  used when prompted for a 
//									passcode when setting a new passcode
//
//	Returns:
//		1 on pass, 0 (or 64) on fail.  
// --------------------------------------------------------------------------------
function settingsTest_setPasscode() {

	if (this.argv.length < 1) {
		UIALogger.logError(this.testName + ": Passcode to set not specified.");
		return 64;		
	}

	var currentPasscode;
	if (this.argv.length == 2) {
		currentPasscode = this.argv[1];
	}
	
	this.testResult = 0;
 	var passcode = this.argv[0];
	
	UIALogger.logMessage("Setting passcode to '" + passcode + "'.");

	settings.launchIfNotActive();
	
	try {
		settings.setPasscode(passcode, currentPasscode);
	} catch (e) {
		UIALogger.logError(e);
		this.testError = "Failed to set passcode.";
		UIALogger.logError(this.testError);
		return this.testResult = 0;
	}

		UIALogger.logMessage("Passcode set.");
		return this.testResult = 1;
}  // end systemTest_setPasscode

// --------------------------------------------------------------------------------
//	Function: systemTest_turnPasscodeOff
//		Turn passcode off.
//
//	Parameters:
//		passcode (string) - passcode to turn off (optional)
//
//	Returns:
//		1 on pass, 0 on fail.  
// --------------------------------------------------------------------------------
function settingsTest_turnPasscodeOff() {
	var passcode = null;
	
	if (this.argv.length > 0) passcode = this.argv[0];
 	
	UIALogger.logMessage("Disabling passcode.");

	settings.launchIfNotActive();

	try {
		settings.turnPasscodeOff(passcode);
	} catch (e) {
		settings.mainWindow().logElementTree();
		this.testError = "Failed to disable passcode.";
		UIALogger.logError(this.testError);
		return this.testResult = 0;
	}

	UIALogger.logMessage("Passcode disabled.");
	return this.testResult = 1;

} // end systemTest_turnPasscodeOff
 

// --------------------------------------------------------------------------------
//	Function: settingsTest_turnLocationdLoggingOn
//		Turn locationd logging on 
//
//	Parameters:
//		None
//
//	Returns:
//		1 on pass, 0 on fail.  
// --------------------------------------------------------------------------------
function settingsTest_turnLocationdLoggingOn() {
	settings.launchIfNotActive();
	try {
		settings.turnLocationdLoggingOn();
	} catch(e) {
		UIALogger.logError(e.message);
		UIALogger.logError("Could not kill the locationd daemon");
		this.testError = "Could not kill the locationd daemon";
		return this.testResult = 0;
	}
	
	return this.testResult = 1;
	
}	// end settingsTest_turnLocationdLoggingOn

// --------------------------------------------------------------------------------
//	Function: settingsTest_setForwardingPhoneNumber
//		Set the forwarding phone number for a device - this test is essentially
//		a wrapper around the setForwardingPhoneNumber method
//
//	Parameters:
//		forwardingSetting (int) - 1 or 0 to turn forwarding on or off, respectively
//		phoneNumber (string) - the phone number to forward to - any formatting is 
//								allowed - all spaces, parenthases and hyphens will
//								be stripped from this parameter, leaving any formatting 
//								to be handled by the Settings app
//
//	Returns:
//		1 on pass, 0 on fail.  
// --------------------------------------------------------------------------------

function settingsTest_setForwardingPhoneNumber() {

	
	if (this.argv.length < 1) {
		UIALogger.logError(this.testName + ": No arguments specified");
		return 64;		
	}
	
	var forwardingSetting;
	if (this.argv.length > 0) {
		forwardingSetting = parseInt(this.argv[0]);
	}
	
	var phoneNumber;
	if (this.argv.length == 2) {
		phoneNumber = this.argv[1];
	}
	
	try {
		settings.setForwardingPhoneNumber(forwardingSetting, phoneNumber);
	} catch(e){
		UIALogger.logError("Failed to set the forwarding phone number setting - " + e.message);
		this.testError = "Failed to set the forwarding phone number setting - " + e.message;
		return this.testResult = 0;
	}

	return this.testResult = 1;
	
} // end settingsTest_setForwardingPhoneNumber


// --------------------------------------------------------------------------------
//	Function: settingsTest_tryOTAUpdate
//		Turn locationd logging on 
//
//	Parameters:
//		None
//
//	Returns:
//		1 on pass, 0 on fail.  
// --------------------------------------------------------------------------------
function settingsTest_tryOTAUpdate() {
	settings.launchIfNotActive();
	try {
		settings.tryOTAUpdate();
	} catch(e) {
		UIALogger.logError(e.message);
		UIALogger.logError("Could not find update");
		this.testError = "Could not find update";
		return this.testResult = 0;
	}
	
	return this.testResult = 1;
	
}	// end settingsTest_tryOTAUpdate


// Create self tests -- this is an unnamed function, just to make sure any local variables stay in the correct context
(function() {	
	if (typeof settings.selfTests == 'undefined') {
		settings.selfTests = new Array();
	}

	if (system.hasCapability("wifi")) {
		settings.selfTests.push(phtCreateTest("SetWifiOn", ["1", "AppleWiFi"], settingsTest_setWifi, "Turn wifi on and set it to AppleWiFi"));
	}
	// createEmailAccount()
	settings.selfTests.push(phtCreateTest("CreateMobileMeAccount", ["me", "Testing Tester", "weliketesting@me.com", "testtest", "contactsSync:0", "bookmarksSync:0", "calendarsSync:0", "notesSync:0"], 
			settingsTest_createEmailAccount, "Create 'me' account")); // expected to fail, if this account is already there
	settings.selfTests.push(phtCreateTest("CreateGmailAccount", ["gmail","Testing Gmail","weliketesting@gmail.com", "testtest"], settingsTest_createEmailAccount, "Create a gmail account"));
	settings.selfTests.push(phtCreateTest("CreateYahooAccount", ["yahoo","Testing Yahoo","weliketesting@yahoo.com", "testtest"], settingsTest_createEmailAccount, "Create a yahoo account"));
	settings.selfTests.push(phtCreateTest("CreateAolAccount", ["aol","Testing AOL","weliketesting@aol.com", "Required"], settingsTest_createEmailAccount, "Create an aol account"));
	settings.selfTests.push(phtCreateTest("CreateExchange07Account", ["exchange", "kyle06", "kyle06@applex.apple.com", "Apple1984", "description:ExchangeAccount", "server:xedge2.apple.com", "contactsSync:0", "calendarsSync:0", "alert:Cannot Verify Server Identity:Continue"], 
				settingsTest_createEmailAccount, "Create an exchange 2007 account"));
	// XXX - TODO -- find a valid 'other' account to add to list, should look something like below:
	
	settings.selfTests.push(phtCreateTest("DeleteGmailAccount", ["weliketesting@gmail.com"], settingsTest_deleteEmailAccount, "Delete a gmail account"));
	settings.selfTests.push(phtCreateTest("EnableBatteryLifeLogging", ["Internal Settings", "Power", "Battery Life Logging", "1"], settingsTest_changeSingleSwitch, "Enable Battery Life Logging"));	
	settings.selfTests.push(phtCreateTest("EnableWifiLogging", ["Internal Settings", "WiFi", "Logging", "UI Logging", 1], settingsTest_changeSingleSwitch, "Enable Wifi Logging"));
	settings.selfTests.push(phtCreateTest("EnableWifiManagerLogging", ["Internal Settings", "WiFi", "Logging", "WiFi Manager", "Logging", "1"], settingsTest_changeSingleSwitch, "Enable WifiManager Logging"));
	settings.selfTests.push(phtCreateTest("EnableWifiManagerFileLogging", ["Internal Settings", "WiFi", "Logging", "WiFi Manager", "File Logging", "1"], settingsTest_changeSingleSwitch, "Enable WifiManager File Logging"));
	if (UIATarget.localTarget().model() == 'iPad')
		settings.selfTests.push(phtCreateTest("SetBrightnessValue", ["Brightness & Wallpaper", "Screen brightness", "0.27"], settingsTest_setSliderToValue, "Set the Brightness Level"));
	else 
		settings.selfTests.push(phtCreateTest("SetBrightnessValue", ["Brightness", "brightness", "0.27"], settingsTest_setSliderToValue, "Set the Brightness Level"));
	settings.selfTests.push(phtCreateTest("SetAutoLockToNever", ["General", "Auto-Lock", "Never"], settingsTest_chooseCheckmarkedItem, "Set Auto-Lock to Never"));
	settings.selfTests.push(phtCreateTest("SetPasscode", ["1111"], settingsTest_setPasscode, "Set a passcode for the device"));
	settings.selfTests.push(phtCreateTest("ChangePasscode", ["2222"], settingsTest_setPasscode, "Change the passcode on the device"));
	settings.selfTests.push(phtCreateTest("TurnPasscodeOff", ["2222"], settingsTest_turnPasscodeOff, "Turn passcode for the device off"));
	settings.selfTests.push(phtCreateTest("SetWallpaper", [], settingsTest_setWallpaper, "Set wallpaper to something from wallpaper"));		
}())
