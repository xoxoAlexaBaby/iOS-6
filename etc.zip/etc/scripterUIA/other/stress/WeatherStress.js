#import "UIAAppStressLibrary.js"

var cityList = new Array( 
		"Los Angeles", "San Francisco", "Seatle", "Washington", "New York", "Denver", "Atlanta", "Boston", 
		"San Jose", "Las Vegas", "Orlando", "Nashville", "New Orleans", "Dallas", "Portland"
		);


if (typeof weather != 'undefined') {
	weatherStress = AppStressBase.stressTest("Weather");
	
	if (typeof weatherStress != 'undefined') {
		weatherStress._cityList = new Array();
		
		weatherStress.setup = function setup() {
			weatherStress.addTest(weatherStress._addCity);
			weatherStress.addTest(weatherStress._deleteCity);
			weatherStress.addTest(weatherStress._slideToCity);
			weatherStress.addTest(weatherStress._goToYahooPage);
		}
		
		weatherStress.run = function run() {
			weatherStress.executeRandomTests(3);
		}
		
		// add a city
		weatherStress._addCity = function _addCity() {
			var result;
			var city = UIAUtility.randomFromArray(cityList);
			
			result = weatherStress.executeTest("AddCity", [city], weatherTest_addCity, "Add " + city + " to saved cities.");
			
			if (result) {
				if (weatherStress._cityList.indexOf(city) == -1) {
					weatherStress._cityList.push(city);
				}
			}
			
			return result;
		}
		
		// delete a city
		weatherStress._deleteCity = function _deleteCity() {
			var city;
			var index;
			var result;
			
			if (weatherStress._cityList.length == 0) {
				city = UIAUtility.randomFromArray(cityList);
			}
			else {
				city = UIAUtility.randomFromArray(weatherStress._cityList);
			}
			
			result = weatherStress.executeTest("DeleteCity", [city], weatherTest_deleteCity, "Delete " + city + " from saved cities.");
			
			if (result) {
				index = weatherStress._cityList.indexOf(city); 
				if (index > -1) { weatherStress._cityList.splice(index) }
			}
			
			return result;
		}
		
		// slide to a specified city
		weatherStress._slideToCity = function _slideToCity() {
			var city;
			var result;
			
			if(weatherStress._cityList.length == 0) {
				result = weatherStress._addCity();
				if (result == false) {
					UIALogger.logError("Unable to add city -- skipping test.");
					return false; 
				}
			}
			
			city = UIAUtility.randomFromArray(weatherStress._cityList);
			
			result = weatherStress.executeTest("SlideToCity", [city], weatherTest_slideToCity, "Slide to " + city + ".");
			
			
			return result;
		}
		
		// go to the Yahoo weather page
		weatherStress._goToYahooPage = function _goToYahooPage() {
			weatherStress.executeTest("GoToYahooPage", [], weatherTest_goToYahooPage, "Go to the Yahoo weather page.");
		}
	}
}