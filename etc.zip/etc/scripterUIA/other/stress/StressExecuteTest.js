#!/usr/local/bin/scripter -uiautomation YES -f

#import "/usr/local/etc/scripterUIA/libs/PHTesting.js"
#import "StressUtilsFull.js"


UIAApp.prototype.shouldUseSwitcherForLaunching = true;

test.testName = "ExecuteTest"
if (ARGV && (ARGV.length > 0)) test.main = eval(ARGV.shift());
test.argv = ARGV;

test.execute();