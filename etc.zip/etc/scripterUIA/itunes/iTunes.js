/*
 Class: UIApp (itunes)
 iTunes object
 */

#import "../libs/SpringBoard.js"
#import "../libs/UIAAppMediaAdditions.js"

itunes = UIAApp.application("iTunes", "com.apple.MobileStore");

if (typeof itunes != 'undefined') {

	//overwriting this to also account for the Loading... that comes up on the main view
	itunes.waitForNetworkLoadingToFinish = function waitForNetworkLoadingToFinish(seconds) {
		if (!seconds) seconds = 60;
		if (!this.__proto__.waitForNetworkLoadingToFinish.apply(this, [seconds])) return false;
		var loadingText = this.mainWindow().staticTexts().firstWithPredicate("name contains 'Loading'");
		if (loadingText.isValid()) {
			UIALogger.logDebug("Loading text found in the main window. Waiting for it to go away...");
			UIATarget.localTarget().pushTimeout(seconds);
			var didLoad = this.waitForInvisible(loadingText);
			UIATarget.localTarget().popTimeout();
			return didLoad;
		}
		return true;
	}
	
	itunes.launchIfNotActive = function launchIfNotActive() {
		this.__proto__.launchIfNotActive.apply(this);
		this.waitForNetworkLoadingToFinish(60);
	}
	
	// --------------------------------------------------------------------------------
	//	Function: getToView
	//		Goes to the specified view using the button bar buttons
	//
	//	Parameters:	
	//		viewName (string) - name of the view to switch to; Featured, Search, More, etc.
	//
	//	Returns: 
	//		None
	// --------------------------------------------------------------------------------
	itunes.getToView = function getToView(viewName) {
		this.launchIfNotActive();
		
		if (this.isInVideoView()) {
			UIALogger.logMessage("Video is playing. Tapping Done.");
			try {
				//sometimes this might return false if the video just ended
				this.videoControlWithName('Done').tap();
			} catch(e) {
				UIALogger.logDebug("Encountered error while trying to tap Done: " + e.message);
				UIALogger.logDebug("Checking if the video view is still visible...");
				if (this.isInVideoView()) throw new Error("Could not tap the 'Done' button");
			}
		}
		
		var tabBar = this.tabBar();
		if (!tabBar.withPredicate("isVisible == 1").isValid()) {
			UIALogger.logDebug("Tab bar not visible -- might be because a popover is up");
			UIATarget.localTarget().tap(tabBar.rect());
			if (!tabBar.withPredicate("isVisible == 1")) UIALogger.logWarning("Tab bar still not visible");
		}
		
		UIALogger.logDebug("Going to '" + viewName + "'");
		var tabButton = tabBar.buttons().firstWithPredicate("name contains '" + viewName + "'");
		tabButton.tap();
		if (!tabButton.withValueForKey(1, "value").isValid()) 
			throw new Error("Tapped the '" + viewName + "' button, but the value did not change");
		this.waitForNetworkLoadingToFinish();
	}
	
	//----------------------------------------------------------------------------------------
	//	Function: priceButtonForTrack 
	//		returns the price button (for purchasing) for this element.
	//
	//	Arguments: 
	//		track (track object) - the track object, the price button for which needs to be returned. 
	//			The track object value used, in most cases, should be the return value of navigateItemSelection.
	//			For more infomation, refer to the function description of navigateItemSelection.
	//
	//	Returns: 
	//		the UIAElement object corresponding to the price button. If no valid price button 
	//		object is found, null is returned. 
	//----------------------------------------------------------------------------------------
	itunes.priceButtonForTrack = function priceButtonForTrack(track) {
		var priceButton;
		if (!track) return null;
		if (UIATarget.localTarget().model() == 'iPad')
			priceButton = track.purchaseButton;
		else {
			if (track instanceof UIATableCell) {
				priceButton = track.buttons().firstWithPredicate("name == 'FREE' or name matches '.*[0-9]+.*'");
			} else if (track.purchaseButton) {
				priceButton = track.purchaseButton;
			}
		}
		if (priceButton && !priceButton.isValid()) return null;
		return priceButton;
	}
	
	//----------------------------------------------------------------------------------------
	//	Function: previewTrack 
	//		start the preview of the specified track
	//
	//	Arguments: 
	//		track (track object) - the track object that needs to be previewed.
	//			The track object value used, in most cases, should be the return value of navigateItemSelection.
	//			For more infomation, refer to the function description of navigateItemSelection.
	//
	//	Returns: 
	//		None
	//----------------------------------------------------------------------------------------
	itunes.previewTrack = function previewTrack(track) {
		if (UIATarget.localTarget().model() == 'iPad') {
			if (!track.previewButton || !track.previewButton.isValid()) 
				throw new Error("Did not find a preview button");
			UIALogger.logDebug("Previewing " + track.previewButton.name());
			track.previewButton.scrollToVisible();
			track.previewButton.tap();
		} else {
			//need to make sure it is preview-able element
			if (track.previewButton && track.previewButton.isValid()) {
				UIALogger.logDebug("Previewing " + track.previewButton.name());
				track.previewButton.scrollToVisible();
				track.previewButton.tap();
			} else if (track instanceof UIAElement) {
				UIALogger.logDebug("Previewing " + track.name());
				track.scrollToVisible();
				track.tap();
			} else {
				throw new Error("Unknown track type -- cannot preview");
			}
		} 
	}
	
	
	//helper function to gather all the track items in the current view
	itunes._itemsInCurrentView = function _itemsInCurrentView() {
		
		//Few notes:
		//1. there are two types of items - those that contain price buttons, and the others that don't
		//2. those items that don't contain the price button are UIAElement
		//3. those items that do contain the price buttons can be UIAElement (for iPhone and iPod Touch devices) or dictionary objects
		//		with priceButton and previewButton keys (the values are UIAElement)
		items = new Array();
		//table view is present only in a few views in iPhones and iPod touches
		if (UIATarget.localTarget().model() == 'iPad' || !this.mainWindow().tableViews()[0].isValid()) {
			var scrollViews = this.mainWindow().scrollViews().withPredicate("isVisible == 1 and ANY webViews.isVisible == 1"); //going through all the scrollViews
			for (var i=0; i<scrollViews.length; i++) {
				var webView = scrollViews[i].webViews()[0];
				if (webView.rect().origin.x < 0) continue ; //need to skip the scroll views that report isVisible == 1 because they are only partially visible
				//add all the links -- avoid a few that we know will not help at all
				items = items.concat(webView.links().withPredicate("name != 'Write a Review ' && (not name contains 'review') && name != 'More' && name != 'iTunes Store Terms and Conditions...' && name != 'Read More About This Movie On Rotten Tomatoes' && name != 'Tell a Friend'").toArray());
				
				//check if tap to preview exists
				UIATarget.localTarget().pushTimeout(0);
				var tapToPreviewText = webView.staticTexts()["Tap to Preview"];
				UIATarget.localTarget().popTimeout();
				//figure out we are in the track list view or not 
				if (UIATarget.localTarget().model() != 'iPad' || tapToPreviewText.isValid()) {
					UIALogger.logDebug("In track list view");
					var elements = webView.elements().toArray();
					var firstPreviewItemIndex, previewItemIndex;
					//since there are no table cells elements that represent the track element on iPad, we need to collect the information in dictionary objects
					for (var i=0; i<elements.length; i++) { 
						if (elements[i].name() == "1") firstPreviewItemIndex = i;
					}

					var previewItemNumber = 1;
					var counter = firstPreviewItemIndex;
					var latestObject;
					while (counter < elements.length) {
						if (!latestObject) {
							//looking for the label itself
							if (elements[counter].name() == previewItemNumber) {
								UIALogger.logDebug("Found preview number " + previewItemNumber);
								latestObject = new Object();
								//found the label index -- now find the preview element
								//if (counter > 1 && elements[counter-1].name() && elements[counter-1].name().indexOf('Preview') >= 0)  {
									//preview button found
								//	latestObject.previewButton = elements[counter-1];
								//} else {
									//set it to itself
									latestObject.previewButton = elements[counter];
								//}
							}
						} else if (elements[counter].name() == "Album Only") {
							//need to get rid of the the current item since it cannot be purchases
							UIALogger.logDebug("Not using preview number " + previewItemNumber);
							previewItemNumber++;
							latestObject = null;
						} else if (elements[counter] instanceof UIAStaticText && latestObject.trackName == null && elements[counter].name() != "Video") {
							latestObject.trackName = elements[counter].name();
							UIALogger.logDebug("The track name is " + latestObject.trackName);
						} else {
							//check to see if this is the purchase button for the latest previewItemNumber
							if (elements[counter] instanceof UIAButton && 
								elements[counter].withPredicate("name == 'FREE' or name matches '.*[0-9]+.*'").isValid()) {
								//found the purchase button
								latestObject.purchaseButton = elements[counter];
								items.push(latestObject);
								UIALogger.logDebug("Done with preview number " + previewItemNumber);
								previewItemNumber++;
								latestObject = null; //time to look for the next item
							}
						}
						
						counter++;
					} //end while loop
				}
				
				//check if PREVIEW exists -- probably a movie is selected
				UIATarget.localTarget().pushTimeout(0);
				var previewButton = webView.elements()["PREVIEW"];
				UIATarget.localTarget().popTimeout();
				if (previewButton.isValid()) {
					UIALogger.logDebug("Preview button found");
					items.push({previewButton:previewButton, purchaseButton:webView.buttons().firstWithPredicate("name == 'FREE' or name matches '.*[0-9]+.*'"), itemName:webView.images()[0].name()});
				}
			}
		} else {
			items = this.mainWindow().tableViews()[0].cells().withPredicate("name != null or (not name contains 'Reviews')").toArray();
			UIATarget.localTarget().pushTimeout(0);
			var previewButton = this.mainWindow().scrollViews()[0].webViews()[0].buttons()["PREVIEW"];
			UIATarget.localTarget().popTimeout();
			if (previewButton.isValid()) {
				UIALogger.logDebug("Preview button found");
				items.push({previewButton:previewButton, purchaseButton:this.mainWindow().scrollViews()[0].webViews()[0].buttons().firstWithPredicate("name == 'FREE' or name matches '.*[0-9]+.*'")});
			}
		}
		
		return items;
	}
	
	//helper function to return an item element with the specified name
	itunes._itemWithName = function _itemWithName(items, name) {
		for (var i=0; i<items.length; i++) {
			if (items[i] instanceof UIAElement && items[i].name()) { 
				if (UIATarget.localTarget().model() == 'iPad') {
					if (items[i].name().indexOf(name) >= 0) return items[i];
				} else {
					UIATarget.localTarget().pushTimeout(0);
					var itemContainsElementWithName = items[i].elements().firstWithPredicate("name contains '" + name + "'").isValid();
					UIATarget.localTarget().popTimeout();
					if (itemContainsElementWithName) return items[i];
				}
			} else if (items[i].trackName && items[i].trackName.indexOf(name) >= 0)
				return items[i];
		}
		return null;
	}
	
	//----------------------------------------------------------------------------------------
	//	Function: navigateItemSelection 
	//		selects a specific tab bar button (described by tabButton),
	//		selects a specific nav bar button (described by navButton), and then navigates tables
	//		to each item in the path array until the desired item has been selected
	//
	//	Arguments: 
	//		path (array) - optional - an array of element names to navigate through. If no 
	//			path element is specified, the function tries to randomly navigate through 
	//			views. Please note that this function does not work on iPad devices when the 
	//			path element names are specified i.e. only random selection is supported on
	//			iPad
	//		options (object) - a dictionary of additional optional parameters specified below 
	//
	//	Options:
	//		tabButton (string) - the name of the tab button to be selected
	//		navButton (string) - the name of the nav button to be selected
	//
	//	Returns: 
	//		the track object that represents the item we navigated to (a track object is  
	//		an item in the store that can be purchased and previewed e.g. a song item, or an item 
	//		such that when it is selected, more track objects come into view e.g. an album item). 
	//		The track object is not necessarily a UIAElement, so use other library functions like 
	//		priceButtonForTrack, etc. to interact with it.
	//----------------------------------------------------------------------------------------
	itunes.navigateItemSelection = function navigateItemSelection(path, options) {
		if (typeof options == 'undefined' || !options) { options = new Object(); }
				
		if (options.tabButton) {
			UIALogger.logDebug("Selecting '" + options.tabButton + "' tab button");
			this.getToView(options.tabButton);
		}
		
		if (options.navButton) {
			UIALogger.logDebug("Selecting nav button '" + options.navButton + ".'");
			this.navigationBar().segmentedControls()[0].buttons().firstWithPredicate("name contains '" + options.navButton + "'").tap();
			this.waitForNetworkLoadingToFinish(10);
		}
		
		if (typeof path == "string") path = [path];
		
		var selectedElement, items;
		var maxLoopCount = (path) ? path.length : 10;
		if (path) path = path.slice(0);
		
		for (var loopCount = 0; loopCount < maxLoopCount; loopCount++) {		
			var pathItem = (path) ? path.shift() : null;
			items = this._itemsInCurrentView();
			
			if (pathItem) {
				//path is specified
				selectedElement = itunes._itemWithName(items, pathItem);
				if (!selectedElement) throw new Error("Did not find an item with name '" + pathItem + "'");
			} else {
				//need to select something random
				if (items.length == 0) {
					UIALogger.logError("Did not find any potential items -- should go back");
					this.logElementTree();
					var navBar = this.navigationBar();
					if (!navBar.isValid()) throw new Error("No nav bar -- do not know how to get out of this view");
					if (navBar.isVisible()) {
						UIALogger.logDebug("Nav bar found and is visible. Tapping the left button.");
						navBar.leftButton().tap();	
					} else {
						UIALogger.logDebug("Nav bar found but not visible. Tapping the nav bar to see if we can get out of this view");
						UIATarget.localTarget().tap(navBar.rect());
					}
					continue;
				} 
				UIALogger.logDebug(maxLoopCount-loopCount + " iterations to go");
				selectedElement = UIAUtility.randomFromArray(items);
			}
			
			var priceButton = itunes.priceButtonForTrack(selectedElement);
			if (priceButton && priceButton.isValid()) {
				UIALogger.logDebug("Done");
				break;
			}
			
			//TODO: this is somewhat going against the abstraction -- might need to clean it up
			UIALogger.logDebug("Selecting the item with name '" + (selectedElement.name()) + "'");
			selectedElement.scrollToVisible();
			selectedElement.tap();
			
			this.waitForNetworkLoadingToFinish(10);
		}
		
		//TODO: account for the case where you don't end up with anything
		return selectedElement;
	}
	
	//----------------------------------------------------------------------------------------
	//	Function: waitForDownloadBadgeOfZero 
	//		wait for downloads to complete 
	//
	//	Arguments: 
	//		time (int) - the numbr of seconds to wait. It is set to 120, by default. 
	//
	//	Returns: 
	//		true, if the downloads badge went down to zero -- false, if it didn't
	//----------------------------------------------------------------------------------------
	itunes.waitForDownloadBadgeOfZero = function waitForDownloadBadgeOfZero(time) {
		if (!time) time = 600;
		
		var tabBarButton = this.mainWindow().tabBars()[0].buttons().firstWithPredicate("name contains 'Downloads' or name contains 'More'");
		if (!tabBarButton.isValid()) throw new Error("Did not find a 'Downloads' or 'More' tab bar button");
		tabBarButton.logElement();
		
		if (tabBarButton.withPredicate("name matches '.*[0-9]+.*'").isValid()) {
			UIALogger.logDebug("Digits found in the button name -- will wait for it to go away for " + time + " seconds");
			UIATarget.localTarget().pushTimeout(time);
			var didDownload = tabBarButton.withPredicate("not name matches '.*[0-9]+.*'").isValid();
			UIATarget.localTarget().popTimeout();
			return didDownload;
		} else {
			UIALogger.logDebug("Did not find any digits in the button name");
		}
		return true;
	}
	
	itunes.search = function search(searchString) {
		if (UIATarget.localTarget().model() != 'iPad') {
			itunes.getToView("Search");
			UIATarget.localTarget().delay(1);
			this.tabBar().buttons()["Search"].tap(); //needed to make sure we are in the top most level of the search page
		} else {
			this.navigationBar().searchBars()[0].tap(); //sometimes two taps are required to actually select it
		}
		
		this.__proto__.search.apply(this, [searchString, {searchBarEvalString:"this.navigationBar().searchBars()[0]"}]);	
		this.waitForNetworkLoadingToFinish();
	}
}
