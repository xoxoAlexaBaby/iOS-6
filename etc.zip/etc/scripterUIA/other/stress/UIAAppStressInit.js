// This is for code that must run before anything else is imported
if (typeof system == 'undefined') system = new System();	
system.println("AppStress Log Version: 3");
