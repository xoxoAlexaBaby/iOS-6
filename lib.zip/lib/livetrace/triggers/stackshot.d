/* @description Trigger on stackshot */

syscall::stack_snapshot:entry
{
    printf("%d #TRIGGER\n", timestamp);
    exit(0);
}

