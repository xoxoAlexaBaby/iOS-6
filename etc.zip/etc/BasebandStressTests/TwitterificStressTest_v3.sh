#!/bin/sh

accountSetup()
{
	eventer c "com.iconfactory.TwitterrificFree"
	echo "Checking for OK..."
	sleep 10
	eventer c "OK"
	echo "Sleeping for 5 seconds."
	sleep 4
	eventer c "Don't Show Again"
	sleep 1
	
	eventer t 265 437
	sleep 3
	eventer t 300 177
	sleep 3
	
	eventer c "KEYDelete"; eventer c "KEYDelete"; eventer c "KEYDelete"; eventer c "KEYDelete";
	eventer c "KEYDelete"; eventer c "KEYDelete"; eventer c "KEYDelete"; eventer c "KEYDelete";
	eventer c "KEYDelete"; eventer c "KEYDelete"; eventer c "KEYDelete"; eventer c "KEYDelete";
	eventer c "KEYDelete"; eventer c "KEYDelete"; eventer c "KEYDelete"; eventer c "KEYDelete";
	
	eventer w "IncredibleTest"
	eventer c "Done"
	sleep 2
	echo "Sleeping for 4 seconds."
	sleep 4
	eventer c "Don't Show Again"
	sleep 1
	eventer t 265 437
	sleep 3
	eventer t 300 221
	sleep 3
	eventer c "KEYDelete"; eventer c "KEYDelete"; eventer c "KEYDelete"; eventer c "KEYDelete";
	eventer c "KEYDelete"; eventer c "KEYDelete"; eventer c "KEYDelete"; eventer c "KEYDelete";
	eventer c "KEYDelete"; eventer c "KEYDelete"; eventer c "KEYDelete"; eventer c "KEYDelete";
	eventer c "KEYDelete"; eventer c "KEYDelete"; eventer c "KEYDelete"; eventer c "KEYDelete";
	eventer w "test95014"		
}

calculateTime()
{
	runTime=$1;
	hours=$(($runTime / 3600)); hours2=$(($hours * 3600));
	mins2=$(($runTime - $hours2)); mins=$(($mins2 / 60));
	abSecs=$(($hours * 3600 + $mins * 60)); secs=$(($runTime - $abSecs));
	if [ $hours -lt 10 ]; then  hours=`echo "0$hours"`;  fi
	if [ $mins -lt 10 ];  then  mins=`echo "0$mins"`;    fi
	if [ $secs -lt 10 ];  then  secs=`echo "0$secs"`;    fi
	totalTime="$hours:$mins:$secs"
	if [ $2 -eq 1 ]; then echo " Total RunTime : $totalTime, RunTime (in secs): $runTime." >> Stats.txt;	fi
	echo $totalTime
}


postMessage()
{
	changeUser
	sleep 2;
	eventer c "OK"
	sleep 2
	eventer t 67 437
	sleep 3
	eventer c "Don't Show Again"
	sleep 2
	eventer t 177 221
	sleep 2
	eventer c "Update Twitter Location"
	sleep 20
	eventer c "OK"
	sleep 1
	eventer t 177 221
	sleep 2
	eventer c "OK"
	sleep 1
	eventer c "Add Map Link To Tweet"
	sleep 2
	eventer c "OK"
	sleep 1
	eventer w "Awesome"
	sleep 2
	eventer c "OK"
	sleep 1
	eventer c "Send"
	echo "Posting Message.. Done.\n"
}

postMessageNew()
{
	sleep 2;
	eventer c "OK"
	sleep 2
	eventer t 97 437
	sleep 3
	eventer c "Don't Show Again"
	sleep 2
	eventer t 207, 20
	sleep 2
	eventer c "Update Twitter Location"
	sleep 20
	eventer c "OK"
	sleep 1
	eventer t 207, 20
	sleep 2
	eventer c "OK"
	sleep 1
	eventer c "Add Map Link to Tweet"
	sleep 2
	eventer c "OK"
	sleep 1
	eventer w "Tweeting for my own pleasure"
	sleep 2
	eventer c "OK"
	sleep 1
	eventer c "Send"
	echo "Posting Message.. Done.\n"
}


changeUser()
{
	eventer c "OK"
	sleep 3
	eventer t 265 437
	sleep 3
	eventer t 300 177
	sleep 3
		
	if [ $(($usercount % 6)) -eq 0 ]; then  eventer c "KEY1"; userid=1; fi
	if [ $(($usercount % 6)) -eq 1 ]; then  eventer c "KEYDelete"; eventer c "KEY2"; userid=2; fi
	if [ $(($usercount % 6)) -eq 2 ]; then  eventer c "KEYDelete"; eventer c "KEY3"; userid=3; fi
	if [ $(($usercount % 6)) -eq 3 ]; then  eventer c "KEYDelete"; eventer c "KEY4"; userid=4; fi
	if [ $(($usercount % 6)) -eq 4 ]; then  eventer c "KEYDelete"; eventer c "KEY5"; userid=5; fi
	if [ $(($usercount % 6)) -eq 5 ]; then  eventer c "KEYDelete"; userid=6; fi
		
	eventer c "Done"
	echo "Changing User... Done.\nUserCount = $usercount. USERID = $userid."
	sleep 2
	eventer c "Don't Show Again"
	sleep 8;
	((usercount++))
}

usingOldApp=0
isNanshan=0

while getopts 'ho' OPTION
do
	case "$OPTION" in
		h )	isNanshan=1
			echo " ####  Hardware C Used.";;
		
		0 )	usingOldApp=1
			#accountSetup
			echo " #### Old App is being tested here.";;
				
		/?)	echo "INVALID OPTIONS.\n"; 
			usage;
			exit 2;;
	esac
	
done

shift $(($OPTIND - 1))
	

getBuildVersions()
{
	BASEBAND=`/usr/local/bin/lockdown_query get NULL BasebandVersion 2>&1`
	DEVICE_NAME=`/usr/local/bin/lockdown_query get NULL DeviceName 2>&1`
	SERIAL=`/usr/local/bin/lockdown_query get NULL SerialNumber 2>&1`
	IMEI=`/usr/local/bin/lockdown_query get NULL InternationalMobileEquipmentIdentity 2>&1`
	if [ $DEVICE_NAME == "iPhone" ]; then  DEVICE_NAME=$SERIAL; fi
	Platform=`/usr/local/bin/lockdown_query get NULL HardwareModel 2>&1 | cut -c1-3`
	APBuild=`/usr/local/bin/lockdown_query get NULL BuildVersion 2>&1`
}

usercount=0
interval=1800
count=0
lastUserUsageTime=`date "+%s"`
startTime=`date "+%s"`
locationdCrashPath="/Library/Logs/CrashReporter/locationd*"
logFiles="/Library/Logs/CrashReporter/Baseband/*csi*"
otherCrashLogs="/var/mobile/Library/Logs//CrashReporter/*.plist /Library/Logs/CrashReporter/*.plist"
totalCrashes=0
totalResets=0
StartDate=` perl -e '
	($s,$m,$H,$d,$M,$Y,$D) = localtime(); $Y += 1900; $M++; 
	printf ("%04d%02d%02d",$Y,$M,$d); 
' `
	
getBuildVersions
if [ $isNanshan -eq 1 ]; then 
	Hardware=`echo $Platform | perl -lne '$s = "$_"."C"; print $s;'`;
else 
	Hardware="$Platform";
fi

BB=`echo $BASEBAND | sed 's/[.]//g'`
KEY="$Hardware-$BB-$APBuild"

while(true);
do
	((count++))
	echo "********** Beginning Iteration - $count: ************"
	echo "Launching the Twitteriffic App..."
	eventer c "com.iconfactory.TwitterrificFree"
	echo "Checking for OK..."
	sleep 10
	eventer c "OK"
	echo "Sleeping for 5 seconds."
	sleep 4
	eventer c "Don't Show Again"
	sleep 1
	
	currentTime=`date "+%s"`
	timeElapsed=$(($currentTime - $lastUserUsageTime))
	
	if [ $timeElapsed -gt $interval ]; then
		lastUserUsageTime=$currentTime
		echo "\nTime is up to change User... Changing User."
		#changeUser
		echo "Posting Message... "
		if [ $usingOldApp -eq 0 ]; then
			postMessageNew
		else
			postMessage
		fi
		sleep 5
	fi
	
	echo "Exiting the App..."
	eventer h
	echo "Sleeping for 90 seconds."
	sleep 15
	
	currentTime=`date "+%s"`
	runTime=$(($currentTime - $startTime))
	tStartTime=`date -r $startTime`
	tCurrentTime=`date -r $currentTime`
	tRunTime=`calculateTime $runTime 255`

	if [ $(($count % 50)) -eq 0 ]; then  
		date
		echo "Sleeping for 30 mins"; sleep 1800;
		
	elif [ $(($count % 1)) -eq 0 ]; then  
		totalCrashes=`ls $locationdCrashPath | wc -l | perl -lne ' s/\s*//; print'`
		#ls $logFiles | perl -lne '$f = $_; open (F, $f); $f =~ s/(.*\Qlog-bb-\E)(.*)(\Q-csi.\E(.*))/$2/; foreach (<F>) { chomp;  if (/\QReason: \E/) { s/^(.*Reason: )//; s/,/_/g;  $i=$_; print "$i,$f"; last; } } close F; '  > /tmp/crashReasons
		ls $logFiles | perl -lne '
				$f = $_;
				open (F, $f); 
				$f =~ s/(.*\Qlog-bb-\E)(.*)(\Q-csi.\E(.*))/$2/;
				foreach (<F>) { 
					chomp;  
					if (/\QReason: \E/) { 
						s/^(.*Reason: )//; 
						s/,/_/g;  $i=$_; 
						print "$i,$f"; last; 
					} 
				} close F; '  > /tmp/crashReasons
		totalModemResets=`cat /tmp/crashReasons | grep "modem reset" | wc -l | perl -lne ' s/\s*//; print'`
		totalBasebandCrashes=`cat /tmp/crashReasons | grep "baseband crash"| wc -l | perl -lne ' s/\s*//; print'`
		totalResets=$(($totalModemResets + $totalBasebandCrashes))
		otherCrashes=`ls $otherCrashLogs | awk ' !/Latest/ && !/locationd/ {print $1}' | wc -l | perl -lne ' s/\s*//; print'`
	fi

	
	echo "\n**** Startime -- $tStartTime; Current Time -- $tCurrentTime;"
	echo "**** Baseband Build - $BASEBAND, AP Build - $APBuild;"
	echo "**** Total Locationd Crashes: $totalCrashes; Total Baseband Crashes = $totalResets;"
	echo "**** Total Run Time is - $runTime seconds, $tRunTime hours.\n\n"

	echo "STARTDATE, KEY, Hardware, DEVICE_NAME, SERIAL, BASEBAND, APBuild, Run Time, Run time(s), Locationd Crashes, BB Resets, otherCrashes, Iterations\n"	
	echo "$StartDate, $KEY, $Hardware, $DEVICE_NAME, $SERIAL, $BASEBAND, $APBuild, $tRunTime, $runTime, $totalCrashes, $totalResets, $otherCrashes, $count\n"

	
done