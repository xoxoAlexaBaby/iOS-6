#import "UIAAppStressLibrary.js"


if (typeof camera != 'undefined') {
	cameraStress = AppStressBase.stressTest('Camera');
	
	if (typeof cameraStress != 'undefined') {

		cameraStress.setup = function setup() {
			cameraStress.addTest(cameraStress._takePicture);
			cameraStress.addTest(cameraStress._sleepAndTakePictures);
			
			// If video capture is supported, add test
			if (system.hasCapability("video-camera")) {
				cameraStress.addTest(cameraStress._captureVideo);
			}
			
			// If photos present, add tests
			var picCmd = "/usr/bin/find /var/mobile/Media/DCIM -name \*.JPG -not -regex .\*.MISC.\* -print";
			var picResult = system.run(picCmd);
			var picOutput = picResult.stdout;
			if (picOutput != "") {
				cameraStress.addTest(cameraStress._scrollThroughCameraRoll);
				cameraStress.addTest(cameraStress._deletePhoto);
				
				if(STRESS_MAIL_ACCOUNT && STRESS_MAIL_PASSWORD) {
					cameraStress.addTest(cameraStress._emailPhoto);
				}
			}

			// If videos present, add tests
			var vidCmd = "/usr/bin/find /var/mobile/Media/DCIM -name \"*.MOV\" -print";
			var vidResult = system.run(vidCmd);
			var vidOutput = vidResult.stdout;
			if (vidOutput != "") {
				cameraStress.addTest(cameraStress._playCapturedVideo);
			}
		}
		
		cameraStress.run = function run() {
			cameraStress.executeRandomTests(5);
		}
		
		// take a picture
		cameraStress._takePicture = function _takePicture() {
			cameraStress.executeTest("TakePicture", [], cameraTest_takePicture, "Take a picture.");
		}
		
		// sleep and take pictures
		cameraStress._sleepAndTakePictures = function _sleepAndTakePictures() {
			// take a picture first
			camera.getToCamera();
			camera.takePicture();
			
			// sleep
			if (!systemStress.testSleep()) {
				UIALogger.logError("Could not sleep between pictures.");
				return false;
			}
			
			// take another picture
			if (!cameraStress._takePicture()) {
				UIALogger.logError("Could not take picture after sleeping.");
				return false;
			}
			
			return true;
		}
		

		// capture video
		cameraStress._captureVideo = function _captureVideo() {
			var duration = system.randomInteger(10, 30);
			cameraStress.executeTest("CaptureVideo", [ duration ], cameraTest_captureVideo, "Capture video.");
		}
		
		// scroll through camera roll
		cameraStress._scrollThroughCameraRoll = function _scrollThroughCameraRoll() {
			cameraStress.executeTest("ScrollThroughCameraRoll", [], cameraTest_scrollThroughCameraRoll, "Scroll through the camera roll.");
		}
		
		// delete photo
		cameraStress._deletePhoto = function _deletePhoto() {
			cameraStress.executeTest("DeletePhoto", [], cameraTest_deletePhoto, "Delete a photo.");
		}
		
		// email photo
		cameraStress._emailPhoto = function _emailPhoto() {
			cameraStress.executeTest( "EmailPhoto", [ STRESS_MAIL_ACCOUNT, "Camera Photo", false ],
						 			  cameraTest_emailPhoto, "Email a photo." );
		}
		
		// play captured video
		cameraStress._playCapturedVideo = function _playCapturedVideo() {
			var duration = system.randomInteger(1, 10);
			cameraStress.executeTest("PlayCapturedVideo", [ duration ], cameraTest_playCapturedVideo, "Play captured video.");
		}
	}
}