#import "./FaceTime.js"
#import "../phone/Phone.js"
#import "../libs/CallMe.js"
#import "../libs/PHTesting.js"

//----------------------------------------------------------------------------------------
//	Function: facetimeTest_makeVideoCallToContact
//		Makes a video call to the given contact.
//
//	Parameters: 
//		contactName (string) - Name of the person to call
//		logFailureData (boolean) - Get additional failure data (screenshots, baseband dumps, etc.), 
//									does nothing if false. default: false
//		groupName (string) - optional - the name of the group where the contact is stored. If no 
//			value is provided, "All Contacts" is assumed. 
//		time (number) - optional - if a time value is specified, the test will wait for the 
//			specified number of seconds, and then verify that the call still exists at the 
//			end of the specified time period. If no value is specified, the test does 
//			not wait. 
//		numberOrAddress (string) - optional - if multiple email addresses or phone numbers are 
//			associated with the contact, this parameter specifies which one to use. If no 
//			value is specified, the first value is chosen by default. Note that the phone number 
//			should be exactly formatted as it appears in the info card. 
//
//	Optional parameters:
//		callMeServiceType (string) - "phonefacetime" or "emailfacetime" - use the http://callme 
//			service to find an auto-answering device offering the specified service type. Once an 
//			auto-answering device is found, a contact is created with name that was provided 
//			as contactName parameter value, and the contact id that was returned by http://callme, 
//			and then a facetime call is made to that contact. Please note that using the callme 
//			service requires the device to be connected to an internal WiFi network. 	
//			For e.g. facetimeTest_makeVideoCallToContact "CallMe device" null null null null callMeServiceType:emailfacetime
//			will issue a http://callme.apple.com/waitfor/emailfacetime request, and will create a contact with name 
//			'CallMe device' and email id with url request return value, and then call the 'CallMe device' contact. 
// 
//	Returns:
//		1 if test passes, 0 or 64 if test fails.
//----------------------------------------------------------------------------------------
function facetimeTest_makeVideoCallToContact() {
	
	if (this.argv.length > 0) { 
		var contactName = this.argv[0];
	} else {
		UIALogger.logError("No contact specified.");
		return 64;		
	}
	
	var logFailureData = false;
	if (this.argv.length > 1) {
		logFailureData = (this.argv[1] == true || this.argv[1] == "true");
	}
	
	var groupName = "All Contacts";
	if (this.argv.length > 2 && this.argv[2] != null && this.argv[2] != "null" && this.argv[2] != "") groupName = this.argv[2];
	
	var time; 
	if (this.argv.length > 3 && !isNaN(parseInt(this.argv[3]))) time = parseInt(this.argv[3]);
	
	var numberOrAddress;
	if (this.argv.length > 4 && this.argv[4] != null && this.argv[4] != "null" && this.argv[4] != "") numberOrAddress = this.argv[4];
	
	var callMeServiceType = UIAUtility.valuesForKey("callMeServiceType", this.argv, 1);
	
	facetime.launchIfNotActive();
	facetime.dismissCallFailureView();
	
	if (callMeServiceType) {
		UIALogger.logDebug("Setting up a CallMe service request of type: " + callMeServiceType);
		var serviceType;
		var contactProperty;
		if (callMeServiceType == "phonefacetime") {
			serviceType = CallMe.SERVICE_TYPE_WAIT_FOR_PHONE_FACETIME;
			contactProperty = "phone";
		} else if (callMeServiceType == "emailfacetime") {
			serviceType = CallMe.SERVICE_TYPE_WAIT_FOR_EMAIL_FACETIME;
			contactProperty = "email";
		} else {
			UIALogger.logError("Unknown callme service type: " + callMeServiceType);
			return 64;
		}
		var callme = new CallMe(serviceType);
		var contactId = callme.waitForDeviceToCall(360);
		if (contactId == null) {
			this.testError = "Call Me service did not return a valid contact id";
			UIALogger.logError(this.testError);
			return this.testResult = 0;
		}
		
		UIALogger.logDebug("Found " + contactId +  ". Now creating a contact");
		
		var contactArray = contactName.split(' ');
		var contactInfo = {firstName:contactArray.shift(), lastName:contactArray.join(' ')};
		contactInfo[contactProperty] = contactId;
		facetime.addContact(contactInfo);
		numberOrAddress = contactId;
	}
	
	var alertDate = new Date();
	facetime.makeVideoCallToContact(contactName, {groupName:groupName, numberOrAddress:numberOrAddress});
	
	UIALogger.logDebug("Initiated video call to '" + contactName + "'.");
	
	//Connect and check for call presence
	var connected = false;
	try {
		if (facetime.waitForVideo()) connected = true;
	} catch(e) {
		UIALogger.logError(e.message);
	}
	
	if (connected) {
		if (time != null) {
			UIALogger.logDebug("Will wait for " + time + " seconds now...");
			UIATarget.localTarget().delay(time);
			UIALogger.logDebug("Checking if the call is still active now");
			if (facetime.isFaceTimeCallActive()) {
				return this.testResult = 1;
			}
		} else
			return this.testResult = 1;
	}

	var failureData = facetime.getVideoCallFailureData({takeScreenshot:logFailureData, alertDate:alertDate});
	this.testError = failureData.failureText;
	return this.testResult = 0;

}


//----------------------------------------------------------------------------------------
//	Function: facetimeTest_endVideoCall 
//		Ends a video call
//
//	Parameters: 
//		logFailureData (boolean) - Get additional failure data (screenshots, baseband dumps, etc.), 
//									does nothing if false. default: false
// 
//	Returns:
//		1 if test passes, 0 or 64 if test fails.
//----------------------------------------------------------------------------------------
function facetimeTest_endVideoCall() {
	
	var logFailureData = false;
	if (this.argv.length > 0) {
		logFailureData = (this.argv[1] == true || this.argv[1] == "true");
	}
	
	facetime.launchIfNotActive();
	try {
		var alertDate = new Date(); //date object for alert checking purposes
		facetime.endVideoCall();
	} catch(e) {
		UIALogger.logError("Could not end video call.");
		var failureData = facetime.getVideoCallFailureData({takeScreenshot:logFailureData, alertDate:alertDate});
		this.testError = failureData.failureText;
		return this.testResult = 0;
	}
	
	return this.testResult = 1;
}

//----------------------------------------------------------------------------------------
//	Function: facetimeTest_signInToFaceTimeAccount 
//		Launches the FaceTime app, and signs in using the specified credentials. Assumes 
//		that an account is not already set up. 
//
//	Parameters: 
//		appleIDUsername (string) - the Apple ID username 
//		appleIDPassword (string) - the Apple ID password
//		emailAddress (string) - optional - the email address that will be used by other devices 
//			to contact the device. If no value is specified, the value in the text 
//			field is not changed. 
// 
//	Returns:
//		1 if test passes, 0 or 64 if test fails.
//----------------------------------------------------------------------------------------
function facetimeTest_signInToFaceTimeAccount() {
	if (this.argv.length < 2) {
		UIALogger.logError("Need to provide the username and password");
		return 64;
	}
	var options = new Object();
	options.appleIDUsername = this.argv[0];
	options.appleIDPassword = this.argv[1];
	
	if (this.argv.length > 2) options.emailAddress = this.argv[2];
	UIALogger.logDebug("Signing in using the account: " + options.appleIDUsername);
	facetime.launchIfNotActive();
	facetime.returnToTopLevel();
	
	if (!facetime.mainWindow().buttons()["Learn more about FaceTime"].isValid()) {
		this.testError = "Did not find the 'Learn more about FaceTime' button";
		return this.testResult = 0;
	}
	
	facetime.signIn(options);
	
	return this.testResult = 1;
}


// Create self tests -- this is an unnamed function, just to make sure any local variables stay in the correct context
(function() {	
	if (typeof facetime != 'undefined') {
		if (typeof facetime.selfTests == 'undefined') {
			facetime.selfTests = new Array();
		}

		if (system.hasCapability("venice") && UIATarget.localTarget().model() == 'iPhone') {
			facetime.selfTests.push(phtCreateTest("MakeFacetimeCallToContact", ["autoanswer fun", false], facetimeTest_makeVideoCallToContact, "Make a facetime call to contact"));
			facetime.selfTests.push(phtCreateTest("EndFacetimeCall", [false], facetimeTest_endVideoCall, "End a facetime call"));
		}
	}
}())
