#!/bin/sh

VERSION_PREFIX="v27"

######### Defaults for setting up the Wireless network
DEFAULT_SSID="CSIQA"
DEFAULT_WEP_KEY="123456789a"
SERVER_ADDR="17.202.12.54"
DEFAULT_SECURITY="wpa2"

if [ -e /$SCRIPTS_DIR/WiFiSettings.sh ]; then
	source $SCRIPTS_DIR/WiFiSettings.sh;
else
	echo "WiFiSettings.sh file is not present... Going with Default Settings.";
fi

############### DEFAULTS if NO OPTIONS specified ###############

######### Defaults for Uploading Stats and Logs
LOG_INTERVAL=14400
STATS_INTERVAL=900
MAX_FILES_TO_UPLOAD=150
DEFAULT_ITERATIONS=1500
MAX_JOIN_ATTEMPTS=5

######## Other Defaults
RATS=( UMTS  GSM  LTE  C2K )
SLEEPOFFSET=15
LOCMON_RUNTIME=30
LOCMON_SLEEPTIME=600

#### DATA DOWNLOAD DEFAULTS
MAX_DATA_FAIL_ATTEMPTS=7
MIN_DATA_FAIL_ATTEMPTS=5
MAX_TIME_FOR_DOWNLOADS=300
MIN_DATA_RATE_UMTS="0.200"
MIN_DATA_RATE_LTE="0.500"
MIN_DATA_RATE_GSM="0.025"
MIN_DATA_RATE_C2K="0.200"
URL0="http://pttest.apple.com/200KB.txt"
URL1="http://pttest.apple.com/1MB.txt"
URL2="http://pttest.apple.com/2MB.txt"
URL3="http://pttest.apple.com/5MB.txt"
URL4="http://pttest.apple.com/10MB.txt"
URL5="http://pttest.apple.com/50MB.txt"
URL6="http://pttest.apple.com/100KB.txt"

PING_PACKET_SIZE=( 64  256  512  1024  2048  4096  8192 )
PING_INTERVALS=( .200  .300  .500   1   2   4  )
UPLOAD_BYTES=1048576
FILE_MULTIPLIER=1
UPLOAD_SERVER="ftp://testftp:tftp95014*@pttest.apple.com/Bandwidth/mytest"
iPERFURL="pttest.apple.com"


### MESSAGING DEFAULTS
SMSSTRING1="Stress...12345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"
SMSSTRING2="Stress..."
MMS_PATH1="$SCRIPTS_DIR/MMS_IMAGE_1.JPG"
MMS_PATH2="$SCRIPTS_DIR/MMS_IMAGE_2.JPG"
MMS_PATH3="$SCRIPTS_DIR/MMS_IMAGE_3.JPG"


######## Default Directory for Baseband logs.
crashDir="/Library/Logs/CrashReporter/"
wirelessDir="/var/wireless/Library/Logs/CrashReporter/"
logsDir="/private/var/wireless/Library/Logs/CrashReporter/Baseband/"
logFiles="$logsDir/*csi.txt"
mobileLogs="/var/mobile/Library/Logs/CrashReporter/*.plist"
mobileDir="/var/mobile/Library/Logs/CrashReporter/"
csiLogsDir="CsiLogs"
DEVICENAME=`hostname`


#### Counters
dcount=0
count=0
callCount=0
smsCount=0

pass=0
fail=0

pdpFails=0
pdpAttempts=0
minUpTime=0
filesUploadedSoFar=0
uploadFlag=0
uploadAttempts=0
uploadPassCount=0
uploadFailCount=0
DataAttempts=0
DataAttempts1=0
dataFailCount=0
dataPassCount=0
dataFailCount1=0
dataFailCount2=0
dataFailTracker=0
lastlowThroughput=1
proceedDataTransfer=0

dontSendSMS=0
spass=0
sfail=0
mpass=0
mfail=0
mmsAudioCount=0
mmsVideoCount=0
mmsImageCount=0
mmsCount=0
mmsPass=0
mmsFail=0

proximitySensor=0
startTcpDump=0
wifiFailCount=0

###################################################################

# Processing the Command Line Arguments with Options.

iterations=0; number=0;interval=0;

UPLOAD=
disableLogsUpload=0
key=
isSSID=
isSecurity=

DoSleep=1
EnableLocmon=
noIdleSleep=
EnableMultiRAB=0
dataFailureLogs=0
additionalLoggging=0
isTopOutput=0
round=0
sNumber=0
changeSSID=0

technology=0
EnableAWD=0

while getopts 'h:i:n:l:ukj:p:e:wsdar:t:gmcx:ob' OPTION
do
	case "$OPTION" in
	
		h )	interval=1
			CALL_INTERVAL="$OPTARG"	
			interval=`echo $CALL_INTERVAL | perl -lne 'if (/\D/g) { print "0";} else { print "1";};' `;;

		i )	iterations=1
			LOOPS="$OPTARG"
			#echo "#### $OPTION -- $OPTIND $OPTARG.\n"
			iterations=`echo $LOOPS | perl -lne 'if (/\D/g) { print "0";} else { print "1";};' `;;
			
		n )	number=1
			calledNumber="$OPTARG"
			number=`echo $calledNumber | perl -lne ' s/[+]//g; if (/\D/g) { print "0";} else { print "1";};' `;;
		
		l )	sNumber=1
			smsNumber="$OPTARG"
			sNumber=`echo $smsNumber | perl -lne ' s/[+]//g; if (/\D/g) { print "0";} else { print "1";};' `;;
				
		u )	UPLOAD=1
			echo " #### UPLOAD ENABLED.";;
		
		k )	disableLogsUpload=1
			echo " #### Disabling Logs Upload.";;
				
		j )	isSSID=1
			SSID="$OPTARG";;
		
		e )	isSecurity=1
			SECURITY="$OPTARG";;

		p )	key=1
			WEPKEY="$OPTARG";;		
		
		w )	DoSleep=0
			echo " #### SLEEP DISABLED --  $OPTION, $OPTIND, $OPTARG.";;
		
		d ) dataFailureLogs=1
			echo " #### Enabling Data Failures Logging --  $OPTION, $OPTIND, $OPTARG.";;
		
		a ) additionalLoggging=1
			echo " #### Additional Logging Enabled --  $OPTION, $OPTIND, $OPTARG.";;

		r ) round=1
			ROUNDINFO="$OPTARG"
			echo " #### RUNNING AGAIN on the same day - $ROUNDINFO -- $OPTION, $OPTIND, $OPTARG.- ROUNDINFO=$ROUNDINFO";;
		
		t ) technology="$OPTARG"
			technology=`echo $technology | perl -lne ' if (/\D/g | $_ > 3 ) { print "0";} else { print;};' `
			echo " #### Technology Selected --  $OPTION, $OPTIND, $OPTARG.";;
				
		g )	EnableLocmon=1
			echo " #### GPS ENABLED -- $OPTION, $OPTIND, $OPTARG.";;

		m )	EnableMultiRAB=1
			echo " #### Multi-RAB Enabled -- $OPTION, $OPTIND, $OPTARG.";;

		c )	EnableAWD=1
			echo " #### IQ Agent Enabled -- $OPTION, $OPTIND";;

		o )	noIdleSleep=1
			echo " #### IQ Agent Enabled -- $OPTION, $OPTIND";;

		b )	SLEEPOFFSET="$OPTARG"
			echo " #### SLEEP OFFSET = $SLEEPOFFSET -- $OPTION, $OPTIND";;

		x )	changeSSID=$OPTARG
			DEFAULT_SSID="CAPSULE"; 
			echo " #### Changing SSID to $DEFAULT_SSID";;

		/?)	echo "INVALID OPTIONS.\n"; 
			usage;
			exit 2;;
	esac
	
done

shift $(($OPTIND - 1))

RAT=${RATS[$technology]}
echo "### RAT chosen : $RAT"
weblink1=$URL2; weblink2=$URL2; weblink3=$URL3;  
MIN_DATA_RATE=${MIN_DATA_RATE_UMTS};
 
case "$technology" in

	0 )  echo "Setting UMTS params..."; 
		 weblink0=$URL0; weblink1=$URL2; weblink2=$URL2; weblink3=$URL3;  
		 EnableMultiRAB=1; MIN_DATA_RATE=${MIN_DATA_RATE_UMTS};;
		 
	1 )  echo "Setting GSM params...";  
		 UPLOAD_BYTES="102400";
		 weblink0=$URL0; weblink1=$URL1; weblink2=$URL1; weblink3=$URL1;  
		 MIN_DATA_RATE=${MIN_DATA_RATE_GSM}; EnableMultiRAB=0;;
		 
	2 )  echo "Setting LTE params..."; 
		 FILE_MULTIPLIER=2; EnableMultiRAB=0;
		 weblink0=$URL1; weblink1=$URL4; weblink2=$URL3; weblink3=$URL4;  
		 MIN_DATA_RATE=${MIN_DATA_RATE_LTE};;
		 
	3 )  echo "Setting C2K params..."; 
		 weblink0=$URL0; weblink1=$URL1; weblink2=$URL2; weblink3=$URL3;  
		 EnableMultiRAB=0;  MIN_DATA_RATE=${MIN_DATA_RATE_C2K};;
		 
	/?)	 echo "Setting Default params..."; 
		 weblink0=$URL0; weblink1=$URL1; weblink2=$URL2; weblink3=$URL3;  
		 MIN_DATA_RATE=${MIN_DATA_RATE_UMTS};;
esac

if [ $iterations -eq 1 ]; then  echo "\n Number of iterations -i \"$LOOPS\" specified";  
else	LOOPS=$DEFAULT_ITERATIONS; fi


if [ $number -eq 1 ] ;  then  
	echo "Loop-Back Number -n \"$calledNumber\" specified";
	LOOP_BACK_NUMBER=$calledNumber;
else
	LOOP_BACK_NUMBER=$LOOP_BACK; 
fi


PHONE_NUMBER=`echo ${PHONE_NUMBER} | perl -lne 's/[(]|[)]|\s+|[-]//g; s/^([1])(.*)$/$1$2/; print;' `
flag=`echo ${PHONE_NUMBER} | perl -lne ' s/[+]//g; if (/^\d{6,12}$/ && $_ !~ /[0]{6,}/ ) { print "1";} else { print "0";};' `

if [ $flag -eq 1 ];  then  
	SMS_NUMBER=${PHONE_NUMBER}; 
	
elif [ $flag -eq 0 ] && [ $sNumber -eq 1 ];  then  
	SMS_NUMBER=$smsNumber; 

else 
	dontSendSMS=1;
	SMS_NUMBER=11111111111;
fi


if [ $interval -eq 1 ] ; then  printf 'Option -h "%s" specified\n' "$CALL_INTERVAL";
else	CALL_INTERVAL=15; fi

if [ "$UPLOAD" ] ;  then   		
		echo "Uploading option -u is specified.";
		
		if [ "$isSSID" ] && [ "$key" ]; then  
			echo "Logs will be uploaded to $SSID - $WEPKEY. Security chosen - $SECURITY.";
		else
			# change the Defaults if needed.
			SSID=$DEFAULT_SSID ; 	
			WEPKEY=$DEFAULT_WEP_KEY;
			SECURITY=$DEFAULT_SECURITY;
			echo "Logs will be uploaded to $SSID - $WEPKEY.";
		fi
		echo "DEFAULT_SSID=\"$SSID\"" >  $SCRIPTS_DIR/WiFiSettings.sh
		echo "DEFAULT_WEP_KEY=\"$WEPKEY\"" >> $SCRIPTS_DIR/WiFiSettings.sh
		echo "DEFAULT_SECURITY=\"$SECURITY\"" >> $SCRIPTS_DIR/WiFiSettings.sh
		echo "SERVER_ADDR=\"$SERVER_ADDR\"" >> $SCRIPTS_DIR/WiFiSettings.sh
fi
