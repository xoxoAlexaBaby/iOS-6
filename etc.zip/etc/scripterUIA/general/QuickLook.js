#!/usr/local/bin/scripter -uiautomation YES -f

#import "../libs/PHTesting.js"
#import "../libs/HarnessUtility.js"
#import "../settings/SettingsTests.js"
#import "../safari/SafariTests.js"
#import "../maps/MapsTests.js"
#import "../ipod/iPodTests.js"
#import "../notes/NotesTests.js"
#import "../mail/MailTests.js"
#import "../contacts/ContactsTests.js"
#import "../clock/ClockTests.js"
#import "../calculator/CalculatorTests.js"
#import "../phone/PhoneTests.js"
#import "../appstore/AppStoreTests.js"
#import "../3rdparty/FacebookTests.js"
#import "../calendar/CalendarTests.js"
#import "../weather/WeatherTests.js"
#import "../camera/CameraTests.js"
#import "../springboard/SpringboardTests.js"
#import "../stocks/StocksTests.js"
#import "../youtube/YouTubeTests.js"
#import "../messages/MessagesTests.js"
#import "../system/SystemTests.js"
#import "../photos/PhotoTests.js"
#import "../facetime/FaceTimeTests.js"

var kReportPath = "/var/mobile/Library/Logs/Testing/";
var hasWifi = system.hasCapability('wifi');
var hasTelephony = system.hasCapability("telephony");

// requires these specific bits of content be on the test device
var kSongName = "Yesterday";
var kMovieName = "Trailer H"
var kMovieSublist = "The Simpsons Movie";
var kMP4MovieName = "TikiBarTV10-DrinkbotMP4V";
var kDRMedSongName = "Delerium DRM";
var kDRMedMovieName = "Nasa DRM";

var start = new Date();
var timeString = start.getTime() + "";  // turn this into a string
var runID = "QuickLook " + start.toDateString() + " - " + timeString.substr(-6);

var kSMSBuddy1 = "4083321896";
var kSMSBuddy2 = "4083323272";

kStoreUsername = "jsmith.purple@gmail.com";
kStorePassword = "telluride";
  
// this is some setup that is required for the sms tests
globalSMSNumber = telephony.myPhoneNumber;

function addTestsToArray(tests) {
	if (UIATarget.localTarget().model() == 'iPad') {
		var movieListParameters = [kMovieName, 15, "Podcasts", kMovieSublist];
	} else {
		var movieListParameters = [kMovieName, 15, kMovieSublist];
	}
	
    var openWebPageInTabParameters = ["http://pttest.apple.com/perfmarketing-power/testcontent/smithsonian.html", "http://pttest.apple.com/perfmarketing-power/testcontent/google.html", "Google"];
    var openWebPageFromPreviousTabParameters = ["http://pttest.apple.com/perfmarketing-power/testcontent/smithsonian.html", "http://pttest.apple.com/perfmarketing-power/testcontent/google.html", "Smithsonian Institution", "Google"];
    
	// Contacts
	if ((typeof addressbook != 'undefined') && springboard.displaysApp(addressbook)) {
		tests.push("Contacts");
		tests.push(phtCreateTest("FlickContactList", [0.026, 0.80, 0.1], contactsTest_flickContactsList, "Flick contact list"));
		tests.push(phtCreateTest("DragContactList", [0.80, 0.026, 1], contactsTest_dragContactsList, "Drag contact list"));
		tests.push(phtCreateTest("NewContact", ["Robert", "Zimmerman"], contactsTest_newContact, "Add a new contact to the addressbook"));
		tests.push(phtCreateTest("SelectContact", ["Robert Zimmerman"], contactsTest_selectContact, "Select the added contact"));
		tests.push(phtCreateTest("AddNewPhoneNumber", ["4089619343", "home"], contactsTest_addNewPhone, "Add a phone number to the selected contact"));
		tests.push(phtCreateTest("AddNewEmail", ["zimmer@something.com", "work"], contactsTest_addNewEmail, "Add an email address to the selected contact"));
		if (addressbook.name == "Phone") {
			tests.push(phtCreateTest("AssignRingtone", ["Crickets"], contactsTest_assignRingtone, "Assign a ringtone to the selected contact"));	
		}
		tests.push(phtCreateTest("DeleteContact", ["Robert", "Zimmerman"], contactsTest_deleteContact, "Delete a contact from the addressbook"));
	}

	// Phone
	if ((typeof phone != 'undefined') && springboard.displaysApp(phone)) {
		tests.push("Phone");
		tests.push(phtCreateTest("MakeCall", ["+14089619343"], phoneTest_makeCall, "Make a call using the keypad")); // Apple Loopback
		tests.push(phtCreateTest("AddCall", ["+14087773456"], phoneTest_addCall, "Add a phone call using keypad")); // Movie Phone
		tests.push(phtCreateTest("MergeCalls", null, phoneTest_mergeCalls, "Merge two calls")); // Movie Phone
		tests.push(phtCreateTest("EndCall", [], phoneTest_endCall, "End calls")); // Both
	}
	
	//FaceTime
	if ((typeof facetime != 'undefined') && springboard.displaysApp(facetime) && hasTelephony) { //disabling the facetime tests on N81 because of <rdar://problem/8519257>
		tests.push("FaceTime");
		tests.push(phtCreateTest("MakeFacetimeCallToContact", ["CallMe contact", false, null, null, null, "callMeServiceType:phonefacetime"], 
								 facetimeTest_makeVideoCallToContact, "Make a facetime call to a contact using a phone number"));
		tests.push(phtCreateTest("EndFacetimeCall", [false], facetimeTest_endVideoCall, "End the facetime call"));
		tests.push(phtCreateTest("MakeFacetimeCallToContactUsingAddress", ["CallMe contact", false, null, null, null, "callMeServiceType:emailfacetime"], 
								 facetimeTest_makeVideoCallToContact, "Make a facetime call to a contact using an email address"));
		tests.push(phtCreateTest("EndFacetimeCall", [false], facetimeTest_endVideoCall, "End the facetime call"));
	}
	
	// Mail		
	if ((typeof mail != 'undefined') && springboard.displaysApp(mail)) {
		tests.push("Mail");
		var emailTitle = runID;
		tests.push(phtCreateTest("CreateMobileMeAccount", ["me", "Testing Tester", "weliketesting@me.com", "testtest", "contactsSync:0", "bookmarksSync:0", "calendarsSync:0", "notesSync:0"], 
								 settingsTest_createEmailAccount, "Setup mail account on the device")); // expected to fail, if this account is already there
		tests.push(phtCreateTest("ComposeAndSendEmail", ["weliketesting@me.com", emailTitle, "This is testing body text."], mailTest_composeAndSendEmail, "Compose and send a mail"));
		tests.push(phtCreateTest("FetchNewMail", [emailTitle, "weliketesting@me.com", "Inbox", 60], mailTest_verifyEmailInFolder, "Fetch new mail"));
		tests.push(phtCreateTest("SearchMailLocally", [emailTitle.split(' ').pop(), "weliketesting@me.com", "Subject", "timeout:120"], mailTest_search, "Search for mail locally"));
		tests.push(phtCreateTest("SearchMailOnServer", ["Hello", "weliketesting@me.com", "Subject", "shouldSearchServer:true", "timeout:120"], mailTest_search, "Search mail on server"));
		tests.push(phtCreateTest("DeleteMail", [emailTitle, "weliketesting@me.com", "Inbox"], mailTest_deleteEmail, "Delete mail"));
	}
	
	// iPod
	if ((typeof video != 'undefined') && springboard.displaysApp(video)) {
		tests.push("Audio/Video");
		tests.push(phtCreateTest("PlaySongFromSongList", [kSongName, 15], iPodTest_playSongFromSongList, "Play an AAC-encoded song"));
		tests.push(phtCreateTest("PlaySongFromSongList", [kDRMedSongName, 15], iPodTest_playSongFromSongList, "Play a DRMed AAC song"));
		if (UIATarget.localTarget().model() != "iPad") 
			tests.push(phtCreateTest("UseCoverFlow", ["songName:Yesterday", "action:Back", "action:Back", "action:Forward"], iPodTest_flipThroughCoverFlow, "Use cover flow"));
		tests.push(phtCreateTest("PlayMovieH264", movieListParameters, iPodTest_playMovieFromVideoList, "Play an H.264 movie"));
		tests.push(phtCreateTest("PlayMovieMPEG",	 [kMP4MovieName, 15], iPodTest_playMovieFromVideoList, "Play an MPEG-4 movie"));
		tests.push(phtCreateTest("PlayMovieFromVideoList", [kDRMedMovieName, 15], iPodTest_playMovieFromVideoList, "Play a DRMed H.264 movie"));
	}
	
	if ((typeof photos != 'undefined') && springboard.displaysApp(photos)) {
		tests.push("Photos");
		tests.push(phtCreateTest("ScrollThroughAPhotoAlbum", null, photosTest_scrollThroughAPhotoAlbum, "Scroll through a photo album"));
		tests.push(phtCreateTest("ViewSomePicturesFromAPhotoAlbum", null, photosTest_viewSomePicturesFromAPhotoAlbum, "View some pictures from a photo album"));
		tests.push(phtCreateTest("PlayPhotoAlbumSlideshow", ["generic photos", 30], photosTest_playPhotoAlbumSlideshow, "Play slideshow for 30 seconds")); 
		tests.push(phtCreateTest("EmailPhoto", ["weliketesting@me.com", "Camera Email:" + runID], photosTest_emailPhoto, "Send an image from Photos through mail")); 
	}
	
	// Camera
	if ((typeof camera != 'undefined') && springboard.displaysApp(camera)) {
		tests.push("Camera");
		tests.push(phtCreateTest("TakePicture", null, cameraTest_takePicture, "Take a Picture, make sure it appears in the Camera Roll"));
		tests.push(phtCreateTest("DeletePhoto", null, cameraTest_deletePhoto, "Delete a Photo"));
		if (system.hasCapability('video-camera')) {
			tests.push(phtCreateTest("CaptureVideo", [15, true], cameraTest_captureVideo, "Capture a video"));
			tests.push(phtCreateTest("PlayCapturedVideo", [10], cameraTest_playCapturedVideo, "Play Captured video"));
		}
		
	}

	// Calendar
	if ((typeof calendar != 'undefined') && springboard.displaysApp(calendar)) {
		tests.push("Calendar");
		var eventText = runID;
		if (UIATarget.localTarget().model() != "iPad") {
			tests.push(phtCreateTest("NavigateCalendarViews", null, calTest_navigateBetweenViews, "Navigate to each calendar view"));		
		} else {
			tests.push(phtCreateTest("NavigateCalendarViews", null, calTest_navigateBetweenViews, "View events in Day, Week, Month and List views"));		
		}
		tests.push(phtCreateTest("AddCalendarEvent", [eventText, "Area 51", null, null, true], calTest_addEvent, "Add an event to the calendar"));
		tests.push(phtCreateTest("SearchCalendarEvent", [eventText, null], calTest_searchForEventUsingSearchBar, "Search for an event"));		
		tests.push(phtCreateTest("DeleteCalendarEvent", [eventText + "_deleteTest"], calTest_deleteCalendarEvent, "Delete an event"));
	}

	
	// Maps
	if ((typeof maps != 'undefined') && springboard.displaysApp(maps)) {
		// use Beijing instead of Seattle for phones with restricted Wifi (China) <rdar://problem/6780293> N82c only: no coffee in Seattle, Wa
		var citySearch = (hasWifi) ? "Seattle, WA" : "Beijing, China";
		// cannot verify location details in N82c
		var locationDetailsParameters = (hasWifi) ? ["searchLocation:London", "addressToVerify:London"] : ["searchLocation:London"];
		tests.push("Maps");
		tests.push(phtCreateTest("MapAddress", [citySearch], mapsTest_search, "Search for city"));
		tests.push(phtCreateTest("MapSearch", ["Coffee"], mapsTest_search, "Search for keyword"));
		tests.push(phtCreateTest("ZoomOutMaps", [maps.getAvailableViews()[0], 150, 150], mapsTest_zoomOut, "Zoom out in map view (no validation)"));
		tests.push(phtCreateTest("ZoomInMaps", ["Satellite", 150, 150], mapsTest_zoomIn, "Zoom in in map view (no validation)"));
		tests.push(phtCreateTest("DragSatelliteView", ["Satellite", 1, 170, 315, 425, 1], mapsTest_drag, "Drag map in satellite view (no validation)"));
		tests.push(phtCreateTest("FlickMapView", [maps.getAvailableViews()[0], 1, 170, 315, 425, 0.1], mapsTest_flick, "Flick map in map view (no validation)"));
		tests.push(phtCreateTest("GetCurrentLocation", null, mapsTest_getCurrentLocation, "Get your current location"));
		tests.push(phtCreateTest("AddBookmark", null, mapsTest_addBookmark, "Add a bookmark"));
		tests.push(phtCreateTest("DeleteBookmark", null, mapsTest_deleteBookmark, "Delete a bookmark"));
		tests.push(phtCreateTest("ShareLocation", ["sendThru:Email", "emailSubject:Share Location:" + runID,
												   "mailRecipient:weliketesting@me.com", "searchLocation:Boston,MA", "shouldValidate:true"], mapsTest_shareLocation, "Share a location"));
		tests.push(phtCreateTest("GetDirections", ["New York, NY","Boston, MA"], mapsTest_getDirections, "Get driving directions"));
		tests.push(phtCreateTest("ShowTraffic", ["searchLocation:New York, NY"], mapsTest_showTraffic, "Turn on Show Traffic (no validation)"));
		tests.push(phtCreateTest("ViewLocationDetails", locationDetailsParameters, mapsTest_viewLocationDetail, "View a location's details")); 
		tests.push(phtCreateTest("ShowStreetView", ["searchLocation:Boston, MA"], mapsTest_showStreetView, "Find Boston MA and load multiple views in Streetview"));
	}
	
	// Notes
	if ((typeof notes != 'undefined') && springboard.displaysApp(notes)) {
		tests.push("Notes");
		tests.push(phtCreateTest("CreateNote", ["Testing Notes", "Entering some text as the body of the note."], notesTest_createNote, "Create a new note and enter some text"));
		tests.push(phtCreateTest("DeleteNote", ["Testing Notes", "Entering some text as the body of the note."], notesTest_deleteNote, "Delete an existing note"));
		tests.push(phtCreateTest("SelectPreviousNextNote", null, notesTest_selectPreviousNextNote, "Use Previous and Next controls"));
		tests.push(phtCreateTest("EmailNote", ["weliketesting@me.com", "Note:" + runID, "Hi!, I like being a note.  How about you? ", true], notesTest_emailNote, "Email a note"));
		
	}
	
	// Clock
	if ((typeof clock != 'undefined') && springboard.displaysApp(clock)) {
		tests.push("World Clock");
		tests.push(phtCreateTest("AddAndWaitForAlarm", [], clockTest_addAndWaitForAlarm, "Add an alarm"));
		tests.push(phtCreateTest("AddWorldClock", ["Paris", "Paris, France"], clockTest_addWorldClock, "Add a new world clock"));
		tests.push(phtCreateTest("RemoveWorldClock", ["Paris"], clockTest_removeWorldClock, "Remove world clock"));		
		tests.push(phtCreateTest("StartStopwatch", [], clockTest_startStopwatch, "Start the stopwatch"));
		tests.push(phtCreateTest("StopStopwatch", [], clockTest_stopStopwatch, "Stop the stopwatch"));
		tests.push(phtCreateTest("ResetStopwatch", [], clockTest_resetStopwatch, "Reset the stopwatch"));
		tests.push(phtCreateTest("GetStopwatchLaptime", [], clockTest_getStopwatchLaptime, "Check the stopwatch laptime"));		
	}
	
	// Weather
	if ((typeof weather != 'undefined') && springboard.displaysApp(weather)) {
		tests.push("Weather");
		tests.push(phtCreateTest("AddCityWeather", ["Atlanta, GA"], weatherTest_addCity, "Add a city"));
		tests.push(phtCreateTest("CheckLocalWeather", ["Cupertino"], weatherTest_slideToCity, "Check Local (Cupertino) Weather"));
		tests.push(phtCreateTest("SlideWeatherToCity", ["New York"], weatherTest_slideToCity, "Slide to New York"));
		tests.push(phtCreateTest("RemoveCityWeather", ["Cupertino"], weatherTest_deleteCity, "Remove a city"));
	}
	

	// YouTube
	if ((typeof youtube != 'undefined') && springboard.displaysApp(youtube)) {
		tests.push("YouTube");
		tests.push(phtCreateTest("SearchForMovie", ["The Real Bruce Lee"], youtubeTest_searchForMovie, "Search for a movie"));
		tests.push(phtCreateTest("AddYouTubeBookmark", [], youtubeTest_addBookmarkFromMovie, "Add movie to bookmarks"));
		tests.push(phtCreateTest("LoginToYoutubeAccount", [], youtubeTest_loginToYoutubeAccount, "Login to Youtube Account"));	
		tests.push(phtCreateTest("EmailYoutubeVideo", ["weliketesting@me.com"], youtubeTest_emailYoutubeVideo, "Email Video"));	
	}
	
	// Calculator
	if ((typeof calculator != 'undefined') && springboard.displaysApp(calculator)) {
		tests.push("Calculator");
		tests.push(phtCreateTest("ClearCalculator", null, calcTest_clear, "Clear the calculator"));
		tests.push(phtCreateTest("Calculate", ["987+654", "1641.000000"], calcTest_calculate, "Enter a calculation"));
		tests.push(phtCreateTest("ContinueCalculation", ["-321"], calcTest_continueCalculation, "Continue a calculation"));
	}

	// 3rd Party Apps
	if ((typeof appstore != 'undefined') && springboard.displaysApp(appstore)) {	
		if (UIATarget.localTarget().model() == 'iPad') tests.push("App Store");
		else tests.push("3rd Party Apps"); 
		
		tests.push(phtCreateTest("PurchaseFacebook", ["Facebook", kStorePassword, null, "Facebook", kStoreUsername], appStoreTest_purchaseAppThroughSearching, "Search for 3rd party app and purchase it"));
		tests.push(phtCreateTest("LaunchFacebook", null, facebookTest_launch, "Launch a purchased 3rd party app"));
	}
	
	// Stocks
	if ((typeof stocks != 'undefined') && springboard.displaysApp(stocks)) {
		tests.push("Stocks");
		tests.push(phtCreateTest("AddStock", ["Google"], stocksTest_addStock, "Add Stock AAPL to List, if it's not already there"));
		tests.push(phtCreateTest("RemoveAndAddStock", null, stocksTest_removeAndAddStock, "Remove and then Add Stock AAPL"));
	}
	
	// Safari
	if ((typeof safari != 'undefined') && springboard.displaysApp(safari)) {
		tests.push("Safari");
		tests.push(phtCreateTest("LoadSafariPage", 
								 ["http://pttest.apple.com/perfmarketing-power/testcontent/digg.html"], safariTest_loadSafariPage, "Load web page in Safari"));
		tests.push(phtCreateTest("PerformGoogleSearch", 
								 ["amazon", "www.amazon.com", false], safariTest_performGoogleSearch, "Perform a Google search"));
		tests.push(phtCreateTest("SelectItemFromSuggestionList", 
								 ["www.appl", "www.apple.com/", "http://www.apple.com/"], safariTest_selectItemFromSuggestionList, "Select an item from the Suggestion List"));
		tests.push(phtCreateTest("RefreshPage", 
								 ["http://pttest.apple.com/perfmarketing-power/testcontent/smithsonian.html"], safariTest_refreshPage, "Refresh page"));
		tests.push(phtCreateTest("ClickOnURL", 
								 ["http://pttest.apple.com/perfmarketing-power/", "flickr.html"], safariTest_clickOnURL, "Click on URL"));
		tests.push(phtCreateTest("OpenWebPageInTab", 
								 openWebPageInTabParameters, 
								 safariTest_openWebPageInTab, "Open a web page in a Tab"));
		tests.push(phtCreateTest("OpenWebPageFromPreviousTab", openWebPageFromPreviousTabParameters, 
										safariTest_openWebPageFromPreviousTab, "Open a web page from a previous tab"));
		tests.push(phtCreateTest("NavigateBackForward", 
								 ["url:http://pttest.apple.com/perfmarketing-power/testcontent/smithsonian.html", "url:http://pttest.apple.com/perfmarketing-power/testcontent/caltrain.html",
								  "action:Back", "action:Forward"], 
								 safariTest_navigateWebPagesWithPreviousNextButtons, "Navigate with the Back / Forward buttons"));
		tests.push(phtCreateTest("LoadBookmark", [], safariTest_loadRandomBookmark, "Load Bookmark"));
		tests.push(phtCreateTest("AddBookmark", 
								 ["http://pttest.apple.com/perfmarketing-power"], safariTest_addBookmark, "Add a bookmark"));
		tests.push(phtCreateTest("AddWebClip", 
								 ["http://pttest.apple.com/perfmarketing-power"], safariTest_addBookmarkToHomeScreen, "Add a webclip"));
		//tests.push(phtCreateTest("PlayQuicktimeMovie", playQuicktimeMovieParameters, safariTest_playQuicktimeMovie, "View a QuickTime movie"));
		
	}
	
	// Spotlight tests
	if (typeof springboard != 'undefined') {
		var musicApp = "com.apple.videos";
		tests.push("Spotlight");
		tests.push(phtCreateTest("SearchForVideoUsingSpotlight", ["Nasa", "app:" + musicApp], springboardTest_search, "Search for video by title")); // will fail w/o QL content
		if (UIATarget.localTarget().model() != 'iPad') {
			tests.push(phtCreateTest("SearchForCalculatorUsingSpotlight", ["Calculator", "app:com.apple.calculator", "query:name contains 'Calculator'"], springboardTest_search, "Search for calculator app")); 
		} else {
			tests.push(phtCreateTest("SearchForSafariUsingSpotlight", ["Safari", "app:com.apple.mobilesafari", "query:name contains 'Safari'"], springboardTest_search, "Search for the Safari app")); 
		}
	}
	
	// Cut/Copy/Paste/Undo tests
	if ((typeof notes != 'undefined') && springboard.displaysApp(notes)) {
		tests.push("Cut/Copy/Paste/Undo");
		var noteTitle = "CopyNote: " + runID;
		tests.push(phtCreateTest("CopyNote", [noteTitle, "Hi!  I like being copied.  How about you?"], notesTest_copyNote, "Copy text from one note and paste it into another"));
		if ((typeof mail != 'undefined') && springboard.displaysApp(mail)) {
			tests.push(phtCreateTest("CopyFromWebPage", ["http://pttest.apple.com/perfmarketing-power/testcontent/disney.html", "name contains 'Tigger & Pooh'"], safariTest_copyFromWebPage, "Copy text from a web page onto the pasteboard"));
			tests.push(phtCreateTest("PasteIntoNote", ["Tigger & Pooh"], notesTest_pasteIntoNote, "Paste text from web page into a new note"));	
			tests.push(phtCreateTest("UndoAction", ["type", "textToType:Someday I will run away to the circus.", "shouldRedo:true"], notesTest_undoAction, "Undo typing"));
		}
	}
		
	// SMS
	if ((typeof messages != 'undefined') && springboard.displaysApp(messages) && hasTelephony) {
		tests.push("SMS");
		var bulkSMSText = "Bulk SMS, " + runID;
        tests.push(phtCreateTest("TurnOffMadrid", ["Messages", "iMessage", 0], settingsTest_changeSingleSwitch, "Turn off Madrid"));
		tests.push(phtCreateTest("SendReceiveSMS", ["1234567890_abcdefghijklmnopABCDEFGHIJKLMNOP.", "timeout:60", "minPercentForPass:0.75", "numberOfAdditionalTextMessagesToSend:5"], 
				messagesTest_sendReceiveTextMessage, "Send and receive an SMS"));
		tests.push(phtCreateTest("DeleteSMSThread", ["0"], messagesTest_deleteThread, "Delete an SMS thread"));
		tests.push(phtCreateTest("SendBulkSMS", [bulkSMSText, "timeout:60", "expectedPercentage:0.5", "phoneNumber:" + telephony.myPhoneNumber, "phoneNumber:" + kSMSBuddy1, "phoneNumber:" + kSMSBuddy2], messagesTest_sendReceiveBulkSMS, "Send and receive bulk SMS"));	
		
		if (system.hasCapability('mms')) {
			tests.push(phtCreateTest("TakePhotoAndSendMMS", ["from:Take Photo"], messagesTest_sendReceivePhotoOrVideoMMS, "Take a photo and send it using MMS"));
			tests.push(phtCreateTest("SendExistingPhotoMMS", ["from:Choose Photo", "textToSend:Hello There."], messagesTest_sendReceivePhotoOrVideoMMS, "Send an existing photo using MMS"));
			if (system.hasCapability('video-camera')) {
				tests.push(phtCreateTest("SendVideoMMS", ["from:Take Video", "timeout:300"], messagesTest_sendReceivePhotoOrVideoMMS, "Send a video using MMS"));
			}
		}
	}
	
	// System Tests

	tests.push("System")
	tests.push(phtCreateTest("SetWallpaper", [], settingsTest_setWallpaper, "Set wallpaper to something from wallpaper"));
	tests.push(phtCreateTest("LockUnlock", ["0"], systemTest_lockAndUnlockDevice, "Lock and unlock the device"));
	tests.push(phtCreateTest("SetPasscode", ["1111"], settingsTest_setPasscode, "Set a passcode for the device"));
	tests.push(phtCreateTest("LockUnlockWithPasscode", ["0", "1111"], systemTest_lockAndUnlockDevice, "Lock and unlock the device with passcode set"));
	tests.push(phtCreateTest("ChangePasscode", ["2222"], settingsTest_setPasscode, "Change the passcode on the device"));
	tests.push(phtCreateTest("TurnPasscodeOff", ["2222"], settingsTest_turnPasscodeOff, "Turn passcode for the device off"));

	
}

function usage() {
	system.println("usage: QuickLook.js [--enable <string>] [--disable <string>] [-o <path> | -filepath <path> | --filename <string>] [-l | --list]");
	system.println("	--disable	tests to skip (may use regex to describe tests)");
	system.println("	--enable	tests to run (may use regex to describe tests)");
	system.println("	--filepath	full path for the results file");
	system.println("	--filename	name to use for the results file");
	system.println("	--wifiname	name to use for the wifi basestation");
	system.println("	--wifipassword	password to use for the wifi basestation");
	system.println("	--nosetup	skip the setup phase of the QuickLook")
	system.println("	--list		list the available tests");
	system.println("	--writecrashes	write out crashes to the results file")
	system.println("	--help | -h	usage description");
}

function main() {
	var tests = new Array();
	var version = harness_getBuildVersion();
	var filename = "QuickLook_" + version + ".txt";
	var filepath;
	var wifiname;
	var wifipassword;
	var writeCrashes = false;
	var enableSetup = true;
	
	// seed the generator, so that any random events are the same for every run
	system.setRandomSeed(1);
	UIATarget.localTarget().unlockScreenIfNecessary();	// screen must be unlocked to check for springboard app icons
	
	// process command line arguments
	var options = new Options();
	if (options.help || options.h) {
		usage();
		return;
	}
	if (options.list || options.l) {
		addTestsToArray(tests);
		harness_listTests(tests);
		return;
	}
	if (options.filename) filename = options.filename;
	if (options.nosetup) enableSetup = false;
	if (options.writecrashes) writeCrashes = true;
	if (options.o) filepath = options.o;
	else if (options.filepath) filepath = options.filepath;
	else {
		harness_makeDirectory(kReportPath);
		filepath = kReportPath + filename;
	}
	
	// if setup is enabled, add the setup tests to the test array.
	if (enableSetup) {
		
		// Unlock the device
		tests.push("Setup");
		//tests.push(phtCreateTest("UnlockDevice", ["0"], systemTest_lockAndUnlockDevice, "Unlock the device")); 
		
		// Set auto-lock to never
		tests.push(phtCreateTest("SetAutoLockToNever", ["General", "Auto-Lock", "Never"], settingsTest_chooseCheckmarkedItem, "Set Auto-Lock to Never"));
        tests.push(phtCreateTest("EnableLocationServices", ["Location Services", "Location Services", "1"], settingsTest_changeSingleSwitch, "Enable Location Services"));
        tests.push(phtCreateTest("EnableBatteryLifeLogging", ["Internal Settings", "Power", "Battery Life Logging", "1"], settingsTest_changeSingleSwitch, "Enable Battery Life Logging"));
		tests.push(phtCreateTest("EnableWifiLogging", ["Internal Settings", "WiFi", "Logging", "UI Logging", 1], settingsTest_changeSingleSwitch, "Enable Wifi Logging"));
		tests.push(phtCreateTest("EnableWifiManagerLogging", ["Internal Settings", "WiFi", "Logging", "WiFi Manager", "Logging", "1"], settingsTest_changeSingleSwitch, "Enable WifiManager Logging"));
		tests.push(phtCreateTest("EnableWifiManagerFileLogging", ["Internal Settings", "WiFi", "Logging", "WiFi Manager", "File Logging", "1"], settingsTest_changeSingleSwitch, "Enable WifiManager File Logging"));
		tests.push(phtCreateTest("TurnLocationDLoggingOn", null, settingsTest_turnLocationdLoggingOn, "Turn locationd logging on"));
		tests.push(phtCreateTest("EnableiTunesStoreLogging", ["Internal Settings","iTunes Store","Level (Console)","Verbose Status + Errors"], settingsTest_chooseCheckmarkedItem, "Enable iTunes store Logging"));
		if ((typeof facetime != 'undefined') && springboard.displaysApp(facetime) && hasTelephony) {
			tests.push(phtCreateTest("EnableFaceTimeRegistrationLogging", ["Internal Settings","FaceTime","Registration Logging", "1"], settingsTest_changeSingleSwitch, "Enable FaceTime Registration Logging"));
			tests.push(phtCreateTest("EnableFaceTimeCallLogging", ["Internal Settings","FaceTime","Call Logging", "1"], settingsTest_changeSingleSwitch, "Enable FaceTime Call Logging"));
		}
		if (hasTelephony)
			tests.push(phtCreateTest("DisableGroupMessaging", ["Messages", "Group Messaging", 0], settingsTest_changeSingleSwitch, "Disable Group Messaging"));
		// Setup proper Wi-Fi
		if (hasWifi) {
			if (options.wifiname) {
				wifiname = options.wifiname;
				if (options.wifipassword) {
					wifipassword = options.wifipassword;
				}
			}
			else {
				wifiname = "Automation";
				wifipassword = "wireless";
				
			}
			tests.push(phtCreateTest("SetWifi", ["1", wifiname, wifipassword, "backupNetwork:AppleWiFi"], settingsTest_setWifi, "Set Wifi to " + wifiname));
			//tests.push(phtCreateTest("SetWifiOn", ["1", "AppleWiFi"], settingsTest_setWifi, "Turn wifi on and set it to AppleWiFi"));
		}

		// Turn MALogs on if the device has a phone -- disabled because this seems to have a large impact on memory
		//if ((typeof phone != 'undefined') && springboard.displaysApp(phone)) {
		//	tests.push(phtCreateTest("BasebandLoggingOn", null, settingsTest_turnOnBasebandLogging, "Turn on Baseband Logging"));
		//}
	}
	
	addTestsToArray(tests); // add all of the normal tests to the array
	
	// uncomment this line if you want top data added to the output
	system.setDefault("com.apple.harness", "utilities", ["/usr/bin/top -o -cpu -l 1"]);
	
	harness_removeFile(filepath);
	harness_runTestsFromArray(tests, filepath, options.disable, options.enable, false, writeCrashes);
	
	system.println("Done Running QuickLook.");
}

main();
