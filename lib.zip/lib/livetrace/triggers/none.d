/* @description No trigger, or trigger integrated into tracing script */
