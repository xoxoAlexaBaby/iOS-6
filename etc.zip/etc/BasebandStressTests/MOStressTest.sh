#!/bin/sh

#################################################################################################
#                                                                                               #
#   ScriptName: CalltressTest.sh                                                                #
#                                                                                               #
#   Usage:      nohup <path_to_Script>/IPCStressTest.sh  <Device_Phone_Number>  <Iterations> &  #
#                                                                                               #
#   Purpose:    To run stress tests on the device stressing the IPC. The script keeps running   #
#               Data downloads, make calls, Send/Receive SMS continuously until the Iterations  #
#               specified.                                                                      #
#               The purpose of the script is to ensure the stability of the Baseband/AP builds  #
#                                                                                               #
#   Author:     Jerome Jesu                                                                     #
#                                                                                               #
#   Revisions:                                                                                  #
#################################################################################################

MTNumber=
CALL_COUNT=
echo "1.  $1,  $2,  $3,  $4"

#while getopts 'p:i:' OPTION; 
#do
#	case "$OPTION" in
#		p )	MTNumber="$OPTARG";;
#		i )	CALL_COUNT="$OPTARG";;
#		/?)	echo "INVALID OPTIONS.\n"; exit 1;;
#	esac
#done
#shift $(($OPTIND - 1))

echo "2. $1,  $2,  $3,  $4"
echo "3. MT Number = $MTNumber, CALL_COUNT = $CALL_COUNT"
MTNumber=$2
CALL_COUNT=$4
echo "4. MT Number = $MTNumber, CALL_COUNT = $CALL_COUNT"

if [ "$MTNumber" ] && [ "$CALL_COUNT" ]; then
	echo "Got MT phone number -- $MTNumber and the call count -- $CALL_COUNT"
else
	echo "\nUSAGE: $0  -p <MT Number>  -i <CALL_COUNT>"
	echo "		example: $0   -p 4085505132   -i 100\n"
	exit 1
fi

SCRIPTS_DIR="/usr/local/etc/BasebandStressTests/"
CALL_INTERVAL=25
DUMP_LOG_ITERATIONS=4

logsDir="/var/wireless/Library/Logs/CrashReporter/Baseband/"
logFiles="$logsDir/*csi*"
csiLogsDir="CsiLogs"
if [ ! -e  $csiLogsDir ]; then mkdir $csiLogsDir; fi

processCsiLogs()
{
	cp  $logFiles  $csiLogsDir/
	ls  $csiLogsDir/*csi* | perl -lne '$f = $_; open (F, $f); $f =~ s/(.*\Qlog-bb-\E)(.*)(\Q-csi.\E(.*))/$2/; foreach (<F>) { chomp; if (/\QReason: \E/) { s/^(.*Reason: )//; s/,/_/g; $i=$_; print "$i,$f"; last; } } close F; '  > /tmp/crashReasons
	cp /tmp/crashReasons crashReasons
	totalCsiLogs=`ls $csiLogsDir/*csi* | wc -l | perl -lne ' s/\s*//; print'`
	totalModemResets=`cat /tmp/crashReasons | grep "modem reset" | wc -l | perl -lne ' s/\s*//; print'`
	totalBasebandCrashes=`cat /tmp/crashReasons | grep "baseband crash"| wc -l | perl -lne ' s/\s*//; print'`
	totalCallFailures=`cat /tmp/crashReasons | grep -i "call fail" | wc -l | perl -lne ' s/\s*//; print'`
	totalCallDrops=`cat /tmp/crashReasons | grep -i "call drop"| wc -l | perl -lne ' s/\s*//; print'`
	totalFTO=`cat /tmp/crashReasons | grep "FTO" | wc -l | perl -lne ' s/\s*//; print' `
	totalBBResets=$(($totalModemResets + $totalBasebandCrashes))
	totalLogs=$(($totalBBResets + $totalCallFailures + $totalCallDrops + $totalDumps + $totalUserDumps + $totalFTO))
	totalOthers=$(($totalCsiLogs - $totalLogs))
	echo "RESETS-$totalModemResets  CRASHES-$totalBasebandCrashes"
	echo "FAIL-$totalCallFailures,  DROPS-$totalCallDrops, DUMPS-$totalDumps, USERDUMPS-$totalUserDumps"
	echo "FTO-$totalFTO,  OTHERS-$totalOthers"
	
} 

sendSMSToBuddy()
{
testCT -s $MTNumber "SMSBuddy
$SCRIPTS_DIR/getCallResult.sh
$CALL_COUNT
$RESULT
$startTime"		
}


###########################################################################
# FUNCTION to Make a MO Call
# USAGE: makeCall LOOPBACKNUMBER  COUNT (optional)
###########################################################################
makeCALL()
{
	/usr/local/bin/testCT -c $1
	resultCall=$?;
	startTime=`date "+%s"`
	echo " Time -- $startTime. Result --- $resultCall"  >> MOCallStressTest.txt
	
	if [ $resultCall -eq 0 ]; then
		echo `date` ": Call ($2) PASSED. " >> MOCallStressTest.txt;
		RESULT="SUCCESS"
		sendSMSToBuddy

	else
		echo `date` ": Call ($2) FAILED. " >> MOCallStressTest.txt;
		RESULT="FAIL"
		sendSMSToBuddy
		#testCT -l "MO CALL FAILED..."
	fi
	echo "Done Making Call $CALL_COUNT " >> MOCallStressTest.txt
	processCsiLogs
	echo " Modem Reset = $totalBBResets; Call Drops = $totalCallDrops;  Call Failures = $totalCallFailures;  FTO = $totalFTO"  >> MOCallStressTest.txt

}



##########################################################################
#################### START EXECUTING STRESS TESTS  #######################
##########################################################################

GREP="grep SMSBuddy"
echo "\n\n ################### " >> MOCallStressTest.txt
echo `date` ": Begining Iteration - $CALL_COUNT " >> MOCallStressTest.txt
echo "####################" >> MOCallStressTest.txt

# MAKING MO call 1
sleep 15
/usr/local/bin/scripter -f /usr/local/etc/scripter/general/Interact.js com.apple.springboard "dismissAlerts(app)"
PIDS=`ps -A | $GREP | perl -lne ' if ( !/grep/ ) { $p = (split)[0]; $p =~ s/\s*//g; print $p;} ' `
echo "Killing Processes  --- $PIDS."
kill -9 $PIDS
/usr/local/bin/scripter -file /usr/local/etc/scripter/general/ExecuteTest.js "events.holdLock(2)"
sleep 15
eventer h
/usr/local/bin/SMSBuddy &

echo "\n	####	MAKING MO CALL - $CALL_COUNT."
makeCALL $MTNumber $CALL_COUNT
