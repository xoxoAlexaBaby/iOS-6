/*
 Class: UIApp (stocks)
 Stocks object
 */

#import "../libs/SpringBoard.js"
#import "../libs/UIAAppWidgetAdditions.js"

stocks = UIAApp.application("Stocks", "com.apple.stocks");

if (typeof stocks != 'undefined') {

	// --------------------------------------------------------------------------------
	//	Function: getMainViewElement
	//		Gets the main view of the "widget".  This method 
	//		is primarily used by UIAAppWidgetAdditions.js to 
	//		get the containing view of all the other view elements,
	//		such as buttons, table views, etc.
	//
	//	Parameters: 
	//		None
	//				
	//	Returns: 
	//		Main window of the stocks app
	// --------------------------------------------------------------------------------
	stocks.getMainViewElement = function getMainViewElement() {
		return this.mainWindow();
	} // end stocks.getMainViewElement
		
}
