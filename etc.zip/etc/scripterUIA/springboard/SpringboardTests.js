#import "../libs/SpringBoard.js"
#import "../libs/PHTesting.js"

//----------------------------------------------------------------------------------------
//	Function: springboardTest_search 
//		Search within spotlight for a string.
//
//	Parameters: 
//		searchString (string) - string to enter into the search field
//
//  Optional Parameters: 
//		app (string) - (optional)  the bundle id of the app that should be launched, if you click 
//			the specified result. 
//		resultPredicateString (string) - (optional) the predicate string that will be used to 
//			select the search result
//		index (integer) - in the case of several results, indicates the index of the result
//			to click (starts at the top at 0).  Use either resultPredicateString or index.
//			If neither are used, we just click the first thing in the list, (i.e. index:0)
//
// 	Usage:
//		 "QuickLook" "app:Notes" "index:1"
//		 "Yesterday" "app:iPod" "resultPredicateString:"name == 'Yesterday' and value contains 'Beatles'"
//	
//	Returns:
//	 0 if test failed, 1 if it succeeded.  Uses the PHTesting object.  
//----------------------------------------------------------------------------------------
function springboardTest_search() {
	if (this.argv.length < 1) {
		UIALogger.logError("Not enough args being passed.");
		return 64;		
	}
	
	var searchString = this.argv[0];
	var optionsArray = new Array();
	
	// push options onto optionsArray;
	for (var i=1; i<this.argv.length; i++) {
		optionsArray.push(this.argv[i]);
	}
	var options = new Object();
	options.app = UIAUtility.valuesForKey("app", optionsArray, 1); 
	options.index = UIAUtility.valuesForKey("index", optionsArray, 1);
	options.resultPredicateString = UIAUtility.valuesForKey("resultPredicateString", optionsArray, 1);
	
	if ((options.index == null) && (options.query == null)) {
		options.index = 0;
	}
	
	var theElement = springboard.search(searchString, options);
	theElement.tap();
	
	if (options.app) {
		UIALogger.logDebug("Waiting for the expected app to become active...");
		var didLaunch = UIAApp.application(options.app).waitForActive(60);
		if (!didLaunch) {
			this.testError = "Current app is '" + UIATarget.localTarget().frontMostApp().bundleID() + "', expected '" + options.app + "'.";
			UIALogger.logError(this.testError);
			return this.testResult = 0;
		}
		UIALogger.logMessage("App '" + options.app + "' launched as expected");		
	}	
	
	return this.testResult = 1;	
}

//----------------------------------------------------------------------------------------
//	Function: springboardTest_launchApp 
//		Launches specified app and waits timeout seconds.  Then checks
//		to make sure app is still frontmost.
//
//	Parameters: 
//		app (string | UIApp Object) - app to launch - could be the app bundle id or the UIApp object
//		timeout (number) - number of seconds to wait before checking to make sure that the app
//		is still frontmost.  Optional--if not specified, uses 5 seconds by default.
//	
//	Returns:
//	 0 if test failed, 1 if it succeeded.  Uses the PHTesting object.  
//----------------------------------------------------------------------------------------
function springboardTest_launchApp() {
	if (this.argv.length < 1) {
		UIALogger.logError("Please pass in the app info.");
		return 64;		
	}
	
	var timeout = 5;  // wait 5 seconds by default
	if (this.argv.length > 1) {
		timeout = parseInt(this.argv[1]);
	}	
	var theApp;
	
	// insure that the app is not already running <rdar://problem/7747970> all launch tests should be failing if the device fails to activate
	springboard.getToSpringBoard();
	
	if ( typeof this.argv[0] == 'string' ) {
		theApp = UIAApp.application(this.argv[0]);
		theApp.launchIfNotActive(); // throws an error if app could not launch.
	} else {
		theApp = this.argv[0];
		theApp.launchIfNotActive();
	}
	var appName = theApp.name;
	
	UIALogger.logDebug("Waiting " + timeout + " seconds to make sure app doesn't crash.");
	UIATarget.localTarget().delay(timeout);
	
	if (!theApp.isActive()) {
		this.testError = "The application '" + appName + "' is no longer active after " + timeout + " seconds.";
		UIATarget.localTarget().frontMostApp().logElementTree();
		UIALogger.logMessage("The app that is currently frontmost is: " + UIATarget.localTarget().frontMostApp().name());
		UIALogger.logError(this.testError);
		return this.testResult = 0;
	}
	return this.testResult = 1;
}

//----------------------------------------------------------------------------------------
//	Function: springboardTest_launchAppFromAppSwitcher 
//		Launches specified app from the app switcher 
//		and waits timeout seconds.  Then checks to make sure app is still frontmost.
//
//	Parameters: 
//		app (string | UIApp Object) - app to launch - could be the app bundle id or the UIApp object
//		timeout (number) - number of seconds to wait before checking to make sure that the app
//			is still frontmost.  Optional--if not specified, uses 5 seconds by default.
//	
//	Returns:
//		0 if test failed, 1 if it succeeded.  Uses the PHTesting object.  
//----------------------------------------------------------------------------------------
function springboardTest_launchAppFromAppSwitcher() {
	if (this.argv.length < 1) {
		UIALogger.logError("Please pass in the app info.");
		return 64;		
	}
	
	var timeout = 5;  // wait 5 seconds by default
	if (this.argv.length > 1) {
		timeout = parseInt(this.argv[1]);
	}	
	var theApp;
	
	if ( typeof this.argv[0] == 'string' ) {
		theApp = UIAApp.application(this.argv[0]);
	} else if (this.argv[0] instanceof UIAApp) {
		theApp = this.argv[0];
	} else {
		UIALogger.logError("Unexpected argument type: " + (typeof this.argv[0]));
		return 64;	
	}
	
	UIALogger.logDebug("Should first launch the app to make sure it is in the app switcher");
	theApp.launchIfNotActive();

	UIALogger.logDebug("App should be launched now. Going back to springboard...");
	springboard.getToSpringBoard();
	
	var appIcon = springboard.getToIconWithNameInAppSwitcher(theApp.name);
	if (!appIcon.isValid()) {
		this.testError = "Launched application '" + theApp.name + "' is not present in the app switcher";
		UIALogger.logError(this.testError);
		return this.testResult = 0;
	}
	
	var originalValue = theApp.shouldUseSwitcherForLaunching;
	UIALogger.logDebug("Original shouldUseSwitcherForLaunching value was " + originalValue + ". Setting it to true.");
	theApp.shouldUseSwitcherForLaunching = true;
	
	try {
		var subTest = phtCreateTest("LaunchApp", [theApp, timeout], springboardTest_launchApp, "Launching the app from the switcher '" + theApp.name + "'.");
		var result = subTest.execute();
		if (subTest.testError) this.testError = subTest.testError;
		theApp.shouldUseSwitcherForLaunching = originalValue;
		return this.testResult = subTest.testResult;		
	} catch(e) {
		UIALogger.logError("Encountered exception");
		theApp.shouldUseSwitcherForLaunching = originalValue;
		throw e;
	}
}

//----------------------------------------------------------------------------------------
//	Function: springboardTest_quitApp 
//		Goes to the app switcher, and quits the app
//
//	Parameters: 
//		app (string | UIApp Object) - app to quit - could be the app bundle id or the UIApp object
//	
//	Returns:
//		0 if test failed, 1 if it succeeded.  Uses the PHTesting object.  
//----------------------------------------------------------------------------------------
function springboardTest_quitApp() {
	if (this.argv.length < 1) {
		UIALogger.logError("Please pass in the app info.");
		return 64;		
	}

	var theApp;
	
	if ( typeof this.argv[0] == 'string' ) {
		theApp = UIAApp.application(this.argv[0]);
	} else if (this.argv[0] instanceof UIAApp) {
		theApp = this.argv[0];
	} else {
		UIALogger.logError("Unexpected argument type: " + (typeof this.argv[0]));
		return 64;	
	}
	
	if (theApp.isActive()) {
		UIALogger.logDebug("App " + theApp.name + " is active. Need to go to springboard first");
		springboard.getToSpringBoard();
	} else {
		UIALogger.logDebug("App " + theApp.name + " is active");
	}
	springboard.quitAppWithName(theApp.name);
	springboard.getToSpringBoard();
	
	return this.testResult = 1;
}


// --------------------------------------------------------------------------------
//	Function: springboardTest_reorderHomeScreen 
//		Moves app icon.
//
//	Parameters:
//		appName (string) - optional - name of application to reorder (e.g. Stocks)
//  	pageIndex (integer or string) - optional - index of page to put app on. 
//          Note that this page must already exist. The page index is either an 
//          integer from 0 to (no. of pages)-1 (if the app needs to be placed in 
//          scroll view area of the window), or "dock" (if the app needs to be 
//          placed on the dock). 
//		appIndex (integer) - optional - place on page to put app.
//		
//	Returns:
//		1 on pass, 0 on fail.  
// --------------------------------------------------------------------------------
function springboardTest_reorderHomeScreen() {
	var appName;
	var pageIndex;
	var appIndex;
	
	if (this.argv.length > 0) {
		appName = this.argv[0];
	} else {
		springboard.getToFirstIconPage();
        var apps = springboard.mainWindow().scrollViews()[0].buttons();
		if (apps.length < 1) {
			this.testError = "No applications found.";
			return this.testResult = 0;
		}
        appName = apps[system.randomInteger(0, apps.length-1)].name();		
	}

	UIALogger.logDebug("App name is '" + appName + "'");
	var app = springboard.getToIconWithName(appName);
	var pages = springboard.getIconPages();
	
	if (this.argv.length > 1) {
		pageIndex = this.argv[1];
		// page must not be out of bounds
		if (pageIndex != "dock" && pageIndex >= pages.length) {
			this.testError = "Invalid page index specified.";
			return this.testResult = 0;
		}
		//make sure dock is not full
		if (pageIndex == "dock" && pages["dock"].length == springboard.maxNumberOfDockIcons()) {
			this.testError = "Dock is full -- cannot move icons to the dock";
			return this.testResult = 0;
		}
	} else {
		pageIndex = system.randomInteger(0, pages.length-1);
	}
	UIALogger.logDebug("Page index is " + pageIndex + ".");
	
	if (this.argv.length > 2) {
		appIndex = this.argv[2];
		if (appIndex >= pages[pageIndex].length) {
			this.testError = "Invalid app index specified.";
			return this.testResult = 0;
		}
	} else {
        appIndex = system.randomInteger(0, pages[pageIndex].length-1);
	}
	UIALogger.logMessage("App index is " + appIndex + ".");
	
	springboard.reorderIcon(appName, pageIndex, appIndex);

	pages = springboard.getIconPages();
	if (pages[pageIndex][appIndex].name() == appName) {
		UIALogger.logMessage("Home screen reordered.");
		return this.testResult = 1;
	} else {
		this.testError = "Application in wrong location after reordering home screen.";
		return this.testResult = 0;
	}
}

//----------------------------------------------------------------------------------------
//	Function: springboardTest_launchAppsAndVerifyAppSwitcher 
//		Launches several different apps, one at a time, then verifies that apps are
//		in correct order in the app switcher.
//
//	Parameters: 
//		app1, app2, app3... - app bundle id or UIAApp object of app to launch 
//			(i.e. "com.apple.mobilemail" or mail)
//	
//	Returns:
//		0 if test failed, 1 if it succeeded.  Uses the PHTesting object.  
//----------------------------------------------------------------------------------------
function springboardTest_launchAppsAndVerifyAppSwitcher() {
	if (this.argv.length < 1) {
		UIALogger.logError("Please pass in the app(s) to be launched");
		return 64;		
	}
	var appArray = new Array();
	
	// push the input app(s) onto an array
	for (var i = 0; i < this.argv.length; i++) {
		var theApp;
		if ( typeof this.argv[i] == 'string' ) {
			theApp = UIAApp.application(this.argv[i]);
			if (typeof theApp.name == 'undefined' ) {
				UIALogger.logMessage("Could not create a UIAApp from '" + this.argv[i] + "'");
				return 64;
			}
		} else if (this.argv[i] instanceof UIAApp) {
			theApp = this.argv[i];
		} else {
			UIALogger.logError("Unexpected argument type: " + (typeof this.argv[i]));
			return 64;	
		}
		UIALogger.logMessage("Pushing '" + theApp.name + "' onto the array of apps.");
		appArray.push(theApp);
	}
	
	for (var i=0; i<this.argv.length; i++) {
		var theApp = appArray[i];
		UIALogger.logDebug("Launching " + theApp.name + " to make sure it is in the app switcher");
		theApp.launchIfNotActive();
		UIATarget.localTarget().delay(1);  // delay to give the app a little time to finish launching 
	}
	// Bring up springboard to make sure the app we just launched shows up in the app switcher
	springboard.getToSpringBoard();
	
	// reverse the order of the apps, because the most recently launched app will be last in the app switcher
	appArray.reverse(); 
	springboard.verifyAppOrderInAppSwitcher(appArray);
	return (this.testResult = 1);
	
}

//----------------------------------------------------------------------------------------
//	Function: springboardTest_joinWiFiFromAskToJoinWindow
//		Launch an application (need to be network appliation) and join a WiFi network from Select a WiFi Network alert window
//
//	Parameters: 
//		app (string) - Bundle ID of the application to launch (Need to be a network application, such as com.apple.mobilesafari)
//		network (string) - Name of the network 
//		password (option) - Passwork of the network	
// 
//	Returns:
//     1 if the test passes
//     0 if the test fails
//
//  Usage: 
//		springboardTest_joinWiFiFromAskToJoinWindow com.apple.mobilesafari AppleWiFi
//
//	Note:
//		Need to forget all WiFi networks to trigger Ask to join Window for this test
//----------------------------------------------------------------------------------------
function springboardTest_joinWiFiFromAskToJoinWindow() {
	
	springboard.selectWiFiNetworkAlertHasShowed = false;
	
	if (this.argv.length < 2) { 
		UIALogger.logError("This test requires two arguments: Name of the network application and network name to join");
		return this.testResult = 0;
	}
	
	var theApp;
	var timeout = 10;
	springboard.wifinetwork = this.argv[1];
	//var username = "";
	
	if (this.argv.length >2) {
		springboard.wifipassword = this.argv[2];		
	}
	
	UIALogger.logMessage("Try to join network:"+springboard.wifinetwork+"; password:"+springboard.wifipassword);
	
	//Turn off Springboard to tigger Ask To Join Window
	UIATarget.pushAlertHandler(springboard.selectNetworkAlertHandler);
	
	if (!system.isScreenLocked()) {		
		UIATarget.localTarget().lock();
		UIATarget.localTarget().delay(1);
	}
	
	if ( typeof this.argv[0] == 'string' ) {
		theApp = UIAApp.application(this.argv[0]);
		theApp.launchIfNotActive(); // throws an error if app could not launch.
	} else {
		theApp = this.argv[0];
		theApp.launchIfNotActive();
	}
	
	if (typeof springboard.lastAlert == 'undefined') {
		UIALogger.logDebug("Waiting " + timeout + " seconds for Ask to Join Alert Window.");
		UIATarget.localTarget().delay(timeout);
	}
	
	UIATarget.popAlertHandler();
	
	if (!springboard.selectWiFiNetworkAlertHasShowed) {
		this.testError = "Select a WiFi network alert window did not pop up";
		return this.testResult = 0;
	} 
	
	//Check if any error from selectNetworkAlertHandler
	if (typeof springboard.lastAlert.wifiError != "undefined") {
		UIALogger.logError(springboard.lastAlert.wifiError);
		this.testError = springboard.lastAlert.wifiError;
		return this.testResult = 0;
	}

	if (settings.checkWiFiName(springboard.wifinetwork, 10)) {
		UIALogger.logMessage("Joined with network: "+springboard.wifinetwork)
	} else {
		this.testError = "Did not join the network: "+springboard.wifinetwork
		UIALogger.logError(this.testError);
		return this.testResult = 0
	}
	
	return this.testResult = 1;
}

// Create self tests -- this is an unnamed function, just to make sure any local variables stay in the correct context
(function() {	
	if (typeof springboard.selfTests == 'undefined') {
		springboard.selfTests = new Array();
	}
	
	var musicApp = "com.apple.mobileipod-VideoPlayer";
	var contactsApp = "com.apple.MobileAddressBook";
	if (UIATarget.localTarget().model() == "iPhone") {
		var musicApp = "com.apple.mobileipod-MediaPlayer";
		var contactsApp = "com.apple.mobilephone";
	} 
	springboard.selfTests.push(phtCreateTest("LaunchApp", ["com.apple.mobilesafari"], springboardTest_launchApp, "Launch safari"));
	springboard.selfTests.push(phtCreateTest("SearchForVideo", ["Nasa", "app:" + musicApp], springboardTest_search, "Search for video by title")); // will fail w/o QL content
	springboard.selfTests.push(phtCreateTest("SearchForContact", ["Bob Dylan", "app:" + contactsApp, "resultPredicateString:name contains 'Bob Dylan'"], springboardTest_search, "Search for contact")); // will fail w/o QL content
	springboard.selfTests.push(phtCreateTest("ReorderRandomAppOnHomeScreen", null, springboardTest_reorderHomeScreen, "Reorder Random App on Home Screen"));
	if (system.hasCapability("multitasking")) {
		springboard.selfTests.push(phtCreateTest("LaunchAppFromAppSwitcher", ["com.apple.Maps"], springboardTest_launchAppFromAppSwitcher, "Launch maps from app swicher"));
		springboard.selfTests.push(phtCreateTest("QuitApp", ["com.apple.Maps"], springboardTest_quitApp, "Quit maps"));
		springboard.selfTests.push(phtCreateTest("LaunchAppsUsingStringsAndVerifyAppSwitcher", ["com.apple.Preferences", "com.apple.Maps", "com.apple.mobilesafari", "com.apple.mobilemail"], 
												 springboardTest_launchAppsAndVerifyAppSwitcher, "Launch apps and verify that they are in the app switcher"));
		// Commenting out below test, because maps, settings, etc may not be imported
		///springboard.selfTests.push(phtCreateTest("LaunchAppsUsingAppObjectsAndVerifyAppSwitcher", [maps, settings, mail, safari], springboardTest_launchAppsAndVerifyAppSwitcher, "Launch Maps using app switcher"));
		
	}
}())