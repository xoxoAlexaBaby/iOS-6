#!/usr/local/bin/scripter -uiautomation YES -f

#import "../libs/PHTesting.js"

#import "../settings/SettingsTests.js"
#import "../safari/SafariTests.js"
#import "../maps/MapsTests.js"
#import "../ipod/iPodTests.js"
#import "../notes/NotesTests.js"
#import "../mail/MailTests.js"
#import "../contacts/ContactsTests.js"
#import "../clock/ClockTests.js"
#import "../calculator/CalculatorTests.js"
#import "../phone/PhoneTests.js"
#import "../appstore/AppStoreTests.js"
#import "../messages/MessagesTests.js"
#import "../3rdparty/FacebookTests.js"
#import "../calendar/CalendarTests.js"
#import "../weather/WeatherTests.js"
#import "../camera/CameraTests.js"
#import "../springboard/SpringboardTests.js"
#import "../stocks/StocksTests.js"
#import "../system/SystemTests.js"
#import "../facetime/FaceTimeTests.js"
#import "../youtube/YouTubeTests.js"
#import "../itunes/iTunesTests.js"
#import "../photos/PhotoTests.js"
#import "../nike/NikeTests.js"
#import "../other/wifi/WiFiTests.js"
#import "../springboard/AssistantTests.js"
#import "../setup/SetupTests.js"

test.testName = "ExecuteTest"
if (ARGV && (ARGV.length > 0)) test.main = eval(ARGV.shift());
test.argv = ARGV;

test.execute();