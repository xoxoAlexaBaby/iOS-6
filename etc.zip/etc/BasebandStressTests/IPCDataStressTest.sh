#!/bin/sh

#################################################################################################
#                                                                                               #
#   ScriptName: IPCDataStressTest_v25.sh                                                        #
#                                                                                               #
#   Usage:      nohup <path_to_Script>/IPCDataStressTest_v26.sh [-Option <optarg>] [ ... ] &    #
#                                                                                               #
#   Purpose:    To run stress tests on the device stressing the IPC. The script keeps running   #
#               Data downloads, make calls, Send/Receive SMS continuously until the Iterations  #
#               specified.                                                                      #
#               The purpose of the script is to ensure the stability of the Baseband/AP builds  #
#                                                                                               #
#   Author:     Jerome Jesu                                                                     #
#   Contact:    jesu@apple.com                                                                  #
#   Version:    v27d_ALL                                                                        #
#                                                                                               #
#   Copyright   2010 Apple. All rights reserved.                                                #
#################################################################################################

SCRIPTS_DIR="/usr/local/etc/BasebandStressTests/"
scriptname=`basename $0`
source $SCRIPTS_DIR/config.sh

usage()
{
	echo "\nUSAGE:   $0 [ -option <option_arg> ] [ -option ] [ ... ] &"
	echo " \t\t <DevicePhNumber>  --  Phone number of the Stress Test DUT."
	echo "\n $0 -OPTIONS <option arg>: Short info"
	echo "  -h <HOLD TIME in seconds> :  Call interval time, \tDefault - 15s"
	echo "  -i <number of Iterations> :  Total Iterations, \tDefault - 1500"
	echo "  -n <Loop Back Number>     :  Loopback Phone number, \tDefault - +14089748874"
	echo "  -l <sms Loop Back Number> :  SMS Phone Number, \tDefault - +11111111111"
	echo "  -j <SSID>                 :  Specify SSID, \t\tDefault - CSIQA"
	echo "  -p <WEP Key>              :  Specify WEP key, \tDefault - 123456789a"
	echo "  -u                        :  Upload Logs/Stats, \tDefault - DISABLED"
	echo "  -g                        :  Enable Locmon, \t\tDefault - DISABLED"
	echo "  -m                        :  Enable MultiRAB, \tDefault - DISABLED"
	echo "  -s                        :  SMS Failure Logging, \tDefault - DISABLED"
	echo "  -w                        :  Disable Sleep Cycling,\tDefault - Enabled"
	echo "  -d                        :  Data Download Failure Logging \tDefault -  DISABLED"
	echo "  -a                        :  Additional Logging Enabled, \tDefault - Disabled."
	echo "  -t                        :  Log Top output/Memory Dumps, \tDefault - Disabled."
	echo "  -k                        :  Disable Logs Uploading with -u option.\n"
}


flag=0
source $SCRIPTS_DIR/Defaults.sh

IPCVERSION=" ######## Version:    IPCStressTestScripts_v25/$scriptname, $VERSION_PREFIX."
scriptname=`basename $0 | perl -lne 's/[.]//; s/sh//; print'`
scriptname="${scriptname}_${VERSION_PREFIX}"
echo $IPCVERSION $scriptname

echo " ****** LOOPS  -- $LOOPS."
echo " ****** Number -- $LOOP_BACK_NUMBER."
echo " ****** HOLD   -- $CALL_INTERVAL.\n\n"
echo " ****** Phone Number used for Loop-Back SMS --- $SMS_NUMBER ####"


##########################################################################
#################### START EXECUTING STRESS TESTS  #######################
##########################################################################

source $SCRIPTS_DIR/TestCases.sh
source $SCRIPTS_DIR/printStatistics.sh
source $SCRIPTS_DIR/uploadStatsLogs.sh
source $SCRIPTS_DIR/dumpingLogs.sh

if [ $additionalLoggging -eq 1 ] && [ -e /$SCRIPTS_DIR/getMemoryStatus.sh ] &&  [ -e /$SCRIPTS_DIR/getTopOutput.sh ]; then
	nohup $SCRIPTS_DIR/getTopOutput.sh &
	#nohup $SCRIPTS_DIR/getMemoryStatus.sh &
fi

#if [ $additionalLoggging -eq 1 ] && [ -e /$SCRIPTS_DIR/setCommandsOnReset.sh ]; then 
#	nohup $SCRIPTS_DIR/setCommandsOnReset.sh &
#	sleep 1
#fi

if [ "$noIdleSleep" ]; then
	nohup /usr/bin/pmset noidle &
fi

getBuildVersions
SUFFIX1=`echo $DEVICENAME | perl -lne '($s,$m,$H,$d,$M,$Y,$D) = localtime(); $Y += 1900; $M++; printf ("ipc_%s_Stats-%02d%02d-%02d%02d",$_,$M,$d,$H,$m); ' `
SUFFIX2=`echo $DEVICENAME | perl -lne '($s,$m,$H,$d,$M,$Y,$D) = localtime(); $Y += 1900; $M++; printf ("ipc_%s_Crashes-%02d%02d-%02d%02d",$_,$M,$d,$H,$m);'`
SUFFIX3=`echo $DEVICENAME | perl -lne '($s,$m,$H,$d,$M,$Y,$D) = localtime(); $Y += 1900; $M++; printf ("LOGS_%s-%02d%02d-%02d%02d",$_,$M,$d,$H,$m);'`
ResultsFile="/var/root/$SUFFIX1.csv"
CsiLogsFile="/var/root/$SUFFIX2.csv"
LOGSFILE="/var/root/$SUFFIX3.log"
rm -r $csiLogsDir/ "RemovedLogs/" Upload* Download* Data* Call* Sms*

echo "START_TIME, CURRENT_TIME, IMEI, DEVICE_NAME, AP_BUILD, BB_BUILD, ITERATIONS, Total BB RESETS, Total_CALLS, Total_SMS, CALL_DROPS, CALL_FAILURES, FTOs, Download_Attempts, Download Pass, Download Fails, DataFailPercent, AvgDownloadDataRate, Upload_Attempts, AvgUploadDataRate, CallFails_CT, SMSFails_CT, START_TIME(s), CURRENT_TIME(s), RUN_TIME(s), FirstResetTime(s), D3, PDPActAttempts, PDPActFAIL, UDID, RUN_TIME (Hours), ScriptName, HARDWARE, SERIAL, Crash Summary, Target, PHONE_NUMBER, SNUM, MMS_COUNT, MMS_FAIL, " >> $ResultsFile


UploadedLogs="$logsDir/UploadedLogs/"
mkdir $csiLogsDir/
mkdir $UploadedLogs/
rm /Library/Logs/CrashReporter/Power*

startTime=`date "+%s"`
firstResetTime=$startTime
tStartTime=`date -r $startTime | cut -c5-19`
lastStatsUploadTime=`date "+%s"`
lastLogsUploadTime=$lastStatsUploadTime

# 1a.  START LOCMON IN THE BACKGROUND
if [ "$EnableLocmon" ]; then startLocmon; fi


while [ $dcount -lt $LOOPS ]
do
		((dcount++)) 
		((count++))
		loopStartTime=`date "+%s"`
		
		echo "\n\n  ################### Begining Iteration - $dcount ####################\n"
		echo "\n\n\n  ################### Begining Iteration - $dcount ####################\n\n" >> DownloadStressTest.txt		
		date
		getRegistrationStatus
		

		# 1a.  RE-START locmon after 25 iterations ONLY IF locmon is NOT running
		if [ "$EnableLocmon" ] && [ $(($dcount % 25)) -eq 0 ]; then  restartLocmonIfStopped; fi
		
		
		#  1b.  Downloading 1 MB Data for 1st time
		echo `date` ": uploadDownloadData  - $dcount"
		Repetition=2;
		uploadDownloadData   $Repetition   $weblink1   30   1
		#DownloadData $Repetition $weblink1 1
		sleep 10; DownloadData $Repetition $weblink0 1_1
		sleep 10; DownloadData $Repetition $weblink0 1_2
		sleep 7;  DownloadData $Repetition $weblink0 1_3
		UploadData1
		sleep 5
		
		
		#  1c.  Sleep
		if [ $DoSleep -eq 1 ]; then 
			sleepInterval=$((RANDOM % 20 + 5))
			runSleepCycler 1 $sleepInterval; 
		else 	
			#${TOOLS_DIR}/DataContext -c 0 down >> DataContextStatus.txt;
			sleep 10
		fi
		
		
		
		
		#  2a. Simultaneous Uploads and Downloads
		echo `date` ": uploadDownloadData  - $dcount"
		Repetition=2;
		uploadDownloadData   $Repetition   $weblink2   60   2
				

		#  2b. Sleep
		if [ $DoSleep -eq 1 ]; then 
			sleepInterval=$((RANDOM % 20 + 5))
			runSleepCycler 2 $sleepInterval; 
		else  
			#${TOOLS_DIR}/DataContext -c 0 down >> DataContextStatus.txt;
			sleep 5
		fi	


		#  2c. Getting TOP output
		if [ $(($dcount % 25)) -eq 0 ]; then  
				echo `date` ": ******  Capturing output of TOP to look for issues that we don't know" >> top_output_$DEVICENAME.txt
				date >> top_output_$DEVICENAME.txt
				top -o -cpu -l 10 >> top_output_$DEVICENAME.txt
				echo "*********************************************************\n" >> top_output_$DEVICENAME.txt
				cp top_output_$DEVICENAME.log /Library/Logs/CrashReporter/
				leaks -exclude _dyld_start CommCenter >> Leaks_${dcount}.txt
				sleep 900; 				
		fi
		
				
		#  3a. Downloading 1 MB Data for 3rd time
		Repetition=1
		echo `date` ":  Data Download - $dcount"
		DownloadData $Repetition $weblink3 3
		sleep 10
		DownloadData $Repetition $weblink1 3
		sleep 10
		UploadData  1



		#  3b. Sleep
		if [ $DoSleep -eq 1 ]; then 
			sleepInterval=$((RANDOM % 20 + 5))
			runSleepCycler 3 $sleepInterval; 
		else
			#${TOOLS_DIR}/DataContext -c 0 down >> DataContextStatus.txt
			sleep 2
		fi		
		

		#  4a. PDP Activation/Deactivation
		echo `date` ":  Datacontext up/down Mini STRESS Test:" ; 
		echo `date` ": ***** PDP Up/Down Stress Iteration - $dcount." >> DataContextStatus.txt		
		pdpcount=0
		sleepCount=4
		while [ $pdpcount -lt 5 ]; do
			echo `date` ": Activating Data Context"
			activatePDPContext 0
			((sleepCount++))
			sleep 5
			if [ $HARDWARE == "K48" ]; then
				echo `date` ": Bringing down DataContext"
				${TOOLS_DIR}/DataContext -c 0 down >> DataContextStatus.txt
				sleep 10
			fi
			((pdpcount++))
		done
		sleep 5
		
		
		#  4b. Sleep
		if [ $DoSleep -eq 1 ]; then 
			sleepInterval=$((RANDOM % 30 + 5))
			runSleepCycler 3 $sleepInterval; 
		else
			#${TOOLS_DIR}/DataContext -c 0 down >> DataContextStatus.txt
			sleep 2
		fi		



		#  5a. Log the Current System time in seconds	 	
		curTime=`date "+%s"`
		tcurTime=`date -r $curTime | cut -c5-19`
		
		# Time take for the current loop
		curLoopTimeTaken=$(($curTime - $loopStartTime))
		
		# 5b.  Check if the timer expired to start printing/Dumping out the logs.
		checkTimeForUploadingStats=$(($curTime - $lastStatsUploadTime))
		checkTimeForUploadingLogs=$(($curTime - $lastLogsUploadTime))		
		echo `date` ": \n ********* Current Time = $tcurTime, $curTime; "
		echo " Loop Time = $curLoopTimeTaken; Loop StartTime = $loopStartTime"
		echo " Last UpLoad Time: STATS = $lastStatsUploadTime, LOGS = $lastLogsUploadTime;"
		echo " Time since last Stats upload = $checkTimeForUploadingStats;"
		echo " Time since last Logs upload  = $checkTimeForUploadingLogs;\n"
				
		
		#  5c. Get Registration Status from CT Monitor
		getRegistrationStatus


		#  5d.  Generate STATS and upload them if necessary.
		if [ $checkTimeForUploadingStats -ge $STATS_INTERVAL ] || [ $dcount -eq $LOOPS ]; then
			 
			# print Statistics to the Results file
			echo `date` ": Printing Stats:"
			printIPCStatistics $startTime $curTime $dcount
			cp $LOGSFILE /Library/Logs/CrashReporter/
						
			if [ "$UPLOAD" ] ;  then 
				echo `date` ": ******** Uploading Stats to the Server: ( $checkTimeForUploadingStats -- LastLogTime - $lastStatsUploadTime.)\n"
				echo `date` ": _____$dcount UPLOADING STATS_____"  >> $LOGSFILE
				uploadStats			
			fi			
			lastStatsUploadTime=`date "+%s"`
		fi
		
		
		if [ $checkTimeForUploadingLogs -ge $LOG_INTERVAL ] || [ $dcount -eq $LOOPS ]; then
			
			#  5d. Compress logs
			echo `date` ": _____$dcount COMPRESS BASEBAND LOGS_____"  >> $LOGSFILE
			echo `date` ": perl $SCRIPTS_DIR/compressLogs.pl"
			perl $SCRIPTS_DIR/compressLogs.pl
			
			
			#  5f. Upload LOGS if necessary
			if [ "$UPLOAD" ]  &&  [ $disableLogsUpload -eq 0 ]; then 
				echo `date` ": ******** Uploading LOGS to the Server: ( $checkTimeForUploadingStats -- LastLogTime - $lastStatsUploadTime.)\n"
				echo `date` ": _____$dcount UPLOADING LOGS_____"  >> $LOGSFILE
				uploadLogs;
				lastLogsUploadTime=`date "+%s"`
				#${TESTCT} -l "Dump state for AWD"
			fi
		fi
		

		if [ -e /$SCRIPTS_DIR/WiFiSettings.sh ]; then
			echo `date` ":  WiFiSettings.sh file is present. Getting the values.";
			source $SCRIPTS_DIR/WiFiSettings.sh;
		fi
		

done
