#!/usr/local/bin/scripter -uiautomation YES -f

#import "UIAAppStressInit.js"
#import "../../libs/SpringBoard.js"
#import "../../libs/HarnessUtility.js"
#import "UIAAppStressLibrary.js"
#import "AppStoreStress.js"
#import "CalculatorStress.js"
#import "CalendarStress.js"
#import "CameraStress.js"
#import "ClockStress.js"
#import "ContactsStress.js"
#import "iPodStress.js"
#import "MailStress.js"
#import "NotesStress.js"
#import "MessagesStress.js"
#import "PhoneStress.js"
#import "MapsStress.js"
#import "SafariStress.js"
#import "SpringBoardStress.js"
#import "StocksStress.js"
#import "SystemStress.js"
#import "WeatherStress.js"
#import "YouTubeStress.js"

TESTS = new Array()

// Mail stress has to be first, to set up accounts
if ((typeof mailStress != 'undefined') && springboard.displaysApp(mail)) {
	TESTS.push(new StressTestArea("Mail", mailStress, 8));
}

if ((typeof appstoreStress != 'undefined') && springboard.displaysApp(appstore)) {
	TESTS.push(new StressTestArea("AppStore", appstoreStress, 3));
}
if ((typeof audioStress != 'undefined') && springboard.displaysApp(audio)) {
	TESTS.push(new StressTestArea("Audio", audioStress, 4));
}
if ((typeof calendarStress != 'undefined') && springboard.displaysApp(calendar)) {
	TESTS.push(new StressTestArea("Calendar", calendarStress, 3));
}
if ((typeof calculatorStress != 'undefined') && springboard.displaysApp(calculator)) {
	TESTS.push(new StressTestArea("Calculator", calculatorStress, 2));
}
if ((typeof cameraStress != 'undefined') && springboard.displaysApp(camera)) {
	TESTS.push(new StressTestArea("Camera", cameraStress, 3));
}
if ((typeof clockStress != 'undefined') && springboard.displaysApp(clock)) {
	TESTS.push(new StressTestArea("Clock", clockStress, 2));
}
if ((typeof contactsStress != 'undefined') && springboard.displaysApp(addressbook)) {
	TESTS.push(new StressTestArea("Contacts", contactsStress, 6));
}
if ((typeof mapsStress != 'undefined') && springboard.displaysApp(maps)) {
	TESTS.push(new StressTestArea("Maps", mapsStress, 6));
}
if ((typeof messagesStress != 'undefined') && springboard.displaysApp(messages)) {
	TESTS.push(new StressTestArea("Messages", messagesStress, 3));
}
if ((typeof notesStress != 'undefined') && springboard.displaysApp(notes)) {
	TESTS.push(new StressTestArea("Notes", notesStress, 3));
}
if ((typeof phoneStress != 'undefined') && springboard.displaysApp(phone)) {
	TESTS.push(new StressTestArea("Phone", phoneStress, 9));
}
if ((typeof safariStress != 'undefined') && springboard.displaysApp(safari)) {
	TESTS.push(new StressTestArea("Safari", safariStress, 11));
}
if ((typeof stocksStress != 'undefined') && springboard.displaysApp(stocks)) {
	TESTS.push(new StressTestArea("Stocks", stocksStress, 1));
}
if ((typeof videoStress != 'undefined') && springboard.displaysApp(video)) {
	TESTS.push(new StressTestArea("Video", videoStress, 4));
}
if ((typeof weatherStress != 'undefined') && springboard.displaysApp(weather)) {
	TESTS.push(new StressTestArea("Weather", weatherStress, 1));
}
if ((typeof youtubeStress != 'undefined') && springboard.displaysApp(youtube)) {
	TESTS.push(new StressTestArea("YouTube", youtubeStress, 7));
}

// these are always run
TESTS.push(new StressTestArea("System", systemStress, 8));
TESTS.push(new StressTestArea("SpringBoard", springboardStress, 3));
	
// main execution section

function usage()
{
	system.println("usage: AppStress.js [-e|-d] [--time <seconds>|--iterations <number>] <test1> <test2>");
	system.println("	--disable	Runs all tests but tests passed in");
	system.println("	--enable	Runs only tests passed in");
	system.println("	--time <seconds>	Number of seconds to run test.  This is the minumum amount of time.");	
	system.println("	--iterations <number>	Number of times to run test.  This is the minumum amount of iterations.");	
	system.println("	--seed <number>	Random number seed to use for test.");	
	system.println("	--haltOnWarning Stops the test from running if a warning is encountered.");
	system.println("	--scripterMemoryThreshold Stops the test from running if a scripter memory usage exceeds this value.");
	system.println("	--disableSetupHalt If test setup fails, the test will keep going.")
	system.println("	Available Stress Areas:");
	for(var i = 0; i < tests.length;i++){
		var test = tests[i];
		system.println("\t\t" + test.name);
	}
}

function ProcessArguments(args)
{
	this.tests = new Object();
	
	for(var i = 0; i < args.length; i++ ){		
		if((args[i] == "-h") || (args[i] == "--help")){
			this.error = " ";
			return;
		}else if(args[i] == "--time"){
			if( (++i) < args.length ){
				this.testTime = args[i];
			}else{
				this.error = "--time requires <seconds> argument";
				return;
			}
		}else if( args[i] == "--iterations"){
			if( (++i) < args.length ){
				this.iterations = args[i];
			}else{
				this.error = "--iterations requires <number> argument";
				return;
			}
		}else if( args[i] == "--seed"){
			if( (++i) < args.length ){
				this.seed = parseInt(args[i]);
			}else{
				this.error = "--seed requires <number> argument";
				return;
			}
		}else if( args[i] == "--enable"){
			if( this.mode ){
				this.error = "--enable cannot be used with --disable";
				return;
			}
			this.mode = "enable";
		}else if( args[i] == "--disable"){
			if( this.mode ){
				this.error = "--disable cannot be used with --enable";
				return;
			}
			this.mode = "disable";
		}else if( args[i] == "--haltOnWarning"){
			this.haltOnWarning = true;
		}else if ( args[i] == "--scripterMemoryThreshold"){
			if( (++i) < args.length ){
				this.scripterMemoryThreshold = parseInt(args[i]);
			}else{
				this.error = "--scripterMemoryThreshold requires <number> argument";
				return;
			}
		}else if ( args[i] == "--disableSetupHalt") {
			this.disableSetupHalt = true;
		}
		else{
			// Add test areas
			this.tests[args[i]] = true;
		}	
	}
}

function main() {
	var weightedTests = new Array();
	var options = new ProcessArguments(ARGV);
	var startSeed;
	var iterations = 0;
	var startTime;
	var endTime;
	var actualTime;
	var wifiName;
	var wifiPassword = 'basestation';
	var wifiCount;
	var wlText;
	var result;

	if( options.error ){
		system.println(options.error);
		usage();
		return;
	}
	
	if( options.seed ){
		topLevelRandom.seed = options.seed;
	} else {
		var storedSeed = system.getDefault(gPlistID, "Seed");
		if (storedSeed) topLevelRandom.seed = storedSeed;
	}
	
	if (options.testTime) {
		var startDateTime = system.getDefault(gPlistID, "startTime");
		
		if (startDateTime) {			
			startTime = new Date(startDateTime);
		} else {
			startTime = new Date();
			system.setDefault(gPlistID, "startTime", startTime.getTime());
		}
	} else {
		startTime = new Date();
	}
	
	UIALogger.logMessage(harness_getDeviceInfo());
	
	try {
		var nameFile = new File(gWifiNamePath, "r");
		var nameLen;
		
		wifiName = nameFile.read();
		wifiName = wifiName.substring(0, wifiName.length - 1);
	}
	catch (e) {
		UIALogger.logError("Unable to read wifi network name -- using backup.");
	}
	
	if (!wifiName) { 
		wifiName = gWifiBackupName;
		wifiPassword = gWifiBackupPassword;
	}
	
	UIALogger.logDebug("using wifi network: [ " + wifiName + " ]");
	
	gAppStressData = new TestData(gAppStressDataPath);
	gAppStressData.markExecutionStart();
	
	// so we don't loop over the same test in the case of a crash in scripter
	if (gAppStressData.dataForKey("ExecutionCount") > 1) {
		UIALogger.logMessage("The last seed was " + topLevelRandom.seed + ".");
		topLevelRandom.randomInteger(0,0);
	}
	
	UIALogger.logStart("Starting Stress: The seed is " + topLevelRandom.seed + " (execution " + gAppStressData.dataForKey("ExecutionCount") + ")");

	startSeed = topLevelRandom.seed;
	
	var scripterID;
	if (options.scripterMemoryThreshold) {
		// get scripter's pid and generate scripters processID for use in warnOnAppMemoryUsage
		for(scripterID in system.process) {
			if (scripterID.match(/scripter/)) break;
		};
		if (scripterID) {
			UIALogger.logMessage("ScripterID: " + scripterID);
		} else {
			UIALogger.logError("Failed to determine scripter's pid!");
			return;
		}
	}
	
	// clear any legacy alerts
	clearAlerts();
	
	// unlock the screen
	UIATarget.localTarget().unlockScreenIfNecessary(gDefaultPasscode);

	// execute setup function for all tests
	for (var i=0; i < TESTS.length; i++) {
		var currentTest = TESTS[i];
		var result = false;
		
		if( (options.mode == "enable") && !(options.tests[currentTest.name]) )
			continue;
		else if( (options.mode == "disable") && (options.tests[currentTest.name]))
			continue;

		try {
			UIALogger.logMessage("Running setup for " + currentTest.name);
			if (currentTest.test.setup() == false) {
				if (!options.disableSetupHalt) {
					UIALogger.logError("setup method for " + currentTest.name + " failed.");
					UIALogger.logMessage("Run with --disableSetupHalt to continue without stopping on setup failure.");
					system.exit(1);
				}
			}
		}
		catch(e) {
			UIALogger.logError(currentTest.name + ": caught setup exception:" + e);
			system.exit(1);
		}
	}
	
	// create a list of weighted tests
	// tests with a greater weight will be run more frequently
	for(var testIndex = 0; testIndex < TESTS.length; testIndex++){
		var test = TESTS[testIndex];
			
		// Only include enabled tests in our test list
		if( (options.mode == "enable") && !(options.tests[test.name]) )
			continue;
		else if( (options.mode == "disable") && (options.tests[test.name]))
			continue;
				
		// Add the test to the weighted test array
		for(var j = 0; j < test.weight; j++){
			weightedTests.push(testIndex);
		}
	}
	
	var warningsFile = system.readObjectFromDisk(gAppStressWarningPath);
	
	if( warningsFile && (warningsFile["version"] == 3) )
		loadWarningsFromDictionaries(warningsFile["warnings"]);
		
	var utils = system.getDefault(gPlistID, "utilities");
	if (!utils) {
		utils = new Array("/usr/bin/top -l 1 -opid -stats pid,command,time,threads,ports,mregs,rprvt,rshrd,rsize,vsize");
		system.setDefault(gPlistID, "utilities", utils);
	};

	while(1){
		// set up for the next test area
		system.sleep(2);
		clearAlerts();
		
		// check/reconnect wifi
		// commented out for Phoenix no WiFi run
//		setWifi(wifiName, wifiPassword, gWifiBackupName, gWifiBackupPassword);
		
		// clear the default passcode if it was set
		settings.launchIfNotActive();
		try {
			settings.turnPasscodeOff(gDefaultPasscode);
		}
		catch (e) {
			UIALogger.logError("Unable to turn off default passcode.");
		}

		// Pick a random area
		// To add a test, see the TESTS array above

		try {
			var seedUsed = topLevelRandom.seed;
			var weightedIndex = topLevelRandom.randomInteger(0,weightedTests.length-1);
			var testIndex = weightedTests[weightedIndex];
			var test = TESTS[testIndex];
			
			system.setDefault(gPlistID, "Seed", seedUsed);
				
			// Run test
			UIALogger.logStart("Running " + test.name);
			UIALogger.logMessage("To start tests from this position, run again with --seed " + seedUsed);
			system.setRandomSeed(topLevelRandom.seed);
			
			test.runArea();

			gAppStressData.archive();
			UIAUtility.runUtilities();	
		}
		catch(e) {
			UIALogger.logError("Catching an error that wasn't caught by an individual test: " + e);
		}
		system.drain();
		iterations++;
		
		// Stop the tests if we have done the iterations requested
		if( options.iterations && (iterations >= options.iterations) ){
			UIALogger.logMessage("Stopping test after " + iterations + " iterations");
			break;
		}
		
		endTime = new Date();
	    actualTime = (endTime.getTime() - startTime.getTime())/1000;
		
		// checkForWarnings makes calls that are not supported on the Simulator
		if(system.isOnHardware() && checkForWarnings(startTime,startSeed, options.haltOnWarning) && options.haltOnWarning){
			UIALogger.logError("Stopping test after encountering warnings.");
			UIAUtility.logToolOutput("/bin/launchctl unload /var/root/com.apple.AppStress.plist", 10);
			break;
		}
		
	    if( actualTime > options.testTime ){
	    	UIALogger.logMessage("Stopping test after " + actualTime + " seconds");
			system.setDefault(gPlistID, "startTime", null);
			UIAUtility.logToolOutput("/bin/launchctl unload /var/root/com.apple.AppStress.plist", 10);
	    	break;
	    }
	    
		if(options.scripterMemoryThreshold && warnOnAppMemoryUsage(scripterID, options.scripterMemoryThreshold)) {
	    	UIALogger.logMessage("Exiting script after exceeding scripter memory threshold");
			system.exit(1);
			break;
		}
    }
}

main();