#This script will check the WiFi connection between Wireless Router and the Internet for each sleep/wake
#TThree argument: SSID, WoW (1/0, default is 0, which means test with WoW disabled) and URL (URL is optional, default is www.google.com
#Script will check the SSID, ping the router IP address, and ping internet URL address

#!/bin/sh -x

SLEEP=10
AUTOJOIN_WAITTIME=60
URL="www.google.com"
COUNT=1

pushd /usr/local/bin/

if [ "$1" != "" ]; then
	SLEEP=$1
fi

echo "This test will start ping $SLEEP seconds after turn WiFi back on"

while true; do
	mobilewifitool -- device power -i en0 0
	sleep 5
	mobilewifitool -- device power -i en0 1
	sleep $SLEEP
	ping -c 5 -t 5 $URL
	if [ 0 -ne $? ]; then
		ping_result="FAIL"
		echo "dump apple80211 --ssid=m to syslog"
		apple80211 --ssid=m
		break;
	fi
	sleep 2
	echo "Completed cycle $COUNT"
	echo
	echo
	((COUNT++))
done

popd
