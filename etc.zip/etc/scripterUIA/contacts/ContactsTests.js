#import "./Contacts.js"
#import "../libs/PHTesting.js"

//----------------------------------------------------------------------------------------
//	Function: contactsTest_newContact
//		Test to add a new contact. 
//
//	Parameters: 
//		company (string) - company of the new contact
//		.. or ..
//		firstName (string) - first name of the new contact
//		lastName (string) - last name of the new contact
//
//	Returns: 
//		1 if the test passes
//		0 if the test fails
//----------------------------------------------------------------------------------------
function contactsTest_newContact() {

	var options;
	
	if (this.argv.length < 1) {
		UIALogger.logError(arguments.callee.name + ": No name or company specified.");
		return 64;		
	}
	
	var textToValidate;
	if (this.argv.length == 1) { 
		var company = this.argv[0];
		textToValidate = company;
		options = {company:company};
	} else {
		var firstName = this.argv[0];
		var lastName = this.argv[1];
		textToValidate = firstName + " " + lastName;
		options = {firstName:firstName, lastName:lastName};
	}
	
	if (this.argv.length > 2) { 
		var company = this.argv[2];	
	}
	
	addressbook.getToContactsList();
	
	//getting the no. of contacts with the same name
	addressbook.searchForContact(textToValidate);
	var dupCount = addressbook.searchResultsTable().cells().withName(textToValidate).length;
	UIALogger.logMessage(dupCount + " instance(s) of '" + textToValidate + "' found.");
		
	UIALogger.logMessage("Adding contact...");
	addressbook.addContact(options);
	addressbook.getToContactsList();
	
	UIALogger.logMessage("Checking for contact '" + textToValidate +"'");
	addressbook.getToContactsList();
	addressbook.searchForContact(textToValidate);
	var matches = addressbook.searchResultsTable().cells().withName(textToValidate);
	//wait for the cell to go away
	if (!matches[dupCount+1].isValid()) 
		UIALogger.logWarning("Table cell did not come up");
	
	//verification
	var updatedDupCount = matches.length;
	if (updatedDupCount != (dupCount+1)) {
		this.testError = updatedDupCount + " instance(s) of '" + textToValidate + "' exist after deleting.";
		UIALogger.logError(this.testError);
		return this.testResult = 0;
	}
	
	UIALogger.logMessage("New contact successfully created");	
	return this.testResult = 1;

}

//----------------------------------------------------------------------------------------
//	Function: contactsTest_selectContact 
//		Test to select an existing contact. 
//
//	Parameters: 
//		company (string) - company of the exisiting contact
//		.. or ..
//		firstName (string) - first name of the exisiting contact
//		lastName (string) - last name of the exisiting contact
//
//	Returns: 
//		1 if the test passes
//		0 if the test fails
//----------------------------------------------------------------------------------------
function contactsTest_selectContact() {
	
	if (this.argv.length < 1) {
		UIALogger.logError(arguments.callee.name + ": No name or company specified.");
		return 64;		
	}
	
	if (this.argv.length == 1) { 
		var contact = this.argv[0];
	} else {
		var contact = this.argv[0] + " " + this.argv[1];
	}
	
	addressbook.getToContactsList();
	addressbook.selectContact(contact);
	UIATarget.localTarget().delay(1); //give the script a second to change tables
	
	var isInContactCard = false;
	if (UIATarget.localTarget().model() == 'iPad') 
		isInContactCard = addressbook.mainWindow().staticTexts()[contact].isValid()
	else 
		isInContactCard = addressbook.mainWindow().tableViews().firstWithPredicate("ANY staticTexts.name == '" + contact + "'").isValid();
	if (!isInContactCard) {
		this.testError = "Could not verify the contact card for '" + contact + "'";
		UIALogger.logError(this.testError);
		return this.testResult = 0;
	}
	return this.testResult = 1;
}

//----------------------------------------------------------------------------------------
//	Function: contactsTest_deleteContact 
//		Test to delete an existing contact. 
//
//	Parameters: 
//		company (string) - company of the exisiting contact
//		.. or ..
//		firstName (string) - first name of the exisiting contact
//		lastName (string) - last name of the exisiting contact
//
//	Returns: 
//		1 if the test passes
//		0 if the test fails
//----------------------------------------------------------------------------------------
function contactsTest_deleteContact() {
	var dupCount;
	
	if (this.argv.length < 1) {
		UIALogger.logError(arguments.callee.name + ": No name or company specified.");
		return 64;		
	}
	
	if (this.argv.length == 1) { 
		var contact = this.argv[0];
	} else {
		var contact = this.argv[0] + " " + this.argv[1];
	}
	
	addressbook.getToContactsList();
	
	//getting the no. of contacts with the same name
	addressbook.searchForContact(contact);
	var dupCount = addressbook.searchResultsTable().cells().withName(contact).length;
	UIALogger.logMessage(dupCount + " instance(s) of '" + contact + "' found.");
	
	//selecting a contact now
	addressbook.getToContactsList();
	addressbook.selectContact(contact);
	
	addressbook.deleteContact();
	
	addressbook.getToContactsList();
	addressbook.searchForContact(contact);
	var matches = addressbook.searchResultsTable().cells().withName(contact);
	//wait for the cell to go away
	if (!matches[dupCount-1].waitForInvalid()) 
		UIALogger.logWarning("Table cell still exists");
	
	//verification
	var updatedDupCount = matches.length;
	if (updatedDupCount != (dupCount-1)) {
		this.testError = updatedDupCount + " instance(s) of '" + contact + "' exist after deleting.";
		UIALogger.logError(this.testError);
		return this.testResult = 0;
	}
	UIALogger.logMessage("Contact deleted.");
	addressbook.getToContactsList();
	
	return this.testResult = 1;
}

//----------------------------------------------------------------------------------------
//	Function: contactsTest_addNewPhone 
//		Test to add a new phone number to an existing contact. 
//		Assumes that addressbook is running and the the contact info screen is being 
//		displayed.
//
//	Parameters: 
//		phoneNumber (string) - the phone number that needs to be added
//		numberType (string) - the label/type of the new number (e.g. 'home', 'work', etc.)
//
//	Returns: 
//		1 if the test passes
//		0 if the test fails
//----------------------------------------------------------------------------------------
function contactsTest_addNewPhone() {
	
	if (this.argv.length < 2) {
		UIALogger.logError("Phone number and type not specified.");
		return 64;		
	}
	
	var phoneNumber = this.argv[0];
	var numberType = this.argv[1];
	
	try {
		addressbook.editContactInfo([{type:"Phone", value:phoneNumber, label:numberType}]);

		// generate a regex to list of all the ui elements that contain the numbers for this phone number
		// allow formatting characters betweeen the digits but maintain the ordering
		var phoneNumberRegExp = "[\+\(\) ]*" + phoneNumber.split("").join("[\-\(\) ]*");
		var phoneNumberCell = addressbook.infoTable().cells().firstWithPredicate("name == '" + numberType + "' and value matches '" + phoneNumberRegExp + "'");
		if (!phoneNumberCell.isValid()) throw new Error("Could not find expected phone number");
		
		return this.testResult = 1;
	} catch(e) {
		
		UIALogger.logError(e.message);
		this.testError = e.message;
		
		UIALogger.logError("Could not add the phone number -- will try to go back to the info view");
		var cancelButton = addressbook.controlButtonWithName("Cancel");
		if (cancelButton.isValid()) {
			UIATarget.localTarget().tap(cancelButton.rect()); //might also get out of popovers
			UIATarget.localTarget().delay(1);
			cancelButton = addressbook.controlButtonWithName("Cancel");
			if (cancelButton.isValid())  {
				cancelButton.tap();
				UIATarget.localTarget().delay(1);
			}
		}
		
		return this.testResult = 0;
	}
}

//----------------------------------------------------------------------------------------
//	Function: contactsTest_addNewEmail
//		Test to add a new email address to an existing contact. 
//		Assumes that addressbook is running and the the contact info screen is being 
//		displayed.
//
//	Parameters: 
//		emailAddress (string) - the email address that needs to be added.
//		emailType (string) - the label/type of the new email (e.g. 'home', 'work', etc.)
//
//	Returns: 
//		1 if the test passes
//		0 if the test fails
//----------------------------------------------------------------------------------------
function contactsTest_addNewEmail() {
	
	if (this.argv.length < 2) {
		UIALogger.logError("Email and type not specified.");
		return 64;		
	}
	
	var emailAddress = this.argv[0];
	var emailType = this.argv[1];
	
	try {
		addressbook.editContactInfo([{type:"Email", value:emailAddress, label:emailType}]);

		//verify
		var emailAddressCell = addressbook.infoTable().cells().firstWithPredicate("name == '" + emailType + "' and value == '" + emailAddress + "'");
		if (!emailAddressCell.isValid()) throw new Error("Could not find the expected email address");
		
		return this.testResult = 1;
	} catch(e) {
		UIALogger.logError(e);
		this.testError = e.message;
		
		UIALogger.logError("Could not add the email address -- will try to go back to the info view");
		
		var cancelButton = addressbook.controlButtonWithName("Cancel");
		if (cancelButton.isValid()) {
			UIATarget.localTarget().tap(cancelButton.rect()); //might also get out of popovers
			UIATarget.localTarget().delay(1);
			cancelButton = addressbook.controlButtonWithName("Cancel");
			if (cancelButton.isValid())  {
				cancelButton.tap();
				UIATarget.localTarget().delay(1);
			}
		}
		
		return this.testResult = 0;
	}
	
	return this.testResult = 1;
}

//----------------------------------------------------------------------------------------
//	Function: contactsTest_assignRingtone 
//		Test to add a ringtone to an existing contact. 
//		Assumes that addressbook is running and the the contact info screen is being 
//		displayed.
//
//	Parameters: 
//		ringtone (string) - the ringtone that needs to be assigned to the contact
//
//	Returns: 
//		1 if the test passes
//		0 if the test fails
//----------------------------------------------------------------------------------------
function contactsTest_assignRingtone() {
	
	if (this.argv.length < 1) {
		UIALogger.logError("Ringtone not specified.");
		return 64;		
	}
	
	var ringtone = this.argv[0];
	
	addressbook.controlButtonWithName("Edit").tap();
	if (!addressbook.controlButtonWithName("Done").isValid()) UIALogger.logWarning("'Done' button did not come up");
	
	UIATarget.localTarget().pushTimeout(0.01);
	var ringtoneLabelTableCell = addressbook.infoTable().cells().firstWithPredicate("ANY elements.name == 'ringtone'");
	UIATarget.localTarget().popTimeout();
	if (!ringtoneLabelTableCell.isValid()) {
		this.testError = "'ringtone' table cell not found";
		UIALogger.logError(this.testError);
		return this.testResult = 0;
	}
	ringtoneLabelTableCell.scrollToVisible();
	ringtoneLabelTableCell.tap();
	
	UIALogger.logMessage("Selecting '" + ringtone + "' ringtone");
	var ringtoneToSelect = addressbook.mainWindow().elements()[ringtone];
	if (!ringtoneToSelect.isValid()) ringtoneToSelect = addressbook.mainWindow().tableViews()[0].elements()[ringtone]; //this is needed because Jasper views have changed
	if (!ringtoneToSelect.isValid()) {
		this.testError = "Could not find '" + ringtone + "' in the ringtones table";
		UIALogger.logError(this.testError);
		return this.testResult = 0;
	}
	ringtoneToSelect.scrollToVisible();
	ringtoneToSelect.tap();
	UIATarget.localTarget().delay(1);
	
	addressbook.controlButtonWithName("Save").tap()
	UIATarget.localTarget().delay(1);
	
	addressbook.controlButtonWithName("Done").tap();
	
	if (!addressbook.controlButtonWithName("Edit").isValid()) UIALogger.logWarning("'Edit' button did not come up");
	//verify
	var ringtoneCell = addressbook.infoTable().cells().firstWithPredicate("name == 'ringtone' and value == '" + ringtone + "'");
	if (!ringtoneCell.isValid()) {
		this.testError = "Could not find the expected ringtone";
		UIALogger.logError("Could not find the expected ringtone");
		return this.testResult = 0;
	}
	
	return this.testResult = 1;
}

//----------------------------------------------------------------------------------------
//	Function: contactsTest_dragContactsList
//		Test to drag the contacts table.
//
//	Optional Parameters: 
//		y1 (float) - the y offset of the point in the table to drag from. Note that the offset is
//			relative to the contacts table. The values can range from 0 to 1.
//		y2 (float) - the y offset of the point in the table to drag to. Note that the offset is 
//			relative to the contact table. The values can range from 0 to 1.
//		speed (float)
//
//	Usage: 
//		contactsTest_dragContactsList 0.2 0.8 0.1
//
//	Returns: 
//		1 if the test passes
//		0 if the test fails
//----------------------------------------------------------------------------------------
function contactsTest_dragContactsList() {
	
	var minNoOfCellsToValidateScroll = (UIATarget.localTarget().model() == 'iPad') ? 9 : 7;
	addressbook.getToContactsList();
	addressbook.chooseGroup("All Contacts");
	var contactsTable = addressbook.contactsListTable();
	if (!contactsTable.isValid()) { 
		this.testError = "Could not find the contacts table";
		UIALogger.logError(this.testError);
		return this.testResult = 0;
	}
	var tableValue = contactsTable.value();
	var tableInfoBeforeDrag = UIAUtility.tableInfoFromValue(tableValue);
	//tableInfoBeforeDrag.noOfCells = contactsTable.cells().length;
	
	var xOffset = 0.5;
	var y1Offset, y2Offset;
	var speed;
	
	if (this.argv.length < 1 || this.argv[0] == null || this.argv[0] == "null") {
		y1Offset = system.randomReal(0.03, 0.8);
	} else
		y1Offset = parseFloat(this.argv[0]);
	
	if (this.argv.length < 2 || this.argv[1] == null || this.argv[1] == "null") {
		y2Offset = system.randomReal(0.03, 0.8);
	} else
		y2Offset = parseFloat(this.argv[1]);
	
	if (this.argv.length < 3 || this.argv[2] == null || this.argv[2] == "null") 
		speed = system.randomReal(0.25, 5); 
	else
		speed = parseFloat(this.argv[2]);
	
	UIALogger.logMessage("Dragging from (" + xOffset + "," + y1Offset + ") to (" + xOffset + "," + y2Offset + ") at speed " + speed);
	contactsTable.dragInsideWithOptions({startOffset:{x:xOffset, y:y1Offset}, endOffset:{x:xOffset, y:y2Offset}, duration:speed});					
	UIATarget.localTarget().delay(1);
	UIALogger.logMessage("Drag from (" + xOffset + "," + y1Offset + ") to (" + xOffset + "," + y2Offset + ") completed.");
	
	if (!contactsTable.isValid()) {
		UIALogger.logWarning("Table no longer valid after dragging.");
	} else if (tableInfoBeforeDrag.noOfElements == null || tableInfoBeforeDrag.noOfElements < minNoOfCellsToValidateScroll) {
		UIALogger.logMessage("Too few contacts to validate scroll.");
	} else if (tableValue == contactsTable.value()) {
		//check if we expect the value to change
		var direction = (y1Offset < y2Offset) ? "up" : "down";
		UIALogger.logMessage("Should have dragged " + direction + ". Now, checking if we are at the top/bottom");
		var isAtTop = (tableInfoBeforeDrag.firstVisibleIndex == 1);
		var isAtBottom = (tableInfoBeforeDrag.lastVisibleIndex == tableInfoBeforeDrag.noOfElements);
		if (direction == "up" && isAtTop)
			UIALogger.logMessage("At the top of the table, so cannot drag up");
		else if (direction == "down" && isAtBottom)
			UIALogger.logMessage("At the bottom of the table, so cannot drag down");
		else {
			this.testError = "Drag did not result in a change in the table. value = " + contactsTable.value() + " old value = " + tableValue;
			UIALogger.logError(this.testError);
			return this.testResult = 0;
		}
	}
	
	if (!addressbook.isActive()) {
		this.testError = "Phone or Contacts is no longer the active application.";
		UIALogger.logError(this.testError);
		return this.testResult = 0;
	}
	return this.testResult = 1;
}

//----------------------------------------------------------------------------------------
//	Function: contactsTest_flickContactsList 
//		Test to flick the contacts table.
//
//	Optional Parameters: 
//		y1 (float) - the y offset of the point in the table to flick from. Note that the offset is
//			relative to the contacts table. The values can range from 0 to 1.
//		y2 (float) - the y offset of the point in the table to flick to. Note that the offset is 
//			relative to the contact table. The values can range from 0 to 1.
//
//	Usage: 
//		e.g. contactsTest_flickContactsList 0.2 0.8
//
//	Returns: 
//		1 if the test passes
//		0 if the test fails
//----------------------------------------------------------------------------------------
function contactsTest_flickContactsList() {

	var minNoOfCellsToValidateScroll = (UIATarget.localTarget().model() == 'iPad') ? 9 : 7;
	addressbook.getToContactsList();
	addressbook.chooseGroup("All Contacts");
	var contactsTable = addressbook.contactsListTable();

	if (!contactsTable.isValid()) {
		this.testError = "Could not find the contacts table";
		UIALogger.logError("Could not find the contacts table");
		return this.testResult = 0;
	}

	var tableValue = contactsTable.value();
	var tableInfoBeforeFlick = UIAUtility.tableInfoFromValue(tableValue);
	//tableInfoBeforeFlick.noOfCells = contactsTable.cells().length;
	var xOffset = 0.5;
	var y1Offset, y2Offset;
	
	if (this.argv.length < 1 || this.argv[0] == null || this.argv[0] == "null") {
		y1Offset = system.randomReal(0.03, 0.8);
	} else
		y1Offset = parseFloat(this.argv[0]);
	
	if (this.argv.length < 2 || this.argv[1] == null || this.argv[1] == "null") {
		y2Offset = system.randomReal(0.03, 0.8);
	} else
		y2Offset = parseFloat(this.argv[1]);
	
	UIALogger.logMessage("Flicking from (" + xOffset + "," + y1Offset + ") to (" + xOffset + "," + y2Offset + ")");
	contactsTable.flickInsideWithOptions({startOffset:{x:xOffset, y:y1Offset}, endOffset:{x:xOffset, y:y2Offset}});					
	UIATarget.localTarget().delay(1);
	UIALogger.logMessage("Flick from (" + xOffset + "," + y1Offset + ") to (" + xOffset + "," + y2Offset + ") completed.");
	
	if (!contactsTable.isValid()) {
		UIALogger.logWarning("Table no longer valid after flicking.");
	} else if (tableInfoBeforeFlick.noOfElements == null || tableInfoBeforeFlick.noOfElements < minNoOfCellsToValidateScroll) {
		UIALogger.logMessage("Too few contacts to validate scroll.");
	} else if (tableValue == contactsTable.value()) {
		//check if we expect the value to change
		var direction = (y1Offset < y2Offset) ? "up" : "down";
		UIALogger.logMessage("Should have flicked " + direction + ". Now, checking if we are at the top/bottom");
		var isAtTop = (tableInfoBeforeFlick.firstVisibleIndex == 1);
		var isAtBottom = (tableInfoBeforeFlick.lastVisibleIndex == tableInfoBeforeFlick.noOfElements);
		if (direction == "up" && isAtTop)
			UIALogger.logMessage("At the top of the table, so cannot flick up");
		else if (direction == "down" && isAtBottom)
			UIALogger.logMessage("At the bottom of the table, so cannot flick down");
		else {
			this.testError = "Flick did not result in a change in the table. value = " + contactsTable.value() + " old value = " + tableValue;
			UIALogger.logError(this.testError);
			return this.testResult = 0;
		}
	}
	
	if (!addressbook.isActive()) { 
		this.testError = "Phone or Contacts is no longer the active application.";
		UIALogger.logError(this.testError);
		return this.testResult = 0;
	}
	return this.testResult = 1;
}

// Create self tests -- this is an unnamed function, just to make sure any local variables stay in the correct context
(function() {	
	if (typeof addressbook.selfTests == 'undefined') {
		addressbook.selfTests = new Array();
	}
	
	addressbook.selfTests.push(phtCreateTest("FlickContactList", [0.026, 0.80], contactsTest_flickContactsList, "Flick contact list"));
	addressbook.selfTests.push(phtCreateTest("DragContactList", [0.80, 0.026, 1], contactsTest_dragContactsList, "Drag contact list"));
	addressbook.selfTests.push(phtCreateTest("NewContact", ["Bob", "Dylan"], contactsTest_newContact, "Add a new contact to the addressbook"));
	addressbook.selfTests.push(phtCreateTest("SelectContact", ["Bob Dylan"], contactsTest_selectContact, "Select the added contact"));
	addressbook.selfTests.push(phtCreateTest("AddNewPhoneNumber", ["4089619343", "home"], contactsTest_addNewPhone, "Add a phone number to the selected contact"));
	addressbook.selfTests.push(phtCreateTest("AddNewEmail", ["zimmer@something.com", "work"], contactsTest_addNewEmail, "Add an email address to the selected contact"));
	// Don't run "Assign Ringtone" tests on any version of the iPod Touch
	if (UIATarget.localTarget().model() == "iPhone") {
		addressbook.selfTests.push(phtCreateTest("AssignRingtone", ["Crickets"], contactsTest_assignRingtone, "Add a ringtone to the selected contact"));
	}
	addressbook.selfTests.push(phtCreateTest("NewContact2", ["Hello", "Kitty"], contactsTest_newContact, "Add a second new contact to the addressbook"));
	addressbook.selfTests.push(phtCreateTest("DeleteContact", ["Hello", "Kitty"], contactsTest_deleteContact, "Delete a contact from the addressbook"));
}())