/*
 Class: UIApp (nike+)
 Messages object
 */

#import "../libs/SpringBoard.js"


try { 
	
	if (typeof photobooth == 'undefined' && (UIATarget.localTarget().model() == 'iPad' && system.hasCapability("front-facing-camera"))) photobooth = UIAApp.application("Photo Booth", "com.apple.Photo-Booth"); }
catch (theError) { 
	system.println("WARNING! Failed to create object for Photo Booth : " + theError); 
}



if (typeof photobooth != 'undefined') {

	//----------------------------------------------------------------------------------------
	//	Function: getNumberOfPhotos
	//		Returns the number of photos in the photo tray
	//
	//	Parameters: 
	//		None
	//
	//	Returns: 
	//		the number of photos in the photo tray
	//	
	//	Throws:
	//		None
	//----------------------------------------------------------------------------------------			
	photobooth.getNumberOfPhotos = function getNumberOfPhotos() {
		return this.mainWindow().images()[0].scrollViews()[0].images().withPredicate("name beginswith 'Photo'").length;
	} // end photoboot.getNumberOfPhotos
	
	
	//----------------------------------------------------------------------------------------
	//	Function: returnToEffects 
	//		Return to the effects view in Photo booth
	//
	//	Parameters: 
	//		None
	//
	//	Returns: 
	//		None
	//	
	//	Throws:
	//		An error if script could not return to the effects view 
	//----------------------------------------------------------------------------------------		
	photobooth.returnToEffects = function returnToEffects() {

		var changeEffectsButton = this.toolbar().buttons().firstWithPredicate("name contains 'Effects'");
		if( this.mainWindow().elements().firstWithName("Normal").isVisible() ) {
			UIALogger.logMessage("Already in the effects selector");
			return;
		} 

        try {
            this.displayControls();
        } catch(e) {
            UIALogger.logMessage(e.message);
        }
        
        if(changeEffectsButton.isVisible()) {
        
			UIALogger.logMessage("Tapping the effects button to return to the effects selector");
			changeEffectsButton.tap();
		} 
		
		if (!changeEffectsButton.checkIsValid()) throw new Error("Could not return to the effects selector");
				
		return;
		
	} // end photobooth.returnToEffects
	
	
	//----------------------------------------------------------------------------------------
	//	Function: chooseEffect 
	//		Choose an effect supplied by the parameter
	//
	//	Parameters: 
	//		effect (string) - the name of the script to select (defaults to "Normal")
	//
	//	Returns: 
	//		None
	//	
	//	Throws:
	//		An error if the script could not choose an effect 
	//----------------------------------------------------------------------------------------			
	photobooth.chooseEffect = function chooseEffect(effect) {
		this.logElementTree();
		if (!effect) effect = "Normal";
		
		UIALogger.logMessage("Choosing " + effect + " effect");
		var effectButton = this.mainWindow().elements().firstWithName(effect);
		if (!effectButton.isValid()) throw new Error("Could not find the button to choose effect " + effect);
		UIALogger.logMessage("Tapping effect button");
		effectButton.logElementTree();
		// Workaround for <rdar://problem/8902206> Photo booth effect elements are not visible

		var xOrigin = effectButton.rect().origin.x;
		var yOrigin = effectButton.rect().origin.y;
		
		var height = effectButton.rect().size.height;
		var width = effectButton.rect().size.width;
		
		var point = {x:(xOrigin + width/2),y:(yOrigin + height/2)};
		
		UIATarget.localTarget().tap(point);
		
		
		UIATarget.localTarget().delay(1);
		return;		
	} // end photobooth.chooseEffect
	
	
	//----------------------------------------------------------------------------------------
	//	Function: chooseCamera 
	//		Choose the front or rear-facing camera
	//
	//	Parameters: 
	//		cameraDirection (string) - "Front" or "Back"
	//
	//	Returns: 
	//		None
	//	
	//	Throws:
	//		none
	//----------------------------------------------------------------------------------------				
	photobooth.chooseCamera = function chooseCamera(cameraDirection) {
		
		var cameraToggleButton = this.toolbar().buttons().firstWithName("Switch Camera");
        
		if (!cameraToggleButton.isValid()) throw new Error("Could not find the camera switcher button");
        var switcherButton = this.mainWindow().elements().firstWithPredicate("name endswith 'facing camera view'");
		var currentlyFacing = switcherButton.name().split(" ")[0];

		if (currentlyFacing != cameraDirection) cameraToggleButton.tap();
        
        switcherButton = this.mainWindow().elements().firstWithPredicate("name endswith '" + cameraDirection + " facing camera view'");
        if (!switcherButton.isVisible()) throw new Error("Tapped the camera switcher, but the camera direction did not change");
        UIATarget.localTarget().delay(3);
        return;
		
	} // end photobooth.chooseCamera
	
	
	//----------------------------------------------------------------------------------------
	//	Function: takePicture 
	//		Take a wild guess what this one does
	//
	//	Parameters: 
	//		None
	//
	//	Returns: 
	//		None
	//	
	//	Throws:
	//		an error if the picture cannot be taken
	//----------------------------------------------------------------------------------------					
	photobooth.takePicture = function takePicture() {
		var cameraButton = this.toolbar().buttons()["Take Picture"];
		if (!cameraButton.isVisible()) throw new Error("Camera Capture Button is not visible");
		cameraButton.tap();
		return;
	
	} // end photobooth.takePicture

	
	//----------------------------------------------------------------------------------------
	//	Function: deletePhoto
	//		Deletes a photo from the photo tray - the first visible image is selected for deletion
	//
	//	Parameters: 
	//		None
	//
	//	Returns: 
	//		None
	//	
	//	Throws:
	//		an error if a photo is not deleted
	//----------------------------------------------------------------------------------------						
	photobooth.deletePhoto = function deletePhoto() {
		this.displayControls();
		var numberOfPhotos = this.getNumberOfPhotos();
		if (numberOfPhotos == 0) {
			UIALogger.logMessage("No photos to delete");
			return;
		}
		UIALogger.logMessage("Number of photos before deletion: " + numberOfPhotos);
		var photoElement = this.mainWindow().images()[0].scrollViews()[0].images().firstWithPredicate("isVisible == 1");
        if (photoElement.isValid()) photoElement.tap();
		var upperleftHandCornerPoint = {x:photoElement.rect().origin.x, y:photoElement.rect().origin.y};
		UIATarget.localTarget().tap(upperleftHandCornerPoint);

		UIATarget.localTarget().delay(1);
	
		var popover = this.mainWindow().popover();
		if (!popover.isValid()) throw new Error("Could not find popover");
		var actionSheet = popover.actionSheet();

		if (!actionSheet.isValid) throw new Error("Did not find Delete button, could not delete a photo");
		actionSheet.buttons()["Delete Photo"].tap();
		
		UIATarget.localTarget().delay(5);
		if (this.getNumberOfPhotos() == numberOfPhotos) throw new Error("Did not delete any photos");
		return;
		
	} // end photobooth.deletePhoto

	
	//----------------------------------------------------------------------------------------
	//	Function: deleteAllPhotos
	//		Delete all the photos in the photo tray
	//
	//	Parameters: 
	//		None
	//
	//	Returns: 
	//		None
	//	
	//	Throws:
	//		none
	//----------------------------------------------------------------------------------------							
	photobooth.deleteAllPhotos = function deleteAllPhotos() {
		this.displayControls();
		UIALogger.logMessage("Deleting all photos");
		
		var numberOfPhotos = this.getNumberOfPhotos();
		for (var i = 0; i < numberOfPhotos; i++ ) { 
			this.deletePhoto();
		}
		
		return;
	} // end photobooth.deleteAllPhotos
	
	
	//----------------------------------------------------------------------------------------
	//	Function: displayControls
	//		Display the controls
	//
	//	Parameters: 
	//		None
	//
	//	Returns: 
	//		None
	//	
	//	Throws:
	//		an error if the controls did not appear
	//----------------------------------------------------------------------------------------								
	photobooth.displayControls = function displayControls() {
		if (!this.toolbar().isVisible()) {
			this.mainWindow().tap();
		}

		UIATarget.localTarget().delay(1);

		if (!this.toolbar().isVisible()) {
			throw new Error("Tapping main window did not display the controls");
		}
		return;
		
	} // end photobooth.displayControls
		
}
	