#!/bin/sh

#################################################################################################
#                                                                                               #
#   ScriptName: IPCStressTest_v25.sh                                                            #
#                                                                                               #
#   Usage:      nohup <path_to_Script>/IPCStressTest_v23.sh [-Option <optarg>] [ ... ] &        #
#                                                                                               #
#   Purpose:    To run stress tests on the device stressing the IPC. The script keeps running   #
#               Data downloads, make calls, Send/Receive SMS continuously until the Iterations  #
#               specified.                                                                      #
#               The purpose of the script is to ensure the stability of the Baseband/AP builds  #
#                                                                                               #
#   Author:     Jerome Jesu                                                                     #
#   Contact:    jesu@apple.com                                                                  #
#   Version:    v27                                                                             #
#                                                                                               #
#   Copyright   2010 Apple. All rights reserved.                                                #
#################################################################################################

SCRIPTS_DIR="/usr/local/etc/BasebandStressTests/"
source $SCRIPTS_DIR/config.sh

usage()
{
	echo "\nUSAGE:   $0 [ -option <option_arg> ] [ -option ] [ ... ] &"
	echo " \t\t <DevicePhNumber>  --  Phone number of the Stress Test DUT."
	echo "\n $0 -OPTIONS <option arg>: Short info"
	echo "  -h <HOLD TIME in seconds> :  Call interval time, \tDefault - 15s"
	echo "  -i <number of Iterations> :  Total Iterations, \tDefault - 1500"
	echo "  -n <Loop Back Number>     :  Loopback Phone number, \tDefault - +14089748874"
	echo "  -l <sms Loop Back Number> :  SMS Phone Number, \tDefault - +11111111111"
	echo "  -j <SSID>                 :  Specify SSID, \t\tDefault - CSIQA"
	echo "  -p <WEP Key>              :  Specify WEP key, \tDefault - 123456789a"
	echo "  -u                        :  Upload Logs/Stats, \tDefault - DISABLED"
	echo "  -g                        :  Enable Locmon, \t\tDefault - DISABLED"
	echo "  -m                        :  Enable MultiRAB, \tDefault - DISABLED"
	echo "  -s                        :  SMS Failure Logging, \tDefault - DISABLED"
	echo "  -w                        :  Disable Sleep Cycling,\tDefault - Enabled"
	echo "  -d                        :  Data Download Failure Logging \tDefault -  DISABLED"
	echo "  -a                        :  Additional Logging Enabled, \tDefault - Disabled."
	echo "  -t                        :  Log Top output/Memory Dumps, \tDefault - Disabled."
	echo "  -r                        :  To have multiple runs of same diff configs on the same day."
	echo "  -k                        :  Disable Logs Uploading with -u option.\n"
}


flag=0
echo "SCRIPT = $0"
source $SCRIPTS_DIR/Defaults.sh

scriptname=`basename $0`
IPCVERSION=" ######## Version:    IPCStressTestScripts_v25/$scriptname, $VERSION_PREFIX."
scriptUSED=`basename $0 | perl -lne 's/[.]//; s/sh//; print'`
scriptname="${scriptname}_${VERSION_PREFIX}"
echo $IPCVERSION  $scriptname  $scriptUSED  $VERSION_PREFIX

echo " ****** LOOPS  -- $LOOPS."
echo " ****** Number -- $LOOP_BACK_NUMBER."
echo " ****** HOLD   -- $CALL_INTERVAL.\n\n"
echo " ****** Phone Number used for Loop-Back SMS --- $SMS_NUMBER ####"


##########################################################################
#################### START EXECUTING STRESS TESTS  #######################
##########################################################################

source $SCRIPTS_DIR/TestCases.sh
source $SCRIPTS_DIR/printStatistics.sh
source $SCRIPTS_DIR/uploadStatsLogs.sh
source $SCRIPTS_DIR/dumpingLogs.sh

if [ $additionalLoggging -eq 1 ] && [ -e /$SCRIPTS_DIR/getMemoryStatus.sh ] &&  [ -e /$SCRIPTS_DIR/getTopOutput.sh ]; then
	nohup $SCRIPTS_DIR/getTopOutput.sh &
	#nohup $SCRIPTS_DIR/getMemoryStatus.sh &
fi

#if [ $additionalLoggging -eq 1 ] && [ -e /$SCRIPTS_DIR/setCommandsOnReset.sh ]; then 
#	nohup $SCRIPTS_DIR/setCommandsOnReset.sh &
#	sleep 1
#fi

if [ "$noIdleSleep" ]; then
	nohup /usr/bin/pmset noidle &
fi

getBuildVersions
SUFFIX1=`echo $DEVICENAME | perl -lne '($s,$m,$H,$d,$M,$Y,$D) = localtime(); $Y += 1900; $M++; printf ("ipc_%s_Stats-%02d%02d-%02d%02d",$_,$M,$d,$H,$m); ' `
SUFFIX2=`echo $DEVICENAME | perl -lne '($s,$m,$H,$d,$M,$Y,$D) = localtime(); $Y += 1900; $M++; printf ("ipc_%s_Crashes-%02d%02d-%02d%02d",$_,$M,$d,$H,$m);'`
SUFFIX3=`echo $DEVICENAME | perl -lne '($s,$m,$H,$d,$M,$Y,$D) = localtime(); $Y += 1900; $M++; printf ("LOGS_%s-%02d%02d-%02d%02d",$_,$M,$d,$H,$m);'`
ResultsFile="/var/root/$SUFFIX1.csv"
CsiLogsFile="/var/root/$SUFFIX2.csv"
LOGSFILE="/var/root/$SUFFIX3.log"
UploadedLogs="$logsDir/UploadedLogs/"
rm -r $csiLogsDir/ "RemovedLogs/" Upload* Download* Data* Call* Sms*

echo "START_TIME, CURRENT_TIME, IMEI, DEVICE_NAME, AP_BUILD, BB_BUILD, ITERATIONS, Total BB RESETS, Total_CALLS, Total_SMS, CALL_DROPS, CALL_FAILURES, FTOs, Download_Attempts, Download Pass, Download Fails, DataFailPercent, AvgDownloadDataRate, Upload_Attempts, AvgUploadDataRate, CallFails_CT, SMSFails_CT, START_TIME(s), CURRENT_TIME(s), RUN_TIME(s), FirstResetTime(s), D3, PDPActAttempts, PDPActFAIL, UDID, RUN_TIME (Hours), ScriptName, HARDWARE, SERIAL, Crash Summary, Target, PHONE_NUMBER, SNUM, MMS_COUNT, MMS_FAIL, " >> $ResultsFile

mkdir $csiLogsDir/
mkdir $UploadedLogs/
rm /Library/Logs/CrashReporter/Power*

startTime=`date "+%s"`
firstResetTime=$startTime
tStartTime=`date -r $startTime | cut -c5-19`
lastStatsUploadTime=`date "+%s"`
lastLogsUploadTime=$lastStatsUploadTime

# 1a.  START LOCMON IN THE BACKGROUND
if [ "$EnableLocmon" ]; then startLocmon; fi


while [ $dcount -lt $LOOPS ]
do
		((dcount++)) 
		((count++))
		((callCount++))
		((smsCount++))
		activationCount=0
		loopStartTime=`date "+%s"`
		
		echo "\n\n  ################### Begining Iteration - $dcount ####################\n"
		echo "\n\n\n  ################### Begining Iteration - $dcount ####################\n\n" >> DownloadStressTest.txt
		date
		getRegistrationStatus
		


		# 1a.  RE-START locmon after 25 iterations ONLY IF locmon is NOT running
		if [ "$EnableLocmon" ] && [ $(($dcount % 25)) -eq 0 ]; then  
			echo `date` ": 	Retart Locmon if not running"
			restartLocmonIfStopped; 
		fi
		
		
		# 1b.  Data Download for www.apple.com
		Repetition=1;
		echo `date` ": 	#### uploadDownloadData; DownloadData 3 times"
		uploadDownloadData   2  $weblink1   30   1
		sleep 10; DownloadData $Repetition $weblink0 1_1
		sleep 10; DownloadData $Repetition $weblink0 1_2
		sleep 7;  DownloadData $Repetition $weblink0 1_3
		sleepInterval=$((RANDOM % 20 + $SLEEPOFFSET))
		if [ $DoSleep -eq 1 ]; then 
			runSleepCycler 1 $sleepInterval;
		else 	
			sleep $sleepInterval; 
		fi


	    # 1c.  MOMT Loopback SMS-1 600+ chars
		echo `date` ": 	####	Sending 600+ chars MO SMS(1) - $smsCount..."
		sendSMS $SMS_NUMBER $smsCount $SMSSTRING1						
		sleepInterval=$((RANDOM % 20 + $SLEEPOFFSET))
		if [ $DoSleep -eq 1 ]; then runSleepCycler 2 $sleepInterval; 
		else 	sleep 10; fi



		# 1d . MAKING MO call 1
		echo `date` ": 	####	MAKING MO CALL 1 - $callCount."
		rand=`expr $RANDOM % 10`
		callTimer=`expr $rand + 20`
		makeCALL $LOOP_BACK_NUMBER $callTimer $callCount			
		sleepInterval=$((RANDOM % 20 + $SLEEPOFFSET))
		if [ $DoSleep -eq 1 ]; then 
			runSleepCycler 3 $sleepInterval; 
		else 	
			sleep 10
		fi

		
		((count++))
		((callCount++))
		((smsCount++))
		
		
		
		
		
		# 2a.  Mult-RAB Call MO + Simultaneous Upload & Download 2
		Repetition=2;
		echo `date` ": 	#### MULTI-CALLS --	MAKING MO CALL 2 - $callCount."
		MultiCalls $LOOP_BACK_NUMBER $Repetition $weblink2 $callCount 2
		sleepInterval=$((RANDOM % 20 + $SLEEPOFFSET))
		if [ $DoSleep -eq 1 ]; then  runSleepCycler 4 $sleepInterval; 
		else 	sleep $sleepInterval; fi		
		
		
		# 2b.  Collect Top output every 25 iterations
		if [ $(($dcount % 25)) -eq 0 ]; then
			tail -50000 /var/root/Library/Caches/locationd/locationd.log >> /Library/Logs/CrashReporter/locationd_${dcount}.log &	
			collectTopOutput; 
			sleepInterval=$((RANDOM % 120 + 240));
			echo `date` ": IDLE TIME:  Sleeping for $sleepInterval."
			sleep $sleepInterval;
		fi
		
			
		# 2c.   MOMT Loopback SMS 2
		echo `date` ": 	####	Sending SMS(2) - $smsCount..."
		sendSMS $SMS_NUMBER $smsCount $SMSSTRING2
		

		
		
		
		# 3a.  Downloading 1 MB Data for 3rd time
		Repetition=1;
		echo `date` ": 	DownloadData $Repetition $weblink3 3; UploadData1"
		DownloadData $Repetition $weblink3 3
		sleep 2
		UploadData1
		sleepInterval=$((RANDOM % 20 + $SLEEPOFFSET))
		if [ $DoSleep -eq 1 ]; then 
			runSleepCycler 5 $sleepInterval; 
		else 	
			sleep 10; 
		fi
				
		
		# 3b.  Bringing up Data Context
		echo `date` ":  Bringing datacontext up." ;
		((pdpAttempts++)) 
		echo `date` ": 	***** PDP Iteration - $dcount." >> DataContextStatus.txt
		activatePDPContext 0
		sleep 5;
		sleepInterval=$((RANDOM % 20 + $SLEEPOFFSET))
		if [ $DoSleep -eq 1 ]; then 
			runSleepCycler 6 $sleepInterval; 
		else 	
			sleep 10
		fi
		#echo `date` ": _____DEACTIVATE PDP - $dcount _____"  >> $LOGSFILE
		#${TOOLS_DIR}/DataContext down
		#sleep 15;
		
		
		
		
		
		# 4a.  Log the Current System time in seconds	 	
		curTime=`date "+%s"`
		tcurTime=`date -r $curTime | cut -c5-19`
		# Time take for the current loop
		curLoopTimeTaken=$(($curTime - $loopStartTime))


		# 4b. Check if the timer expired to start printing/Dumping out the logs.
		checkTimeForUploadingStats=$(($curTime - $lastStatsUploadTime))
		checkTimeForUploadingLogs=$(($curTime - $lastLogsUploadTime))
		echo `date` ": 	\n ********* Current Time = $tcurTime, $curTime;"
		echo " Loop Time = $curLoopTimeTaken; Loop StartTime = $loopStartTime"
		echo " Last UpLoad Time: STATS = $lastStatsUploadTime, LOGS = $lastLogsUploadTime;"
		echo " Time since last Stats upload = $checkTimeForUploadingStats;"
		echo " Time since last Logs upload  = $checkTimeForUploadingLogs;\n"
		
		#  4c. Get Registration Status from CT Monitor
		getRegistrationStatus


		#  4d.  Generate STATS and upload them if necessary.
		if [ $checkTimeForUploadingStats -ge $STATS_INTERVAL ] || [ $dcount -eq $LOOPS ]; then
			 
			# print Statistics to the Results file
			echo `date` ": 	Printing Stats:"
			printIPCStatistics $startTime $curTime $dcount
			cp $LOGSFILE /Library/Logs/CrashReporter/
						
			if [ "$UPLOAD" ] ;  then 
				echo `date` ": 	******** Uploading Stats to the Server: ( $checkTimeForUploadingStats -- LastLogTime - $lastStatsUploadTime.)\n"
				echo `date` ": _____$dcount UPLOADING STATS_____"  >> $LOGSFILE
				uploadStats			
			fi			
			lastStatsUploadTime=`date "+%s"`
		fi
		
		
		if [ $checkTimeForUploadingLogs -ge $LOG_INTERVAL ] || [ $dcount -eq $LOOPS ]; then
			
			# 4e. Compress logs
			echo `date` ": _____$dcount COMPRESS BASEBAND LOGS_____"  >> $LOGSFILE
			echo `date` ": 	perl $SCRIPTS_DIR/compressLogs.pl"
			perl $SCRIPTS_DIR/compressLogs.pl
			
			
			# 4f. Upload LOGS if necessary
			if [ "$UPLOAD" ]  &&  [ $disableLogsUpload -eq 0 ]; then 
				echo `date` ":  ******** Uploading LOGS to the Server: ( $checkTimeForUploadingStats -- LastLogTime - $lastStatsUploadTime.)\n"
				echo `date` ": _____$dcount UPLOADING LOGS_____"  >> $LOGSFILE
				uploadLogs;
				lastLogsUploadTime=`date "+%s"`
				#${TESTCT} -l "Dump state for AWD"
			fi
		fi
		

		if [ -e /$SCRIPTS_DIR/WiFiSettings.sh ]; then
			echo `date` ": 	WiFiSettings.sh file is present. Getting the values.";
			source $SCRIPTS_DIR/WiFiSettings.sh;
		fi
		
done
