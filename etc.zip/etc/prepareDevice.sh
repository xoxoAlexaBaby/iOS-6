#!/bin/sh

date
	
/bin/mkdir /var/root/OldLogsStats/;
/bin/mv    /var/root/LOG* /var/root/OldLogsStats/;
/bin/mv    /var/root/STATS* /var/root/OldLogsStats/;
/bin/mv    /var/root/CRASHES* /var/root/OldLogsStats/;
/bin/rm -r /var/root/StressTest*;
/bin/rm -r /var/root/Library/Caches/locationd/location*;
/bin/rm -r /var/mobile/Library/SMS/sms.db;
		
/bin/mkdir /private/var/wireless/Library/Logs/CrashReporter/OldCrashLogs/;
/bin/rm    /Library/Logs/CrashReporter/*log;
/bin/rm    /Library/Logs/CrashReporter/*plist;
/bin/mv    /private/var/wireless/Library/Logs/Global*  /var/root/OldLogsStats/;
/bin/mv    /private/var/wireless/Library/Logs/CrashReporter/*plist /var/root/OldLogsStats/;
/bin/mv    /var/mobile/Library/Logs/CrashReporter/*plist /var/root/OldLogsStats/;
/bin/mv    /private/var/wireless/Library/Logs/CrashReporter/Baseband/* /var/root/OldLogsStats/;

/usr/bin/touch /var/mobile/Library/Caches/powerlog.launchd
/usr/local/bin/testCT -c "#*293#"
/usr/bin/perl -p -i -e s/CSILog::fEnabled=0x0/CSILog::fEnabled=0x1/g /private/var/wireless/Library/Preferences/csidata;
/usr/bin/perl -p -i -e s/CSILog::fHistory=0x.*/CSILog::fHistory=0x10/g /private/var/wireless/Library/Preferences/csidata;
/usr/bin/perl -p -i -e s/EURCoreDump::fEnabled=0x.*/EURCoreDump::fEnabled=0x1/g /private/var/wireless/Library/Preferences/csidata;


/usr/sbin/nvram boot-args="amfi_unrestrict_task_for_pid=1 amfi_allow_any_signature=1 cs_enforcement_disable=1 serial=3 asm-debug=0x5 debug=0x14e amfi_get_out_of_my_way=1";
/sbin/reboot;
	
echo 'All done!'


#### CSI History Capacity Settings
# NONE = 0xffffffff
# 128k = 0x2
# 256k = 0x4
# 512k = 0x8
# 1 MB = 0x10
# 4 MB = 0x40
# 16 M = 0x100
# 32 M = 0x200
# 128M = 0x800
# 512M = 0x2000
# Inf  = 0x0


##### MA/Artemis History Capacity Settings
# 8 MB  = 0x8
# 16 MB = 0x10
# 32 MB = 0x20
# 40 MB = 0x28
# 64 MB = 0x40
# 128 MB = 0x80
# 256 MB = 0x100
# 512 MB = 0x200
# Infinite = 0x0
