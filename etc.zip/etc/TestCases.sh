#!/bin/sh
#################################################################################################
#                                                                                               #
#   ScriptName: TestCases.sh                                                                    #
#                                                                                               #
#   Usage:      <path_to_Script>/TestCases.sh                                                   #
#                                                                                               #
#   Purpose:    This Scripts contains functions for running the test cases on PhoenixStress     #
#                                                                                               #
#   Author:     Jerome Jesu                                                                     #
#   Contact:    jesu@apple.com                                                                  #
#   Version:    v20.2                                                                           #
#                                                                                               #
#   Copyright   2010 Apple. All rights reserved.                                                #
#################################################################################################


TOOLSDIR="/usr/local/bin"
#protocol=HTTP

###########################################################################
# FUNCTION to Send/Receive (MO/MT) SMS
# USAGE: sendSMS DEVICE_PHONE_NUMBER COUNT SMS_STRING -- count is optional
###########################################################################
sendSMS()
{
	echo `date` ": _____SENDING SMS START - $dcount,$2 ____"  >> $LOGSFILE
	echo "$TOOLSDIR/testCTP -s $1 \"$2 $3\""
	$TOOLSDIR/testCTP -s $1 "$2 $3" >& /tmp/dummy.txt
	grep "SMSSent PASS" /tmp/dummy.txt; resultSms=$?; rm /tmp/dummy.txt;
	
	if [ $resultSms -eq 0 ]; then
		((spass++)); 
		echo `date` ": SMS ($2) Sent Passed.	Pass: $spass\tFail: $sfail." >> SmsStressTest.txt
	else
		((sfail++));
		echo `date` ": _____SMS $2 FAILED - $dcount ____"	>> $LOGSFILE
		echo `date` ": SMS ($2) FAILED. Iteration: $dcount.";
		echo `date` ": SMS ($2) Sent FAILED.	Pass: $spass\tFail: $sfail." >> SmsStressTest.txt
		if [ $smsFailureLogs ]; then takeK00lState "Sending_SMS--$2--FAILED."; fi
	fi
	echo `date` ": _____SENDING SMS END - $dcount,$2 ____" >> $LOGSFILE
	sleep 2;
}

checkForExistingCall()
{
	${TESTCT} -x | grep status
	if [ $? -eq 0 ]; then 
		${CT_MONITOR} -q 2> CT.txt
		echo "**** Iteration $dcount" >> CallsStressTest.txt;
		date  >> CallsStressTest.txt;
		grep "Call to " CT.txt >> CallsStressTest.txt
		echo `date` ": ***** Ongoing Call before Dialing Call ($1).... Ending it now" >> CallsStressTest.txt;
		echo "***** Calls are still active... even though they should be ended by now. Ending them now"
		/usr/local/etc/scripterUIA/general/ExecuteTest.js��phoneTest_endCall
		eventer c "End"    #end all active calls
		echo "Checking Call Status again"
		${TESTCT} -x
	else
		echo " There are no active calls to end."
	fi
}

###########################################################################
# FUNCTION to Make a MO Call
# USAGE: makeCall LOOPBACKNUMBER CALL_INTERVAL COUNT (optional)
###########################################################################
makeCALL()
{	
	echo `date` ": _____MOCALL $2 START - $dcount ____" >> $LOGSFILE
	checkForExistingCall $3
	$TOOLSDIR/testCTP -c $1 >& /tmp/dummy.txt
	sleep $2; 
	grep "CallStatusActive PASS" /tmp/dummy.txt; resultCall=$?; rm /tmp/dummy.txt;
	
	if [ $resultCall -eq 0 ]; then
		((pass++))
		echo `date` ": Call ($3) passed.  Passed: $pass\tFailed: $fail." >> CallsStressTest.txt;
		echo `date` ": _____MOCALL $2 PASSED - $dcount ____"	>> $LOGSFILE
		$TOOLSDIR/testCTP -e

	else
		((fail++)); echo `date` ": Call ($3) FAILED. Iteration: $dcount.";
		echo `date` ": Call ($3) FAILED.  Passed: $pass\tFailed: $fail." >> CallsStressTest.txt;
		echo `date` ": _____MOCALL $2 FAILED - $dcount ____"	>> $LOGSFILE
	fi

	echo `date` ": _____MOCALL $2 END - $dcount ____"	>> $LOGSFILE
} 



###########################################################################
# Function to Download Data using StreamPerf
# USAGE: DownloadData URL TIMES_to_REPEAT COUNT (optional)
###########################################################################
DownloadData() 
{
	activatePDPContext 0
	webpage=$2
	wAttempts=$1
	FOUND=""
	echo "\n #####  $3. Dowloading $webpage  $wAttempts time(s)."; date;
	echo "\n #####  $3. Dowloading $webpage  $wAttempts time(s). #####" >> DownloadStressTest.txt
	echo `date` ": _____DOWNLOADDATA $webpage START - $dcount,$3 _____"  >> $LOGSFILE
	$TOOLSDIR/StreamPerf $protocol -c 0 -x $wAttempts $webpage > /tmp/DownloadDummy.txt
	FOUND=`grep Average /tmp/DownloadDummy.txt`
	echo `date` ": _____DOWNLOAD = $FOUND _____" >> $LOGSFILE
	echo `date` ": _____DOWNLOADDATA $webpage END - $dcount,$3 _____"  >> $LOGSFILE
	
	cat /tmp/DownloadDummy.txt >> DownloadStressTest.txt
	if [ $logDataFailure -eq 1 ]; then logDataDownloadFailures $dcount $3 $wAttempts; fi
	echo "Downloading $2 $1 time(s) finished.";
	echo `date` ": _____DEACTIVATE PDP - $dcount _____"  >> $LOGSFILE
	#$TOOLSDIR/DataContext -c 1 down; 
	echo;
}


###########################################################################
# FUNCTION to do uploads
# USAGE: uploadData 
###########################################################################
UploadData()
{
		echo `date` ": _____UPLOADDOWNLOAD START - $dcount _____"  >> $LOGSFILE
		uploadServer=$iPERFURL
		date;

		activatePDPContext 0
		((uploadAttempts++));
		echo "\n #####  $dcount. Uploading Data #####" >> UploadStressTest.txt
		uploadServer="ftp://testftp:tftp95014*@pttest.apple.com/Bandwidth/1MB.txt"
		StreamPerf FTP -w -N 1048576 $uploadServer  > /tmp/UploadStressTest.txt
		#echo `date` ": _____UPLOAD - iPerf to $uploadServer START - $dcount _____"  >> $LOGSFILE
		#echo "$TOOLSDIR/iperf -c $uploadServer -t 60 -i 10"
		#$TOOLSDIR/iperf -c $uploadServer -t 60 -i 10 > /tmp/UploadStressTest.txt 

		cat /tmp/UploadStressTest.txt >> UploadStressTest.txt
		#tail -1 /tmp/UploadStressTest.txt >> DataUploadStress.txt
		#FOUND=`tail -1 /tmp/UploadStressTest.txt`
		FOUND=`grep Average /tmp/UploadStressTest.txt`
		echo `date` ": _____UPLOAD = $FOUND _____" >> $LOGSFILE		
	
		echo `date` ": _____UPLOAD END - $dcount _____"  >> $LOGSFILE
}


###########################################################################
# FUNCTION to do simultaneous uploads and downloads
# USAGE: uploadDownloadData 
# PARAMS: 1.$Repetition  2.$URL  3.$waitUploadDownload 
# PARAMS: 4.countForLogs(optional)
###########################################################################
uploadDownloadData()
{
		echo `date` ": _____UPLOADDOWNLOAD START - $dcount _____"  >> $LOGSFILE
		wAttempts=$1
		webpage=$2
		waitUploadDownload=$3
		FOUND=""


		activatePDPContext 0
		echo "Wifi is not enabled so going forward with data download."

		echo "\n #####  $4. Dowloading $2  $wAttempts time(s)."; 
		echo "\n #####  $4. Dowloading $2  $wAttempts time(s). #####" >> DownloadStressTest.txt 
		echo `date` ": _____UPLOADDOWNLOAD-Downloading  $2 START - $dcount,$4 _____"  >> $LOGSFILE
		$TOOLSDIR/StreamPerf $protocol -x $wAttempts $webpage > /tmp/DownloadDummy.txt  &


		((uploadAttempts++));
		echo "\n #####  $dcount. Uploading Data #####" >> UploadStressTest.txt
		echo `date` ": _____UPLOADDOWNLOAD - Uploading START - $dcount _____"  >> $LOGSFILE
		uploadServer="ftp://testftp:tftp95014*@pttest.apple.com/Bandwidth/1MB.txt"
		StreamPerf FTP -w -N 1048576 $uploadServer  > /tmp/UploadStressTest.txt
		#uploadServer=$iPERFURL
		#echo `date` ": _____UPLOADDOWNLOAD - iPerf to $uploadServer START - $dcount _____"  >> $LOGSFILE
		#echo "$TOOLSDIR/iperf -c $uploadServer -t 60 -i 10"
		#$TOOLSDIR/iperf -c $uploadServer -t 60 -i 10 > /tmp/UploadStressTest.txt 

		echo "sleeping for $waitUploadDownload seconds..."
		sleep $waitUploadDownload
	
		killall -9 StreamPerf
		echo `date` ": _____UPLOADDOWNLOAD StreamPerf KILLED - $dcount,$4 _____"  >> $LOGSFILE
		ps -A
		#PIDS1=`ps ux | awk '/StreamPerf/ && !/awk/ {print $2}'`
		#PIDS2=`ps ux | awk '/iperf/ && !/awk/ {print $2}'`
		#echo "Killing iperf and StreamPerfs.. $PIDS1"
		#echo `date` ": _____UPLOADDOWNLOAD StreamPerf PIDs-> $PIDS1 - $dcount,$4 _____"  >> $LOGSFILE
		echo `date` ": _____UPLOADDOWNLOAD Download/Upload KILLED - $dcount,$4 _____"  >> $LOGSFILE

		#$TOOLSDIR/DataContext down
		cat /tmp/DownloadDummy.txt >> DownloadStressTest.txt
		if [ $logDataFailure -eq 1 ]; then  logDataDownloadFailures $dcount $4 $wAttempts; fi
		cat /tmp/UploadStressTest.txt >> UploadStressTest.txt
		#tail -1 /tmp/UploadStressTest.txt >> DataUploadStress.txt
		#FOUND=`tail -1 /tmp/UploadStressTest.txt`
		FOUND=`grep Average /tmp/UploadStressTest.txt`
		echo `date` ": _____UPLOAD = $FOUND _____" >> $LOGSFILE	
	
		FOUND=`grep Average /tmp/DownloadDummy.txt`
		echo `date` ": _____DOWNLOAD = $FOUND _____" >> $LOGSFILE
		
		echo `date` ": _____UPLOADDOWNLOAD END - $dcount _____"  >> $LOGSFILE
	fi
}


#########################################################
# Activate PDP Context and check for Failures
#########################################################
activatePDPContext()
{
	if [ "$1" ]; then pdpid=$1;
	else pdpid=0; fi
	((pdpAttempts++))
	
	echo `date` ": _____ACTIVATE PDP START - $dcount _____"  >> $LOGSFILE
	$TOOLSDIR/DataContext -c $pdpid up > /tmp/DataContextStatus
	echo `date` ": _____ACTIVATE PDP START - $dcount _____" >> DataContextStatus.txt
	cat /tmp/DataContextStatus  >> DataContextStatus.txt
	grep "PDP Context $pdpid is up" /tmp/DataContextStatus
	resultPDP=$?
	
	if [ $resultPDP -eq 0 ]; then
		#echo " **** PDP Context Activation Failed..."
		#echo `date` ": _____ACTIVATE PDP FAILED - $dcount _____"  >> $LOGSFILE
		((pdpFails++))
	fi
	#rm /tmp/DataContextStatus
	echo `date` ": _____ACTIVATE PDP END - $dcount _____"  >> $LOGSFILE
}


#########################################################
# STOP and START LOCMON on the background every N iterations
#########################################################
stopStartLocmon()
{
	echo "Entering Function to check whether GPS is running... "
	echo "Starting Locmon to stress the GPS and Baseband..."
	echo `date` ": _____Locmon STOP - $dcount _____"  >> $LOGSFILE
	killall -9 locmon
	echo `date` ": _____Locmon PAUSE - $dcount _____"  >> $LOGSFILE
	sleep 30
	$TOOLSDIR/locmon -l -i 2> locmonStressTest.txt &
	echo `date` ": _____Locmon START - $dcount _____"  >> $LOGSFILE
}


###########################################################################
# Function to Dump the Unwanted Logs 
###########################################################################
dumpLogs()
{
		echo ": Dumping Logs after $1 iterations using SIGUSR2...   \c"; date;
		killall -USR2 CommCenter
		sleep 10
}


#########################################################
# Functions to check whether Baseband is in reset state
# or Power Asserted before entering Sleep Cycler.
#########################################################
checkResetState()
{
	isBBReset=0
	$TOOLSDIR/CTGetResetState | grep "CommCenter in reset state";
	
	if [ $? -eq 0 ]; then isBBReset=1;
	else isBBReset=0;
	fi
	
	echo "CheckResetState: isBBReset = $isBBReset."
}


checkPowerAssertion()
{
	isPowerAsserted=1
	powerCount=0
	#assertion=`${TOOLS_DIR}/powerstat  | head -n 2 | tail -n 1 | tr -d ' '`

	while [ $isPowerAsserted -eq 1 ]; do
		assertion=`${TOOLS_DIR}/powerstat -a | grep PreventUserIdleSystemSleep | grep -v springboard`
		
		if [ "$assertion" ]; then
			((powerCount++))
			echo "PowerCount = $powerCount, assertion= $assertion"
			isPowerAsserted=1
		else
			isPowerAsserted=0
			echo "No Power Assertion.. Assertion=$assertion, isPowerAsserted=$isPowerAsserted."
			break;
		fi
		
		if [ $powerCount -gt 2 ]; then 
			echo "PowerCount = $powerCount, assertion= $isPowerAsserted"
			break; 
		fi
		sleep 5

	done
}


readyToRunSleepCycler()
{
	timeToSleep=0
	maxTimeToWait=210
	
	checkResetState
	
	while [ $isBBReset -eq 1 ]; 
	do
		echo "Sleeping for 30 seconds before checking again."
		sleep 30;
		timeToSleep=$(($timeToSleep + 30));
		
		if [ $timeToSleep -ge $maxTimeToWait ]; then 
			echo "Max Timer exceeded $maxTimeToWait seconds wait period."
			break; 
		fi
		echo "checking again after $timeToSleep seconds... since isBBReset = $isBBReset."
		checkResetState
		
	done
	
	checkPowerAssertion
	echo "checkPowerAssertion: isPowerAsserted = $isPowerAsserted, $assertion."
	echo "readyToRunSleepCycler: isBBReset = $isBBReset. isPowerAsserted = $isPowerAsserted."

}

#########################################################
# run SleepCycler for 1 iteration $2=sleepTime $1=Count
#########################################################
runSleepCycler()
{	
	echo "Check if we are READY to run SleepCycler..."
	sleep 5
	readyToRunSleepCycler
	
	if [ $isBBReset -eq 0 ] && [ $isPowerAsserted -eq 0 ]; then
		echo `date` ": _____DEVICE ENTERING SLEEP -- RESET=$isBBReset,POWER=$isPowerAsserted-$assertion - $dcount,$1 _____"  >> $LOGSFILE
		echo "\n$1. Sleepcycling 1 time -n 1 -s $2";
		$TOOLSDIR/SleepCycler -n 1 -s $2;
		echo `date` ": _____WAKE UP FROM SLEEP - $dcount,$1 _____"
		echo `date` ": _____WAKE UP FROM SLEEP - $dcount,$1 _____"  >> $LOGSFILE
	else 
		echo "Skipping SleepCycler since Baseband is resetting or Power Asserted..."
		echo `date` ": _____NO SLEEPCYCLING -- RESET=$isBBReset,POWER=$isPowerAsserted-$assertion - $dcount,$1 _____"  >> $LOGSFILE
	fi
	
}
